import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.chart.axis.ValueAxis valueAxis3 = categoryPlot0.getRangeAxisForDataset(0);
        java.awt.Stroke stroke4 = categoryPlot0.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setRangeCrosshairValue(0.0d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomDomainAxes((double) 10, plotRenderingInfo10, point2D11);
        boolean boolean13 = categoryPlot0.isRangeCrosshairVisible();
        categoryPlot0.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str7 = categoryPlot6.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font9 = categoryAxis8.getLabelFont();
        categoryPlot6.setNoDataMessageFont(font9);
        java.awt.Font font11 = categoryPlot6.getNoDataMessageFont();
        boolean boolean12 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot6);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis11.setNegativeArrowVisible(false);
        java.awt.Paint paint14 = numberAxis11.getTickMarkPaint();
        org.jfree.data.Range range15 = numberAxis11.getRange();
        int int16 = categoryPlot0.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis11);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot0.getDomainAxis(255);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNull(categoryAxis18);
    }

//    @Test
//    public void test005() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test005");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        numberAxis1.setUpperMargin((double) 100.0f);
        double double7 = numberAxis1.getFixedDimension();
        boolean boolean8 = numberAxis1.isAutoRange();
        org.jfree.chart.plot.Plot plot9 = null;
        numberAxis1.setPlot(plot9);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range4, true, false);
        numberAxis1.resizeRange((-9.0d), (double) 'a');
        java.lang.Object obj11 = null;
        boolean boolean12 = numberAxis1.equals(obj11);
        java.awt.Shape shape13 = numberAxis1.getRightArrow();
        numberAxis1.setLabelToolTip("java.awt.Color[r=128,g=0,b=128]");
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setCategoryMargin(0.2d);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double13 = numberAxis12.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis15.setNegativeArrowVisible(false);
        java.awt.Shape shape18 = numberAxis15.getDownArrow();
        numberAxis15.setUpperMargin((double) 100.0f);
        double double21 = numberAxis15.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis12, (org.jfree.chart.axis.ValueAxis) numberAxis15, xYItemRenderer22);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str26 = categoryPlot25.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font28 = categoryAxis27.getLabelFont();
        categoryPlot25.setNoDataMessageFont(font28);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot25.addDomainMarker((int) 'a', categoryMarker32, layer33);
        java.util.Collection collection35 = xYPlot23.getRangeMarkers(3, layer33);
        xYPlot23.clearRangeMarkers();
        java.awt.Stroke stroke37 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot23.setDomainCrosshairStroke(stroke37);
        categoryAxis1.setTickMarkStroke(stroke37);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        java.awt.Color color0 = java.awt.Color.WHITE;
        java.awt.Color color1 = color0.darker();
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        int int3 = color1.getTransparency();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        float[] floatArray6 = new float[] {};
        try {
            float[] floatArray7 = color1.getComponents(colorSpace5, floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone7);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass12 = color11.getClass();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.Class class15 = null;
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone17);
        java.awt.Color color20 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass21 = color20.getClass();
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.lang.Class class24 = null;
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone26);
        java.lang.Class class29 = null;
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date22, timeZone31);
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color35 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass36 = color35.getClass();
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.lang.Class class39 = null;
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date34, timeZone41);
        java.lang.Class class45 = null;
        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date34, timeZone47);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("13-June-2019", timeZone47);
        dateAxis50.configure();
        java.lang.Object obj52 = dateAxis50.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(obj52);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        boolean boolean13 = sortOrder11.equals((java.lang.Object) chartChangeEventType12);
        java.lang.String str14 = chartChangeEventType12.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str14.equals("ChartChangeEventType.GENERAL"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot13.getRangeAxisEdge();
        xYPlot13.setRangeZeroBaselineVisible(true);
        java.awt.Stroke stroke29 = xYPlot13.getDomainZeroBaselineStroke();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("PlotOrientation.HORIZONTAL");
        int int2 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-4.0d), font3);
        double double5 = categoryAxis1.getLowerMargin();
        java.awt.Color color7 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass8 = color7.getClass();
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        java.lang.Class class11 = null;
        java.util.Date date12 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone13 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = org.jfree.data.time.RegularTimePeriod.createInstance(class11, date12, timeZone13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass8, date9, timeZone13);
        java.lang.Class class16 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass8);
        java.awt.Color color17 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass18 = color17.getClass();
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        java.lang.Class class21 = null;
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone23 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = org.jfree.data.time.RegularTimePeriod.createInstance(class21, date22, timeZone23);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date19, timeZone23);
        java.awt.Color color26 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass27 = color26.getClass();
        java.util.Date date28 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        java.lang.Class class30 = null;
        java.util.Date date31 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone32 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date31, timeZone32);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass27, date28, timeZone32);
        java.lang.Class class35 = null;
        java.util.Date date36 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone37 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = org.jfree.data.time.RegularTimePeriod.createInstance(class35, date36, timeZone37);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date28, timeZone37);
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color41 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass42 = color41.getClass();
        java.util.Date date43 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
        java.lang.Class class45 = null;
        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass42, date43, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod50 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass18, date40, timeZone47);
        java.lang.Class class51 = null;
        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone53 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = org.jfree.data.time.RegularTimePeriod.createInstance(class51, date52, timeZone53);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod55 = org.jfree.data.time.RegularTimePeriod.createInstance(class16, date40, timeZone53);
        org.jfree.chart.axis.DateAxis dateAxis56 = new org.jfree.chart.axis.DateAxis("13-June-2019", timeZone53);
        java.util.Date date57 = dateAxis56.getMaximumDate();
        java.awt.Paint paint58 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) date57);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertNotNull(timeZone13);
        org.junit.Assert.assertNull(regularTimePeriod14);
        org.junit.Assert.assertNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(class16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeZone23);
        org.junit.Assert.assertNull(regularTimePeriod24);
        org.junit.Assert.assertNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNotNull(timeZone32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNotNull(timeZone37);
        org.junit.Assert.assertNull(regularTimePeriod38);
        org.junit.Assert.assertNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNull(regularTimePeriod49);
        org.junit.Assert.assertNull(regularTimePeriod50);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(timeZone53);
        org.junit.Assert.assertNull(regularTimePeriod54);
        org.junit.Assert.assertNotNull(regularTimePeriod55);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        xYPlot13.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        xYPlot13.zoomDomainAxes((double) (-65281), (double) (short) 1, plotRenderingInfo29, point2D30);
        java.awt.Paint paint32 = xYPlot13.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        categoryAxis2.addChangeListener(axisChangeListener4);
        categoryAxis2.setLabelAngle((double) 100);
        java.awt.Color color8 = java.awt.Color.WHITE;
        categoryAxis2.setTickMarkPaint((java.awt.Paint) color8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        double double12 = categoryAxis11.getLowerMargin();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis11.setAxisLineStroke(stroke13);
        java.awt.Color color17 = java.awt.Color.getColor("hi!", 0);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color8, stroke13, (java.awt.Paint) color17, stroke18, 0.0f);
        int int21 = color8.getRed();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        categoryPlot0.drawBackgroundImage(graphics2D2, rectangle2D3);
        float float5 = categoryPlot0.getBackgroundAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        boolean boolean10 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot6.getRangeAxis(255);
        categoryPlot6.setRangeCrosshairValue(0.0d);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot6.getDomainAxisLocation((int) '#');
        categoryPlot0.setDomainAxisLocation(axisLocation16, false);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 1.0f + "'", float5 == 1.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(axisLocation16);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = null;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7, stroke8 };
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] { stroke10, stroke11, stroke12, stroke13, stroke14 };
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray9, strokeArray15, shapeArray16);
        java.awt.Stroke stroke18 = defaultDrawingSupplier17.getNextOutlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        boolean boolean21 = defaultDrawingSupplier17.equals((java.lang.Object) categoryAxis20);
        try {
            java.awt.Paint paint22 = defaultDrawingSupplier17.getNextFillPaint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = color4.darker();
        categoryAxis2.setTickMarkPaint((java.awt.Paint) color4);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        double double8 = categoryPlot7.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot7.getDataset((int) (byte) 1);
        categoryAxis2.setPlot((org.jfree.chart.plot.Plot) categoryPlot7);
        org.jfree.chart.util.SortOrder sortOrder12 = categoryPlot7.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        categoryPlot7.setRenderer(categoryItemRenderer13);
        double double15 = categoryPlot7.getRangeCrosshairValue();
        boolean boolean16 = chartChangeEventType0.equals((java.lang.Object) categoryPlot7);
        java.lang.String str17 = chartChangeEventType0.toString();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNotNull(sortOrder12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str17.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.util.UnitType unitType17 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = new org.jfree.chart.util.RectangleInsets(unitType17, (double) 11, 0.2d, (double) (-16777216), (double) (-16777216));
        xYPlot13.setInsets(rectangleInsets22, true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(unitType17);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        categoryAxis1.setLabelAngle((double) 100);
        boolean boolean7 = categoryAxis1.isTickLabelsVisible();
        categoryAxis1.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint11 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 100);
        double double12 = categoryAxis1.getUpperMargin();
        double double13 = categoryAxis1.getLowerMargin();
        categoryAxis1.setAxisLineVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape17 = defaultDrawingSupplier16.getNextShape();
        boolean boolean18 = categoryAxis1.equals((java.lang.Object) defaultDrawingSupplier16);
        java.awt.Stroke stroke19 = defaultDrawingSupplier16.getNextOutlineStroke();
        java.awt.Stroke stroke20 = defaultDrawingSupplier16.getNextOutlineStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis7.setNegativeArrowVisible(false);
        java.awt.Shape shape10 = numberAxis7.getDownArrow();
        boolean boolean11 = numberAxis7.isVerticalTickLabels();
        org.jfree.chart.plot.Plot plot12 = numberAxis7.getPlot();
        int int13 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        float float14 = xYPlot0.getBackgroundImageAlpha();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = xYPlot0.getRenderer(2);
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNull(xYItemRenderer16);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot0.getRendererForDataset(xYDataset5);
        java.awt.Stroke stroke7 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection10 = xYPlot0.getDomainMarkers(4, layer9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot0.getRenderer();
        double double12 = xYPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double15 = numberAxis14.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis17.setNegativeArrowVisible(false);
        java.awt.Shape shape20 = numberAxis17.getDownArrow();
        numberAxis17.setUpperMargin((double) 100.0f);
        double double23 = numberAxis17.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer24);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource30 = numberAxis27.getStandardTickUnits();
        xYPlot25.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis27);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis33.setNegativeArrowVisible(false);
        boolean boolean36 = numberAxis33.isNegativeArrowVisible();
        java.lang.String str37 = numberAxis33.getLabelURL();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis39.setNegativeArrowVisible(false);
        java.awt.Shape shape42 = numberAxis39.getDownArrow();
        numberAxis39.setUpperMargin((double) 100.0f);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand45 = numberAxis39.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis47.setNegativeArrowVisible(false);
        org.jfree.data.Range range50 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis47.setRange(range50, true, false);
        numberAxis47.resizeRange((-9.0d), (double) 'a');
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double59 = numberAxis58.getUpperMargin();
        double double60 = numberAxis58.getLowerBound();
        double double61 = numberAxis58.getUpperMargin();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray62 = new org.jfree.chart.axis.ValueAxis[] { numberAxis27, numberAxis33, numberAxis39, numberAxis47, numberAxis58 };
        categoryPlot0.setRangeAxes(valueAxisArray62);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation64 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNull(markerAxisBand45);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.05d + "'", double59 == 0.05d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.05d + "'", double61 == 0.05d);
        org.junit.Assert.assertNotNull(valueAxisArray62);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        java.awt.Color color2 = java.awt.Color.getColor("AxisLocation.TOP_OR_LEFT", 2019);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace17, false);
        xYPlot13.setRangeCrosshairLockedOnData(false);
        java.awt.Paint paint22 = xYPlot13.getBackgroundPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        categoryAxis1.setLabelAngle((double) 100);
        boolean boolean7 = categoryAxis1.isTickLabelsVisible();
        categoryAxis1.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint11 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 100);
        double double12 = categoryAxis1.getUpperMargin();
        java.awt.Paint paint13 = categoryAxis1.getLabelPaint();
        java.lang.String str14 = categoryAxis1.getLabelURL();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        intervalMarker10.setGradientPaintTransformer(gradientPaintTransformer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        double double15 = categoryAxis14.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis14.getTickLabelInsets();
        java.awt.Paint paint18 = categoryAxis14.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font19 = categoryAxis14.getLabelFont();
        intervalMarker10.setLabelFont(font19);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        double double24 = categoryAxis23.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryAxis23.getTickLabelInsets();
        java.awt.Paint paint27 = categoryAxis23.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font28 = categoryAxis23.getLabelFont();
        double double29 = categoryAxis23.getLowerMargin();
        categoryAxis23.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection33 = categoryPlot32.getFixedLegendItems();
        java.awt.Image image34 = null;
        categoryPlot32.setBackgroundImage(image34);
        java.util.List list36 = categoryPlot32.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot32.getDomainAxisEdge();
        boolean boolean38 = categoryAxis23.hasListener((java.util.EventListener) categoryPlot32);
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis40.setNegativeArrowVisible(false);
        categoryPlot32.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis40);
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        numberAxis40.setTickLabelPaint((java.awt.Paint) color44);
        boolean boolean46 = numberAxis40.isNegativeArrowVisible();
        boolean boolean47 = intervalMarker10.equals((java.lang.Object) numberAxis40);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis49.setNegativeArrowVisible(false);
        org.jfree.data.Range range52 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis49.setRange(range52, true, false);
        numberAxis40.setRangeWithMargins(range52, false, true);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand59 = numberAxis40.getMarkerBand();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection33);
        org.junit.Assert.assertNull(list36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNull(markerAxisBand59);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray3 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer2 };
        xYPlot0.setRenderers(xYItemRendererArray3);
        boolean boolean5 = xYPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNotNull(xYItemRendererArray3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot0.getIndexOf(categoryItemRenderer12);
        java.awt.Color color14 = java.awt.Color.darkGray;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color14);
        java.util.List list16 = categoryPlot0.getAnnotations();
        java.awt.Paint paint17 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        double double20 = categoryAxis19.getLowerMargin();
        java.awt.Color color21 = java.awt.Color.WHITE;
        java.awt.Color color22 = color21.darker();
        categoryAxis19.setTickMarkPaint((java.awt.Paint) color21);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        double double25 = categoryPlot24.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset27 = categoryPlot24.getDataset((int) (byte) 1);
        categoryAxis19.setPlot((org.jfree.chart.plot.Plot) categoryPlot24);
        org.jfree.chart.util.SortOrder sortOrder29 = categoryPlot24.getRowRenderingOrder();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType30 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        boolean boolean31 = sortOrder29.equals((java.lang.Object) lengthAdjustmentType30);
        categoryPlot0.setColumnRenderingOrder(sortOrder29);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset27);
        org.junit.Assert.assertNotNull(sortOrder29);
        org.junit.Assert.assertNotNull(lengthAdjustmentType30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str17 = plotOrientation16.toString();
        xYPlot13.setOrientation(plotOrientation16);
        int int19 = xYPlot13.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str17.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        categoryPlot0.clearAnnotations();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            categoryPlot0.drawOutline(graphics2D5, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent17 = null;
        categoryPlot10.notifyListeners(plotChangeEvent17);
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot10.getRangeMarkers(4, layer20);
        categoryPlot10.setDomainGridlinesVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(collection21);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font3 = categoryAxis2.getLabelFont();
        categoryPlot0.setNoDataMessageFont(font3);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxisForDataset((int) (byte) 1);
        boolean boolean8 = categoryPlot0.getDrawSharedDomainAxis();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        double double5 = rectangleInsets3.trimHeight((double) 0L);
        double double7 = rectangleInsets3.calculateRightOutset((double) 43629L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-4.0d) + "'", double5 == (-4.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-4.0d), font3);
        boolean boolean5 = categoryAxis1.isTickMarksVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis1.getLabelInsets();
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double14 = numberAxis13.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis16.setNegativeArrowVisible(false);
        java.awt.Shape shape19 = numberAxis16.getDownArrow();
        numberAxis16.setUpperMargin((double) 100.0f);
        double double22 = numberAxis16.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer23);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str27 = categoryPlot26.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font29 = categoryAxis28.getLabelFont();
        categoryPlot26.setNoDataMessageFont(font29);
        org.jfree.chart.plot.CategoryMarker categoryMarker33 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer34 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot26.addDomainMarker((int) 'a', categoryMarker33, layer34);
        java.util.Collection collection36 = xYPlot24.getRangeMarkers(3, layer34);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot24.getRangeAxisEdge();
        boolean boolean38 = xYPlot24.isDomainZeroBaselineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = xYPlot24.getDomainAxisEdge((-1));
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        try {
            org.jfree.chart.axis.AxisState axisState42 = categoryAxis1.draw(graphics2D7, (double) 15, rectangle2D9, rectangle2D10, rectangleEdge40, plotRenderingInfo41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(layer34);
        org.junit.Assert.assertNull(collection36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray3 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer2 };
        xYPlot0.setRenderers(xYItemRendererArray3);
        org.jfree.data.xy.XYDataset xYDataset6 = xYPlot0.getDataset((int) (byte) 10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNotNull(xYItemRendererArray3);
        org.junit.Assert.assertNull(xYDataset6);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setRangeCrosshairValue(0.0d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomDomainAxes((double) 10, plotRenderingInfo10, point2D11);
        java.lang.String str13 = categoryPlot0.getNoDataMessage();
        java.awt.Paint paint14 = categoryPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(str13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        double double5 = numberAxis1.getUpperBound();
        numberAxis1.centerRange((double) (byte) 0);
        numberAxis1.setNegativeArrowVisible(true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot13.getRangeAxisEdge();
        boolean boolean27 = xYPlot13.isDomainZeroBaselineVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot13.getDomainAxisEdge((-1));
        xYPlot13.mapDatasetToRangeAxis(255, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(categoryItemRenderer12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        int int15 = categoryPlot6.getIndexOf(categoryItemRenderer14);
        java.util.List list16 = categoryPlot6.getCategories();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double22 = numberAxis21.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis24.setNegativeArrowVisible(false);
        java.awt.Shape shape27 = numberAxis24.getDownArrow();
        numberAxis24.setUpperMargin((double) 100.0f);
        double double30 = numberAxis24.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset19, (org.jfree.chart.axis.ValueAxis) numberAxis21, (org.jfree.chart.axis.ValueAxis) numberAxis24, xYItemRenderer31);
        boolean boolean33 = xYPlot32.isDomainCrosshairLockedOnData();
        java.awt.geom.Point2D point2D34 = xYPlot32.getQuadrantOrigin();
        categoryPlot6.zoomDomainAxes((double) (short) 0, plotRenderingInfo18, point2D34);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(list16);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(point2D34);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        categoryPlot0.mapDatasetToDomainAxis((int) (byte) 10, 0);
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot13.getRangeAxisEdge();
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot13.getDomainAxis(255);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        double double30 = categoryPlot29.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot29.getDataset((int) (byte) 1);
        boolean boolean33 = categoryPlot29.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis35 = categoryPlot29.getRangeAxis(255);
        categoryPlot29.setRangeCrosshairValue(0.0d);
        java.awt.Paint paint38 = categoryPlot29.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation39, plotOrientation40);
        categoryPlot29.setOrientation(plotOrientation40);
        java.awt.Paint[] paintArray43 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray44 = null;
        java.awt.Paint[] paintArray45 = null;
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke48 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke50 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray52 = new java.awt.Stroke[] { stroke46, stroke47, stroke48, stroke49, stroke50, stroke51 };
        java.awt.Stroke stroke53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke57 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] { stroke53, stroke54, stroke55, stroke56, stroke57 };
        java.awt.Shape[] shapeArray59 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray43, paintArray44, paintArray45, strokeArray52, strokeArray58, shapeArray59);
        java.awt.Stroke stroke61 = defaultDrawingSupplier60.getNextOutlineStroke();
        categoryPlot29.setRangeGridlineStroke(stroke61);
        java.awt.Paint paint63 = categoryPlot29.getRangeGridlinePaint();
        xYPlot13.setRangeCrosshairPaint(paint63);
        java.awt.Color color65 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace66 = color65.getColorSpace();
        xYPlot13.setDomainTickBandPaint((java.awt.Paint) color65);
        xYPlot13.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(valueAxis35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(paintArray43);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(strokeArray52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(shapeArray59);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(colorSpace66);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        double double5 = numberAxis1.getUpperBound();
        numberAxis1.centerRange((double) (byte) 0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double11 = numberAxis10.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis13.setNegativeArrowVisible(false);
        java.awt.Shape shape16 = numberAxis13.getDownArrow();
        numberAxis13.setUpperMargin((double) 100.0f);
        double double19 = numberAxis13.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer20);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis13.setTickUnit(numberTickUnit22, true, true);
        numberAxis1.setTickUnit(numberTickUnit22);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection28 = categoryPlot27.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis29 = categoryPlot27.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot27.getDomainAxisLocation(255);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = categoryPlot27.getDomainAxis();
        categoryPlot27.clearRangeMarkers();
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot27);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit22);
        org.junit.Assert.assertNull(legendItemCollection28);
        org.junit.Assert.assertNull(valueAxis29);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNull(categoryAxis32);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-4.0d), font3);
        boolean boolean5 = categoryAxis1.isTickMarksVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis1.getLabelInsets();
        categoryAxis1.setLowerMargin((double) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis1.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            rectangleInsets9.trim(rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setRangeCrosshairValue(0.0d);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getDomainAxisLocation((int) '#');
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        try {
            boolean boolean12 = categoryPlot0.removeAnnotation(categoryAnnotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str1.equals("TextAnchor.BASELINE_RIGHT"));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 12, (double) 43629L, (double) 10L, (double) 500);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            rectangleInsets4.trim(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        java.awt.Stroke stroke12 = categoryPlot6.getOutlineStroke();
        java.awt.Font font13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot6.setNoDataMessageFont(font13);
        float float15 = categoryPlot6.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 1.0f + "'", float15 == 1.0f);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot13.zoomRangeAxes((double) 100.0f, plotRenderingInfo19, point2D20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.CrosshairState crosshairState26 = null;
        boolean boolean27 = xYPlot13.render(graphics2D22, rectangle2D23, 1, plotRenderingInfo25, crosshairState26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str29 = categoryPlot28.getNoDataMessage();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        int int31 = categoryPlot28.getIndexOf(categoryItemRenderer30);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent32 = null;
        categoryPlot28.datasetChanged(datasetChangeEvent32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot28.zoomRangeAxes(0.0d, plotRenderingInfo35, point2D36, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        boolean boolean41 = categoryPlot28.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker40);
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker40);
        java.lang.Comparable comparable43 = categoryMarker40.getKey();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", comparable43.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot0.getRangeAxisLocation((int) '4');
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis14.setNegativeArrowVisible(false);
        java.awt.Paint paint17 = numberAxis14.getTickMarkPaint();
        numberAxis14.setUpperBound(10.0d);
        java.lang.String str20 = numberAxis14.getLabelToolTip();
        categoryPlot0.setRangeAxis(2, (org.jfree.chart.axis.ValueAxis) numberAxis14, false);
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone7);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass12 = color11.getClass();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.Class class15 = null;
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone17);
        java.awt.Color color20 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass21 = color20.getClass();
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.lang.Class class24 = null;
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone26);
        java.lang.Class class29 = null;
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date22, timeZone31);
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color35 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass36 = color35.getClass();
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.lang.Class class39 = null;
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date34, timeZone41);
        java.lang.Class class45 = null;
        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date34, timeZone47);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("13-June-2019", timeZone47);
        java.util.Date date51 = dateAxis50.getMaximumDate();
        java.util.Date date52 = dateAxis50.getMaximumDate();
        try {
            dateAxis50.setRange((double) (byte) 1, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(date52);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font3 = categoryAxis2.getLabelFont();
        categoryPlot0.setNoDataMessageFont(font3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray6 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer5 };
        categoryPlot0.setRenderers(categoryItemRendererArray6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str9 = categoryPlot8.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font11 = categoryAxis10.getLabelFont();
        categoryPlot8.setNoDataMessageFont(font11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer13 };
        categoryPlot8.setRenderers(categoryItemRendererArray14);
        categoryPlot0.setRenderers(categoryItemRendererArray14);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray6);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
    }

//    @Test
//    public void test057() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test057");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.xy.XYDataset xYDataset4 = null;
//        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
//        double double7 = numberAxis6.getUpperMargin();
//        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
//        numberAxis9.setNegativeArrowVisible(false);
//        java.awt.Shape shape12 = numberAxis9.getDownArrow();
//        numberAxis9.setUpperMargin((double) 100.0f);
//        double double15 = numberAxis9.getFixedDimension();
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
//        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis9, xYItemRenderer16);
//        xYPlot17.setRangeGridlinesVisible(false);
//        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getRangeAxisEdge(11);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
//        java.awt.geom.Point2D point2D24 = null;
//        xYPlot17.zoomRangeAxes((double) 100.0f, plotRenderingInfo23, point2D24);
//        xYPlot17.setRangeCrosshairValue(0.2d, true);
//        boolean boolean29 = day0.equals((java.lang.Object) xYPlot17);
//        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) day0);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
//        org.junit.Assert.assertNotNull(shape12);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
//        org.junit.Assert.assertNotNull(rectangleEdge21);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double15 = numberAxis14.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis17.setNegativeArrowVisible(false);
        java.awt.Shape shape20 = numberAxis17.getDownArrow();
        numberAxis17.setUpperMargin((double) 100.0f);
        double double23 = numberAxis17.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer24);
        boolean boolean26 = xYPlot25.isDomainCrosshairLockedOnData();
        java.awt.geom.Point2D point2D27 = xYPlot25.getQuadrantOrigin();
        categoryPlot0.zoomRangeAxes(1.0d, plotRenderingInfo11, point2D27, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(point2D27);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        xYPlot13.mapDatasetToRangeAxis(1, (int) 'a');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        try {
            xYPlot13.handleClick((int) ' ', 8, plotRenderingInfo20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = null;
        intervalMarker8.setGradientPaintTransformer(gradientPaintTransformer9);
        java.awt.Paint paint11 = intervalMarker8.getLabelPaint();
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean14 = categoryPlot0.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) intervalMarker8, layer12, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot0.setRenderer((int) 'a', categoryItemRenderer16, false);
        org.jfree.chart.util.SortOrder sortOrder19 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        double double22 = categoryAxis21.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener23 = null;
        categoryAxis21.addChangeListener(axisChangeListener23);
        categoryAxis21.setLabelAngle((double) 100);
        java.awt.Color color27 = java.awt.Color.WHITE;
        categoryAxis21.setTickMarkPaint((java.awt.Paint) color27);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color27);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(sortOrder19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperMargin();
        double double3 = numberAxis1.getLowerBound();
        numberAxis1.setLabelAngle((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) -1, 3, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = null;
        java.awt.geom.Point2D point2D6 = null;
        xYPlot0.zoomDomainAxes((double) 4, (double) (short) -1, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot0.setFixedRangeAxisSpace(axisSpace8, true);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        try {
            boolean boolean13 = xYPlot0.removeAnnotation(xYAnnotation11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setRangeCrosshairValue(0.0d);
        java.awt.Paint paint9 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation11);
        categoryPlot0.setOrientation(plotOrientation11);
        java.awt.Paint[] paintArray14 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray15 = null;
        java.awt.Paint[] paintArray16 = null;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] { stroke17, stroke18, stroke19, stroke20, stroke21, stroke22 };
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] { stroke24, stroke25, stroke26, stroke27, stroke28 };
        java.awt.Shape[] shapeArray30 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray14, paintArray15, paintArray16, strokeArray23, strokeArray29, shapeArray30);
        java.awt.Stroke stroke32 = defaultDrawingSupplier31.getNextOutlineStroke();
        categoryPlot0.setRangeGridlineStroke(stroke32);
        java.awt.Paint paint34 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        double double36 = categoryPlot35.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset38 = categoryPlot35.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = categoryPlot35.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.data.Range range42 = categoryPlot35.getDataRange(valueAxis41);
        java.awt.Paint paint43 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot35.setNoDataMessagePaint(paint43);
        java.awt.Color color45 = java.awt.Color.blue;
        categoryPlot35.setNoDataMessagePaint((java.awt.Paint) color45);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        int int48 = categoryPlot35.getIndexOf(categoryItemRenderer47);
        java.awt.Color color49 = java.awt.Color.darkGray;
        categoryPlot35.setNoDataMessagePaint((java.awt.Paint) color49);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        double double53 = categoryAxis52.getLowerMargin();
        java.awt.Color color54 = java.awt.Color.WHITE;
        java.awt.Color color55 = color54.darker();
        categoryAxis52.setTickMarkPaint((java.awt.Paint) color54);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        double double58 = categoryPlot57.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset60 = categoryPlot57.getDataset((int) (byte) 1);
        categoryAxis52.setPlot((org.jfree.chart.plot.Plot) categoryPlot57);
        org.jfree.chart.util.SortOrder sortOrder62 = categoryPlot57.getRowRenderingOrder();
        categoryPlot35.setRowRenderingOrder(sortOrder62);
        categoryPlot0.setRowRenderingOrder(sortOrder62);
        org.jfree.chart.axis.AxisSpace axisSpace65 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(shapeArray30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset38);
        org.junit.Assert.assertNull(categoryAxis40);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.05d + "'", double53 == 0.05d);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset60);
        org.junit.Assert.assertNotNull(sortOrder62);
        org.junit.Assert.assertNull(axisSpace65);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        double double5 = numberAxis1.getUpperBound();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis7.setNegativeArrowVisible(false);
        java.awt.Shape shape10 = numberAxis7.getDownArrow();
        numberAxis7.setUpperMargin((double) 100.0f);
        java.text.NumberFormat numberFormat13 = numberAxis7.getNumberFormatOverride();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis15.setNegativeArrowVisible(false);
        java.awt.Paint paint18 = numberAxis15.getTickMarkPaint();
        org.jfree.data.Range range19 = numberAxis15.getRange();
        numberAxis7.setDefaultAutoRange(range19);
        numberAxis1.setRangeWithMargins(range19, true, true);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.Plot plot25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        double double28 = categoryPlot27.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset30 = categoryPlot27.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = categoryPlot27.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.data.Range range34 = categoryPlot27.getDataRange(valueAxis33);
        java.awt.Paint paint35 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot27.setNoDataMessagePaint(paint35);
        java.awt.Color color37 = java.awt.Color.blue;
        categoryPlot27.setNoDataMessagePaint((java.awt.Paint) color37);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        int int40 = categoryPlot27.getIndexOf(categoryItemRenderer39);
        org.jfree.chart.plot.Plot plot41 = categoryPlot27.getRootPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot27.getRangeAxisEdge(2);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace45 = numberAxis1.reserveSpace(graphics2D24, plot25, rectangle2D26, rectangleEdge43, axisSpace44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(numberFormat13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset30);
        org.junit.Assert.assertNull(categoryAxis32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(plot41);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot0.getIndexOf(categoryItemRenderer12);
        java.awt.Color color14 = java.awt.Color.darkGray;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.util.Layer layer16 = null;
        java.util.Collection collection17 = categoryPlot0.getRangeMarkers(layer16);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(collection17);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        double double4 = categoryAxis3.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis3.getTickLabelInsets();
        java.awt.Paint paint7 = categoryAxis3.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font8 = categoryAxis3.getLabelFont();
        double double9 = categoryAxis3.getLowerMargin();
        categoryAxis3.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot12.getFixedLegendItems();
        java.awt.Image image14 = null;
        categoryPlot12.setBackgroundImage(image14);
        java.util.List list16 = categoryPlot12.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot12.getDomainAxisEdge();
        boolean boolean18 = categoryAxis3.hasListener((java.util.EventListener) categoryPlot12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = null;
        categoryPlot12.notifyListeners(plotChangeEvent19);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot12.getRangeMarkers(4, layer22);
        categoryPlot12.mapDatasetToDomainAxis((int) (short) 100, (int) (byte) 10);
        boolean boolean27 = plotOrientation0.equals((java.lang.Object) categoryPlot12);
        java.awt.Stroke stroke28 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.data.general.Dataset dataset29 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent30 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) stroke28, dataset29);
        org.jfree.data.general.Dataset dataset31 = datasetChangeEvent30.getDataset();
        categoryPlot12.datasetChanged(datasetChangeEvent30);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot12.getDomainMarkers(12, layer34);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertNull(list16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(dataset31);
        org.junit.Assert.assertNull(collection35);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        double double7 = categoryAxis6.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis6.getTickLabelInsets();
        java.awt.Paint paint10 = categoryAxis6.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font11 = categoryAxis6.getLabelFont();
        intervalMarker2.setLabelFont(font11);
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean16 = chartChangeEventType14.equals((java.lang.Object) color15);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) font11, jFreeChart13, chartChangeEventType14);
        org.jfree.chart.JFreeChart jFreeChart18 = chartChangeEvent17.getChart();
        java.lang.Object obj19 = chartChangeEvent17.getSource();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(chartChangeEventType14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(jFreeChart18);
        org.junit.Assert.assertNotNull(obj19);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        categoryPlot0.setDomainGridlinesVisible(true);
        java.awt.Font font10 = categoryPlot0.getNoDataMessageFont();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        categoryPlot0.setRenderer(categoryItemRenderer4, true);
        java.lang.Class<?> wildcardClass7 = categoryPlot0.getClass();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone7);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass12 = color11.getClass();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.Class class15 = null;
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone17);
        java.awt.Color color20 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass21 = color20.getClass();
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.lang.Class class24 = null;
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone26);
        java.lang.Class class29 = null;
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date22, timeZone31);
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color35 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass36 = color35.getClass();
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.lang.Class class39 = null;
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date34, timeZone41);
        java.lang.Class class45 = null;
        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date34, timeZone47);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("13-June-2019", timeZone47);
        dateAxis50.configure();
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis53.setNegativeArrowVisible(false);
        java.awt.Paint paint56 = numberAxis53.getTickMarkPaint();
        org.jfree.data.Range range57 = numberAxis53.getRange();
        dateAxis50.setRange(range57);
        org.jfree.chart.axis.DateTickUnit dateTickUnit59 = dateAxis50.getTickUnit();
        org.jfree.chart.axis.DateTickUnit dateTickUnit60 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis50.setTickUnit(dateTickUnit60);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertNotNull(dateTickUnit59);
        org.junit.Assert.assertNotNull(dateTickUnit60);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        categoryAxis2.addChangeListener(axisChangeListener4);
        categoryAxis2.setLabelAngle((double) 100);
        java.awt.Color color8 = java.awt.Color.WHITE;
        categoryAxis2.setTickMarkPaint((java.awt.Paint) color8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        double double12 = categoryAxis11.getLowerMargin();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis11.setAxisLineStroke(stroke13);
        java.awt.Color color17 = java.awt.Color.getColor("hi!", 0);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color8, stroke13, (java.awt.Paint) color17, stroke18, 0.0f);
        java.lang.String str21 = valueMarker20.getLabel();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(str21);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot0.getIndexOf(categoryItemRenderer12);
        java.awt.Color color14 = java.awt.Color.darkGray;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color14);
        java.util.List list16 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace17, false);
        java.awt.Stroke stroke20 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace17, false);
        org.jfree.data.xy.XYDataset xYDataset20 = xYPlot13.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot21.setDomainCrosshairStroke(stroke24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot21.getRendererForDataset(xYDataset26);
        java.awt.Stroke stroke28 = xYPlot21.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection31 = xYPlot21.getDomainMarkers(4, layer30);
        java.util.Collection collection32 = xYPlot13.getDomainMarkers(layer30);
        java.awt.Stroke stroke33 = null;
        try {
            xYPlot13.setDomainCrosshairStroke(stroke33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(xYDataset20);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNull(collection32);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray5 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer4 };
        categoryPlot3.setRenderers(categoryItemRendererArray5);
        categoryPlot3.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        categoryPlot3.setDataset(categoryDataset9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str12 = categoryAnchor11.toString();
        categoryPlot3.setDomainGridlinePosition(categoryAnchor11);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int15 = color14.getAlpha();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        double double18 = categoryAxis17.getLowerMargin();
        java.awt.Paint paint20 = categoryAxis17.getTickLabelPaint((java.lang.Comparable) 'a');
        java.awt.Color color21 = java.awt.Color.MAGENTA;
        categoryAxis17.setTickMarkPaint((java.awt.Paint) color21);
        float[] floatArray29 = new float[] { 1560409200000L, 2.0f, 2.0f, (short) 10, '#', (byte) 10 };
        float[] floatArray30 = color21.getRGBComponents(floatArray29);
        float[] floatArray31 = color14.getRGBColorComponents(floatArray30);
        boolean boolean32 = categoryAnchor11.equals((java.lang.Object) floatArray31);
        float[] floatArray33 = color0.getColorComponents(colorSpace2, floatArray31);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(categoryItemRendererArray5);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "CategoryAnchor.END" + "'", str12.equals("CategoryAnchor.END"));
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(floatArray33);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        double double11 = categoryAxis10.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis10.getTickLabelInsets();
        java.awt.Paint paint13 = categoryAxis10.getTickLabelPaint();
        categoryAxis10.setLowerMargin((-1.0d));
        java.util.List list16 = categoryPlot0.getCategoriesForAxis(categoryAxis10);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection18 = categoryPlot17.getFixedLegendItems();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        categoryPlot17.drawBackgroundImage(graphics2D19, rectangle2D20);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str23 = categoryAnchor22.toString();
        categoryPlot17.setDomainGridlinePosition(categoryAnchor22);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = null;
        double double29 = categoryAxis10.getCategoryJava2DCoordinate(categoryAnchor22, (-65281), (int) (short) 10, rectangle2D27, rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(categoryAnchor22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "CategoryAnchor.END" + "'", str23.equals("CategoryAnchor.END"));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis3.setNegativeArrowVisible(false);
        numberAxis3.setVerticalTickLabels(false);
        numberAxis3.setAutoRange(false);
        java.awt.Stroke stroke10 = numberAxis3.getTickMarkStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis15.setNegativeArrowVisible(false);
        java.awt.Paint paint18 = numberAxis15.getTickMarkPaint();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint18, stroke19, (java.awt.Paint) color20, stroke21, (float) (byte) 1);
        categoryMarker12.setOutlinePaint((java.awt.Paint) color20);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double28 = numberAxis27.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis30.setNegativeArrowVisible(false);
        java.awt.Shape shape33 = numberAxis30.getDownArrow();
        numberAxis30.setUpperMargin((double) 100.0f);
        double double36 = numberAxis30.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset25, (org.jfree.chart.axis.ValueAxis) numberAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis30, xYItemRenderer37);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str41 = categoryPlot40.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font43 = categoryAxis42.getLabelFont();
        categoryPlot40.setNoDataMessageFont(font43);
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot40.addDomainMarker((int) 'a', categoryMarker47, layer48);
        java.util.Collection collection50 = xYPlot38.getRangeMarkers(3, layer48);
        xYPlot38.clearRangeMarkers();
        java.awt.Stroke stroke52 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot38.setDomainCrosshairStroke(stroke52);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        xYPlot38.setRenderer(xYItemRenderer54);
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis58.setNegativeArrowVisible(false);
        java.awt.Paint paint61 = numberAxis58.getTickMarkPaint();
        java.awt.Stroke stroke62 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color63 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke64 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker66 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint61, stroke62, (java.awt.Paint) color63, stroke64, (float) (byte) 1);
        xYPlot38.setDomainCrosshairPaint(paint61);
        java.awt.Stroke stroke68 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot38.setDomainCrosshairStroke(stroke68);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker71 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color1, stroke10, (java.awt.Paint) color20, stroke68, (float) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertNotNull(font43);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(stroke68);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-4.0d), font3);
        java.lang.String str6 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 255);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Paint paint5 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes((double) 1, (double) 1, plotRenderingInfo8, point2D9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = categoryPlot0.getDomainGridlinePosition();
        java.lang.String str12 = categoryAnchor11.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str12.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis7.setNegativeArrowVisible(false);
        java.awt.Shape shape10 = numberAxis7.getDownArrow();
        boolean boolean11 = numberAxis7.isVerticalTickLabels();
        org.jfree.chart.plot.Plot plot12 = numberAxis7.getPlot();
        int int13 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis16.setNegativeArrowVisible(false);
        java.awt.Shape shape19 = numberAxis16.getDownArrow();
        numberAxis16.setUpperMargin((double) 100.0f);
        double double22 = numberAxis16.getFixedDimension();
        numberAxis16.setTickMarkInsideLength(0.0f);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis16, false);
        java.lang.String str27 = numberAxis16.getLabelToolTip();
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 1560409200000L, (double) 1560452399999L, (double) (byte) -1, (double) 0.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getAutoRangeMinimumSize();
        java.awt.Shape shape3 = numberAxis1.getDownArrow();
        boolean boolean4 = numberAxis1.getAutoRangeStickyZero();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.AxisState axisState6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double11 = numberAxis10.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis13.setNegativeArrowVisible(false);
        java.awt.Shape shape16 = numberAxis13.getDownArrow();
        numberAxis13.setUpperMargin((double) 100.0f);
        double double19 = numberAxis13.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer20);
        xYPlot21.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot21.getRangeAxisEdge(11);
        try {
            java.util.List list26 = numberAxis1.refreshTicks(graphics2D5, axisState6, rectangle2D7, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-8d + "'", double2 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot13.zoomRangeAxes((double) 100.0f, plotRenderingInfo19, point2D20);
        xYPlot13.setRangeCrosshairValue(0.2d, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray26 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer25 };
        xYPlot13.setRenderers(xYItemRendererArray26);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot13.getRangeAxisEdge();
        xYPlot13.mapDatasetToRangeAxis(2019, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(xYItemRendererArray26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot0.getIndexOf(categoryItemRenderer12);
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder17 = xYPlot16.getSeriesRenderingOrder();
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        xYPlot16.setFixedDomainAxisSpace(axisSpace18, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot21.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis23 = categoryPlot21.getRangeAxis();
        java.awt.Stroke stroke24 = categoryPlot21.getRangeGridlineStroke();
        categoryPlot21.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker29 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer30 = null;
        intervalMarker29.setGradientPaintTransformer(gradientPaintTransformer30);
        java.awt.Paint paint32 = intervalMarker29.getLabelPaint();
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean35 = categoryPlot21.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) intervalMarker29, layer33, true);
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = xYPlot36.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot36.setDomainCrosshairStroke(stroke39);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = xYPlot36.getRendererForDataset(xYDataset41);
        java.awt.Stroke stroke43 = xYPlot36.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer45 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection46 = xYPlot36.getDomainMarkers(4, layer45);
        xYPlot16.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker29, layer45);
        try {
            boolean boolean49 = categoryPlot0.removeRangeMarker(8, marker15, layer45, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(seriesRenderingOrder17);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertNull(valueAxis23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(xYItemRenderer42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(layer45);
        org.junit.Assert.assertNull(collection46);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot0.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        categoryPlot0.axisChanged(axisChangeEvent9);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot0.getLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot0.setRenderer(categoryItemRenderer12, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        double double17 = categoryAxis16.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryAxis16.getTickLabelInsets();
        double double20 = rectangleInsets18.trimWidth((double) (-1));
        double double21 = rectangleInsets18.getRight();
        java.lang.String str22 = rectangleInsets18.toString();
        categoryPlot0.setAxisOffset(rectangleInsets18);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType26 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        try {
            java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets18.createAdjustedRectangle(rectangle2D24, lengthAdjustmentType25, lengthAdjustmentType26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-9.0d) + "'", double20 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 4.0d + "'", double21 == 4.0d);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str22.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType25);
        org.junit.Assert.assertNotNull(lengthAdjustmentType26);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getAutoRangeMinimumSize();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier3 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape4 = defaultDrawingSupplier3.getNextShape();
        java.awt.Shape shape5 = defaultDrawingSupplier3.getNextShape();
        numberAxis1.setUpArrow(shape5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-8d + "'", double2 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int int0 = org.jfree.data.time.MonthConstants.JULY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Paint[] paintArray0 = new java.awt.Paint[] {};
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Paint[] paintArray3 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray4 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray5 = null;
        java.awt.Paint[] paintArray6 = null;
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke12 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray13 = new java.awt.Stroke[] { stroke7, stroke8, stroke9, stroke10, stroke11, stroke12 };
        java.awt.Stroke stroke14 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke17 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray19 = new java.awt.Stroke[] { stroke14, stroke15, stroke16, stroke17, stroke18 };
        java.awt.Shape[] shapeArray20 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray4, paintArray5, paintArray6, strokeArray13, strokeArray19, shapeArray20);
        java.awt.Stroke[] strokeArray22 = null;
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        double double26 = categoryAxis25.getLowerMargin();
        java.awt.Stroke stroke27 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis25.setAxisLineStroke(stroke27);
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] { stroke23, stroke27 };
        java.awt.Shape[] shapeArray30 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray3, paintArray5, strokeArray22, strokeArray29, shapeArray30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        double double34 = categoryAxis33.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener35 = null;
        categoryAxis33.addChangeListener(axisChangeListener35);
        categoryAxis33.setLabelAngle((double) 100);
        boolean boolean39 = categoryAxis33.isTickLabelsVisible();
        categoryAxis33.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint43 = categoryAxis33.getTickLabelPaint((java.lang.Comparable) 100);
        java.awt.Stroke stroke44 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis33.setAxisLineStroke(stroke44);
        java.awt.Stroke[] strokeArray46 = new java.awt.Stroke[] { stroke44 };
        java.awt.Stroke[] strokeArray47 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Shape[] shapeArray48 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier49 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray5, strokeArray46, strokeArray47, shapeArray48);
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray3);
        org.junit.Assert.assertNotNull(paintArray4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(strokeArray13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(strokeArray19);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(shapeArray30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.05d + "'", double34 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(strokeArray46);
        org.junit.Assert.assertNotNull(strokeArray47);
        org.junit.Assert.assertNotNull(shapeArray48);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setRangeCrosshairValue(0.0d);
        java.awt.Paint paint9 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation11);
        categoryPlot0.setOrientation(plotOrientation11);
        java.awt.Paint[] paintArray14 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray15 = null;
        java.awt.Paint[] paintArray16 = null;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke20 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke22 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] { stroke17, stroke18, stroke19, stroke20, stroke21, stroke22 };
        java.awt.Stroke stroke24 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke25 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke27 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] { stroke24, stroke25, stroke26, stroke27, stroke28 };
        java.awt.Shape[] shapeArray30 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray14, paintArray15, paintArray16, strokeArray23, strokeArray29, shapeArray30);
        java.awt.Stroke stroke32 = defaultDrawingSupplier31.getNextOutlineStroke();
        categoryPlot0.setRangeGridlineStroke(stroke32);
        java.awt.Paint paint34 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        double double36 = categoryPlot35.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset38 = categoryPlot35.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = categoryPlot35.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.data.Range range42 = categoryPlot35.getDataRange(valueAxis41);
        java.awt.Paint paint43 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot35.setNoDataMessagePaint(paint43);
        java.awt.Color color45 = java.awt.Color.blue;
        categoryPlot35.setNoDataMessagePaint((java.awt.Paint) color45);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        int int48 = categoryPlot35.getIndexOf(categoryItemRenderer47);
        java.awt.Color color49 = java.awt.Color.darkGray;
        categoryPlot35.setNoDataMessagePaint((java.awt.Paint) color49);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        double double53 = categoryAxis52.getLowerMargin();
        java.awt.Color color54 = java.awt.Color.WHITE;
        java.awt.Color color55 = color54.darker();
        categoryAxis52.setTickMarkPaint((java.awt.Paint) color54);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        double double58 = categoryPlot57.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset60 = categoryPlot57.getDataset((int) (byte) 1);
        categoryAxis52.setPlot((org.jfree.chart.plot.Plot) categoryPlot57);
        org.jfree.chart.util.SortOrder sortOrder62 = categoryPlot57.getRowRenderingOrder();
        categoryPlot35.setRowRenderingOrder(sortOrder62);
        categoryPlot0.setRowRenderingOrder(sortOrder62);
        java.lang.String str65 = sortOrder62.toString();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(shapeArray30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset38);
        org.junit.Assert.assertNull(categoryAxis40);
        org.junit.Assert.assertNull(range42);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.05d + "'", double53 == 0.05d);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset60);
        org.junit.Assert.assertNotNull(sortOrder62);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "SortOrder.ASCENDING" + "'", str65.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        boolean boolean4 = numberAxis1.isNegativeArrowVisible();
        org.jfree.data.time.DateRange dateRange5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        numberAxis1.setDefaultAutoRange((org.jfree.data.Range) dateRange5);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(dateRange5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        xYPlot13.mapDatasetToRangeAxis(1, (int) 'a');
        float float18 = xYPlot13.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setRangeCrosshairValue(0.0d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomDomainAxes((double) 10, plotRenderingInfo10, point2D11);
        boolean boolean13 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot0.getInsets();
        org.jfree.chart.util.SortOrder sortOrder15 = categoryPlot0.getColumnRenderingOrder();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(sortOrder15);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        float float5 = intervalMarker2.getAlpha();
        double double6 = intervalMarker2.getStartValue();
        java.lang.Object obj7 = intervalMarker2.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font11 = null;
        categoryAxis9.setTickLabelFont((java.lang.Comparable) (-4.0d), font11);
        boolean boolean13 = categoryAxis9.isTickMarksVisible();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = categoryAxis9.getCategoryEnd((int) (short) 1, 0, rectangle2D16, rectangleEdge17);
        boolean boolean20 = categoryAxis9.equals((java.lang.Object) (byte) 10);
        categoryAxis9.setTickLabelsVisible(false);
        boolean boolean23 = intervalMarker2.equals((java.lang.Object) false);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.8f + "'", float5 == 0.8f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis13.setNegativeArrowVisible(false);
        java.awt.Paint paint16 = numberAxis13.getTickMarkPaint();
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker21 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint16, stroke17, (java.awt.Paint) color18, stroke19, (float) (byte) 1);
        categoryMarker10.setOutlinePaint((java.awt.Paint) color18);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double26 = numberAxis25.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis28.setNegativeArrowVisible(false);
        java.awt.Shape shape31 = numberAxis28.getDownArrow();
        numberAxis28.setUpperMargin((double) 100.0f);
        double double34 = numberAxis28.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset23, (org.jfree.chart.axis.ValueAxis) numberAxis25, (org.jfree.chart.axis.ValueAxis) numberAxis28, xYItemRenderer35);
        boolean boolean37 = xYPlot36.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot36.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace40 = null;
        xYPlot36.setFixedRangeAxisSpace(axisSpace40, false);
        org.jfree.data.xy.XYDataset xYDataset43 = xYPlot36.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = xYPlot44.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot44.setDomainCrosshairStroke(stroke47);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = xYPlot44.getRendererForDataset(xYDataset49);
        java.awt.Stroke stroke51 = xYPlot44.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection54 = xYPlot44.getDomainMarkers(4, layer53);
        java.util.Collection collection55 = xYPlot36.getDomainMarkers(layer53);
        boolean boolean57 = categoryPlot0.removeRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) categoryMarker10, layer53, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNull(xYDataset43);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNull(xYItemRenderer50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertNull(collection54);
        org.junit.Assert.assertNull(collection55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint();
        categoryAxis1.setLowerMargin((-1.0d));
        categoryAxis1.setLowerMargin((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.xy.XYDataset xYDataset4 = null;
//        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
//        double double7 = numberAxis6.getUpperMargin();
//        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
//        numberAxis9.setNegativeArrowVisible(false);
//        java.awt.Shape shape12 = numberAxis9.getDownArrow();
//        numberAxis9.setUpperMargin((double) 100.0f);
//        double double15 = numberAxis9.getFixedDimension();
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
//        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis6, (org.jfree.chart.axis.ValueAxis) numberAxis9, xYItemRenderer16);
//        xYPlot17.setRangeGridlinesVisible(false);
//        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot17.getRangeAxisEdge(11);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
//        java.awt.geom.Point2D point2D24 = null;
//        xYPlot17.zoomRangeAxes((double) 100.0f, plotRenderingInfo23, point2D24);
//        xYPlot17.setRangeCrosshairValue(0.2d, true);
//        boolean boolean29 = day0.equals((java.lang.Object) xYPlot17);
//        try {
//            org.jfree.chart.axis.ValueAxis valueAxis31 = xYPlot17.getRangeAxisForDataset((int) (short) 10);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 10 out of bounds.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
//        org.junit.Assert.assertNotNull(shape12);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
//        org.junit.Assert.assertNotNull(rectangleEdge21);
//        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = day1.previous();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = regularTimePeriod2.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace17, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot13.setRenderer((int) '#', xYItemRenderer21, true);
        xYPlot13.setRangeZeroBaselineVisible(false);
        xYPlot13.setWeight(7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.Class class0 = null;
        java.util.Date date1 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone2 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone2);
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone2);
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertNotNull(tickUnitSource5);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis1.getStandardTickUnits();
        boolean boolean5 = numberAxis1.isAutoRange();
        org.jfree.chart.plot.Plot plot6 = numberAxis1.getPlot();
        org.junit.Assert.assertNotNull(tickUnitSource4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(plot6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        categoryAxis1.setLabel("hi!");
        float float8 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(10.0d, (-9.0d), (double) (byte) 1, 0.2d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        java.awt.Paint paint6 = intervalMarker2.getLabelPaint();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(categoryItemRenderer12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        int int15 = categoryPlot6.getIndexOf(categoryItemRenderer14);
        java.util.List list16 = categoryPlot6.getCategories();
        categoryPlot6.setRangeCrosshairValue((double) (byte) 100, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(list16);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.LegendItemCollection legendItemCollection17 = xYPlot13.getLegendItems();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(legendItemCollection17);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot0.getIndexOf(categoryItemRenderer12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace14);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        double double5 = numberAxis1.getUpperBound();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        boolean boolean10 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot6.zoomRangeAxes((double) ' ', (double) (byte) 10, plotRenderingInfo13, point2D14);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot6.getRangeAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        double double18 = categoryPlot17.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset20 = categoryPlot17.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot17.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.data.Range range24 = categoryPlot17.getDataRange(valueAxis23);
        java.awt.Paint paint25 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot17.setNoDataMessagePaint(paint25);
        java.awt.Color color27 = java.awt.Color.blue;
        categoryPlot17.setNoDataMessagePaint((java.awt.Paint) color27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        int int30 = categoryPlot17.getIndexOf(categoryItemRenderer29);
        java.awt.Color color31 = java.awt.Color.darkGray;
        categoryPlot17.setNoDataMessagePaint((java.awt.Paint) color31);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        double double35 = categoryAxis34.getLowerMargin();
        java.awt.Color color36 = java.awt.Color.WHITE;
        java.awt.Color color37 = color36.darker();
        categoryAxis34.setTickMarkPaint((java.awt.Paint) color36);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        double double40 = categoryPlot39.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset42 = categoryPlot39.getDataset((int) (byte) 1);
        categoryAxis34.setPlot((org.jfree.chart.plot.Plot) categoryPlot39);
        org.jfree.chart.util.SortOrder sortOrder44 = categoryPlot39.getRowRenderingOrder();
        categoryPlot17.setRowRenderingOrder(sortOrder44);
        categoryPlot6.setRowRenderingOrder(sortOrder44);
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        categoryPlot6.setDataset(categoryDataset47);
        numberAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset20);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNull(range24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset42);
        org.junit.Assert.assertNotNull(sortOrder44);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        categoryAxis1.setLabelAngle((double) 100);
        boolean boolean7 = categoryAxis1.isTickLabelsVisible();
        categoryAxis1.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint11 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 100);
        double double12 = categoryAxis1.getUpperMargin();
        double double13 = categoryAxis1.getLowerMargin();
        categoryAxis1.setAxisLineVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape17 = defaultDrawingSupplier16.getNextShape();
        boolean boolean18 = categoryAxis1.equals((java.lang.Object) defaultDrawingSupplier16);
        java.awt.Stroke stroke19 = defaultDrawingSupplier16.getNextOutlineStroke();
        java.awt.Paint paint20 = defaultDrawingSupplier16.getNextOutlinePaint();
        java.awt.Stroke stroke21 = defaultDrawingSupplier16.getNextOutlineStroke();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Paint paint5 = categoryPlot0.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace6, false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = categoryPlot0.getDomainGridlinePosition();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(categoryAnchor9);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot0.getRendererForDataset(xYDataset5);
        java.awt.Stroke stroke7 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection10 = xYPlot0.getDomainMarkers(4, layer9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot0.getRenderer();
        int int12 = xYPlot0.getDomainAxisCount();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot13.getRangeAxisEdge();
        java.awt.Stroke stroke27 = xYPlot13.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-4.0d), font3);
        boolean boolean5 = categoryAxis1.isTickMarksVisible();
        categoryAxis1.setTickMarkInsideLength((float) 6);
        categoryAxis1.setCategoryLabelPositionOffset(10);
        double double10 = categoryAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.Plot plot2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (short) 100);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace8 = categoryAxis0.reserveSpace(graphics2D1, plot2, rectangle2D3, rectangleEdge6, axisSpace7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        double double9 = categoryAxis8.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis8.getTickLabelInsets();
        double double12 = rectangleInsets10.calculateLeftOutset(0.0d);
        categoryPlot0.setAxisOffset(rectangleInsets10);
        double double15 = rectangleInsets10.calculateBottomOutset((double) 15);
        org.jfree.chart.util.UnitType unitType16 = rectangleInsets10.getUnitType();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
        org.junit.Assert.assertNotNull(unitType16);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation15, plotOrientation16);
        xYPlot13.setDomainAxisLocation(11, axisLocation15);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        double double21 = categoryAxis20.getLowerMargin();
        java.awt.Color color22 = java.awt.Color.WHITE;
        java.awt.Color color23 = color22.darker();
        categoryAxis20.setTickMarkPaint((java.awt.Paint) color22);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        double double26 = categoryPlot25.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot25.getDataset((int) (byte) 1);
        categoryAxis20.setPlot((org.jfree.chart.plot.Plot) categoryPlot25);
        org.jfree.chart.util.SortOrder sortOrder30 = categoryPlot25.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot25.getRangeAxisLocation();
        xYPlot13.setRangeAxisLocation(axisLocation31, true);
        org.jfree.chart.axis.ValueAxis valueAxis34 = xYPlot13.getDomainAxis();
        boolean boolean35 = xYPlot13.isDomainZoomable();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        double double37 = categoryPlot36.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset39 = categoryPlot36.getDataset((int) (byte) 1);
        boolean boolean40 = categoryPlot36.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis42 = categoryPlot36.getRangeAxis(255);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        double double45 = categoryAxis44.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = categoryAxis44.getTickLabelInsets();
        double double48 = rectangleInsets46.calculateLeftOutset(0.0d);
        categoryPlot36.setAxisOffset(rectangleInsets46);
        double double51 = rectangleInsets46.calculateRightOutset(0.0d);
        xYPlot13.setInsets(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.05d + "'", double21 == 0.05d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertNotNull(sortOrder30);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(valueAxis34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(valueAxis42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.05d + "'", double45 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 4.0d + "'", double48 == 4.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 4.0d + "'", double51 == 4.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        java.awt.Color color1 = java.awt.Color.GREEN;
        java.awt.Color color2 = java.awt.Color.getColor("UnitType.RELATIVE", color1);
        java.awt.Color color3 = color2.darker();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot6.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.data.Range range13 = categoryPlot6.getDataRange(valueAxis12);
        java.awt.Paint paint14 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot6.setNoDataMessagePaint(paint14);
        java.awt.Color color16 = java.awt.Color.blue;
        categoryPlot6.setNoDataMessagePaint((java.awt.Paint) color16);
        java.lang.String str18 = color16.toString();
        float[] floatArray19 = null;
        float[] floatArray20 = color16.getComponents(floatArray19);
        float[] floatArray21 = color3.getComponents(colorSpace5, floatArray19);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertNull(range13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=0,g=0,b=255]" + "'", str18.equals("java.awt.Color[r=0,g=0,b=255]"));
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis1.setAxisLineStroke(stroke3);
        double double5 = categoryAxis1.getLabelAngle();
        categoryAxis1.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        xYPlot13.clearAnnotations();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = xYPlot13.getOrientation();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(plotOrientation19);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray1 = null;
        java.awt.Paint[] paintArray2 = null;
        java.awt.Stroke stroke3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray9 = new java.awt.Stroke[] { stroke3, stroke4, stroke5, stroke6, stroke7, stroke8 };
        java.awt.Stroke stroke10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke11 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray15 = new java.awt.Stroke[] { stroke10, stroke11, stroke12, stroke13, stroke14 };
        java.awt.Shape[] shapeArray16 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray2, strokeArray9, strokeArray15, shapeArray16);
        java.awt.Stroke stroke18 = defaultDrawingSupplier17.getNextOutlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        boolean boolean21 = defaultDrawingSupplier17.equals((java.lang.Object) categoryAxis20);
        java.lang.Object obj22 = defaultDrawingSupplier17.clone();
        org.junit.Assert.assertNotNull(paintArray0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(strokeArray9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(strokeArray15);
        org.junit.Assert.assertNotNull(shapeArray16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-4.0d), font3);
        boolean boolean5 = categoryAxis1.isTickMarksVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis1.getLabelInsets();
        categoryAxis1.setLowerMargin((double) (short) 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis1.getTickLabelInsets();
        double double11 = rectangleInsets9.calculateTopInset((double) (-65281));
        double double13 = rectangleInsets9.calculateLeftOutset(4.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.lang.Object obj7 = null;
        boolean boolean8 = textAnchor6.equals(obj7);
        intervalMarker2.setLabelTextAnchor(textAnchor6);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        numberAxis5.setLabel("SortOrder.ASCENDING");
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getAutoRangeMinimumSize();
        java.awt.Shape shape3 = numberAxis1.getDownArrow();
        boolean boolean4 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis7.setNegativeArrowVisible(false);
        java.awt.Paint paint10 = numberAxis7.getTickMarkPaint();
        java.awt.Stroke stroke11 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint10, stroke11, (java.awt.Paint) color12, stroke13, (float) (byte) 1);
        numberAxis1.setTickLabelPaint((java.awt.Paint) color12);
        int int17 = color12.getRed();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-8d + "'", double2 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 192 + "'", int17 == 192);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        java.awt.Color color1 = java.awt.Color.PINK;
        java.awt.Stroke stroke2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "ChartChangeEventType.GENERAL", (java.awt.Paint) color1, stroke2);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis();
        xYPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = xYPlot0.getAxisOffset();
        double double9 = rectangleInsets7.calculateBottomOutset((double) 0.8f);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(categoryItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot6.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        java.awt.Color color7 = java.awt.Color.WHITE;
        java.awt.Color color8 = color7.darker();
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        int int10 = color8.getTransparency();
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color8);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.configure();
        categoryAxis1.setLabel("ChartChangeEventType.NEW_DATASET");
        categoryAxis1.configure();
        java.awt.Paint paint17 = categoryAxis1.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace17, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot13.setRenderer((int) '#', xYItemRenderer21, true);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot26.getRangeAxisEdge((int) (short) 100);
        xYPlot26.clearDomainMarkers();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        double double33 = categoryPlot32.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset35 = categoryPlot32.getDataset((int) (byte) 1);
        boolean boolean36 = categoryPlot32.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis38 = categoryPlot32.getRangeAxis(255);
        categoryPlot32.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        double double43 = categoryAxis42.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = categoryAxis42.getTickLabelInsets();
        java.awt.Paint paint45 = categoryAxis42.getTickLabelPaint();
        categoryAxis42.setLowerMargin((-1.0d));
        java.util.List list48 = categoryPlot32.getCategoriesForAxis(categoryAxis42);
        xYPlot26.drawRangeTickBands(graphics2D30, rectangle2D31, list48);
        xYPlot13.drawRangeTickBands(graphics2D24, rectangle2D25, list48);
        int int51 = xYPlot13.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis18.setNegativeArrowVisible(false);
        categoryPlot10.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis18);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        numberAxis18.setTickLabelPaint((java.awt.Paint) color22);
        boolean boolean24 = numberAxis18.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        categoryAxis1.setLabelAngle((double) 100);
        boolean boolean7 = categoryAxis1.isTickLabelsVisible();
        categoryAxis1.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint11 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 100);
        double double12 = categoryAxis1.getUpperMargin();
        double double13 = categoryAxis1.getLowerMargin();
        categoryAxis1.setAxisLineVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape17 = defaultDrawingSupplier16.getNextShape();
        boolean boolean18 = categoryAxis1.equals((java.lang.Object) defaultDrawingSupplier16);
        java.awt.Stroke stroke19 = defaultDrawingSupplier16.getNextOutlineStroke();
        java.lang.Object obj20 = defaultDrawingSupplier16.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 1560452399999L);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot0.getRangeAxisLocation((int) '4');
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis13.setNegativeArrowVisible(false);
        java.awt.Shape shape16 = numberAxis13.getDownArrow();
        double double17 = numberAxis13.getUpperBound();
        numberAxis13.resizeRange((double) (byte) 100, (double) (-16777216));
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { numberAxis13 };
        categoryPlot0.setRangeAxes(valueAxisArray21);
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(valueAxisArray21);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis7.setNegativeArrowVisible(false);
        java.awt.Shape shape10 = numberAxis7.getDownArrow();
        boolean boolean11 = numberAxis7.isVerticalTickLabels();
        org.jfree.chart.plot.Plot plot12 = numberAxis7.getPlot();
        int int13 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        xYPlot0.setDomainAxis(valueAxis14);
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot0.zoomRangeAxes((double) ' ', (double) (byte) 10, plotRenderingInfo7, point2D8);
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke11 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) plotOrientation0, dataset1);
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker4 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        xYPlot0.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker4);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis7.setNegativeArrowVisible(false);
        java.awt.Shape shape10 = numberAxis7.getDownArrow();
        boolean boolean11 = numberAxis7.isVerticalTickLabels();
        org.jfree.chart.plot.Plot plot12 = numberAxis7.getPlot();
        int int13 = xYPlot0.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis7);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis16.setNegativeArrowVisible(false);
        java.awt.Shape shape19 = numberAxis16.getDownArrow();
        numberAxis16.setUpperMargin((double) 100.0f);
        double double22 = numberAxis16.getFixedDimension();
        numberAxis16.setTickMarkInsideLength(0.0f);
        xYPlot0.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis16, false);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis28.setNegativeArrowVisible(false);
        org.jfree.data.Range range31 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis28.setRange(range31, true, false);
        numberAxis16.setRangeWithMargins(range31, false, true);
        numberAxis16.setLabelToolTip("AxisLocation.TOP_OR_LEFT");
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1) + "'", int13 == (-1));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(range31);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.centerRange(1.0d);
        numberAxis1.setTickLabelsVisible(true);
        double double6 = numberAxis1.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0E-8d + "'", double6 == 1.0E-8d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot13.getRangeAxisEdge();
        xYPlot13.setRangeZeroBaselineVisible(true);
        float float29 = xYPlot13.getBackgroundImageAlpha();
        boolean boolean30 = xYPlot13.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 0.5f + "'", float29 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis();
        xYPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            xYPlot0.handleClick(0, (int) (byte) 0, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = numberAxis5.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis13.setNegativeArrowVisible(false);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis13.setRange(range16, true, false);
        numberAxis5.setRangeWithMargins(range16, false, true);
        xYPlot0.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        xYPlot0.setDomainCrosshairValue((double) 0, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double33 = numberAxis32.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis35.setNegativeArrowVisible(false);
        java.awt.Shape shape38 = numberAxis35.getDownArrow();
        numberAxis35.setUpperMargin((double) 100.0f);
        double double41 = numberAxis35.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset30, (org.jfree.chart.axis.ValueAxis) numberAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis35, xYItemRenderer42);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str46 = categoryPlot45.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font48 = categoryAxis47.getLabelFont();
        categoryPlot45.setNoDataMessageFont(font48);
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer53 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot45.addDomainMarker((int) 'a', categoryMarker52, layer53);
        java.util.Collection collection55 = xYPlot43.getRangeMarkers(3, layer53);
        xYPlot43.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder60 = xYPlot59.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray62 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer61 };
        xYPlot59.setRenderers(xYItemRendererArray62);
        org.jfree.data.xy.XYDataset xYDataset64 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer65 = xYPlot59.getRendererForDataset(xYDataset64);
        java.awt.geom.Point2D point2D66 = xYPlot59.getQuadrantOrigin();
        xYPlot43.zoomRangeAxes((double) 100L, plotRenderingInfo58, point2D66);
        xYPlot0.zoomRangeAxes(0.2d, plotRenderingInfo29, point2D66);
        int int69 = xYPlot0.getDatasetCount();
        java.awt.Stroke stroke70 = xYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(markerAxisBand11);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.05d + "'", double33 == 0.05d);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str46);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(layer53);
        org.junit.Assert.assertNull(collection55);
        org.junit.Assert.assertNotNull(seriesRenderingOrder60);
        org.junit.Assert.assertNotNull(xYItemRendererArray62);
        org.junit.Assert.assertNull(xYItemRenderer65);
        org.junit.Assert.assertNotNull(point2D66);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 1 + "'", int69 == 1);
        org.junit.Assert.assertNotNull(stroke70);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("UnitType.RELATIVE");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray3 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer2 };
        xYPlot0.setRenderers(xYItemRendererArray3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot0.getRendererForDataset(xYDataset5);
        java.awt.geom.Point2D point2D7 = xYPlot0.getQuadrantOrigin();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double11 = numberAxis10.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis13.setNegativeArrowVisible(false);
        java.awt.Shape shape16 = numberAxis13.getDownArrow();
        numberAxis13.setUpperMargin((double) 100.0f);
        double double19 = numberAxis13.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer20);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str24 = categoryPlot23.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font26 = categoryAxis25.getLabelFont();
        categoryPlot23.setNoDataMessageFont(font26);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot23.addDomainMarker((int) 'a', categoryMarker30, layer31);
        java.util.Collection collection33 = xYPlot21.getRangeMarkers(3, layer31);
        java.util.Collection collection34 = xYPlot0.getDomainMarkers(layer31);
        xYPlot0.setRangeCrosshairVisible(false);
        java.awt.Paint paint37 = xYPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNotNull(xYItemRendererArray3);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getAutoRangeMinimumSize();
        double double3 = numberAxis1.getUpperBound();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = numberAxis1.getTickLabelInsets();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-8d + "'", double2 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.geom.Point2D point2D15 = xYPlot13.getQuadrantOrigin();
        java.util.List list16 = xYPlot13.getAnnotations();
        int int17 = xYPlot13.getSeriesCount();
        xYPlot13.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot13.getRangeAxisEdge(6);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(point2D15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.awt.Color color1 = java.awt.Color.getColor("TextAnchor.BASELINE_RIGHT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis2.setTickUnit(numberTickUnit14, true, true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit14);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot0.getRendererForDataset(xYDataset5);
        java.awt.Stroke stroke7 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection10 = xYPlot0.getDomainMarkers(4, layer9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double14 = numberAxis13.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis16.setNegativeArrowVisible(false);
        java.awt.Shape shape19 = numberAxis16.getDownArrow();
        numberAxis16.setUpperMargin((double) 100.0f);
        double double22 = numberAxis16.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer23);
        xYPlot24.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot24.getRangeAxisEdge(11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        xYPlot24.zoomRangeAxes((double) 100.0f, plotRenderingInfo30, point2D31);
        xYPlot24.setRangeCrosshairValue(0.2d, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray37 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer36 };
        xYPlot24.setRenderers(xYItemRendererArray37);
        xYPlot0.setRenderers(xYItemRendererArray37);
        java.lang.String str40 = xYPlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(xYItemRendererArray37);
        org.junit.Assert.assertNull(str40);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        java.util.List list4 = categoryPlot0.getCategories();
        categoryPlot0.setOutlineVisible(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot0.setRenderer((int) (byte) 1, categoryItemRenderer8);
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryPlot0.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint12 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.util.Layer layer13 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection14 = categoryPlot0.getDomainMarkers(layer13);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(list4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(layer13);
        org.junit.Assert.assertNull(collection14);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        java.util.List list4 = categoryPlot2.getCategories();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        double double8 = categoryAxis7.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis7.getTickLabelInsets();
        double double10 = categoryAxis7.getCategoryMargin();
        categoryPlot2.setDomainAxis(100, categoryAxis7);
        org.junit.Assert.assertNull(list4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.2d + "'", double10 == 0.2d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        double double4 = numberAxis2.getLowerBound();
        boolean boolean5 = categoryAnchor0.equals((java.lang.Object) numberAxis2);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis2.setNumberFormatOverride(numberFormat6);
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis18.setNegativeArrowVisible(false);
        categoryPlot10.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis18);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot10.getDomainAxisLocation();
        boolean boolean23 = categoryPlot10.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        java.awt.Color color7 = java.awt.Color.WHITE;
        java.awt.Color color8 = color7.darker();
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        int int10 = color8.getTransparency();
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color8);
        boolean boolean12 = categoryAxis1.isVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVerticalTickLabels(false);
        double double6 = numberAxis1.getLabelAngle();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis8.setNegativeArrowVisible(false);
        org.jfree.data.Range range11 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis8.setRange(range11, true, false);
        numberAxis1.setRange(range11, false, true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.lang.Class class4 = null;
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date2, timeZone6);
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date2);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNull(regularTimePeriod8);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getAutoRangeMinimumSize();
        java.awt.Shape shape3 = numberAxis1.getDownArrow();
        boolean boolean4 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis1.setStandardTickUnits(tickUnitSource5);
        numberAxis1.setAutoRange(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-8d + "'", double2 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(tickUnitSource5);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setAutoRange(false);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int9 = color8.getAlpha();
        numberAxis1.setLabelPaint((java.awt.Paint) color8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot11.getFixedLegendItems();
        java.awt.Image image13 = null;
        categoryPlot11.setBackgroundImage(image13);
        categoryPlot11.clearAnnotations();
        boolean boolean16 = numberAxis1.equals((java.lang.Object) categoryPlot11);
        numberAxis1.setPositiveArrowVisible(false);
        boolean boolean19 = numberAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(categoryItemRenderer12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        int int15 = categoryPlot6.getIndexOf(categoryItemRenderer14);
        java.util.List list16 = categoryPlot6.getCategories();
        categoryPlot6.clearAnnotations();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNull(list16);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.plot.Plot plot18 = xYPlot13.getParent();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNull(plot18);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot0.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str10 = categoryPlot9.getNoDataMessage();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        int int12 = categoryPlot9.getIndexOf(categoryItemRenderer11);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        categoryPlot9.datasetChanged(datasetChangeEvent13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot9.zoomRangeAxes(0.0d, plotRenderingInfo16, point2D17, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        boolean boolean22 = categoryPlot9.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker21);
        categoryPlot0.addDomainMarker(categoryMarker21);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray26 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer25 };
        categoryPlot24.setRenderers(categoryItemRendererArray26);
        categoryPlot24.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot24.zoomRangeAxes((double) (-1.0f), plotRenderingInfo31, point2D32);
        org.jfree.chart.plot.XYPlot xYPlot34 = new org.jfree.chart.plot.XYPlot();
        java.awt.Stroke stroke35 = xYPlot34.getRangeZeroBaselineStroke();
        org.jfree.data.general.Dataset dataset36 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent37 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) xYPlot34, dataset36);
        categoryPlot24.datasetChanged(datasetChangeEvent37);
        categoryPlot0.datasetChanged(datasetChangeEvent37);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        categoryPlot0.setRenderer(categoryItemRenderer40);
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererArray26);
        org.junit.Assert.assertNotNull(stroke35);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setCategoryMargin(0.05d);
        categoryAxis1.setTickMarkOutsideLength((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        double double14 = categoryAxis13.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryAxis13.getTickLabelInsets();
        double double17 = rectangleInsets15.trimWidth((double) (-1));
        double double18 = rectangleInsets15.getRight();
        categoryAxis1.setLabelInsets(rectangleInsets15);
        java.lang.String str20 = rectangleInsets15.toString();
        double double22 = rectangleInsets15.calculateBottomInset(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-9.0d) + "'", double17 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str20.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone7);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass12 = color11.getClass();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.Class class15 = null;
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone17);
        java.awt.Color color20 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass21 = color20.getClass();
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.lang.Class class24 = null;
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone26);
        java.lang.Class class29 = null;
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date22, timeZone31);
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color35 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass36 = color35.getClass();
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.lang.Class class39 = null;
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date34, timeZone41);
        java.lang.Class class45 = null;
        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date34, timeZone47);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("13-June-2019", timeZone47);
        dateAxis50.configure();
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis53.setNegativeArrowVisible(false);
        java.awt.Paint paint56 = numberAxis53.getTickMarkPaint();
        org.jfree.data.Range range57 = numberAxis53.getRange();
        dateAxis50.setRange(range57);
        dateAxis50.setRange((double) (short) -1, (double) 3);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(range57);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge((int) (short) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        double double9 = categoryPlot8.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset11 = categoryPlot8.getDataset((int) (byte) 1);
        boolean boolean12 = categoryPlot8.isRangeCrosshairVisible();
        categoryPlot8.mapDatasetToRangeAxis(11, 3);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        double double18 = categoryAxis17.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryAxis17.getTickLabelInsets();
        java.awt.Paint paint21 = categoryAxis17.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font22 = categoryAxis17.getLabelFont();
        java.awt.Color color23 = java.awt.Color.WHITE;
        java.awt.Color color24 = color23.darker();
        java.awt.color.ColorSpace colorSpace25 = color24.getColorSpace();
        int int26 = color24.getTransparency();
        categoryAxis17.setAxisLinePaint((java.awt.Paint) color24);
        double double28 = categoryAxis17.getLowerMargin();
        categoryAxis17.setAxisLineVisible(false);
        java.awt.Font font31 = categoryAxis17.getTickLabelFont();
        java.lang.Object obj32 = categoryAxis17.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        float float35 = categoryAxis34.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray36 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis17, categoryAxis34 };
        categoryPlot8.setDomainAxes(categoryAxisArray36);
        categoryPlot0.setDomainAxes(categoryAxisArray36);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 0.0f + "'", float35 == 0.0f);
        org.junit.Assert.assertNotNull(categoryAxisArray36);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot0.getRendererForDataset(xYDataset5);
        java.awt.Stroke stroke7 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection10 = xYPlot0.getDomainMarkers(4, layer9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double14 = numberAxis13.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis16.setNegativeArrowVisible(false);
        java.awt.Shape shape19 = numberAxis16.getDownArrow();
        numberAxis16.setUpperMargin((double) 100.0f);
        double double22 = numberAxis16.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer23);
        xYPlot24.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot24.getRangeAxisEdge(11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        xYPlot24.zoomRangeAxes((double) 100.0f, plotRenderingInfo30, point2D31);
        xYPlot24.setRangeCrosshairValue(0.2d, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray37 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer36 };
        xYPlot24.setRenderers(xYItemRendererArray37);
        xYPlot0.setRenderers(xYItemRendererArray37);
        java.awt.Stroke stroke40 = xYPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNotNull(xYItemRendererArray37);
        org.junit.Assert.assertNotNull(stroke40);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.Stroke stroke15 = xYPlot13.getRangeGridlineStroke();
        java.awt.Paint paint16 = xYPlot13.getRangeCrosshairPaint();
        org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot13.getDomainAxis();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(valueAxis17);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        boolean boolean4 = categoryPlot0.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double8 = numberAxis7.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis10.setNegativeArrowVisible(false);
        java.awt.Shape shape13 = numberAxis10.getDownArrow();
        numberAxis10.setUpperMargin((double) 100.0f);
        double double16 = numberAxis10.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset5, (org.jfree.chart.axis.ValueAxis) numberAxis7, (org.jfree.chart.axis.ValueAxis) numberAxis10, xYItemRenderer17);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str21 = categoryPlot20.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font23 = categoryAxis22.getLabelFont();
        categoryPlot20.setNoDataMessageFont(font23);
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer28 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot20.addDomainMarker((int) 'a', categoryMarker27, layer28);
        java.util.Collection collection30 = xYPlot18.getRangeMarkers(3, layer28);
        java.util.Collection collection31 = categoryPlot0.getRangeMarkers(layer28);
        categoryPlot0.setRangeGridlinesVisible(false);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        boolean boolean38 = categoryPlot0.render(graphics2D34, rectangle2D35, (int) (short) 100, plotRenderingInfo37);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(layer28);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(7, (-65281), (-65281));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test170() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test170");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        long long2 = day1.getFirstMillisecond();
//        long long3 = day1.getFirstMillisecond();
//        int int4 = day1.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1560409200000L + "'", long3 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        double double3 = intervalMarker2.getStartValue();
        java.awt.Paint paint4 = intervalMarker2.getPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        categoryAxis2.addChangeListener(axisChangeListener4);
        categoryAxis2.setLabelAngle((double) 100);
        java.awt.Color color8 = java.awt.Color.WHITE;
        categoryAxis2.setTickMarkPaint((java.awt.Paint) color8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        double double12 = categoryAxis11.getLowerMargin();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis11.setAxisLineStroke(stroke13);
        java.awt.Color color17 = java.awt.Color.getColor("hi!", 0);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color8, stroke13, (java.awt.Paint) color17, stroke18, 0.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        double double23 = categoryAxis22.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis22.getTickLabelInsets();
        double double26 = rectangleInsets24.calculateTopInset((double) 100);
        double double28 = rectangleInsets24.calculateLeftOutset((double) 100.0f);
        valueMarker20.setLabelOffset(rectangleInsets24);
        double double31 = rectangleInsets24.calculateTopInset((double) (-16777216));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 4.0d + "'", double28 == 4.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = categoryPlot10.getRendererForDataset(categoryDataset17);
        int int19 = categoryPlot10.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(categoryItemRenderer18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.Paint paint15 = xYPlot13.getDomainGridlinePaint();
        xYPlot13.clearRangeMarkers(255);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Color color22 = java.awt.Color.BLACK;
        categoryAxis21.setTickLabelPaint((java.awt.Paint) color22);
        int int24 = color22.getAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        double double26 = categoryPlot25.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot25.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot25.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.data.Range range32 = categoryPlot25.getDataRange(valueAxis31);
        java.awt.Paint paint33 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot25.setNoDataMessagePaint(paint33);
        java.awt.Color color35 = java.awt.Color.blue;
        categoryPlot25.setNoDataMessagePaint((java.awt.Paint) color35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        int int38 = categoryPlot25.getIndexOf(categoryItemRenderer37);
        java.awt.Color color39 = java.awt.Color.darkGray;
        categoryPlot25.setNoDataMessagePaint((java.awt.Paint) color39);
        java.util.List list41 = categoryPlot25.getAnnotations();
        boolean boolean42 = color22.equals((java.lang.Object) list41);
        xYPlot13.drawRangeTickBands(graphics2D18, rectangle2D19, list41);
        int int44 = xYPlot13.getDomainAxisCount();
        boolean boolean45 = xYPlot13.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis1.setRange(range4, true, false);
        numberAxis1.resizeRange((-9.0d), (double) 'a');
        java.lang.Object obj11 = null;
        boolean boolean12 = numberAxis1.equals(obj11);
        numberAxis1.setTickMarkInsideLength((float) 8);
        org.jfree.chart.axis.TickUnitSource tickUnitSource15 = numberAxis1.getStandardTickUnits();
        numberAxis1.setTickMarkOutsideLength((float) 4);
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(tickUnitSource15);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = axisLocation0.getOpposite();
        java.lang.String str4 = axisLocation0.toString();
        java.lang.String str5 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str4.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str5.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font1 = categoryAxis0.getLabelFont();
        float float2 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone7);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass12 = color11.getClass();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.Class class15 = null;
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone17);
        java.awt.Color color20 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass21 = color20.getClass();
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.lang.Class class24 = null;
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone26);
        java.lang.Class class29 = null;
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date22, timeZone31);
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color35 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass36 = color35.getClass();
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.lang.Class class39 = null;
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date34, timeZone41);
        java.lang.Class class45 = null;
        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date34, timeZone47);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("13-June-2019", timeZone47);
        dateAxis50.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray54 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer53 };
        categoryPlot52.setRenderers(categoryItemRendererArray54);
        categoryPlot52.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        categoryPlot52.setDataset(categoryDataset58);
        java.awt.Paint paint60 = categoryPlot52.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset61 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = categoryPlot52.getRendererForDataset(categoryDataset61);
        int int63 = categoryPlot52.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis("");
        double double66 = categoryAxis65.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener67 = null;
        categoryAxis65.addChangeListener(axisChangeListener67);
        categoryAxis65.setLabelAngle((double) 100);
        boolean boolean71 = categoryAxis65.isTickLabelsVisible();
        categoryAxis65.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint75 = categoryAxis65.getTickLabelPaint((java.lang.Comparable) 100);
        double double76 = categoryAxis65.getUpperMargin();
        double double77 = categoryAxis65.getLowerMargin();
        int int78 = categoryPlot52.getDomainAxisIndex(categoryAxis65);
        boolean boolean79 = dateAxis50.equals((java.lang.Object) categoryAxis65);
        org.jfree.chart.axis.DateTickUnit dateTickUnit80 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis50.setTickUnit(dateTickUnit80, false, false);
        try {
            dateAxis50.setRange((double) 255, (-16.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(categoryItemRendererArray54);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNull(categoryItemRenderer62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.05d + "'", double66 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.05d + "'", double76 == 0.05d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.05d + "'", double77 == 0.05d);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(dateTickUnit80);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis18.setNegativeArrowVisible(false);
        categoryPlot10.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis18);
        java.lang.String str22 = numberAxis18.getLabelURL();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis24.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource27 = numberAxis24.getStandardTickUnits();
        numberAxis18.setStandardTickUnits(tickUnitSource27);
        java.awt.Paint paint29 = numberAxis18.getLabelPaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertNotNull(tickUnitSource27);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        intervalMarker10.setGradientPaintTransformer(gradientPaintTransformer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        double double15 = categoryAxis14.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis14.getTickLabelInsets();
        java.awt.Paint paint18 = categoryAxis14.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font19 = categoryAxis14.getLabelFont();
        intervalMarker10.setLabelFont(font19);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        double double24 = categoryAxis23.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryAxis23.getTickLabelInsets();
        java.awt.Paint paint27 = categoryAxis23.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font28 = categoryAxis23.getLabelFont();
        double double29 = categoryAxis23.getLowerMargin();
        categoryAxis23.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection33 = categoryPlot32.getFixedLegendItems();
        java.awt.Image image34 = null;
        categoryPlot32.setBackgroundImage(image34);
        java.util.List list36 = categoryPlot32.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot32.getDomainAxisEdge();
        boolean boolean38 = categoryAxis23.hasListener((java.util.EventListener) categoryPlot32);
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis40.setNegativeArrowVisible(false);
        categoryPlot32.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis40);
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        numberAxis40.setTickLabelPaint((java.awt.Paint) color44);
        boolean boolean46 = numberAxis40.isNegativeArrowVisible();
        boolean boolean47 = intervalMarker10.equals((java.lang.Object) numberAxis40);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis49.setNegativeArrowVisible(false);
        org.jfree.data.Range range52 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis49.setRange(range52, true, false);
        numberAxis40.setRangeWithMargins(range52, false, true);
        numberAxis40.configure();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.05d + "'", double29 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection33);
        org.junit.Assert.assertNull(list36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(range52);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot0.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        categoryPlot0.axisChanged(axisChangeEvent9);
        org.jfree.chart.plot.CategoryMarker categoryMarker12 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis15.setNegativeArrowVisible(false);
        java.awt.Paint paint18 = numberAxis15.getTickMarkPaint();
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker23 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint18, stroke19, (java.awt.Paint) color20, stroke21, (float) (byte) 1);
        categoryMarker12.setOutlinePaint((java.awt.Paint) color20);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color20);
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis();
        xYPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection8 = categoryPlot7.getFixedLegendItems();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        categoryPlot7.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Stroke stroke12 = categoryPlot7.getRangeGridlineStroke();
        xYPlot0.setDomainGridlineStroke(stroke12);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder6);
        org.junit.Assert.assertNull(legendItemCollection8);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        categoryAxis2.addChangeListener(axisChangeListener4);
        categoryAxis2.setLabelAngle((double) 100);
        boolean boolean8 = categoryAxis2.isTickLabelsVisible();
        categoryAxis2.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint12 = categoryAxis2.getTickLabelPaint((java.lang.Comparable) 100);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis2.setAxisLineStroke(stroke13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = xYPlot15.getSeriesRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        xYPlot15.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis22.setNegativeArrowVisible(false);
        java.awt.Shape shape25 = numberAxis22.getDownArrow();
        boolean boolean26 = numberAxis22.isVerticalTickLabels();
        org.jfree.chart.plot.Plot plot27 = numberAxis22.getPlot();
        int int28 = xYPlot15.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer29);
        int int31 = categoryPlot30.getDatasetCount();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace17, false);
        org.jfree.data.xy.XYDataset xYDataset20 = xYPlot13.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = xYPlot21.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke24 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot21.setDomainCrosshairStroke(stroke24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot21.getRendererForDataset(xYDataset26);
        java.awt.Stroke stroke28 = xYPlot21.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection31 = xYPlot21.getDomainMarkers(4, layer30);
        java.util.Collection collection32 = xYPlot13.getDomainMarkers(layer30);
        java.awt.Image image33 = null;
        xYPlot13.setBackgroundImage(image33);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(xYDataset20);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNull(collection32);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = categoryPlot0.getLegendItems();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) legendItemCollection5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(legendItemCollection5);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        java.util.List list4 = categoryPlot0.getCategories();
        categoryPlot0.setOutlineVisible(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = null;
        intervalMarker9.setGradientPaintTransformer(gradientPaintTransformer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        double double14 = categoryAxis13.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryAxis13.getTickLabelInsets();
        java.awt.Paint paint17 = categoryAxis13.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font18 = categoryAxis13.getLabelFont();
        intervalMarker9.setLabelFont(font18);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        intervalMarker9.setLabelAnchor(rectangleAnchor20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str23 = categoryPlot22.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font25 = categoryAxis24.getLabelFont();
        categoryPlot22.setNoDataMessageFont(font25);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot22.addDomainMarker((int) 'a', categoryMarker29, layer30);
        boolean boolean32 = rectangleAnchor20.equals((java.lang.Object) categoryMarker29);
        boolean boolean33 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker29);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(list4);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(legendItemCollection34);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        java.awt.Color color7 = java.awt.Color.WHITE;
        java.awt.Color color8 = color7.darker();
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        int int10 = color8.getTransparency();
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color8);
        double double12 = categoryAxis1.getLowerMargin();
        categoryAxis1.setAxisLineVisible(false);
        java.awt.Font font15 = categoryAxis1.getTickLabelFont();
        java.lang.Object obj16 = categoryAxis1.clone();
        categoryAxis1.setAxisLineVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        xYPlot13.clearAnnotations();
        boolean boolean19 = xYPlot13.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        double double22 = categoryAxis21.getLowerMargin();
        java.awt.Color color23 = java.awt.Color.WHITE;
        java.awt.Color color24 = color23.darker();
        categoryAxis21.setTickMarkPaint((java.awt.Paint) color23);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        double double27 = categoryPlot26.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset29 = categoryPlot26.getDataset((int) (byte) 1);
        categoryAxis21.setPlot((org.jfree.chart.plot.Plot) categoryPlot26);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot26.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot26.getRangeAxisLocation();
        java.awt.Paint paint33 = categoryPlot26.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection34 = categoryPlot26.getLegendItems();
        xYPlot13.setFixedLegendItems(legendItemCollection34);
        java.awt.geom.Point2D point2D36 = xYPlot13.getQuadrantOrigin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset29);
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(legendItemCollection34);
        org.junit.Assert.assertNotNull(point2D36);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot0.getRangeAxisLocation((int) '4');
        categoryPlot0.clearDomainMarkers(6);
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        numberAxis1.setUpperMargin((double) 100.0f);
        java.text.NumberFormat numberFormat7 = numberAxis1.getNumberFormatOverride();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis9.setNegativeArrowVisible(false);
        java.awt.Paint paint12 = numberAxis9.getTickMarkPaint();
        org.jfree.data.Range range13 = numberAxis9.getRange();
        numberAxis1.setDefaultAutoRange(range13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double19 = numberAxis18.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis21.setNegativeArrowVisible(false);
        java.awt.Shape shape24 = numberAxis21.getDownArrow();
        numberAxis21.setUpperMargin((double) 100.0f);
        double double27 = numberAxis21.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis21, xYItemRenderer28);
        org.jfree.chart.axis.AxisLocation axisLocation31 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation31, plotOrientation32);
        xYPlot29.setDomainAxisLocation(11, axisLocation31);
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double39 = numberAxis38.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis41.setNegativeArrowVisible(false);
        java.awt.Shape shape44 = numberAxis41.getDownArrow();
        numberAxis41.setUpperMargin((double) 100.0f);
        double double47 = numberAxis41.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset36, (org.jfree.chart.axis.ValueAxis) numberAxis38, (org.jfree.chart.axis.ValueAxis) numberAxis41, xYItemRenderer48);
        xYPlot49.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = xYPlot49.getRangeAxisEdge(11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo55 = null;
        java.awt.geom.Point2D point2D56 = null;
        xYPlot49.zoomRangeAxes((double) 100.0f, plotRenderingInfo55, point2D56);
        xYPlot49.setRangeCrosshairValue(0.2d, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer61 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray62 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer61 };
        xYPlot49.setRenderers(xYItemRendererArray62);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = xYPlot49.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace65 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace66 = numberAxis1.reserveSpace(graphics2D15, (org.jfree.chart.plot.Plot) xYPlot29, rectangle2D35, rectangleEdge64, axisSpace65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(numberFormat7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(shape44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(xYItemRendererArray62);
        org.junit.Assert.assertNotNull(rectangleEdge64);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setNegativeArrowVisible(false);
        java.awt.Paint paint5 = numberAxis2.getTickMarkPaint();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint5, stroke6, (java.awt.Paint) color7, stroke8, (float) (byte) 1);
        valueMarker10.setLabel("NO_CHANGE");
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Color color15 = java.awt.Color.BLACK;
        categoryAxis14.setTickLabelPaint((java.awt.Paint) color15);
        int int17 = color15.getAlpha();
        valueMarker10.setOutlinePaint((java.awt.Paint) color15);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape20 = defaultDrawingSupplier19.getNextShape();
        java.awt.Shape shape21 = defaultDrawingSupplier19.getNextShape();
        java.awt.Shape shape22 = defaultDrawingSupplier19.getNextShape();
        java.awt.Stroke stroke23 = defaultDrawingSupplier19.getNextStroke();
        java.awt.Stroke stroke24 = defaultDrawingSupplier19.getNextStroke();
        valueMarker10.setStroke(stroke24);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        boolean boolean27 = valueMarker10.equals((java.lang.Object) datasetRenderingOrder26);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace17, false);
        org.jfree.data.xy.XYDataset xYDataset20 = xYPlot13.getDataset();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        double double22 = categoryPlot21.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot21.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot21.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot21.getRangeAxisEdge();
        java.awt.Image image28 = categoryPlot21.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer32 = null;
        intervalMarker31.setGradientPaintTransformer(gradientPaintTransformer32);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        double double36 = categoryAxis35.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = categoryAxis35.getTickLabelInsets();
        java.awt.Paint paint39 = categoryAxis35.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font40 = categoryAxis35.getLabelFont();
        intervalMarker31.setLabelFont(font40);
        categoryPlot21.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker31);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent43 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker31);
        boolean boolean44 = xYPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker31);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        double double46 = categoryPlot45.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset48 = categoryPlot45.getDataset((int) (byte) 1);
        boolean boolean49 = categoryPlot45.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis51 = categoryPlot45.getRangeAxis(255);
        categoryPlot45.setRangeCrosshairValue(0.0d);
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot45.getDomainAxisLocation((int) '#');
        xYPlot13.setRangeAxisLocation(axisLocation55, true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(xYDataset20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertNull(categoryAxis26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNull(image28);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(valueAxis51);
        org.junit.Assert.assertNotNull(axisLocation55);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot0.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = null;
        categoryPlot0.axisChanged(axisChangeEvent9);
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot1.getFixedLegendItems();
        java.awt.Image image3 = null;
        categoryPlot1.setBackgroundImage(image3);
        categoryPlot1.clearAnnotations();
        boolean boolean6 = textAnchor0.equals((java.lang.Object) categoryPlot1);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.util.List list9 = categoryPlot1.getCategoriesForAxis(categoryAxis8);
        categoryPlot1.clearRangeMarkers();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            boolean boolean9 = categoryPlot0.removeAnnotation(categoryAnnotation7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        double double5 = numberAxis1.getUpperBound();
        numberAxis1.centerRange((double) (byte) 0);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double11 = numberAxis10.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis13.setNegativeArrowVisible(false);
        java.awt.Shape shape16 = numberAxis13.getDownArrow();
        numberAxis13.setUpperMargin((double) 100.0f);
        double double19 = numberAxis13.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer20);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis13.setTickUnit(numberTickUnit22, true, true);
        numberAxis1.setTickUnit(numberTickUnit22);
        numberAxis1.setLabel("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
        java.awt.Paint paint29 = numberAxis1.getTickLabelPaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit22);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        java.lang.String str2 = color1.toString();
        java.awt.Color color3 = java.awt.Color.getColor("Category Plot", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=128,g=0,b=128]" + "'", str2.equals("java.awt.Color[r=128,g=0,b=128]"));
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        java.lang.Object obj2 = categoryMarker1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        double double5 = rectangleInsets3.trimWidth((double) (-1));
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets3.createOutsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-9.0d) + "'", double5 == (-9.0d));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot0.getRendererForDataset(xYDataset5);
        java.awt.Stroke stroke7 = xYPlot0.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer9 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection10 = xYPlot0.getDomainMarkers(4, layer9);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot0.getRenderer();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        double double15 = categoryPlot14.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot14.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot14.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.data.Range range21 = categoryPlot14.getDataRange(valueAxis20);
        java.awt.Paint paint22 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot14.setNoDataMessagePaint(paint22);
        java.awt.Color color24 = java.awt.Color.blue;
        categoryPlot14.setNoDataMessagePaint((java.awt.Paint) color24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        int int27 = categoryPlot14.getIndexOf(categoryItemRenderer26);
        java.awt.Color color28 = java.awt.Color.darkGray;
        categoryPlot14.setNoDataMessagePaint((java.awt.Paint) color28);
        boolean boolean30 = categoryPlot14.getDrawSharedDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double37 = numberAxis36.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis39.setNegativeArrowVisible(false);
        java.awt.Shape shape42 = numberAxis39.getDownArrow();
        numberAxis39.setUpperMargin((double) 100.0f);
        double double45 = numberAxis39.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.plot.XYPlot xYPlot47 = new org.jfree.chart.plot.XYPlot(xYDataset34, (org.jfree.chart.axis.ValueAxis) numberAxis36, (org.jfree.chart.axis.ValueAxis) numberAxis39, xYItemRenderer46);
        boolean boolean48 = xYPlot47.isDomainCrosshairLockedOnData();
        java.awt.geom.Point2D point2D49 = xYPlot47.getQuadrantOrigin();
        categoryPlot14.zoomRangeAxes(0.0d, (double) 12, plotRenderingInfo33, point2D49);
        xYPlot0.zoomRangeAxes((double) 0.5f, plotRenderingInfo13, point2D49);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(layer9);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(point2D49);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot0.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRendererForDataset(categoryDataset9);
        int int11 = categoryPlot0.getDatasetCount();
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-4.0d), font3);
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker11 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        xYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker11);
        java.awt.Paint paint13 = intervalMarker11.getPaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (-1.0d), paint13);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        numberAxis1.setUpperMargin((double) 100.0f);
        java.awt.Stroke stroke7 = numberAxis1.getAxisLineStroke();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double12 = numberAxis11.getAutoRangeMinimumSize();
        java.awt.Shape shape13 = numberAxis11.getUpArrow();
        numberAxis9.setDownArrow(shape13);
        numberAxis1.setDownArrow(shape13);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double19 = numberAxis18.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis21.setNegativeArrowVisible(false);
        java.awt.Shape shape24 = numberAxis21.getDownArrow();
        numberAxis21.setUpperMargin((double) 100.0f);
        double double27 = numberAxis21.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis21, xYItemRenderer28);
        boolean boolean30 = xYPlot29.isDomainCrosshairLockedOnData();
        java.awt.Paint paint31 = xYPlot29.getDomainGridlinePaint();
        xYPlot29.clearRangeMarkers(255);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Color color38 = java.awt.Color.BLACK;
        categoryAxis37.setTickLabelPaint((java.awt.Paint) color38);
        int int40 = color38.getAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        double double42 = categoryPlot41.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset44 = categoryPlot41.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = categoryPlot41.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.data.Range range48 = categoryPlot41.getDataRange(valueAxis47);
        java.awt.Paint paint49 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot41.setNoDataMessagePaint(paint49);
        java.awt.Color color51 = java.awt.Color.blue;
        categoryPlot41.setNoDataMessagePaint((java.awt.Paint) color51);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        int int54 = categoryPlot41.getIndexOf(categoryItemRenderer53);
        java.awt.Color color55 = java.awt.Color.darkGray;
        categoryPlot41.setNoDataMessagePaint((java.awt.Paint) color55);
        java.util.List list57 = categoryPlot41.getAnnotations();
        boolean boolean58 = color38.equals((java.lang.Object) list57);
        xYPlot29.drawRangeTickBands(graphics2D34, rectangle2D35, list57);
        int int60 = xYPlot29.getDomainAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection62 = categoryPlot61.getFixedLegendItems();
        java.awt.Graphics2D graphics2D63 = null;
        java.awt.geom.Rectangle2D rectangle2D64 = null;
        categoryPlot61.drawBackgroundImage(graphics2D63, rectangle2D64);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor66 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str67 = categoryAnchor66.toString();
        categoryPlot61.setDomainGridlinePosition(categoryAnchor66);
        xYPlot29.setParent((org.jfree.chart.plot.Plot) categoryPlot61);
        xYPlot29.setWeight(11);
        java.awt.Stroke stroke72 = xYPlot29.getRangeGridlineStroke();
        numberAxis1.setTickMarkStroke(stroke72);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0E-8d + "'", double12 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 255 + "'", int40 == 255);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset44);
        org.junit.Assert.assertNull(categoryAxis46);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(list57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertNull(legendItemCollection62);
        org.junit.Assert.assertNotNull(categoryAnchor66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "CategoryAnchor.END" + "'", str67.equals("CategoryAnchor.END"));
        org.junit.Assert.assertNotNull(stroke72);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-4.0d), font3);
        int int5 = categoryAxis1.getCategoryLabelPositionOffset();
        categoryAxis1.setCategoryLabelPositionOffset(8);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        double double10 = categoryAxis9.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener11 = null;
        categoryAxis9.addChangeListener(axisChangeListener11);
        categoryAxis9.setLabelAngle((double) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryAxis9.getTickLabelInsets();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions16 = categoryAxis9.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions16);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double25 = numberAxis24.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setNegativeArrowVisible(false);
        java.awt.Shape shape30 = numberAxis27.getDownArrow();
        numberAxis27.setUpperMargin((double) 100.0f);
        double double33 = numberAxis27.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset22, (org.jfree.chart.axis.ValueAxis) numberAxis24, (org.jfree.chart.axis.ValueAxis) numberAxis27, xYItemRenderer34);
        xYPlot35.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = xYPlot35.getRangeAxisEdge(11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        xYPlot35.zoomRangeAxes((double) 100.0f, plotRenderingInfo41, point2D42);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo47 = null;
        org.jfree.chart.plot.CrosshairState crosshairState48 = null;
        boolean boolean49 = xYPlot35.render(graphics2D44, rectangle2D45, 1, plotRenderingInfo47, crosshairState48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = xYPlot35.getRangeAxisEdge();
        double double51 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor18, (int) (short) 100, (int) (byte) 100, rectangle2D21, rectangleEdge50);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(categoryLabelPositions16);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        xYPlot0.clearDomainAxes();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        try {
            xYPlot0.setRangeAxisLocation(axisLocation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        boolean boolean17 = categoryPlot6.render(graphics2D13, rectangle2D14, 8, plotRenderingInfo16);
        int int18 = categoryPlot6.getRangeAxisCount();
        categoryPlot6.clearRangeAxes();
        categoryPlot6.setRangeCrosshairValue((double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot1.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot1.setDomainCrosshairStroke(stroke4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot1.getRendererForDataset(xYDataset6);
        java.awt.Stroke stroke8 = xYPlot1.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection11 = xYPlot1.getDomainMarkers(4, layer10);
        boolean boolean12 = layer0.equals((java.lang.Object) xYPlot1);
        java.awt.Color color13 = java.awt.Color.PINK;
        xYPlot1.setRangeZeroBaselinePaint((java.awt.Paint) color13);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        xYPlot1.rendererChanged(rendererChangeEvent15);
        java.util.List list17 = xYPlot1.getAnnotations();
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(list17);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis();
        java.awt.Paint paint4 = xYPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-4.0d), font3);
        boolean boolean5 = categoryAxis1.isTickMarksVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis1.getLabelInsets();
        double double8 = rectangleInsets6.calculateRightOutset((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3.0d + "'", double8 == 3.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getAxisOffset();
        boolean boolean7 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart13);
        java.lang.Object obj15 = chartChangeEvent14.getSource();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace17, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot13.setRenderer((int) '#', xYItemRenderer21, true);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot26.getRangeAxisEdge((int) (short) 100);
        xYPlot26.clearDomainMarkers();
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        double double33 = categoryPlot32.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset35 = categoryPlot32.getDataset((int) (byte) 1);
        boolean boolean36 = categoryPlot32.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis38 = categoryPlot32.getRangeAxis(255);
        categoryPlot32.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        double double43 = categoryAxis42.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = categoryAxis42.getTickLabelInsets();
        java.awt.Paint paint45 = categoryAxis42.getTickLabelPaint();
        categoryAxis42.setLowerMargin((-1.0d));
        java.util.List list48 = categoryPlot32.getCategoriesForAxis(categoryAxis42);
        xYPlot26.drawRangeTickBands(graphics2D30, rectangle2D31, list48);
        xYPlot13.drawRangeTickBands(graphics2D24, rectangle2D25, list48);
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double54 = numberAxis53.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis56 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis56.setNegativeArrowVisible(false);
        java.awt.Shape shape59 = numberAxis56.getDownArrow();
        numberAxis56.setUpperMargin((double) 100.0f);
        double double62 = numberAxis56.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset51, (org.jfree.chart.axis.ValueAxis) numberAxis53, (org.jfree.chart.axis.ValueAxis) numberAxis56, xYItemRenderer63);
        boolean boolean65 = xYPlot64.isDomainCrosshairLockedOnData();
        java.awt.Stroke stroke66 = xYPlot64.getRangeGridlineStroke();
        java.awt.Paint paint67 = xYPlot64.getRangeCrosshairPaint();
        xYPlot13.setRangeTickBandPaint(paint67);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.05d + "'", double54 == 0.05d);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(paint67);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone7);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass12 = color11.getClass();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.Class class15 = null;
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone17);
        java.awt.Color color20 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass21 = color20.getClass();
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.lang.Class class24 = null;
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone26);
        java.lang.Class class29 = null;
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date22, timeZone31);
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color35 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass36 = color35.getClass();
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.lang.Class class39 = null;
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date34, timeZone41);
        java.lang.Class class45 = null;
        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date34, timeZone47);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("13-June-2019", timeZone47);
        dateAxis50.configure();
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis53.setNegativeArrowVisible(false);
        org.jfree.data.Range range56 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis53.setRange(range56, true, false);
        dateAxis50.setRange(range56, false, true);
        boolean boolean63 = dateAxis50.isPositiveArrowVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setRangeCrosshairValue(0.0d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomDomainAxes((double) 10, plotRenderingInfo10, point2D11);
        boolean boolean13 = categoryPlot0.isRangeCrosshairVisible();
        categoryPlot0.clearRangeMarkers(4);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double19 = numberAxis18.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis21.setNegativeArrowVisible(false);
        java.awt.Shape shape24 = numberAxis21.getDownArrow();
        numberAxis21.setUpperMargin((double) 100.0f);
        double double27 = numberAxis21.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset16, (org.jfree.chart.axis.ValueAxis) numberAxis18, (org.jfree.chart.axis.ValueAxis) numberAxis21, xYItemRenderer28);
        xYPlot29.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = xYPlot29.getRangeAxisEdge(11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        xYPlot29.zoomRangeAxes((double) 100.0f, plotRenderingInfo35, point2D36);
        java.awt.Paint paint38 = xYPlot29.getRangeCrosshairPaint();
        categoryPlot0.setDomainGridlinePaint(paint38);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        categoryAxis1.setLabelAngle((double) 100);
        boolean boolean7 = categoryAxis1.isTickLabelsVisible();
        categoryAxis1.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint11 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        double double14 = categoryAxis13.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener15 = null;
        categoryAxis13.addChangeListener(axisChangeListener15);
        categoryAxis13.setLabelAngle((double) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryAxis13.getTickLabelInsets();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = categoryAxis13.getCategoryLabelPositions();
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.centerRange((double) (byte) 0);
        numberAxis1.resizeRange((-1.0d));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        categoryAxis1.setLabelAngle((double) 100);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        try {
            double double16 = categoryAxis1.getCategoryEnd((int) '#', (int) '4', rectangle2D9, rectangleEdge15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8);
        categoryPlot0.setRangeGridlinesVisible(true);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot0.getIndexOf(categoryItemRenderer12);
        java.awt.Color color14 = java.awt.Color.darkGray;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        double double18 = categoryAxis17.getLowerMargin();
        java.awt.Color color19 = java.awt.Color.WHITE;
        java.awt.Color color20 = color19.darker();
        categoryAxis17.setTickMarkPaint((java.awt.Paint) color19);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        double double23 = categoryPlot22.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset25 = categoryPlot22.getDataset((int) (byte) 1);
        categoryAxis17.setPlot((org.jfree.chart.plot.Plot) categoryPlot22);
        org.jfree.chart.util.SortOrder sortOrder27 = categoryPlot22.getRowRenderingOrder();
        categoryPlot0.setRowRenderingOrder(sortOrder27);
        categoryPlot0.clearRangeAxes();
        categoryPlot0.setRangeGridlinesVisible(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        categoryPlot0.setRenderer(categoryItemRenderer32, false);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset25);
        org.junit.Assert.assertNotNull(sortOrder27);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot13.getRangeAxisEdge();
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot13.getDomainAxis(255);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        double double30 = categoryPlot29.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot29.getDataset((int) (byte) 1);
        boolean boolean33 = categoryPlot29.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis35 = categoryPlot29.getRangeAxis(255);
        categoryPlot29.setRangeCrosshairValue(0.0d);
        java.awt.Paint paint38 = categoryPlot29.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation39 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation39, plotOrientation40);
        categoryPlot29.setOrientation(plotOrientation40);
        java.awt.Paint[] paintArray43 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray44 = null;
        java.awt.Paint[] paintArray45 = null;
        java.awt.Stroke stroke46 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke48 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke50 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke51 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray52 = new java.awt.Stroke[] { stroke46, stroke47, stroke48, stroke49, stroke50, stroke51 };
        java.awt.Stroke stroke53 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke54 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke55 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke56 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke57 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray58 = new java.awt.Stroke[] { stroke53, stroke54, stroke55, stroke56, stroke57 };
        java.awt.Shape[] shapeArray59 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier60 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray43, paintArray44, paintArray45, strokeArray52, strokeArray58, shapeArray59);
        java.awt.Stroke stroke61 = defaultDrawingSupplier60.getNextOutlineStroke();
        categoryPlot29.setRangeGridlineStroke(stroke61);
        java.awt.Paint paint63 = categoryPlot29.getRangeGridlinePaint();
        xYPlot13.setRangeCrosshairPaint(paint63);
        java.awt.Color color65 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace66 = color65.getColorSpace();
        xYPlot13.setDomainTickBandPaint((java.awt.Paint) color65);
        double double68 = xYPlot13.getDomainCrosshairValue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(valueAxis35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(axisLocation39);
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(paintArray43);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(strokeArray52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(strokeArray58);
        org.junit.Assert.assertNotNull(shapeArray59);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(colorSpace66);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        org.jfree.chart.plot.Marker marker7 = markerChangeEvent6.getMarker();
        java.awt.Stroke stroke8 = marker7.getOutlineStroke();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = marker7.getLabelAnchor();
        org.jfree.chart.text.TextAnchor textAnchor10 = marker7.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(marker7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        xYPlot13.clearAnnotations();
        boolean boolean19 = xYPlot13.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        double double22 = categoryAxis21.getLowerMargin();
        java.awt.Color color23 = java.awt.Color.WHITE;
        java.awt.Color color24 = color23.darker();
        categoryAxis21.setTickMarkPaint((java.awt.Paint) color23);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        double double27 = categoryPlot26.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset29 = categoryPlot26.getDataset((int) (byte) 1);
        categoryAxis21.setPlot((org.jfree.chart.plot.Plot) categoryPlot26);
        org.jfree.chart.util.SortOrder sortOrder31 = categoryPlot26.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot26.getRangeAxisLocation();
        java.awt.Paint paint33 = categoryPlot26.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection34 = categoryPlot26.getLegendItems();
        xYPlot13.setFixedLegendItems(legendItemCollection34);
        java.awt.Paint paint36 = xYPlot13.getOutlinePaint();
        xYPlot13.mapDatasetToRangeAxis((int) '4', 8);
        org.jfree.chart.plot.IntervalMarker intervalMarker42 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer43 = null;
        intervalMarker42.setGradientPaintTransformer(gradientPaintTransformer43);
        java.awt.Paint paint45 = intervalMarker42.getLabelPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent46 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker42);
        intervalMarker42.setAlpha((float) 1L);
        java.awt.Color color49 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int50 = color49.getAlpha();
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        double double53 = categoryAxis52.getLowerMargin();
        java.awt.Paint paint55 = categoryAxis52.getTickLabelPaint((java.lang.Comparable) 'a');
        java.awt.Color color56 = java.awt.Color.MAGENTA;
        categoryAxis52.setTickMarkPaint((java.awt.Paint) color56);
        float[] floatArray64 = new float[] { 1560409200000L, 2.0f, 2.0f, (short) 10, '#', (byte) 10 };
        float[] floatArray65 = color56.getRGBComponents(floatArray64);
        float[] floatArray66 = color49.getRGBColorComponents(floatArray65);
        intervalMarker42.setPaint((java.awt.Paint) color49);
        xYPlot13.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker42);
        java.awt.Stroke stroke69 = intervalMarker42.getStroke();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.05d + "'", double22 == 0.05d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset29);
        org.junit.Assert.assertNotNull(sortOrder31);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(legendItemCollection34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 255 + "'", int50 == 255);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.05d + "'", double53 == 0.05d);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(floatArray64);
        org.junit.Assert.assertNotNull(floatArray65);
        org.junit.Assert.assertNotNull(floatArray66);
        org.junit.Assert.assertNotNull(stroke69);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        intervalMarker10.setGradientPaintTransformer(gradientPaintTransformer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        double double15 = categoryAxis14.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis14.getTickLabelInsets();
        java.awt.Paint paint18 = categoryAxis14.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font19 = categoryAxis14.getLabelFont();
        intervalMarker10.setLabelFont(font19);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10);
        boolean boolean22 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        double double28 = categoryPlot27.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset30 = categoryPlot27.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = categoryPlot27.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.data.Range range34 = categoryPlot27.getDataRange(valueAxis33);
        java.awt.Paint paint35 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot27.setNoDataMessagePaint(paint35);
        java.awt.Color color37 = java.awt.Color.blue;
        categoryPlot27.setNoDataMessagePaint((java.awt.Paint) color37);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = null;
        int int40 = categoryPlot27.getIndexOf(categoryItemRenderer39);
        java.awt.Color color41 = java.awt.Color.darkGray;
        categoryPlot27.setNoDataMessagePaint((java.awt.Paint) color41);
        boolean boolean43 = categoryPlot27.getDrawSharedDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double50 = numberAxis49.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis52.setNegativeArrowVisible(false);
        java.awt.Shape shape55 = numberAxis52.getDownArrow();
        numberAxis52.setUpperMargin((double) 100.0f);
        double double58 = numberAxis52.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer59 = null;
        org.jfree.chart.plot.XYPlot xYPlot60 = new org.jfree.chart.plot.XYPlot(xYDataset47, (org.jfree.chart.axis.ValueAxis) numberAxis49, (org.jfree.chart.axis.ValueAxis) numberAxis52, xYItemRenderer59);
        boolean boolean61 = xYPlot60.isDomainCrosshairLockedOnData();
        java.awt.geom.Point2D point2D62 = xYPlot60.getQuadrantOrigin();
        categoryPlot27.zoomRangeAxes(0.0d, (double) 12, plotRenderingInfo46, point2D62);
        categoryPlot0.zoomRangeAxes((double) 0.0f, plotRenderingInfo26, point2D62);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(categoryAnchor23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset30);
        org.junit.Assert.assertNull(categoryAxis32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.05d + "'", double50 == 0.05d);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(point2D62);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setNegativeArrowVisible(false);
        java.awt.Paint paint5 = numberAxis2.getTickMarkPaint();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint5, stroke6, (java.awt.Paint) color7, stroke8, (float) (byte) 1);
        valueMarker10.setLabel("NO_CHANGE");
        java.awt.Stroke stroke13 = valueMarker10.getStroke();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 12, (double) 43629L, (double) 10L, (double) 500);
        java.lang.String str5 = rectangleInsets4.toString();
        double double7 = rectangleInsets4.calculateTopOutset((double) 3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=12.0,l=43629.0,b=10.0,r=500.0]" + "'", str5.equals("RectangleInsets[t=12.0,l=43629.0,b=10.0,r=500.0]"));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 12.0d + "'", double7 == 12.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis16.setNegativeArrowVisible(false);
        org.jfree.data.Range range19 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis16);
        float float20 = xYPlot13.getForegroundAlpha();
        boolean boolean21 = xYPlot13.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis();
        xYPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.setWeight(0);
        java.lang.Object obj9 = xYPlot0.clone();
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder6);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        java.awt.Paint paint6 = intervalMarker2.getPaint();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.awt.Color color9 = java.awt.Color.GREEN;
        java.awt.Color color10 = java.awt.Color.getColor("UnitType.RELATIVE", color9);
        boolean boolean11 = lengthAdjustmentType7.equals((java.lang.Object) color10);
        intervalMarker2.setLabelOffsetType(lengthAdjustmentType7);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        java.awt.Color color7 = java.awt.Color.WHITE;
        java.awt.Color color8 = color7.darker();
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        int int10 = color8.getTransparency();
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color8);
        double double12 = categoryAxis1.getLowerMargin();
        categoryAxis1.setAxisLineVisible(false);
        java.awt.Font font15 = categoryAxis1.getTickLabelFont();
        java.lang.Object obj16 = categoryAxis1.clone();
        double double17 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot7.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray10 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer9 };
        xYPlot7.setRenderers(xYItemRendererArray10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = xYPlot7.getRendererForDataset(xYDataset12);
        java.awt.geom.Point2D point2D14 = xYPlot7.getQuadrantOrigin();
        categoryPlot0.zoomDomainAxes((double) 0.0f, plotRenderingInfo6, point2D14);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertNotNull(xYItemRendererArray10);
        org.junit.Assert.assertNull(xYItemRenderer13);
        org.junit.Assert.assertNotNull(point2D14);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisLocation axisLocation4 = xYPlot0.getRangeAxisLocation((int) (short) 0);
        org.jfree.chart.axis.ValueAxis valueAxis6 = xYPlot0.getDomainAxis(2019);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(valueAxis6);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        java.lang.String str26 = layer23.toString();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Layer.FOREGROUND" + "'", str26.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis4.setNegativeArrowVisible(false);
        numberAxis4.setVerticalTickLabels(false);
        numberAxis4.setRangeAboutValue(0.0d, 1.0d);
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder13 = xYPlot12.getSeriesRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        xYPlot12.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker16);
        java.awt.Color color18 = java.awt.Color.red;
        xYPlot12.setDomainGridlinePaint((java.awt.Paint) color18);
        numberAxis4.setAxisLinePaint((java.awt.Paint) color18);
        java.awt.Color color21 = java.awt.Color.red;
        java.lang.String str22 = color21.toString();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double25 = numberAxis24.getUpperMargin();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand26 = numberAxis24.getMarkerBand();
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int28 = color27.getAlpha();
        numberAxis24.setTickMarkPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Color color32 = java.awt.Color.BLACK;
        categoryAxis31.setTickLabelPaint((java.awt.Paint) color32);
        int int34 = color32.getAlpha();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        double double37 = categoryAxis36.getLowerMargin();
        java.awt.Paint paint39 = categoryAxis36.getTickLabelPaint((java.lang.Comparable) 'a');
        java.awt.Color color40 = java.awt.Color.MAGENTA;
        categoryAxis36.setTickMarkPaint((java.awt.Paint) color40);
        float[] floatArray48 = new float[] { 1560409200000L, 2.0f, 2.0f, (short) 10, '#', (byte) 10 };
        float[] floatArray49 = color40.getRGBComponents(floatArray48);
        float[] floatArray50 = color32.getColorComponents(floatArray49);
        float[] floatArray51 = color27.getRGBColorComponents(floatArray50);
        float[] floatArray52 = color21.getComponents(floatArray50);
        float[] floatArray53 = color18.getRGBColorComponents(floatArray50);
        float[] floatArray54 = java.awt.Color.RGBtoHSB(0, 100, (int) '4', floatArray53);
        org.junit.Assert.assertNotNull(seriesRenderingOrder13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str22.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertNull(markerAxisBand26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 255 + "'", int28 == 255);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 255 + "'", int34 == 255);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(floatArray48);
        org.junit.Assert.assertNotNull(floatArray49);
        org.junit.Assert.assertNotNull(floatArray50);
        org.junit.Assert.assertNotNull(floatArray51);
        org.junit.Assert.assertNotNull(floatArray52);
        org.junit.Assert.assertNotNull(floatArray53);
        org.junit.Assert.assertNotNull(floatArray54);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot13.zoomRangeAxes((double) 100.0f, plotRenderingInfo19, point2D20);
        xYPlot13.setRangeCrosshairValue(0.2d, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray26 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer25 };
        xYPlot13.setRenderers(xYItemRendererArray26);
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        intervalMarker30.setStartValue((double) (short) 100);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double36 = numberAxis35.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis38 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis38.setNegativeArrowVisible(false);
        java.awt.Shape shape41 = numberAxis38.getDownArrow();
        numberAxis38.setUpperMargin((double) 100.0f);
        double double44 = numberAxis38.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset33, (org.jfree.chart.axis.ValueAxis) numberAxis35, (org.jfree.chart.axis.ValueAxis) numberAxis38, xYItemRenderer45);
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str49 = categoryPlot48.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font51 = categoryAxis50.getLabelFont();
        categoryPlot48.setNoDataMessageFont(font51);
        org.jfree.chart.plot.CategoryMarker categoryMarker55 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer56 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot48.addDomainMarker((int) 'a', categoryMarker55, layer56);
        java.util.Collection collection58 = xYPlot46.getRangeMarkers(3, layer56);
        boolean boolean59 = xYPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker30, layer56);
        org.jfree.chart.axis.AxisSpace axisSpace60 = xYPlot13.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(xYItemRendererArray26);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNull(str49);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(layer56);
        org.junit.Assert.assertNull(collection58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNull(axisSpace60);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.geom.Point2D point2D15 = xYPlot13.getQuadrantOrigin();
        java.util.List list16 = xYPlot13.getAnnotations();
        int int17 = xYPlot13.getSeriesCount();
        boolean boolean18 = xYPlot13.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(point2D15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.SortOrder sortOrder6 = categoryPlot0.getRowRenderingOrder();
        java.lang.Object obj7 = null;
        boolean boolean8 = sortOrder6.equals(obj7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(sortOrder6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        xYPlot13.setDomainCrosshairValue((double) 1.0f);
        org.jfree.chart.axis.AxisSpace axisSpace19 = xYPlot13.getFixedRangeAxisSpace();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(axisSpace19);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.Paint paint15 = xYPlot13.getDomainGridlinePaint();
        xYPlot13.clearRangeMarkers(255);
        java.awt.Color color19 = java.awt.Color.GREEN;
        java.awt.Color color20 = java.awt.Color.getColor("UnitType.RELATIVE", color19);
        java.awt.Color color21 = color20.darker();
        xYPlot13.setRangeGridlinePaint((java.awt.Paint) color20);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        xYPlot0.clearDomainMarkers();
        xYPlot0.mapDatasetToRangeAxis(255, (int) (byte) 100);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(categoryItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        double double15 = categoryPlot14.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot14.getDataset((int) (byte) 1);
        boolean boolean18 = categoryPlot14.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis20 = categoryPlot14.getRangeAxis(255);
        categoryPlot14.setRangeCrosshairValue(0.0d);
        java.awt.Paint paint23 = categoryPlot14.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation24, plotOrientation25);
        categoryPlot14.setOrientation(plotOrientation25);
        java.lang.String str28 = plotOrientation25.toString();
        java.lang.String str29 = plotOrientation25.toString();
        categoryPlot6.setOrientation(plotOrientation25);
        int int31 = categoryPlot6.getDatasetCount();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str28.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str29.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

//    @Test
//    public void test246() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test246");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        long long1 = day0.getSerialIndex();
//        long long2 = day0.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
//        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
//        double double7 = numberAxis6.getAutoRangeMinimumSize();
//        java.awt.Shape shape8 = numberAxis6.getDownArrow();
//        boolean boolean9 = numberAxis6.getAutoRangeStickyZero();
//        org.jfree.chart.axis.TickUnitSource tickUnitSource10 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//        numberAxis6.setStandardTickUnits(tickUnitSource10);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource12 = numberAxis6.getStandardTickUnits();
//        boolean boolean13 = day4.equals((java.lang.Object) numberAxis6);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43629L + "'", long1 == 43629L);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1560409200000L + "'", long2 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-8d + "'", double7 == 1.0E-8d);
//        org.junit.Assert.assertNotNull(shape8);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
//        org.junit.Assert.assertNotNull(tickUnitSource10);
//        org.junit.Assert.assertNotNull(tickUnitSource12);
//        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
//    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        java.awt.Stroke stroke4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis2.setAxisLineStroke(stroke4);
        xYPlot0.setDomainGridlineStroke(stroke4);
        java.awt.Paint paint7 = xYPlot0.getRangeZeroBaselinePaint();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        xYPlot0.setFixedDomainAxisSpace(axisSpace8, true);
        org.jfree.data.xy.XYDataset xYDataset12 = xYPlot0.getDataset(192);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(xYDataset12);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setRangeCrosshairValue(0.0d);
        java.awt.Stroke stroke9 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder10 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        java.lang.String str11 = seriesRenderingOrder10.toString();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double15 = numberAxis14.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis17.setNegativeArrowVisible(false);
        java.awt.Shape shape20 = numberAxis17.getDownArrow();
        numberAxis17.setUpperMargin((double) 100.0f);
        double double23 = numberAxis17.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis14, (org.jfree.chart.axis.ValueAxis) numberAxis17, xYItemRenderer24);
        xYPlot25.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot25.getRangeAxisEdge(11);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis33.setNegativeArrowVisible(false);
        java.awt.Paint paint36 = numberAxis33.getTickMarkPaint();
        java.awt.Stroke stroke37 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint36, stroke37, (java.awt.Paint) color38, stroke39, (float) (byte) 1);
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean44 = xYPlot25.removeDomainMarker(3, (org.jfree.chart.plot.Marker) valueMarker41, layer42, true);
        boolean boolean45 = seriesRenderingOrder10.equals((java.lang.Object) valueMarker41);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        double double47 = categoryPlot46.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset49 = categoryPlot46.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = categoryPlot46.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot46.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font54 = categoryAxis53.getLabelFont();
        categoryPlot46.setDomainAxis(categoryAxis53);
        org.jfree.chart.plot.IntervalMarker intervalMarker59 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer60 = null;
        intervalMarker59.setGradientPaintTransformer(gradientPaintTransformer60);
        java.awt.Paint paint62 = intervalMarker59.getLabelPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent63 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker59);
        org.jfree.chart.plot.Marker marker64 = markerChangeEvent63.getMarker();
        org.jfree.chart.util.Layer layer65 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean67 = categoryPlot46.removeDomainMarker((-16777216), marker64, layer65, true);
        boolean boolean68 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) valueMarker41, layer65);
        org.jfree.data.category.CategoryDataset categoryDataset70 = null;
        try {
            categoryPlot0.setDataset((-1), categoryDataset70);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(seriesRenderingOrder10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "SeriesRenderingOrder.FORWARD" + "'", str11.equals("SeriesRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset49);
        org.junit.Assert.assertNull(categoryAxis51);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(marker64);
        org.junit.Assert.assertNotNull(layer65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation1, plotOrientation2);
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation1.getOpposite();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean6 = axisLocation4.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double9 = numberAxis8.getUpperMargin();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = numberAxis8.getMarkerBand();
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis8.setStandardTickUnits(tickUnitSource11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer13);
        java.awt.Stroke stroke15 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        numberAxis8.setTickMarkStroke(stroke15);
        java.text.NumberFormat numberFormat17 = numberAxis8.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(markerAxisBand10);
        org.junit.Assert.assertNotNull(tickUnitSource11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(numberFormat17);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str17 = plotOrientation16.toString();
        xYPlot13.setOrientation(plotOrientation16);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        double double20 = categoryPlot19.getAnchorValue();
        categoryPlot19.setBackgroundAlpha(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot24.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot24.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation28 = categoryPlot24.getDomainAxisLocation(255);
        categoryPlot19.setDomainAxisLocation((int) (byte) 100, axisLocation28);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        categoryPlot19.setFixedRangeAxisSpace(axisSpace30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        double double33 = categoryPlot32.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset35 = categoryPlot32.getDataset((int) (byte) 1);
        boolean boolean36 = categoryPlot32.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis38 = categoryPlot32.getRangeAxis(255);
        categoryPlot32.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        double double43 = categoryAxis42.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = categoryAxis42.getTickLabelInsets();
        java.awt.Paint paint45 = categoryAxis42.getTickLabelPaint();
        categoryAxis42.setLowerMargin((-1.0d));
        java.util.List list48 = categoryPlot32.getCategoriesForAxis(categoryAxis42);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font52 = null;
        categoryAxis50.setTickLabelFont((java.lang.Comparable) (-4.0d), font52);
        boolean boolean54 = categoryAxis50.isTickMarksVisible();
        categoryAxis50.setTickMarkInsideLength((float) 6);
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = new org.jfree.chart.axis.CategoryAxis("");
        double double59 = categoryAxis58.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = categoryAxis58.getTickLabelInsets();
        java.awt.Paint paint62 = categoryAxis58.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font63 = categoryAxis58.getLabelFont();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray64 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis42, categoryAxis50, categoryAxis58 };
        categoryPlot19.setDomainAxes(categoryAxisArray64);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent66 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot19);
        xYPlot13.notifyListeners(plotChangeEvent66);
        int int68 = xYPlot13.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str17.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(legendItemCollection25);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNotNull(axisLocation28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.05d + "'", double59 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(font63);
        org.junit.Assert.assertNotNull(categoryAxisArray64);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1 + "'", int68 == 1);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.FOREGROUND;
        org.jfree.chart.plot.XYPlot xYPlot1 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = xYPlot1.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke4 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot1.setDomainCrosshairStroke(stroke4);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = xYPlot1.getRendererForDataset(xYDataset6);
        java.awt.Stroke stroke8 = xYPlot1.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer10 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection11 = xYPlot1.getDomainMarkers(4, layer10);
        boolean boolean12 = layer0.equals((java.lang.Object) xYPlot1);
        java.awt.Color color13 = java.awt.Color.PINK;
        xYPlot1.setRangeZeroBaselinePaint((java.awt.Paint) color13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.image.ColorModel colorModel16 = null;
        java.awt.Rectangle rectangle17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.AffineTransform affineTransform19 = null;
        java.awt.RenderingHints renderingHints20 = null;
        java.awt.PaintContext paintContext21 = color15.createContext(colorModel16, rectangle17, rectangle2D18, affineTransform19, renderingHints20);
        xYPlot1.setRangeGridlinePaint((java.awt.Paint) color15);
        xYPlot1.setDomainCrosshairValue((double) 500);
        org.junit.Assert.assertNotNull(layer0);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(xYItemRenderer7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(layer10);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paintContext21);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone7);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass12 = color11.getClass();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.Class class15 = null;
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone17);
        java.awt.Color color20 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass21 = color20.getClass();
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.lang.Class class24 = null;
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone26);
        java.lang.Class class29 = null;
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date22, timeZone31);
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color35 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass36 = color35.getClass();
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.lang.Class class39 = null;
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date34, timeZone41);
        java.lang.Class class45 = null;
        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date34, timeZone47);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("13-June-2019", timeZone47);
        dateAxis50.configure();
        java.awt.Color color52 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass53 = color52.getClass();
        java.util.Date date54 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day55 = new org.jfree.data.time.Day(date54);
        java.lang.Class class56 = null;
        java.util.Date date57 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone58 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod59 = org.jfree.data.time.RegularTimePeriod.createInstance(class56, date57, timeZone58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date54, timeZone58);
        java.awt.Color color61 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass62 = color61.getClass();
        java.util.Date date63 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day64 = new org.jfree.data.time.Day(date63);
        java.lang.Class class65 = null;
        java.util.Date date66 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone67 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date66, timeZone67);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass62, date63, timeZone67);
        java.lang.Class class70 = null;
        java.util.Date date71 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone72 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod73 = org.jfree.data.time.RegularTimePeriod.createInstance(class70, date71, timeZone72);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date63, timeZone72);
        java.util.Date date75 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color76 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass77 = color76.getClass();
        java.util.Date date78 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day79 = new org.jfree.data.time.Day(date78);
        java.lang.Class class80 = null;
        java.util.Date date81 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone82 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod83 = org.jfree.data.time.RegularTimePeriod.createInstance(class80, date81, timeZone82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass77, date78, timeZone82);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass53, date75, timeZone82);
        org.jfree.data.time.Day day86 = new org.jfree.data.time.Day(date75);
        dateAxis50.setMinimumDate(date75);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(date54);
        org.junit.Assert.assertNotNull(date57);
        org.junit.Assert.assertNotNull(timeZone58);
        org.junit.Assert.assertNull(regularTimePeriod59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertNotNull(wildcardClass62);
        org.junit.Assert.assertNotNull(date63);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(timeZone67);
        org.junit.Assert.assertNull(regularTimePeriod68);
        org.junit.Assert.assertNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertNotNull(timeZone72);
        org.junit.Assert.assertNull(regularTimePeriod73);
        org.junit.Assert.assertNull(regularTimePeriod74);
        org.junit.Assert.assertNotNull(date75);
        org.junit.Assert.assertNotNull(color76);
        org.junit.Assert.assertNotNull(wildcardClass77);
        org.junit.Assert.assertNotNull(date78);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(timeZone82);
        org.junit.Assert.assertNull(regularTimePeriod83);
        org.junit.Assert.assertNull(regularTimePeriod84);
        org.junit.Assert.assertNull(regularTimePeriod85);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis();
        xYPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = xYPlot0.getDatasetRenderingOrder();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = xYPlot0.getAxisOffset();
        double double9 = rectangleInsets7.calculateTopInset((double) 15);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot13.zoomRangeAxes((double) 100.0f, plotRenderingInfo19, point2D20);
        xYPlot13.setRangeCrosshairValue(0.2d, true);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis27.setNegativeArrowVisible(false);
        java.awt.Shape shape30 = numberAxis27.getDownArrow();
        numberAxis27.setUpperMargin((double) 100.0f);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand33 = numberAxis27.getMarkerBand();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        double double36 = categoryAxis35.getLowerMargin();
        java.awt.Color color37 = java.awt.Color.WHITE;
        java.awt.Color color38 = color37.darker();
        categoryAxis35.setTickMarkPaint((java.awt.Paint) color37);
        java.awt.Color color40 = color37.brighter();
        numberAxis27.setTickMarkPaint((java.awt.Paint) color40);
        java.awt.Shape shape42 = numberAxis27.getLeftArrow();
        xYPlot13.setRangeAxis((int) (short) 0, (org.jfree.chart.axis.ValueAxis) numberAxis27, false);
        xYPlot13.clearDomainMarkers();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNull(markerAxisBand33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(shape42);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker18 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = null;
        intervalMarker18.setGradientPaintTransformer(gradientPaintTransformer19);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        double double23 = categoryAxis22.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis22.getTickLabelInsets();
        java.awt.Paint paint26 = categoryAxis22.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font27 = categoryAxis22.getLabelFont();
        intervalMarker18.setLabelFont(font27);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection30 = categoryPlot29.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis31 = categoryPlot29.getRangeAxis();
        java.awt.Stroke stroke32 = categoryPlot29.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        categoryPlot29.setRenderer(2, categoryItemRenderer34);
        java.awt.Stroke stroke36 = categoryPlot29.getOutlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        int int38 = categoryPlot29.getIndexOf(categoryItemRenderer37);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        categoryPlot29.setDomainAxis(6, categoryAxis40, true);
        boolean boolean43 = categoryPlot29.isDomainZoomable();
        org.jfree.chart.plot.IntervalMarker intervalMarker46 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer47 = null;
        intervalMarker46.setGradientPaintTransformer(gradientPaintTransformer47);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        double double51 = categoryAxis50.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = categoryAxis50.getTickLabelInsets();
        java.awt.Paint paint54 = categoryAxis50.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font55 = categoryAxis50.getLabelFont();
        intervalMarker46.setLabelFont(font55);
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double60 = numberAxis59.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis62.setNegativeArrowVisible(false);
        java.awt.Shape shape65 = numberAxis62.getDownArrow();
        numberAxis62.setUpperMargin((double) 100.0f);
        double double68 = numberAxis62.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer69 = null;
        org.jfree.chart.plot.XYPlot xYPlot70 = new org.jfree.chart.plot.XYPlot(xYDataset57, (org.jfree.chart.axis.ValueAxis) numberAxis59, (org.jfree.chart.axis.ValueAxis) numberAxis62, xYItemRenderer69);
        boolean boolean71 = xYPlot70.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = xYPlot70.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace74 = null;
        xYPlot70.setFixedRangeAxisSpace(axisSpace74, false);
        org.jfree.data.xy.XYDataset xYDataset77 = xYPlot70.getDataset();
        org.jfree.chart.plot.XYPlot xYPlot78 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = xYPlot78.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke81 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot78.setDomainCrosshairStroke(stroke81);
        org.jfree.data.xy.XYDataset xYDataset83 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer84 = xYPlot78.getRendererForDataset(xYDataset83);
        java.awt.Stroke stroke85 = xYPlot78.getRangeGridlineStroke();
        org.jfree.chart.util.Layer layer87 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection88 = xYPlot78.getDomainMarkers(4, layer87);
        java.util.Collection collection89 = xYPlot70.getDomainMarkers(layer87);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent90 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) layer87);
        boolean boolean91 = categoryPlot29.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker46, layer87);
        boolean boolean92 = xYPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker18, layer87);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNull(legendItemCollection30);
        org.junit.Assert.assertNull(valueAxis31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.05d + "'", double51 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.05d + "'", double60 == 0.05d);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertNull(xYDataset77);
        org.junit.Assert.assertNotNull(rectangleEdge80);
        org.junit.Assert.assertNotNull(stroke81);
        org.junit.Assert.assertNull(xYItemRenderer84);
        org.junit.Assert.assertNotNull(stroke85);
        org.junit.Assert.assertNotNull(layer87);
        org.junit.Assert.assertNull(collection88);
        org.junit.Assert.assertNull(collection89);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setRangeAboutValue(0.0d, 1.0d);
        numberAxis1.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat11 = numberAxis1.getNumberFormatOverride();
        numberAxis1.setRange((double) '4', (double) 2019);
        org.junit.Assert.assertNull(numberFormat11);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (-16.0d));
        boolean boolean2 = categoryMarker1.getDrawAsLine();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.geom.Point2D point2D15 = xYPlot13.getQuadrantOrigin();
        java.util.List list16 = xYPlot13.getAnnotations();
        int int17 = xYPlot13.getSeriesCount();
        xYPlot13.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(point2D15);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        java.awt.Paint[] paintArray0 = null;
        java.awt.Paint[] paintArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        java.awt.Paint[] paintArray2 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray3 = null;
        java.awt.Paint[] paintArray4 = null;
        java.awt.Stroke stroke5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke6 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke9 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke10 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray11 = new java.awt.Stroke[] { stroke5, stroke6, stroke7, stroke8, stroke9, stroke10 };
        java.awt.Stroke stroke12 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke15 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke16 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray17 = new java.awt.Stroke[] { stroke12, stroke13, stroke14, stroke15, stroke16 };
        java.awt.Shape[] shapeArray18 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray2, paintArray3, paintArray4, strokeArray11, strokeArray17, shapeArray18);
        java.awt.Stroke[] strokeArray20 = null;
        java.awt.Stroke stroke21 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        double double24 = categoryAxis23.getLowerMargin();
        java.awt.Stroke stroke25 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis23.setAxisLineStroke(stroke25);
        java.awt.Stroke[] strokeArray27 = new java.awt.Stroke[] { stroke21, stroke25 };
        java.awt.Shape[] shapeArray28 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray0, paintArray1, paintArray3, strokeArray20, strokeArray27, shapeArray28);
        try {
            java.awt.Stroke stroke30 = defaultDrawingSupplier29.getNextStroke();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paintArray1);
        org.junit.Assert.assertNotNull(paintArray2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(strokeArray11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(strokeArray17);
        org.junit.Assert.assertNotNull(shapeArray18);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(strokeArray27);
        org.junit.Assert.assertNotNull(shapeArray28);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent8 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        try {
            categoryPlot0.setRenderer((-16777216), categoryItemRenderer11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(axisSpace7);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot8.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot8.getRangeAxis();
        java.awt.Stroke stroke11 = categoryPlot8.getRangeGridlineStroke();
        categoryPlot8.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker16 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = null;
        intervalMarker16.setGradientPaintTransformer(gradientPaintTransformer17);
        java.awt.Paint paint19 = intervalMarker16.getLabelPaint();
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean22 = categoryPlot8.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) intervalMarker16, layer20, true);
        org.jfree.chart.text.TextAnchor textAnchor23 = intervalMarker16.getLabelTextAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        double double26 = categoryAxis25.getLowerMargin();
        java.awt.Color color27 = java.awt.Color.WHITE;
        java.awt.Color color28 = color27.darker();
        categoryAxis25.setTickMarkPaint((java.awt.Paint) color27);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        double double31 = categoryPlot30.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset33 = categoryPlot30.getDataset((int) (byte) 1);
        categoryAxis25.setPlot((org.jfree.chart.plot.Plot) categoryPlot30);
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot30.getRowRenderingOrder();
        java.awt.Stroke stroke36 = categoryPlot30.getOutlineStroke();
        java.awt.Font font37 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot30.setNoDataMessageFont(font37);
        intervalMarker16.setLabelFont(font37);
        categoryAxis1.setTickLabelFont((java.lang.Comparable) '4', font37);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(textAnchor23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset33);
        org.junit.Assert.assertNotNull(sortOrder35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(font37);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font3 = categoryAxis2.getLabelFont();
        categoryPlot0.setNoDataMessageFont(font3);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addDomainMarker((int) 'a', categoryMarker7, layer8);
        java.lang.Comparable comparable10 = categoryMarker7.getKey();
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass12 = color11.getClass();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.Class class15 = null;
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone17);
        java.awt.Color color20 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass21 = color20.getClass();
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.lang.Class class24 = null;
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone26);
        java.lang.Class class29 = null;
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date22, timeZone31);
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color35 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass36 = color35.getClass();
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.lang.Class class39 = null;
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date34, timeZone41);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date34);
        categoryMarker7.setKey((java.lang.Comparable) date34);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertTrue("'" + comparable10 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", comparable10.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.plot.IntervalMarker intervalMarker8 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = null;
        intervalMarker8.setGradientPaintTransformer(gradientPaintTransformer9);
        java.awt.Paint paint11 = intervalMarker8.getLabelPaint();
        org.jfree.chart.util.Layer layer12 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean14 = categoryPlot0.removeDomainMarker((int) (byte) 1, (org.jfree.chart.plot.Marker) intervalMarker8, layer12, true);
        org.jfree.chart.text.TextAnchor textAnchor15 = intervalMarker8.getLabelTextAnchor();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        double double18 = categoryAxis17.getLowerMargin();
        java.awt.Color color19 = java.awt.Color.WHITE;
        java.awt.Color color20 = color19.darker();
        categoryAxis17.setTickMarkPaint((java.awt.Paint) color19);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        double double23 = categoryPlot22.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset25 = categoryPlot22.getDataset((int) (byte) 1);
        categoryAxis17.setPlot((org.jfree.chart.plot.Plot) categoryPlot22);
        org.jfree.chart.util.SortOrder sortOrder27 = categoryPlot22.getRowRenderingOrder();
        java.awt.Stroke stroke28 = categoryPlot22.getOutlineStroke();
        java.awt.Font font29 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        categoryPlot22.setNoDataMessageFont(font29);
        intervalMarker8.setLabelFont(font29);
        java.lang.Object obj32 = intervalMarker8.clone();
        java.awt.Paint paint33 = intervalMarker8.getPaint();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(layer12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset25);
        org.junit.Assert.assertNotNull(sortOrder27);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("TextAnchor.BOTTOM_CENTER");
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int2 = color1.getAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        double double4 = categoryPlot3.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset6 = categoryPlot3.getDataset((int) (byte) 1);
        boolean boolean7 = categoryPlot3.isRangeCrosshairVisible();
        java.awt.Paint paint8 = categoryPlot3.getRangeCrosshairPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot9.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot9.getRangeAxis();
        java.awt.Stroke stroke12 = categoryPlot9.getRangeGridlineStroke();
        categoryPlot3.setDomainGridlineStroke(stroke12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double18 = numberAxis17.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis20.setNegativeArrowVisible(false);
        java.awt.Shape shape23 = numberAxis20.getDownArrow();
        numberAxis20.setUpperMargin((double) 100.0f);
        double double26 = numberAxis20.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis20, xYItemRenderer27);
        boolean boolean29 = xYPlot28.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = xYPlot28.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        xYPlot28.setFixedRangeAxisSpace(axisSpace32, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        xYPlot28.setRenderer((int) '#', xYItemRenderer36, true);
        xYPlot28.setRangeZeroBaselineVisible(false);
        java.awt.Stroke stroke41 = xYPlot28.getDomainCrosshairStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker43 = new org.jfree.chart.plot.ValueMarker((double) (-65281), (java.awt.Paint) color1, stroke12, (java.awt.Paint) color14, stroke41, (float) (-16777216));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNull(valueAxis11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        float float5 = intervalMarker2.getAlpha();
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) float5, jFreeChart6, chartChangeEventType7);
        java.lang.String str9 = chartChangeEventType7.toString();
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.8f + "'", float5 == 0.8f);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ChartChangeEventType.NEW_DATASET" + "'", str9.equals("ChartChangeEventType.NEW_DATASET"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone7);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass12 = color11.getClass();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.Class class15 = null;
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone17);
        java.awt.Color color20 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass21 = color20.getClass();
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.lang.Class class24 = null;
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone26);
        java.lang.Class class29 = null;
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date22, timeZone31);
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color35 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass36 = color35.getClass();
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.lang.Class class39 = null;
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date34, timeZone41);
        java.lang.Class class45 = null;
        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date34, timeZone47);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("13-June-2019", timeZone47);
        java.util.Date date51 = dateAxis50.getMaximumDate();
        java.util.Date date52 = dateAxis50.getMaximumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit53 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date54 = dateAxis50.calculateLowestVisibleTickValue(dateTickUnit53);
        dateAxis50.configure();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertNotNull(dateTickUnit53);
        org.junit.Assert.assertNotNull(date54);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot1.getFixedLegendItems();
        java.awt.Image image3 = null;
        categoryPlot1.setBackgroundImage(image3);
        categoryPlot1.clearAnnotations();
        boolean boolean6 = textAnchor0.equals((java.lang.Object) categoryPlot1);
        java.awt.Stroke stroke7 = categoryPlot1.getRangeGridlineStroke();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setAxisLineVisible(false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation4 = categoryPlot0.getDomainAxisLocation(255);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        double double9 = categoryAxis8.getLowerMargin();
        java.awt.Color color10 = java.awt.Color.WHITE;
        java.awt.Color color11 = color10.darker();
        categoryAxis8.setTickMarkPaint((java.awt.Paint) color10);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        double double14 = categoryPlot13.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot13.getDataset((int) (byte) 1);
        categoryAxis8.setPlot((org.jfree.chart.plot.Plot) categoryPlot13);
        org.jfree.chart.util.SortOrder sortOrder18 = categoryPlot13.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot13.setRenderer(categoryItemRenderer19);
        double double21 = categoryPlot13.getRangeCrosshairValue();
        java.awt.Stroke stroke22 = categoryPlot13.getDomainGridlineStroke();
        categoryPlot0.setOutlineStroke(stroke22);
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot();
        xYPlot24.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis29.setNegativeArrowVisible(false);
        java.awt.Shape shape32 = numberAxis29.getDownArrow();
        numberAxis29.setUpperMargin((double) 100.0f);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand35 = numberAxis29.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis37.setNegativeArrowVisible(false);
        org.jfree.data.Range range40 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis37.setRange(range40, true, false);
        numberAxis29.setRangeWithMargins(range40, false, true);
        xYPlot24.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis29, true);
        org.jfree.chart.axis.AxisLocation axisLocation49 = xYPlot24.getRangeAxisLocation();
        categoryPlot0.setDomainAxisLocation(axisLocation49, false);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNull(markerAxisBand35);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(axisLocation49);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        categoryPlot0.setRangeCrosshairValue((double) 10, false);
        java.util.List list7 = categoryPlot0.getCategories();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(list7);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone7);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date0, timeZone7);
        int int11 = day10.getMonth();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        categoryAxis1.setLabelAngle((double) 100);
        boolean boolean7 = categoryAxis1.isTickLabelsVisible();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 0);
        categoryAxis1.setMaximumCategoryLabelLines((int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(categoryItemRenderer12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.data.Range range16 = categoryPlot6.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis15);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNull(range16);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        categoryPlot0.setDomainGridlinesVisible(true);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot0.getRangeAxisLocation((int) '4');
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double18 = numberAxis17.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis20.setNegativeArrowVisible(false);
        java.awt.Shape shape23 = numberAxis20.getDownArrow();
        numberAxis20.setUpperMargin((double) 100.0f);
        double double26 = numberAxis20.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset15, (org.jfree.chart.axis.ValueAxis) numberAxis17, (org.jfree.chart.axis.ValueAxis) numberAxis20, xYItemRenderer27);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str31 = categoryPlot30.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font33 = categoryAxis32.getLabelFont();
        categoryPlot30.setNoDataMessageFont(font33);
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot30.addDomainMarker((int) 'a', categoryMarker37, layer38);
        java.util.Collection collection40 = xYPlot28.getRangeMarkers(3, layer38);
        xYPlot28.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder45 = xYPlot44.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray47 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer46 };
        xYPlot44.setRenderers(xYItemRendererArray47);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = xYPlot44.getRendererForDataset(xYDataset49);
        java.awt.geom.Point2D point2D51 = xYPlot44.getQuadrantOrigin();
        xYPlot28.zoomRangeAxes((double) 100L, plotRenderingInfo43, point2D51);
        categoryPlot0.zoomDomainAxes(100.0d, (double) 1560452399999L, plotRenderingInfo14, point2D51);
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(str31);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertNull(collection40);
        org.junit.Assert.assertNotNull(seriesRenderingOrder45);
        org.junit.Assert.assertNotNull(xYItemRendererArray47);
        org.junit.Assert.assertNull(xYItemRenderer50);
        org.junit.Assert.assertNotNull(point2D51);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot13.zoomRangeAxes((double) 100.0f, plotRenderingInfo19, point2D20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        double double23 = categoryPlot22.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset25 = categoryPlot22.getDataset((int) (byte) 1);
        boolean boolean26 = categoryPlot22.isRangeCrosshairVisible();
        boolean boolean27 = categoryPlot22.isDomainZoomable();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot22.getAxisOffset();
        xYPlot13.setInsets(rectangleInsets28, true);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis33.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource36 = numberAxis33.getStandardTickUnits();
        double double37 = numberAxis33.getLowerBound();
        xYPlot13.setDomainAxis(0, (org.jfree.chart.axis.ValueAxis) numberAxis33);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(tickUnitSource36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis15.setNegativeArrowVisible(false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource18 = numberAxis15.getStandardTickUnits();
        xYPlot13.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis15);
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot20.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke23 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot20.setDomainCrosshairStroke(stroke23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot20.getRendererForDataset(xYDataset25);
        java.awt.Stroke stroke27 = xYPlot20.getRangeGridlineStroke();
        numberAxis15.setTickMarkStroke(stroke27);
        float float29 = numberAxis15.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(tickUnitSource18);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(xYItemRenderer26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + float29 + "' != '" + 2.0f + "'", float29 == 2.0f);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        double double5 = categoryAxis4.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis4.getTickLabelInsets();
        java.awt.Paint paint8 = categoryAxis4.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font9 = categoryAxis4.getLabelFont();
        double double10 = categoryAxis4.getLowerMargin();
        categoryAxis4.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot13.getFixedLegendItems();
        java.awt.Image image15 = null;
        categoryPlot13.setBackgroundImage(image15);
        java.util.List list17 = categoryPlot13.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot13.getDomainAxisEdge();
        boolean boolean19 = categoryAxis4.hasListener((java.util.EventListener) categoryPlot13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent20 = null;
        categoryPlot13.notifyListeners(plotChangeEvent20);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot13.getRangeMarkers(4, layer23);
        categoryPlot13.mapDatasetToDomainAxis((int) (short) 100, (int) (byte) 10);
        boolean boolean28 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot13);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection14);
        org.junit.Assert.assertNull(list17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        intervalMarker10.setGradientPaintTransformer(gradientPaintTransformer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        double double15 = categoryAxis14.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis14.getTickLabelInsets();
        java.awt.Paint paint18 = categoryAxis14.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font19 = categoryAxis14.getLabelFont();
        intervalMarker10.setLabelFont(font19);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10);
        boolean boolean22 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor23);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        java.awt.Paint paint27 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(categoryAnchor23);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        categoryAxis2.addChangeListener(axisChangeListener4);
        categoryAxis2.setLabelAngle((double) 100);
        java.awt.Color color8 = java.awt.Color.WHITE;
        categoryAxis2.setTickMarkPaint((java.awt.Paint) color8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        double double12 = categoryAxis11.getLowerMargin();
        java.awt.Stroke stroke13 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis11.setAxisLineStroke(stroke13);
        java.awt.Color color17 = java.awt.Color.getColor("hi!", 0);
        java.awt.Stroke stroke18 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker20 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color8, stroke13, (java.awt.Paint) color17, stroke18, 0.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        double double23 = categoryAxis22.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis22.getTickLabelInsets();
        double double26 = rectangleInsets24.calculateTopInset((double) 100);
        double double28 = rectangleInsets24.calculateLeftOutset((double) 100.0f);
        valueMarker20.setLabelOffset(rectangleInsets24);
        double double31 = rectangleInsets24.calculateRightOutset(0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.0d + "'", double26 == 2.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 4.0d + "'", double28 == 4.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Color color2 = java.awt.Color.getColor("AxisLocation.TOP_OR_RIGHT", color1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Color color5 = java.awt.Color.BLACK;
        categoryAxis4.setTickLabelPaint((java.awt.Paint) color5);
        int int7 = color5.getAlpha();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        double double10 = categoryAxis9.getLowerMargin();
        java.awt.Paint paint12 = categoryAxis9.getTickLabelPaint((java.lang.Comparable) 'a');
        java.awt.Color color13 = java.awt.Color.MAGENTA;
        categoryAxis9.setTickMarkPaint((java.awt.Paint) color13);
        float[] floatArray21 = new float[] { 1560409200000L, 2.0f, 2.0f, (short) 10, '#', (byte) 10 };
        float[] floatArray22 = color13.getRGBComponents(floatArray21);
        float[] floatArray23 = color5.getColorComponents(floatArray22);
        float[] floatArray24 = color2.getColorComponents(floatArray23);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 255 + "'", int7 == 255);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.lang.Class class4 = null;
        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date2, timeZone6);
        java.awt.Color color9 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass10 = color9.getClass();
        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        java.lang.Class class13 = null;
        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone15);
        java.lang.Class class18 = null;
        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date11, timeZone20);
        java.lang.Class class23 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(timeZone6);
        org.junit.Assert.assertNull(regularTimePeriod7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(timeZone15);
        org.junit.Assert.assertNull(regularTimePeriod16);
        org.junit.Assert.assertNull(regularTimePeriod17);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(timeZone20);
        org.junit.Assert.assertNull(regularTimePeriod21);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(class23);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxis();
        java.awt.Stroke stroke3 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(2, categoryItemRenderer5);
        java.util.List list7 = categoryPlot0.getCategories();
        boolean boolean8 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double14 = numberAxis13.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis16.setNegativeArrowVisible(false);
        java.awt.Shape shape19 = numberAxis16.getDownArrow();
        numberAxis16.setUpperMargin((double) 100.0f);
        double double22 = numberAxis16.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset11, (org.jfree.chart.axis.ValueAxis) numberAxis13, (org.jfree.chart.axis.ValueAxis) numberAxis16, xYItemRenderer23);
        boolean boolean25 = xYPlot24.isDomainCrosshairLockedOnData();
        java.awt.geom.Point2D point2D26 = xYPlot24.getQuadrantOrigin();
        categoryPlot0.zoomRangeAxes((double) 6, plotRenderingInfo10, point2D26, false);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(point2D26);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation15, plotOrientation16);
        xYPlot13.setDomainAxisLocation(11, axisLocation15);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis21.setNegativeArrowVisible(false);
        java.awt.Paint paint24 = numberAxis21.getTickMarkPaint();
        numberAxis21.setUpperBound(10.0d);
        xYPlot13.setDomainAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis21);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis16.setNegativeArrowVisible(false);
        org.jfree.data.Range range19 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis16);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis21.setNegativeArrowVisible(false);
        java.awt.Paint paint24 = numberAxis21.getTickMarkPaint();
        numberAxis21.setUpperBound(10.0d);
        java.lang.String str27 = numberAxis21.getLabelToolTip();
        xYPlot13.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis21);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(str27);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        java.awt.Paint paint5 = intervalMarker2.getLabelPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker2);
        org.jfree.chart.plot.Marker marker7 = markerChangeEvent6.getMarker();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        markerChangeEvent6.setChart(jFreeChart8);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(marker7);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-4.0d), font3);
        boolean boolean5 = categoryAxis1.isTickMarksVisible();
        java.awt.Paint paint6 = categoryAxis1.getLabelPaint();
        categoryAxis1.setUpperMargin((double) 1560409200000L);
        categoryAxis1.clearCategoryLabelToolTips();
        int int10 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getUpperMargin();
        double double3 = numberAxis1.getLowerBound();
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int5 = color4.getAlpha();
        boolean boolean6 = numberAxis1.equals((java.lang.Object) int5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 255 + "'", int5 == 255);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis16.setNegativeArrowVisible(false);
        org.jfree.data.Range range19 = xYPlot13.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis16);
        float float20 = xYPlot13.getForegroundAlpha();
        int int21 = xYPlot13.getSeriesCount();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(range19);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 1.0f + "'", float20 == 1.0f);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.Paint paint15 = xYPlot13.getDomainGridlinePaint();
        xYPlot13.clearRangeMarkers(255);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Color color22 = java.awt.Color.BLACK;
        categoryAxis21.setTickLabelPaint((java.awt.Paint) color22);
        int int24 = color22.getAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        double double26 = categoryPlot25.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot25.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot25.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.data.Range range32 = categoryPlot25.getDataRange(valueAxis31);
        java.awt.Paint paint33 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot25.setNoDataMessagePaint(paint33);
        java.awt.Color color35 = java.awt.Color.blue;
        categoryPlot25.setNoDataMessagePaint((java.awt.Paint) color35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        int int38 = categoryPlot25.getIndexOf(categoryItemRenderer37);
        java.awt.Color color39 = java.awt.Color.darkGray;
        categoryPlot25.setNoDataMessagePaint((java.awt.Paint) color39);
        java.util.List list41 = categoryPlot25.getAnnotations();
        boolean boolean42 = color22.equals((java.lang.Object) list41);
        xYPlot13.drawRangeTickBands(graphics2D18, rectangle2D19, list41);
        int int44 = xYPlot13.getDomainAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection46 = categoryPlot45.getFixedLegendItems();
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        categoryPlot45.drawBackgroundImage(graphics2D47, rectangle2D48);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor50 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str51 = categoryAnchor50.toString();
        categoryPlot45.setDomainGridlinePosition(categoryAnchor50);
        xYPlot13.setParent((org.jfree.chart.plot.Plot) categoryPlot45);
        org.jfree.chart.axis.AxisSpace axisSpace54 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace54);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double59 = numberAxis58.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis61.setNegativeArrowVisible(false);
        java.awt.Shape shape64 = numberAxis61.getDownArrow();
        numberAxis61.setUpperMargin((double) 100.0f);
        double double67 = numberAxis61.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = null;
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.axis.ValueAxis) numberAxis61, xYItemRenderer68);
        org.jfree.chart.axis.AxisLocation axisLocation71 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation72 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation71, plotOrientation72);
        xYPlot69.setDomainAxisLocation(11, axisLocation71);
        org.jfree.chart.plot.IntervalMarker intervalMarker77 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer78 = null;
        intervalMarker77.setGradientPaintTransformer(gradientPaintTransformer78);
        org.jfree.chart.axis.CategoryAxis categoryAxis81 = new org.jfree.chart.axis.CategoryAxis("");
        double double82 = categoryAxis81.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets83 = categoryAxis81.getTickLabelInsets();
        java.awt.Paint paint85 = categoryAxis81.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font86 = categoryAxis81.getLabelFont();
        intervalMarker77.setLabelFont(font86);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor88 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        intervalMarker77.setLabelAnchor(rectangleAnchor88);
        org.jfree.chart.util.Layer layer90 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean91 = xYPlot69.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker77, layer90);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer92 = intervalMarker77.getGradientPaintTransformer();
        boolean boolean93 = xYPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker77);
        xYPlot13.setRangeCrosshairLockedOnData(false);
        java.awt.Color color96 = org.jfree.chart.ChartColor.LIGHT_RED;
        xYPlot13.setOutlinePaint((java.awt.Paint) color96);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNull(legendItemCollection46);
        org.junit.Assert.assertNotNull(categoryAnchor50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "CategoryAnchor.END" + "'", str51.equals("CategoryAnchor.END"));
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.05d + "'", double59 == 0.05d);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertNotNull(plotOrientation72);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.05d + "'", double82 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets83);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(font86);
        org.junit.Assert.assertNotNull(rectangleAnchor88);
        org.junit.Assert.assertNotNull(layer90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNull(gradientPaintTransformer92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(color96);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        categoryAxis1.setLabelAngle((double) 100);
        boolean boolean7 = categoryAxis1.isTickLabelsVisible();
        categoryAxis1.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint11 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 100);
        double double12 = categoryAxis1.getUpperMargin();
        java.awt.Paint paint13 = categoryAxis1.getLabelPaint();
        categoryAxis1.setVisible(true);
        categoryAxis1.setVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        java.util.List list4 = categoryPlot0.getCategories();
        categoryPlot0.setOutlineVisible(false);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot0.setRenderer((int) (byte) 1, categoryItemRenderer8);
        java.awt.Paint paint10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        categoryPlot0.setRangeCrosshairPaint(paint10);
        java.awt.Paint paint12 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        double double17 = categoryAxis16.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener18 = null;
        categoryAxis16.addChangeListener(axisChangeListener18);
        categoryAxis16.setLabelAngle((double) 100);
        java.awt.Color color22 = java.awt.Color.WHITE;
        categoryAxis16.setTickMarkPaint((java.awt.Paint) color22);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        double double26 = categoryAxis25.getLowerMargin();
        java.awt.Stroke stroke27 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis25.setAxisLineStroke(stroke27);
        java.awt.Color color31 = java.awt.Color.getColor("hi!", 0);
        java.awt.Stroke stroke32 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color22, stroke27, (java.awt.Paint) color31, stroke32, 0.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        double double37 = categoryAxis36.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = categoryAxis36.getTickLabelInsets();
        double double40 = rectangleInsets38.calculateTopInset((double) 100);
        double double42 = rectangleInsets38.calculateLeftOutset((double) 100.0f);
        valueMarker34.setLabelOffset(rectangleInsets38);
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder45 = xYPlot44.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray47 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer46 };
        xYPlot44.setRenderers(xYItemRendererArray47);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = xYPlot44.getRendererForDataset(xYDataset49);
        java.awt.geom.Point2D point2D51 = xYPlot44.getQuadrantOrigin();
        org.jfree.data.xy.XYDataset xYDataset52 = null;
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double55 = numberAxis54.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis57.setNegativeArrowVisible(false);
        java.awt.Shape shape60 = numberAxis57.getDownArrow();
        numberAxis57.setUpperMargin((double) 100.0f);
        double double63 = numberAxis57.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer64 = null;
        org.jfree.chart.plot.XYPlot xYPlot65 = new org.jfree.chart.plot.XYPlot(xYDataset52, (org.jfree.chart.axis.ValueAxis) numberAxis54, (org.jfree.chart.axis.ValueAxis) numberAxis57, xYItemRenderer64);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str68 = categoryPlot67.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis69 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font70 = categoryAxis69.getLabelFont();
        categoryPlot67.setNoDataMessageFont(font70);
        org.jfree.chart.plot.CategoryMarker categoryMarker74 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer75 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot67.addDomainMarker((int) 'a', categoryMarker74, layer75);
        java.util.Collection collection77 = xYPlot65.getRangeMarkers(3, layer75);
        java.util.Collection collection78 = xYPlot44.getDomainMarkers(layer75);
        boolean boolean80 = categoryPlot0.removeRangeMarker(5, (org.jfree.chart.plot.Marker) valueMarker34, layer75, true);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(list4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.05d + "'", double26 == 0.05d);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 2.0d + "'", double40 == 2.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 4.0d + "'", double42 == 4.0d);
        org.junit.Assert.assertNotNull(seriesRenderingOrder45);
        org.junit.Assert.assertNotNull(xYItemRendererArray47);
        org.junit.Assert.assertNull(xYItemRenderer50);
        org.junit.Assert.assertNotNull(point2D51);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.05d + "'", double55 == 0.05d);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNull(str68);
        org.junit.Assert.assertNotNull(font70);
        org.junit.Assert.assertNotNull(layer75);
        org.junit.Assert.assertNull(collection77);
        org.junit.Assert.assertNull(collection78);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis2.setNegativeArrowVisible(false);
        java.awt.Paint paint5 = numberAxis2.getTickMarkPaint();
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint5, stroke6, (java.awt.Paint) color7, stroke8, (float) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = valueMarker10.getLabelOffset();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) valueMarker10);
        org.jfree.chart.plot.Marker marker13 = markerChangeEvent12.getMarker();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(marker13);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-4.0d), font3);
        boolean boolean5 = categoryAxis1.isTickMarksVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis1.getLabelInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        double double10 = categoryAxis9.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener11 = null;
        categoryAxis9.addChangeListener(axisChangeListener11);
        categoryAxis9.setLabelAngle((double) 100);
        java.awt.Color color15 = java.awt.Color.WHITE;
        categoryAxis9.setTickMarkPaint((java.awt.Paint) color15);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        double double19 = categoryAxis18.getLowerMargin();
        java.awt.Stroke stroke20 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryAxis18.setAxisLineStroke(stroke20);
        java.awt.Color color24 = java.awt.Color.getColor("hi!", 0);
        java.awt.Stroke stroke25 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((-1.0d), (java.awt.Paint) color15, stroke20, (java.awt.Paint) color24, stroke25, 0.0f);
        boolean boolean28 = categoryAxis1.equals((java.lang.Object) stroke25);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        double double30 = categoryPlot29.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot29.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = categoryPlot29.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot29.getRangeAxisEdge();
        java.awt.Image image36 = categoryPlot29.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker39 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer40 = null;
        intervalMarker39.setGradientPaintTransformer(gradientPaintTransformer40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("");
        double double44 = categoryAxis43.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = categoryAxis43.getTickLabelInsets();
        java.awt.Paint paint47 = categoryAxis43.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font48 = categoryAxis43.getLabelFont();
        intervalMarker39.setLabelFont(font48);
        categoryPlot29.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker39);
        boolean boolean51 = categoryPlot29.isRangeCrosshairLockedOnData();
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        categoryPlot29.setDataset(6, categoryDataset53);
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot29);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation56 = null;
        try {
            boolean boolean58 = categoryPlot29.removeAnnotation(categoryAnnotation56, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.05d + "'", double19 == 0.05d);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertNull(categoryAxis34);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNull(image36);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.05d + "'", double44 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        boolean boolean17 = categoryPlot6.render(graphics2D13, rectangle2D14, 8, plotRenderingInfo16);
        int int18 = categoryPlot6.getRangeAxisCount();
        categoryPlot6.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        java.util.List list6 = categoryPlot0.getCategories();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation7, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(list6);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font3 = categoryAxis2.getLabelFont();
        categoryPlot0.setNoDataMessageFont(font3);
        org.jfree.chart.plot.CategoryMarker categoryMarker7 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer8 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addDomainMarker((int) 'a', categoryMarker7, layer8);
        java.awt.Paint paint10 = categoryMarker7.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        double double13 = categoryAxis12.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis12.getTickLabelInsets();
        java.awt.Paint paint16 = categoryAxis12.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font17 = categoryAxis12.getLabelFont();
        double double18 = categoryAxis12.getLowerMargin();
        categoryAxis12.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot21.getFixedLegendItems();
        java.awt.Image image23 = null;
        categoryPlot21.setBackgroundImage(image23);
        java.util.List list25 = categoryPlot21.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot21.getDomainAxisEdge();
        boolean boolean27 = categoryAxis12.hasListener((java.util.EventListener) categoryPlot21);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis29.setNegativeArrowVisible(false);
        categoryPlot21.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis29);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        numberAxis29.setTickLabelPaint((java.awt.Paint) color33);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis36.setNegativeArrowVisible(false);
        java.awt.Shape shape39 = numberAxis36.getDownArrow();
        numberAxis36.setUpperMargin((double) 100.0f);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand42 = numberAxis36.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis44.setNegativeArrowVisible(false);
        org.jfree.data.Range range47 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis44.setRange(range47, true, false);
        numberAxis36.setRangeWithMargins(range47, false, true);
        numberAxis29.setRangeWithMargins(range47);
        numberAxis29.setRangeAboutValue((double) 2, (double) '4');
        double double58 = numberAxis29.getAutoRangeMinimumSize();
        boolean boolean59 = categoryMarker7.equals((java.lang.Object) double58);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(layer8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.05d + "'", double18 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertNull(list25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNull(markerAxisBand42);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0E-8d + "'", double58 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.jfree.chart.axis.AxisLocation axisLocation2 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(axisLocation2);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener4 = null;
        categoryAxis2.addChangeListener(axisChangeListener4);
        categoryAxis2.setLabelAngle((double) 100);
        boolean boolean8 = categoryAxis2.isTickLabelsVisible();
        categoryAxis2.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint12 = categoryAxis2.getTickLabelPaint((java.lang.Comparable) 100);
        java.awt.Stroke stroke13 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryAxis2.setAxisLineStroke(stroke13);
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder16 = xYPlot15.getSeriesRenderingOrder();
        org.jfree.chart.plot.IntervalMarker intervalMarker19 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        xYPlot15.addDomainMarker((org.jfree.chart.plot.Marker) intervalMarker19);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis22.setNegativeArrowVisible(false);
        java.awt.Shape shape25 = numberAxis22.getDownArrow();
        boolean boolean26 = numberAxis22.isVerticalTickLabels();
        org.jfree.chart.plot.Plot plot27 = numberAxis22.getPlot();
        int int28 = xYPlot15.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis22);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis22, categoryItemRenderer29);
        categoryAxis2.setMaximumCategoryLabelLines((int) '4');
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(seriesRenderingOrder16);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(plot27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test303");
//        java.awt.Color color1 = java.awt.Color.MAGENTA;
//        java.lang.Class<?> wildcardClass2 = color1.getClass();
//        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
//        java.lang.Class class5 = null;
//        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone7);
//        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
//        java.awt.Color color11 = java.awt.Color.MAGENTA;
//        java.lang.Class<?> wildcardClass12 = color11.getClass();
//        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
//        java.lang.Class class15 = null;
//        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone17);
//        java.awt.Color color20 = java.awt.Color.MAGENTA;
//        java.lang.Class<?> wildcardClass21 = color20.getClass();
//        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
//        java.lang.Class class24 = null;
//        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone26);
//        java.lang.Class class29 = null;
//        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date22, timeZone31);
//        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.Color color35 = java.awt.Color.MAGENTA;
//        java.lang.Class<?> wildcardClass36 = color35.getClass();
//        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
//        java.lang.Class class39 = null;
//        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone41);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date34, timeZone41);
//        java.lang.Class class45 = null;
//        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date34, timeZone47);
//        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("13-June-2019", timeZone47);
//        dateAxis50.configure();
//        java.util.Date date52 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date52);
//        long long54 = day53.getFirstMillisecond();
//        int int55 = day53.getMonth();
//        java.util.Date date56 = day53.getEnd();
//        dateAxis50.setMaximumDate(date56);
//        java.awt.geom.Rectangle2D rectangle2D59 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot();
//        double double61 = categoryPlot60.getAnchorValue();
//        org.jfree.data.category.CategoryDataset categoryDataset63 = categoryPlot60.getDataset((int) (byte) 1);
//        org.jfree.chart.axis.CategoryAxis categoryAxis65 = categoryPlot60.getDomainAxisForDataset(100);
//        org.jfree.chart.util.RectangleEdge rectangleEdge66 = categoryPlot60.getRangeAxisEdge();
//        try {
//            double double67 = dateAxis50.java2DToValue((double) (byte) 0, rectangle2D59, rectangleEdge66);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(color1);
//        org.junit.Assert.assertNotNull(wildcardClass2);
//        org.junit.Assert.assertNotNull(date3);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertNotNull(timeZone7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNull(regularTimePeriod9);
//        org.junit.Assert.assertNotNull(class10);
//        org.junit.Assert.assertNotNull(color11);
//        org.junit.Assert.assertNotNull(wildcardClass12);
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(timeZone17);
//        org.junit.Assert.assertNull(regularTimePeriod18);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertNotNull(color20);
//        org.junit.Assert.assertNotNull(wildcardClass21);
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date25);
//        org.junit.Assert.assertNotNull(timeZone26);
//        org.junit.Assert.assertNull(regularTimePeriod27);
//        org.junit.Assert.assertNull(regularTimePeriod28);
//        org.junit.Assert.assertNotNull(date30);
//        org.junit.Assert.assertNotNull(timeZone31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertNotNull(color35);
//        org.junit.Assert.assertNotNull(wildcardClass36);
//        org.junit.Assert.assertNotNull(date37);
//        org.junit.Assert.assertNotNull(date40);
//        org.junit.Assert.assertNotNull(timeZone41);
//        org.junit.Assert.assertNull(regularTimePeriod42);
//        org.junit.Assert.assertNull(regularTimePeriod43);
//        org.junit.Assert.assertNull(regularTimePeriod44);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertNotNull(regularTimePeriod49);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1560409200000L + "'", long54 == 1560409200000L);
//        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
//        org.junit.Assert.assertNotNull(date56);
//        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
//        org.junit.Assert.assertNull(categoryDataset63);
//        org.junit.Assert.assertNull(categoryAxis65);
//        org.junit.Assert.assertNotNull(rectangleEdge66);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone7);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass12 = color11.getClass();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.Class class15 = null;
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone17);
        java.awt.Color color20 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass21 = color20.getClass();
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.lang.Class class24 = null;
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone26);
        java.lang.Class class29 = null;
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date22, timeZone31);
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color35 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass36 = color35.getClass();
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.lang.Class class39 = null;
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date34, timeZone41);
        java.lang.Class class45 = null;
        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date34, timeZone47);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("13-June-2019", timeZone47);
        dateAxis50.configure();
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray54 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer53 };
        categoryPlot52.setRenderers(categoryItemRendererArray54);
        categoryPlot52.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        categoryPlot52.setDataset(categoryDataset58);
        java.awt.Paint paint60 = categoryPlot52.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset61 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = categoryPlot52.getRendererForDataset(categoryDataset61);
        int int63 = categoryPlot52.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis("");
        double double66 = categoryAxis65.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener67 = null;
        categoryAxis65.addChangeListener(axisChangeListener67);
        categoryAxis65.setLabelAngle((double) 100);
        boolean boolean71 = categoryAxis65.isTickLabelsVisible();
        categoryAxis65.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint75 = categoryAxis65.getTickLabelPaint((java.lang.Comparable) 100);
        double double76 = categoryAxis65.getUpperMargin();
        double double77 = categoryAxis65.getLowerMargin();
        int int78 = categoryPlot52.getDomainAxisIndex(categoryAxis65);
        boolean boolean79 = dateAxis50.equals((java.lang.Object) categoryAxis65);
        org.jfree.chart.axis.DateTickUnit dateTickUnit80 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis50.setTickUnit(dateTickUnit80, false, false);
        org.jfree.chart.axis.DateTickUnit dateTickUnit84 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis50.setTickUnit(dateTickUnit84);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(categoryItemRendererArray54);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNull(categoryItemRenderer62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.05d + "'", double66 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
        org.junit.Assert.assertNotNull(paint75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.05d + "'", double76 == 0.05d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.05d + "'", double77 == 0.05d);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1) + "'", int78 == (-1));
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(dateTickUnit80);
        org.junit.Assert.assertNotNull(dateTickUnit84);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setAutoRange(false);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int9 = color8.getAlpha();
        numberAxis1.setLabelPaint((java.awt.Paint) color8);
        java.awt.Color color11 = color8.darker();
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        categoryPlot6.setRenderer(categoryItemRenderer12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        int int15 = categoryPlot6.getIndexOf(categoryItemRenderer14);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot6.getRangeAxisEdge();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        java.util.List list4 = categoryPlot0.getCategories();
        categoryPlot0.setOutlineVisible(false);
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(list4);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        double double4 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setTickMarksVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis();
        xYPlot0.clearRangeMarkers((int) ' ');
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder6 = xYPlot0.getDatasetRenderingOrder();
        xYPlot0.clearRangeMarkers((int) (short) 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(valueAxis3);
        org.junit.Assert.assertNotNull(datasetRenderingOrder6);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot13.zoomRangeAxes((double) 100.0f, plotRenderingInfo19, point2D20);
        java.awt.Paint paint22 = xYPlot13.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot13.getRangeAxisLocation(1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(axisLocation24);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font8 = categoryAxis7.getLabelFont();
        categoryPlot0.setDomainAxis(categoryAxis7);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis7.getTickLabelInsets();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot13.zoomRangeAxes((double) 100.0f, plotRenderingInfo19, point2D20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        org.jfree.chart.plot.CrosshairState crosshairState26 = null;
        boolean boolean27 = xYPlot13.render(graphics2D22, rectangle2D23, 1, plotRenderingInfo25, crosshairState26);
        boolean boolean28 = xYPlot13.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.Paint paint15 = xYPlot13.getDomainGridlinePaint();
        xYPlot13.clearRangeMarkers(255);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Color color22 = java.awt.Color.BLACK;
        categoryAxis21.setTickLabelPaint((java.awt.Paint) color22);
        int int24 = color22.getAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        double double26 = categoryPlot25.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot25.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot25.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.data.Range range32 = categoryPlot25.getDataRange(valueAxis31);
        java.awt.Paint paint33 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot25.setNoDataMessagePaint(paint33);
        java.awt.Color color35 = java.awt.Color.blue;
        categoryPlot25.setNoDataMessagePaint((java.awt.Paint) color35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        int int38 = categoryPlot25.getIndexOf(categoryItemRenderer37);
        java.awt.Color color39 = java.awt.Color.darkGray;
        categoryPlot25.setNoDataMessagePaint((java.awt.Paint) color39);
        java.util.List list41 = categoryPlot25.getAnnotations();
        boolean boolean42 = color22.equals((java.lang.Object) list41);
        xYPlot13.drawRangeTickBands(graphics2D18, rectangle2D19, list41);
        int int44 = xYPlot13.getDomainAxisCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection46 = categoryPlot45.getFixedLegendItems();
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        categoryPlot45.drawBackgroundImage(graphics2D47, rectangle2D48);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor50 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str51 = categoryAnchor50.toString();
        categoryPlot45.setDomainGridlinePosition(categoryAnchor50);
        xYPlot13.setParent((org.jfree.chart.plot.Plot) categoryPlot45);
        org.jfree.chart.axis.AxisSpace axisSpace54 = null;
        xYPlot13.setFixedDomainAxisSpace(axisSpace54);
        org.jfree.data.xy.XYDataset xYDataset56 = null;
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double59 = numberAxis58.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis61 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis61.setNegativeArrowVisible(false);
        java.awt.Shape shape64 = numberAxis61.getDownArrow();
        numberAxis61.setUpperMargin((double) 100.0f);
        double double67 = numberAxis61.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = null;
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot(xYDataset56, (org.jfree.chart.axis.ValueAxis) numberAxis58, (org.jfree.chart.axis.ValueAxis) numberAxis61, xYItemRenderer68);
        org.jfree.chart.axis.AxisLocation axisLocation71 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation72 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation71, plotOrientation72);
        xYPlot69.setDomainAxisLocation(11, axisLocation71);
        org.jfree.chart.plot.IntervalMarker intervalMarker77 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer78 = null;
        intervalMarker77.setGradientPaintTransformer(gradientPaintTransformer78);
        org.jfree.chart.axis.CategoryAxis categoryAxis81 = new org.jfree.chart.axis.CategoryAxis("");
        double double82 = categoryAxis81.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets83 = categoryAxis81.getTickLabelInsets();
        java.awt.Paint paint85 = categoryAxis81.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font86 = categoryAxis81.getLabelFont();
        intervalMarker77.setLabelFont(font86);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor88 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        intervalMarker77.setLabelAnchor(rectangleAnchor88);
        org.jfree.chart.util.Layer layer90 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean91 = xYPlot69.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker77, layer90);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer92 = intervalMarker77.getGradientPaintTransformer();
        boolean boolean93 = xYPlot13.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker77);
        int int94 = xYPlot13.getWeight();
        int int95 = xYPlot13.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNull(legendItemCollection46);
        org.junit.Assert.assertNotNull(categoryAnchor50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "CategoryAnchor.END" + "'", str51.equals("CategoryAnchor.END"));
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.05d + "'", double59 == 0.05d);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertNotNull(plotOrientation72);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.05d + "'", double82 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets83);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNotNull(font86);
        org.junit.Assert.assertNotNull(rectangleAnchor88);
        org.junit.Assert.assertNotNull(layer90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNull(gradientPaintTransformer92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 1 + "'", int94 == 1);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1 + "'", int95 == 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot8.getFixedLegendItems();
        java.awt.Image image10 = null;
        categoryPlot8.setBackgroundImage(image10);
        java.util.List list12 = categoryPlot8.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot8.getDomainAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            org.jfree.chart.axis.AxisState axisState15 = categoryAxis1.draw(graphics2D4, (double) (-16777216), rectangle2D6, rectangle2D7, rectangleEdge13, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertNull(list12);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.Paint paint15 = xYPlot13.getDomainGridlinePaint();
        xYPlot13.clearRangeMarkers(255);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Color color22 = java.awt.Color.BLACK;
        categoryAxis21.setTickLabelPaint((java.awt.Paint) color22);
        int int24 = color22.getAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        double double26 = categoryPlot25.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot25.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot25.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.data.Range range32 = categoryPlot25.getDataRange(valueAxis31);
        java.awt.Paint paint33 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot25.setNoDataMessagePaint(paint33);
        java.awt.Color color35 = java.awt.Color.blue;
        categoryPlot25.setNoDataMessagePaint((java.awt.Paint) color35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        int int38 = categoryPlot25.getIndexOf(categoryItemRenderer37);
        java.awt.Color color39 = java.awt.Color.darkGray;
        categoryPlot25.setNoDataMessagePaint((java.awt.Paint) color39);
        java.util.List list41 = categoryPlot25.getAnnotations();
        boolean boolean42 = color22.equals((java.lang.Object) list41);
        xYPlot13.drawRangeTickBands(graphics2D18, rectangle2D19, list41);
        int int44 = xYPlot13.getDomainAxisCount();
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer48 = null;
        intervalMarker47.setGradientPaintTransformer(gradientPaintTransformer48);
        java.awt.Paint paint50 = intervalMarker47.getLabelPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent51 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker47);
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        double double53 = categoryPlot52.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset55 = categoryPlot52.getDataset((int) (byte) 1);
        boolean boolean56 = categoryPlot52.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis58 = categoryPlot52.getRangeAxis(255);
        categoryPlot52.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        double double63 = categoryAxis62.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = categoryAxis62.getTickLabelInsets();
        java.awt.Paint paint65 = categoryAxis62.getTickLabelPaint();
        categoryAxis62.setLowerMargin((-1.0d));
        java.util.List list68 = categoryPlot52.getCategoriesForAxis(categoryAxis62);
        intervalMarker47.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot52);
        xYPlot13.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker47);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer71 = null;
        int int72 = xYPlot13.getIndexOf(xYItemRenderer71);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(valueAxis58);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.05d + "'", double63 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(list68);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        java.awt.Paint paint13 = categoryPlot6.getNoDataMessagePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot6.getLegendItems();
        categoryPlot6.setAnchorValue((double) 1, false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(legendItemCollection14);
    }

//    @Test
//    public void test318() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test318");
//        java.awt.Color color0 = java.awt.Color.MAGENTA;
//        java.lang.Class<?> wildcardClass1 = color0.getClass();
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        java.lang.Class class4 = null;
//        java.util.Date date5 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone6 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = org.jfree.data.time.RegularTimePeriod.createInstance(class4, date5, timeZone6);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date2, timeZone6);
//        java.awt.Color color9 = java.awt.Color.MAGENTA;
//        java.lang.Class<?> wildcardClass10 = color9.getClass();
//        java.util.Date date11 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
//        java.lang.Class class13 = null;
//        java.util.Date date14 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone15 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = org.jfree.data.time.RegularTimePeriod.createInstance(class13, date14, timeZone15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass10, date11, timeZone15);
//        java.lang.Class class18 = null;
//        java.util.Date date19 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone20 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = org.jfree.data.time.RegularTimePeriod.createInstance(class18, date19, timeZone20);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date11, timeZone20);
//        java.util.Date date23 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.awt.Color color24 = java.awt.Color.MAGENTA;
//        java.lang.Class<?> wildcardClass25 = color24.getClass();
//        java.util.Date date26 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
//        java.lang.Class class28 = null;
//        java.util.Date date29 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        java.util.TimeZone timeZone30 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = org.jfree.data.time.RegularTimePeriod.createInstance(class28, date29, timeZone30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass25, date26, timeZone30);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass1, date23, timeZone30);
//        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date23);
//        long long35 = day34.getSerialIndex();
//        java.lang.String str36 = day34.toString();
//        java.util.Calendar calendar37 = null;
//        try {
//            long long38 = day34.getMiddleMillisecond(calendar37);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(color0);
//        org.junit.Assert.assertNotNull(wildcardClass1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(date5);
//        org.junit.Assert.assertNotNull(timeZone6);
//        org.junit.Assert.assertNull(regularTimePeriod7);
//        org.junit.Assert.assertNull(regularTimePeriod8);
//        org.junit.Assert.assertNotNull(color9);
//        org.junit.Assert.assertNotNull(wildcardClass10);
//        org.junit.Assert.assertNotNull(date11);
//        org.junit.Assert.assertNotNull(date14);
//        org.junit.Assert.assertNotNull(timeZone15);
//        org.junit.Assert.assertNull(regularTimePeriod16);
//        org.junit.Assert.assertNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(date19);
//        org.junit.Assert.assertNotNull(timeZone20);
//        org.junit.Assert.assertNull(regularTimePeriod21);
//        org.junit.Assert.assertNull(regularTimePeriod22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(color24);
//        org.junit.Assert.assertNotNull(wildcardClass25);
//        org.junit.Assert.assertNotNull(date26);
//        org.junit.Assert.assertNotNull(date29);
//        org.junit.Assert.assertNotNull(timeZone30);
//        org.junit.Assert.assertNull(regularTimePeriod31);
//        org.junit.Assert.assertNull(regularTimePeriod32);
//        org.junit.Assert.assertNull(regularTimePeriod33);
//        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 43629L + "'", long35 == 43629L);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "13-June-2019" + "'", str36.equals("13-June-2019"));
//    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        categoryAxis1.setLabelAngle((double) 100);
        boolean boolean7 = categoryAxis1.isTickLabelsVisible();
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 0);
        categoryAxis1.setLowerMargin((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        java.awt.Font font12 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        intervalMarker10.setGradientPaintTransformer(gradientPaintTransformer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        double double15 = categoryAxis14.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis14.getTickLabelInsets();
        java.awt.Paint paint18 = categoryAxis14.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font19 = categoryAxis14.getLabelFont();
        intervalMarker10.setLabelFont(font19);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10);
        boolean boolean22 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        categoryPlot0.setDataset(6, categoryDataset24);
        float float26 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = null;
        categoryAxis1.setTickLabelFont((java.lang.Comparable) (-4.0d), font3);
        boolean boolean5 = categoryAxis1.isTickMarksVisible();
        java.awt.Paint paint6 = categoryAxis1.getLabelPaint();
        categoryAxis1.setUpperMargin((double) 1560409200000L);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        double double10 = categoryPlot9.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot9.getDataset((int) (byte) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryPlot9.setAxisOffset(rectangleInsets13);
        categoryAxis1.setLabelInsets(rectangleInsets13);
        categoryAxis1.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertNotNull(rectangleInsets13);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis15.setNegativeArrowVisible(false);
        java.awt.Shape shape18 = numberAxis15.getDownArrow();
        double double19 = numberAxis15.getUpperBound();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis21.setNegativeArrowVisible(false);
        java.awt.Shape shape24 = numberAxis21.getDownArrow();
        numberAxis21.setUpperMargin((double) 100.0f);
        java.text.NumberFormat numberFormat27 = numberAxis21.getNumberFormatOverride();
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis29.setNegativeArrowVisible(false);
        java.awt.Paint paint32 = numberAxis29.getTickMarkPaint();
        org.jfree.data.Range range33 = numberAxis29.getRange();
        numberAxis21.setDefaultAutoRange(range33);
        numberAxis15.setRangeWithMargins(range33, true, true);
        numberAxis5.setRangeWithMargins(range33, false, false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNull(numberFormat27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(range33);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getAutoRangeMinimumSize();
        java.awt.Shape shape3 = numberAxis1.getUpArrow();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-8d + "'", double2 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint4 = categoryAxis1.getTickLabelPaint();
        categoryAxis1.setLowerMargin((-1.0d));
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot10.getRangeAxisEdge((int) (short) 100);
        try {
            double double13 = categoryAxis1.getCategoryMiddle((-1), (int) (byte) 100, rectangle2D9, rectangleEdge12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        double double5 = numberAxis1.getUpperBound();
        numberAxis1.centerRange((double) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot8.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot8.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot8.getDomainAxisLocation(255);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot8.getDomainAxis();
        java.awt.Paint paint14 = categoryPlot8.getRangeGridlinePaint();
        numberAxis1.setTickLabelPaint(paint14);
        numberAxis1.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener3 = null;
        categoryAxis1.addChangeListener(axisChangeListener3);
        categoryAxis1.setLabelAngle((double) 100);
        boolean boolean7 = categoryAxis1.isTickLabelsVisible();
        categoryAxis1.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint11 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 100);
        double double12 = categoryAxis1.getUpperMargin();
        double double13 = categoryAxis1.getLowerMargin();
        categoryAxis1.setLabel("SeriesRenderingOrder.FORWARD");
        categoryAxis1.setLowerMargin((double) (short) 10);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.axis.AxisLocation axisLocation21 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation21, plotOrientation22);
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation24, plotOrientation25);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation21, plotOrientation25);
        try {
            double double28 = categoryAxis1.getCategoryEnd(0, 11, rectangle2D20, rectangleEdge27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.05d + "'", double12 == 0.05d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.05d + "'", double13 == 0.05d);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot13.zoomRangeAxes((double) 100.0f, plotRenderingInfo19, point2D20);
        xYPlot13.setRangeCrosshairValue(0.2d, true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray26 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer25 };
        xYPlot13.setRenderers(xYItemRendererArray26);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder28 = xYPlot13.getSeriesRenderingOrder();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(xYItemRendererArray26);
        org.junit.Assert.assertNotNull(seriesRenderingOrder28);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        xYPlot0.setDomainCrosshairStroke(stroke3);
        xYPlot0.clearDomainAxes();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        xYPlot0.setRangeCrosshairPaint((java.awt.Paint) color6);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        xYPlot0.setRenderer(xYItemRenderer9);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        categoryPlot0.setRenderer(categoryItemRenderer4, true);
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font3 = categoryAxis2.getLabelFont();
        categoryPlot0.setNoDataMessageFont(font3);
        categoryPlot0.configureRangeAxes();
        int int6 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        double double10 = categoryPlot9.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot9.getDataset((int) (byte) 1);
        boolean boolean13 = categoryPlot9.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis15 = categoryPlot9.getRangeAxis(255);
        categoryPlot9.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot9.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str26 = categoryPlot25.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font28 = categoryAxis27.getLabelFont();
        categoryPlot25.setNoDataMessageFont(font28);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot25.addDomainMarker((int) 'a', categoryMarker32, layer33);
        categoryPlot9.addDomainMarker(categoryMarker24, layer33);
        boolean boolean36 = categoryMarker24.getDrawAsLine();
        org.jfree.chart.util.Layer layer37 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean39 = categoryPlot0.removeRangeMarker(7, (org.jfree.chart.plot.Marker) categoryMarker24, layer37, false);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(valueAxis15);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(layer37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone7);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass12 = color11.getClass();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.Class class15 = null;
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone17);
        java.awt.Color color20 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass21 = color20.getClass();
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.lang.Class class24 = null;
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone26);
        java.lang.Class class29 = null;
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date22, timeZone31);
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color35 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass36 = color35.getClass();
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.lang.Class class39 = null;
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date34, timeZone41);
        java.lang.Class class45 = null;
        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date34, timeZone47);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("13-June-2019", timeZone47);
        dateAxis50.configure();
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis53.setNegativeArrowVisible(false);
        org.jfree.data.Range range56 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis53.setRange(range56, true, false);
        dateAxis50.setRange(range56, false, true);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition63 = null;
        try {
            dateAxis50.setTickMarkPosition(dateTickMarkPosition63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(range56);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart13);
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.axis.AxisSpace axisSpace16 = categoryPlot6.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(axisSpace16);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        java.util.List list4 = categoryPlot0.getCategories();
        categoryPlot0.setOutlineVisible(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer10 = null;
        intervalMarker9.setGradientPaintTransformer(gradientPaintTransformer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        double double14 = categoryAxis13.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryAxis13.getTickLabelInsets();
        java.awt.Paint paint17 = categoryAxis13.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font18 = categoryAxis13.getLabelFont();
        intervalMarker9.setLabelFont(font18);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        intervalMarker9.setLabelAnchor(rectangleAnchor20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str23 = categoryPlot22.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font25 = categoryAxis24.getLabelFont();
        categoryPlot22.setNoDataMessageFont(font25);
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer30 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot22.addDomainMarker((int) 'a', categoryMarker29, layer30);
        boolean boolean32 = rectangleAnchor20.equals((java.lang.Object) categoryMarker29);
        boolean boolean33 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker29);
        java.awt.Stroke stroke34 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        categoryPlot0.setOutlineStroke(stroke34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = categoryPlot0.getDomainAxisForDataset((int) (short) -1);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(list4);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(layer30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(categoryAxis37);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder1 = xYPlot0.getSeriesRenderingOrder();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray3 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer2 };
        xYPlot0.setRenderers(xYItemRendererArray3);
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = xYPlot0.getRendererForDataset(xYDataset5);
        java.awt.geom.Point2D point2D7 = xYPlot0.getQuadrantOrigin();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double11 = numberAxis10.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis13.setNegativeArrowVisible(false);
        java.awt.Shape shape16 = numberAxis13.getDownArrow();
        numberAxis13.setUpperMargin((double) 100.0f);
        double double19 = numberAxis13.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis10, (org.jfree.chart.axis.ValueAxis) numberAxis13, xYItemRenderer20);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str24 = categoryPlot23.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font26 = categoryAxis25.getLabelFont();
        categoryPlot23.setNoDataMessageFont(font26);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot23.addDomainMarker((int) 'a', categoryMarker30, layer31);
        java.util.Collection collection33 = xYPlot21.getRangeMarkers(3, layer31);
        java.util.Collection collection34 = xYPlot0.getDomainMarkers(layer31);
        java.awt.Color color36 = java.awt.Color.GREEN;
        java.awt.Color color37 = java.awt.Color.getColor("UnitType.RELATIVE", color36);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color36);
        java.awt.Color color39 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int40 = color39.getAlpha();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        double double43 = categoryAxis42.getLowerMargin();
        java.awt.Paint paint45 = categoryAxis42.getTickLabelPaint((java.lang.Comparable) 'a');
        java.awt.Color color46 = java.awt.Color.MAGENTA;
        categoryAxis42.setTickMarkPaint((java.awt.Paint) color46);
        float[] floatArray54 = new float[] { 1560409200000L, 2.0f, 2.0f, (short) 10, '#', (byte) 10 };
        float[] floatArray55 = color46.getRGBComponents(floatArray54);
        float[] floatArray56 = color39.getRGBColorComponents(floatArray55);
        xYPlot0.setOutlinePaint((java.awt.Paint) color39);
        org.junit.Assert.assertNotNull(seriesRenderingOrder1);
        org.junit.Assert.assertNotNull(xYItemRendererArray3);
        org.junit.Assert.assertNull(xYItemRenderer6);
        org.junit.Assert.assertNotNull(point2D7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNull(str24);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertNull(collection34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 255 + "'", int40 == 255);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(floatArray54);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray56);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        double double2 = categoryPlot1.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset4 = categoryPlot1.getDataset((int) (byte) 1);
        boolean boolean5 = categoryPlot1.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot1.getRangeAxis(255);
        categoryPlot1.setRangeCrosshairValue(0.0d);
        java.awt.Paint paint10 = categoryPlot1.getNoDataMessagePaint();
        boolean boolean11 = defaultDrawingSupplier0.equals((java.lang.Object) paint10);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) boolean11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(valueAxis7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        categoryPlot0.setAnchorValue((-16.0d), false);
        double double7 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation(4);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        double double3 = categoryAxis2.getLowerMargin();
        java.awt.Color color4 = java.awt.Color.WHITE;
        java.awt.Color color5 = color4.darker();
        categoryAxis2.setTickMarkPaint((java.awt.Paint) color4);
        java.awt.Color color7 = color4.brighter();
        int int8 = color7.getAlpha();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis10.setNegativeArrowVisible(false);
        numberAxis10.setVerticalTickLabels(false);
        numberAxis10.setAutoRange(false);
        java.awt.Stroke stroke17 = numberAxis10.getTickMarkStroke();
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color7, stroke17);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        categoryPlot0.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str10 = categoryPlot9.getNoDataMessage();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        int int12 = categoryPlot9.getIndexOf(categoryItemRenderer11);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = null;
        categoryPlot9.datasetChanged(datasetChangeEvent13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot9.zoomRangeAxes(0.0d, plotRenderingInfo16, point2D17, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        boolean boolean22 = categoryPlot9.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker21);
        categoryPlot0.addDomainMarker(categoryMarker21);
        java.lang.Comparable comparable24 = categoryMarker21.getKey();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType25 = categoryMarker21.getLabelOffsetType();
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", comparable24.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(lengthAdjustmentType25);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        xYPlot13.clearAnnotations();
        boolean boolean19 = xYPlot13.isDomainZoomable();
        boolean boolean20 = xYPlot13.isDomainCrosshairVisible();
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_RED;
        xYPlot13.setRangeZeroBaselinePaint((java.awt.Paint) color21);
        int int23 = color21.getBlue();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        xYPlot13.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        xYPlot13.zoomDomainAxes((double) (-65281), (double) (short) 1, plotRenderingInfo29, point2D30);
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis33.setNegativeArrowVisible(false);
        org.jfree.data.Range range36 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis33.setRange(range36, true, false);
        numberAxis33.resizeRange((-9.0d), (double) 'a');
        numberAxis33.setPositiveArrowVisible(false);
        xYPlot13.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis33);
        xYPlot13.setDomainCrosshairValue((double) 1560409200000L, false);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(range36);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        numberAxis1.setUpperMargin((double) 100.0f);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand7 = numberAxis1.getMarkerBand();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        double double10 = categoryAxis9.getLowerMargin();
        java.awt.Color color11 = java.awt.Color.WHITE;
        java.awt.Color color12 = color11.darker();
        categoryAxis9.setTickMarkPaint((java.awt.Paint) color11);
        java.awt.Color color14 = color11.brighter();
        numberAxis1.setTickMarkPaint((java.awt.Paint) color14);
        numberAxis1.setUpperMargin((double) (-1));
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNull(markerAxisBand7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis18.setNegativeArrowVisible(false);
        categoryPlot10.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis18);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        numberAxis18.setTickLabelPaint((java.awt.Paint) color22);
        java.text.NumberFormat numberFormat24 = null;
        numberAxis18.setNumberFormatOverride(numberFormat24);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        double double29 = categoryPlot28.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot28.getDataset((int) (byte) 1);
        boolean boolean32 = categoryPlot28.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis34 = categoryPlot28.getRangeAxis(255);
        categoryPlot28.setRangeCrosshairValue(0.0d);
        java.awt.Paint paint37 = categoryPlot28.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation38 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation39 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation38, plotOrientation39);
        categoryPlot28.setOrientation(plotOrientation39);
        java.awt.Paint[] paintArray42 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        java.awt.Paint[] paintArray43 = null;
        java.awt.Paint[] paintArray44 = null;
        java.awt.Stroke stroke45 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke46 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke47 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke48 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke49 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke50 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke[] strokeArray51 = new java.awt.Stroke[] { stroke45, stroke46, stroke47, stroke48, stroke49, stroke50 };
        java.awt.Stroke stroke52 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke53 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        java.awt.Stroke stroke54 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke stroke55 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Stroke stroke56 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Stroke[] strokeArray57 = new java.awt.Stroke[] { stroke52, stroke53, stroke54, stroke55, stroke56 };
        java.awt.Shape[] shapeArray58 = new java.awt.Shape[] {};
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier59 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray42, paintArray43, paintArray44, strokeArray51, strokeArray57, shapeArray58);
        java.awt.Stroke stroke60 = defaultDrawingSupplier59.getNextOutlineStroke();
        categoryPlot28.setRangeGridlineStroke(stroke60);
        java.awt.Paint paint62 = categoryPlot28.getRangeGridlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot();
        double double64 = categoryPlot63.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset66 = categoryPlot63.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis68 = categoryPlot63.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis69 = null;
        org.jfree.data.Range range70 = categoryPlot63.getDataRange(valueAxis69);
        java.awt.Paint paint71 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot63.setNoDataMessagePaint(paint71);
        java.awt.Color color73 = java.awt.Color.blue;
        categoryPlot63.setNoDataMessagePaint((java.awt.Paint) color73);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer75 = null;
        int int76 = categoryPlot63.getIndexOf(categoryItemRenderer75);
        java.awt.Color color77 = java.awt.Color.darkGray;
        categoryPlot63.setNoDataMessagePaint((java.awt.Paint) color77);
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = new org.jfree.chart.axis.CategoryAxis("");
        double double81 = categoryAxis80.getLowerMargin();
        java.awt.Color color82 = java.awt.Color.WHITE;
        java.awt.Color color83 = color82.darker();
        categoryAxis80.setTickMarkPaint((java.awt.Paint) color82);
        org.jfree.chart.plot.CategoryPlot categoryPlot85 = new org.jfree.chart.plot.CategoryPlot();
        double double86 = categoryPlot85.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset88 = categoryPlot85.getDataset((int) (byte) 1);
        categoryAxis80.setPlot((org.jfree.chart.plot.Plot) categoryPlot85);
        org.jfree.chart.util.SortOrder sortOrder90 = categoryPlot85.getRowRenderingOrder();
        categoryPlot63.setRowRenderingOrder(sortOrder90);
        categoryPlot28.setRowRenderingOrder(sortOrder90);
        org.jfree.chart.util.RectangleEdge rectangleEdge94 = categoryPlot28.getDomainAxisEdge((int) 'a');
        try {
            double double95 = numberAxis18.valueToJava2D((double) 12, rectangle2D27, rectangleEdge94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(valueAxis34);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNotNull(plotOrientation39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(paintArray42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(strokeArray51);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(strokeArray57);
        org.junit.Assert.assertNotNull(shapeArray58);
        org.junit.Assert.assertNotNull(stroke60);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset66);
        org.junit.Assert.assertNull(categoryAxis68);
        org.junit.Assert.assertNull(range70);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.05d + "'", double81 == 0.05d);
        org.junit.Assert.assertNotNull(color82);
        org.junit.Assert.assertNotNull(color83);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset88);
        org.junit.Assert.assertNotNull(sortOrder90);
        org.junit.Assert.assertNotNull(rectangleEdge94);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation2 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation1, plotOrientation2);
        org.jfree.chart.axis.AxisLocation axisLocation4 = axisLocation1.getOpposite();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        boolean boolean6 = axisLocation4.equals((java.lang.Object) categoryAxis5);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double9 = numberAxis8.getUpperMargin();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand10 = numberAxis8.getMarkerBand();
        org.jfree.chart.axis.TickUnitSource tickUnitSource11 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis8.setStandardTickUnits(tickUnitSource11);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis5, (org.jfree.chart.axis.ValueAxis) numberAxis8, categoryItemRenderer13);
        numberAxis8.setUpperMargin(2.0d);
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertNotNull(plotOrientation2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(axisLocation4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertNull(markerAxisBand10);
        org.junit.Assert.assertNotNull(tickUnitSource11);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.Image image2 = null;
        categoryPlot0.setBackgroundImage(image2);
        java.util.List list4 = categoryPlot0.getCategories();
        categoryPlot0.setOutlineVisible(false);
        java.awt.Stroke stroke7 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(list4);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        numberAxis1.setUpperMargin((double) 100.0f);
        double double7 = numberAxis1.getFixedDimension();
        numberAxis1.setTickMarkInsideLength(0.0f);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis11.setNegativeArrowVisible(false);
        java.awt.Shape shape14 = numberAxis11.getDownArrow();
        numberAxis1.setRightArrow(shape14);
        numberAxis1.setRangeAboutValue((double) 100L, 0.0d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot13.setFixedRangeAxisSpace(axisSpace17, false);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        xYPlot13.setRenderer((int) '#', xYItemRenderer21, true);
        xYPlot13.setRangeZeroBaselineVisible(false);
        xYPlot13.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font3 = categoryAxis2.getLabelFont();
        categoryPlot0.setNoDataMessageFont(font3);
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNull(axisSpace6);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.data.Range range7 = categoryPlot0.getDataRange(valueAxis6);
        java.awt.Paint paint8 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot0.setNoDataMessagePaint(paint8);
        java.awt.Color color10 = java.awt.Color.blue;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        int int13 = categoryPlot0.getIndexOf(categoryItemRenderer12);
        java.awt.Color color14 = java.awt.Color.darkGray;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color14);
        boolean boolean16 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double23 = numberAxis22.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis25.setNegativeArrowVisible(false);
        java.awt.Shape shape28 = numberAxis25.getDownArrow();
        numberAxis25.setUpperMargin((double) 100.0f);
        double double31 = numberAxis25.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset20, (org.jfree.chart.axis.ValueAxis) numberAxis22, (org.jfree.chart.axis.ValueAxis) numberAxis25, xYItemRenderer32);
        boolean boolean34 = xYPlot33.isDomainCrosshairLockedOnData();
        java.awt.geom.Point2D point2D35 = xYPlot33.getQuadrantOrigin();
        categoryPlot0.zoomRangeAxes(0.0d, (double) 12, plotRenderingInfo19, point2D35);
        int int37 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNull(range7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setRangeAboutValue(0.0d, 1.0d);
        numberAxis1.setAutoRangeStickyZero(false);
        numberAxis1.setUpperBound((double) (short) 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        java.awt.Paint paint8 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRendererForDataset(categoryDataset9);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent11 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent11);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer16 = null;
        intervalMarker15.setGradientPaintTransformer(gradientPaintTransformer16);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("");
        double double20 = categoryAxis19.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = categoryAxis19.getTickLabelInsets();
        java.awt.Paint paint23 = categoryAxis19.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font24 = categoryAxis19.getLabelFont();
        intervalMarker15.setLabelFont(font24);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        intervalMarker15.setLabelAnchor(rectangleAnchor26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str29 = categoryPlot28.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font31 = categoryAxis30.getLabelFont();
        categoryPlot28.setNoDataMessageFont(font31);
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot28.addDomainMarker((int) 'a', categoryMarker35, layer36);
        boolean boolean38 = rectangleAnchor26.equals((java.lang.Object) categoryMarker35);
        categoryMarker35.setDrawAsLine(true);
        boolean boolean41 = categoryPlot0.equals((java.lang.Object) true);
        org.jfree.chart.plot.CategoryMarker categoryMarker43 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        boolean boolean44 = categoryMarker43.getDrawAsLine();
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double48 = numberAxis47.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis50.setNegativeArrowVisible(false);
        java.awt.Shape shape53 = numberAxis50.getDownArrow();
        numberAxis50.setUpperMargin((double) 100.0f);
        double double56 = numberAxis50.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer57 = null;
        org.jfree.chart.plot.XYPlot xYPlot58 = new org.jfree.chart.plot.XYPlot(xYDataset45, (org.jfree.chart.axis.ValueAxis) numberAxis47, (org.jfree.chart.axis.ValueAxis) numberAxis50, xYItemRenderer57);
        xYPlot58.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = xYPlot58.getRangeAxisEdge(11);
        org.jfree.chart.axis.NumberAxis numberAxis66 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis66.setNegativeArrowVisible(false);
        java.awt.Paint paint69 = numberAxis66.getTickMarkPaint();
        java.awt.Stroke stroke70 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color71 = org.jfree.chart.ChartColor.DARK_YELLOW;
        java.awt.Stroke stroke72 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        org.jfree.chart.plot.ValueMarker valueMarker74 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint69, stroke70, (java.awt.Paint) color71, stroke72, (float) (byte) 1);
        org.jfree.chart.util.Layer layer75 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean77 = xYPlot58.removeDomainMarker(3, (org.jfree.chart.plot.Marker) valueMarker74, layer75, true);
        boolean boolean78 = categoryPlot0.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker43, layer75);
        org.jfree.chart.plot.CategoryPlot categoryPlot79 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer80 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray81 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer80 };
        categoryPlot79.setRenderers(categoryItemRendererArray81);
        categoryPlot79.setRangeCrosshairVisible(true);
        java.awt.Graphics2D graphics2D85 = null;
        java.awt.geom.Rectangle2D rectangle2D86 = null;
        categoryPlot79.drawBackgroundImage(graphics2D85, rectangle2D86);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent88 = null;
        categoryPlot79.axisChanged(axisChangeEvent88);
        org.jfree.chart.LegendItemCollection legendItemCollection90 = categoryPlot79.getLegendItems();
        categoryPlot0.setFixedLegendItems(legendItemCollection90);
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(rectangleAnchor26);
        org.junit.Assert.assertNull(str29);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(layer36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.05d + "'", double48 == 0.05d);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(color71);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertNotNull(layer75);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererArray81);
        org.junit.Assert.assertNotNull(legendItemCollection90);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Paint paint4 = numberAxis1.getTickMarkPaint();
        org.jfree.data.Range range5 = numberAxis1.getRange();
        boolean boolean6 = numberAxis1.isAutoRange();
        boolean boolean7 = numberAxis1.isTickMarksVisible();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        java.awt.Image image7 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.plot.IntervalMarker intervalMarker10 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = null;
        intervalMarker10.setGradientPaintTransformer(gradientPaintTransformer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        double double15 = categoryAxis14.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis14.getTickLabelInsets();
        java.awt.Paint paint18 = categoryAxis14.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font19 = categoryAxis14.getLabelFont();
        intervalMarker10.setLabelFont(font19);
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker10);
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = categoryPlot0.getOrientation();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(image7);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.05d + "'", double15 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(plotOrientation22);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        org.jfree.chart.plot.Plot plot2 = categoryAxis0.getPlot();
        java.lang.Object obj3 = categoryAxis0.clone();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.centerRange(1.0d);
        numberAxis5.setLabelToolTip("");
        java.awt.Font font10 = numberAxis5.getLabelFont();
        org.jfree.data.RangeType rangeType11 = numberAxis5.getRangeType();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot12.getFixedLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis14 = categoryPlot12.getRangeAxis();
        java.awt.Stroke stroke15 = categoryPlot12.getRangeGridlineStroke();
        categoryPlot12.setRangeCrosshairValue((double) 10, false);
        java.awt.Font font19 = categoryPlot12.getNoDataMessageFont();
        numberAxis5.setTickLabelFont(font19);
        categoryAxis0.setTickLabelFont(font19);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(plot2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(rangeType11);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getAutoRangeMinimumSize();
        java.awt.Shape shape4 = numberAxis2.getDownArrow();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double7 = numberAxis6.getAutoRangeMinimumSize();
        java.awt.Shape shape8 = numberAxis6.getDownArrow();
        boolean boolean9 = numberAxis6.getAutoRangeStickyZero();
        double double10 = numberAxis6.getFixedDimension();
        numberAxis6.setLabelToolTip("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis6, xYItemRenderer13);
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis16.setNegativeArrowVisible(false);
        numberAxis16.setVerticalTickLabels(false);
        numberAxis16.setRangeAboutValue(0.0d, 1.0d);
        numberAxis16.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat26 = null;
        numberAxis16.setNumberFormatOverride(numberFormat26);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis16.setTickUnit(numberTickUnit28, true, false);
        numberAxis2.setTickUnit(numberTickUnit28, true, true);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-8d + "'", double3 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0E-8d + "'", double7 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit28);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getNoDataMessage();
        boolean boolean2 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj5 = categoryAxis4.clone();
        try {
            categoryPlot0.setDomainAxis((-65281), categoryAxis4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        java.awt.Color color6 = color3.brighter();
        java.awt.Color color7 = java.awt.Color.red;
        java.lang.String str8 = color7.toString();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double11 = numberAxis10.getUpperMargin();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand12 = numberAxis10.getMarkerBand();
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_BLUE;
        int int14 = color13.getAlpha();
        numberAxis10.setTickMarkPaint((java.awt.Paint) color13);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Color color18 = java.awt.Color.BLACK;
        categoryAxis17.setTickLabelPaint((java.awt.Paint) color18);
        int int20 = color18.getAlpha();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        double double23 = categoryAxis22.getLowerMargin();
        java.awt.Paint paint25 = categoryAxis22.getTickLabelPaint((java.lang.Comparable) 'a');
        java.awt.Color color26 = java.awt.Color.MAGENTA;
        categoryAxis22.setTickMarkPaint((java.awt.Paint) color26);
        float[] floatArray34 = new float[] { 1560409200000L, 2.0f, 2.0f, (short) 10, '#', (byte) 10 };
        float[] floatArray35 = color26.getRGBComponents(floatArray34);
        float[] floatArray36 = color18.getColorComponents(floatArray35);
        float[] floatArray37 = color13.getRGBColorComponents(floatArray36);
        float[] floatArray38 = color7.getComponents(floatArray36);
        float[] floatArray39 = color6.getRGBColorComponents(floatArray36);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=255,g=0,b=0]" + "'", str8.equals("java.awt.Color[r=255,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNull(markerAxisBand12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 255 + "'", int14 == 255);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 255 + "'", int20 == 255);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(floatArray34);
        org.junit.Assert.assertNotNull(floatArray35);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
        org.junit.Assert.assertNotNull(floatArray38);
        org.junit.Assert.assertNotNull(floatArray39);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        xYPlot13.setRangeGridlinesVisible(false);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot13.getRangeAxisEdge(11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        xYPlot13.zoomRangeAxes((double) 100.0f, plotRenderingInfo19, point2D20);
        xYPlot13.setRangeCrosshairValue(0.2d, true);
        xYPlot13.zoom(0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        java.awt.Paint paint8 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRendererForDataset(categoryDataset9);
        int int11 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        double double14 = categoryAxis13.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener15 = null;
        categoryAxis13.addChangeListener(axisChangeListener15);
        categoryAxis13.setLabelAngle((double) 100);
        boolean boolean19 = categoryAxis13.isTickLabelsVisible();
        categoryAxis13.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint23 = categoryAxis13.getTickLabelPaint((java.lang.Comparable) 100);
        double double24 = categoryAxis13.getUpperMargin();
        double double25 = categoryAxis13.getLowerMargin();
        int int26 = categoryPlot0.getDomainAxisIndex(categoryAxis13);
        java.awt.Paint paint27 = categoryPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.05d + "'", double25 == 0.05d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = numberAxis5.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis13.setNegativeArrowVisible(false);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis13.setRange(range16, true, false);
        numberAxis5.setRangeWithMargins(range16, false, true);
        xYPlot0.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        org.jfree.chart.axis.AxisLocation axisLocation25 = xYPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        double double28 = categoryAxis27.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener29 = null;
        categoryAxis27.addChangeListener(axisChangeListener29);
        categoryAxis27.setLabelAngle((double) 100);
        boolean boolean33 = categoryAxis27.isTickLabelsVisible();
        categoryAxis27.setTickMarkInsideLength((float) 10L);
        java.awt.Paint paint37 = categoryAxis27.getTickLabelPaint((java.lang.Comparable) 100);
        double double38 = categoryAxis27.getUpperMargin();
        double double39 = categoryAxis27.getLowerMargin();
        categoryAxis27.setAxisLineVisible(true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier42 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape43 = defaultDrawingSupplier42.getNextShape();
        boolean boolean44 = categoryAxis27.equals((java.lang.Object) defaultDrawingSupplier42);
        java.awt.Stroke stroke45 = defaultDrawingSupplier42.getNextOutlineStroke();
        xYPlot0.setDomainZeroBaselineStroke(stroke45);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis48.setNegativeArrowVisible(false);
        numberAxis48.setVerticalTickLabels(false);
        numberAxis48.setAutoRange(false);
        java.awt.Stroke stroke55 = numberAxis48.getTickMarkStroke();
        xYPlot0.setRangeCrosshairStroke(stroke55);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(markerAxisBand11);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.05d + "'", double28 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.05d + "'", double38 == 0.05d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.05d + "'", double39 == 0.05d);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str16 = categoryPlot15.getNoDataMessage();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryPlot15.setNoDataMessageFont(font18);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) "PlotOrientation.HORIZONTAL");
        org.jfree.chart.util.Layer layer23 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot15.addDomainMarker((int) 'a', categoryMarker22, layer23);
        java.util.Collection collection25 = xYPlot13.getRangeMarkers(3, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = xYPlot13.getRangeAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        double double28 = categoryPlot27.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset30 = categoryPlot27.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = categoryPlot27.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.data.Range range34 = categoryPlot27.getDataRange(valueAxis33);
        java.awt.Paint paint35 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot27.setNoDataMessagePaint(paint35);
        java.awt.Color color37 = java.awt.Color.blue;
        categoryPlot27.setNoDataMessagePaint((java.awt.Paint) color37);
        xYPlot13.setDomainTickBandPaint((java.awt.Paint) color37);
        java.awt.Stroke stroke40 = xYPlot13.getDomainGridlineStroke();
        java.awt.Stroke stroke41 = xYPlot13.getRangeCrosshairStroke();
        java.awt.Paint paint42 = xYPlot13.getDomainCrosshairPaint();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(layer23);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset30);
        org.junit.Assert.assertNull(categoryAxis32);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double4 = numberAxis3.getAutoRangeMinimumSize();
        java.awt.Shape shape5 = numberAxis3.getUpArrow();
        numberAxis1.setDownArrow(shape5);
        numberAxis1.setVisible(false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-8d + "'", double4 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer1 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray2 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer1 };
        categoryPlot0.setRenderers(categoryItemRendererArray2);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        categoryPlot0.setDataset(categoryDataset6);
        java.awt.Paint paint8 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot0.getRendererForDataset(categoryDataset9);
        int int11 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        double double14 = categoryAxis13.getLowerMargin();
        org.jfree.chart.event.AxisChangeListener axisChangeListener15 = null;
        categoryAxis13.addChangeListener(axisChangeListener15);
        categoryAxis13.setLabelAngle((double) 100);
        boolean boolean19 = categoryAxis13.isTickLabelsVisible();
        categoryAxis13.setTickMarkInsideLength((float) 10L);
        int int22 = categoryPlot0.getDomainAxisIndex(categoryAxis13);
        boolean boolean23 = categoryAxis13.isTickMarksVisible();
        org.junit.Assert.assertNotNull(categoryItemRendererArray2);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.05d + "'", double14 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = color3.darker();
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot6);
        org.jfree.chart.util.SortOrder sortOrder11 = categoryPlot6.getRowRenderingOrder();
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getRangeAxisLocation();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryPlot6, jFreeChart13);
        categoryPlot6.clearRangeAxes();
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis17.setNegativeArrowVisible(false);
        java.awt.Paint paint20 = numberAxis17.getTickMarkPaint();
        org.jfree.data.Range range21 = numberAxis17.getRange();
        categoryPlot6.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis17);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertNotNull(sortOrder11);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(range21);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.lang.Object obj1 = categoryAxis0.clone();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        java.lang.String str3 = categoryAxis0.getLabelURL();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis3 = xYPlot0.getRangeAxis();
        xYPlot0.setRangeZeroBaselineVisible(false);
        xYPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNull(valueAxis3);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.Paint paint15 = xYPlot13.getDomainGridlinePaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        xYPlot13.setRenderer(255, xYItemRenderer17);
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        xYPlot19.setRenderer(xYItemRenderer20);
        java.awt.Paint paint22 = xYPlot19.getRangeZeroBaselinePaint();
        xYPlot13.setDomainZeroBaselinePaint(paint22);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setRangeCrosshairValue(0.0d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomDomainAxes((double) 10, plotRenderingInfo10, point2D11);
        boolean boolean13 = categoryPlot0.isRangeCrosshairVisible();
        categoryPlot0.clearRangeMarkers(4);
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxisForDataset(100);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Font font8 = categoryAxis7.getLabelFont();
        categoryPlot0.setDomainAxis(categoryAxis7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("13-June-2019");
        java.lang.Object obj2 = categoryAxis1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setRangeAboutValue(0.0d, 1.0d);
        numberAxis1.setAutoRangeStickyZero(false);
        java.text.NumberFormat numberFormat11 = null;
        numberAxis1.setNumberFormatOverride(numberFormat11);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit13, true, false);
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = numberAxis1.getStandardTickUnits();
        org.junit.Assert.assertNotNull(numberTickUnit13);
        org.junit.Assert.assertNotNull(tickUnitSource17);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.lang.String str1 = categoryPlot0.getNoDataMessage();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer2 = null;
        int int3 = categoryPlot0.getIndexOf(categoryItemRenderer2);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent4 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent4);
        org.jfree.chart.util.UnitType unitType6 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = new org.jfree.chart.util.RectangleInsets(unitType6, (double) 11, 0.2d, (double) (-16777216), (double) (-16777216));
        categoryPlot0.setInsets(rectangleInsets11);
        org.junit.Assert.assertNull(str1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(unitType6);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getAutoRangeMinimumSize();
        java.awt.Shape shape3 = numberAxis1.getDownArrow();
        boolean boolean4 = numberAxis1.getAutoRangeStickyZero();
        double double5 = numberAxis1.getFixedDimension();
        numberAxis1.setLabelToolTip("");
        boolean boolean8 = numberAxis1.isTickMarksVisible();
        double double9 = numberAxis1.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-8d + "'", double2 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = null;
        dateAxis0.setDateFormatOverride(dateFormat1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        org.jfree.chart.axis.TickUnitSource tickUnitSource5 = numberAxis1.getStandardTickUnits();
        boolean boolean6 = numberAxis1.isAutoRange();
        numberAxis1.setLowerBound((double) '#');
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(tickUnitSource5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.IntervalMarker intervalMarker5 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = null;
        intervalMarker5.setGradientPaintTransformer(gradientPaintTransformer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = intervalMarker5.getLabelOffset();
        java.lang.Object obj9 = intervalMarker5.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        double double11 = categoryPlot10.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset13 = categoryPlot10.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = categoryPlot10.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.Range range17 = categoryPlot10.getDataRange(valueAxis16);
        java.awt.Paint paint18 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot10.setNoDataMessagePaint(paint18);
        java.awt.Color color20 = java.awt.Color.blue;
        categoryPlot10.setNoDataMessagePaint((java.awt.Paint) color20);
        intervalMarker5.setOutlinePaint((java.awt.Paint) color20);
        xYPlot0.setRangeGridlinePaint((java.awt.Paint) color20);
        java.awt.Image image24 = xYPlot0.getBackgroundImage();
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset13);
        org.junit.Assert.assertNull(categoryAxis15);
        org.junit.Assert.assertNull(range17);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(image24);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        xYPlot0.clearDomainMarkers(2019);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = xYPlot0.getRangeAxisEdge((int) (short) 100);
        xYPlot0.clearDomainMarkers();
        java.awt.Graphics2D graphics2D4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        double double7 = categoryPlot6.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot6.getDataset((int) (byte) 1);
        boolean boolean10 = categoryPlot6.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot6.getRangeAxis(255);
        categoryPlot6.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        double double17 = categoryAxis16.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryAxis16.getTickLabelInsets();
        java.awt.Paint paint19 = categoryAxis16.getTickLabelPaint();
        categoryAxis16.setLowerMargin((-1.0d));
        java.util.List list22 = categoryPlot6.getCategoriesForAxis(categoryAxis16);
        xYPlot0.drawRangeTickBands(graphics2D4, rectangle2D5, list22);
        xYPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.ChartColor chartColor29 = new org.jfree.chart.ChartColor(0, (int) 'a', 1);
        xYPlot0.setRangeTickBandPaint((java.awt.Paint) chartColor29);
        java.awt.Stroke stroke31 = xYPlot0.getDomainCrosshairStroke();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double35 = numberAxis34.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis37.setNegativeArrowVisible(false);
        java.awt.Shape shape40 = numberAxis37.getDownArrow();
        numberAxis37.setUpperMargin((double) 100.0f);
        double double43 = numberAxis37.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset32, (org.jfree.chart.axis.ValueAxis) numberAxis34, (org.jfree.chart.axis.ValueAxis) numberAxis37, xYItemRenderer44);
        boolean boolean46 = xYPlot45.isDomainCrosshairLockedOnData();
        java.awt.geom.Point2D point2D47 = xYPlot45.getQuadrantOrigin();
        xYPlot0.setQuadrantOrigin(point2D47);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.05d + "'", double35 == 0.05d);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(point2D47);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.awt.Color color1 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass2 = color1.getClass();
        java.util.Date date3 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        java.lang.Class class5 = null;
        java.util.Date date6 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone7 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = org.jfree.data.time.RegularTimePeriod.createInstance(class5, date6, timeZone7);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass2, date3, timeZone7);
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass2);
        java.awt.Color color11 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass12 = color11.getClass();
        java.util.Date date13 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        java.lang.Class class15 = null;
        java.util.Date date16 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class15, date16, timeZone17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date13, timeZone17);
        java.awt.Color color20 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass21 = color20.getClass();
        java.util.Date date22 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        java.lang.Class class24 = null;
        java.util.Date date25 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone26 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = org.jfree.data.time.RegularTimePeriod.createInstance(class24, date25, timeZone26);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass21, date22, timeZone26);
        java.lang.Class class29 = null;
        java.util.Date date30 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone31 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = org.jfree.data.time.RegularTimePeriod.createInstance(class29, date30, timeZone31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date22, timeZone31);
        java.util.Date date34 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.awt.Color color35 = java.awt.Color.MAGENTA;
        java.lang.Class<?> wildcardClass36 = color35.getClass();
        java.util.Date date37 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        java.lang.Class class39 = null;
        java.util.Date date40 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class39, date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass36, date37, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass12, date34, timeZone41);
        java.lang.Class class45 = null;
        java.util.Date date46 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date46, timeZone47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = org.jfree.data.time.RegularTimePeriod.createInstance(class10, date34, timeZone47);
        org.jfree.chart.axis.DateAxis dateAxis50 = new org.jfree.chart.axis.DateAxis("13-June-2019", timeZone47);
        java.util.Date date51 = dateAxis50.getMaximumDate();
        org.jfree.chart.axis.Timeline timeline52 = dateAxis50.getTimeline();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(timeZone7);
        org.junit.Assert.assertNull(regularTimePeriod8);
        org.junit.Assert.assertNull(regularTimePeriod9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(timeZone26);
        org.junit.Assert.assertNull(regularTimePeriod27);
        org.junit.Assert.assertNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeZone31);
        org.junit.Assert.assertNull(regularTimePeriod32);
        org.junit.Assert.assertNull(regularTimePeriod33);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNull(regularTimePeriod43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertNotNull(timeZone47);
        org.junit.Assert.assertNull(regularTimePeriod48);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertNotNull(timeline52);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        java.awt.Paint paint15 = xYPlot13.getDomainGridlinePaint();
        xYPlot13.clearRangeMarkers(255);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Color color22 = java.awt.Color.BLACK;
        categoryAxis21.setTickLabelPaint((java.awt.Paint) color22);
        int int24 = color22.getAlpha();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        double double26 = categoryPlot25.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot25.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot25.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.data.Range range32 = categoryPlot25.getDataRange(valueAxis31);
        java.awt.Paint paint33 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot25.setNoDataMessagePaint(paint33);
        java.awt.Color color35 = java.awt.Color.blue;
        categoryPlot25.setNoDataMessagePaint((java.awt.Paint) color35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        int int38 = categoryPlot25.getIndexOf(categoryItemRenderer37);
        java.awt.Color color39 = java.awt.Color.darkGray;
        categoryPlot25.setNoDataMessagePaint((java.awt.Paint) color39);
        java.util.List list41 = categoryPlot25.getAnnotations();
        boolean boolean42 = color22.equals((java.lang.Object) list41);
        xYPlot13.drawRangeTickBands(graphics2D18, rectangle2D19, list41);
        int int44 = xYPlot13.getDomainAxisCount();
        org.jfree.chart.plot.IntervalMarker intervalMarker47 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer48 = null;
        intervalMarker47.setGradientPaintTransformer(gradientPaintTransformer48);
        java.awt.Paint paint50 = intervalMarker47.getLabelPaint();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent51 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker47);
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot();
        double double53 = categoryPlot52.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset55 = categoryPlot52.getDataset((int) (byte) 1);
        boolean boolean56 = categoryPlot52.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis58 = categoryPlot52.getRangeAxis(255);
        categoryPlot52.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        double double63 = categoryAxis62.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets64 = categoryAxis62.getTickLabelInsets();
        java.awt.Paint paint65 = categoryAxis62.getTickLabelPaint();
        categoryAxis62.setLowerMargin((-1.0d));
        java.util.List list68 = categoryPlot52.getCategoriesForAxis(categoryAxis62);
        intervalMarker47.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot52);
        xYPlot13.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker47);
        boolean boolean71 = xYPlot13.isDomainZoomable();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertNull(range32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(list41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(valueAxis58);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.05d + "'", double63 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets64);
        org.junit.Assert.assertNotNull(paint65);
        org.junit.Assert.assertNotNull(list68);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + true + "'", boolean71 == true);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        double double1 = categoryPlot0.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset3 = categoryPlot0.getDataset((int) (byte) 1);
        boolean boolean4 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot0.getRangeAxis(255);
        categoryPlot0.setRangeCrosshairValue((double) 10.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        double double11 = categoryAxis10.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis10.getTickLabelInsets();
        java.awt.Paint paint13 = categoryAxis10.getTickLabelPaint();
        categoryAxis10.setLowerMargin((-1.0d));
        java.util.List list16 = categoryPlot0.getCategoriesForAxis(categoryAxis10);
        categoryAxis10.setTickMarkOutsideLength((float) (-1));
        float float19 = categoryAxis10.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        double double2 = categoryAxis1.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Paint paint5 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font6 = categoryAxis1.getLabelFont();
        double double7 = categoryAxis1.getLowerMargin();
        categoryAxis1.setTickMarkOutsideLength((float) 100L);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        java.awt.Image image12 = null;
        categoryPlot10.setBackgroundImage(image12);
        java.util.List list14 = categoryPlot10.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot10.getDomainAxisEdge();
        boolean boolean16 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot10);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis18.setNegativeArrowVisible(false);
        categoryPlot10.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis18);
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        numberAxis18.setTickLabelPaint((java.awt.Paint) color22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        double double25 = categoryPlot24.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset27 = categoryPlot24.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = categoryPlot24.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.data.Range range31 = categoryPlot24.getDataRange(valueAxis30);
        categoryPlot24.setForegroundAlpha(0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot24.getRangeAxisEdge((int) (byte) -1);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = categoryPlot24.getDatasetRenderingOrder();
        numberAxis18.setPlot((org.jfree.chart.plot.Plot) categoryPlot24);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05d + "'", double2 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertNull(list14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset27);
        org.junit.Assert.assertNull(categoryAxis29);
        org.junit.Assert.assertNull(range31);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
        xYPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand11 = numberAxis5.getMarkerBand();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis13.setNegativeArrowVisible(false);
        org.jfree.data.Range range16 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis13.setRange(range16, true, false);
        numberAxis5.setRangeWithMargins(range16, false, true);
        xYPlot0.setDomainAxis((int) '#', (org.jfree.chart.axis.ValueAxis) numberAxis5, true);
        org.jfree.chart.axis.TickUnitSource tickUnitSource25 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        numberAxis5.setStandardTickUnits(tickUnitSource25);
        numberAxis5.setRangeAboutValue(100.0d, 0.0d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(markerAxisBand11);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertNotNull(tickUnitSource25);
    }

//    @Test
//    public void test385() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test385");
//        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
//        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
//        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
//        float float5 = intervalMarker2.getAlpha();
//        org.jfree.chart.JFreeChart jFreeChart6 = null;
//        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
//        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) float5, jFreeChart6, chartChangeEventType7);
//        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day();
//        long long10 = day9.getSerialIndex();
//        long long11 = day9.getFirstMillisecond();
//        org.jfree.data.time.SerialDate serialDate12 = day9.getSerialDate();
//        org.jfree.data.xy.XYDataset xYDataset13 = null;
//        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
//        double double16 = numberAxis15.getUpperMargin();
//        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
//        numberAxis18.setNegativeArrowVisible(false);
//        java.awt.Shape shape21 = numberAxis18.getDownArrow();
//        numberAxis18.setUpperMargin((double) 100.0f);
//        double double24 = numberAxis18.getFixedDimension();
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
//        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset13, (org.jfree.chart.axis.ValueAxis) numberAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer25);
//        xYPlot26.setRangeGridlinesVisible(false);
//        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot26.getRangeAxisEdge(11);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
//        java.awt.geom.Point2D point2D33 = null;
//        xYPlot26.zoomRangeAxes((double) 100.0f, plotRenderingInfo32, point2D33);
//        xYPlot26.setRangeCrosshairValue(0.2d, true);
//        boolean boolean38 = day9.equals((java.lang.Object) xYPlot26);
//        boolean boolean39 = chartChangeEventType7.equals((java.lang.Object) day9);
//        long long40 = day9.getMiddleMillisecond();
//        java.util.Calendar calendar41 = null;
//        try {
//            day9.peg(calendar41);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.8f + "'", float5 == 0.8f);
//        org.junit.Assert.assertNotNull(chartChangeEventType7);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 43629L + "'", long10 == 43629L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560409200000L + "'", long11 == 1560409200000L);
//        org.junit.Assert.assertNotNull(serialDate12);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.05d + "'", double16 == 0.05d);
//        org.junit.Assert.assertNotNull(shape21);
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
//        org.junit.Assert.assertNotNull(rectangleEdge30);
//        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1560452399999L + "'", long40 == 1560452399999L);
//    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getUpperMargin();
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis5.setNegativeArrowVisible(false);
        java.awt.Shape shape8 = numberAxis5.getDownArrow();
        numberAxis5.setUpperMargin((double) 100.0f);
        double double11 = numberAxis5.getFixedDimension();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis5, xYItemRenderer12);
        boolean boolean14 = xYPlot13.isDomainCrosshairLockedOnData();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot13.getRangeAxisEdge(11);
        xYPlot13.setDomainCrosshairValue((double) 1.0f);
        boolean boolean19 = xYPlot13.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = intervalMarker2.getLabelOffset();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        intervalMarker2.setOutlinePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor8 = intervalMarker2.getLabelAnchor();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        double double10 = categoryPlot9.getAnchorValue();
        boolean boolean11 = rectangleAnchor8.equals((java.lang.Object) double10);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleAnchor8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setNegativeArrowVisible(false);
        java.awt.Shape shape4 = numberAxis1.getDownArrow();
        numberAxis1.setLowerBound((double) 192);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) (short) -1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = null;
        intervalMarker2.setGradientPaintTransformer(gradientPaintTransformer3);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = intervalMarker2.getLabelOffset();
        java.lang.Object obj6 = intervalMarker2.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        double double8 = categoryPlot7.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot7.getDataset((int) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = categoryPlot7.getDomainAxisForDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.Range range14 = categoryPlot7.getDataRange(valueAxis13);
        java.awt.Paint paint15 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryPlot7.setNoDataMessagePaint(paint15);
        java.awt.Color color17 = java.awt.Color.blue;
        categoryPlot7.setNoDataMessagePaint((java.awt.Paint) color17);
        intervalMarker2.setOutlinePaint((java.awt.Paint) color17);
        double double20 = intervalMarker2.getStartValue();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        double double23 = categoryAxis22.getLowerMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis22.getTickLabelInsets();
        java.awt.Paint paint26 = categoryAxis22.getTickLabelPaint((java.lang.Comparable) (short) -1);
        java.awt.Font font27 = categoryAxis22.getLabelFont();
        intervalMarker2.setLabelFont(font27);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertNull(categoryAxis12);
        org.junit.Assert.assertNull(range14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.05d + "'", double23 == 0.05d);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(font27);
    }
}

