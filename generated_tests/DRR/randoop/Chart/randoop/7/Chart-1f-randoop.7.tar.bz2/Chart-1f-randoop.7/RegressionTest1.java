import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj2 = standardCategorySeriesLabelGenerator1.clone();
        java.lang.Object obj3 = null;
        boolean boolean4 = standardCategorySeriesLabelGenerator1.equals(obj3);
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot6.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot6.setRenderer(categoryItemRenderer11);
        org.jfree.chart.entity.PlotEntity plotEntity14 = new org.jfree.chart.entity.PlotEntity(shape5, (org.jfree.chart.plot.Plot) categoryPlot6, "");
        categoryPlot6.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font22 = categoryAxis21.getLabelFont();
        categoryAxis18.setTickLabelFont((java.lang.Comparable) 10.0d, font22);
        java.awt.Stroke stroke24 = categoryAxis18.getTickMarkStroke();
        categoryPlot6.setDomainGridlineStroke(stroke24);
        java.lang.Comparable comparable26 = categoryPlot6.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font29 = categoryAxis28.getLabelFont();
        boolean boolean30 = categoryAxis28.isMinorTickMarksVisible();
        boolean boolean31 = categoryAxis28.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray32 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis28 };
        categoryPlot6.setDomainAxes(categoryAxisArray32);
        boolean boolean34 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) categoryPlot6);
        categoryPlot6.setDomainCrosshairRowKey((java.lang.Comparable) (short) 0);
        float float37 = categoryPlot6.getBackgroundImageAlpha();
        categoryPlot6.setRangeMinorGridlinesVisible(false);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(comparable26);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 0.5f + "'", float37 == 0.5f);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = categoryAxis1.getCategoryLabelPositions();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.panRangeAxes((double) (short) 1, plotRenderingInfo11, point2D12);
        float float14 = categoryPlot0.getBackgroundImageAlpha();
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 100, 0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke10 = barRenderer0.getItemStroke(8, (int) (byte) 0, true);
        java.awt.Paint paint11 = barRenderer0.getShadowPaint();
        org.jfree.chart.renderer.RenderAttributes renderAttributes13 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape16 = renderAttributes13.getItemShape(8, 8);
        java.awt.Stroke stroke18 = renderAttributes13.getSeriesStroke(100);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes13.setSeriesStroke(128, stroke20);
        barRenderer0.setSeriesStroke(35, stroke20, false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(shape16);
        org.junit.Assert.assertNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        categoryPlot0.axisChanged(axisChangeEvent2);
        int int4 = categoryPlot0.getRangeAxisCount();
        categoryPlot0.setAnchorValue(0.0d);
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape10 = renderAttributes7.getItemShape(8, 8);
        java.awt.Stroke stroke12 = renderAttributes7.getSeriesStroke(100);
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes7.setSeriesStroke(128, stroke14);
        categoryPlot0.setRangeCrosshairStroke(stroke14);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) 0L);
        java.lang.Number number2 = selectableValue1.getValue();
        boolean boolean3 = selectableValue1.isSelected();
        java.lang.Number number4 = selectableValue1.getValue();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0L + "'", number2.equals(0L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0L + "'", number4.equals(0L));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        barRenderer0.setDefaultEntityRadius(2);
        java.awt.Stroke stroke6 = barRenderer0.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot7.setRangeGridlineStroke(stroke19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        categoryPlot7.notifyListeners(plotChangeEvent21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot7.getRangeAxisEdge(3);
        barRenderer0.setPlot(categoryPlot7);
        boolean boolean27 = barRenderer0.isSeriesVisible((int) (short) 10);
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setBaseShape(shape28, false);
        java.awt.Stroke stroke32 = barRenderer0.lookupSeriesStroke((int) 'a');
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator5, false);
        java.lang.Boolean boolean9 = barRenderer0.getSeriesCreateEntities(1);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopOutset((double) (short) 0);
        double double4 = rectangleInsets0.calculateTopInset((double) 0.5f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font11 = categoryAxis10.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis10.getTickLabelInsets();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis10.setLabelPaint((java.awt.Paint) color13);
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color13);
        categoryAxis1.setFixedDimension((double) 1);
        categoryAxis1.setMinorTickMarkInsideLength((float) (-1));
        categoryAxis1.setLabelToolTip("hi!");
        boolean boolean22 = categoryAxis1.isVisible();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setBaseSeriesVisible(false, true);
        barRenderer0.setBaseSeriesVisibleInLegend(false, true);
        boolean boolean10 = barRenderer0.getBaseItemLabelsVisible();
        boolean boolean13 = barRenderer0.getItemVisible((int) (byte) 100, 35);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape0, jFreeChart1, chartChangeEventType2);
        java.lang.String str4 = chartChangeEvent3.toString();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape5, jFreeChart6, chartChangeEventType7);
        chartChangeEvent3.setType(chartChangeEventType7);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent3.setType(chartChangeEventType10);
        org.jfree.chart.JFreeChart jFreeChart12 = null;
        chartChangeEvent3.setChart(jFreeChart12);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]"));
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Paint paint3 = barRenderer0.lookupSeriesOutlinePaint((int) (byte) 100);
        java.awt.Paint paint4 = barRenderer0.getShadowPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        java.awt.Color color0 = java.awt.Color.magenta;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape1 = defaultDrawingSupplier0.getNextShape();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        boolean boolean10 = categoryPlot1.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis12.setLabelInsets(rectangleInsets13, true);
        java.util.List list16 = categoryPlot1.getCategoriesForAxis(categoryAxis12);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        categoryPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot17.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        categoryPlot17.setRangeAxis(2, valueAxis22, true);
        org.jfree.chart.LegendItemCollection legendItemCollection25 = new org.jfree.chart.LegendItemCollection();
        categoryPlot17.setFixedLegendItems(legendItemCollection25);
        categoryPlot1.setFixedLegendItems(legendItemCollection25);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer28.setAutoPopulateSeriesShape(false);
        barRenderer28.setDefaultEntityRadius(2);
        java.awt.Stroke stroke34 = barRenderer28.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener36 = null;
        categoryPlot35.addChangeListener(plotChangeListener36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot35.setBackgroundPaint((java.awt.Paint) color38);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font45 = categoryAxis44.getLabelFont();
        categoryAxis41.setTickLabelFont((java.lang.Comparable) 10.0d, font45);
        java.awt.Stroke stroke47 = categoryAxis41.getTickMarkStroke();
        categoryPlot35.setRangeGridlineStroke(stroke47);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent49 = null;
        categoryPlot35.notifyListeners(plotChangeEvent49);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot35.getRangeAxisEdge(3);
        barRenderer28.setPlot(categoryPlot35);
        boolean boolean55 = barRenderer28.isSeriesVisible((int) (short) 10);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor56 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor57 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition58 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor56, textAnchor57);
        barRenderer28.setBasePositiveItemLabelPosition(itemLabelPosition58);
        int int60 = categoryPlot1.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer28);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor56);
        org.junit.Assert.assertNotNull(textAnchor57);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1) + "'", int60 == (-1));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator5, false);
        barRenderer0.setItemMargin((double) 4);
        double double10 = barRenderer0.getMaximumBarWidth();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = barRenderer0.getLegendItems();
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        categoryPlot0.clearSelection();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        int int6 = categoryPlot0.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, color12 };
        java.awt.Color color14 = java.awt.Color.YELLOW;
        int int15 = color14.getBlue();
        java.awt.Color color16 = java.awt.Color.ORANGE;
        java.awt.Color color17 = java.awt.Color.WHITE;
        java.awt.Color color18 = color17.darker();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray20 = new java.awt.Paint[] { color14, color16, color18, color19 };
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] { stroke21, stroke22 };
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font29 = categoryAxis28.getLabelFont();
        categoryAxis25.setTickLabelFont((java.lang.Comparable) 10.0d, font29);
        java.awt.Stroke stroke31 = categoryAxis25.getTickMarkStroke();
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] { stroke31 };
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray34 = new java.awt.Shape[] { shape33 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray13, paintArray20, strokeArray23, strokeArray32, shapeArray34);
        java.lang.Object obj36 = defaultDrawingSupplier35.clone();
        java.awt.Paint paint37 = defaultDrawingSupplier35.getNextOutlinePaint();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray39 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot0.setRangeAxes(valueAxisArray39);
        categoryPlot0.setBackgroundAlpha((float) (byte) 1);
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font46 = categoryAxis45.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = null;
        double double52 = categoryAxis45.getCategoryJava2DCoordinate(categoryAnchor47, (int) (byte) 100, (int) (byte) 1, rectangle2D50, rectangleEdge51);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font55 = categoryAxis54.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = categoryAxis54.getTickLabelInsets();
        java.awt.Color color57 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis54.setLabelPaint((java.awt.Paint) color57);
        categoryAxis45.setAxisLinePaint((java.awt.Paint) color57);
        categoryAxis45.setFixedDimension((double) 1);
        categoryAxis45.setMinorTickMarkInsideLength((float) (-1));
        categoryAxis45.setLabelToolTip("hi!");
        try {
            categoryPlot0.setDomainAxis((-3), categoryAxis45, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shapeArray34);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(valueAxisArray39);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(font55);
        org.junit.Assert.assertNotNull(rectangleInsets56);
        org.junit.Assert.assertNotNull(color57);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Font font2 = renderAttributes1.getDefaultLabelFont();
        java.awt.Color color6 = java.awt.Color.getHSBColor(0.0f, (float) (byte) 100, (float) 100);
        renderAttributes1.setDefaultLabelPaint((java.awt.Paint) color6);
        int int8 = color6.getBlue();
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 173 + "'", int8 == 173);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        legendItem31.setLabelFont(font37);
        java.awt.Paint paint40 = legendItem31.getLinePaint();
        java.awt.Shape shape41 = legendItem31.getLine();
        java.awt.Stroke stroke42 = legendItem31.getLineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer43.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer47 = barRenderer43.getGradientPaintTransformer();
        java.awt.Shape shape49 = barRenderer43.lookupLegendShape((int) (short) 10);
        java.awt.Paint paint51 = barRenderer43.getSeriesOutlinePaint((-16727872));
        java.awt.Shape shape52 = barRenderer43.getBaseShape();
        legendItem31.setShape(shape52);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(gradientPaintTransformer47);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNull(paint51);
        org.junit.Assert.assertNotNull(shape52);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        try {
            keyedObjects0.removeValue((java.lang.Comparable) "TextAnchor.TOP_RIGHT");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (TextAnchor.TOP_RIGHT) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (byte) 0);
        org.jfree.chart.plot.Marker marker4 = null;
        try {
            categoryPlot0.addRangeMarker(marker4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType32 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType32);
        legendItem31.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        java.lang.String str35 = legendItem31.getToolTipText();
        boolean boolean36 = legendItem31.isShapeFilled();
        java.lang.Comparable comparable37 = legendItem31.getSeriesKey();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(comparable37);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color8, color10 };
        java.awt.Color color12 = java.awt.Color.YELLOW;
        int int13 = color12.getBlue();
        java.awt.Color color14 = java.awt.Color.ORANGE;
        java.awt.Color color15 = java.awt.Color.WHITE;
        java.awt.Color color16 = color15.darker();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { color12, color14, color16, color17 };
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] { stroke19, stroke20 };
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font27 = categoryAxis26.getLabelFont();
        categoryAxis23.setTickLabelFont((java.lang.Comparable) 10.0d, font27);
        java.awt.Stroke stroke29 = categoryAxis23.getTickMarkStroke();
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] { stroke29 };
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray32 = new java.awt.Shape[] { shape31 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray11, paintArray18, strokeArray21, strokeArray30, shapeArray32);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier33);
        categoryPlot0.setBackgroundImageAlignment((int) (byte) 10);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        categoryPlot0.setRangeAxis(valueAxis37);
        java.awt.Stroke stroke39 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font42 = categoryAxis41.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor43 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = null;
        double double48 = categoryAxis41.getCategoryJava2DCoordinate(categoryAnchor43, (int) (byte) 100, (int) (byte) 1, rectangle2D46, rectangleEdge47);
        categoryAxis41.setLabelToolTip("hi!");
        categoryPlot0.setDomainAxis(categoryAxis41);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shapeArray32);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot12.setBackgroundPaint((java.awt.Paint) color15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot12.setRenderer(categoryItemRenderer17);
        org.jfree.chart.entity.PlotEntity plotEntity20 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) categoryPlot12, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        categoryPlot21.addChangeListener(plotChangeListener22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot21.setBackgroundPaint((java.awt.Paint) color24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font31 = categoryAxis30.getLabelFont();
        categoryAxis27.setTickLabelFont((java.lang.Comparable) 10.0d, font31);
        java.awt.Stroke stroke33 = categoryAxis27.getTickMarkStroke();
        categoryPlot21.setRangeGridlineStroke(stroke33);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color37 = java.awt.Color.getColor("", color36);
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape11, stroke33, (java.awt.Paint) color37);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType39 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer40 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType39);
        legendItem38.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer40);
        java.lang.String str42 = legendItem38.getToolTipText();
        java.awt.Paint paint43 = legendItem38.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font49 = categoryAxis48.getLabelFont();
        categoryAxis45.setTickLabelFont((java.lang.Comparable) 10.0d, font49);
        java.awt.Stroke stroke51 = categoryAxis45.getTickMarkStroke();
        java.awt.Font font52 = categoryAxis45.getLabelFont();
        legendItem38.setLabelFont(font52);
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font56 = categoryAxis55.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor57 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = null;
        double double62 = categoryAxis55.getCategoryJava2DCoordinate(categoryAnchor57, (int) (byte) 100, (int) (byte) 1, rectangle2D60, rectangleEdge61);
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font65 = categoryAxis64.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets66 = categoryAxis64.getTickLabelInsets();
        java.awt.Color color67 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis64.setLabelPaint((java.awt.Paint) color67);
        categoryAxis55.setAxisLinePaint((java.awt.Paint) color67);
        legendItem38.setLinePaint((java.awt.Paint) color67);
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color67);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = null;
        try {
            categoryPlot0.handleClick(10, 255, plotRenderingInfo74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(gradientPaintTransformType39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNotNull(rectangleInsets66);
        org.junit.Assert.assertNotNull(color67);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        barRenderer0.setBase((double) 0.5f);
        barRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot10.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot10.setRenderer(categoryItemRenderer15);
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape9, (org.jfree.chart.plot.Plot) categoryPlot10, "");
        categoryPlot10.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font26 = categoryAxis25.getLabelFont();
        categoryAxis22.setTickLabelFont((java.lang.Comparable) 10.0d, font26);
        java.awt.Stroke stroke28 = categoryAxis22.getTickMarkStroke();
        categoryPlot10.setDomainGridlineStroke(stroke28);
        java.lang.Comparable comparable30 = categoryPlot10.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot10.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset31);
        org.jfree.data.Range range34 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset31, true);
        int int35 = defaultCategoryDataset31.getRowCount();
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(comparable30);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        renderAttributes0.setDefaultPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke7 = renderAttributes0.getDefaultOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer9.setAutoPopulateSeriesShape(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer12.setBaseItemLabelGenerator(categoryItemLabelGenerator13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition();
        java.awt.Color color17 = java.awt.Color.WHITE;
        java.awt.Color color18 = color17.darker();
        boolean boolean19 = itemLabelPosition16.equals((java.lang.Object) color17);
        barRenderer12.setBasePositiveItemLabelPosition(itemLabelPosition16, false);
        barRenderer9.setBasePositiveItemLabelPosition(itemLabelPosition16, false);
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        barRenderer9.setShadowPaint((java.awt.Paint) color25);
        renderAttributes0.setSeriesPaint(0, (java.awt.Paint) color25);
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint31 = barRenderer30.getBaseLegendTextPaint();
        java.awt.Font font35 = barRenderer30.getItemLabelFont((int) (short) 10, 100, false);
        try {
            renderAttributes0.setSeriesLabelFont(10, font35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(font35);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        categoryPlot0.select((double) (-1L), (double) 100, rectangle2D4, renderingSource5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        int int8 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getInsets();
        double double11 = rectangleInsets9.calculateLeftInset((double) 1);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.0d + "'", double11 == 8.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot15.setBackgroundPaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        categoryPlot15.setRenderer(categoryItemRenderer20);
        org.jfree.chart.entity.PlotEntity plotEntity23 = new org.jfree.chart.entity.PlotEntity(shape14, (org.jfree.chart.plot.Plot) categoryPlot15, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot24.addChangeListener(plotChangeListener25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot24.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font34 = categoryAxis33.getLabelFont();
        categoryAxis30.setTickLabelFont((java.lang.Comparable) 10.0d, font34);
        java.awt.Stroke stroke36 = categoryAxis30.getTickMarkStroke();
        categoryPlot24.setRangeGridlineStroke(stroke36);
        java.awt.Color color39 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color40 = java.awt.Color.getColor("", color39);
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape14, stroke36, (java.awt.Paint) color40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font47 = categoryAxis46.getLabelFont();
        categoryAxis43.setTickLabelFont((java.lang.Comparable) 10.0d, font47);
        legendItem41.setLabelFont(font47);
        java.awt.Paint paint50 = legendItem41.getLinePaint();
        java.awt.Shape shape51 = legendItem41.getLine();
        java.awt.Stroke stroke52 = legendItem41.getLineStroke();
        categoryPlot1.setRangeGridlineStroke(stroke52);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(paint50);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(stroke52);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = categoryAxis2.getLabelFont();
        boolean boolean4 = categoryAxis2.isMinorTickMarksVisible();
        boolean boolean5 = categoryAxis2.isAxisLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis2.getTickLabelInsets();
        boolean boolean7 = plotOrientation0.equals((java.lang.Object) rectangleInsets6);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        categoryPlot0.clearSelection();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        int int6 = categoryPlot0.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, color12 };
        java.awt.Color color14 = java.awt.Color.YELLOW;
        int int15 = color14.getBlue();
        java.awt.Color color16 = java.awt.Color.ORANGE;
        java.awt.Color color17 = java.awt.Color.WHITE;
        java.awt.Color color18 = color17.darker();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray20 = new java.awt.Paint[] { color14, color16, color18, color19 };
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] { stroke21, stroke22 };
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font29 = categoryAxis28.getLabelFont();
        categoryAxis25.setTickLabelFont((java.lang.Comparable) 10.0d, font29);
        java.awt.Stroke stroke31 = categoryAxis25.getTickMarkStroke();
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] { stroke31 };
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray34 = new java.awt.Shape[] { shape33 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray13, paintArray20, strokeArray23, strokeArray32, shapeArray34);
        java.lang.Object obj36 = defaultDrawingSupplier35.clone();
        java.awt.Paint paint37 = defaultDrawingSupplier35.getNextOutlinePaint();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35);
        java.awt.Shape shape39 = defaultDrawingSupplier35.getNextShape();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shapeArray34);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(shape39);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        boolean boolean7 = barRenderer0.isItemLabelVisible((int) (byte) 10, 0, true);
        barRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot10.getFixedLegendItems();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = null;
        categoryPlot10.axisChanged(axisChangeEvent12);
        int int14 = categoryPlot10.getRangeAxisCount();
        float float15 = categoryPlot10.getBackgroundImageAlpha();
        java.awt.Stroke stroke16 = categoryPlot10.getRangeZeroBaselineStroke();
        barRenderer0.setBaseStroke(stroke16);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(legendItemCollection11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        lineAndShapeRenderer2.clearSeriesPaints(true);
        lineAndShapeRenderer2.setUseFillPaint(true);
        boolean boolean10 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        lineAndShapeRenderer2.setAutoPopulateSeriesShape(true);
        java.lang.Object obj13 = lineAndShapeRenderer2.clone();
        int int14 = lineAndShapeRenderer2.getPassCount();
        lineAndShapeRenderer2.setSeriesLinesVisible(1, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        barRenderer0.setSeriesItemLabelsVisible((int) '4', false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        float float19 = categoryAxis13.getTickMarkInsideLength();
        float float20 = categoryAxis13.getMinorTickMarkInsideLength();
        categoryAxis13.setLabel("");
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot25.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot25.setRenderer(categoryItemRenderer30);
        org.jfree.chart.entity.PlotEntity plotEntity33 = new org.jfree.chart.entity.PlotEntity(shape24, (org.jfree.chart.plot.Plot) categoryPlot25, "");
        categoryPlot25.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font41 = categoryAxis40.getLabelFont();
        categoryAxis37.setTickLabelFont((java.lang.Comparable) 10.0d, font41);
        java.awt.Stroke stroke43 = categoryAxis37.getTickMarkStroke();
        categoryPlot25.setDomainGridlineStroke(stroke43);
        java.lang.Comparable comparable45 = categoryPlot25.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset46 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot25.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset46);
        defaultCategoryDataset46.clearSelection();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D54 = barRenderer0.createHotSpotBounds(graphics2D9, rectangle2D10, categoryPlot11, categoryAxis13, valueAxis23, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset46, 128, 1, true, categoryItemRendererState52, rectangle2D53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 0.0f + "'", float19 == 0.0f);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.0f + "'", float20 == 0.0f);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(comparable45);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.trimHeight((double) 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        legendItem31.setLabelFont(font37);
        legendItem31.setShapeVisible(false);
        java.lang.Object obj42 = legendItem31.clone();
        java.lang.Comparable comparable43 = legendItem31.getSeriesKey();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(obj42);
        org.junit.Assert.assertNull(comparable43);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        boolean boolean7 = barRenderer0.isItemLabelVisible((int) (byte) 10, 0, true);
        java.awt.Shape shape9 = barRenderer0.getSeriesShape((int) (short) -1);
        java.awt.Shape shape11 = barRenderer0.getLegendShape((int) (byte) 0);
        java.awt.Shape shape15 = barRenderer0.getItemShape((int) (byte) -1, 8, false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertNull(shape11);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setUseOutlinePaint(false);
        int int9 = lineAndShapeRenderer2.getDefaultEntityRadius();
        java.lang.Boolean boolean11 = lineAndShapeRenderer2.getSeriesShapesVisible((int) '#');
        java.awt.Font font12 = lineAndShapeRenderer2.getBaseLegendTextFont();
        java.awt.Stroke stroke14 = lineAndShapeRenderer2.lookupSeriesStroke((int) '4');
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
        org.junit.Assert.assertNull(boolean11);
        org.junit.Assert.assertNull(font12);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkOutsideLength(0.0f);
        java.awt.Font font3 = categoryAxis0.getTickLabelFont();
        float float4 = categoryAxis0.getMinorTickMarkOutsideLength();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font8 = categoryAxis7.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis7.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        java.awt.Paint paint13 = categoryPlot10.getDomainGridlinePaint();
        categoryAxis7.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        categoryPlot10.clearAnnotations();
        java.awt.Font font16 = categoryPlot10.getNoDataMessageFont();
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot10.setDomainAxisLocation(axisLocation17, true);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint22 = categoryPlot21.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot21.getDomainAxisEdge((int) (byte) 0);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace26 = categoryAxis0.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) categoryPlot10, rectangle2D20, rectangleEdge24, axisSpace25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        categoryPlot0.select((double) (-1L), (double) 100, rectangle2D4, renderingSource5);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray7);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            categoryPlot0.addRangeMarker(marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        categoryPlot2.addChangeListener(plotChangeListener3);
        java.awt.Paint paint5 = categoryPlot2.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        boolean boolean8 = categoryPlot2.removeDomainMarker(marker6, layer7);
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot2.getDataset(100);
        boolean boolean11 = categoryPlot2.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        categoryPlot2.setRangeAxis((int) (short) 100, valueAxis13, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryPlot2.getAxisOffset();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.Paint paint19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        java.awt.Paint paint23 = categoryPlot20.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker24 = null;
        org.jfree.chart.util.Layer layer25 = null;
        boolean boolean26 = categoryPlot20.removeDomainMarker(marker24, layer25);
        org.jfree.data.category.CategoryDataset categoryDataset28 = categoryPlot20.getDataset(100);
        boolean boolean29 = categoryPlot20.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        int int31 = categoryPlot20.getIndexOf(categoryItemRenderer30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection33 = categoryPlot32.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        org.jfree.chart.RenderingSource renderingSource37 = null;
        categoryPlot32.select((double) (-1L), (double) 100, rectangle2D36, renderingSource37);
        boolean boolean39 = categoryPlot32.canSelectByRegion();
        int int40 = categoryPlot32.getDomainAxisCount();
        categoryPlot20.setParent((org.jfree.chart.plot.Plot) categoryPlot32);
        java.awt.Stroke stroke42 = categoryPlot32.getRangeMinorGridlineStroke();
        try {
            barRenderer0.drawDomainLine(graphics2D1, categoryPlot2, rectangle2D17, (double) 10, paint19, stroke42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(categoryDataset28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNull(legendItemCollection33);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType32 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType32);
        legendItem31.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        java.lang.String str35 = legendItem31.getDescription();
        int int36 = legendItem31.getDatasetIndex();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot0.setRangeAxis(2, valueAxis5, true);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot0.setRangeAxis((int) (short) 100, valueAxis9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot0.setRangeAxis(valueAxis11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        java.awt.geom.Point2D point2D15 = null;
        org.jfree.chart.plot.PlotState plotState16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            categoryPlot0.draw(graphics2D13, rectangle2D14, point2D15, plotState16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor2, 0, (int) ' ', rectangle2D5, rectangleEdge6);
        categoryAxis1.setCategoryMargin((double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis1.setTickLabelInsets(rectangleInsets10);
        categoryAxis1.setMaximumCategoryLabelLines((-16727872));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        try {
            categoryPlot1.addDomainMarker(categoryMarker21, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        boolean boolean3 = categoryAxis1.isMinorTickMarksVisible();
        boolean boolean4 = categoryAxis1.isAxisLineVisible();
        categoryAxis1.setAxisLineVisible(false);
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        categoryPlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot3.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot8.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color11, color13 };
        java.awt.Color color15 = java.awt.Color.YELLOW;
        int int16 = color15.getBlue();
        java.awt.Color color17 = java.awt.Color.ORANGE;
        java.awt.Color color18 = java.awt.Color.WHITE;
        java.awt.Color color19 = color18.darker();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color15, color17, color19, color20 };
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray24 = new java.awt.Stroke[] { stroke22, stroke23 };
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font30 = categoryAxis29.getLabelFont();
        categoryAxis26.setTickLabelFont((java.lang.Comparable) 10.0d, font30);
        java.awt.Stroke stroke32 = categoryAxis26.getTickMarkStroke();
        java.awt.Stroke[] strokeArray33 = new java.awt.Stroke[] { stroke32 };
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray35 = new java.awt.Shape[] { shape34 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray14, paintArray21, strokeArray24, strokeArray33, shapeArray35);
        categoryPlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier36);
        org.jfree.chart.entity.PlotEntity plotEntity40 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot3, "ChartChangeEventType.DATASET_UPDATED", "hi!");
        java.lang.Object obj41 = plotEntity40.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(strokeArray33);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shapeArray35);
        org.junit.Assert.assertNotNull(obj41);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        boolean boolean22 = categoryPlot1.canSelectByPoint();
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot1.setFixedDomainAxisSpace(axisSpace23);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.RenderingSource renderingSource28 = null;
        categoryPlot1.select((double) 15, (double) 1L, rectangle2D27, renderingSource28);
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = categoryPlot1.getRangeMarkers(layer30);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(collection31);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        barRenderer0.setSeriesOutlinePaint(0, paint7, true);
        barRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer0.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator14);
        java.awt.Paint paint17 = barRenderer0.getSeriesOutlinePaint(100);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(paint17);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot0.getIndexOf(categoryItemRenderer10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot12.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.RenderingSource renderingSource17 = null;
        categoryPlot12.select((double) (-1L), (double) 100, rectangle2D16, renderingSource17);
        boolean boolean19 = categoryPlot12.canSelectByRegion();
        int int20 = categoryPlot12.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        categoryPlot0.addChangeListener(plotChangeListener22);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis1.setLabelInsets(rectangleInsets4, true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color7);
        int int9 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.chart.renderer.RenderAttributes renderAttributes10 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape13 = renderAttributes10.getItemShape(8, 8);
        java.awt.Stroke stroke15 = renderAttributes10.getSeriesStroke(100);
        java.awt.Color color17 = java.awt.Color.green;
        renderAttributes10.setSeriesOutlinePaint(4, (java.awt.Paint) color17);
        categoryAxis1.setLabelPaint((java.awt.Paint) color17);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(shape13);
        org.junit.Assert.assertNull(stroke15);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot4.setBackgroundPaint((java.awt.Paint) color7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray10 = new java.awt.Paint[] { color7, color9 };
        java.awt.Color color11 = java.awt.Color.YELLOW;
        int int12 = color11.getBlue();
        java.awt.Color color13 = java.awt.Color.ORANGE;
        java.awt.Color color14 = java.awt.Color.WHITE;
        java.awt.Color color15 = color14.darker();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color11, color13, color15, color16 };
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke18, stroke19 };
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font26 = categoryAxis25.getLabelFont();
        categoryAxis22.setTickLabelFont((java.lang.Comparable) 10.0d, font26);
        java.awt.Stroke stroke28 = categoryAxis22.getTickMarkStroke();
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] { stroke28 };
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray31 = new java.awt.Shape[] { shape30 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray17, strokeArray20, strokeArray29, shapeArray31);
        java.lang.Object obj33 = defaultDrawingSupplier32.clone();
        java.awt.Paint paint34 = defaultDrawingSupplier32.getNextOutlinePaint();
        barRenderer0.setBaseOutlinePaint(paint34, false);
        java.awt.Font font38 = barRenderer0.lookupLegendTextFont(0);
        barRenderer0.setIncludeBaseInRange(true);
        boolean boolean44 = barRenderer0.isItemLabelVisible((int) (short) 100, 0, false);
        boolean boolean46 = barRenderer0.isSeriesItemLabelsVisible((int) '#');
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shapeArray31);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(font38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        java.lang.Boolean boolean8 = lineAndShapeRenderer2.getSeriesShapesFilled(15);
        boolean boolean11 = lineAndShapeRenderer2.getItemLineVisible(3, (int) '4');
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        categoryPlot0.axisChanged(axisChangeEvent2);
        int int4 = categoryPlot0.getRangeAxisCount();
        float float5 = categoryPlot0.getBackgroundImageAlpha();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxis(128);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5f + "'", float5 == 0.5f);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType32 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType32);
        legendItem31.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        java.lang.String str35 = legendItem31.getToolTipText();
        boolean boolean36 = legendItem31.isShapeFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot37.addChangeListener(plotChangeListener38);
        java.awt.Paint paint40 = categoryPlot37.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = null;
        boolean boolean43 = categoryPlot37.removeDomainMarker(marker41, layer42);
        org.jfree.data.category.CategoryDataset categoryDataset45 = categoryPlot37.getDataset(100);
        boolean boolean46 = categoryPlot37.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        int int48 = categoryPlot37.getIndexOf(categoryItemRenderer47);
        org.jfree.chart.renderer.category.BarRenderer barRenderer49 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer49.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener54 = null;
        categoryPlot53.addChangeListener(plotChangeListener54);
        java.awt.Paint paint56 = categoryPlot53.getDomainGridlinePaint();
        barRenderer49.setSeriesOutlinePaint(0, paint56, true);
        barRenderer49.setBaseItemLabelsVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent61 = null;
        barRenderer49.notifyListeners(rendererChangeEvent61);
        categoryPlot37.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer49);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent64 = null;
        categoryPlot37.markerChanged(markerChangeEvent64);
        java.awt.Stroke stroke66 = categoryPlot37.getRangeZeroBaselineStroke();
        legendItem31.setOutlineStroke(stroke66);
        java.awt.Shape shape68 = legendItem31.getShape();
        java.lang.String str69 = legendItem31.getDescription();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "hi!" + "'", str69.equals("hi!"));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis1.setLabelInsets(rectangleInsets4, true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color7);
        int int9 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.Paint paint11 = categoryAxis1.getTickLabelPaint((java.lang.Comparable) 1.0d);
        categoryAxis1.setMinorTickMarksVisible(true);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Paint paint1 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = categoryPlot0.getDomainAxisEdge((int) (byte) 0);
        org.jfree.chart.plot.Plot plot4 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(plot4);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        java.lang.String str10 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        categoryAxis1.setTickMarkInsideLength((float) (byte) 1);
        categoryAxis1.clearCategoryLabelToolTips();
        java.awt.Font font15 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 1);
        float float16 = categoryAxis1.getMinorTickMarkOutsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryAxis1.getLabelInsets();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 2.0f + "'", float16 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        categoryPlot0.select((double) (-1L), (double) 100, rectangle2D4, renderingSource5);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray7);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier11, true);
        boolean boolean14 = categoryPlot0.isRangePannable();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState19 = null;
        boolean boolean20 = categoryPlot0.render(graphics2D15, rectangle2D16, (int) (short) 100, plotRenderingInfo18, categoryCrosshairState19);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        barRenderer0.setSeriesOutlinePaint(0, paint7, true);
        double double10 = barRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace6, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        java.awt.Stroke stroke12 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("PlotEntity: tooltip = ");
        categoryPlot0.setDomainAxis(categoryAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        categoryPlot0.setRangeAxis((int) (byte) 0, valueAxis17);
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("PlotEntity: tooltip = ");
        categoryAxis1.setTickLabelsVisible(true);
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot9.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot9.setRenderer(categoryItemRenderer14);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) categoryPlot9, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        categoryPlot18.addChangeListener(plotChangeListener19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot18.setBackgroundPaint((java.awt.Paint) color21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font28 = categoryAxis27.getLabelFont();
        categoryAxis24.setTickLabelFont((java.lang.Comparable) 10.0d, font28);
        java.awt.Stroke stroke30 = categoryAxis24.getTickMarkStroke();
        categoryPlot18.setRangeGridlineStroke(stroke30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color34 = java.awt.Color.getColor("", color33);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape8, stroke30, (java.awt.Paint) color34);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType36 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer37 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType36);
        legendItem35.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer37);
        java.lang.String str39 = legendItem35.getToolTipText();
        java.awt.Paint paint40 = legendItem35.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font46 = categoryAxis45.getLabelFont();
        categoryAxis42.setTickLabelFont((java.lang.Comparable) 10.0d, font46);
        legendItem35.setLabelFont(font46);
        categoryAxis1.setLabelFont(font46);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(gradientPaintTransformType36);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "hi!" + "'", str39.equals("hi!"));
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(font46);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        lineAndShapeRenderer2.clearSeriesPaints(true);
        lineAndShapeRenderer2.setUseFillPaint(true);
        boolean boolean10 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        lineAndShapeRenderer2.setAutoPopulateSeriesShape(true);
        java.lang.Object obj13 = lineAndShapeRenderer2.clone();
        int int14 = lineAndShapeRenderer2.getPassCount();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = lineAndShapeRenderer2.getSeriesURLGenerator(0);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlineStroke(true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNull(categoryURLGenerator16);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot0.notifyListeners(plotChangeEvent14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot0.getRangeAxisEdge(3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.Plot plot19 = plotChangeEvent18.getPlot();
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        plot19.drawBackgroundImage(graphics2D20, rectangle2D21);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(plot19);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getDrawOutlines();
        java.lang.Boolean boolean8 = lineAndShapeRenderer2.getSeriesLinesVisible(0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = lineAndShapeRenderer2.getBaseItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator9);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke10 = barRenderer0.getItemStroke(8, (int) (byte) 0, true);
        java.awt.Shape shape11 = barRenderer0.getBaseShape();
        boolean boolean13 = barRenderer0.isSeriesItemLabelsVisible((int) ' ');
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = barRenderer0.getLegendItemLabelGenerator();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        java.awt.Paint paint19 = categoryPlot16.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = categoryPlot16.removeDomainMarker(marker20, layer21);
        boolean boolean23 = categoryPlot16.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot24.addChangeListener(plotChangeListener25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot24.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font34 = categoryAxis33.getLabelFont();
        categoryAxis30.setTickLabelFont((java.lang.Comparable) 10.0d, font34);
        java.awt.Stroke stroke36 = categoryAxis30.getTickMarkStroke();
        categoryPlot24.setRangeGridlineStroke(stroke36);
        categoryPlot16.setRangeGridlineStroke(stroke36);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        categoryPlot16.setRenderer((int) (byte) 1, categoryItemRenderer40);
        float float42 = categoryPlot16.getForegroundAlpha();
        float float43 = categoryPlot16.getBackgroundImageAlpha();
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        try {
            barRenderer0.drawBackground(graphics2D15, categoryPlot16, rectangle2D44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator14);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 1.0f + "'", float42 == 1.0f);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.5f + "'", float43 == 0.5f);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis1.setLabelInsets(rectangleInsets4, true);
        double double8 = rectangleInsets4.calculateBottomOutset((double) (byte) 10);
        double double10 = rectangleInsets4.calculateRightInset((double) 0L);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            rectangleInsets4.trim(rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke10 = barRenderer0.getItemStroke(8, (int) (byte) 0, true);
        java.awt.Shape shape11 = barRenderer0.getBaseShape();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot12.addChangeListener(plotChangeListener13);
        java.awt.Paint paint15 = categoryPlot12.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        boolean boolean18 = categoryPlot12.removeDomainMarker(marker16, layer17);
        boolean boolean19 = categoryPlot12.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot20.setBackgroundPaint((java.awt.Paint) color23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font30 = categoryAxis29.getLabelFont();
        categoryAxis26.setTickLabelFont((java.lang.Comparable) 10.0d, font30);
        java.awt.Stroke stroke32 = categoryAxis26.getTickMarkStroke();
        categoryPlot20.setRangeGridlineStroke(stroke32);
        categoryPlot12.setRangeGridlineStroke(stroke32);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        categoryPlot12.setRenderer((int) (byte) 1, categoryItemRenderer36);
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener39 = null;
        categoryPlot38.addChangeListener(plotChangeListener39);
        java.awt.Paint paint41 = categoryPlot38.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker42 = null;
        org.jfree.chart.util.Layer layer43 = null;
        boolean boolean44 = categoryPlot38.removeDomainMarker(marker42, layer43);
        org.jfree.data.category.CategoryDataset categoryDataset46 = categoryPlot38.getDataset(100);
        boolean boolean47 = categoryPlot38.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        categoryPlot38.panRangeAxes((double) (short) 1, plotRenderingInfo49, point2D50);
        float float52 = categoryPlot38.getBackgroundImageAlpha();
        categoryPlot38.clearSelection();
        org.jfree.chart.util.SortOrder sortOrder54 = categoryPlot38.getRowRenderingOrder();
        categoryPlot12.setColumnRenderingOrder(sortOrder54);
        org.jfree.chart.entity.PlotEntity plotEntity56 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) categoryPlot12);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(categoryDataset46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 0.5f + "'", float52 == 0.5f);
        org.junit.Assert.assertNotNull(sortOrder54);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot0.setRenderer(3, categoryItemRenderer7);
        categoryPlot0.clearRangeMarkers((int) (short) 1);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 1);
        categoryPlot0.setNotify(false);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        categoryPlot0.select((double) (-1L), (double) 100, rectangle2D4, renderingSource5);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray7);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier11, true);
        boolean boolean14 = categoryPlot0.isRangePannable();
        categoryPlot0.setNoDataMessage("TextAnchor.TOP_RIGHT");
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint8 = barRenderer0.lookupSeriesOutlinePaint(0);
        java.awt.Paint paint12 = barRenderer0.getItemFillPaint(0, (int) (short) 1, true);
        barRenderer0.setBaseItemLabelsVisible(false, false);
        java.lang.Boolean boolean17 = barRenderer0.getSeriesVisibleInLegend((int) (short) 1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(boolean17);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font6 = categoryAxis5.getLabelFont();
        boolean boolean7 = categoryAxis5.isMinorTickMarksVisible();
        boolean boolean8 = categoryAxis5.isAxisLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis5.getTickLabelInsets();
        categoryPlot0.setDomainAxis(categoryAxis5);
        org.jfree.chart.util.SortOrder sortOrder11 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        java.awt.Paint paint9 = categoryPlot4.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot4.getRangeAxisLocation();
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        categoryPlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot13.setBackgroundPaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot13.setRenderer(categoryItemRenderer18);
        org.jfree.chart.entity.PlotEntity plotEntity21 = new org.jfree.chart.entity.PlotEntity(shape12, (org.jfree.chart.plot.Plot) categoryPlot13, "");
        categoryPlot13.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font29 = categoryAxis28.getLabelFont();
        categoryAxis25.setTickLabelFont((java.lang.Comparable) 10.0d, font29);
        java.awt.Stroke stroke31 = categoryAxis25.getTickMarkStroke();
        categoryPlot13.setDomainGridlineStroke(stroke31);
        java.lang.Comparable comparable33 = categoryPlot13.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset34 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot13.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset34);
        defaultCategoryDataset34.clearSelection();
        int int37 = defaultCategoryDataset34.getColumnCount();
        categoryPlot4.setDataset((int) (short) 1, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset34);
        defaultCategoryDataset34.addValue((double) 35, (java.lang.Comparable) (-1L), (java.lang.Comparable) 100.0f);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(comparable33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer4.setBaseItemLabelGenerator(categoryItemLabelGenerator5, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        barRenderer4.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator9, false);
        barRenderer4.setItemMargin((double) 4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor16 = itemLabelPosition15.getTextAnchor();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        boolean boolean18 = textAnchor16.equals((java.lang.Object) defaultDrawingSupplier17);
        java.awt.Paint paint19 = defaultDrawingSupplier17.getNextOutlinePaint();
        java.awt.Shape shape20 = defaultDrawingSupplier17.getNextShape();
        barRenderer4.setSeriesShape(100, shape20, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        categoryPlot23.addChangeListener(plotChangeListener24);
        java.awt.Paint paint26 = categoryPlot23.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker27 = null;
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot23.removeDomainMarker(marker27, layer28);
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot23.getDataset(100);
        boolean boolean32 = categoryPlot23.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot23.panRangeAxes((double) (short) 1, plotRenderingInfo34, point2D35);
        float float37 = categoryPlot23.getBackgroundImageAlpha();
        categoryPlot23.clearSelection();
        float float39 = categoryPlot23.getBackgroundImageAlpha();
        java.awt.Paint paint40 = categoryPlot23.getRangeGridlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer43.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean47 = lineAndShapeRenderer43.getDrawOutlines();
        lineAndShapeRenderer43.setUseOutlinePaint(false);
        boolean boolean50 = lineAndShapeRenderer43.getBaseCreateEntities();
        org.jfree.chart.renderer.category.BarRenderer barRenderer51 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator55 = barRenderer51.getItemLabelGenerator(100, 100, false);
        int int56 = barRenderer51.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = barRenderer51.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint59 = barRenderer51.lookupSeriesOutlinePaint(0);
        java.awt.Paint paint63 = barRenderer51.getItemFillPaint(0, (int) (short) 1, true);
        java.awt.Stroke stroke64 = barRenderer51.getBaseOutlineStroke();
        lineAndShapeRenderer43.setBaseOutlineStroke(stroke64, false);
        java.awt.Color color67 = java.awt.Color.orange;
        try {
            org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem(attributedString0, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "PlotOrientation.VERTICAL", "SortOrder.ASCENDING", shape20, paint40, stroke64, (java.awt.Paint) color67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(categoryDataset31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 0.5f + "'", float37 == 0.5f);
        org.junit.Assert.assertTrue("'" + float39 + "' != '" + 0.5f + "'", float39 == 0.5f);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNull(itemLabelPosition57);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(color67);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot4.setBackgroundPaint((java.awt.Paint) color7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray10 = new java.awt.Paint[] { color7, color9 };
        java.awt.Color color11 = java.awt.Color.YELLOW;
        int int12 = color11.getBlue();
        java.awt.Color color13 = java.awt.Color.ORANGE;
        java.awt.Color color14 = java.awt.Color.WHITE;
        java.awt.Color color15 = color14.darker();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color11, color13, color15, color16 };
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke18, stroke19 };
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font26 = categoryAxis25.getLabelFont();
        categoryAxis22.setTickLabelFont((java.lang.Comparable) 10.0d, font26);
        java.awt.Stroke stroke28 = categoryAxis22.getTickMarkStroke();
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] { stroke28 };
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray31 = new java.awt.Shape[] { shape30 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray17, strokeArray20, strokeArray29, shapeArray31);
        java.lang.Object obj33 = defaultDrawingSupplier32.clone();
        java.awt.Paint paint34 = defaultDrawingSupplier32.getNextOutlinePaint();
        barRenderer0.setBaseOutlinePaint(paint34, false);
        java.awt.Font font38 = barRenderer0.lookupLegendTextFont(0);
        barRenderer0.setIncludeBaseInRange(true);
        boolean boolean44 = barRenderer0.isItemLabelVisible((int) (short) 100, 0, false);
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer0.setBaseLegendTextPaint((java.awt.Paint) color45);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shapeArray31);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(font38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(color45);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        java.lang.String str10 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        double double11 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        java.awt.Stroke stroke9 = barRenderer0.getItemOutlineStroke((-16727872), 10, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = null;
        barRenderer13.setBaseItemLabelGenerator(categoryItemLabelGenerator14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = new org.jfree.chart.labels.ItemLabelPosition();
        java.awt.Color color18 = java.awt.Color.WHITE;
        java.awt.Color color19 = color18.darker();
        boolean boolean20 = itemLabelPosition17.equals((java.lang.Object) color18);
        barRenderer13.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        java.lang.Object obj23 = null;
        boolean boolean24 = itemLabelPosition17.equals(obj23);
        barRenderer0.setSeriesNegativeItemLabelPosition((int) '#', itemLabelPosition17, false);
        double double27 = itemLabelPosition17.getAngle();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes0.setDefaultOutlineStroke(stroke1);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator5, false);
        java.lang.Boolean boolean9 = barRenderer0.getSeriesCreateEntities(4);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        barRenderer0.drawRangeMarker(graphics2D10, categoryPlot11, valueAxis12, marker13, rectangle2D14);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setBaseShapesVisible(false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            rectangleInsets3.trim(rectangle2D4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis1.setLabelPaint((java.awt.Paint) color4);
        float float6 = categoryAxis1.getMinorTickMarkOutsideLength();
        categoryAxis1.setMinorTickMarkInsideLength((float) (short) 1);
        categoryAxis1.setLabelAngle((double) (-1.0f));
        double double11 = categoryAxis1.getCategoryMargin();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 10, plotRenderingInfo3, point2D4, false);
        org.jfree.chart.util.SortOrder sortOrder7 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder7);
        int int9 = categoryPlot0.getDomainAxisCount();
        java.awt.Font font10 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        defaultCategoryDataset22.clearSelection();
        org.jfree.data.category.CategoryDatasetSelectionState categoryDatasetSelectionState25 = defaultCategoryDataset22.getSelectionState();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(categoryDatasetSelectionState25);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        barRenderer3.setBaseItemLabelGenerator(categoryItemLabelGenerator4, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition();
        java.awt.Color color8 = java.awt.Color.WHITE;
        java.awt.Color color9 = color8.darker();
        boolean boolean10 = itemLabelPosition7.equals((java.lang.Object) color8);
        barRenderer3.setBasePositiveItemLabelPosition(itemLabelPosition7, false);
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition7, false);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color17 = java.awt.Color.getColor("", color16);
        barRenderer0.setShadowPaint((java.awt.Paint) color16);
        java.awt.Font font20 = barRenderer0.getSeriesItemLabelFont((int) (byte) -1);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(font20);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Font font2 = renderAttributes1.getDefaultLabelFont();
        java.awt.Color color6 = java.awt.Color.getHSBColor(0.0f, (float) (byte) 100, (float) 100);
        renderAttributes1.setDefaultLabelPaint((java.awt.Paint) color6);
        java.awt.Stroke stroke8 = renderAttributes1.getDefaultOutlineStroke();
        java.lang.Boolean boolean9 = renderAttributes1.getDefaultLabelVisible();
        java.awt.Paint paint10 = null;
        try {
            renderAttributes1.setDefaultFillPaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(stroke8);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Color color1 = java.awt.Color.CYAN;
        barRenderer0.setShadowPaint((java.awt.Paint) color1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryAxis4.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = categoryPlot7.getDomainGridlinePaint();
        categoryAxis4.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        java.awt.Paint paint12 = categoryPlot7.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot7.getRangeAxisLocation();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot16.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot16.setRenderer(categoryItemRenderer21);
        org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity(shape15, (org.jfree.chart.plot.Plot) categoryPlot16, "");
        categoryPlot16.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font32 = categoryAxis31.getLabelFont();
        categoryAxis28.setTickLabelFont((java.lang.Comparable) 10.0d, font32);
        java.awt.Stroke stroke34 = categoryAxis28.getTickMarkStroke();
        categoryPlot16.setDomainGridlineStroke(stroke34);
        java.lang.Comparable comparable36 = categoryPlot16.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset37 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot16.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset37);
        defaultCategoryDataset37.clearSelection();
        int int40 = defaultCategoryDataset37.getColumnCount();
        categoryPlot7.setDataset((int) (short) 1, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset37);
        org.jfree.data.Range range42 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset37);
        try {
            defaultCategoryDataset37.removeColumn((java.lang.Comparable) (-254));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Column key (-254) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNull(comparable36);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNull(range42);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setUseOutlinePaint(false);
        boolean boolean11 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 0, 4);
        java.awt.Color color13 = java.awt.Color.WHITE;
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color13.createContext(colorModel14, rectangle15, rectangle2D16, affineTransform17, renderingHints18);
        lineAndShapeRenderer2.setSeriesFillPaint(100, (java.awt.Paint) color13);
        java.lang.Boolean boolean22 = lineAndShapeRenderer2.getSeriesLinesVisible(15);
        lineAndShapeRenderer2.setSeriesShapesVisible(128, (java.lang.Boolean) false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintContext19);
        org.junit.Assert.assertNull(boolean22);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType32 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType32);
        legendItem31.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        java.lang.String str35 = legendItem31.getToolTipText();
        java.text.AttributedString attributedString36 = legendItem31.getAttributedLabel();
        java.lang.String str37 = legendItem31.getDescription();
        boolean boolean38 = legendItem31.isLineVisible();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNull(attributedString36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "hi!" + "'", str37.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        int int3 = java.awt.Color.HSBtoRGB((float) (short) 1, (float) (short) 100, 0.5f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-334) + "'", int3 == (-334));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint8 = barRenderer0.lookupSeriesOutlinePaint(0);
        java.awt.Paint paint12 = barRenderer0.getItemFillPaint(0, (int) (short) 1, true);
        barRenderer0.setBaseItemLabelsVisible(false, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator16, false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        defaultCategoryDataset22.clearSelection();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        categoryPlot26.addChangeListener(plotChangeListener27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot26.setBackgroundPaint((java.awt.Paint) color29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot26.setRenderer(categoryItemRenderer31);
        org.jfree.chart.entity.PlotEntity plotEntity34 = new org.jfree.chart.entity.PlotEntity(shape25, (org.jfree.chart.plot.Plot) categoryPlot26, "");
        categoryPlot26.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font42 = categoryAxis41.getLabelFont();
        categoryAxis38.setTickLabelFont((java.lang.Comparable) 10.0d, font42);
        java.awt.Stroke stroke44 = categoryAxis38.getTickMarkStroke();
        categoryPlot26.setDomainGridlineStroke(stroke44);
        java.lang.Comparable comparable46 = categoryPlot26.getDomainCrosshairColumnKey();
        boolean boolean47 = categoryPlot26.canSelectByPoint();
        boolean boolean48 = defaultCategoryDataset22.hasListener((java.util.EventListener) categoryPlot26);
        categoryPlot26.setRangeCrosshairValue((double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font53 = categoryAxis52.getLabelFont();
        boolean boolean54 = categoryAxis52.isMinorTickMarksVisible();
        boolean boolean55 = categoryAxis52.isAxisLineVisible();
        categoryAxis52.setAxisLineVisible(false);
        java.util.List list58 = categoryPlot26.getCategoriesForAxis(categoryAxis52);
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font62 = categoryAxis61.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = categoryAxis61.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener65 = null;
        categoryPlot64.addChangeListener(plotChangeListener65);
        java.awt.Paint paint67 = categoryPlot64.getDomainGridlinePaint();
        categoryAxis61.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot64);
        categoryPlot64.clearAnnotations();
        java.awt.Font font70 = categoryPlot64.getNoDataMessageFont();
        org.jfree.chart.axis.AxisLocation axisLocation71 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot64.setDomainAxisLocation(axisLocation71, true);
        categoryPlot26.setRangeAxisLocation((int) (byte) 100, axisLocation71);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(comparable46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(list58);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNotNull(font70);
        org.junit.Assert.assertNotNull(axisLocation71);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis1.setLabelInsets(rectangleInsets4, true);
        categoryAxis1.setLowerMargin((double) (-1));
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = categoryAxis1.hasListener(eventListener9);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.awt.Color color0 = java.awt.Color.red;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Stroke stroke3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        categoryPlot0.setOutlineStroke(stroke3);
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot6.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot6.setRenderer(categoryItemRenderer11);
        org.jfree.chart.entity.PlotEntity plotEntity14 = new org.jfree.chart.entity.PlotEntity(shape5, (org.jfree.chart.plot.Plot) categoryPlot6, "");
        boolean boolean15 = categoryPlot6.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis17.setLabelInsets(rectangleInsets18, true);
        java.util.List list21 = categoryPlot6.getCategoriesForAxis(categoryAxis17);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        categoryPlot22.addChangeListener(plotChangeListener23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot22.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        categoryPlot22.setRangeAxis(2, valueAxis27, true);
        org.jfree.chart.LegendItemCollection legendItemCollection30 = new org.jfree.chart.LegendItemCollection();
        categoryPlot22.setFixedLegendItems(legendItemCollection30);
        categoryPlot6.setFixedLegendItems(legendItemCollection30);
        java.awt.Stroke stroke33 = categoryPlot6.getDomainCrosshairStroke();
        categoryPlot0.setRangeGridlineStroke(stroke33);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) 0L);
        java.lang.Number number2 = selectableValue1.getValue();
        selectableValue1.setSelected(false);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0L + "'", number2.equals(0L));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        try {
            java.lang.Object obj3 = keyedObjects0.getObject((java.lang.Comparable) "PlotEntity: tooltip = ");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (PlotEntity: tooltip = ) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getRowKeys();
        try {
            keyedObjects2D0.removeColumn((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot0.notifyListeners(plotChangeEvent14);
        java.awt.Paint paint16 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = categoryPlot0.getOrientation();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(plotOrientation17);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot1.getLegendItems();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(legendItemCollection21);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        barRenderer0.setBase((double) 0.5f);
        barRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot10.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot10.setRenderer(categoryItemRenderer15);
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape9, (org.jfree.chart.plot.Plot) categoryPlot10, "");
        categoryPlot10.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font26 = categoryAxis25.getLabelFont();
        categoryAxis22.setTickLabelFont((java.lang.Comparable) 10.0d, font26);
        java.awt.Stroke stroke28 = categoryAxis22.getTickMarkStroke();
        categoryPlot10.setDomainGridlineStroke(stroke28);
        java.lang.Comparable comparable30 = categoryPlot10.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot10.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset31);
        org.jfree.data.Range range34 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset31, true);
        int int36 = defaultCategoryDataset31.getColumnIndex((java.lang.Comparable) 10.0f);
        try {
            defaultCategoryDataset31.setSelected(0, 3, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(comparable30);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        categoryPlot4.clearAnnotations();
        java.awt.Font font10 = categoryPlot4.getNoDataMessageFont();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setDomainAxisLocation(axisLocation11, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator18 = barRenderer14.getItemLabelGenerator(100, 100, false);
        barRenderer14.setBase((double) 0.5f);
        barRenderer14.setAutoPopulateSeriesStroke(true);
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot24.addChangeListener(plotChangeListener25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot24.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        categoryPlot24.setRenderer(categoryItemRenderer29);
        org.jfree.chart.entity.PlotEntity plotEntity32 = new org.jfree.chart.entity.PlotEntity(shape23, (org.jfree.chart.plot.Plot) categoryPlot24, "");
        categoryPlot24.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font40 = categoryAxis39.getLabelFont();
        categoryAxis36.setTickLabelFont((java.lang.Comparable) 10.0d, font40);
        java.awt.Stroke stroke42 = categoryAxis36.getTickMarkStroke();
        categoryPlot24.setDomainGridlineStroke(stroke42);
        java.lang.Comparable comparable44 = categoryPlot24.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset45 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot24.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset45);
        org.jfree.data.Range range48 = barRenderer14.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset45, true);
        int int49 = categoryPlot4.indexOf((org.jfree.data.category.CategoryDataset) defaultCategoryDataset45);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator18);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNull(comparable44);
        org.junit.Assert.assertNull(range48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        barRenderer0.setBase((double) 0.5f);
        java.lang.Object obj7 = barRenderer0.clone();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = barRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot11.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot11.setRenderer(categoryItemRenderer16);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape10, (org.jfree.chart.plot.Plot) categoryPlot11, "");
        categoryPlot11.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font27 = categoryAxis26.getLabelFont();
        categoryAxis23.setTickLabelFont((java.lang.Comparable) 10.0d, font27);
        java.awt.Stroke stroke29 = categoryAxis23.getTickMarkStroke();
        categoryPlot11.setDomainGridlineStroke(stroke29);
        java.lang.Comparable comparable31 = categoryPlot11.getDomainCrosshairColumnKey();
        barRenderer0.setPlot(categoryPlot11);
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer33.setBaseSeriesVisibleInLegend(true, false);
        barRenderer33.setItemLabelAnchorOffset((double) 8);
        java.awt.Stroke stroke42 = barRenderer33.getItemOutlineStroke((-16727872), 10, false);
        categoryPlot11.setRangeZeroBaselineStroke(stroke42);
        categoryPlot11.setNoDataMessage("hi!");
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(comparable31);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape3 = renderAttributes0.getItemShape(8, 8);
        java.awt.Shape shape4 = renderAttributes0.getDefaultShape();
        org.junit.Assert.assertNull(shape3);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        java.awt.Stroke stroke7 = categoryAxis1.getTickMarkStroke();
        java.awt.Font font8 = categoryAxis1.getLabelFont();
        java.awt.Stroke stroke9 = categoryAxis1.getTickMarkStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis1.getLabelInsets();
        categoryAxis1.setMinorTickMarkOutsideLength((float) (short) 100);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Paint paint3 = barRenderer0.lookupSeriesOutlinePaint((int) (byte) 100);
        org.jfree.chart.util.ShapeList shapeList4 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape6 = shapeList4.getShape((int) (byte) -1);
        boolean boolean7 = barRenderer0.equals((java.lang.Object) shapeList4);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        categoryPlot4.clearAnnotations();
        java.awt.Font font10 = categoryPlot4.getNoDataMessageFont();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setDomainAxisLocation(axisLocation11, true);
        org.jfree.chart.axis.AxisSpace axisSpace14 = categoryPlot4.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNull(axisSpace14);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = barRenderer4.getItemLabelGenerator(100, 100, false);
        int int9 = barRenderer4.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer4.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint12 = barRenderer4.lookupSeriesOutlinePaint(0);
        java.awt.Paint paint16 = barRenderer4.getItemFillPaint(0, (int) (short) 1, true);
        java.awt.Stroke stroke17 = barRenderer4.getBaseOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer19.setAutoPopulateSeriesShape(false);
        barRenderer19.setDefaultEntityRadius(2);
        java.awt.Stroke stroke25 = barRenderer19.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        categoryPlot26.addChangeListener(plotChangeListener27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot26.setBackgroundPaint((java.awt.Paint) color29);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font36 = categoryAxis35.getLabelFont();
        categoryAxis32.setTickLabelFont((java.lang.Comparable) 10.0d, font36);
        java.awt.Stroke stroke38 = categoryAxis32.getTickMarkStroke();
        categoryPlot26.setRangeGridlineStroke(stroke38);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent40 = null;
        categoryPlot26.notifyListeners(plotChangeEvent40);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot26.getRangeAxisEdge(3);
        barRenderer19.setPlot(categoryPlot26);
        boolean boolean46 = barRenderer19.isSeriesVisible((int) (short) 10);
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer19.setBaseShape(shape47, false);
        barRenderer4.setLegendShape((int) (byte) 10, shape47);
        java.awt.Paint paint51 = null;
        try {
            org.jfree.chart.LegendItem legendItem52 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "CategoryAnchor.START", "", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", shape47, paint51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(shape47);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType32 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType32);
        legendItem31.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        java.lang.String str35 = legendItem31.getToolTipText();
        java.awt.Paint paint36 = legendItem31.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font42 = categoryAxis41.getLabelFont();
        categoryAxis38.setTickLabelFont((java.lang.Comparable) 10.0d, font42);
        java.awt.Stroke stroke44 = categoryAxis38.getTickMarkStroke();
        java.awt.Font font45 = categoryAxis38.getLabelFont();
        legendItem31.setLabelFont(font45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font49 = categoryAxis48.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor50 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = categoryAxis48.getCategoryJava2DCoordinate(categoryAnchor50, (int) (byte) 100, (int) (byte) 1, rectangle2D53, rectangleEdge54);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font58 = categoryAxis57.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = categoryAxis57.getTickLabelInsets();
        java.awt.Color color60 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis57.setLabelPaint((java.awt.Paint) color60);
        categoryAxis48.setAxisLinePaint((java.awt.Paint) color60);
        legendItem31.setLinePaint((java.awt.Paint) color60);
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis68 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font69 = categoryAxis68.getLabelFont();
        categoryAxis65.setTickLabelFont((java.lang.Comparable) 10.0d, font69);
        java.awt.Stroke stroke71 = categoryAxis65.getTickMarkStroke();
        java.awt.Font font72 = categoryAxis65.getLabelFont();
        java.awt.Stroke stroke73 = categoryAxis65.getTickMarkStroke();
        java.awt.Color color77 = java.awt.Color.getHSBColor(0.0f, (float) (byte) 100, (float) 100);
        categoryAxis65.setTickMarkPaint((java.awt.Paint) color77);
        legendItem31.setLabelPaint((java.awt.Paint) color77);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(font69);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(font72);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(color77);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        categoryPlot2.addChangeListener(plotChangeListener3);
        java.awt.Paint paint5 = categoryPlot2.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        boolean boolean8 = categoryPlot2.removeDomainMarker(marker6, layer7);
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot2.getDataset(100);
        boolean boolean11 = categoryPlot2.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot2.getLegendItems();
        categoryPlot2.setRangeCrosshairValue((-9.0d));
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator16 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj17 = standardCategorySeriesLabelGenerator16.clone();
        java.lang.Object obj18 = null;
        boolean boolean19 = standardCategorySeriesLabelGenerator16.equals(obj18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font22 = categoryAxis21.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryAxis21.getTickLabelInsets();
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis21.setLabelPaint((java.awt.Paint) color24);
        boolean boolean26 = standardCategorySeriesLabelGenerator16.equals((java.lang.Object) color24);
        categoryPlot2.setDomainGridlinePaint((java.awt.Paint) color24);
        org.jfree.chart.axis.AxisSpace axisSpace28 = null;
        categoryPlot2.setFixedRangeAxisSpace(axisSpace28, false);
        java.awt.Paint paint31 = categoryPlot2.getOutlinePaint();
        boolean boolean32 = keyedObjects0.equals((java.lang.Object) paint31);
        int int33 = keyedObjects0.getItemCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(categoryDataset10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray6 = new java.awt.Paint[] { color3, color5 };
        java.awt.Color color7 = java.awt.Color.YELLOW;
        int int8 = color7.getBlue();
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Color color10 = java.awt.Color.WHITE;
        java.awt.Color color11 = color10.darker();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color7, color9, color11, color12 };
        java.awt.Stroke stroke14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray16 = new java.awt.Stroke[] { stroke14, stroke15 };
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font22 = categoryAxis21.getLabelFont();
        categoryAxis18.setTickLabelFont((java.lang.Comparable) 10.0d, font22);
        java.awt.Stroke stroke24 = categoryAxis18.getTickMarkStroke();
        java.awt.Stroke[] strokeArray25 = new java.awt.Stroke[] { stroke24 };
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray27 = new java.awt.Shape[] { shape26 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier28 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray6, paintArray13, strokeArray16, strokeArray25, shapeArray27);
        java.lang.Object obj29 = defaultDrawingSupplier28.clone();
        java.awt.Stroke stroke30 = defaultDrawingSupplier28.getNextStroke();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paintArray6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(strokeArray25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(shapeArray27);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        java.lang.Object obj2 = datasetGroup1.clone();
        java.lang.Object obj3 = null;
        boolean boolean4 = datasetGroup1.equals(obj3);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor2, 0, (int) ' ', rectangle2D5, rectangleEdge6);
        categoryAxis1.setCategoryMargin((double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis1.setTickLabelInsets(rectangleInsets10);
        int int12 = categoryAxis1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 4 + "'", int12 == 4);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape3 = renderAttributes0.getItemShape(8, 8);
        java.awt.Paint paint6 = renderAttributes0.getItemFillPaint((int) (short) 100, (int) '4');
        java.awt.Paint paint8 = renderAttributes0.getSeriesFillPaint(101);
        java.lang.Boolean boolean9 = renderAttributes0.getDefaultLabelVisible();
        org.junit.Assert.assertNull(shape3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font6 = categoryAxis5.getLabelFont();
        boolean boolean7 = categoryAxis5.isMinorTickMarksVisible();
        boolean boolean8 = categoryAxis5.isAxisLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis5.getTickLabelInsets();
        categoryPlot0.setDomainAxis(categoryAxis5);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getLegendItems();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot16.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot16.setRenderer(categoryItemRenderer21);
        org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity(shape15, (org.jfree.chart.plot.Plot) categoryPlot16, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot25.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font35 = categoryAxis34.getLabelFont();
        categoryAxis31.setTickLabelFont((java.lang.Comparable) 10.0d, font35);
        java.awt.Stroke stroke37 = categoryAxis31.getTickMarkStroke();
        categoryPlot25.setRangeGridlineStroke(stroke37);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color41 = java.awt.Color.getColor("", color40);
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape15, stroke37, (java.awt.Paint) color41);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font48 = categoryAxis47.getLabelFont();
        categoryAxis44.setTickLabelFont((java.lang.Comparable) 10.0d, font48);
        legendItem42.setLabelFont(font48);
        legendItem42.setShapeVisible(false);
        legendItemCollection10.add(legendItem42);
        java.awt.Shape shape54 = legendItem42.getLine();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(shape54);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setUseOutlinePaint(false);
        boolean boolean11 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 0, 4);
        java.awt.Color color13 = java.awt.Color.WHITE;
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color13.createContext(colorModel14, rectangle15, rectangle2D16, affineTransform17, renderingHints18);
        lineAndShapeRenderer2.setSeriesFillPaint(100, (java.awt.Paint) color13);
        java.lang.Boolean boolean22 = lineAndShapeRenderer2.getSeriesLinesVisible(15);
        java.lang.Object obj23 = lineAndShapeRenderer2.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintContext19);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        boolean boolean25 = categoryAxis23.isMinorTickMarksVisible();
        boolean boolean26 = categoryAxis23.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray27 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis23 };
        categoryPlot1.setDomainAxes(categoryAxisArray27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        categoryPlot1.setFixedDomainAxisSpace(axisSpace29, true);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray27);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator3);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        boolean boolean6 = categoryPlot0.isRangePannable();
        java.lang.Comparable comparable7 = null;
        categoryPlot0.setDomainCrosshairRowKey(comparable7);
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            boolean boolean12 = categoryPlot0.removeRangeMarker(35, marker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("CategoryAnchor.END");
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        double double9 = categoryAxis1.getLabelAngle();
        float float10 = categoryAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        java.awt.Color color4 = java.awt.Color.green;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        barRenderer0.setSeriesToolTipGenerator(0, categoryToolTipGenerator7, true);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font15 = categoryAxis14.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis14.getCategoryJava2DCoordinate(categoryAnchor16, (int) (byte) 100, (int) (byte) 1, rectangle2D19, rectangleEdge20);
        int int22 = categoryAxis14.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke23 = categoryAxis14.getTickMarkStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis14.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset26 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D32 = barRenderer0.createHotSpotBounds(graphics2D10, rectangle2D11, categoryPlot12, categoryAxis14, valueAxis25, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset26, 100, (int) 'a', true, categoryItemRendererState30, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape4 = renderAttributes1.getItemShape(8, 8);
        java.awt.Stroke stroke6 = renderAttributes1.getSeriesStroke(100);
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        renderAttributes1.setSeriesStroke(128, stroke8);
        boolean boolean10 = plotOrientation0.equals((java.lang.Object) 128);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNull(stroke6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        barRenderer0.setSeriesOutlinePaint(0, paint7, true);
        barRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = barRenderer0.getLegendItemLabelGenerator();
        java.awt.Paint paint14 = barRenderer0.getSeriesPaint((int) (byte) 100);
        java.awt.Paint paint18 = barRenderer0.getItemFillPaint((int) (short) 0, 8, false);
        java.awt.Paint paint22 = barRenderer0.getItemPaint(100, (int) (byte) 1, false);
        barRenderer0.setDefaultEntityRadius((-1));
        barRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape0, jFreeChart1, chartChangeEventType2);
        java.lang.String str4 = chartChangeEvent3.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = chartChangeEvent3.getType();
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        chartChangeEvent3.setChart(jFreeChart6);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        chartChangeEvent3.setChart(jFreeChart8);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]"));
        org.junit.Assert.assertNotNull(chartChangeEventType5);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        float float7 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setLabelAngle((double) (short) 100);
        java.awt.Paint paint10 = null;
        try {
            categoryAxis1.setTickLabelPaint(paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot6.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot6.setRenderer(categoryItemRenderer11);
        org.jfree.chart.entity.PlotEntity plotEntity14 = new org.jfree.chart.entity.PlotEntity(shape5, (org.jfree.chart.plot.Plot) categoryPlot6, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot15.setBackgroundPaint((java.awt.Paint) color18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font25 = categoryAxis24.getLabelFont();
        categoryAxis21.setTickLabelFont((java.lang.Comparable) 10.0d, font25);
        java.awt.Stroke stroke27 = categoryAxis21.getTickMarkStroke();
        categoryPlot15.setRangeGridlineStroke(stroke27);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color31 = java.awt.Color.getColor("", color30);
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape5, stroke27, (java.awt.Paint) color31);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType33 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer34 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType33);
        legendItem32.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer34);
        java.lang.String str36 = legendItem32.getToolTipText();
        boolean boolean37 = legendItem32.isShapeFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener39 = null;
        categoryPlot38.addChangeListener(plotChangeListener39);
        java.awt.Paint paint41 = categoryPlot38.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker42 = null;
        org.jfree.chart.util.Layer layer43 = null;
        boolean boolean44 = categoryPlot38.removeDomainMarker(marker42, layer43);
        org.jfree.data.category.CategoryDataset categoryDataset46 = categoryPlot38.getDataset(100);
        boolean boolean47 = categoryPlot38.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = null;
        int int49 = categoryPlot38.getIndexOf(categoryItemRenderer48);
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer50.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener55 = null;
        categoryPlot54.addChangeListener(plotChangeListener55);
        java.awt.Paint paint57 = categoryPlot54.getDomainGridlinePaint();
        barRenderer50.setSeriesOutlinePaint(0, paint57, true);
        barRenderer50.setBaseItemLabelsVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent62 = null;
        barRenderer50.notifyListeners(rendererChangeEvent62);
        categoryPlot38.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer50);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent65 = null;
        categoryPlot38.markerChanged(markerChangeEvent65);
        java.awt.Stroke stroke67 = categoryPlot38.getRangeZeroBaselineStroke();
        legendItem32.setOutlineStroke(stroke67);
        org.jfree.data.KeyedObject keyedObject69 = new org.jfree.data.KeyedObject((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (java.lang.Object) legendItem32);
        java.lang.Object obj70 = keyedObject69.getObject();
        java.lang.Object obj71 = keyedObject69.getObject();
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(gradientPaintTransformType33);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "hi!" + "'", str36.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(categoryDataset46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(obj70);
        org.junit.Assert.assertNotNull(obj71);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        boolean boolean3 = categoryAxis1.isMinorTickMarksVisible();
        float float4 = categoryAxis1.getTickMarkInsideLength();
        java.awt.Paint paint5 = null;
        try {
            categoryAxis1.setLabelPaint(paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        java.awt.Stroke stroke9 = barRenderer0.getItemOutlineStroke((-16727872), 10, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = null;
        barRenderer13.setBaseItemLabelGenerator(categoryItemLabelGenerator14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = new org.jfree.chart.labels.ItemLabelPosition();
        java.awt.Color color18 = java.awt.Color.WHITE;
        java.awt.Color color19 = color18.darker();
        boolean boolean20 = itemLabelPosition17.equals((java.lang.Object) color18);
        barRenderer13.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        java.lang.Object obj23 = null;
        boolean boolean24 = itemLabelPosition17.equals(obj23);
        barRenderer0.setSeriesNegativeItemLabelPosition((int) '#', itemLabelPosition17, false);
        int int27 = barRenderer0.getDefaultEntityRadius();
        java.awt.Stroke stroke28 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        barRenderer0.setBaseOutlineStroke(stroke28, false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape0, jFreeChart1, chartChangeEventType2);
        java.lang.String str4 = chartChangeEvent3.toString();
        java.lang.Object obj5 = chartChangeEvent3.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType6 = chartChangeEvent3.getType();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]"));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(chartChangeEventType6);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        boolean boolean7 = barRenderer0.isItemLabelVisible((int) (byte) 10, 0, true);
        boolean boolean9 = barRenderer0.isSeriesItemLabelsVisible(4);
        java.lang.Boolean boolean11 = barRenderer0.getSeriesVisibleInLegend((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(boolean11);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        java.lang.String str10 = plotEntity9.toString();
        java.lang.String str11 = plotEntity9.toString();
        java.lang.String str12 = plotEntity9.getShapeType();
        java.lang.String str13 = plotEntity9.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PlotEntity: tooltip = " + "'", str10.equals("PlotEntity: tooltip = "));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "PlotEntity: tooltip = " + "'", str11.equals("PlotEntity: tooltip = "));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "rect" + "'", str12.equals("rect"));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "PlotEntity: tooltip = " + "'", str13.equals("PlotEntity: tooltip = "));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        barRenderer0.setSeriesOutlinePaint(0, paint7, true);
        barRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = barRenderer0.getLegendItemLabelGenerator();
        java.awt.Paint paint14 = barRenderer0.getSeriesPaint((int) (byte) 100);
        java.awt.Paint paint18 = barRenderer0.getItemFillPaint((int) (short) 0, 8, false);
        java.awt.Paint paint22 = barRenderer0.getItemPaint(100, (int) (byte) 1, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator28 = barRenderer24.getItemLabelGenerator(100, 100, false);
        int int29 = barRenderer24.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = barRenderer24.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint32 = barRenderer24.lookupSeriesOutlinePaint(0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator34 = null;
        barRenderer33.setBaseItemLabelGenerator(categoryItemLabelGenerator34, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition37 = new org.jfree.chart.labels.ItemLabelPosition();
        java.awt.Color color38 = java.awt.Color.WHITE;
        java.awt.Color color39 = color38.darker();
        boolean boolean40 = itemLabelPosition37.equals((java.lang.Object) color38);
        barRenderer33.setBasePositiveItemLabelPosition(itemLabelPosition37, false);
        barRenderer24.setPositiveItemLabelPositionFallback(itemLabelPosition37);
        org.jfree.chart.renderer.category.BarRenderer barRenderer44 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer44.setAutoPopulateSeriesShape(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer47 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator48 = null;
        barRenderer47.setBaseItemLabelGenerator(categoryItemLabelGenerator48, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition51 = new org.jfree.chart.labels.ItemLabelPosition();
        java.awt.Color color52 = java.awt.Color.WHITE;
        java.awt.Color color53 = color52.darker();
        boolean boolean54 = itemLabelPosition51.equals((java.lang.Object) color52);
        barRenderer47.setBasePositiveItemLabelPosition(itemLabelPosition51, false);
        barRenderer44.setBasePositiveItemLabelPosition(itemLabelPosition51, false);
        barRenderer24.setBaseNegativeItemLabelPosition(itemLabelPosition51, true);
        barRenderer0.setSeriesNegativeItemLabelPosition(0, itemLabelPosition51);
        org.jfree.chart.text.TextAnchor textAnchor62 = itemLabelPosition51.getTextAnchor();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNull(categoryItemLabelGenerator28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(textAnchor62);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        java.lang.Boolean boolean8 = lineAndShapeRenderer2.getSeriesShapesFilled(15);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            lineAndShapeRenderer2.addAnnotation(categoryAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(boolean8);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        boolean boolean7 = barRenderer0.isItemLabelVisible((int) (byte) 10, 0, true);
        boolean boolean9 = barRenderer0.isSeriesItemLabelsVisible(4);
        boolean boolean10 = barRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            categoryPlot0.addRangeMarker(0, marker5, layer6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        categoryPlot0.setDomainCrosshairVisible(false);
        java.awt.Stroke stroke9 = categoryPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        categoryPlot0.select((double) (-1L), (double) 100, rectangle2D4, renderingSource5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        int int8 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getInsets();
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot0.getRangeMarkers(layer10);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        boolean boolean3 = categoryAxis1.isMinorTickMarksVisible();
        float float4 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setLabelAngle(0.0d);
        int int7 = categoryAxis1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        defaultCategoryDataset22.clearSelection();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        categoryPlot26.addChangeListener(plotChangeListener27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot26.setBackgroundPaint((java.awt.Paint) color29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot26.setRenderer(categoryItemRenderer31);
        org.jfree.chart.entity.PlotEntity plotEntity34 = new org.jfree.chart.entity.PlotEntity(shape25, (org.jfree.chart.plot.Plot) categoryPlot26, "");
        categoryPlot26.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font42 = categoryAxis41.getLabelFont();
        categoryAxis38.setTickLabelFont((java.lang.Comparable) 10.0d, font42);
        java.awt.Stroke stroke44 = categoryAxis38.getTickMarkStroke();
        categoryPlot26.setDomainGridlineStroke(stroke44);
        java.lang.Comparable comparable46 = categoryPlot26.getDomainCrosshairColumnKey();
        boolean boolean47 = categoryPlot26.canSelectByPoint();
        boolean boolean48 = defaultCategoryDataset22.hasListener((java.util.EventListener) categoryPlot26);
        categoryPlot26.setRangeCrosshairValue((double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font53 = categoryAxis52.getLabelFont();
        boolean boolean54 = categoryAxis52.isMinorTickMarksVisible();
        boolean boolean55 = categoryAxis52.isAxisLineVisible();
        categoryAxis52.setAxisLineVisible(false);
        java.util.List list58 = categoryPlot26.getCategoriesForAxis(categoryAxis52);
        org.jfree.chart.axis.ValueAxis valueAxis59 = categoryPlot26.getRangeAxis();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(comparable46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(list58);
        org.junit.Assert.assertNull(valueAxis59);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot4.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot4.setRenderer(categoryItemRenderer9);
        org.jfree.chart.entity.PlotEntity plotEntity12 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) categoryPlot4, "");
        categoryPlot4.setBackgroundAlpha((float) 10L);
        keyedObjects0.setObject((java.lang.Comparable) 10.0f, (java.lang.Object) 10L);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType17 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer18 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType17);
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot20.setBackgroundPaint((java.awt.Paint) color23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot20.setRenderer(categoryItemRenderer25);
        org.jfree.chart.entity.PlotEntity plotEntity28 = new org.jfree.chart.entity.PlotEntity(shape19, (org.jfree.chart.plot.Plot) categoryPlot20, "");
        boolean boolean29 = categoryPlot20.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis31.setLabelInsets(rectangleInsets32, true);
        java.util.List list35 = categoryPlot20.getCategoriesForAxis(categoryAxis31);
        java.awt.Color color36 = java.awt.Color.ORANGE;
        categoryAxis31.setTickMarkPaint((java.awt.Paint) color36);
        boolean boolean38 = standardGradientPaintTransformer18.equals((java.lang.Object) categoryAxis31);
        keyedObjects0.setObject((java.lang.Comparable) 0.0d, (java.lang.Object) standardGradientPaintTransformer18);
        try {
            java.lang.Comparable comparable41 = keyedObjects0.getKey((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(gradientPaintTransformType17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        java.lang.String str10 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        java.awt.Font font12 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 1);
        int int13 = categoryAxis1.getMaximumCategoryLabelLines();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        java.lang.String str10 = plotEntity9.toString();
        java.lang.Object obj11 = plotEntity9.clone();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator12 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator13 = null;
        java.lang.String str14 = plotEntity9.getImageMapAreaTag(toolTipTagFragmentGenerator12, uRLTagFragmentGenerator13);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "PlotEntity: tooltip = " + "'", str10.equals("PlotEntity: tooltip = "));
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.util.UnitType unitType4 = rectangleInsets3.getUnitType();
        double double6 = rectangleInsets3.extendHeight((double) (short) 1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(unitType4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 5.0d + "'", double6 == 5.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis1.setLabelInsets(rectangleInsets4, true);
        double double8 = rectangleInsets4.calculateBottomOutset((double) (byte) 10);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets4.createAdjustedRectangle(rectangle2D9, lengthAdjustmentType10, lengthAdjustmentType11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.panRangeAxes((double) (short) 1, plotRenderingInfo11, point2D12);
        float float14 = categoryPlot0.getBackgroundImageAlpha();
        categoryPlot0.clearSelection();
        org.jfree.chart.plot.Marker marker16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        try {
            boolean boolean18 = categoryPlot0.removeRangeMarker(marker16, layer17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        categoryPlot0.select((double) (-1L), (double) 100, rectangle2D4, renderingSource5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        int int8 = categoryPlot0.getDomainAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        categoryPlot0.setRangeAxis((int) (byte) 1, valueAxis10);
        boolean boolean12 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        categoryPlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot3.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot8.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color11, color13 };
        java.awt.Color color15 = java.awt.Color.YELLOW;
        int int16 = color15.getBlue();
        java.awt.Color color17 = java.awt.Color.ORANGE;
        java.awt.Color color18 = java.awt.Color.WHITE;
        java.awt.Color color19 = color18.darker();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color15, color17, color19, color20 };
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray24 = new java.awt.Stroke[] { stroke22, stroke23 };
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font30 = categoryAxis29.getLabelFont();
        categoryAxis26.setTickLabelFont((java.lang.Comparable) 10.0d, font30);
        java.awt.Stroke stroke32 = categoryAxis26.getTickMarkStroke();
        java.awt.Stroke[] strokeArray33 = new java.awt.Stroke[] { stroke32 };
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray35 = new java.awt.Shape[] { shape34 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray14, paintArray21, strokeArray24, strokeArray33, shapeArray35);
        categoryPlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier36);
        org.jfree.chart.entity.PlotEntity plotEntity40 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot3, "ChartChangeEventType.DATASET_UPDATED", "hi!");
        java.lang.String str41 = plotEntity40.getURLText();
        plotEntity40.setURLText("PlotEntity: tooltip = ");
        java.lang.String str44 = plotEntity40.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(strokeArray33);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shapeArray35);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "PlotEntity: tooltip = ChartChangeEventType.DATASET_UPDATED" + "'", str44.equals("PlotEntity: tooltip = ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape0, jFreeChart1, chartChangeEventType2);
        java.lang.String str4 = chartChangeEvent3.toString();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape5, jFreeChart6, chartChangeEventType7);
        chartChangeEvent3.setType(chartChangeEventType7);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.Object obj11 = null;
        boolean boolean12 = chartChangeEventType10.equals(obj11);
        boolean boolean14 = chartChangeEventType10.equals((java.lang.Object) (short) 100);
        chartChangeEvent3.setType(chartChangeEventType10);
        org.jfree.chart.JFreeChart jFreeChart16 = chartChangeEvent3.getChart();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]"));
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(jFreeChart16);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.util.List list1 = keyedObjects0.getKeys();
        java.lang.Object obj2 = keyedObjects0.clone();
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot1.getRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot11.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font21 = categoryAxis20.getLabelFont();
        categoryAxis17.setTickLabelFont((java.lang.Comparable) 10.0d, font21);
        java.awt.Stroke stroke23 = categoryAxis17.getTickMarkStroke();
        categoryPlot11.setRangeGridlineStroke(stroke23);
        java.awt.Color color26 = java.awt.Color.WHITE;
        java.awt.Color color27 = color26.darker();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator31 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color26, (float) 100L, 10, (double) 0L);
        categoryPlot11.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator31);
        categoryPlot1.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator31);
        categoryPlot1.setRangeCrosshairValue((double) (-334), true);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("PlotEntity: tooltip = ");
        categoryAxis1.setTickLabelsVisible(true);
        categoryAxis1.clearCategoryLabelToolTips();
        categoryAxis1.setLabelToolTip("GradientPaintTransformType.CENTER_VERTICAL");
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint8 = barRenderer0.getLegendTextPaint(4);
        java.awt.Paint paint10 = barRenderer0.lookupLegendTextPaint(35);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        java.lang.String str2 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SortOrder.ASCENDING" + "'", str2.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        boolean boolean3 = categoryAxis1.isMinorTickMarksVisible();
        categoryAxis1.setLabelToolTip("UnitType.ABSOLUTE");
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.panRangeAxes((double) (short) 1, plotRenderingInfo11, point2D12);
        float float14 = categoryPlot0.getBackgroundImageAlpha();
        categoryPlot0.clearSelection();
        float float16 = categoryPlot0.getBackgroundImageAlpha();
        org.jfree.chart.plot.Marker marker17 = null;
        boolean boolean18 = categoryPlot0.removeDomainMarker(marker17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.5f + "'", float16 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(valueAxis19);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 10, plotRenderingInfo3, point2D4, false);
        org.jfree.chart.util.SortOrder sortOrder7 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder7);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        java.awt.Paint paint13 = categoryPlot10.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot10.removeDomainMarker(marker14, layer15);
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot10.getDataset(100);
        boolean boolean19 = categoryPlot10.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection20 = categoryPlot10.getLegendItems();
        categoryPlot10.setRangeCrosshairValue((-9.0d));
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator24 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj25 = standardCategorySeriesLabelGenerator24.clone();
        java.lang.Object obj26 = null;
        boolean boolean27 = standardCategorySeriesLabelGenerator24.equals(obj26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font30 = categoryAxis29.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryAxis29.getTickLabelInsets();
        java.awt.Color color32 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis29.setLabelPaint((java.awt.Paint) color32);
        boolean boolean34 = standardCategorySeriesLabelGenerator24.equals((java.lang.Object) color32);
        categoryPlot10.setDomainGridlinePaint((java.awt.Paint) color32);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator39 = new org.jfree.chart.util.DefaultShadowGenerator(3, color32, (float) (short) 100, 1, 1.0d);
        boolean boolean40 = sortOrder7.equals((java.lang.Object) defaultShadowGenerator39);
        double double41 = defaultShadowGenerator39.getAngle();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(categoryDataset18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        barRenderer0.setDefaultEntityRadius(2);
        java.awt.Stroke stroke6 = barRenderer0.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.renderer.RenderAttributes renderAttributes9 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Font font10 = renderAttributes9.getDefaultLabelFont();
        java.awt.Color color14 = java.awt.Color.getHSBColor(0.0f, (float) (byte) 100, (float) 100);
        renderAttributes9.setDefaultLabelPaint((java.awt.Paint) color14);
        barRenderer0.setSeriesItemLabelPaint(1, (java.awt.Paint) color14);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = barRenderer0.getURLGenerator((int) '#', 1, false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(font10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(categoryURLGenerator20);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        barRenderer0.setDefaultEntityRadius(2);
        java.awt.Stroke stroke6 = barRenderer0.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot7.setRangeGridlineStroke(stroke19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        categoryPlot7.notifyListeners(plotChangeEvent21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot7.getRangeAxisEdge(3);
        barRenderer0.setPlot(categoryPlot7);
        boolean boolean27 = barRenderer0.isSeriesVisible((int) (short) 10);
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setBaseShape(shape28, false);
        barRenderer0.setSeriesItemLabelsVisible(128, (java.lang.Boolean) true);
        java.awt.Color color34 = java.awt.Color.lightGray;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color34, true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(color34);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        org.jfree.chart.util.SortOrder sortOrder2 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str3 = sortOrder2.toString();
        keyedObjects0.sortByObjects(sortOrder2);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(sortOrder2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SortOrder.ASCENDING" + "'", str3.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke2 = renderAttributes0.getSeriesStroke((int) (short) -1);
        java.awt.Color color3 = java.awt.Color.blue;
        renderAttributes0.setDefaultPaint((java.awt.Paint) color3);
        org.jfree.chart.ChartColor chartColor9 = new org.jfree.chart.ChartColor(8, (int) (byte) 1, (int) '#');
        int int10 = chartColor9.getRed();
        renderAttributes0.setSeriesFillPaint((int) (byte) 1, (java.awt.Paint) chartColor9);
        java.awt.Stroke stroke12 = renderAttributes0.getDefaultStroke();
        java.awt.Paint paint15 = renderAttributes0.getItemFillPaint(4, 255);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        org.jfree.chart.LegendItemCollection legendItemCollection19 = categoryPlot16.getFixedLegendItems();
        java.awt.Paint paint20 = categoryPlot16.getNoDataMessagePaint();
        renderAttributes0.setDefaultLabelPaint(paint20);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
        org.junit.Assert.assertNull(stroke12);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNull(legendItemCollection19);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        lineAndShapeRenderer2.clearSeriesPaints(true);
        lineAndShapeRenderer2.setUseFillPaint(true);
        boolean boolean10 = lineAndShapeRenderer2.getUseFillPaint();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("PlotEntity: tooltip = ");
        float float2 = categoryAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        defaultCategoryDataset22.clearSelection();
        java.util.List list25 = defaultCategoryDataset22.getColumnKeys();
        defaultCategoryDataset22.fireSelectionEvent();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(list25);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.awt.Color color1 = java.awt.Color.GRAY;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("", (java.awt.Paint) color1);
        boolean boolean3 = legendItem2.isShapeVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis1.setLabelInsets(rectangleInsets4, true);
        categoryAxis1.setLabelURL("ItemLabelAnchor.OUTSIDE4");
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor(8, (int) (byte) 1, (int) '#');
        int int11 = chartColor10.getRed();
        categoryPlot0.setBackgroundPaint((java.awt.Paint) chartColor10);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = categoryPlot0.getOrientation();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertNotNull(plotOrientation13);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot25.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot25.setRenderer(categoryItemRenderer30);
        org.jfree.chart.entity.PlotEntity plotEntity33 = new org.jfree.chart.entity.PlotEntity(shape24, (org.jfree.chart.plot.Plot) categoryPlot25, "");
        java.lang.String str34 = plotEntity33.toString();
        boolean boolean35 = defaultCategoryDataset22.equals((java.lang.Object) plotEntity33);
        try {
            java.lang.Comparable comparable37 = defaultCategoryDataset22.getColumnKey(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PlotEntity: tooltip = " + "'", str34.equals("PlotEntity: tooltip = "));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesVisible((int) (short) 0);
        org.jfree.chart.LegendItem legendItem7 = lineAndShapeRenderer2.getLegendItem((int) (short) -1, 35);
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(legendItem7);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        categoryPlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot3.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot8.setBackgroundPaint((java.awt.Paint) color11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray14 = new java.awt.Paint[] { color11, color13 };
        java.awt.Color color15 = java.awt.Color.YELLOW;
        int int16 = color15.getBlue();
        java.awt.Color color17 = java.awt.Color.ORANGE;
        java.awt.Color color18 = java.awt.Color.WHITE;
        java.awt.Color color19 = color18.darker();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color15, color17, color19, color20 };
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke23 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray24 = new java.awt.Stroke[] { stroke22, stroke23 };
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font30 = categoryAxis29.getLabelFont();
        categoryAxis26.setTickLabelFont((java.lang.Comparable) 10.0d, font30);
        java.awt.Stroke stroke32 = categoryAxis26.getTickMarkStroke();
        java.awt.Stroke[] strokeArray33 = new java.awt.Stroke[] { stroke32 };
        java.awt.Shape shape34 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray35 = new java.awt.Shape[] { shape34 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray14, paintArray21, strokeArray24, strokeArray33, shapeArray35);
        categoryPlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier36);
        org.jfree.chart.entity.PlotEntity plotEntity40 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot3, "ChartChangeEventType.DATASET_UPDATED", "hi!");
        java.lang.String str41 = plotEntity40.getURLText();
        java.lang.String str42 = plotEntity40.toString();
        java.lang.Object obj43 = null;
        boolean boolean44 = plotEntity40.equals(obj43);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintArray14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(strokeArray33);
        org.junit.Assert.assertNotNull(shape34);
        org.junit.Assert.assertNotNull(shapeArray35);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "hi!" + "'", str41.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "PlotEntity: tooltip = ChartChangeEventType.DATASET_UPDATED" + "'", str42.equals("PlotEntity: tooltip = ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundImageAlignment(10);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot1.rendererChanged(rendererChangeEvent12);
        categoryPlot1.setDomainCrosshairColumnKey((java.lang.Comparable) "GradientPaintTransformType.CENTER_VERTICAL", false);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        categoryPlot17.addChangeListener(plotChangeListener18);
        java.awt.Paint paint20 = categoryPlot17.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = categoryPlot17.removeDomainMarker(marker21, layer22);
        org.jfree.data.category.CategoryDataset categoryDataset25 = categoryPlot17.getDataset(100);
        boolean boolean26 = categoryPlot17.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = categoryPlot17.getLegendItems();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = categoryPlot17.getDatasetRenderingOrder();
        categoryPlot1.setDatasetRenderingOrder(datasetRenderingOrder28);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(categoryDataset25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(legendItemCollection27);
        org.junit.Assert.assertNotNull(datasetRenderingOrder28);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        categoryPlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot3.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot3.setRenderer(categoryItemRenderer8);
        org.jfree.chart.entity.PlotEntity plotEntity11 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot3, "");
        categoryPlot3.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font19 = categoryAxis18.getLabelFont();
        categoryAxis15.setTickLabelFont((java.lang.Comparable) 10.0d, font19);
        java.awt.Stroke stroke21 = categoryAxis15.getTickMarkStroke();
        categoryPlot3.setDomainGridlineStroke(stroke21);
        java.lang.Comparable comparable23 = categoryPlot3.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot3.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = categoryPlot26.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.RenderingSource renderingSource31 = null;
        categoryPlot26.select((double) (-1L), (double) 100, rectangle2D30, renderingSource31);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray33 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot26.setRenderers(categoryItemRendererArray33);
        defaultCategoryDataset24.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot26);
        defaultCategoryDataset24.fireSelectionEvent();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo37 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent38 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) keyedObjects2D0, (org.jfree.data.general.Dataset) defaultCategoryDataset24, datasetChangeInfo37);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection40 = categoryPlot39.getFixedLegendItems();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent41 = null;
        categoryPlot39.axisChanged(axisChangeEvent41);
        int int43 = categoryPlot39.getRangeAxisCount();
        categoryPlot39.setAnchorValue(0.0d);
        keyedObjects2D0.setObject((java.lang.Object) categoryPlot39, (java.lang.Comparable) (-1.0d), (java.lang.Comparable) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(comparable23);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertNotNull(categoryItemRendererArray33);
        org.junit.Assert.assertNull(legendItemCollection40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        lineAndShapeRenderer2.clearSeriesPaints(true);
        lineAndShapeRenderer2.setUseFillPaint(true);
        boolean boolean10 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = lineAndShapeRenderer2.getSeriesPositiveItemLabelPosition((int) (byte) 0);
        boolean boolean13 = lineAndShapeRenderer2.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        categoryPlot4.clearAnnotations();
        java.awt.Font font10 = categoryPlot4.getNoDataMessageFont();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setDomainAxisLocation(axisLocation11, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font16 = categoryAxis15.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryAxis15.getTickLabelInsets();
        categoryPlot4.setAxisOffset(rectangleInsets17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer19.setAutoPopulateSeriesShape(false);
        barRenderer19.setDefaultEntityRadius(2);
        java.awt.Stroke stroke25 = barRenderer19.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        categoryPlot26.addChangeListener(plotChangeListener27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot26.setBackgroundPaint((java.awt.Paint) color29);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font36 = categoryAxis35.getLabelFont();
        categoryAxis32.setTickLabelFont((java.lang.Comparable) 10.0d, font36);
        java.awt.Stroke stroke38 = categoryAxis32.getTickMarkStroke();
        categoryPlot26.setRangeGridlineStroke(stroke38);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent40 = null;
        categoryPlot26.notifyListeners(plotChangeEvent40);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot26.getRangeAxisEdge(3);
        barRenderer19.setPlot(categoryPlot26);
        boolean boolean46 = barRenderer19.isSeriesVisible((int) (short) 10);
        java.awt.Font font48 = barRenderer19.getLegendTextFont((-16727872));
        boolean boolean49 = rectangleInsets17.equals((java.lang.Object) barRenderer19);
        double double51 = rectangleInsets17.calculateLeftInset((double) 2.0f);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNull(font48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 4.0d + "'", double51 == 4.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape0, jFreeChart1, chartChangeEventType2);
        java.lang.String str4 = chartChangeEvent3.toString();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape5, jFreeChart6, chartChangeEventType7);
        chartChangeEvent3.setType(chartChangeEventType7);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent3.setType(chartChangeEventType10);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = chartChangeEvent3.getType();
        org.jfree.chart.JFreeChart jFreeChart13 = chartChangeEvent3.getChart();
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.JFreeChart jFreeChart15 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType16 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent17 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape14, jFreeChart15, chartChangeEventType16);
        java.lang.String str18 = chartChangeEvent17.toString();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.JFreeChart jFreeChart20 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType21 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent22 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape19, jFreeChart20, chartChangeEventType21);
        chartChangeEvent17.setType(chartChangeEventType21);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType24 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.Object obj25 = null;
        boolean boolean26 = chartChangeEventType24.equals(obj25);
        boolean boolean28 = chartChangeEventType24.equals((java.lang.Object) (short) 100);
        chartChangeEvent17.setType(chartChangeEventType24);
        chartChangeEvent3.setType(chartChangeEventType24);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]"));
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertNull(jFreeChart13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(chartChangeEventType16);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]" + "'", str18.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]"));
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(chartChangeEventType21);
        org.junit.Assert.assertNotNull(chartChangeEventType24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        boolean boolean6 = categoryPlot0.isRangePannable();
        categoryPlot0.setRangePannable(true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getLegendItems();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot0.getDatasetRenderingOrder();
        java.lang.Object obj12 = null;
        boolean boolean13 = datasetRenderingOrder11.equals(obj12);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        legendItem31.setLabelFont(font37);
        legendItem31.setShapeVisible(false);
        java.awt.Shape shape42 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity44 = new org.jfree.chart.entity.ChartEntity(shape42, "hi!");
        legendItem31.setShape(shape42);
        int int46 = legendItem31.getSeriesIndex();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot0.notifyListeners(plotChangeEvent14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryPlot0.getAxisOffset();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer17.setBaseSeriesVisibleInLegend(true, false);
        barRenderer17.setItemLabelAnchorOffset((double) 8);
        java.awt.Shape shape24 = barRenderer17.getSeriesShape((int) (byte) 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation25 = null;
        boolean boolean26 = barRenderer17.removeAnnotation(categoryAnnotation25);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        categoryPlot28.addChangeListener(plotChangeListener29);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot28.getFixedLegendItems();
        java.awt.Paint paint32 = categoryPlot28.getNoDataMessagePaint();
        barRenderer17.setSeriesFillPaint((int) (short) 100, paint32, true);
        boolean boolean35 = barRenderer17.getAutoPopulateSeriesStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer37 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer37.setBaseSeriesVisibleInLegend(true, false);
        barRenderer37.setBaseSeriesVisible(false, true);
        java.awt.Color color46 = java.awt.Color.getColor("Category Plot", (int) '4');
        barRenderer37.setBasePaint((java.awt.Paint) color46, true);
        barRenderer17.setSeriesOutlinePaint(100, (java.awt.Paint) color46, false);
        categoryPlot0.setRangeMinorGridlinePaint((java.awt.Paint) color46);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(legendItemCollection31);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(color46);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        float float7 = categoryAxis1.getTickMarkInsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis1.getLabelInsets();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot0.setRangeAxis((int) (short) 100, valueAxis11, true);
        double double14 = categoryPlot0.getRangeCrosshairValue();
        boolean boolean15 = categoryPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) (byte) -1);
        java.lang.String str4 = textAnchor1.toString();
        java.lang.String str5 = textAnchor1.toString();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.TOP_RIGHT" + "'", str4.equals("TextAnchor.TOP_RIGHT"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.TOP_RIGHT" + "'", str5.equals("TextAnchor.TOP_RIGHT"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        boolean boolean9 = lineAndShapeRenderer2.getItemShapeFilled(0, 8);
        lineAndShapeRenderer2.setAutoPopulateSeriesPaint(false);
        try {
            lineAndShapeRenderer2.setSeriesShapesVisible((-3), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = barRenderer0.getGradientPaintTransformer();
        java.awt.Paint paint6 = barRenderer0.getSeriesFillPaint((-16727872));
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font9 = categoryAxis8.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis8.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot11.addChangeListener(plotChangeListener12);
        java.awt.Paint paint14 = categoryPlot11.getDomainGridlinePaint();
        categoryAxis8.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot11);
        java.awt.Paint paint16 = categoryPlot11.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot11.getRangeAxisLocation();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot20.setBackgroundPaint((java.awt.Paint) color23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot20.setRenderer(categoryItemRenderer25);
        org.jfree.chart.entity.PlotEntity plotEntity28 = new org.jfree.chart.entity.PlotEntity(shape19, (org.jfree.chart.plot.Plot) categoryPlot20, "");
        categoryPlot20.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font36 = categoryAxis35.getLabelFont();
        categoryAxis32.setTickLabelFont((java.lang.Comparable) 10.0d, font36);
        java.awt.Stroke stroke38 = categoryAxis32.getTickMarkStroke();
        categoryPlot20.setDomainGridlineStroke(stroke38);
        java.lang.Comparable comparable40 = categoryPlot20.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset41 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot20.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset41);
        defaultCategoryDataset41.clearSelection();
        int int44 = defaultCategoryDataset41.getColumnCount();
        categoryPlot11.setDataset((int) (short) 1, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset41);
        org.jfree.data.Range range47 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset41, true);
        java.util.List list48 = defaultCategoryDataset41.getColumnKeys();
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNull(comparable40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNotNull(list48);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        barRenderer0.setBase((double) 0.5f);
        java.lang.Object obj7 = barRenderer0.clone();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = barRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot11.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot11.setRenderer(categoryItemRenderer16);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape10, (org.jfree.chart.plot.Plot) categoryPlot11, "");
        categoryPlot11.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font27 = categoryAxis26.getLabelFont();
        categoryAxis23.setTickLabelFont((java.lang.Comparable) 10.0d, font27);
        java.awt.Stroke stroke29 = categoryAxis23.getTickMarkStroke();
        categoryPlot11.setDomainGridlineStroke(stroke29);
        java.lang.Comparable comparable31 = categoryPlot11.getDomainCrosshairColumnKey();
        barRenderer0.setPlot(categoryPlot11);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font35 = categoryAxis34.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor36 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = null;
        double double41 = categoryAxis34.getCategoryJava2DCoordinate(categoryAnchor36, (int) (byte) 100, (int) (byte) 1, rectangle2D39, rectangleEdge40);
        java.lang.String str43 = categoryAxis34.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        java.awt.Font font45 = categoryAxis34.getTickLabelFont((java.lang.Comparable) 1);
        barRenderer0.setBaseItemLabelFont(font45, true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(comparable31);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNull(str43);
        org.junit.Assert.assertNotNull(font45);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        barRenderer0.setBase((double) 0.5f);
        java.lang.Object obj7 = barRenderer0.clone();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = barRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot11.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot11.setRenderer(categoryItemRenderer16);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape10, (org.jfree.chart.plot.Plot) categoryPlot11, "");
        categoryPlot11.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font27 = categoryAxis26.getLabelFont();
        categoryAxis23.setTickLabelFont((java.lang.Comparable) 10.0d, font27);
        java.awt.Stroke stroke29 = categoryAxis23.getTickMarkStroke();
        categoryPlot11.setDomainGridlineStroke(stroke29);
        java.lang.Comparable comparable31 = categoryPlot11.getDomainCrosshairColumnKey();
        barRenderer0.setPlot(categoryPlot11);
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer33.setBaseSeriesVisibleInLegend(true, false);
        barRenderer33.setItemLabelAnchorOffset((double) 8);
        java.awt.Stroke stroke42 = barRenderer33.getItemOutlineStroke((-16727872), 10, false);
        categoryPlot11.setRangeZeroBaselineStroke(stroke42);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        categoryPlot11.setFixedDomainAxisSpace(axisSpace44);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(comparable31);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        java.awt.Shape shape7 = barRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = barRenderer0.removeAnnotation(categoryAnnotation8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot11.addChangeListener(plotChangeListener12);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot11.getFixedLegendItems();
        java.awt.Paint paint15 = categoryPlot11.getNoDataMessagePaint();
        barRenderer0.setSeriesFillPaint((int) (short) 100, paint15, true);
        boolean boolean18 = barRenderer0.getAutoPopulateSeriesStroke();
        boolean boolean19 = barRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        categoryPlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot3.setBackgroundPaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        categoryPlot3.setRenderer(categoryItemRenderer8);
        org.jfree.chart.entity.PlotEntity plotEntity11 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot3, "");
        categoryPlot3.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font19 = categoryAxis18.getLabelFont();
        categoryAxis15.setTickLabelFont((java.lang.Comparable) 10.0d, font19);
        java.awt.Stroke stroke21 = categoryAxis15.getTickMarkStroke();
        categoryPlot3.setDomainGridlineStroke(stroke21);
        java.lang.Comparable comparable23 = categoryPlot3.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset24 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot3.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection27 = categoryPlot26.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.RenderingSource renderingSource31 = null;
        categoryPlot26.select((double) (-1L), (double) 100, rectangle2D30, renderingSource31);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray33 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot26.setRenderers(categoryItemRendererArray33);
        defaultCategoryDataset24.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot26);
        defaultCategoryDataset24.fireSelectionEvent();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo37 = new org.jfree.chart.event.DatasetChangeInfo();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent38 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) keyedObjects2D0, (org.jfree.data.general.Dataset) defaultCategoryDataset24, datasetChangeInfo37);
        org.jfree.data.general.Dataset dataset39 = datasetChangeEvent38.getDataset();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(comparable23);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertNotNull(categoryItemRendererArray33);
        org.junit.Assert.assertNotNull(dataset39);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        barRenderer0.setSeriesOutlinePaint(0, paint7, true);
        barRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer0.notifyListeners(rendererChangeEvent12);
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot16.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot16.setRenderer(categoryItemRenderer21);
        org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity(shape15, (org.jfree.chart.plot.Plot) categoryPlot16, "");
        boolean boolean25 = categoryPlot16.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis27.setLabelInsets(rectangleInsets28, true);
        java.util.List list31 = categoryPlot16.getCategoriesForAxis(categoryAxis27);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        categoryPlot32.addChangeListener(plotChangeListener33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot32.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        categoryPlot32.setRangeAxis(2, valueAxis37, true);
        org.jfree.chart.LegendItemCollection legendItemCollection40 = new org.jfree.chart.LegendItemCollection();
        categoryPlot32.setFixedLegendItems(legendItemCollection40);
        categoryPlot16.setFixedLegendItems(legendItemCollection40);
        java.awt.Stroke stroke43 = categoryPlot16.getDomainCrosshairStroke();
        barRenderer0.setSeriesStroke(15, stroke43, false);
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.Shape shape47 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener49 = null;
        categoryPlot48.addChangeListener(plotChangeListener49);
        java.awt.Color color51 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot48.setBackgroundPaint((java.awt.Paint) color51);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        categoryPlot48.setRenderer(categoryItemRenderer53);
        org.jfree.chart.entity.PlotEntity plotEntity56 = new org.jfree.chart.entity.PlotEntity(shape47, (org.jfree.chart.plot.Plot) categoryPlot48, "");
        categoryPlot48.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font64 = categoryAxis63.getLabelFont();
        categoryAxis60.setTickLabelFont((java.lang.Comparable) 10.0d, font64);
        java.awt.Stroke stroke66 = categoryAxis60.getTickMarkStroke();
        categoryPlot48.setDomainGridlineStroke(stroke66);
        java.lang.Comparable comparable68 = categoryPlot48.getDomainCrosshairColumnKey();
        boolean boolean69 = categoryPlot48.canSelectByPoint();
        org.jfree.chart.axis.AxisSpace axisSpace70 = null;
        categoryPlot48.setFixedDomainAxisSpace(axisSpace70);
        java.awt.geom.Rectangle2D rectangle2D72 = null;
        java.awt.Paint paint74 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener76 = null;
        categoryPlot75.addChangeListener(plotChangeListener76);
        java.awt.Color color78 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot75.setBackgroundPaint((java.awt.Paint) color78);
        org.jfree.chart.axis.CategoryAxis categoryAxis81 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis84 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font85 = categoryAxis84.getLabelFont();
        categoryAxis81.setTickLabelFont((java.lang.Comparable) 10.0d, font85);
        java.awt.Stroke stroke87 = categoryAxis81.getTickMarkStroke();
        categoryPlot75.setRangeGridlineStroke(stroke87);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent89 = null;
        categoryPlot75.notifyListeners(plotChangeEvent89);
        java.awt.Paint paint91 = categoryPlot75.getRangeMinorGridlinePaint();
        java.awt.Stroke stroke92 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot75.setDomainCrosshairStroke(stroke92);
        try {
            barRenderer0.drawDomainLine(graphics2D46, categoryPlot48, rectangle2D72, (double) 3, paint74, stroke92);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(shape47);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNull(comparable68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(font85);
        org.junit.Assert.assertNotNull(stroke87);
        org.junit.Assert.assertNotNull(paint91);
        org.junit.Assert.assertNotNull(stroke92);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        legendItem31.setLabelFont(font37);
        java.awt.Paint paint40 = legendItem31.getLinePaint();
        legendItem31.setURLText("{0}");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer43 = legendItem31.getFillPaintTransformer();
        legendItem31.setToolTipText("AxisLocation.BOTTOM_OR_LEFT");
        legendItem31.setDatasetIndex((int) '#');
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(gradientPaintTransformer43);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape0, jFreeChart1, chartChangeEventType2);
        java.lang.String str4 = chartChangeEvent3.toString();
        org.jfree.chart.JFreeChart jFreeChart5 = null;
        chartChangeEvent3.setChart(jFreeChart5);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setSeriesShapesFilled(2, (java.lang.Boolean) true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer2.getItemStroke(100, 0, true);
        boolean boolean15 = lineAndShapeRenderer2.isSeriesItemLabelsVisible((int) ' ');
        lineAndShapeRenderer2.setSeriesShapesVisible(173, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot0.notifyListeners(plotChangeEvent14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot0.zoomDomainAxes((double) (short) 1, plotRenderingInfo17, point2D18);
        java.awt.Paint paint20 = categoryPlot0.getBackgroundPaint();
        double double21 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        categoryPlot23.addChangeListener(plotChangeListener24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot23.setBackgroundPaint((java.awt.Paint) color26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        categoryPlot23.setRenderer(categoryItemRenderer28);
        boolean boolean30 = categoryPlot23.isDomainPannable();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        categoryPlot32.addChangeListener(plotChangeListener33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot32.getDomainAxisLocation();
        categoryPlot23.setDomainAxisLocation(1, axisLocation35, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation38 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation35, plotOrientation38);
        categoryPlot0.setRangeAxisLocation(10, axisLocation35, false);
        categoryPlot0.clearDomainMarkers(101);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(plotOrientation38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.panRangeAxes((double) (short) 1, plotRenderingInfo11, point2D12);
        float float14 = categoryPlot0.getBackgroundImageAlpha();
        float float15 = categoryPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(categoryItemRenderer5);
        boolean boolean7 = categoryPlot0.isDomainPannable();
        java.awt.Stroke stroke8 = categoryPlot0.getRangeMinorGridlineStroke();
        int int9 = categoryPlot0.getWeight();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        java.awt.Stroke stroke9 = barRenderer0.getItemOutlineStroke((-16727872), 10, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator10);
        java.awt.Paint paint13 = barRenderer0.getSeriesItemLabelPaint((int) (short) 100);
        barRenderer0.setAutoPopulateSeriesOutlineStroke(false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        legendItem31.setLabelFont(font37);
        java.awt.Paint paint40 = legendItem31.getLinePaint();
        legendItem31.setURLText("{0}");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer43 = legendItem31.getFillPaintTransformer();
        legendItem31.setToolTipText("AxisLocation.BOTTOM_OR_LEFT");
        java.text.AttributedString attributedString46 = legendItem31.getAttributedLabel();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(gradientPaintTransformer43);
        org.junit.Assert.assertNull(attributedString46);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        boolean boolean3 = categoryAxis1.isMinorTickMarksVisible();
        float float4 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setLabelAngle(0.0d);
        double double7 = categoryAxis1.getLabelAngle();
        java.lang.String str9 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) (short) 10);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        renderAttributes0.setDefaultPaint((java.awt.Paint) color4);
        java.awt.Stroke stroke7 = renderAttributes0.getDefaultOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer9.setAutoPopulateSeriesShape(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = null;
        barRenderer12.setBaseItemLabelGenerator(categoryItemLabelGenerator13, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = new org.jfree.chart.labels.ItemLabelPosition();
        java.awt.Color color17 = java.awt.Color.WHITE;
        java.awt.Color color18 = color17.darker();
        boolean boolean19 = itemLabelPosition16.equals((java.lang.Object) color17);
        barRenderer12.setBasePositiveItemLabelPosition(itemLabelPosition16, false);
        barRenderer9.setBasePositiveItemLabelPosition(itemLabelPosition16, false);
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color26 = java.awt.Color.getColor("", color25);
        barRenderer9.setShadowPaint((java.awt.Paint) color25);
        renderAttributes0.setSeriesPaint(0, (java.awt.Paint) color25);
        java.awt.Stroke stroke29 = renderAttributes0.getDefaultOutlineStroke();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(stroke29);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        boolean boolean10 = categoryPlot1.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis12.setLabelInsets(rectangleInsets13, true);
        java.util.List list16 = categoryPlot1.getCategoriesForAxis(categoryAxis12);
        java.awt.Color color17 = java.awt.Color.ORANGE;
        categoryAxis12.setTickMarkPaint((java.awt.Paint) color17);
        java.awt.Font font20 = categoryAxis12.getTickLabelFont((java.lang.Comparable) 100);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font20);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getLegendItems();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot16.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot16.setRenderer(categoryItemRenderer21);
        org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity(shape15, (org.jfree.chart.plot.Plot) categoryPlot16, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot25.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font35 = categoryAxis34.getLabelFont();
        categoryAxis31.setTickLabelFont((java.lang.Comparable) 10.0d, font35);
        java.awt.Stroke stroke37 = categoryAxis31.getTickMarkStroke();
        categoryPlot25.setRangeGridlineStroke(stroke37);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color41 = java.awt.Color.getColor("", color40);
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape15, stroke37, (java.awt.Paint) color41);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font48 = categoryAxis47.getLabelFont();
        categoryAxis44.setTickLabelFont((java.lang.Comparable) 10.0d, font48);
        legendItem42.setLabelFont(font48);
        legendItem42.setShapeVisible(false);
        legendItemCollection10.add(legendItem42);
        org.jfree.chart.LegendItemCollection legendItemCollection54 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection10.addAll(legendItemCollection54);
        java.util.Iterator iterator56 = legendItemCollection54.iterator();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(iterator56);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        barRenderer0.setDefaultEntityRadius(2);
        java.awt.Stroke stroke6 = barRenderer0.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot7.setRangeGridlineStroke(stroke19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        categoryPlot7.notifyListeners(plotChangeEvent21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot7.getRangeAxisEdge(3);
        barRenderer0.setPlot(categoryPlot7);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot7.setRangeAxisLocation(axisLocation26);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        barRenderer0.setBase((double) 0.5f);
        barRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot10.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot10.setRenderer(categoryItemRenderer15);
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape9, (org.jfree.chart.plot.Plot) categoryPlot10, "");
        categoryPlot10.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font26 = categoryAxis25.getLabelFont();
        categoryAxis22.setTickLabelFont((java.lang.Comparable) 10.0d, font26);
        java.awt.Stroke stroke28 = categoryAxis22.getTickMarkStroke();
        categoryPlot10.setDomainGridlineStroke(stroke28);
        java.lang.Comparable comparable30 = categoryPlot10.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot10.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset31);
        org.jfree.data.Range range34 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset31, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator35 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator35, true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(comparable30);
        org.junit.Assert.assertNull(range34);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        java.awt.Color color7 = java.awt.Color.YELLOW;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font11 = categoryAxis10.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis10.getTickLabelInsets();
        categoryAxis1.setLabelInsets(rectangleInsets12, false);
        double double16 = rectangleInsets12.calculateBottomOutset((double) (-334));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        barRenderer0.setDefaultEntityRadius(2);
        java.awt.Stroke stroke6 = barRenderer0.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot7.setRangeGridlineStroke(stroke19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        categoryPlot7.notifyListeners(plotChangeEvent21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot7.getRangeAxisEdge(3);
        barRenderer0.setPlot(categoryPlot7);
        boolean boolean27 = barRenderer0.isSeriesVisible((int) (short) 10);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor28 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor28, textAnchor29);
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition30);
        barRenderer0.setBaseCreateEntities(true);
        org.jfree.chart.renderer.RenderAttributes renderAttributes35 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape38 = renderAttributes35.getItemShape(8, 8);
        java.awt.Stroke stroke40 = renderAttributes35.getSeriesStroke(100);
        java.awt.Color color42 = java.awt.Color.green;
        renderAttributes35.setSeriesOutlinePaint(4, (java.awt.Paint) color42);
        barRenderer0.setSeriesPaint((int) '#', (java.awt.Paint) color42, true);
        java.awt.Font font47 = barRenderer0.getLegendTextFont(100);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(itemLabelAnchor28);
        org.junit.Assert.assertNotNull(textAnchor29);
        org.junit.Assert.assertNull(shape38);
        org.junit.Assert.assertNull(stroke40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNull(font47);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor2, textAnchor3, 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE8" + "'", str1.equals("ItemLabelAnchor.OUTSIDE8"));
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        categoryPlot3.addChangeListener(plotChangeListener4);
        java.awt.Paint paint6 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = categoryPlot3.removeDomainMarker(marker7, layer8);
        boolean boolean10 = categoryPlot3.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot11.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font21 = categoryAxis20.getLabelFont();
        categoryAxis17.setTickLabelFont((java.lang.Comparable) 10.0d, font21);
        java.awt.Stroke stroke23 = categoryAxis17.getTickMarkStroke();
        categoryPlot11.setRangeGridlineStroke(stroke23);
        categoryPlot3.setRangeGridlineStroke(stroke23);
        keyedObjects0.addObject((java.lang.Comparable) 0.05d, (java.lang.Object) categoryPlot3);
        java.lang.Object obj28 = null;
        keyedObjects0.addObject((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", obj28);
        keyedObjects0.removeValue((int) (short) 0);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot0.getIndexOf(categoryItemRenderer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer12.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        java.awt.Paint paint19 = categoryPlot16.getDomainGridlinePaint();
        barRenderer12.setSeriesOutlinePaint(0, paint19, true);
        barRenderer12.setBaseItemLabelsVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        barRenderer12.notifyListeners(rendererChangeEvent24);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer27.setBaseSeriesVisibleInLegend(true, false);
        barRenderer27.setItemLabelAnchorOffset((double) 8);
        java.awt.Stroke stroke36 = barRenderer27.getItemOutlineStroke((-16727872), 10, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator37 = null;
        barRenderer27.setBaseURLGenerator(categoryURLGenerator37);
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator41 = null;
        barRenderer40.setBaseItemLabelGenerator(categoryItemLabelGenerator41, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = new org.jfree.chart.labels.ItemLabelPosition();
        java.awt.Color color45 = java.awt.Color.WHITE;
        java.awt.Color color46 = color45.darker();
        boolean boolean47 = itemLabelPosition44.equals((java.lang.Object) color45);
        barRenderer40.setBasePositiveItemLabelPosition(itemLabelPosition44, false);
        java.lang.Object obj50 = null;
        boolean boolean51 = itemLabelPosition44.equals(obj50);
        barRenderer27.setSeriesNegativeItemLabelPosition((int) '#', itemLabelPosition44, false);
        barRenderer12.setBaseNegativeItemLabelPosition(itemLabelPosition44);
        java.awt.Stroke stroke58 = barRenderer12.getItemOutlineStroke((int) (short) 1, 0, false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(stroke58);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        java.awt.Stroke stroke7 = categoryAxis1.getTickMarkStroke();
        java.awt.Font font8 = categoryAxis1.getLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot9.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.RenderingSource renderingSource14 = null;
        categoryPlot9.select((double) (-1L), (double) 100, rectangle2D13, renderingSource14);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray16 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot9.setRenderers(categoryItemRendererArray16);
        boolean boolean18 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = null;
        barRenderer19.setBaseItemLabelGenerator(categoryItemLabelGenerator20, true);
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType24 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer25 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType24);
        java.awt.Shape shape26 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        categoryPlot27.addChangeListener(plotChangeListener28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot27.setBackgroundPaint((java.awt.Paint) color30);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        categoryPlot27.setRenderer(categoryItemRenderer32);
        org.jfree.chart.entity.PlotEntity plotEntity35 = new org.jfree.chart.entity.PlotEntity(shape26, (org.jfree.chart.plot.Plot) categoryPlot27, "");
        boolean boolean36 = categoryPlot27.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis38.setLabelInsets(rectangleInsets39, true);
        java.util.List list42 = categoryPlot27.getCategoriesForAxis(categoryAxis38);
        java.awt.Color color43 = java.awt.Color.ORANGE;
        categoryAxis38.setTickMarkPaint((java.awt.Paint) color43);
        boolean boolean45 = standardGradientPaintTransformer25.equals((java.lang.Object) categoryAxis38);
        barRenderer19.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer25);
        java.awt.Paint paint47 = barRenderer19.getBaseOutlinePaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator49 = null;
        barRenderer19.setSeriesItemLabelGenerator((int) (byte) 100, categoryItemLabelGenerator49, true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType24);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(paint47);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        java.awt.Color color0 = java.awt.Color.cyan;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setBaseSeriesVisible(false, true);
        boolean boolean7 = barRenderer0.getBaseItemLabelsVisible();
        barRenderer0.setBaseItemLabelsVisible(true, false);
        double double11 = barRenderer0.getMinimumBarLength();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        legendItem31.setLabelFont(font37);
        java.awt.Paint paint40 = legendItem31.getLinePaint();
        java.awt.Shape shape41 = legendItem31.getLine();
        legendItem31.setDescription("AxisLocation.BOTTOM_OR_LEFT");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer44 = legendItem31.getFillPaintTransformer();
        legendItem31.setSeriesKey((java.lang.Comparable) 10);
        java.lang.Comparable comparable47 = legendItem31.getSeriesKey();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(gradientPaintTransformer44);
        org.junit.Assert.assertTrue("'" + comparable47 + "' != '" + 10 + "'", comparable47.equals(10));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot1.getRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot11.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font21 = categoryAxis20.getLabelFont();
        categoryAxis17.setTickLabelFont((java.lang.Comparable) 10.0d, font21);
        java.awt.Stroke stroke23 = categoryAxis17.getTickMarkStroke();
        categoryPlot11.setRangeGridlineStroke(stroke23);
        java.awt.Color color26 = java.awt.Color.WHITE;
        java.awt.Color color27 = color26.darker();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator31 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color26, (float) 100L, 10, (double) 0L);
        categoryPlot11.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator31);
        categoryPlot1.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator31);
        java.awt.Shape[] shapeArray34 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        boolean boolean35 = defaultShadowGenerator31.equals((java.lang.Object) shapeArray34);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(shapeArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        org.jfree.chart.plot.Plot plot10 = plotEntity9.getPlot();
        plotEntity9.setURLText("GradientPaintTransformType.CENTER_VERTICAL");
        org.jfree.chart.plot.Plot plot13 = plotEntity9.getPlot();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertNotNull(plot13);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getLegendItems();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = categoryPlot0.getDatasetRenderingOrder();
        categoryPlot0.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = null;
        categoryPlot0.axisChanged(axisChangeEvent5);
        java.util.List list7 = categoryPlot0.getCategories();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        double double12 = rectangleInsets11.getLeft();
        double double14 = rectangleInsets11.extendWidth((double) 255);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(list7);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.0d + "'", double12 == 4.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 263.0d + "'", double14 == 263.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        legendItem31.setLabelFont(font37);
        java.awt.Paint paint40 = legendItem31.getLinePaint();
        boolean boolean41 = legendItem31.isShapeVisible();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        barRenderer0.setBase((double) 0.5f);
        barRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot10.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot10.setRenderer(categoryItemRenderer15);
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape9, (org.jfree.chart.plot.Plot) categoryPlot10, "");
        categoryPlot10.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font26 = categoryAxis25.getLabelFont();
        categoryAxis22.setTickLabelFont((java.lang.Comparable) 10.0d, font26);
        java.awt.Stroke stroke28 = categoryAxis22.getTickMarkStroke();
        categoryPlot10.setDomainGridlineStroke(stroke28);
        java.lang.Comparable comparable30 = categoryPlot10.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot10.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset31);
        org.jfree.data.Range range34 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset31, true);
        int int36 = defaultCategoryDataset31.getColumnIndex((java.lang.Comparable) 10.0f);
        try {
            defaultCategoryDataset31.removeColumn((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(comparable30);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj2 = standardCategorySeriesLabelGenerator1.clone();
        java.lang.Object obj3 = null;
        boolean boolean4 = standardCategorySeriesLabelGenerator1.equals(obj3);
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot6.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot6.setRenderer(categoryItemRenderer11);
        org.jfree.chart.entity.PlotEntity plotEntity14 = new org.jfree.chart.entity.PlotEntity(shape5, (org.jfree.chart.plot.Plot) categoryPlot6, "");
        categoryPlot6.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font22 = categoryAxis21.getLabelFont();
        categoryAxis18.setTickLabelFont((java.lang.Comparable) 10.0d, font22);
        java.awt.Stroke stroke24 = categoryAxis18.getTickMarkStroke();
        categoryPlot6.setDomainGridlineStroke(stroke24);
        java.lang.Comparable comparable26 = categoryPlot6.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font29 = categoryAxis28.getLabelFont();
        boolean boolean30 = categoryAxis28.isMinorTickMarksVisible();
        boolean boolean31 = categoryAxis28.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray32 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis28 };
        categoryPlot6.setDomainAxes(categoryAxisArray32);
        boolean boolean34 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) categoryPlot6);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.RenderingSource renderingSource38 = null;
        categoryPlot6.select((double) 10.0f, 0.05d, rectangle2D37, renderingSource38);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(comparable26);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        legendItem31.setLabelFont(font37);
        legendItem31.setShapeVisible(false);
        java.awt.Font font42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        legendItem31.setLabelFont(font42);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(font42);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape3 = renderAttributes0.getItemShape(8, 8);
        java.awt.Stroke stroke5 = renderAttributes0.getSeriesStroke(100);
        java.awt.Color color7 = java.awt.Color.green;
        renderAttributes0.setSeriesOutlinePaint(4, (java.awt.Paint) color7);
        java.awt.Font font9 = renderAttributes0.getDefaultLabelFont();
        org.junit.Assert.assertNull(shape3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(font9);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        java.lang.String str10 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        categoryAxis1.setLabelAngle((double) (short) 100);
        java.awt.Font font13 = categoryAxis1.getLabelFont();
        categoryAxis1.setFixedDimension((double) ' ');
        categoryAxis1.setTickMarkInsideLength(0.0f);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(font13);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, 1.0d, (double) 1.0f, (double) 100);
        double double6 = rectangleInsets4.calculateLeftInset((double) (-1));
        double double8 = rectangleInsets4.calculateRightInset((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis16.getCategoryJava2DCoordinate(categoryAnchor17, 0, (int) ' ', rectangle2D20, rectangleEdge21);
        java.awt.Paint paint23 = categoryAxis16.getLabelPaint();
        categoryPlot0.setBackgroundPaint(paint23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = categoryPlot0.getDomainAxisForDataset(3);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(categoryAxis26);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis16.getCategoryJava2DCoordinate(categoryAnchor17, 0, (int) ' ', rectangle2D20, rectangleEdge21);
        java.awt.Paint paint23 = categoryAxis16.getLabelPaint();
        categoryPlot0.setBackgroundPaint(paint23);
        categoryPlot0.setCrosshairDatasetIndex(2);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        categoryPlot28.addChangeListener(plotChangeListener29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot28.setBackgroundPaint((java.awt.Paint) color31);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font38 = categoryAxis37.getLabelFont();
        categoryAxis34.setTickLabelFont((java.lang.Comparable) 10.0d, font38);
        java.awt.Stroke stroke40 = categoryAxis34.getTickMarkStroke();
        categoryPlot28.setRangeGridlineStroke(stroke40);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent42 = null;
        categoryPlot28.notifyListeners(plotChangeEvent42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        categoryPlot28.zoomDomainAxes((double) (short) 1, plotRenderingInfo45, point2D46);
        java.awt.Paint paint48 = categoryPlot28.getBackgroundPaint();
        double double49 = categoryPlot28.getRangeCrosshairValue();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener52 = null;
        categoryPlot51.addChangeListener(plotChangeListener52);
        java.awt.Color color54 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot51.setBackgroundPaint((java.awt.Paint) color54);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer56 = null;
        categoryPlot51.setRenderer(categoryItemRenderer56);
        boolean boolean58 = categoryPlot51.isDomainPannable();
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener61 = null;
        categoryPlot60.addChangeListener(plotChangeListener61);
        org.jfree.chart.axis.AxisLocation axisLocation63 = categoryPlot60.getDomainAxisLocation();
        categoryPlot51.setDomainAxisLocation(1, axisLocation63, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation66 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge67 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation63, plotOrientation66);
        categoryPlot28.setRangeAxisLocation(10, axisLocation63, false);
        categoryPlot0.setRangeAxisLocation(0, axisLocation63);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(axisLocation63);
        org.junit.Assert.assertNotNull(plotOrientation66);
        org.junit.Assert.assertNotNull(rectangleEdge67);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        defaultCategoryDataset22.clearSelection();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        categoryPlot26.addChangeListener(plotChangeListener27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot26.setBackgroundPaint((java.awt.Paint) color29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot26.setRenderer(categoryItemRenderer31);
        org.jfree.chart.entity.PlotEntity plotEntity34 = new org.jfree.chart.entity.PlotEntity(shape25, (org.jfree.chart.plot.Plot) categoryPlot26, "");
        categoryPlot26.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font42 = categoryAxis41.getLabelFont();
        categoryAxis38.setTickLabelFont((java.lang.Comparable) 10.0d, font42);
        java.awt.Stroke stroke44 = categoryAxis38.getTickMarkStroke();
        categoryPlot26.setDomainGridlineStroke(stroke44);
        java.lang.Comparable comparable46 = categoryPlot26.getDomainCrosshairColumnKey();
        boolean boolean47 = categoryPlot26.canSelectByPoint();
        boolean boolean48 = defaultCategoryDataset22.hasListener((java.util.EventListener) categoryPlot26);
        categoryPlot26.setRangeCrosshairValue((double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font53 = categoryAxis52.getLabelFont();
        boolean boolean54 = categoryAxis52.isMinorTickMarksVisible();
        boolean boolean55 = categoryAxis52.isAxisLineVisible();
        categoryAxis52.setAxisLineVisible(false);
        java.util.List list58 = categoryPlot26.getCategoriesForAxis(categoryAxis52);
        org.jfree.chart.LegendItemCollection legendItemCollection59 = categoryPlot26.getLegendItems();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(comparable46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(list58);
        org.junit.Assert.assertNotNull(legendItemCollection59);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot24.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot24.select((double) (-1L), (double) 100, rectangle2D28, renderingSource29);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray31 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot24.setRenderers(categoryItemRendererArray31);
        defaultCategoryDataset22.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot24);
        try {
            defaultCategoryDataset22.setSelected((int) (short) -1, 4, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNull(legendItemCollection25);
        org.junit.Assert.assertNotNull(categoryItemRendererArray31);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot0.setRangeAxis(2, valueAxis5, true);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        categoryPlot0.setRangeAxis((int) (short) 100, valueAxis9);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot0.getRangeAxis();
        categoryPlot0.setBackgroundAlpha((float) 1L);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer7.setBaseSeriesVisibleInLegend(true, false);
        barRenderer7.setBaseSeriesVisible(false, true);
        java.awt.Color color16 = java.awt.Color.getColor("Category Plot", (int) '4');
        barRenderer7.setBasePaint((java.awt.Paint) color16, true);
        barRenderer0.setSeriesPaint(35, (java.awt.Paint) color16, true);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        categoryPlot4.clearAnnotations();
        java.awt.Font font10 = categoryPlot4.getNoDataMessageFont();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setDomainAxisLocation(axisLocation11, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = null;
        double double22 = categoryAxis16.getCategoryJava2DCoordinate(categoryAnchor17, 0, (int) ' ', rectangle2D20, rectangleEdge21);
        categoryPlot4.setDomainAxis(3, categoryAxis16, true);
        int int25 = categoryPlot4.getRendererCount();
        boolean boolean26 = categoryPlot4.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        java.lang.String str10 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        categoryAxis1.setTickMarkInsideLength((float) (byte) 1);
        categoryAxis1.clearCategoryLabelToolTips();
        java.awt.Paint paint15 = null;
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) (-1.0d), paint15);
        categoryAxis1.setTickMarkInsideLength((-1.0f));
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer0 = new org.jfree.chart.util.StandardGradientPaintTransformer();
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        try {
            keyedObjects2D0.removeColumn((java.lang.Comparable) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Column key (-1.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot4.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot4.setRenderer(categoryItemRenderer9);
        org.jfree.chart.entity.PlotEntity plotEntity12 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) categoryPlot4, "");
        categoryPlot4.setBackgroundAlpha((float) 10L);
        keyedObjects0.setObject((java.lang.Comparable) 10.0f, (java.lang.Object) 10L);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType17 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer18 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType17);
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot20.setBackgroundPaint((java.awt.Paint) color23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot20.setRenderer(categoryItemRenderer25);
        org.jfree.chart.entity.PlotEntity plotEntity28 = new org.jfree.chart.entity.PlotEntity(shape19, (org.jfree.chart.plot.Plot) categoryPlot20, "");
        boolean boolean29 = categoryPlot20.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis31.setLabelInsets(rectangleInsets32, true);
        java.util.List list35 = categoryPlot20.getCategoriesForAxis(categoryAxis31);
        java.awt.Color color36 = java.awt.Color.ORANGE;
        categoryAxis31.setTickMarkPaint((java.awt.Paint) color36);
        boolean boolean38 = standardGradientPaintTransformer18.equals((java.lang.Object) categoryAxis31);
        keyedObjects0.setObject((java.lang.Comparable) 0.0d, (java.lang.Object) standardGradientPaintTransformer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font45 = categoryAxis44.getLabelFont();
        categoryAxis41.setTickLabelFont((java.lang.Comparable) 10.0d, font45);
        java.awt.Stroke stroke47 = categoryAxis41.getTickMarkStroke();
        java.awt.Font font48 = categoryAxis41.getLabelFont();
        java.awt.Stroke stroke49 = categoryAxis41.getTickMarkStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = categoryAxis41.getLabelInsets();
        double double52 = rectangleInsets50.calculateLeftOutset((double) '#');
        boolean boolean53 = keyedObjects0.equals((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(gradientPaintTransformType17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 3.0d + "'", double52 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer11.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean15 = lineAndShapeRenderer11.getAutoPopulateSeriesOutlinePaint();
        boolean boolean16 = lineAndShapeRenderer11.getBaseLinesVisible();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer11.setSeriesPositiveItemLabelPosition(0, itemLabelPosition18);
        categoryPlot0.setRenderer(8, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11, false);
        lineAndShapeRenderer11.setSeriesShapesFilled((int) '4', (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 10, plotRenderingInfo3, point2D4, false);
        org.jfree.chart.util.SortOrder sortOrder7 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder7);
        int int9 = categoryPlot0.getDomainAxisCount();
        java.awt.Font font10 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(sortOrder7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        java.awt.Color color7 = java.awt.Color.YELLOW;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        categoryAxis1.setMaximumCategoryLabelLines((-1));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer11.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean15 = lineAndShapeRenderer11.getAutoPopulateSeriesOutlinePaint();
        boolean boolean16 = lineAndShapeRenderer11.getBaseLinesVisible();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer11.setSeriesPositiveItemLabelPosition(0, itemLabelPosition18);
        categoryPlot0.setRenderer(8, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11, false);
        java.awt.Stroke stroke22 = lineAndShapeRenderer11.getBaseOutlineStroke();
        lineAndShapeRenderer11.setSeriesShapesVisible((int) (byte) 0, true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape3 = renderAttributes0.getItemShape(8, 8);
        java.awt.Font font4 = renderAttributes0.getDefaultLabelFont();
        boolean boolean5 = renderAttributes0.getAllowNull();
        org.junit.Assert.assertNull(shape3);
        org.junit.Assert.assertNull(font4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        renderAttributes1.setDefaultStroke(stroke2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        renderAttributes1.setDefaultLabelPaint((java.awt.Paint) color4);
        java.awt.Color color6 = java.awt.Color.lightGray;
        renderAttributes1.setDefaultFillPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        java.lang.String str10 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        categoryAxis1.setTickMarkInsideLength((float) (byte) 1);
        java.lang.Object obj13 = null;
        boolean boolean14 = categoryAxis1.equals(obj13);
        categoryAxis1.setCategoryLabelPositionOffset((int) (short) 100);
        java.awt.Paint paint17 = null;
        try {
            categoryAxis1.setLabelPaint(paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setBaseSeriesVisible(false, true);
        barRenderer0.setBaseSeriesVisibleInLegend(false, true);
        java.awt.Paint paint10 = barRenderer0.getBaseLegendTextPaint();
        barRenderer0.setBaseSeriesVisibleInLegend(false, true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator15 = barRenderer0.getSeriesToolTipGenerator((int) (short) 0);
        java.awt.Shape shape16 = barRenderer0.getBaseLegendShape();
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(categoryToolTipGenerator15);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        java.awt.Stroke stroke7 = categoryAxis1.getTickMarkStroke();
        java.awt.Font font8 = categoryAxis1.getLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot9.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.RenderingSource renderingSource14 = null;
        categoryPlot9.select((double) (-1L), (double) 100, rectangle2D13, renderingSource14);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray16 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot9.setRenderers(categoryItemRendererArray16);
        boolean boolean18 = categoryAxis1.hasListener((java.util.EventListener) categoryPlot9);
        java.awt.Paint paint19 = categoryPlot9.getDomainGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot9.getDomainAxisEdge((int) (byte) 0);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(categoryItemRendererArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot0.notifyListeners(plotChangeEvent14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot0.zoomDomainAxes((double) (short) 1, plotRenderingInfo17, point2D18);
        java.awt.Paint paint20 = categoryPlot0.getBackgroundPaint();
        double double21 = categoryPlot0.getRangeCrosshairValue();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        categoryPlot23.addChangeListener(plotChangeListener24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot23.setBackgroundPaint((java.awt.Paint) color26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        categoryPlot23.setRenderer(categoryItemRenderer28);
        boolean boolean30 = categoryPlot23.isDomainPannable();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        categoryPlot32.addChangeListener(plotChangeListener33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot32.getDomainAxisLocation();
        categoryPlot23.setDomainAxisLocation(1, axisLocation35, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation38 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation35, plotOrientation38);
        categoryPlot0.setRangeAxisLocation(10, axisLocation35, false);
        org.jfree.chart.axis.AxisLocation axisLocation42 = axisLocation35.getOpposite();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(plotOrientation38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(axisLocation42);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        java.awt.Stroke stroke9 = barRenderer0.getItemOutlineStroke((-16727872), 10, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator10);
        java.awt.Paint paint13 = barRenderer0.getSeriesItemLabelPaint((int) (short) 100);
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot16.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot16.setRenderer(categoryItemRenderer21);
        org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity(shape15, (org.jfree.chart.plot.Plot) categoryPlot16, "");
        java.lang.String str25 = plotEntity24.getURLText();
        java.awt.Shape shape26 = plotEntity24.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        categoryPlot27.addChangeListener(plotChangeListener28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot27.setBackgroundPaint((java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        java.awt.Stroke stroke39 = categoryAxis33.getTickMarkStroke();
        categoryPlot27.setRangeGridlineStroke(stroke39);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent41 = null;
        categoryPlot27.notifyListeners(plotChangeEvent41);
        java.awt.Paint paint43 = categoryPlot27.getRangeMinorGridlinePaint();
        java.awt.Stroke stroke44 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        categoryPlot27.setDomainCrosshairStroke(stroke44);
        org.jfree.chart.entity.PlotEntity plotEntity47 = new org.jfree.chart.entity.PlotEntity(shape26, (org.jfree.chart.plot.Plot) categoryPlot27, "ItemLabelAnchor.OUTSIDE4");
        barRenderer0.setLegendShape((int) (byte) 0, shape26);
        java.awt.Font font50 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        barRenderer0.setLegendTextFont((int) '4', font50);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(str25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(font50);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        java.lang.String str10 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        java.awt.Font font12 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 1);
        categoryAxis1.setTickLabelsVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor18 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = categoryAxis16.getCategoryJava2DCoordinate(categoryAnchor18, (int) (byte) 100, (int) (byte) 1, rectangle2D21, rectangleEdge22);
        int int24 = categoryAxis16.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke25 = categoryAxis16.getTickMarkStroke();
        categoryAxis1.setAxisLineStroke(stroke25);
        categoryAxis1.setTickMarksVisible(true);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 1 + "'", int24 == 1);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) -1, (int) (short) 100, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        boolean boolean7 = lineAndShapeRenderer2.getBaseLinesVisible();
        lineAndShapeRenderer2.setUseFillPaint(false);
        lineAndShapeRenderer2.setSeriesVisibleInLegend((int) (short) 1, (java.lang.Boolean) false);
        double double13 = lineAndShapeRenderer2.getItemMargin();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        categoryPlot0.clearSelection();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        int int6 = categoryPlot0.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, color12 };
        java.awt.Color color14 = java.awt.Color.YELLOW;
        int int15 = color14.getBlue();
        java.awt.Color color16 = java.awt.Color.ORANGE;
        java.awt.Color color17 = java.awt.Color.WHITE;
        java.awt.Color color18 = color17.darker();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray20 = new java.awt.Paint[] { color14, color16, color18, color19 };
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] { stroke21, stroke22 };
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font29 = categoryAxis28.getLabelFont();
        categoryAxis25.setTickLabelFont((java.lang.Comparable) 10.0d, font29);
        java.awt.Stroke stroke31 = categoryAxis25.getTickMarkStroke();
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] { stroke31 };
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray34 = new java.awt.Shape[] { shape33 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray13, paintArray20, strokeArray23, strokeArray32, shapeArray34);
        java.lang.Object obj36 = defaultDrawingSupplier35.clone();
        java.awt.Paint paint37 = defaultDrawingSupplier35.getNextOutlinePaint();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray39 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot0.setRangeAxes(valueAxisArray39);
        java.awt.Paint paint41 = categoryPlot0.getOutlinePaint();
        java.awt.Stroke stroke42 = categoryPlot0.getRangeGridlineStroke();
        float float43 = categoryPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shapeArray34);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(valueAxisArray39);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertTrue("'" + float43 + "' != '" + 0.5f + "'", float43 == 0.5f);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = null;
        categoryPlot0.axisChanged(axisChangeEvent5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot0.getDomainAxisEdge((int) (byte) -1);
        org.jfree.chart.plot.CategoryMarker categoryMarker9 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesShapesFilled(0);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer11.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean15 = lineAndShapeRenderer11.getAutoPopulateSeriesOutlinePaint();
        boolean boolean16 = lineAndShapeRenderer11.getBaseLinesVisible();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = null;
        lineAndShapeRenderer11.setSeriesPositiveItemLabelPosition(0, itemLabelPosition18);
        categoryPlot0.setRenderer(8, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11, false);
        java.awt.Stroke stroke22 = lineAndShapeRenderer11.getBaseOutlineStroke();
        java.awt.Paint paint26 = lineAndShapeRenderer11.getItemFillPaint((int) ' ', (-254), false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        legendItem31.setLabelFont(font37);
        java.awt.Paint paint40 = legendItem31.getLinePaint();
        java.awt.Shape shape41 = legendItem31.getLine();
        legendItem31.setDescription("AxisLocation.BOTTOM_OR_LEFT");
        legendItem31.setDescription("Category Plot");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer48 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer48.setSeriesLinesVisible((int) (short) 10, true);
        lineAndShapeRenderer48.setItemMargin((double) 0.0f);
        java.awt.Stroke stroke55 = lineAndShapeRenderer48.lookupSeriesOutlineStroke(15);
        legendItem31.setOutlineStroke(stroke55);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(stroke55);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        categoryPlot0.clearSelection();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        int int6 = categoryPlot0.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color10, color12 };
        java.awt.Color color14 = java.awt.Color.YELLOW;
        int int15 = color14.getBlue();
        java.awt.Color color16 = java.awt.Color.ORANGE;
        java.awt.Color color17 = java.awt.Color.WHITE;
        java.awt.Color color18 = color17.darker();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray20 = new java.awt.Paint[] { color14, color16, color18, color19 };
        java.awt.Stroke stroke21 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray23 = new java.awt.Stroke[] { stroke21, stroke22 };
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font29 = categoryAxis28.getLabelFont();
        categoryAxis25.setTickLabelFont((java.lang.Comparable) 10.0d, font29);
        java.awt.Stroke stroke31 = categoryAxis25.getTickMarkStroke();
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] { stroke31 };
        java.awt.Shape shape33 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray34 = new java.awt.Shape[] { shape33 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray13, paintArray20, strokeArray23, strokeArray32, shapeArray34);
        java.lang.Object obj36 = defaultDrawingSupplier35.clone();
        java.awt.Paint paint37 = defaultDrawingSupplier35.getNextOutlinePaint();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35);
        java.awt.Paint paint39 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        categoryPlot0.panDomainAxes(0.0d, plotRenderingInfo41, point2D42);
        categoryPlot0.configureRangeAxes();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paintArray20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(strokeArray23);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(shapeArray34);
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint39);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType32 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType32);
        legendItem31.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        legendItem31.setDescription("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType32);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setTickMarkOutsideLength(0.0f);
        int int3 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.panRangeAxes((double) (short) 1, plotRenderingInfo11, point2D12);
        float float14 = categoryPlot0.getBackgroundImageAlpha();
        categoryPlot0.clearSelection();
        categoryPlot0.setRangeCrosshairValue((double) (-1.0f));
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        categoryPlot0.setRangeCrosshairValue((double) 10);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot0.getRangeAxis();
        org.jfree.chart.renderer.RenderAttributes renderAttributes18 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Font font19 = renderAttributes18.getDefaultLabelFont();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        categoryPlot21.addChangeListener(plotChangeListener22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot21.setBackgroundPaint((java.awt.Paint) color24);
        renderAttributes18.setSeriesOutlinePaint((int) (byte) 1, (java.awt.Paint) color24);
        categoryPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color24);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertNull(font19);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent5 = null;
        categoryPlot0.axisChanged(axisChangeEvent5);
        java.awt.Shape shape11 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot12.setBackgroundPaint((java.awt.Paint) color15);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot12.setRenderer(categoryItemRenderer17);
        org.jfree.chart.entity.PlotEntity plotEntity20 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) categoryPlot12, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        categoryPlot21.addChangeListener(plotChangeListener22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot21.setBackgroundPaint((java.awt.Paint) color24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font31 = categoryAxis30.getLabelFont();
        categoryAxis27.setTickLabelFont((java.lang.Comparable) 10.0d, font31);
        java.awt.Stroke stroke33 = categoryAxis27.getTickMarkStroke();
        categoryPlot21.setRangeGridlineStroke(stroke33);
        java.awt.Color color36 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color37 = java.awt.Color.getColor("", color36);
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape11, stroke33, (java.awt.Paint) color37);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType39 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer40 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType39);
        legendItem38.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer40);
        java.lang.String str42 = legendItem38.getToolTipText();
        java.awt.Paint paint43 = legendItem38.getOutlinePaint();
        java.awt.Paint paint44 = legendItem38.getLinePaint();
        categoryPlot0.setDomainGridlinePaint(paint44);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(gradientPaintTransformType39);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "hi!" + "'", str42.equals("hi!"));
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot8.setBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryAxis14.setTickLabelFont((java.lang.Comparable) 10.0d, font18);
        java.awt.Stroke stroke20 = categoryAxis14.getTickMarkStroke();
        categoryPlot8.setRangeGridlineStroke(stroke20);
        categoryPlot0.setRangeGridlineStroke(stroke20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        categoryPlot0.setRenderer((int) (byte) 1, categoryItemRenderer24);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.plot.Marker marker27 = null;
        try {
            boolean boolean28 = categoryPlot0.removeRangeMarker(marker27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(drawingSupplier26);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        int int3 = color1.getRGB();
        java.awt.Color color4 = color1.darker();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16727872) + "'", int3 == (-16727872));
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setUseOutlinePaint(false);
        boolean boolean11 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 0, 4);
        java.awt.Color color13 = java.awt.Color.WHITE;
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color13.createContext(colorModel14, rectangle15, rectangle2D16, affineTransform17, renderingHints18);
        lineAndShapeRenderer2.setSeriesFillPaint(100, (java.awt.Paint) color13);
        java.lang.Boolean boolean22 = lineAndShapeRenderer2.getSeriesShapesFilled((int) (short) 100);
        boolean boolean23 = lineAndShapeRenderer2.getBaseShapesFilled();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintContext19);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot8.setBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryAxis14.setTickLabelFont((java.lang.Comparable) 10.0d, font18);
        java.awt.Stroke stroke20 = categoryAxis14.getTickMarkStroke();
        categoryPlot8.setRangeGridlineStroke(stroke20);
        categoryPlot0.setRangeGridlineStroke(stroke20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        categoryPlot0.setRenderer((int) (byte) 1, categoryItemRenderer24);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.util.SortOrder sortOrder27 = categoryPlot0.getColumnRenderingOrder();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(sortOrder27);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        java.awt.Stroke stroke9 = barRenderer0.getItemOutlineStroke((-16727872), 10, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = null;
        barRenderer13.setBaseItemLabelGenerator(categoryItemLabelGenerator14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = new org.jfree.chart.labels.ItemLabelPosition();
        java.awt.Color color18 = java.awt.Color.WHITE;
        java.awt.Color color19 = color18.darker();
        boolean boolean20 = itemLabelPosition17.equals((java.lang.Object) color18);
        barRenderer13.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        java.lang.Object obj23 = null;
        boolean boolean24 = itemLabelPosition17.equals(obj23);
        barRenderer0.setSeriesNegativeItemLabelPosition((int) '#', itemLabelPosition17, false);
        boolean boolean27 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        barRenderer0.setDefaultEntityRadius(2);
        java.awt.Stroke stroke6 = barRenderer0.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot7.setRangeGridlineStroke(stroke19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        categoryPlot7.notifyListeners(plotChangeEvent21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot7.getRangeAxisEdge(3);
        barRenderer0.setPlot(categoryPlot7);
        boolean boolean27 = barRenderer0.isSeriesVisible((int) (short) 10);
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setBaseShape(shape28, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot31.addChangeListener(plotChangeListener32);
        java.awt.Paint paint34 = categoryPlot31.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker35 = null;
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean37 = categoryPlot31.removeDomainMarker(marker35, layer36);
        org.jfree.data.category.CategoryDataset categoryDataset39 = categoryPlot31.getDataset(100);
        boolean boolean40 = categoryPlot31.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection41 = categoryPlot31.getLegendItems();
        org.jfree.chart.event.PlotChangeListener plotChangeListener42 = null;
        categoryPlot31.addChangeListener(plotChangeListener42);
        org.jfree.chart.entity.PlotEntity plotEntity45 = new org.jfree.chart.entity.PlotEntity(shape28, (org.jfree.chart.plot.Plot) categoryPlot31, "PlotEntity: tooltip = ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        categoryPlot31.setRangeAxis((int) (short) 1, valueAxis47, false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(legendItemCollection41);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        java.awt.Paint paint7 = lineAndShapeRenderer2.getLegendTextPaint((int) (short) 0);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setBaseSeriesVisible(false, true);
        boolean boolean7 = barRenderer0.getBaseItemLabelsVisible();
        boolean boolean9 = barRenderer0.isSeriesVisible(3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Paint paint4 = categoryPlot1.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        boolean boolean7 = categoryPlot1.removeDomainMarker(marker5, layer6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot1.getDataset(100);
        boolean boolean10 = categoryPlot1.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot1.getLegendItems();
        categoryPlot1.setRangeCrosshairValue((-9.0d));
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator15 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj16 = standardCategorySeriesLabelGenerator15.clone();
        java.lang.Object obj17 = null;
        boolean boolean18 = standardCategorySeriesLabelGenerator15.equals(obj17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font21 = categoryAxis20.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryAxis20.getTickLabelInsets();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis20.setLabelPaint((java.awt.Paint) color23);
        boolean boolean25 = standardCategorySeriesLabelGenerator15.equals((java.lang.Object) color23);
        categoryPlot1.setDomainGridlinePaint((java.awt.Paint) color23);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator30 = new org.jfree.chart.util.DefaultShadowGenerator(3, color23, (float) (short) 100, 1, 1.0d);
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace32 = color31.getColorSpace();
        float[] floatArray36 = new float[] { (-254), 173, '#' };
        float[] floatArray37 = color23.getColorComponents(colorSpace32, floatArray36);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(colorSpace32);
        org.junit.Assert.assertNotNull(floatArray36);
        org.junit.Assert.assertNotNull(floatArray37);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor(8, (int) (byte) 1, (int) '#');
        int int11 = chartColor10.getRed();
        categoryPlot0.setBackgroundPaint((java.awt.Paint) chartColor10);
        java.awt.Color color13 = chartColor10.darker();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        barRenderer0.setDefaultEntityRadius(2);
        java.awt.Stroke stroke6 = barRenderer0.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot7.setRangeGridlineStroke(stroke19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        categoryPlot7.notifyListeners(plotChangeEvent21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot7.getRangeAxisEdge(3);
        barRenderer0.setPlot(categoryPlot7);
        boolean boolean27 = barRenderer0.isSeriesVisible((int) (short) 10);
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer0.setBaseShape(shape28, false);
        barRenderer0.setMaximumBarWidth(10.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator34 = null;
        barRenderer33.setBaseItemLabelGenerator(categoryItemLabelGenerator34, true);
        boolean boolean40 = barRenderer33.isItemLabelVisible((int) (byte) 10, 0, true);
        barRenderer33.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Paint paint44 = barRenderer33.lookupSeriesPaint((int) (short) -1);
        barRenderer0.setBaseFillPaint(paint44);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        categoryAxis1.setLowerMargin((double) (byte) 100);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        categoryPlot4.clearAnnotations();
        java.awt.Font font10 = categoryPlot4.getNoDataMessageFont();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setDomainAxisLocation(axisLocation11, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font16 = categoryAxis15.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryAxis15.getTickLabelInsets();
        categoryPlot4.setAxisOffset(rectangleInsets17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer19.setAutoPopulateSeriesShape(false);
        barRenderer19.setDefaultEntityRadius(2);
        java.awt.Stroke stroke25 = barRenderer19.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        categoryPlot26.addChangeListener(plotChangeListener27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot26.setBackgroundPaint((java.awt.Paint) color29);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font36 = categoryAxis35.getLabelFont();
        categoryAxis32.setTickLabelFont((java.lang.Comparable) 10.0d, font36);
        java.awt.Stroke stroke38 = categoryAxis32.getTickMarkStroke();
        categoryPlot26.setRangeGridlineStroke(stroke38);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent40 = null;
        categoryPlot26.notifyListeners(plotChangeEvent40);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot26.getRangeAxisEdge(3);
        barRenderer19.setPlot(categoryPlot26);
        boolean boolean46 = barRenderer19.isSeriesVisible((int) (short) 10);
        java.awt.Font font48 = barRenderer19.getLegendTextFont((-16727872));
        boolean boolean49 = rectangleInsets17.equals((java.lang.Object) barRenderer19);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation50 = null;
        try {
            barRenderer19.addAnnotation(categoryAnnotation50);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNull(font48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesVisible((int) (short) 0);
        lineAndShapeRenderer2.setSeriesVisibleInLegend(0, (java.lang.Boolean) false, true);
        boolean boolean9 = lineAndShapeRenderer2.getUseSeriesOffset();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape3 = renderAttributes0.getItemShape(8, 8);
        java.awt.Shape shape5 = renderAttributes0.getSeriesShape((-16727872));
        org.junit.Assert.assertNull(shape3);
        org.junit.Assert.assertNull(shape5);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator5, false);
        java.lang.Boolean boolean9 = barRenderer0.getSeriesCreateEntities(4);
        java.lang.Object obj10 = barRenderer0.clone();
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        int int13 = barRenderer0.getDefaultEntityRadius();
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        categoryPlot4.clearAnnotations();
        java.awt.Font font10 = categoryPlot4.getNoDataMessageFont();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setDomainAxisLocation(axisLocation11, true);
        categoryPlot4.clearDomainAxes();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font4 = categoryAxis3.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis3.getTickLabelInsets();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis3.setLabelPaint((java.awt.Paint) color6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis3, valueAxis8, categoryItemRenderer9);
        try {
            defaultCategoryDataset0.removeRow(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        java.awt.Stroke stroke7 = categoryAxis1.getTickMarkStroke();
        java.awt.Font font8 = categoryAxis1.getLabelFont();
        java.awt.Stroke stroke9 = categoryAxis1.getTickMarkStroke();
        java.awt.Paint paint10 = categoryAxis1.getLabelPaint();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        barRenderer0.setDefaultEntityRadius(2);
        java.awt.Paint paint6 = null;
        barRenderer0.setSeriesPaint(4, paint6, true);
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot14.setRenderer(categoryItemRenderer19);
        org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity(shape13, (org.jfree.chart.plot.Plot) categoryPlot14, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        categoryPlot23.addChangeListener(plotChangeListener24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot23.setBackgroundPaint((java.awt.Paint) color26);
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font33 = categoryAxis32.getLabelFont();
        categoryAxis29.setTickLabelFont((java.lang.Comparable) 10.0d, font33);
        java.awt.Stroke stroke35 = categoryAxis29.getTickMarkStroke();
        categoryPlot23.setRangeGridlineStroke(stroke35);
        java.awt.Color color38 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color39 = java.awt.Color.getColor("", color38);
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape13, stroke35, (java.awt.Paint) color39);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font46 = categoryAxis45.getLabelFont();
        categoryAxis42.setTickLabelFont((java.lang.Comparable) 10.0d, font46);
        legendItem40.setLabelFont(font46);
        legendItem40.setShapeVisible(false);
        java.awt.Shape shape51 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity53 = new org.jfree.chart.entity.ChartEntity(shape51, "hi!");
        legendItem40.setShape(shape51);
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection56 = categoryPlot55.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        org.jfree.chart.RenderingSource renderingSource60 = null;
        categoryPlot55.select((double) (-1L), (double) 100, rectangle2D59, renderingSource60);
        boolean boolean62 = categoryPlot55.canSelectByRegion();
        org.jfree.chart.entity.PlotEntity plotEntity65 = new org.jfree.chart.entity.PlotEntity(shape51, (org.jfree.chart.plot.Plot) categoryPlot55, "AxisLocation.TOP_OR_LEFT", "PlotEntity: tooltip = ");
        barRenderer0.setBaseShape(shape51, false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNull(legendItemCollection56);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape8, "hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot11.addChangeListener(plotChangeListener12);
        java.awt.Paint paint14 = categoryPlot11.getDomainGridlinePaint();
        java.awt.Stroke stroke15 = categoryPlot11.getRangeCrosshairStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = barRenderer16.getItemLabelGenerator(100, 100, false);
        int int21 = barRenderer16.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer16.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint24 = barRenderer16.lookupSeriesOutlinePaint(0);
        java.awt.Paint paint28 = barRenderer16.getItemFillPaint(0, (int) (short) 1, true);
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("PlotEntity: tooltip = ", "", "AxisLocation.BOTTOM_OR_LEFT", "Category Plot", shape8, stroke15, paint28);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        categoryPlot30.addChangeListener(plotChangeListener31);
        java.awt.Paint paint33 = categoryPlot30.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker34 = null;
        org.jfree.chart.util.Layer layer35 = null;
        boolean boolean36 = categoryPlot30.removeDomainMarker(marker34, layer35);
        org.jfree.data.category.CategoryDataset categoryDataset38 = categoryPlot30.getDataset(100);
        boolean boolean39 = categoryPlot30.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection40 = categoryPlot30.getLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = null;
        java.awt.geom.Point2D point2D43 = null;
        categoryPlot30.zoomRangeAxes(0.0d, plotRenderingInfo42, point2D43);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor47 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = null;
        double double52 = categoryAxis46.getCategoryJava2DCoordinate(categoryAnchor47, 0, (int) ' ', rectangle2D50, rectangleEdge51);
        java.awt.Paint paint53 = categoryAxis46.getLabelPaint();
        categoryPlot30.setBackgroundPaint(paint53);
        org.jfree.chart.LegendItem legendItem55 = new org.jfree.chart.LegendItem("ItemLabelAnchor.OUTSIDE4", "ItemLabelAnchor.OUTSIDE8", "CategoryAnchor.START", "", shape8, paint53);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(categoryItemLabelGenerator20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categoryDataset38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(legendItemCollection40);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        categoryAxis1.setMinorTickMarkOutsideLength(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot12.setBackgroundPaint((java.awt.Paint) color15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { color15, color17 };
        java.awt.Color color19 = java.awt.Color.YELLOW;
        int int20 = color19.getBlue();
        java.awt.Color color21 = java.awt.Color.ORANGE;
        java.awt.Color color22 = java.awt.Color.WHITE;
        java.awt.Color color23 = color22.darker();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray25 = new java.awt.Paint[] { color19, color21, color23, color24 };
        java.awt.Stroke stroke26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke27 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray28 = new java.awt.Stroke[] { stroke26, stroke27 };
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font34 = categoryAxis33.getLabelFont();
        categoryAxis30.setTickLabelFont((java.lang.Comparable) 10.0d, font34);
        java.awt.Stroke stroke36 = categoryAxis30.getTickMarkStroke();
        java.awt.Stroke[] strokeArray37 = new java.awt.Stroke[] { stroke36 };
        java.awt.Shape shape38 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray39 = new java.awt.Shape[] { shape38 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier40 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray18, paintArray25, strokeArray28, strokeArray37, shapeArray39);
        java.lang.Object obj41 = defaultDrawingSupplier40.clone();
        java.awt.Paint paint42 = defaultDrawingSupplier40.getNextOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) "UnitType.ABSOLUTE", paint42);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(paintArray25);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(strokeArray28);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(strokeArray37);
        org.junit.Assert.assertNotNull(shape38);
        org.junit.Assert.assertNotNull(shapeArray39);
        org.junit.Assert.assertNotNull(obj41);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke4 = renderAttributes1.getItemStroke((int) (short) 10, 128);
        java.awt.Paint paint5 = renderAttributes1.getDefaultLabelPaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        boolean boolean25 = categoryAxis23.isMinorTickMarksVisible();
        boolean boolean26 = categoryAxis23.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray27 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis23 };
        categoryPlot1.setDomainAxes(categoryAxisArray27);
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        categoryPlot30.addChangeListener(plotChangeListener31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot30.setBackgroundPaint((java.awt.Paint) color33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        categoryPlot30.setRenderer(categoryItemRenderer35);
        org.jfree.chart.entity.PlotEntity plotEntity38 = new org.jfree.chart.entity.PlotEntity(shape29, (org.jfree.chart.plot.Plot) categoryPlot30, "");
        categoryPlot30.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font46 = categoryAxis45.getLabelFont();
        categoryAxis42.setTickLabelFont((java.lang.Comparable) 10.0d, font46);
        java.awt.Stroke stroke48 = categoryAxis42.getTickMarkStroke();
        categoryPlot30.setDomainGridlineStroke(stroke48);
        java.lang.Comparable comparable50 = categoryPlot30.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font53 = categoryAxis52.getLabelFont();
        boolean boolean54 = categoryAxis52.isMinorTickMarksVisible();
        boolean boolean55 = categoryAxis52.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray56 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis52 };
        categoryPlot30.setDomainAxes(categoryAxisArray56);
        categoryPlot1.setDomainAxes(categoryAxisArray56);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 10.0f, (double) 0L, (double) 100, (double) 10.0f);
        categoryPlot1.setAxisOffset(rectangleInsets63);
        categoryPlot1.setDomainCrosshairRowKey((java.lang.Comparable) 0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent67 = null;
        categoryPlot1.rendererChanged(rendererChangeEvent67);
        categoryPlot1.clearAnnotations();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(comparable50);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray56);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        org.jfree.chart.plot.Plot plot10 = plotEntity9.getPlot();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator11 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator12 = null;
        java.lang.String str13 = plotEntity9.getImageMapAreaTag(toolTipTagFragmentGenerator11, uRLTagFragmentGenerator12);
        java.lang.Object obj14 = plotEntity9.clone();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        lineAndShapeRenderer2.clearSeriesPaints(true);
        lineAndShapeRenderer2.setUseFillPaint(true);
        boolean boolean10 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        lineAndShapeRenderer2.setAutoPopulateSeriesShape(true);
        java.lang.Object obj13 = lineAndShapeRenderer2.clone();
        lineAndShapeRenderer2.setItemMargin(0.2d);
        java.lang.Boolean boolean17 = lineAndShapeRenderer2.getSeriesLinesVisible(1);
        lineAndShapeRenderer2.setSeriesShapesVisible((int) (short) 100, true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(boolean17);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace6, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        java.awt.Stroke stroke12 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("PlotEntity: tooltip = ");
        categoryPlot0.setDomainAxis(categoryAxis14);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        categoryPlot0.setRangeAxis((int) (byte) 0, valueAxis17);
        java.util.List list20 = null;
        try {
            categoryPlot0.mapDatasetToDomainAxes(1, list20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color8, color10 };
        java.awt.Color color12 = java.awt.Color.YELLOW;
        int int13 = color12.getBlue();
        java.awt.Color color14 = java.awt.Color.ORANGE;
        java.awt.Color color15 = java.awt.Color.WHITE;
        java.awt.Color color16 = color15.darker();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { color12, color14, color16, color17 };
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] { stroke19, stroke20 };
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font27 = categoryAxis26.getLabelFont();
        categoryAxis23.setTickLabelFont((java.lang.Comparable) 10.0d, font27);
        java.awt.Stroke stroke29 = categoryAxis23.getTickMarkStroke();
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] { stroke29 };
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray32 = new java.awt.Shape[] { shape31 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray11, paintArray18, strokeArray21, strokeArray30, shapeArray32);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier33);
        categoryPlot0.setBackgroundImageAlignment((int) (byte) 10);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        categoryPlot0.setRangeAxis(valueAxis37);
        java.awt.Stroke stroke39 = categoryPlot0.getRangeZeroBaselineStroke();
        categoryPlot0.setRangeZeroBaselineVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor44 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        double double49 = categoryAxis43.getCategoryJava2DCoordinate(categoryAnchor44, 0, (int) ' ', rectangle2D47, rectangleEdge48);
        categoryAxis43.setCategoryMargin((double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis43.setTickLabelInsets(rectangleInsets52);
        boolean boolean54 = categoryPlot0.equals((java.lang.Object) categoryAxis43);
        double double55 = categoryAxis43.getLabelAngle();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shapeArray32);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace6, true);
        categoryPlot0.setBackgroundImageAlignment(2);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryPlot0.setInsets(rectangleInsets11, true);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        java.awt.Paint paint12 = categoryPlot1.getRangeCrosshairPaint();
        boolean boolean13 = categoryPlot1.canSelectByRegion();
        categoryPlot1.clearDomainAxes();
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot1.getDataset(8);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryDataset16);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.panRangeAxes((double) (short) 1, plotRenderingInfo11, point2D12);
        int int14 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNotNull(rectangleInsets15);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType32 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType32);
        legendItem31.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        java.lang.String str35 = legendItem31.getToolTipText();
        boolean boolean36 = legendItem31.isShapeFilled();
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.JFreeChart jFreeChart38 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType39 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape37, jFreeChart38, chartChangeEventType39);
        legendItem31.setShape(shape37);
        legendItem31.setDatasetIndex(1);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(chartChangeEventType39);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        lineAndShapeRenderer2.clearSeriesPaints(true);
        lineAndShapeRenderer2.setUseFillPaint(true);
        boolean boolean10 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        lineAndShapeRenderer2.setAutoPopulateSeriesShape(true);
        java.lang.Object obj13 = lineAndShapeRenderer2.clone();
        lineAndShapeRenderer2.setItemMargin(0.2d);
        java.lang.Boolean boolean17 = lineAndShapeRenderer2.getSeriesLinesVisible(1);
        java.awt.Font font18 = lineAndShapeRenderer2.getBaseLegendTextFont();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertNull(font18);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        categoryPlot0.axisChanged(axisChangeEvent2);
        int int4 = categoryPlot0.getRangeAxisCount();
        categoryPlot0.setAnchorValue(0.0d);
        java.awt.Paint paint7 = categoryPlot0.getOutlinePaint();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        boolean boolean22 = categoryPlot1.canSelectByPoint();
        org.jfree.chart.plot.Marker marker24 = null;
        org.jfree.chart.util.Layer layer25 = null;
        try {
            categoryPlot1.addRangeMarker(0, marker24, layer25, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = categoryPlot1.getRenderer();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot11.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font21 = categoryAxis20.getLabelFont();
        categoryAxis17.setTickLabelFont((java.lang.Comparable) 10.0d, font21);
        java.awt.Stroke stroke23 = categoryAxis17.getTickMarkStroke();
        categoryPlot11.setRangeGridlineStroke(stroke23);
        java.awt.Color color26 = java.awt.Color.WHITE;
        java.awt.Color color27 = color26.darker();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator31 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color26, (float) 100L, 10, (double) 0L);
        categoryPlot11.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator31);
        categoryPlot1.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator31);
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        categoryPlot1.setRangeCrosshairPaint((java.awt.Paint) color34);
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = null;
        org.jfree.chart.util.Layer layer38 = null;
        try {
            categoryPlot1.addDomainMarker((-1), categoryMarker37, layer38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(categoryItemRenderer10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color34);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        legendItem31.setLabelFont(font37);
        java.awt.Paint paint40 = legendItem31.getLinePaint();
        legendItem31.setURLText("{0}");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer43 = legendItem31.getFillPaintTransformer();
        legendItem31.setToolTipText("AxisLocation.BOTTOM_OR_LEFT");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer46 = legendItem31.getFillPaintTransformer();
        legendItem31.setShapeVisible(true);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(gradientPaintTransformer43);
        org.junit.Assert.assertNotNull(gradientPaintTransformer46);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        int int6 = barRenderer0.getRowCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = categoryPlot7.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean13 = categoryPlot7.removeDomainMarker(marker11, layer12);
        org.jfree.data.category.CategoryDataset categoryDataset15 = categoryPlot7.getDataset(100);
        boolean boolean16 = categoryPlot7.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection17 = categoryPlot7.getLegendItems();
        categoryPlot7.setRangeCrosshairValue((-9.0d));
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator21 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj22 = standardCategorySeriesLabelGenerator21.clone();
        java.lang.Object obj23 = null;
        boolean boolean24 = standardCategorySeriesLabelGenerator21.equals(obj23);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font27 = categoryAxis26.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryAxis26.getTickLabelInsets();
        java.awt.Color color29 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis26.setLabelPaint((java.awt.Paint) color29);
        boolean boolean31 = standardCategorySeriesLabelGenerator21.equals((java.lang.Object) color29);
        categoryPlot7.setDomainGridlinePaint((java.awt.Paint) color29);
        barRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator35 = null;
        barRenderer0.setSeriesItemLabelGenerator((int) (short) 100, categoryItemLabelGenerator35, false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(legendItemCollection17);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getDrawOutlines();
        java.lang.Boolean boolean8 = lineAndShapeRenderer2.getSeriesLinesVisible(0);
        lineAndShapeRenderer2.setSeriesShapesVisible(0, false);
        boolean boolean12 = lineAndShapeRenderer2.getUseOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        lineAndShapeRenderer2.clearSeriesPaints(true);
        lineAndShapeRenderer2.setUseFillPaint(true);
        boolean boolean10 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        lineAndShapeRenderer2.setAutoPopulateSeriesShape(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        categoryPlot13.addChangeListener(plotChangeListener14);
        java.awt.Paint paint16 = categoryPlot13.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot13.removeDomainMarker(marker17, layer18);
        org.jfree.data.category.CategoryDataset categoryDataset21 = categoryPlot13.getDataset(100);
        boolean boolean22 = categoryPlot13.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        categoryPlot13.setRangeAxis((int) (short) 100, valueAxis24, true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape28 = defaultDrawingSupplier27.getNextShape();
        java.awt.Shape shape29 = defaultDrawingSupplier27.getNextShape();
        java.awt.Stroke stroke30 = defaultDrawingSupplier27.getNextOutlineStroke();
        categoryPlot13.setRangeCrosshairStroke(stroke30);
        categoryPlot13.clearRangeAxes();
        boolean boolean33 = lineAndShapeRenderer2.hasListener((java.util.EventListener) categoryPlot13);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(categoryDataset21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        lineAndShapeRenderer2.clearSeriesPaints(true);
        lineAndShapeRenderer2.setUseFillPaint(true);
        boolean boolean10 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        lineAndShapeRenderer2.setAutoPopulateSeriesShape(true);
        java.lang.Object obj13 = lineAndShapeRenderer2.clone();
        int int14 = lineAndShapeRenderer2.getPassCount();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        lineAndShapeRenderer2.setBaseItemLabelGenerator(categoryItemLabelGenerator15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer2.getSeriesNegativeItemLabelPosition((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot0.setRenderer(3, categoryItemRenderer7);
        categoryPlot0.clearRangeMarkers((int) (short) 1);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot0.getRangeAxisLocation(0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer14.setAutoPopulateSeriesShape(false);
        barRenderer14.setDefaultEntityRadius(2);
        java.awt.Stroke stroke20 = barRenderer14.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        categoryPlot21.addChangeListener(plotChangeListener22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot21.setBackgroundPaint((java.awt.Paint) color24);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font31 = categoryAxis30.getLabelFont();
        categoryAxis27.setTickLabelFont((java.lang.Comparable) 10.0d, font31);
        java.awt.Stroke stroke33 = categoryAxis27.getTickMarkStroke();
        categoryPlot21.setRangeGridlineStroke(stroke33);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent35 = null;
        categoryPlot21.notifyListeners(plotChangeEvent35);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot21.getRangeAxisEdge(3);
        barRenderer14.setPlot(categoryPlot21);
        boolean boolean41 = barRenderer14.isSeriesVisible((int) (short) 10);
        java.awt.Shape shape42 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer14.setBaseShape(shape42, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener46 = null;
        categoryPlot45.addChangeListener(plotChangeListener46);
        java.awt.Paint paint48 = categoryPlot45.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker49 = null;
        org.jfree.chart.util.Layer layer50 = null;
        boolean boolean51 = categoryPlot45.removeDomainMarker(marker49, layer50);
        org.jfree.data.category.CategoryDataset categoryDataset53 = categoryPlot45.getDataset(100);
        boolean boolean54 = categoryPlot45.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection55 = categoryPlot45.getLegendItems();
        org.jfree.chart.event.PlotChangeListener plotChangeListener56 = null;
        categoryPlot45.addChangeListener(plotChangeListener56);
        org.jfree.chart.entity.PlotEntity plotEntity59 = new org.jfree.chart.entity.PlotEntity(shape42, (org.jfree.chart.plot.Plot) categoryPlot45, "PlotEntity: tooltip = ChartChangeEventType.DATASET_UPDATED");
        org.jfree.chart.axis.AxisLocation axisLocation61 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot45.setDomainAxisLocation(0, axisLocation61);
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation61);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(categoryDataset53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(legendItemCollection55);
        org.junit.Assert.assertNotNull(axisLocation61);
    }
}

