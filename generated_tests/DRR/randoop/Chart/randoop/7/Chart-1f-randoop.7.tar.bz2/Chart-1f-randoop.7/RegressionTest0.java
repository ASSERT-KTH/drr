import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test002");
//        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("hi!");
        boolean boolean3 = datasetGroup1.equals((java.lang.Object) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        boolean boolean2 = textAnchor0.equals((java.lang.Object) (short) 10);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray2 = null;
        try {
            float[] floatArray3 = color0.getColorComponents(colorSpace1, floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo2 = null;
        try {
            org.jfree.data.event.DatasetChangeEvent datasetChangeEvent3 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) 0.0d, dataset1, datasetChangeInfo2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.Stroke stroke6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint7 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        try {
            org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem(attributedString0, "", "hi!", "hi!", shape4, (java.awt.Paint) color5, stroke6, paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("hi!", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity6 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "", "hi!", categoryDataset3, (java.lang.Comparable) (short) 10, (java.lang.Comparable) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        double double5 = rectangleInsets3.calculateRightOutset((double) 8);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, 1.0d, (double) 1.0f, (double) 100);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets4.createOutsetRectangle(rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("hi!");
        java.lang.Object obj2 = datasetGroup1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        java.awt.Paint paint7 = null;
        try {
            categoryAxis1.setAxisLinePaint(paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name , locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        try {
            boolean boolean10 = categoryPlot0.removeRangeMarker(marker8, layer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType32 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType32);
        legendItem31.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        java.lang.Object obj35 = null;
        boolean boolean36 = standardGradientPaintTransformer33.equals(obj35);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.panRangeAxes((double) (short) 1, plotRenderingInfo11, point2D12);
        categoryPlot0.setDomainCrosshairVisible(true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        categoryPlot0.clearSelection();
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) 1.0d);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 10.0f, (double) 0L, (double) 100, (double) 10.0f);
        double double6 = rectangleInsets4.trimWidth(1.0d);
        double double8 = rectangleInsets4.trimWidth(0.0d);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets4.createOutsetRectangle(rectangle2D9, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-9.0d) + "'", double6 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-10.0d) + "'", double8 == (-10.0d));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "hi!");
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape4, "hi!", "");
        java.awt.Paint paint10 = null;
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot16.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot16.setRenderer(categoryItemRenderer21);
        org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity(shape15, (org.jfree.chart.plot.Plot) categoryPlot16, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot25.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font35 = categoryAxis34.getLabelFont();
        categoryAxis31.setTickLabelFont((java.lang.Comparable) 10.0d, font35);
        java.awt.Stroke stroke37 = categoryAxis31.getTickMarkStroke();
        categoryPlot25.setRangeGridlineStroke(stroke37);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color41 = java.awt.Color.getColor("", color40);
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape15, stroke37, (java.awt.Paint) color41);
        java.awt.Color color43 = org.jfree.chart.ChartColor.DARK_CYAN;
        try {
            org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem(attributedString0, "", "hi!", "PlotEntity: tooltip = ", shape4, paint10, stroke37, (java.awt.Paint) color43);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        java.awt.Stroke stroke7 = categoryPlot0.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator6 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 0, color2, (float) 8, 10, 4.0d);
        double double7 = defaultShadowGenerator6.getAngle();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        categoryPlot0.setRangeAxis(100, valueAxis7);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        java.awt.Stroke stroke7 = categoryAxis1.getTickMarkStroke();
        double double8 = categoryAxis1.getUpperMargin();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        java.awt.Paint paint13 = categoryPlot10.getDomainGridlinePaint();
        categoryPlot10.clearSelection();
        boolean boolean15 = categoryPlot10.isOutlineVisible();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        categoryPlot17.addChangeListener(plotChangeListener18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot17.setBackgroundPaint((java.awt.Paint) color20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font27 = categoryAxis26.getLabelFont();
        categoryAxis23.setTickLabelFont((java.lang.Comparable) 10.0d, font27);
        java.awt.Stroke stroke29 = categoryAxis23.getTickMarkStroke();
        categoryPlot17.setRangeGridlineStroke(stroke29);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent31 = null;
        categoryPlot17.notifyListeners(plotChangeEvent31);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot17.getRangeAxisEdge(3);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace36 = categoryAxis1.reserveSpace(graphics2D9, (org.jfree.chart.plot.Plot) categoryPlot10, rectangle2D16, rectangleEdge34, axisSpace35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        java.lang.String str10 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        categoryAxis1.setTickMarkInsideLength((float) (byte) 1);
        int int13 = categoryAxis1.getCategoryLabelPositionOffset();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 4 + "'", int13 == 4);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        categoryPlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot2.setBackgroundPaint((java.awt.Paint) color5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot2.setRenderer(categoryItemRenderer7);
        org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity(shape1, (org.jfree.chart.plot.Plot) categoryPlot2, "");
        categoryPlot2.setBackgroundAlpha((float) 10L);
        java.awt.Paint paint13 = categoryPlot2.getRangeCrosshairPaint();
        boolean boolean14 = categoryPlot2.canSelectByRegion();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot2.getRenderer(3);
        try {
            org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        java.awt.Paint paint7 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        categoryPlot0.setDomainCrosshairPaint(paint7);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(categoryItemRenderer5);
        boolean boolean7 = categoryPlot0.isDomainPannable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomRangeAxes(0.05d, plotRenderingInfo9, point2D10);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        java.awt.Color color2 = java.awt.Color.YELLOW;
        int int3 = color2.getBlue();
        categoryAxis1.setTickLabelPaint((java.awt.Paint) color2);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot8.setBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryAxis14.setTickLabelFont((java.lang.Comparable) 10.0d, font18);
        java.awt.Stroke stroke20 = categoryAxis14.getTickMarkStroke();
        categoryPlot8.setRangeGridlineStroke(stroke20);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent22 = null;
        categoryPlot8.notifyListeners(plotChangeEvent22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot8.getRangeAxisEdge(3);
        try {
            double double26 = categoryAxis1.getCategoryMiddle((-1), 3, rectangle2D7, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Color color0 = java.awt.Color.GRAY;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "hi!");
        boolean boolean4 = chartEntity2.equals((java.lang.Object) 1.0d);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer2 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        boolean boolean3 = categoryAxis1.isMinorTickMarksVisible();
        categoryAxis1.setMinorTickMarkInsideLength((float) (-16727872));
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.awt.Color color0 = java.awt.Color.WHITE;
        java.awt.Color color1 = color0.darker();
        java.awt.color.ColorSpace colorSpace2 = null;
        float[] floatArray4 = new float[] { 0.0f };
        try {
            float[] floatArray5 = color1.getColorComponents(colorSpace2, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) 100, 1.0d, (double) 1.0f, (double) 100);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        org.junit.Assert.assertNotNull(unitType5);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis1.setLabelInsets(rectangleInsets4, true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot9.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot9.setRenderer(categoryItemRenderer14);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) categoryPlot9, "");
        categoryPlot9.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font25 = categoryAxis24.getLabelFont();
        categoryAxis21.setTickLabelFont((java.lang.Comparable) 10.0d, font25);
        java.awt.Stroke stroke27 = categoryAxis21.getTickMarkStroke();
        categoryPlot9.setDomainGridlineStroke(stroke27);
        int int29 = categoryPlot9.getDomainAxisCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font32 = categoryAxis31.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis31.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener35 = null;
        categoryPlot34.addChangeListener(plotChangeListener35);
        java.awt.Paint paint37 = categoryPlot34.getDomainGridlinePaint();
        categoryAxis31.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot34);
        double double39 = categoryAxis31.getLabelAngle();
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset41 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState45 = null;
        try {
            java.awt.Shape shape46 = barRenderer0.createHotSpotShape(graphics2D6, rectangle2D7, categoryPlot9, categoryAxis31, valueAxis40, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset41, (int) (byte) 10, (-16727872), false, categoryItemRendererState45);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot9.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot9.setRenderer(categoryItemRenderer14);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) categoryPlot9, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        categoryPlot18.addChangeListener(plotChangeListener19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot18.setBackgroundPaint((java.awt.Paint) color21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font28 = categoryAxis27.getLabelFont();
        categoryAxis24.setTickLabelFont((java.lang.Comparable) 10.0d, font28);
        java.awt.Stroke stroke30 = categoryAxis24.getTickMarkStroke();
        categoryPlot18.setRangeGridlineStroke(stroke30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color34 = java.awt.Color.getColor("", color33);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape8, stroke30, (java.awt.Paint) color34);
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot37.addChangeListener(plotChangeListener38);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot37.setBackgroundPaint((java.awt.Paint) color40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font47 = categoryAxis46.getLabelFont();
        categoryAxis43.setTickLabelFont((java.lang.Comparable) 10.0d, font47);
        java.awt.Stroke stroke49 = categoryAxis43.getTickMarkStroke();
        categoryPlot37.setRangeGridlineStroke(stroke49);
        java.awt.Color color51 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        int int52 = color51.getGreen();
        try {
            org.jfree.chart.LegendItem legendItem53 = new org.jfree.chart.LegendItem(attributedString0, "", "", "{0}", shape8, (java.awt.Paint) color36, stroke49, (java.awt.Paint) color51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.chart.plot.Marker marker7 = null;
        try {
            boolean boolean8 = categoryPlot0.removeRangeMarker(marker7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        java.awt.Shape shape7 = barRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = barRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot11.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot16.setBackgroundPaint((java.awt.Paint) color19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray22 = new java.awt.Paint[] { color19, color21 };
        java.awt.Color color23 = java.awt.Color.YELLOW;
        int int24 = color23.getBlue();
        java.awt.Color color25 = java.awt.Color.ORANGE;
        java.awt.Color color26 = java.awt.Color.WHITE;
        java.awt.Color color27 = color26.darker();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray29 = new java.awt.Paint[] { color23, color25, color27, color28 };
        java.awt.Stroke stroke30 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke31 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray32 = new java.awt.Stroke[] { stroke30, stroke31 };
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font38 = categoryAxis37.getLabelFont();
        categoryAxis34.setTickLabelFont((java.lang.Comparable) 10.0d, font38);
        java.awt.Stroke stroke40 = categoryAxis34.getTickMarkStroke();
        java.awt.Stroke[] strokeArray41 = new java.awt.Stroke[] { stroke40 };
        java.awt.Shape shape42 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray43 = new java.awt.Shape[] { shape42 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier44 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray22, paintArray29, strokeArray32, strokeArray41, shapeArray43);
        categoryPlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier44);
        categoryPlot11.setBackgroundImageAlignment((int) (byte) 10);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        java.awt.Color color51 = java.awt.Color.WHITE;
        java.awt.Color color52 = color51.darker();
        java.awt.Stroke stroke53 = null;
        try {
            barRenderer0.drawRangeLine(graphics2D10, categoryPlot11, valueAxis48, rectangle2D49, (double) (-1L), (java.awt.Paint) color51, stroke53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintArray22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(paintArray29);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(strokeArray32);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(strokeArray41);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertNotNull(shapeArray43);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color52);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        org.jfree.chart.axis.AxisLocation axisLocation13 = categoryPlot10.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup14 = categoryPlot10.getDatasetGroup();
        java.awt.Font font15 = categoryPlot10.getNoDataMessageFont();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor19 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = categoryAxis17.getCategoryJava2DCoordinate(categoryAnchor19, (int) (byte) 100, (int) (byte) 1, rectangle2D22, rectangleEdge23);
        java.lang.String str26 = categoryAxis17.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        categoryAxis17.setTickMarkInsideLength((float) (byte) 1);
        java.lang.Object obj29 = null;
        boolean boolean30 = categoryAxis17.equals(obj29);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset32 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState36 = null;
        try {
            boolean boolean37 = barRenderer0.hitTest((double) 3, (double) 2, graphics2D8, rectangle2D9, categoryPlot10, categoryAxis17, valueAxis31, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset32, (-16727872), (int) (byte) 100, true, categoryItemRendererState36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNull(datasetGroup14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        boolean boolean12 = categoryPlot5.isDomainPannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis14.setLabelInsets(rectangleInsets15, true);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        categoryPlot23.addChangeListener(plotChangeListener24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot23.setBackgroundPaint((java.awt.Paint) color26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        categoryPlot23.setRenderer(categoryItemRenderer28);
        org.jfree.chart.entity.PlotEntity plotEntity31 = new org.jfree.chart.entity.PlotEntity(shape22, (org.jfree.chart.plot.Plot) categoryPlot23, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        categoryPlot32.addChangeListener(plotChangeListener33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot32.setBackgroundPaint((java.awt.Paint) color35);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font42 = categoryAxis41.getLabelFont();
        categoryAxis38.setTickLabelFont((java.lang.Comparable) 10.0d, font42);
        java.awt.Stroke stroke44 = categoryAxis38.getTickMarkStroke();
        categoryPlot32.setRangeGridlineStroke(stroke44);
        java.awt.Color color47 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color48 = java.awt.Color.getColor("", color47);
        org.jfree.chart.LegendItem legendItem49 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape22, stroke44, (java.awt.Paint) color48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font55 = categoryAxis54.getLabelFont();
        categoryAxis51.setTickLabelFont((java.lang.Comparable) 10.0d, font55);
        legendItem49.setLabelFont(font55);
        categoryAxis14.setTickLabelFont(font55);
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset60 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D66 = barRenderer0.createHotSpotBounds(graphics2D3, rectangle2D4, categoryPlot5, categoryAxis14, valueAxis59, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset60, (int) (byte) 100, 0, false, categoryItemRendererState64, rectangle2D65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(rectangleInsets15);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(font55);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo3 = null;
        try {
            org.jfree.data.event.DatasetChangeEvent datasetChangeEvent4 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) standardGradientPaintTransformer1, (org.jfree.data.general.Dataset) defaultCategoryDataset2, datasetChangeInfo3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        java.lang.String str10 = plotEntity9.getToolTipText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        java.awt.Stroke stroke7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        try {
            barRenderer0.setSeriesStroke((-16727872), stroke7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer11.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer15 = barRenderer11.getGradientPaintTransformer();
        try {
            categoryPlot1.setRenderer((int) (short) -1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(gradientPaintTransformer15);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 10.0f, (double) 0L, (double) 100, (double) 10.0f);
        double double6 = rectangleInsets4.calculateBottomOutset((double) 100);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        java.lang.Comparable comparable6 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset8 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font11 = categoryAxis10.getLabelFont();
        boolean boolean12 = categoryAxis10.isMinorTickMarksVisible();
        boolean boolean13 = categoryAxis10.isAxisLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis10.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.axis.AxisLocation axisLocation16 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation16, plotOrientation17);
        try {
            double double19 = barRenderer0.getItemMiddle(comparable6, (java.lang.Comparable) (byte) 100, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset8, categoryAxis10, rectangle2D15, rectangleEdge18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        java.awt.Shape shape7 = barRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = barRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot12.setBackgroundPaint((java.awt.Paint) color15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        categoryPlot12.axisChanged(axisChangeEvent17);
        java.util.List list19 = categoryPlot12.getCategories();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset20 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState22 = barRenderer0.initialise(graphics2D10, rectangle2D11, categoryPlot12, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNull(list19);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getLegendItems();
        try {
            categoryPlot0.zoom(100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor(8, (int) (byte) 1, (int) '#');
        int int11 = chartColor10.getRed();
        categoryPlot0.setBackgroundPaint((java.awt.Paint) chartColor10);
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        boolean boolean14 = chartColor10.equals((java.lang.Object) stroke13);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        categoryPlot0.clearSelection();
        boolean boolean5 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.plot.Marker marker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        try {
            categoryPlot0.addRangeMarker(marker6, layer7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        barRenderer0.setDefaultEntityRadius(2);
        java.awt.Stroke stroke6 = barRenderer0.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot7.setRangeGridlineStroke(stroke19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        categoryPlot7.notifyListeners(plotChangeEvent21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot7.getRangeAxisEdge(3);
        barRenderer0.setPlot(categoryPlot7);
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        categoryPlot29.addChangeListener(plotChangeListener30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot29.setBackgroundPaint((java.awt.Paint) color32);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font39 = categoryAxis38.getLabelFont();
        categoryAxis35.setTickLabelFont((java.lang.Comparable) 10.0d, font39);
        java.awt.Stroke stroke41 = categoryAxis35.getTickMarkStroke();
        categoryPlot29.setRangeGridlineStroke(stroke41);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent43 = null;
        categoryPlot29.notifyListeners(plotChangeEvent43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        categoryPlot29.zoomDomainAxes((double) (short) 1, plotRenderingInfo46, point2D47);
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis53 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font54 = categoryAxis53.getLabelFont();
        categoryAxis50.setTickLabelFont((java.lang.Comparable) 10.0d, font54);
        categoryAxis50.setLabelURL("hi!");
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        java.awt.Shape shape59 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener61 = null;
        categoryPlot60.addChangeListener(plotChangeListener61);
        java.awt.Color color63 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot60.setBackgroundPaint((java.awt.Paint) color63);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer65 = null;
        categoryPlot60.setRenderer(categoryItemRenderer65);
        org.jfree.chart.entity.PlotEntity plotEntity68 = new org.jfree.chart.entity.PlotEntity(shape59, (org.jfree.chart.plot.Plot) categoryPlot60, "");
        categoryPlot60.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis75 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font76 = categoryAxis75.getLabelFont();
        categoryAxis72.setTickLabelFont((java.lang.Comparable) 10.0d, font76);
        java.awt.Stroke stroke78 = categoryAxis72.getTickMarkStroke();
        categoryPlot60.setDomainGridlineStroke(stroke78);
        java.lang.Comparable comparable80 = categoryPlot60.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset81 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot60.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset81);
        try {
            barRenderer0.drawItem(graphics2D26, categoryItemRendererState27, rectangle2D28, categoryPlot29, categoryAxis50, valueAxis58, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset81, (int) (byte) 100, (-1), true, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(font54);
        org.junit.Assert.assertNotNull(shape59);
        org.junit.Assert.assertNotNull(color63);
        org.junit.Assert.assertNotNull(font76);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertNull(comparable80);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj2 = standardCategorySeriesLabelGenerator1.clone();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            java.lang.String str5 = standardCategorySeriesLabelGenerator1.generateLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        barRenderer0.setDrawBarOutline(false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        legendItem31.setLabelFont(font37);
        legendItem31.setShapeVisible(false);
        java.awt.Shape shape42 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity44 = new org.jfree.chart.entity.ChartEntity(shape42, "hi!");
        legendItem31.setShape(shape42);
        java.lang.String str46 = legendItem31.getToolTipText();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(shape42);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "hi!" + "'", str46.equals("hi!"));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType32 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType32);
        legendItem31.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        java.lang.Object obj35 = standardGradientPaintTransformer33.clone();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType36 = standardGradientPaintTransformer33.getType();
        java.lang.String str37 = gradientPaintTransformType36.toString();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType32);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(gradientPaintTransformType36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str37.equals("GradientPaintTransformType.CENTER_VERTICAL"));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        boolean boolean10 = categoryPlot1.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis12.setLabelInsets(rectangleInsets13, true);
        java.util.List list16 = categoryPlot1.getCategoriesForAxis(categoryAxis12);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        try {
            categoryPlot1.drawOutline(graphics2D17, rectangle2D18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        categoryAxis1.setMinorTickMarkOutsideLength(0.0f);
        categoryAxis1.setAxisLineVisible(true);
        categoryAxis1.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot0.notifyListeners(plotChangeEvent14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryPlot0.getAxisOffset();
        double double18 = rectangleInsets16.calculateLeftInset((double) 0L);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Shape shape4 = barRenderer0.getItemShape((int) (byte) 10, 1, true);
        org.junit.Assert.assertNotNull(shape4);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
        java.lang.String str3 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str3.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        java.awt.Paint paint12 = categoryPlot1.getRangeCrosshairPaint();
        boolean boolean13 = categoryPlot1.canSelectByRegion();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot1.getRenderer(3);
        categoryPlot1.clearDomainMarkers();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNull(categoryItemRenderer15);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        boolean boolean6 = categoryPlot0.isRangePannable();
        org.jfree.chart.plot.Marker marker7 = null;
        try {
            boolean boolean8 = categoryPlot0.removeRangeMarker(marker7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Color color1 = java.awt.Color.getColor("ChartChangeEventType.DATASET_UPDATED");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        barRenderer0.setSeriesOutlinePaint(0, paint7, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = null;
        try {
            barRenderer0.setSeriesItemLabelGenerator((-1), categoryItemLabelGenerator11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        categoryPlot0.select((double) (-1L), (double) 100, rectangle2D4, renderingSource5);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray7);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        categoryPlot0.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot25.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot25.setRenderer(categoryItemRenderer30);
        org.jfree.chart.entity.PlotEntity plotEntity33 = new org.jfree.chart.entity.PlotEntity(shape24, (org.jfree.chart.plot.Plot) categoryPlot25, "");
        java.lang.String str34 = plotEntity33.toString();
        boolean boolean35 = defaultCategoryDataset22.equals((java.lang.Object) plotEntity33);
        try {
            defaultCategoryDataset22.removeRow((java.lang.Comparable) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (1) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PlotEntity: tooltip = " + "'", str34.equals("PlotEntity: tooltip = "));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        categoryPlot0.select((double) (-1L), (double) 100, rectangle2D4, renderingSource5);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray7);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(categoryItemRenderer5);
        boolean boolean7 = categoryPlot0.isDomainPannable();
        boolean boolean8 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke10 = barRenderer0.getItemStroke(8, (int) (byte) 0, true);
        java.awt.Paint paint11 = barRenderer0.getShadowPaint();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        categoryPlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot13.setBackgroundPaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot13.setRenderer(categoryItemRenderer18);
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            barRenderer0.drawBackground(graphics2D12, categoryPlot13, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font9 = categoryAxis8.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = null;
        double double15 = categoryAxis8.getCategoryJava2DCoordinate(categoryAnchor10, (int) (byte) 100, (int) (byte) 1, rectangle2D13, rectangleEdge14);
        int int16 = categoryAxis8.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke17 = categoryAxis8.getTickMarkStroke();
        try {
            barRenderer0.setSeriesOutlineStroke((-1), stroke17, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.panRangeAxes((double) (short) 1, plotRenderingInfo11, point2D12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryItemRenderer14);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            defaultCategoryDataset0.removeRow((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        categoryPlot0.select((double) (-1L), (double) 100, rectangle2D4, renderingSource5);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray7);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier11, true);
        boolean boolean14 = categoryPlot0.isRangePannable();
        java.awt.Stroke stroke15 = null;
        try {
            categoryPlot0.setRangeMinorGridlineStroke(stroke15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator5, false);
        java.lang.Boolean boolean9 = barRenderer0.getSeriesCreateEntities(4);
        java.lang.Object obj10 = barRenderer0.clone();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation11 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        org.jfree.chart.plot.Plot plot10 = plotEntity9.getPlot();
        plotEntity9.setURLText("AxisLocation.BOTTOM_OR_LEFT");
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(plot10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        barRenderer0.setDefaultEntityRadius(2);
        java.awt.Stroke stroke6 = barRenderer0.lookupSeriesOutlineStroke((int) (byte) 1);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot8.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.RenderingSource renderingSource13 = null;
        categoryPlot8.select((double) (-1L), (double) 100, rectangle2D12, renderingSource13);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray15 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot8.setRenderers(categoryItemRendererArray15);
        categoryPlot8.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = null;
        categoryPlot8.setDrawingSupplier(drawingSupplier19, true);
        boolean boolean22 = categoryPlot8.isRangePannable();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState27 = null;
        boolean boolean28 = categoryPlot8.render(graphics2D23, rectangle2D24, (int) (short) 100, plotRenderingInfo26, categoryCrosshairState27);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        try {
            barRenderer0.drawBackground(graphics2D7, categoryPlot8, rectangle2D29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(categoryItemRendererArray15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets((double) 10.0f, (double) 0L, (double) 100, (double) 10.0f);
        boolean boolean6 = itemLabelAnchor0.equals((java.lang.Object) 100);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        java.awt.Stroke stroke7 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.setLabel("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]");
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        boolean boolean7 = barRenderer0.isItemLabelVisible((int) (byte) 10, 0, true);
        barRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        barRenderer0.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        categoryPlot0.configureDomainAxes();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        categoryPlot0.setRangeCrosshairValue((double) 10);
        categoryPlot0.setAnchorValue((double) 0.0f);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        categoryPlot0.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot0.getRenderer();
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = null;
        try {
            categoryPlot0.addRangeMarker((int) (short) -1, marker23, layer24, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryItemRenderer21);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace6, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        categoryPlot17.addChangeListener(plotChangeListener18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot17.setBackgroundPaint((java.awt.Paint) color20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        categoryPlot17.setRenderer(categoryItemRenderer22);
        org.jfree.chart.entity.PlotEntity plotEntity25 = new org.jfree.chart.entity.PlotEntity(shape16, (org.jfree.chart.plot.Plot) categoryPlot17, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        categoryPlot26.addChangeListener(plotChangeListener27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot26.setBackgroundPaint((java.awt.Paint) color29);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font36 = categoryAxis35.getLabelFont();
        categoryAxis32.setTickLabelFont((java.lang.Comparable) 10.0d, font36);
        java.awt.Stroke stroke38 = categoryAxis32.getTickMarkStroke();
        categoryPlot26.setRangeGridlineStroke(stroke38);
        java.awt.Color color41 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color42 = java.awt.Color.getColor("", color41);
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape16, stroke38, (java.awt.Paint) color42);
        categoryPlot0.setRangeCrosshairStroke(stroke38);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color42);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesShape();
        java.awt.Paint paint9 = barRenderer0.lookupLegendTextPaint((int) (byte) 10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke10 = categoryAxis1.getTickMarkStroke();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) 0.5f);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font15 = categoryAxis14.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis14.getCategoryJava2DCoordinate(categoryAnchor16, (int) (byte) 100, (int) (byte) 1, rectangle2D19, rectangleEdge20);
        java.lang.String str23 = categoryAxis14.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        categoryAxis14.setLabelAngle((double) (short) 100);
        java.awt.Font font26 = categoryAxis14.getLabelFont();
        categoryAxis1.setTickLabelFont(font26);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNull(str23);
        org.junit.Assert.assertNotNull(font26);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = null;
        try {
            org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'type' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        barRenderer0.setDefaultEntityRadius(2);
        java.awt.Stroke stroke6 = barRenderer0.lookupSeriesOutlineStroke((int) (byte) 1);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.Color color12 = java.awt.Color.YELLOW;
        int int13 = color12.getBlue();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape15 = defaultDrawingSupplier14.getNextShape();
        java.awt.Shape shape16 = defaultDrawingSupplier14.getNextShape();
        java.awt.Stroke stroke17 = defaultDrawingSupplier14.getNextOutlineStroke();
        try {
            barRenderer0.drawRangeLine(graphics2D7, categoryPlot8, valueAxis9, rectangle2D10, (double) 100.0f, (java.awt.Paint) color12, stroke17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean1 = renderAttributes0.getDefaultLabelVisible();
        org.junit.Assert.assertNull(boolean1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        float float7 = categoryAxis1.getTickMarkInsideLength();
        java.awt.Font font9 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 4.0d);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor1 = itemLabelPosition0.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor2 = itemLabelPosition0.getTextAnchor();
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(textAnchor2);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot0.setRenderer(3, categoryItemRenderer7);
        categoryPlot0.clearRangeMarkers((int) (short) 1);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace11);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        int int1 = paintList0.size();
        java.awt.Paint paint3 = paintList0.getPaint((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("");
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        lineAndShapeRenderer2.setSeriesShapesFilled(3, (java.lang.Boolean) true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font11 = categoryAxis10.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis10.getTickLabelInsets();
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis10.setLabelPaint((java.awt.Paint) color13);
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color13);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryAxis1.getTickLabelInsets();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint8 = barRenderer0.lookupSeriesOutlinePaint(0);
        java.awt.Stroke stroke9 = null;
        try {
            barRenderer0.setBaseStroke(stroke9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            boolean boolean14 = categoryPlot4.removeRangeMarker((-16727872), marker11, layer12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.util.ShapeList shapeList4 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6, "hi!");
        shapeList4.setShape(0, shape6);
        java.awt.Paint paint10 = null;
        try {
            org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("PlotEntity: tooltip = ", "", "PlotEntity: tooltip = ", "", shape6, paint10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        categoryPlot0.clearSelection();
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace5);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator5, false);
        java.awt.Color color9 = java.awt.Color.lightGray;
        try {
            barRenderer0.setSeriesOutlinePaint((-1), (java.awt.Paint) color9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType32 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType32);
        legendItem31.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        java.lang.Object obj35 = standardGradientPaintTransformer33.clone();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType36 = standardGradientPaintTransformer33.getType();
        java.awt.GradientPaint gradientPaint37 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer38.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer42 = barRenderer38.getGradientPaintTransformer();
        java.awt.Shape shape44 = barRenderer38.lookupLegendShape((int) (short) 10);
        try {
            java.awt.GradientPaint gradientPaint45 = standardGradientPaintTransformer33.transform(gradientPaint37, shape44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType32);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(gradientPaintTransformType36);
        org.junit.Assert.assertNotNull(gradientPaintTransformer42);
        org.junit.Assert.assertNotNull(shape44);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Paint paint3 = barRenderer0.lookupSeriesOutlinePaint((int) (byte) 100);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = categoryPlot7.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean13 = categoryPlot7.removeDomainMarker(marker11, layer12);
        boolean boolean14 = categoryPlot7.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot15.setBackgroundPaint((java.awt.Paint) color18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font25 = categoryAxis24.getLabelFont();
        categoryAxis21.setTickLabelFont((java.lang.Comparable) 10.0d, font25);
        java.awt.Stroke stroke27 = categoryAxis21.getTickMarkStroke();
        categoryPlot15.setRangeGridlineStroke(stroke27);
        categoryPlot7.setRangeGridlineStroke(stroke27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot7.setRenderer((int) (byte) 1, categoryItemRenderer31);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        java.awt.Shape shape36 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot37.addChangeListener(plotChangeListener38);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot37.setBackgroundPaint((java.awt.Paint) color40);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        categoryPlot37.setRenderer(categoryItemRenderer42);
        org.jfree.chart.entity.PlotEntity plotEntity45 = new org.jfree.chart.entity.PlotEntity(shape36, (org.jfree.chart.plot.Plot) categoryPlot37, "");
        categoryPlot37.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font53 = categoryAxis52.getLabelFont();
        categoryAxis49.setTickLabelFont((java.lang.Comparable) 10.0d, font53);
        java.awt.Stroke stroke55 = categoryAxis49.getTickMarkStroke();
        categoryPlot37.setDomainGridlineStroke(stroke55);
        java.lang.Comparable comparable57 = categoryPlot37.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset58 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot37.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset58);
        defaultCategoryDataset58.clearSelection();
        try {
            barRenderer0.drawItem(graphics2D4, categoryItemRendererState5, rectangle2D6, categoryPlot7, categoryAxis34, valueAxis35, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset58, 128, (int) (byte) 100, false, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNull(comparable57);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        boolean boolean7 = barRenderer0.isItemLabelVisible((int) (byte) 10, 0, true);
        java.awt.Shape shape9 = barRenderer0.getSeriesShape((int) (short) -1);
        barRenderer0.setBaseSeriesVisible(true, false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(shape9);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        boolean boolean2 = plotOrientation0.equals((java.lang.Object) font1);
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        boolean boolean3 = categoryAxis1.isMinorTickMarksVisible();
        boolean boolean4 = categoryAxis1.isAxisLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font8 = categoryAxis7.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis7.getTickLabelInsets();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor10 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        boolean boolean11 = rectangleInsets9.equals((java.lang.Object) itemLabelAnchor10);
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets9.getUnitType();
        categoryAxis1.setLabelInsets(rectangleInsets9);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(itemLabelAnchor10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(unitType12);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Color color0 = java.awt.Color.BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8, true);
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot0.setRangeAxis((int) (short) 100, valueAxis11, true);
        org.jfree.chart.JFreeChart jFreeChart14 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType15 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) valueAxis11, jFreeChart14, chartChangeEventType15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType15);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis1.setLabelInsets(rectangleInsets4, true);
        double double8 = rectangleInsets4.calculateBottomOutset((double) (byte) 10);
        double double10 = rectangleInsets4.calculateRightInset((double) 0L);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType13 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets4.createAdjustedRectangle(rectangle2D11, lengthAdjustmentType12, lengthAdjustmentType13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        categoryPlot0.select((double) (-1L), (double) 100, rectangle2D4, renderingSource5);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray7);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.Marker marker11 = null;
        try {
            boolean boolean12 = categoryPlot0.removeRangeMarker(marker11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        lineAndShapeRenderer2.clearSeriesPaints(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot8.addChangeListener(plotChangeListener9);
        java.awt.Paint paint11 = categoryPlot8.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        boolean boolean14 = categoryPlot8.removeDomainMarker(marker12, layer13);
        org.jfree.chart.ChartColor chartColor18 = new org.jfree.chart.ChartColor(8, (int) (byte) 1, (int) '#');
        int int19 = chartColor18.getRed();
        categoryPlot8.setBackgroundPaint((java.awt.Paint) chartColor18);
        lineAndShapeRenderer2.setBaseItemLabelPaint((java.awt.Paint) chartColor18, false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 8 + "'", int19 == 8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        org.jfree.chart.plot.Marker marker9 = null;
        try {
            categoryPlot4.addRangeMarker(marker9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        java.awt.Shape shape7 = barRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = barRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot11.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.RenderingSource renderingSource16 = null;
        categoryPlot11.select((double) (-1L), (double) 100, rectangle2D15, renderingSource16);
        boolean boolean18 = categoryPlot11.canSelectByRegion();
        java.awt.Stroke stroke19 = categoryPlot11.getOutlineStroke();
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            barRenderer0.drawOutline(graphics2D10, categoryPlot11, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(legendItemCollection12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke19);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator5, false);
        boolean boolean10 = barRenderer0.getItemVisible(2, 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint8 = null;
        barRenderer0.setSeriesPaint(128, paint8);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("PlotEntity: tooltip = ");
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot4.setBackgroundPaint((java.awt.Paint) color7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray10 = new java.awt.Paint[] { color7, color9 };
        java.awt.Color color11 = java.awt.Color.YELLOW;
        int int12 = color11.getBlue();
        java.awt.Color color13 = java.awt.Color.ORANGE;
        java.awt.Color color14 = java.awt.Color.WHITE;
        java.awt.Color color15 = color14.darker();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color11, color13, color15, color16 };
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke18, stroke19 };
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font26 = categoryAxis25.getLabelFont();
        categoryAxis22.setTickLabelFont((java.lang.Comparable) 10.0d, font26);
        java.awt.Stroke stroke28 = categoryAxis22.getTickMarkStroke();
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] { stroke28 };
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray31 = new java.awt.Shape[] { shape30 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray17, strokeArray20, strokeArray29, shapeArray31);
        java.lang.Object obj33 = defaultDrawingSupplier32.clone();
        java.awt.Paint paint34 = defaultDrawingSupplier32.getNextOutlinePaint();
        barRenderer0.setBaseOutlinePaint(paint34, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator37 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator37);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shapeArray31);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        try {
            lineAndShapeRenderer2.setSeriesShapesFilled((int) (short) -1, (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertNull(axisSpace7);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.panRangeAxes((double) (short) 1, plotRenderingInfo11, point2D12);
        float float14 = categoryPlot0.getBackgroundImageAlpha();
        categoryPlot0.clearSelection();
        categoryPlot0.configureRangeAxes();
        categoryPlot0.setDomainGridlinesVisible(true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        int int21 = categoryPlot1.getDomainAxisCount();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation22 = null;
        try {
            boolean boolean23 = categoryPlot1.removeAnnotation(categoryAnnotation22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        barRenderer0.setSeriesOutlinePaint(0, paint7, true);
        barRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = barRenderer0.getLegendItemLabelGenerator();
        java.lang.Object obj13 = barRenderer0.clone();
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator5, false);
        java.lang.Boolean boolean9 = barRenderer0.getSeriesCreateEntities(4);
        java.lang.Object obj10 = barRenderer0.clone();
        boolean boolean11 = barRenderer0.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        float float7 = categoryAxis1.getTickMarkInsideLength();
        float float8 = categoryAxis1.getMinorTickMarkInsideLength();
        java.awt.Stroke stroke9 = categoryAxis1.getTickMarkStroke();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        categoryPlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot13.setBackgroundPaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot13.setRenderer(categoryItemRenderer18);
        boolean boolean20 = categoryPlot13.isDomainPannable();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        categoryPlot22.addChangeListener(plotChangeListener23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = categoryPlot22.getDomainAxisLocation();
        categoryPlot13.setDomainAxisLocation(1, axisLocation25, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation28 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation25, plotOrientation28);
        try {
            double double30 = categoryAxis1.getCategoryMiddle(0, 0, rectangle2D12, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation25);
        org.junit.Assert.assertNotNull(plotOrientation28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor(8, (int) (byte) 1, (int) '#');
        int int11 = chartColor10.getRed();
        categoryPlot0.setBackgroundPaint((java.awt.Paint) chartColor10);
        java.awt.Shape shape17 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        categoryPlot18.addChangeListener(plotChangeListener19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot18.setBackgroundPaint((java.awt.Paint) color21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        categoryPlot18.setRenderer(categoryItemRenderer23);
        org.jfree.chart.entity.PlotEntity plotEntity26 = new org.jfree.chart.entity.PlotEntity(shape17, (org.jfree.chart.plot.Plot) categoryPlot18, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        categoryPlot27.addChangeListener(plotChangeListener28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot27.setBackgroundPaint((java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        java.awt.Stroke stroke39 = categoryAxis33.getTickMarkStroke();
        categoryPlot27.setRangeGridlineStroke(stroke39);
        java.awt.Color color42 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color43 = java.awt.Color.getColor("", color42);
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape17, stroke39, (java.awt.Paint) color43);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font50 = categoryAxis49.getLabelFont();
        categoryAxis46.setTickLabelFont((java.lang.Comparable) 10.0d, font50);
        legendItem44.setLabelFont(font50);
        java.awt.Paint paint53 = legendItem44.getLinePaint();
        categoryPlot0.setOutlinePaint(paint53);
        org.jfree.chart.axis.AxisSpace axisSpace55 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertNotNull(paint53);
        org.junit.Assert.assertNull(axisSpace55);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        boolean boolean7 = barRenderer0.isItemLabelVisible((int) (byte) 10, 0, true);
        barRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        barRenderer0.setBaseSeriesVisibleInLegend(true, true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        java.awt.Stroke stroke7 = categoryAxis1.getTickMarkStroke();
        java.awt.Font font8 = categoryAxis1.getLabelFont();
        java.awt.Stroke stroke9 = categoryAxis1.getTickMarkStroke();
        java.awt.Font font10 = categoryAxis1.getTickLabelFont();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.AxisLocation axisLocation14 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot15.setBackgroundPaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        categoryPlot15.setRenderer(categoryItemRenderer20);
        boolean boolean22 = categoryPlot15.isDomainPannable();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot24.addChangeListener(plotChangeListener25);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot24.getDomainAxisLocation();
        categoryPlot15.setDomainAxisLocation(1, axisLocation27, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation27, plotOrientation30);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation14, plotOrientation30);
        try {
            java.util.List list33 = categoryAxis1.refreshTicks(graphics2D11, axisState12, rectangle2D13, rectangleEdge32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor(8, (int) (byte) 1, (int) '#');
        int int11 = chartColor10.getRed();
        java.awt.Paint paint13 = null;
        java.awt.Stroke stroke14 = null;
        java.awt.Shape shape16 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity18 = new org.jfree.chart.entity.ChartEntity(shape16, "hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        categoryPlot19.addChangeListener(plotChangeListener20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot19.setBackgroundPaint((java.awt.Paint) color22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot24.addChangeListener(plotChangeListener25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot24.setBackgroundPaint((java.awt.Paint) color27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray30 = new java.awt.Paint[] { color27, color29 };
        java.awt.Color color31 = java.awt.Color.YELLOW;
        int int32 = color31.getBlue();
        java.awt.Color color33 = java.awt.Color.ORANGE;
        java.awt.Color color34 = java.awt.Color.WHITE;
        java.awt.Color color35 = color34.darker();
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray37 = new java.awt.Paint[] { color31, color33, color35, color36 };
        java.awt.Stroke stroke38 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke39 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray40 = new java.awt.Stroke[] { stroke38, stroke39 };
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font46 = categoryAxis45.getLabelFont();
        categoryAxis42.setTickLabelFont((java.lang.Comparable) 10.0d, font46);
        java.awt.Stroke stroke48 = categoryAxis42.getTickMarkStroke();
        java.awt.Stroke[] strokeArray49 = new java.awt.Stroke[] { stroke48 };
        java.awt.Shape shape50 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray51 = new java.awt.Shape[] { shape50 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier52 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray30, paintArray37, strokeArray40, strokeArray49, shapeArray51);
        categoryPlot19.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier52);
        org.jfree.chart.entity.PlotEntity plotEntity56 = new org.jfree.chart.entity.PlotEntity(shape16, (org.jfree.chart.plot.Plot) categoryPlot19, "ChartChangeEventType.DATASET_UPDATED", "hi!");
        java.awt.Stroke stroke57 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        java.awt.Color color58 = java.awt.Color.WHITE;
        java.awt.Color color59 = color58.darker();
        try {
            org.jfree.chart.LegendItem legendItem60 = new org.jfree.chart.LegendItem("{0}", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]", "Category Plot", "ChartChangeEventType.DATASET_UPDATED", false, shape5, false, (java.awt.Paint) chartColor10, false, paint13, stroke14, false, shape16, stroke57, (java.awt.Paint) color58);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'outlinePaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(paintArray30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(paintArray37);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(strokeArray40);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(strokeArray49);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(shapeArray51);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(color59);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType32 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType32);
        legendItem31.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        java.lang.Object obj35 = standardGradientPaintTransformer33.clone();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType36 = standardGradientPaintTransformer33.getType();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer37 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType36);
        java.lang.String str38 = gradientPaintTransformType36.toString();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType32);
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNotNull(gradientPaintTransformType36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str38.equals("GradientPaintTransformType.CENTER_VERTICAL"));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        int int21 = categoryPlot1.getDomainAxisCount();
        categoryPlot1.clearDomainMarkers(0);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        float float7 = categoryAxis1.getTickMarkInsideLength();
        float float8 = categoryAxis1.getMinorTickMarkInsideLength();
        categoryAxis1.setUpperMargin((double) '4');
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape0, jFreeChart1, chartChangeEventType2);
        java.lang.String str4 = chartChangeEvent3.toString();
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType7 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent8 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape5, jFreeChart6, chartChangeEventType7);
        chartChangeEvent3.setType(chartChangeEventType7);
        java.lang.String str10 = chartChangeEventType7.toString();
        java.lang.String str11 = chartChangeEventType7.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]"));
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(chartChangeEventType7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str10.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str11.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation0, plotOrientation1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation3);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        int int1 = legendItemCollection0.getItemCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace6, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        java.awt.Stroke stroke12 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot0.getDomainMarkers(layer13);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(collection14);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        barRenderer0.setSeriesOutlinePaint(0, paint7, true);
        barRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer0.notifyListeners(rendererChangeEvent12);
        try {
            barRenderer0.setSeriesItemLabelsVisible((int) (short) -1, (java.lang.Boolean) true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.awt.Color color2 = java.awt.Color.getColor("Category Plot", (int) '4');
        int int3 = color2.getTransparency();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        java.lang.String str14 = categoryPlot0.getPlotType();
        double double15 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        barRenderer0.setSeriesOutlinePaint(0, paint7, true);
        barRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = barRenderer0.getLegendItemLabelGenerator();
        java.awt.Paint paint14 = barRenderer0.getSeriesOutlinePaint(0);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color8, color10 };
        java.awt.Color color12 = java.awt.Color.YELLOW;
        int int13 = color12.getBlue();
        java.awt.Color color14 = java.awt.Color.ORANGE;
        java.awt.Color color15 = java.awt.Color.WHITE;
        java.awt.Color color16 = color15.darker();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { color12, color14, color16, color17 };
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] { stroke19, stroke20 };
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font27 = categoryAxis26.getLabelFont();
        categoryAxis23.setTickLabelFont((java.lang.Comparable) 10.0d, font27);
        java.awt.Stroke stroke29 = categoryAxis23.getTickMarkStroke();
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] { stroke29 };
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray32 = new java.awt.Shape[] { shape31 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray11, paintArray18, strokeArray21, strokeArray30, shapeArray32);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier33);
        categoryPlot0.setDomainCrosshairVisible(false);
        boolean boolean37 = categoryPlot0.isRangePannable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        categoryPlot0.zoomDomainAxes((double) (byte) -1, (double) 0, plotRenderingInfo40, point2D41);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shapeArray32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(100);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        categoryPlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot3.setBackgroundPaint((java.awt.Paint) color6);
        objectList1.set((int) (short) 1, (java.lang.Object) categoryPlot3);
        java.lang.Object obj10 = objectList1.get(0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(obj10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        java.awt.Color color7 = java.awt.Color.YELLOW;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font11 = categoryAxis10.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis10.getTickLabelInsets();
        categoryAxis1.setLabelInsets(rectangleInsets12, false);
        double double16 = rectangleInsets12.calculateRightInset((-9.0d));
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean2 = barRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition();
        java.awt.Color color5 = java.awt.Color.WHITE;
        java.awt.Color color6 = color5.darker();
        boolean boolean7 = itemLabelPosition4.equals((java.lang.Object) color5);
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition4, false);
        boolean boolean12 = barRenderer0.getItemVisible((int) (short) 100, (int) (byte) 10);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        categoryPlot0.axisChanged(axisChangeEvent2);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.RenderingSource renderingSource7 = null;
        categoryPlot0.select((-10.0d), 0.0d, rectangle2D6, renderingSource7);
        org.junit.Assert.assertNull(legendItemCollection1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        float[] floatArray4 = new float[] { 10L };
        try {
            float[] floatArray5 = color0.getColorComponents(colorSpace2, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.panRangeAxes((double) (short) 1, plotRenderingInfo11, point2D12);
        float float14 = categoryPlot0.getBackgroundImageAlpha();
        categoryPlot0.clearSelection();
        org.jfree.chart.util.SortOrder sortOrder16 = categoryPlot0.getRowRenderingOrder();
        java.awt.Paint paint17 = null;
        try {
            categoryPlot0.setDomainCrosshairPaint(paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNotNull(sortOrder16);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        float[] floatArray6 = new float[] { 128, (short) 1, 0L };
        try {
            float[] floatArray7 = color0.getComponents(colorSpace2, floatArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(floatArray6);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(categoryItemRenderer5);
        boolean boolean7 = categoryPlot0.isDomainPannable();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot9.getDomainAxisLocation();
        categoryPlot0.setDomainAxisLocation(1, axisLocation12, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation12, plotOrientation15);
        java.lang.String str17 = axisLocation12.toString();
        java.lang.String str18 = axisLocation12.toString();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str17.equals("AxisLocation.BOTTOM_OR_LEFT"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str18.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        java.lang.String str10 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        boolean boolean11 = categoryAxis1.isMinorTickMarksVisible();
        org.jfree.chart.plot.Plot plot12 = categoryAxis1.getPlot();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(plot12);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape5 = defaultDrawingSupplier4.getNextShape();
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = barRenderer7.getItemLabelGenerator(100, 100, false);
        int int12 = barRenderer7.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer7.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint15 = barRenderer7.lookupSeriesOutlinePaint(0);
        java.awt.Paint paint19 = barRenderer7.getItemFillPaint(0, (int) (short) 1, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        java.awt.Paint paint23 = categoryPlot20.getDomainGridlinePaint();
        categoryPlot20.clearSelection();
        boolean boolean25 = categoryPlot20.isOutlineVisible();
        int int26 = categoryPlot20.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        categoryPlot27.addChangeListener(plotChangeListener28);
        java.awt.Color color30 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot27.setBackgroundPaint((java.awt.Paint) color30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray33 = new java.awt.Paint[] { color30, color32 };
        java.awt.Color color34 = java.awt.Color.YELLOW;
        int int35 = color34.getBlue();
        java.awt.Color color36 = java.awt.Color.ORANGE;
        java.awt.Color color37 = java.awt.Color.WHITE;
        java.awt.Color color38 = color37.darker();
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray40 = new java.awt.Paint[] { color34, color36, color38, color39 };
        java.awt.Stroke stroke41 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke42 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray43 = new java.awt.Stroke[] { stroke41, stroke42 };
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font49 = categoryAxis48.getLabelFont();
        categoryAxis45.setTickLabelFont((java.lang.Comparable) 10.0d, font49);
        java.awt.Stroke stroke51 = categoryAxis45.getTickMarkStroke();
        java.awt.Stroke[] strokeArray52 = new java.awt.Stroke[] { stroke51 };
        java.awt.Shape shape53 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray54 = new java.awt.Shape[] { shape53 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier55 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray33, paintArray40, strokeArray43, strokeArray52, shapeArray54);
        java.lang.Object obj56 = defaultDrawingSupplier55.clone();
        java.awt.Paint paint57 = defaultDrawingSupplier55.getNextOutlinePaint();
        categoryPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier55);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray59 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot20.setRangeAxes(valueAxisArray59);
        java.awt.Paint paint61 = categoryPlot20.getOutlinePaint();
        java.awt.Stroke stroke62 = categoryPlot20.getRangeGridlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor65 = null;
        java.awt.geom.Rectangle2D rectangle2D68 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = null;
        double double70 = categoryAxis64.getCategoryJava2DCoordinate(categoryAnchor65, 0, (int) ' ', rectangle2D68, rectangleEdge69);
        categoryAxis64.setCategoryMargin((double) (byte) 100);
        java.awt.Color color73 = java.awt.Color.YELLOW;
        int int74 = color73.getBlue();
        categoryAxis64.setTickLabelPaint((java.awt.Paint) color73);
        try {
            org.jfree.chart.LegendItem legendItem76 = new org.jfree.chart.LegendItem(attributedString0, "Category Plot", "", "GradientPaintTransformType.CENTER_VERTICAL", shape5, paint19, stroke62, (java.awt.Paint) color73);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paintArray33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(paintArray40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNotNull(strokeArray43);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(strokeArray52);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(shapeArray54);
        org.junit.Assert.assertNotNull(obj56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(valueAxisArray59);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNotNull(stroke62);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(color73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection25 = categoryPlot24.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.RenderingSource renderingSource29 = null;
        categoryPlot24.select((double) (-1L), (double) 100, rectangle2D28, renderingSource29);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray31 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot24.setRenderers(categoryItemRendererArray31);
        defaultCategoryDataset22.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot24);
        try {
            defaultCategoryDataset22.removeValue((java.lang.Comparable) 0.05d, (java.lang.Comparable) "TextAnchor.TOP_RIGHT");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (0.05) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNull(legendItemCollection25);
        org.junit.Assert.assertNotNull(categoryItemRendererArray31);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType32 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType32);
        legendItem31.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        java.lang.String str35 = legendItem31.getToolTipText();
        java.awt.Paint paint36 = legendItem31.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font42 = categoryAxis41.getLabelFont();
        categoryAxis38.setTickLabelFont((java.lang.Comparable) 10.0d, font42);
        java.awt.Stroke stroke44 = categoryAxis38.getTickMarkStroke();
        java.awt.Font font45 = categoryAxis38.getLabelFont();
        legendItem31.setLabelFont(font45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font49 = categoryAxis48.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor50 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = null;
        double double55 = categoryAxis48.getCategoryJava2DCoordinate(categoryAnchor50, (int) (byte) 100, (int) (byte) 1, rectangle2D53, rectangleEdge54);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font58 = categoryAxis57.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets59 = categoryAxis57.getTickLabelInsets();
        java.awt.Color color60 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis57.setLabelPaint((java.awt.Paint) color60);
        categoryAxis48.setAxisLinePaint((java.awt.Paint) color60);
        legendItem31.setLinePaint((java.awt.Paint) color60);
        java.text.AttributedString attributedString64 = legendItem31.getAttributedLabel();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(font58);
        org.junit.Assert.assertNotNull(rectangleInsets59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNull(attributedString64);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator5, false);
        java.lang.Boolean boolean9 = barRenderer0.getSeriesCreateEntities(4);
        boolean boolean10 = barRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        try {
            lineAndShapeRenderer2.setItemMargin((double) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot4.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot4.setRenderer(categoryItemRenderer9);
        org.jfree.chart.entity.PlotEntity plotEntity12 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) categoryPlot4, "");
        categoryPlot4.setBackgroundAlpha((float) 10L);
        keyedObjects0.setObject((java.lang.Comparable) 10.0f, (java.lang.Object) 10L);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType17 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer18 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType17);
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot20.setBackgroundPaint((java.awt.Paint) color23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot20.setRenderer(categoryItemRenderer25);
        org.jfree.chart.entity.PlotEntity plotEntity28 = new org.jfree.chart.entity.PlotEntity(shape19, (org.jfree.chart.plot.Plot) categoryPlot20, "");
        boolean boolean29 = categoryPlot20.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis31.setLabelInsets(rectangleInsets32, true);
        java.util.List list35 = categoryPlot20.getCategoriesForAxis(categoryAxis31);
        java.awt.Color color36 = java.awt.Color.ORANGE;
        categoryAxis31.setTickMarkPaint((java.awt.Paint) color36);
        boolean boolean38 = standardGradientPaintTransformer18.equals((java.lang.Object) categoryAxis31);
        keyedObjects0.setObject((java.lang.Comparable) 0.0d, (java.lang.Object) standardGradientPaintTransformer18);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) (-1L));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (-1) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(gradientPaintTransformType17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        categoryPlot0.select((double) (-1L), (double) 100, rectangle2D4, renderingSource5);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray7);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier11, true);
        boolean boolean14 = categoryPlot0.isRangePannable();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState19 = null;
        boolean boolean20 = categoryPlot0.render(graphics2D15, rectangle2D16, (int) (short) 100, plotRenderingInfo18, categoryCrosshairState19);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        categoryPlot0.setRangeAxis((int) (short) 100, valueAxis22, false);
        boolean boolean25 = categoryPlot0.isNotify();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        try {
            defaultCategoryDataset0.removeColumn(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.AxisSpace axisSpace6 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace6, true);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        java.awt.Stroke stroke12 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("PlotEntity: tooltip = ");
        categoryPlot0.setDomainAxis(categoryAxis14);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot20.setBackgroundPaint((java.awt.Paint) color23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot20.setRenderer(categoryItemRenderer25);
        boolean boolean27 = categoryPlot20.isDomainPannable();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        categoryPlot29.addChangeListener(plotChangeListener30);
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot29.getDomainAxisLocation();
        categoryPlot20.setDomainAxisLocation(1, axisLocation32, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation32, plotOrientation35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation19, plotOrientation35);
        try {
            double double38 = categoryAxis14.getCategoryMiddle((int) (byte) 1, (int) (byte) 100, rectangle2D18, rectangleEdge37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(plotOrientation35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getLegendItems();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot16.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot16.setRenderer(categoryItemRenderer21);
        org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity(shape15, (org.jfree.chart.plot.Plot) categoryPlot16, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot25.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font35 = categoryAxis34.getLabelFont();
        categoryAxis31.setTickLabelFont((java.lang.Comparable) 10.0d, font35);
        java.awt.Stroke stroke37 = categoryAxis31.getTickMarkStroke();
        categoryPlot25.setRangeGridlineStroke(stroke37);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color41 = java.awt.Color.getColor("", color40);
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape15, stroke37, (java.awt.Paint) color41);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font48 = categoryAxis47.getLabelFont();
        categoryAxis44.setTickLabelFont((java.lang.Comparable) 10.0d, font48);
        legendItem42.setLabelFont(font48);
        legendItem42.setShapeVisible(false);
        legendItemCollection10.add(legendItem42);
        org.jfree.chart.LegendItemCollection legendItemCollection54 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection10.addAll(legendItemCollection54);
        java.lang.Object obj56 = null;
        boolean boolean57 = legendItemCollection10.equals(obj56);
        java.util.Iterator iterator58 = legendItemCollection10.iterator();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(iterator58);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(categoryItemRenderer5);
        boolean boolean7 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        categoryPlot0.select((double) (-1L), (double) 100, rectangle2D4, renderingSource5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = barRenderer8.getItemLabelGenerator(100, 100, false);
        int int13 = barRenderer8.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer8.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint16 = barRenderer8.lookupSeriesOutlinePaint(0);
        java.awt.Paint paint20 = barRenderer8.getItemFillPaint(0, (int) (short) 1, true);
        categoryPlot0.setRangeGridlinePaint(paint20);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor(8, (int) (byte) 1, (int) '#');
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        float[] floatArray12 = new float[] { 3, 2, (short) -1, (short) -1, 4, 8 };
        float[] floatArray13 = chartColor3.getColorComponents(colorSpace5, floatArray12);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets((double) 10.0f, (double) 0L, (double) 100, (double) 10.0f);
        double double7 = rectangleInsets5.trimWidth(1.0d);
        boolean boolean8 = categoryAnchor0.equals((java.lang.Object) double7);
        java.lang.String str9 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-9.0d) + "'", double7 == (-9.0d));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "CategoryAnchor.START" + "'", str9.equals("CategoryAnchor.START"));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        int int2 = keyedObjects0.getItemCount();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator5, false);
        java.lang.Boolean boolean9 = barRenderer0.getSeriesCreateEntities(4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator10);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            lineAndShapeRenderer2.addAnnotation(categoryAnnotation7, layer8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        categoryPlot0.setRenderer(categoryItemRenderer5);
        boolean boolean7 = categoryPlot0.isDomainPannable();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot9.getDomainAxisLocation();
        categoryPlot0.setDomainAxisLocation(1, axisLocation12, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation12, plotOrientation15);
        java.lang.String str17 = plotOrientation15.toString();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PlotOrientation.VERTICAL" + "'", str17.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis1.setLabelInsets(rectangleInsets2, true);
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot10.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot10.setRenderer(categoryItemRenderer15);
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape9, (org.jfree.chart.plot.Plot) categoryPlot10, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener20 = null;
        categoryPlot19.addChangeListener(plotChangeListener20);
        java.awt.Color color22 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot19.setBackgroundPaint((java.awt.Paint) color22);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font29 = categoryAxis28.getLabelFont();
        categoryAxis25.setTickLabelFont((java.lang.Comparable) 10.0d, font29);
        java.awt.Stroke stroke31 = categoryAxis25.getTickMarkStroke();
        categoryPlot19.setRangeGridlineStroke(stroke31);
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color35 = java.awt.Color.getColor("", color34);
        org.jfree.chart.LegendItem legendItem36 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape9, stroke31, (java.awt.Paint) color35);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font42 = categoryAxis41.getLabelFont();
        categoryAxis38.setTickLabelFont((java.lang.Comparable) 10.0d, font42);
        legendItem36.setLabelFont(font42);
        categoryAxis1.setTickLabelFont(font42);
        boolean boolean46 = categoryAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        defaultCategoryDataset22.clearSelection();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        categoryPlot26.addChangeListener(plotChangeListener27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot26.setBackgroundPaint((java.awt.Paint) color29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot26.setRenderer(categoryItemRenderer31);
        org.jfree.chart.entity.PlotEntity plotEntity34 = new org.jfree.chart.entity.PlotEntity(shape25, (org.jfree.chart.plot.Plot) categoryPlot26, "");
        categoryPlot26.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font42 = categoryAxis41.getLabelFont();
        categoryAxis38.setTickLabelFont((java.lang.Comparable) 10.0d, font42);
        java.awt.Stroke stroke44 = categoryAxis38.getTickMarkStroke();
        categoryPlot26.setDomainGridlineStroke(stroke44);
        java.lang.Comparable comparable46 = categoryPlot26.getDomainCrosshairColumnKey();
        boolean boolean47 = categoryPlot26.canSelectByPoint();
        boolean boolean48 = defaultCategoryDataset22.hasListener((java.util.EventListener) categoryPlot26);
        try {
            defaultCategoryDataset22.removeColumn(128);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 128, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(comparable46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font15 = categoryAxis14.getLabelFont();
        categoryAxis11.setTickLabelFont((java.lang.Comparable) 10.0d, font15);
        java.awt.Stroke stroke17 = categoryAxis11.getTickMarkStroke();
        categoryPlot5.setRangeGridlineStroke(stroke17);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent19 = null;
        categoryPlot5.notifyListeners(plotChangeEvent19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot5.getRangeAxisEdge(3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        int int24 = categoryPlot5.getIndexOf(categoryItemRenderer23);
        java.awt.Paint paint25 = categoryPlot5.getDomainCrosshairPaint();
        categoryPlot0.setOutlinePaint(paint25);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font4 = categoryAxis3.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis3.getTickLabelInsets();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis3.setLabelPaint((java.awt.Paint) color6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis3, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot10.panDomainAxes((double) 100, plotRenderingInfo12, point2D13);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        java.awt.Stroke stroke9 = barRenderer0.getItemOutlineStroke((-16727872), 10, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = null;
        barRenderer13.setBaseItemLabelGenerator(categoryItemLabelGenerator14, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = new org.jfree.chart.labels.ItemLabelPosition();
        java.awt.Color color18 = java.awt.Color.WHITE;
        java.awt.Color color19 = color18.darker();
        boolean boolean20 = itemLabelPosition17.equals((java.lang.Object) color18);
        barRenderer13.setBasePositiveItemLabelPosition(itemLabelPosition17, false);
        java.lang.Object obj23 = null;
        boolean boolean24 = itemLabelPosition17.equals(obj23);
        barRenderer0.setSeriesNegativeItemLabelPosition((int) '#', itemLabelPosition17, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator28 = null;
        barRenderer0.setSeriesToolTipGenerator(0, categoryToolTipGenerator28);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 10.0f, (double) 0L, (double) 100, (double) 10.0f);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets4.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType5, (double) '#', (-1.0d), (double) 4, (double) 0.5f);
        org.junit.Assert.assertNotNull(unitType5);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.END" + "'", str1.equals("CategoryAnchor.END"));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot0.notifyListeners(plotChangeEvent14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryPlot0.getAxisOffset();
        boolean boolean17 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot0.setRenderer(3, categoryItemRenderer7);
        categoryPlot0.clearRangeMarkers((int) (short) 1);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Point2D point2D13 = null;
        org.jfree.chart.plot.PlotState plotState14 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        try {
            categoryPlot0.draw(graphics2D11, rectangle2D12, point2D13, plotState14, plotRenderingInfo15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot0.notifyListeners(plotChangeEvent14);
        java.awt.Paint paint16 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener18 = null;
        categoryPlot17.addChangeListener(plotChangeListener18);
        org.jfree.chart.axis.AxisLocation axisLocation20 = categoryPlot17.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup21 = categoryPlot17.getDatasetGroup();
        java.awt.Font font22 = categoryPlot17.getNoDataMessageFont();
        org.jfree.chart.axis.AxisLocation axisLocation24 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation24, plotOrientation25);
        categoryPlot17.setRangeAxisLocation((int) (short) 1, axisLocation24);
        categoryPlot0.setDomainAxisLocation(axisLocation24);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(axisLocation20);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis1.setLabelInsets(rectangleInsets4, true);
        double double8 = rectangleInsets4.calculateBottomOutset((double) (byte) 10);
        double double10 = rectangleInsets4.calculateRightInset((double) 0L);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D14 = rectangleInsets4.createOutsetRectangle(rectangle2D11, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent10 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent10);
        categoryPlot4.configureDomainAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        categoryPlot13.addChangeListener(plotChangeListener14);
        java.awt.Paint paint16 = categoryPlot13.getDomainGridlinePaint();
        categoryPlot4.setRangeZeroBaselinePaint(paint16);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8, true);
        categoryPlot0.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint8 = barRenderer0.lookupSeriesOutlinePaint(0);
        java.awt.Paint paint12 = barRenderer0.getItemFillPaint(0, (int) (short) 1, true);
        java.awt.Stroke stroke13 = barRenderer0.getBaseOutlineStroke();
        java.awt.Font font15 = barRenderer0.lookupLegendTextFont(8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(font15);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        java.awt.Shape shape0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font11 = categoryAxis10.getLabelFont();
        categoryAxis7.setTickLabelFont((java.lang.Comparable) 10.0d, font11);
        java.awt.Stroke stroke13 = categoryAxis7.getTickMarkStroke();
        categoryPlot1.setRangeGridlineStroke(stroke13);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent15 = null;
        categoryPlot1.notifyListeners(plotChangeEvent15);
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot1.getRangeAxisEdge(3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        int int20 = categoryPlot1.getIndexOf(categoryItemRenderer19);
        java.awt.Paint paint21 = categoryPlot1.getDomainCrosshairPaint();
        try {
            org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "CategoryAnchor.END", "TextAnchor.TOP_RIGHT");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setBaseSeriesVisibleInLegend(true, false);
        barRenderer1.setItemLabelAnchorOffset((double) 8);
        java.awt.Shape shape8 = barRenderer1.getSeriesShape((int) (byte) 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        boolean boolean10 = barRenderer1.removeAnnotation(categoryAnnotation9);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot12.addChangeListener(plotChangeListener13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot12.getFixedLegendItems();
        java.awt.Paint paint16 = categoryPlot12.getNoDataMessagePaint();
        barRenderer1.setSeriesFillPaint((int) (short) 100, paint16, true);
        boolean boolean19 = barRenderer1.getAutoPopulateSeriesStroke();
        boolean boolean20 = itemLabelAnchor0.equals((java.lang.Object) barRenderer1);
        boolean boolean21 = barRenderer1.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot25.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot25.setRenderer(categoryItemRenderer30);
        org.jfree.chart.entity.PlotEntity plotEntity33 = new org.jfree.chart.entity.PlotEntity(shape24, (org.jfree.chart.plot.Plot) categoryPlot25, "");
        java.lang.String str34 = plotEntity33.toString();
        boolean boolean35 = defaultCategoryDataset22.equals((java.lang.Object) plotEntity33);
        try {
            boolean boolean38 = defaultCategoryDataset22.isSelected((int) (short) 100, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PlotEntity: tooltip = " + "'", str34.equals("PlotEntity: tooltip = "));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot0.getFixedLegendItems();
        java.awt.Paint paint4 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        try {
            categoryPlot0.setRangeAxis((-16727872), valueAxis6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType32 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType32);
        legendItem31.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        java.lang.String str35 = legendItem31.getToolTipText();
        boolean boolean36 = legendItem31.isShapeFilled();
        java.awt.Shape shape37 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.JFreeChart jFreeChart38 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType39 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent40 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) shape37, jFreeChart38, chartChangeEventType39);
        legendItem31.setShape(shape37);
        org.jfree.data.general.Dataset dataset42 = legendItem31.getDataset();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(chartChangeEventType39);
        org.junit.Assert.assertNull(dataset42);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        lineAndShapeRenderer2.clearSeriesPaints(true);
        lineAndShapeRenderer2.setUseFillPaint(true);
        boolean boolean10 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        lineAndShapeRenderer2.setAutoPopulateSeriesShape(true);
        try {
            lineAndShapeRenderer2.setItemMargin((double) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke10 = categoryAxis1.getTickMarkStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot11.addChangeListener(plotChangeListener12);
        java.awt.Paint paint14 = categoryPlot11.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean17 = categoryPlot11.removeDomainMarker(marker15, layer16);
        org.jfree.chart.ChartColor chartColor21 = new org.jfree.chart.ChartColor(8, (int) (byte) 1, (int) '#');
        int int22 = chartColor21.getRed();
        categoryPlot11.setBackgroundPaint((java.awt.Paint) chartColor21);
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        categoryPlot29.addChangeListener(plotChangeListener30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot29.setBackgroundPaint((java.awt.Paint) color32);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        categoryPlot29.setRenderer(categoryItemRenderer34);
        org.jfree.chart.entity.PlotEntity plotEntity37 = new org.jfree.chart.entity.PlotEntity(shape28, (org.jfree.chart.plot.Plot) categoryPlot29, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener39 = null;
        categoryPlot38.addChangeListener(plotChangeListener39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot38.setBackgroundPaint((java.awt.Paint) color41);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font48 = categoryAxis47.getLabelFont();
        categoryAxis44.setTickLabelFont((java.lang.Comparable) 10.0d, font48);
        java.awt.Stroke stroke50 = categoryAxis44.getTickMarkStroke();
        categoryPlot38.setRangeGridlineStroke(stroke50);
        java.awt.Color color53 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color54 = java.awt.Color.getColor("", color53);
        org.jfree.chart.LegendItem legendItem55 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape28, stroke50, (java.awt.Paint) color54);
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font61 = categoryAxis60.getLabelFont();
        categoryAxis57.setTickLabelFont((java.lang.Comparable) 10.0d, font61);
        legendItem55.setLabelFont(font61);
        java.awt.Paint paint64 = legendItem55.getLinePaint();
        categoryPlot11.setOutlinePaint(paint64);
        categoryAxis1.setTickLabelPaint(paint64);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 8 + "'", int22 == 8);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertNotNull(font61);
        org.junit.Assert.assertNotNull(paint64);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj2 = standardCategorySeriesLabelGenerator1.clone();
        java.lang.Object obj3 = null;
        boolean boolean4 = standardCategorySeriesLabelGenerator1.equals(obj3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font7 = categoryAxis6.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryAxis6.getTickLabelInsets();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis6.setLabelPaint((java.awt.Paint) color9);
        boolean boolean11 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) color9);
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        categoryPlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot13.setBackgroundPaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot13.setRenderer(categoryItemRenderer18);
        org.jfree.chart.entity.PlotEntity plotEntity21 = new org.jfree.chart.entity.PlotEntity(shape12, (org.jfree.chart.plot.Plot) categoryPlot13, "");
        categoryPlot13.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font29 = categoryAxis28.getLabelFont();
        categoryAxis25.setTickLabelFont((java.lang.Comparable) 10.0d, font29);
        java.awt.Stroke stroke31 = categoryAxis25.getTickMarkStroke();
        categoryPlot13.setDomainGridlineStroke(stroke31);
        java.lang.Comparable comparable33 = categoryPlot13.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset34 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot13.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset34);
        defaultCategoryDataset34.clearSelection();
        int int37 = defaultCategoryDataset34.getColumnCount();
        try {
            java.lang.String str39 = standardCategorySeriesLabelGenerator1.generateLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset34, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(comparable33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setSeriesShapesFilled(2, (java.lang.Boolean) true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer2.getItemStroke(100, 0, true);
        lineAndShapeRenderer2.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator6 = new org.jfree.chart.util.DefaultShadowGenerator((int) (short) 0, color2, (float) 8, 10, 4.0d);
        float[] floatArray10 = new float[] { 2.0f, (byte) -1, (byte) 0 };
        try {
            float[] floatArray11 = color2.getRGBComponents(floatArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        java.lang.String str10 = plotEntity9.getURLText();
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        barRenderer11.setBaseItemLabelGenerator(categoryItemLabelGenerator12, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = null;
        barRenderer11.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator16, false);
        java.lang.Boolean boolean20 = barRenderer11.getSeriesCreateEntities(4);
        java.lang.Object obj21 = barRenderer11.clone();
        boolean boolean22 = plotEntity9.equals((java.lang.Object) barRenderer11);
        org.jfree.chart.plot.Plot plot23 = plotEntity9.getPlot();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(plot23);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        boolean boolean7 = barRenderer0.isItemLabelVisible((int) (byte) 10, 0, true);
        barRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean10 = barRenderer0.getBaseCreateEntities();
        boolean boolean14 = barRenderer0.isItemLabelVisible(2, (int) ' ', false);
        java.awt.Paint paint16 = barRenderer0.getSeriesOutlinePaint((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        lineAndShapeRenderer2.clearSeriesPaints(true);
        lineAndShapeRenderer2.setUseFillPaint(true);
        boolean boolean10 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        lineAndShapeRenderer2.setAutoPopulateSeriesShape(true);
        lineAndShapeRenderer2.setBaseShapesVisible(true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((-1.0d), (double) (-1L), (double) 1.0f, (double) 1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke10 = barRenderer0.getItemStroke(8, (int) (byte) 0, true);
        java.awt.Paint paint11 = barRenderer0.getShadowPaint();
        barRenderer0.removeAnnotations();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = barRenderer0.getLegendItemLabelGenerator();
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator13);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke2 = renderAttributes0.getSeriesStroke(8);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        categoryPlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot13.setBackgroundPaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot13.setRenderer(categoryItemRenderer18);
        org.jfree.chart.entity.PlotEntity plotEntity21 = new org.jfree.chart.entity.PlotEntity(shape12, (org.jfree.chart.plot.Plot) categoryPlot13, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        categoryPlot22.addChangeListener(plotChangeListener23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot22.setBackgroundPaint((java.awt.Paint) color25);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font32 = categoryAxis31.getLabelFont();
        categoryAxis28.setTickLabelFont((java.lang.Comparable) 10.0d, font32);
        java.awt.Stroke stroke34 = categoryAxis28.getTickMarkStroke();
        categoryPlot22.setRangeGridlineStroke(stroke34);
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color38 = java.awt.Color.getColor("", color37);
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape12, stroke34, (java.awt.Paint) color38);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType40 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer41 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType40);
        legendItem39.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer41);
        java.lang.String str43 = legendItem39.getToolTipText();
        boolean boolean44 = legendItem39.isShapeFilled();
        java.awt.Shape shape45 = legendItem39.getShape();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font48 = categoryAxis47.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor49 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = categoryAxis47.getCategoryJava2DCoordinate(categoryAnchor49, (int) (byte) 100, (int) (byte) 1, rectangle2D52, rectangleEdge53);
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font57 = categoryAxis56.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = categoryAxis56.getTickLabelInsets();
        java.awt.Color color59 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis56.setLabelPaint((java.awt.Paint) color59);
        categoryAxis47.setAxisLinePaint((java.awt.Paint) color59);
        org.jfree.chart.LegendItem legendItem62 = new org.jfree.chart.LegendItem("PlotEntity: tooltip = ", "AxisLocation.BOTTOM_OR_LEFT", "GradientPaintTransformType.CENTER_VERTICAL", "ItemLabelAnchor.OUTSIDE8", shape45, (java.awt.Paint) color59);
        java.awt.Paint paint63 = null;
        try {
            org.jfree.chart.LegendItem legendItem64 = new org.jfree.chart.LegendItem(attributedString0, "GradientPaintTransformType.CENTER_VERTICAL", "org.jfree.chart.event.ChartChangeEvent[source=java.awt.geom.Rectangle2D$Double[x=-4.0,y=-4.0,w=8.0,h=8.0]]", "ChartChangeEventType.DATASET_UPDATED", shape45, paint63);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(gradientPaintTransformType40);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "hi!" + "'", str43.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertNotNull(color59);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        defaultCategoryDataset22.clearSelection();
        int int25 = defaultCategoryDataset22.getColumnCount();
        defaultCategoryDataset22.setValue(100.0d, (java.lang.Comparable) (byte) 0, (java.lang.Comparable) "GradientPaintTransformType.CENTER_VERTICAL");
        org.jfree.data.general.DatasetGroup datasetGroup30 = null;
        try {
            defaultCategoryDataset22.setGroup(datasetGroup30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font6 = categoryAxis5.getLabelFont();
        boolean boolean7 = categoryAxis5.isMinorTickMarksVisible();
        boolean boolean8 = categoryAxis5.isAxisLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis5.getTickLabelInsets();
        categoryPlot0.setDomainAxis(categoryAxis5);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot12.addChangeListener(plotChangeListener13);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot12.getDomainAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        categoryPlot12.setRangeAxis(2, valueAxis17, true);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = new org.jfree.chart.LegendItemCollection();
        categoryPlot12.setFixedLegendItems(legendItemCollection20);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        categoryPlot23.addChangeListener(plotChangeListener24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot23.setBackgroundPaint((java.awt.Paint) color26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        categoryPlot23.setRenderer(categoryItemRenderer28);
        boolean boolean30 = categoryPlot23.isDomainPannable();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        categoryPlot32.addChangeListener(plotChangeListener33);
        org.jfree.chart.axis.AxisLocation axisLocation35 = categoryPlot32.getDomainAxisLocation();
        categoryPlot23.setDomainAxisLocation(1, axisLocation35, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation38 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation35, plotOrientation38);
        org.jfree.chart.axis.AxisSpace axisSpace40 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace41 = categoryAxis5.reserveSpace(graphics2D11, (org.jfree.chart.plot.Plot) categoryPlot12, rectangle2D22, rectangleEdge39, axisSpace40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertNotNull(plotOrientation38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setUseOutlinePaint(false);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 0, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.awt.Color color0 = java.awt.Color.black;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE4" + "'", str1.equals("ItemLabelAnchor.OUTSIDE4"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Font font2 = renderAttributes1.getDefaultLabelFont();
        java.awt.Color color6 = java.awt.Color.getHSBColor(0.0f, (float) (byte) 100, (float) 100);
        renderAttributes1.setDefaultLabelPaint((java.awt.Paint) color6);
        int int8 = color6.getGreen();
        org.junit.Assert.assertNull(font2);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 255 + "'", int8 == 255);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.jfree.chart.util.ObjectList objectList3 = new org.jfree.chart.util.ObjectList(100);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        objectList3.set((int) (short) 1, (java.lang.Object) categoryPlot5);
        boolean boolean11 = chartChangeEventType0.equals((java.lang.Object) categoryPlot5);
        categoryPlot5.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            categoryPlot5.addDomainMarker(categoryMarker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        categoryPlot4.clearAnnotations();
        java.awt.Font font10 = categoryPlot4.getNoDataMessageFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryPlot4.setBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_GREEN;
        boolean boolean15 = datasetRenderingOrder13.equals((java.lang.Object) color14);
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder13);
        categoryPlot4.clearDomainMarkers(3);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot0.setRangeAxis((int) (short) 100, valueAxis11, true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape15 = defaultDrawingSupplier14.getNextShape();
        java.awt.Shape shape16 = defaultDrawingSupplier14.getNextShape();
        java.awt.Stroke stroke17 = defaultDrawingSupplier14.getNextOutlineStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke17);
        org.jfree.chart.plot.Marker marker19 = null;
        try {
            boolean boolean20 = categoryPlot0.removeRangeMarker(marker19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        try {
            java.lang.Comparable comparable3 = defaultCategoryDataset0.getRowKey(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke10 = categoryAxis1.getTickMarkStroke();
        boolean boolean11 = categoryAxis1.isAxisLineVisible();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot0.notifyListeners(plotChangeEvent14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot0.zoomDomainAxes((double) (short) 1, plotRenderingInfo17, point2D18);
        categoryPlot0.clearRangeMarkers(0);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot0.getDataset();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryDataset22);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.awt.Color color0 = java.awt.Color.darkGray;
        java.lang.String str1 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=64,g=64,b=64]" + "'", str1.equals("java.awt.Color[r=64,g=64,b=64]"));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        categoryPlot4.clearAnnotations();
        java.awt.Font font10 = categoryPlot4.getNoDataMessageFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryPlot4.setBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_GREEN;
        boolean boolean15 = datasetRenderingOrder13.equals((java.lang.Object) color14);
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder13);
        int int17 = categoryPlot4.getDomainAxisCount();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent3 = null;
        categoryPlot1.axisChanged(axisChangeEvent3);
        abstractCategoryDataset0.removeChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot1);
        org.junit.Assert.assertNull(legendItemCollection2);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        java.awt.Color color4 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis1.setLabelPaint((java.awt.Paint) color4);
        float float6 = categoryAxis1.getMinorTickMarkOutsideLength();
        categoryAxis1.setMinorTickMarkInsideLength((float) (short) 1);
        categoryAxis1.setLabelAngle((double) (-1.0f));
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent28 = null;
        categoryPlot14.notifyListeners(plotChangeEvent28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot14.getRangeAxisEdge(3);
        try {
            java.util.List list32 = categoryAxis1.refreshTicks(graphics2D11, axisState12, rectangle2D13, rectangleEdge31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 2.0f + "'", float6 == 2.0f);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        barRenderer0.setSeriesOutlinePaint(0, paint7, true);
        barRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation12, layer13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setUseOutlinePaint(false);
        boolean boolean11 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 0, 4);
        java.awt.Color color13 = java.awt.Color.WHITE;
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color13.createContext(colorModel14, rectangle15, rectangle2D16, affineTransform17, renderingHints18);
        lineAndShapeRenderer2.setSeriesFillPaint(100, (java.awt.Paint) color13);
        java.lang.Boolean boolean22 = lineAndShapeRenderer2.getSeriesShapesFilled((int) (short) 100);
        java.awt.Shape shape24 = lineAndShapeRenderer2.getLegendShape((int) '#');
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintContext19);
        org.junit.Assert.assertNull(boolean22);
        org.junit.Assert.assertNull(shape24);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot0.setRangeAxis((int) (short) 100, valueAxis11, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot0.getAxisOffset();
        int int15 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 101 + "'", int15 == 101);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke4 = renderAttributes1.getItemStroke((int) (short) 10, 128);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        renderAttributes1.setDefaultLabelFont(font10);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ItemLabelAnchor.OUTSIDE8");
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        boolean boolean25 = categoryAxis23.isMinorTickMarksVisible();
        boolean boolean26 = categoryAxis23.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray27 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis23 };
        categoryPlot1.setDomainAxes(categoryAxisArray27);
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        categoryPlot30.addChangeListener(plotChangeListener31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot30.setBackgroundPaint((java.awt.Paint) color33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        categoryPlot30.setRenderer(categoryItemRenderer35);
        org.jfree.chart.entity.PlotEntity plotEntity38 = new org.jfree.chart.entity.PlotEntity(shape29, (org.jfree.chart.plot.Plot) categoryPlot30, "");
        categoryPlot30.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font46 = categoryAxis45.getLabelFont();
        categoryAxis42.setTickLabelFont((java.lang.Comparable) 10.0d, font46);
        java.awt.Stroke stroke48 = categoryAxis42.getTickMarkStroke();
        categoryPlot30.setDomainGridlineStroke(stroke48);
        java.lang.Comparable comparable50 = categoryPlot30.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font53 = categoryAxis52.getLabelFont();
        boolean boolean54 = categoryAxis52.isMinorTickMarksVisible();
        boolean boolean55 = categoryAxis52.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray56 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis52 };
        categoryPlot30.setDomainAxes(categoryAxisArray56);
        categoryPlot1.setDomainAxes(categoryAxisArray56);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder59 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color60 = org.jfree.chart.ChartColor.DARK_GREEN;
        boolean boolean61 = datasetRenderingOrder59.equals((java.lang.Object) color60);
        categoryPlot1.setDatasetRenderingOrder(datasetRenderingOrder59);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(comparable50);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray56);
        org.junit.Assert.assertNotNull(datasetRenderingOrder59);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        java.lang.String str10 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        categoryAxis1.setTickMarkInsideLength((float) (byte) 1);
        categoryAxis1.clearCategoryLabelToolTips();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.axis.AxisLocation axisLocation17 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation17, plotOrientation18);
        try {
            double double20 = categoryAxis1.getCategoryStart(10, (int) '4', rectangle2D16, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        java.lang.Object obj3 = null;
        keyedObjects0.setObject((java.lang.Comparable) (-1.0d), obj3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 10.0f, (double) 0L, (double) 100, (double) 10.0f);
        double double6 = rectangleInsets4.trimWidth(1.0d);
        double double8 = rectangleInsets4.trimWidth(0.0d);
        double double9 = rectangleInsets4.getTop();
        double double10 = rectangleInsets4.getTop();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-9.0d) + "'", double6 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-10.0d) + "'", double8 == (-10.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 10.0d + "'", double9 == 10.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 10.0d + "'", double10 == 10.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.awt.Color color1 = java.awt.Color.WHITE;
        java.awt.Color color2 = color1.darker();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator6 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color1, (float) 100L, 10, (double) 0L);
        int int7 = defaultShadowGenerator6.getShadowSize();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 35 + "'", int7 == 35);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer1.setBaseSeriesVisibleInLegend(true, false);
        barRenderer1.setItemLabelAnchorOffset((double) 8);
        java.awt.Shape shape8 = barRenderer1.getSeriesShape((int) (byte) 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        boolean boolean10 = barRenderer1.removeAnnotation(categoryAnnotation9);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot12.addChangeListener(plotChangeListener13);
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot12.getFixedLegendItems();
        java.awt.Paint paint16 = categoryPlot12.getNoDataMessagePaint();
        barRenderer1.setSeriesFillPaint((int) (short) 100, paint16, true);
        boolean boolean19 = barRenderer1.getAutoPopulateSeriesStroke();
        boolean boolean20 = itemLabelAnchor0.equals((java.lang.Object) barRenderer1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = null;
        barRenderer22.setBaseItemLabelGenerator(categoryItemLabelGenerator23, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition();
        java.awt.Color color27 = java.awt.Color.WHITE;
        java.awt.Color color28 = color27.darker();
        boolean boolean29 = itemLabelPosition26.equals((java.lang.Object) color27);
        barRenderer22.setBasePositiveItemLabelPosition(itemLabelPosition26, false);
        java.lang.Object obj32 = null;
        boolean boolean33 = itemLabelPosition26.equals(obj32);
        try {
            barRenderer1.setSeriesNegativeItemLabelPosition((-1), itemLabelPosition26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot0.setRangeAxis((int) (short) 100, valueAxis11, true);
        java.awt.Font font14 = categoryPlot0.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.axis.AxisSpace axisSpace8 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace8, true);
        boolean boolean11 = categoryPlot0.isDomainZoomable();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color8, color10 };
        java.awt.Color color12 = java.awt.Color.YELLOW;
        int int13 = color12.getBlue();
        java.awt.Color color14 = java.awt.Color.ORANGE;
        java.awt.Color color15 = java.awt.Color.WHITE;
        java.awt.Color color16 = color15.darker();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { color12, color14, color16, color17 };
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] { stroke19, stroke20 };
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font27 = categoryAxis26.getLabelFont();
        categoryAxis23.setTickLabelFont((java.lang.Comparable) 10.0d, font27);
        java.awt.Stroke stroke29 = categoryAxis23.getTickMarkStroke();
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] { stroke29 };
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray32 = new java.awt.Shape[] { shape31 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray11, paintArray18, strokeArray21, strokeArray30, shapeArray32);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier33);
        categoryPlot0.setBackgroundImageAlignment((int) (byte) 10);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot0.getDomainAxisEdge(101);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shapeArray32);
        org.junit.Assert.assertNotNull(rectangleEdge38);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        barRenderer0.setSeriesOutlinePaint(0, paint7, true);
        barRenderer0.setBaseItemLabelsVisible(true);
        barRenderer0.setSeriesVisibleInLegend(35, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = strokeList0.getStroke((int) (short) -1);
        java.lang.Object obj3 = strokeList0.clone();
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke10 = categoryAxis1.getTickMarkStroke();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot16.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot16.setRenderer(categoryItemRenderer21);
        org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity(shape15, (org.jfree.chart.plot.Plot) categoryPlot16, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot25.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font35 = categoryAxis34.getLabelFont();
        categoryAxis31.setTickLabelFont((java.lang.Comparable) 10.0d, font35);
        java.awt.Stroke stroke37 = categoryAxis31.getTickMarkStroke();
        categoryPlot25.setRangeGridlineStroke(stroke37);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color41 = java.awt.Color.getColor("", color40);
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape15, stroke37, (java.awt.Paint) color41);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font48 = categoryAxis47.getLabelFont();
        categoryAxis44.setTickLabelFont((java.lang.Comparable) 10.0d, font48);
        legendItem42.setLabelFont(font48);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font56 = categoryAxis55.getLabelFont();
        categoryAxis52.setTickLabelFont((java.lang.Comparable) 10.0d, font56);
        legendItem42.setLabelFont(font56);
        categoryAxis1.setLabelFont(font56);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(font56);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setBaseSeriesVisible(false, true);
        boolean boolean7 = barRenderer0.getBaseItemLabelsVisible();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        barRenderer0.setSeriesOutlinePaint(2, (java.awt.Paint) color9);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color9);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        legendItem31.setLabelFont(font37);
        java.awt.Paint paint40 = legendItem31.getLinePaint();
        legendItem31.setURLText("{0}");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer43 = legendItem31.getFillPaintTransformer();
        legendItem31.setToolTipText("AxisLocation.BOTTOM_OR_LEFT");
        java.awt.Color color46 = java.awt.Color.green;
        legendItem31.setOutlinePaint((java.awt.Paint) color46);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(gradientPaintTransformer43);
        org.junit.Assert.assertNotNull(color46);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        categoryPlot0.axisChanged(axisChangeEvent2);
        java.awt.Paint paint4 = categoryPlot0.getDomainCrosshairPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        java.lang.String str14 = categoryPlot0.getPlotType();
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        categoryPlot0.setRangeAxis(0, valueAxis16);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "Category Plot" + "'", str14.equals("Category Plot"));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        float[] floatArray2 = new float[] { 2.0f };
        try {
            float[] floatArray3 = color0.getRGBColorComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot25.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot25.setRenderer(categoryItemRenderer30);
        org.jfree.chart.entity.PlotEntity plotEntity33 = new org.jfree.chart.entity.PlotEntity(shape24, (org.jfree.chart.plot.Plot) categoryPlot25, "");
        java.lang.String str34 = plotEntity33.toString();
        boolean boolean35 = defaultCategoryDataset22.equals((java.lang.Object) plotEntity33);
        org.jfree.chart.plot.Plot plot36 = plotEntity33.getPlot();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PlotEntity: tooltip = " + "'", str34.equals("PlotEntity: tooltip = "));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(plot36);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        categoryPlot4.clearAnnotations();
        categoryPlot4.setDomainCrosshairVisible(false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        legendItem31.setLabelFont(font37);
        java.awt.Paint paint40 = legendItem31.getLinePaint();
        java.awt.Shape shape41 = legendItem31.getLine();
        java.awt.Stroke stroke42 = legendItem31.getLineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator47 = barRenderer43.getItemLabelGenerator(100, 100, false);
        int int48 = barRenderer43.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition49 = barRenderer43.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint51 = barRenderer43.lookupSeriesOutlinePaint(0);
        legendItem31.setOutlinePaint(paint51);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNull(categoryItemLabelGenerator47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNull(itemLabelPosition49);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        double double6 = barRenderer0.getItemMargin();
        java.awt.Shape shape8 = barRenderer0.lookupLegendShape(8);
        double double9 = barRenderer0.getBase();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        barRenderer1.setBaseItemLabelGenerator(categoryItemLabelGenerator2, true);
        java.awt.Paint paint5 = barRenderer1.getBaseItemLabelPaint();
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("java.awt.Color[r=64,g=64,b=64]", paint5);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        java.awt.Color color5 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        barRenderer0.setShadowPaint((java.awt.Paint) color5);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        defaultCategoryDataset22.clearSelection();
        try {
            boolean boolean27 = defaultCategoryDataset22.isSelected((int) ' ', 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        boolean boolean6 = categoryPlot0.isDomainGridlinesVisible();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setUseOutlinePaint(false);
        boolean boolean9 = lineAndShapeRenderer2.getBaseCreateEntities();
        java.awt.Paint paint13 = lineAndShapeRenderer2.getItemFillPaint((-1), (int) ' ', true);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        categoryPlot18.addChangeListener(plotChangeListener19);
        org.jfree.chart.LegendItemCollection legendItemCollection21 = categoryPlot18.getFixedLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        boolean boolean25 = categoryAxis23.isMinorTickMarksVisible();
        boolean boolean26 = categoryAxis23.isAxisLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryAxis23.getTickLabelInsets();
        categoryPlot18.setDomainAxis(categoryAxis23);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener32 = null;
        categoryPlot31.addChangeListener(plotChangeListener32);
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot31.setBackgroundPaint((java.awt.Paint) color34);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        categoryPlot31.setRenderer(categoryItemRenderer36);
        org.jfree.chart.entity.PlotEntity plotEntity39 = new org.jfree.chart.entity.PlotEntity(shape30, (org.jfree.chart.plot.Plot) categoryPlot31, "");
        categoryPlot31.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font47 = categoryAxis46.getLabelFont();
        categoryAxis43.setTickLabelFont((java.lang.Comparable) 10.0d, font47);
        java.awt.Stroke stroke49 = categoryAxis43.getTickMarkStroke();
        categoryPlot31.setDomainGridlineStroke(stroke49);
        java.lang.Comparable comparable51 = categoryPlot31.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset52 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot31.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset52);
        defaultCategoryDataset52.clearSelection();
        try {
            lineAndShapeRenderer2.drawItem(graphics2D14, categoryItemRendererState15, rectangle2D16, categoryPlot17, categoryAxis23, valueAxis29, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset52, (int) (byte) 10, (int) (short) 10, false, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(legendItemCollection21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(comparable51);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.panRangeAxes((double) (short) 1, plotRenderingInfo11, point2D12);
        float float14 = categoryPlot0.getBackgroundImageAlpha();
        java.awt.Paint paint15 = categoryPlot0.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = barRenderer0.getGradientPaintTransformer();
        barRenderer0.setShadowXOffset((double) 0.5f);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint8 = barRenderer0.lookupSeriesOutlinePaint(0);
        java.awt.Paint paint12 = barRenderer0.getItemFillPaint(0, (int) (short) 1, true);
        barRenderer0.setBaseItemLabelsVisible(false, false);
        boolean boolean19 = barRenderer0.getItemCreateEntity(3, 101, false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.panRangeAxes((double) (short) 1, plotRenderingInfo11, point2D12);
        float float14 = categoryPlot0.getBackgroundImageAlpha();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            categoryPlot0.drawOutline(graphics2D15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.5f + "'", float14 == 0.5f);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType32 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType32);
        legendItem31.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        java.lang.String str35 = legendItem31.getToolTipText();
        java.awt.Paint paint36 = legendItem31.getOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection38 = categoryPlot37.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        org.jfree.chart.RenderingSource renderingSource42 = null;
        categoryPlot37.select((double) (-1L), (double) 100, rectangle2D41, renderingSource42);
        boolean boolean44 = categoryPlot37.canSelectByRegion();
        java.awt.Stroke stroke45 = categoryPlot37.getOutlineStroke();
        org.jfree.chart.util.SortOrder sortOrder46 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot37.setColumnRenderingOrder(sortOrder46);
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        categoryPlot37.setBackgroundPaint((java.awt.Paint) color48);
        legendItem31.setOutlinePaint((java.awt.Paint) color48);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(legendItemCollection38);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(sortOrder46);
        org.junit.Assert.assertNotNull(color48);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = strokeList0.getStroke((int) (short) -1);
        java.lang.Object obj3 = strokeList0.clone();
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setSeriesToolTipGenerator(100, categoryToolTipGenerator8, true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot0.setRangeAxis((int) (short) 100, valueAxis11, true);
        org.jfree.chart.plot.Plot plot14 = categoryPlot0.getRootPlot();
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        try {
            plot14.drawOutline(graphics2D15, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(plot14);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        java.awt.Paint paint4 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator5, false);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        barRenderer0.setDefaultEntityRadius(2);
        java.awt.Stroke stroke6 = barRenderer0.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot7.setRangeGridlineStroke(stroke19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        categoryPlot7.notifyListeners(plotChangeEvent21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot7.getRangeAxisEdge(3);
        barRenderer0.setPlot(categoryPlot7);
        java.awt.Paint paint27 = null;
        barRenderer0.setSeriesItemLabelPaint((int) (short) 1, paint27, true);
        java.lang.Boolean boolean31 = barRenderer0.getSeriesVisible(2);
        barRenderer0.clearSeriesPaints(false);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNull(boolean31);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getLegendItems();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot16.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot16.setRenderer(categoryItemRenderer21);
        org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity(shape15, (org.jfree.chart.plot.Plot) categoryPlot16, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot25.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font35 = categoryAxis34.getLabelFont();
        categoryAxis31.setTickLabelFont((java.lang.Comparable) 10.0d, font35);
        java.awt.Stroke stroke37 = categoryAxis31.getTickMarkStroke();
        categoryPlot25.setRangeGridlineStroke(stroke37);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color41 = java.awt.Color.getColor("", color40);
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape15, stroke37, (java.awt.Paint) color41);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font48 = categoryAxis47.getLabelFont();
        categoryAxis44.setTickLabelFont((java.lang.Comparable) 10.0d, font48);
        legendItem42.setLabelFont(font48);
        legendItem42.setShapeVisible(false);
        legendItemCollection10.add(legendItem42);
        org.jfree.chart.LegendItemCollection legendItemCollection54 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection10.addAll(legendItemCollection54);
        try {
            org.jfree.chart.LegendItem legendItem57 = legendItemCollection54.get(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(font48);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity4 = new org.jfree.chart.entity.ChartEntity(shape2, "hi!");
        shapeList0.setShape(0, shape2);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis("hi!");
        boolean boolean8 = shapeList0.equals((java.lang.Object) categoryAxis7);
        java.awt.Shape shape14 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        categoryPlot15.addChangeListener(plotChangeListener16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot15.setBackgroundPaint((java.awt.Paint) color18);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        categoryPlot15.setRenderer(categoryItemRenderer20);
        org.jfree.chart.entity.PlotEntity plotEntity23 = new org.jfree.chart.entity.PlotEntity(shape14, (org.jfree.chart.plot.Plot) categoryPlot15, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot24.addChangeListener(plotChangeListener25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot24.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font34 = categoryAxis33.getLabelFont();
        categoryAxis30.setTickLabelFont((java.lang.Comparable) 10.0d, font34);
        java.awt.Stroke stroke36 = categoryAxis30.getTickMarkStroke();
        categoryPlot24.setRangeGridlineStroke(stroke36);
        java.awt.Color color39 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color40 = java.awt.Color.getColor("", color39);
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape14, stroke36, (java.awt.Paint) color40);
        try {
            shapeList0.setShape((-1), shape14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation7, plotOrientation8);
        categoryPlot0.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.Marker marker12 = null;
        org.jfree.chart.util.Layer layer13 = null;
        try {
            boolean boolean15 = categoryPlot0.removeRangeMarker(2, marker12, layer13, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Stroke stroke4 = renderAttributes1.getItemStroke((int) (short) 10, 128);
        renderAttributes1.setDefaultCreateEntity((java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = barRenderer0.getGradientPaintTransformer();
        java.awt.Shape shape6 = barRenderer0.lookupLegendShape((int) (short) 10);
        java.awt.Paint paint8 = barRenderer0.getSeriesOutlinePaint((-16727872));
        java.awt.Shape shape9 = barRenderer0.getBaseShape();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation10 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot0.notifyListeners(plotChangeEvent14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot0.getRangeAxisEdge(3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        int int19 = categoryPlot0.getIndexOf(categoryItemRenderer18);
        categoryPlot0.setAnchorValue(0.0d);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        java.lang.String str10 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        categoryAxis1.setTickMarkInsideLength((float) (byte) 1);
        categoryAxis1.clearCategoryLabelToolTips();
        java.awt.Font font15 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 1);
        float float16 = categoryAxis1.getMinorTickMarkOutsideLength();
        categoryAxis1.setLowerMargin((double) 8);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 2.0f + "'", float16 == 2.0f);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        boolean boolean7 = barRenderer0.isItemLabelVisible((int) (byte) 10, 0, true);
        barRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        boolean boolean10 = barRenderer0.getBaseCreateEntities();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font16 = categoryAxis15.getLabelFont();
        categoryAxis12.setTickLabelFont((java.lang.Comparable) 10.0d, font16);
        java.awt.Stroke stroke18 = categoryAxis12.getTickMarkStroke();
        java.awt.Font font19 = categoryAxis12.getLabelFont();
        java.awt.Stroke stroke20 = categoryAxis12.getTickMarkStroke();
        java.awt.Font font21 = categoryAxis12.getTickLabelFont();
        barRenderer0.setBaseLegendTextFont(font21);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(font21);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker8 = null;
        org.jfree.chart.util.Layer layer9 = null;
        boolean boolean10 = categoryPlot4.removeDomainMarker(marker8, layer9);
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot4.getDataset(100);
        boolean boolean13 = categoryPlot4.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot4.getLegendItems();
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot20.setBackgroundPaint((java.awt.Paint) color23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot20.setRenderer(categoryItemRenderer25);
        org.jfree.chart.entity.PlotEntity plotEntity28 = new org.jfree.chart.entity.PlotEntity(shape19, (org.jfree.chart.plot.Plot) categoryPlot20, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        categoryPlot29.addChangeListener(plotChangeListener30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot29.setBackgroundPaint((java.awt.Paint) color32);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font39 = categoryAxis38.getLabelFont();
        categoryAxis35.setTickLabelFont((java.lang.Comparable) 10.0d, font39);
        java.awt.Stroke stroke41 = categoryAxis35.getTickMarkStroke();
        categoryPlot29.setRangeGridlineStroke(stroke41);
        java.awt.Color color44 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color45 = java.awt.Color.getColor("", color44);
        org.jfree.chart.LegendItem legendItem46 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape19, stroke41, (java.awt.Paint) color45);
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font52 = categoryAxis51.getLabelFont();
        categoryAxis48.setTickLabelFont((java.lang.Comparable) 10.0d, font52);
        legendItem46.setLabelFont(font52);
        legendItem46.setShapeVisible(false);
        legendItemCollection14.add(legendItem46);
        org.jfree.chart.LegendItemCollection legendItemCollection58 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection14.addAll(legendItemCollection58);
        java.lang.Object obj60 = null;
        boolean boolean61 = legendItemCollection14.equals(obj60);
        categoryPlot0.setFixedLegendItems(legendItemCollection14);
        java.lang.Object obj63 = legendItemCollection14.clone();
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(obj63);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = barRenderer0.getPlot();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator3 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator3, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryPlot2);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor2, 0, (int) ' ', rectangle2D5, rectangleEdge6);
        categoryAxis1.setCategoryMargin((double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis1.setTickLabelInsets(rectangleInsets10);
        double double13 = rectangleInsets10.calculateBottomInset(0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color8, color10 };
        java.awt.Color color12 = java.awt.Color.YELLOW;
        int int13 = color12.getBlue();
        java.awt.Color color14 = java.awt.Color.ORANGE;
        java.awt.Color color15 = java.awt.Color.WHITE;
        java.awt.Color color16 = color15.darker();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { color12, color14, color16, color17 };
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] { stroke19, stroke20 };
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font27 = categoryAxis26.getLabelFont();
        categoryAxis23.setTickLabelFont((java.lang.Comparable) 10.0d, font27);
        java.awt.Stroke stroke29 = categoryAxis23.getTickMarkStroke();
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] { stroke29 };
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray32 = new java.awt.Shape[] { shape31 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray11, paintArray18, strokeArray21, strokeArray30, shapeArray32);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier33);
        categoryPlot0.setBackgroundImageAlignment((int) (byte) 10);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        categoryPlot0.setRangeAxis(valueAxis37);
        categoryPlot0.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shapeArray32);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape7 = defaultDrawingSupplier6.getNextShape();
        barRenderer0.setBaseShape(shape7, true);
        boolean boolean10 = barRenderer0.isDrawBarOutline();
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape3 = renderAttributes0.getItemShape(8, 8);
        java.awt.Stroke stroke5 = renderAttributes0.getSeriesStroke(100);
        java.awt.Color color7 = java.awt.Color.green;
        renderAttributes0.setSeriesOutlinePaint(4, (java.awt.Paint) color7);
        int int9 = color7.getAlpha();
        org.junit.Assert.assertNull(shape3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        java.lang.String str10 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        java.awt.Font font12 = categoryAxis1.getTickLabelFont((java.lang.Comparable) 1);
        java.awt.Color color13 = java.awt.Color.gray;
        categoryAxis1.setAxisLinePaint((java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        boolean boolean10 = categoryPlot1.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis12.setLabelInsets(rectangleInsets13, true);
        java.util.List list16 = categoryPlot1.getCategoriesForAxis(categoryAxis12);
        java.awt.Font font17 = categoryAxis12.getTickLabelFont();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setUseOutlinePaint(false);
        boolean boolean9 = lineAndShapeRenderer2.getBaseCreateEntities();
        double double10 = lineAndShapeRenderer2.getItemLabelAnchorOffset();
        java.awt.Shape shape13 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot14.setRenderer(categoryItemRenderer19);
        org.jfree.chart.entity.PlotEntity plotEntity22 = new org.jfree.chart.entity.PlotEntity(shape13, (org.jfree.chart.plot.Plot) categoryPlot14, "");
        categoryPlot14.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font30 = categoryAxis29.getLabelFont();
        categoryAxis26.setTickLabelFont((java.lang.Comparable) 10.0d, font30);
        java.awt.Stroke stroke32 = categoryAxis26.getTickMarkStroke();
        categoryPlot14.setDomainGridlineStroke(stroke32);
        java.lang.Comparable comparable34 = categoryPlot14.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset35 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot14.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset35);
        defaultCategoryDataset35.clearSelection();
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font40 = categoryAxis39.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor41 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = null;
        double double46 = categoryAxis39.getCategoryJava2DCoordinate(categoryAnchor41, (int) (byte) 100, (int) (byte) 1, rectangle2D44, rectangleEdge45);
        java.lang.String str48 = categoryAxis39.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        categoryAxis39.setTickMarkInsideLength((float) (byte) 1);
        java.lang.Object obj51 = null;
        boolean boolean52 = categoryAxis39.equals(obj51);
        categoryAxis39.setCategoryLabelPositionOffset((int) (short) 100);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener57 = null;
        categoryPlot56.addChangeListener(plotChangeListener57);
        java.awt.Color color59 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot56.setBackgroundPaint((java.awt.Paint) color59);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        categoryPlot56.setRenderer(categoryItemRenderer61);
        boolean boolean63 = categoryPlot56.isDomainPannable();
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener66 = null;
        categoryPlot65.addChangeListener(plotChangeListener66);
        org.jfree.chart.axis.AxisLocation axisLocation68 = categoryPlot65.getDomainAxisLocation();
        categoryPlot56.setDomainAxisLocation(1, axisLocation68, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation71 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge72 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation68, plotOrientation71);
        try {
            double double73 = lineAndShapeRenderer2.getItemMiddle((java.lang.Comparable) 1.0d, (java.lang.Comparable) (-1.0d), (org.jfree.data.category.CategoryDataset) defaultCategoryDataset35, categoryAxis39, rectangle2D55, rectangleEdge72);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.0d + "'", double10 == 2.0d);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(comparable34);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNull(str48);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(axisLocation68);
        org.junit.Assert.assertNotNull(plotOrientation71);
        org.junit.Assert.assertNotNull(rectangleEdge72);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape1 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        categoryPlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot2.setBackgroundPaint((java.awt.Paint) color5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot2.setRenderer(categoryItemRenderer7);
        org.jfree.chart.entity.PlotEntity plotEntity10 = new org.jfree.chart.entity.PlotEntity(shape1, (org.jfree.chart.plot.Plot) categoryPlot2, "");
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape1, "ChartChangeEventType.DATASET_UPDATED", "PlotEntity: tooltip = ");
        boolean boolean14 = shapeList0.equals((java.lang.Object) "PlotEntity: tooltip = ");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot4.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot4.setRenderer(categoryItemRenderer9);
        org.jfree.chart.entity.PlotEntity plotEntity12 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) categoryPlot4, "");
        categoryPlot4.setBackgroundAlpha((float) 10L);
        keyedObjects0.setObject((java.lang.Comparable) 10.0f, (java.lang.Object) 10L);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        try {
            keyedObjects0.insertValue(8, (java.lang.Comparable) 2, (java.lang.Object) color18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator5, false);
        java.lang.Boolean boolean9 = barRenderer0.getSeriesCreateEntities(4);
        java.lang.Object obj10 = barRenderer0.clone();
        java.awt.Paint paint11 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer0.getPositiveItemLabelPosition(0, 2, false);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj2 = standardCategorySeriesLabelGenerator1.clone();
        java.lang.Object obj3 = null;
        boolean boolean4 = standardCategorySeriesLabelGenerator1.equals(obj3);
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot6.addChangeListener(plotChangeListener7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot6.setBackgroundPaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        categoryPlot6.setRenderer(categoryItemRenderer11);
        org.jfree.chart.entity.PlotEntity plotEntity14 = new org.jfree.chart.entity.PlotEntity(shape5, (org.jfree.chart.plot.Plot) categoryPlot6, "");
        categoryPlot6.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font22 = categoryAxis21.getLabelFont();
        categoryAxis18.setTickLabelFont((java.lang.Comparable) 10.0d, font22);
        java.awt.Stroke stroke24 = categoryAxis18.getTickMarkStroke();
        categoryPlot6.setDomainGridlineStroke(stroke24);
        java.lang.Comparable comparable26 = categoryPlot6.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font29 = categoryAxis28.getLabelFont();
        boolean boolean30 = categoryAxis28.isMinorTickMarksVisible();
        boolean boolean31 = categoryAxis28.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray32 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis28 };
        categoryPlot6.setDomainAxes(categoryAxisArray32);
        boolean boolean34 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) categoryPlot6);
        categoryPlot6.setDomainCrosshairRowKey((java.lang.Comparable) (short) 0);
        float float37 = categoryPlot6.getBackgroundImageAlpha();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        categoryPlot6.zoomDomainAxes((double) 2, (double) 255, plotRenderingInfo40, point2D41);
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer43.setAutoPopulateSeriesShape(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer46 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator47 = null;
        barRenderer46.setBaseItemLabelGenerator(categoryItemLabelGenerator47, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition50 = new org.jfree.chart.labels.ItemLabelPosition();
        java.awt.Color color51 = java.awt.Color.WHITE;
        java.awt.Color color52 = color51.darker();
        boolean boolean53 = itemLabelPosition50.equals((java.lang.Object) color51);
        barRenderer46.setBasePositiveItemLabelPosition(itemLabelPosition50, false);
        barRenderer43.setBasePositiveItemLabelPosition(itemLabelPosition50, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer58 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean59 = barRenderer58.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = barRenderer58.getPlot();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator61 = null;
        barRenderer58.setBaseToolTipGenerator(categoryToolTipGenerator61, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer64 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Color color65 = java.awt.Color.CYAN;
        barRenderer64.setShadowPaint((java.awt.Paint) color65);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator67 = barRenderer64.getBaseURLGenerator();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer70 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer70.setSeriesLinesVisible((int) (short) 10, true);
        lineAndShapeRenderer70.setSeriesShapesFilled(3, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer77 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator78 = null;
        barRenderer77.setBaseItemLabelGenerator(categoryItemLabelGenerator78, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator82 = null;
        barRenderer77.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator82, false);
        java.lang.Boolean boolean86 = barRenderer77.getSeriesCreateEntities(4);
        boolean boolean87 = barRenderer77.getBaseSeriesVisibleInLegend();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray88 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { barRenderer43, barRenderer58, barRenderer64, lineAndShapeRenderer70, barRenderer77 };
        categoryPlot6.setRenderers(categoryItemRendererArray88);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(comparable26);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + float37 + "' != '" + 0.5f + "'", float37 == 0.5f);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNull(categoryPlot60);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNull(categoryURLGenerator67);
        org.junit.Assert.assertNull(boolean86);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + true + "'", boolean87 == true);
        org.junit.Assert.assertNotNull(categoryItemRendererArray88);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke2 = renderAttributes0.getSeriesStroke((int) (short) -1);
        java.awt.Color color3 = java.awt.Color.blue;
        renderAttributes0.setDefaultPaint((java.awt.Paint) color3);
        org.jfree.chart.ChartColor chartColor9 = new org.jfree.chart.ChartColor(8, (int) (byte) 1, (int) '#');
        int int10 = chartColor9.getRed();
        renderAttributes0.setSeriesFillPaint((int) (byte) 1, (java.awt.Paint) chartColor9);
        java.awt.Paint paint12 = null;
        try {
            renderAttributes0.setDefaultPaint(paint12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint8 = barRenderer0.lookupSeriesOutlinePaint(0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        barRenderer9.setBaseItemLabelGenerator(categoryItemLabelGenerator10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition();
        java.awt.Color color14 = java.awt.Color.WHITE;
        java.awt.Color color15 = color14.darker();
        boolean boolean16 = itemLabelPosition13.equals((java.lang.Object) color14);
        barRenderer9.setBasePositiveItemLabelPosition(itemLabelPosition13, false);
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = barRenderer0.getSeriesNegativeItemLabelPosition((int) (short) 1);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor2, 0, (int) ' ', rectangle2D5, rectangleEdge6);
        categoryAxis1.setCategoryMargin((double) (byte) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryAxis1.setTickLabelInsets(rectangleInsets10);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        categoryPlot18.addChangeListener(plotChangeListener19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot18.setBackgroundPaint((java.awt.Paint) color21);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        categoryPlot18.setRenderer(categoryItemRenderer23);
        boolean boolean25 = categoryPlot18.isDomainPannable();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener28 = null;
        categoryPlot27.addChangeListener(plotChangeListener28);
        org.jfree.chart.axis.AxisLocation axisLocation30 = categoryPlot27.getDomainAxisLocation();
        categoryPlot18.setDomainAxisLocation(1, axisLocation30, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation30, plotOrientation33);
        try {
            double double35 = categoryAxis1.getCategorySeriesMiddle((int) (byte) 10, (int) '4', (-16727872), (int) ' ', (-9.0d), rectangle2D17, rectangleEdge34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation30);
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        java.awt.Paint paint9 = categoryPlot4.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot4.getRangeAxisLocation();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot4.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("PlotEntity: tooltip = ");
        categoryAxis1.setMaximumCategoryLabelWidthRatio((float) 1L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        defaultCategoryDataset22.clearSelection();
        int int25 = defaultCategoryDataset22.getColumnCount();
        defaultCategoryDataset22.setValue(100.0d, (java.lang.Comparable) (byte) 0, (java.lang.Comparable) "GradientPaintTransformType.CENTER_VERTICAL");
        try {
            java.lang.Number number32 = defaultCategoryDataset22.getValue((java.lang.Comparable) (-1.0f), (java.lang.Comparable) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (-1.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis1.setLabelInsets(rectangleInsets4, true);
        java.lang.String str7 = rectangleInsets4.toString();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str7.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray10 = new org.jfree.chart.axis.ValueAxis[] { valueAxis9 };
        categoryPlot0.setRangeAxes(valueAxisArray10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation12 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertNotNull(valueAxisArray10);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setUseOutlinePaint(false);
        boolean boolean9 = lineAndShapeRenderer2.getBaseCreateEntities();
        java.awt.Paint paint13 = lineAndShapeRenderer2.getItemFillPaint((-1), (int) ' ', true);
        lineAndShapeRenderer2.setDrawOutlines(true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        lineAndShapeRenderer2.clearSeriesPaints(true);
        lineAndShapeRenderer2.setUseFillPaint(true);
        boolean boolean10 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        lineAndShapeRenderer2.setAutoPopulateSeriesShape(true);
        java.lang.Object obj13 = lineAndShapeRenderer2.clone();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = null;
        lineAndShapeRenderer2.setBaseItemLabelGenerator(categoryItemLabelGenerator14, true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = barRenderer18.getItemLabelGenerator(100, 100, false);
        barRenderer18.setBase((double) 0.5f);
        java.lang.Object obj25 = barRenderer18.clone();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation26 = null;
        boolean boolean27 = barRenderer18.removeAnnotation(categoryAnnotation26);
        java.awt.Shape shape28 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener30 = null;
        categoryPlot29.addChangeListener(plotChangeListener30);
        java.awt.Color color32 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot29.setBackgroundPaint((java.awt.Paint) color32);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = null;
        categoryPlot29.setRenderer(categoryItemRenderer34);
        org.jfree.chart.entity.PlotEntity plotEntity37 = new org.jfree.chart.entity.PlotEntity(shape28, (org.jfree.chart.plot.Plot) categoryPlot29, "");
        categoryPlot29.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font45 = categoryAxis44.getLabelFont();
        categoryAxis41.setTickLabelFont((java.lang.Comparable) 10.0d, font45);
        java.awt.Stroke stroke47 = categoryAxis41.getTickMarkStroke();
        categoryPlot29.setDomainGridlineStroke(stroke47);
        java.lang.Comparable comparable49 = categoryPlot29.getDomainCrosshairColumnKey();
        barRenderer18.setPlot(categoryPlot29);
        org.jfree.chart.renderer.category.BarRenderer barRenderer51 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer51.setBaseSeriesVisibleInLegend(true, false);
        barRenderer51.setItemLabelAnchorOffset((double) 8);
        java.awt.Stroke stroke60 = barRenderer51.getItemOutlineStroke((-16727872), 10, false);
        categoryPlot29.setRangeZeroBaselineStroke(stroke60);
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        try {
            lineAndShapeRenderer2.drawBackground(graphics2D17, categoryPlot29, rectangle2D62);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
        org.junit.Assert.assertNotNull(obj25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(font45);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNull(comparable49);
        org.junit.Assert.assertNotNull(stroke60);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        java.awt.Color color7 = java.awt.Color.YELLOW;
        categoryAxis1.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font11 = categoryAxis10.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis10.getTickLabelInsets();
        categoryAxis1.setLabelInsets(rectangleInsets12, false);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets12.createOutsetRectangle(rectangle2D15, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot8.setBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryAxis14.setTickLabelFont((java.lang.Comparable) 10.0d, font18);
        java.awt.Stroke stroke20 = categoryAxis14.getTickMarkStroke();
        categoryPlot8.setRangeGridlineStroke(stroke20);
        categoryPlot0.setRangeGridlineStroke(stroke20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        categoryPlot0.setRenderer((int) (byte) 1, categoryItemRenderer24);
        float float26 = categoryPlot0.getForegroundAlpha();
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        categoryPlot28.addChangeListener(plotChangeListener29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot28.setBackgroundPaint((java.awt.Paint) color31);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        categoryPlot28.setRenderer(categoryItemRenderer33);
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape27, (org.jfree.chart.plot.Plot) categoryPlot28, "");
        categoryPlot28.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font44 = categoryAxis43.getLabelFont();
        categoryAxis40.setTickLabelFont((java.lang.Comparable) 10.0d, font44);
        java.awt.Stroke stroke46 = categoryAxis40.getTickMarkStroke();
        categoryPlot28.setDomainGridlineStroke(stroke46);
        java.lang.Comparable comparable48 = categoryPlot28.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font51 = categoryAxis50.getLabelFont();
        boolean boolean52 = categoryAxis50.isMinorTickMarksVisible();
        boolean boolean53 = categoryAxis50.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray54 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis50 };
        categoryPlot28.setDomainAxes(categoryAxisArray54);
        categoryPlot0.setDomainAxes(categoryAxisArray54);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 1.0f + "'", float26 == 1.0f);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNull(comparable48);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray54);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis1.setLabelInsets(rectangleInsets4, true);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryAxis1.setTickMarkPaint((java.awt.Paint) color7);
        categoryAxis1.setCategoryMargin((double) (byte) 1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        java.lang.String str10 = plotEntity9.getURLText();
        java.awt.Shape shape11 = plotEntity9.getArea();
        java.lang.String str12 = plotEntity9.getURLText();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getLegendItems();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot16.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot16.setRenderer(categoryItemRenderer21);
        org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity(shape15, (org.jfree.chart.plot.Plot) categoryPlot16, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot25.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font35 = categoryAxis34.getLabelFont();
        categoryAxis31.setTickLabelFont((java.lang.Comparable) 10.0d, font35);
        java.awt.Stroke stroke37 = categoryAxis31.getTickMarkStroke();
        categoryPlot25.setRangeGridlineStroke(stroke37);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color41 = java.awt.Color.getColor("", color40);
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape15, stroke37, (java.awt.Paint) color41);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font48 = categoryAxis47.getLabelFont();
        categoryAxis44.setTickLabelFont((java.lang.Comparable) 10.0d, font48);
        legendItem42.setLabelFont(font48);
        legendItem42.setShapeVisible(false);
        legendItemCollection10.add(legendItem42);
        java.lang.Object obj54 = legendItemCollection10.clone();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(obj54);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke2 = renderAttributes0.getSeriesStroke((int) (short) -1);
        java.awt.Color color3 = java.awt.Color.blue;
        renderAttributes0.setDefaultPaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = renderAttributes0.getSeriesFillPaint(0);
        org.junit.Assert.assertNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setUseOutlinePaint(false);
        boolean boolean11 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 0, 4);
        java.awt.Color color13 = java.awt.Color.WHITE;
        java.awt.image.ColorModel colorModel14 = null;
        java.awt.Rectangle rectangle15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        java.awt.geom.AffineTransform affineTransform17 = null;
        java.awt.RenderingHints renderingHints18 = null;
        java.awt.PaintContext paintContext19 = color13.createContext(colorModel14, rectangle15, rectangle2D16, affineTransform17, renderingHints18);
        lineAndShapeRenderer2.setSeriesFillPaint(100, (java.awt.Paint) color13);
        java.awt.Paint paint21 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer2.setBasePaint(paint21);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(paintContext19);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        double double16 = categoryAxis10.getCategoryJava2DCoordinate(categoryAnchor11, 0, (int) ' ', rectangle2D14, rectangleEdge15);
        java.awt.Paint paint17 = categoryAxis10.getLabelPaint();
        java.awt.Paint paint18 = categoryAxis10.getAxisLinePaint();
        categoryPlot4.setDomainGridlinePaint(paint18);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = barRenderer0.getGradientPaintTransformer();
        java.awt.Paint paint6 = barRenderer0.getSeriesFillPaint((-16727872));
        barRenderer0.setDrawBarOutline(true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNull(paint6);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.chart.ChartColor chartColor10 = new org.jfree.chart.ChartColor(8, (int) (byte) 1, (int) '#');
        int int11 = chartColor10.getRed();
        categoryPlot0.setBackgroundPaint((java.awt.Paint) chartColor10);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace13);
        java.lang.Comparable comparable15 = categoryPlot0.getDomainCrosshairColumnKey();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 8 + "'", int11 == 8);
        org.junit.Assert.assertNull(comparable15);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        categoryPlot0.axisChanged(axisChangeEvent2);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot0.setRangeAxis(35, valueAxis5, false);
        org.junit.Assert.assertNull(legendItemCollection1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        boolean boolean7 = barRenderer0.isItemLabelVisible((int) (byte) 10, 0, true);
        java.awt.Shape shape9 = barRenderer0.getSeriesShape((int) (short) -1);
        boolean boolean10 = barRenderer0.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(shape9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        boolean boolean5 = rectangleInsets3.equals((java.lang.Object) itemLabelAnchor4);
        org.jfree.chart.util.UnitType unitType6 = rectangleInsets3.getUnitType();
        java.lang.String str7 = unitType6.toString();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(unitType6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "UnitType.ABSOLUTE" + "'", str7.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        legendItem31.setLabelFont(font37);
        java.awt.Paint paint40 = legendItem31.getLinePaint();
        java.awt.Shape shape41 = legendItem31.getLine();
        java.awt.Stroke stroke42 = legendItem31.getLineStroke();
        legendItem31.setSeriesKey((java.lang.Comparable) "");
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot4.setBackgroundPaint((java.awt.Paint) color7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray10 = new java.awt.Paint[] { color7, color9 };
        java.awt.Color color11 = java.awt.Color.YELLOW;
        int int12 = color11.getBlue();
        java.awt.Color color13 = java.awt.Color.ORANGE;
        java.awt.Color color14 = java.awt.Color.WHITE;
        java.awt.Color color15 = color14.darker();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color11, color13, color15, color16 };
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke18, stroke19 };
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font26 = categoryAxis25.getLabelFont();
        categoryAxis22.setTickLabelFont((java.lang.Comparable) 10.0d, font26);
        java.awt.Stroke stroke28 = categoryAxis22.getTickMarkStroke();
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] { stroke28 };
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray31 = new java.awt.Shape[] { shape30 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray17, strokeArray20, strokeArray29, shapeArray31);
        java.lang.Object obj33 = defaultDrawingSupplier32.clone();
        java.awt.Paint paint34 = defaultDrawingSupplier32.getNextOutlinePaint();
        barRenderer0.setBaseOutlinePaint(paint34, false);
        java.awt.Paint paint37 = barRenderer0.getBaseFillPaint();
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shapeArray31);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font6 = categoryAxis5.getLabelFont();
        boolean boolean7 = categoryAxis5.isMinorTickMarksVisible();
        boolean boolean8 = categoryAxis5.isAxisLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis5.getTickLabelInsets();
        categoryPlot0.setDomainAxis(categoryAxis5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = categoryPlot0.getRenderer((-1));
        org.junit.Assert.assertNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNull(categoryItemRenderer12);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        java.awt.Color color15 = java.awt.Color.WHITE;
        java.awt.Color color16 = color15.darker();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator20 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color15, (float) 100L, 10, (double) 0L);
        categoryPlot0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator20);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = null;
        try {
            boolean boolean25 = categoryPlot0.removeRangeMarker((int) ' ', marker23, layer24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent14 = null;
        categoryPlot0.notifyListeners(plotChangeEvent14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot0.getRangeAxisEdge(3);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent18 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType19 = plotChangeEvent18.getType();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(chartChangeEventType19);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        barRenderer0.setBase((double) 0.5f);
        barRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot10.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot10.setRenderer(categoryItemRenderer15);
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape9, (org.jfree.chart.plot.Plot) categoryPlot10, "");
        categoryPlot10.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font26 = categoryAxis25.getLabelFont();
        categoryAxis22.setTickLabelFont((java.lang.Comparable) 10.0d, font26);
        java.awt.Stroke stroke28 = categoryAxis22.getTickMarkStroke();
        categoryPlot10.setDomainGridlineStroke(stroke28);
        java.lang.Comparable comparable30 = categoryPlot10.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot10.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset31);
        org.jfree.data.Range range34 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset31, true);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font38 = categoryAxis37.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = categoryAxis37.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener41 = null;
        categoryPlot40.addChangeListener(plotChangeListener41);
        java.awt.Paint paint43 = categoryPlot40.getDomainGridlinePaint();
        categoryAxis37.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot40);
        categoryPlot40.clearAnnotations();
        java.awt.Font font46 = categoryPlot40.getNoDataMessageFont();
        barRenderer0.setSeriesItemLabelFont(1, font46);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(comparable30);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(font46);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType32 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType32);
        legendItem31.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        java.lang.String str35 = legendItem31.getToolTipText();
        boolean boolean36 = legendItem31.isShapeFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot37.addChangeListener(plotChangeListener38);
        java.awt.Paint paint40 = categoryPlot37.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = null;
        boolean boolean43 = categoryPlot37.removeDomainMarker(marker41, layer42);
        org.jfree.data.category.CategoryDataset categoryDataset45 = categoryPlot37.getDataset(100);
        boolean boolean46 = categoryPlot37.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        int int48 = categoryPlot37.getIndexOf(categoryItemRenderer47);
        org.jfree.chart.renderer.category.BarRenderer barRenderer49 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer49.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener54 = null;
        categoryPlot53.addChangeListener(plotChangeListener54);
        java.awt.Paint paint56 = categoryPlot53.getDomainGridlinePaint();
        barRenderer49.setSeriesOutlinePaint(0, paint56, true);
        barRenderer49.setBaseItemLabelsVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent61 = null;
        barRenderer49.notifyListeners(rendererChangeEvent61);
        categoryPlot37.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer49);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent64 = null;
        categoryPlot37.markerChanged(markerChangeEvent64);
        java.awt.Stroke stroke66 = categoryPlot37.getRangeZeroBaselineStroke();
        legendItem31.setOutlineStroke(stroke66);
        java.awt.Shape shape68 = legendItem31.getShape();
        java.lang.Object obj69 = legendItem31.clone();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(shape68);
        org.junit.Assert.assertNotNull(obj69);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener3 = null;
        categoryPlot2.addChangeListener(plotChangeListener3);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot2.setBackgroundPaint((java.awt.Paint) color5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        categoryPlot2.axisChanged(axisChangeEvent7);
        java.util.List list9 = categoryPlot2.getCategories();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace10, true);
        boolean boolean13 = datasetGroup1.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNull(list9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        categoryPlot3.addChangeListener(plotChangeListener4);
        java.awt.Paint paint6 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = categoryPlot3.removeDomainMarker(marker7, layer8);
        boolean boolean10 = categoryPlot3.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot11.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font21 = categoryAxis20.getLabelFont();
        categoryAxis17.setTickLabelFont((java.lang.Comparable) 10.0d, font21);
        java.awt.Stroke stroke23 = categoryAxis17.getTickMarkStroke();
        categoryPlot11.setRangeGridlineStroke(stroke23);
        categoryPlot3.setRangeGridlineStroke(stroke23);
        keyedObjects0.addObject((java.lang.Comparable) 0.05d, (java.lang.Object) categoryPlot3);
        java.lang.Object obj28 = null;
        keyedObjects0.addObject((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", obj28);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        categoryPlot30.addChangeListener(plotChangeListener31);
        java.awt.Paint paint33 = categoryPlot30.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker34 = null;
        org.jfree.chart.util.Layer layer35 = null;
        boolean boolean36 = categoryPlot30.removeDomainMarker(marker34, layer35);
        boolean boolean37 = categoryPlot30.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener39 = null;
        categoryPlot38.addChangeListener(plotChangeListener39);
        java.awt.Color color41 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot38.setBackgroundPaint((java.awt.Paint) color41);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font48 = categoryAxis47.getLabelFont();
        categoryAxis44.setTickLabelFont((java.lang.Comparable) 10.0d, font48);
        java.awt.Stroke stroke50 = categoryAxis44.getTickMarkStroke();
        categoryPlot38.setRangeGridlineStroke(stroke50);
        categoryPlot30.setRangeGridlineStroke(stroke50);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer54 = null;
        categoryPlot30.setRenderer((int) (byte) 1, categoryItemRenderer54);
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener57 = null;
        categoryPlot56.addChangeListener(plotChangeListener57);
        java.awt.Paint paint59 = categoryPlot56.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker60 = null;
        org.jfree.chart.util.Layer layer61 = null;
        boolean boolean62 = categoryPlot56.removeDomainMarker(marker60, layer61);
        org.jfree.data.category.CategoryDataset categoryDataset64 = categoryPlot56.getDataset(100);
        boolean boolean65 = categoryPlot56.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        java.awt.geom.Point2D point2D68 = null;
        categoryPlot56.panRangeAxes((double) (short) 1, plotRenderingInfo67, point2D68);
        float float70 = categoryPlot56.getBackgroundImageAlpha();
        categoryPlot56.clearSelection();
        org.jfree.chart.util.SortOrder sortOrder72 = categoryPlot56.getRowRenderingOrder();
        categoryPlot30.setColumnRenderingOrder(sortOrder72);
        try {
            keyedObjects0.sortByKeys(sortOrder72);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Double cannot be cast to java.lang.String");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(categoryDataset64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + float70 + "' != '" + 0.5f + "'", float70 == 0.5f);
        org.junit.Assert.assertNotNull(sortOrder72);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        java.awt.Font font7 = barRenderer0.getLegendTextFont(0);
        org.junit.Assert.assertNull(font7);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot0.getLegendItems();
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot16.setBackgroundPaint((java.awt.Paint) color19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        categoryPlot16.setRenderer(categoryItemRenderer21);
        org.jfree.chart.entity.PlotEntity plotEntity24 = new org.jfree.chart.entity.PlotEntity(shape15, (org.jfree.chart.plot.Plot) categoryPlot16, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot25.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font35 = categoryAxis34.getLabelFont();
        categoryAxis31.setTickLabelFont((java.lang.Comparable) 10.0d, font35);
        java.awt.Stroke stroke37 = categoryAxis31.getTickMarkStroke();
        categoryPlot25.setRangeGridlineStroke(stroke37);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color41 = java.awt.Color.getColor("", color40);
        org.jfree.chart.LegendItem legendItem42 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape15, stroke37, (java.awt.Paint) color41);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font48 = categoryAxis47.getLabelFont();
        categoryAxis44.setTickLabelFont((java.lang.Comparable) 10.0d, font48);
        legendItem42.setLabelFont(font48);
        legendItem42.setShapeVisible(false);
        legendItemCollection10.add(legendItem42);
        org.jfree.chart.LegendItemCollection legendItemCollection54 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection10.addAll(legendItemCollection54);
        org.jfree.chart.renderer.RenderAttributes renderAttributes57 = new org.jfree.chart.renderer.RenderAttributes(false);
        java.awt.Font font58 = renderAttributes57.getDefaultLabelFont();
        java.awt.Color color62 = java.awt.Color.getHSBColor(0.0f, (float) (byte) 100, (float) 100);
        renderAttributes57.setDefaultLabelPaint((java.awt.Paint) color62);
        java.awt.Stroke stroke64 = renderAttributes57.getDefaultOutlineStroke();
        boolean boolean65 = legendItemCollection54.equals((java.lang.Object) stroke64);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(legendItemCollection10);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(font48);
        org.junit.Assert.assertNull(font58);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertNull(stroke64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        float[] floatArray4 = new float[] { ' ' };
        try {
            float[] floatArray5 = java.awt.Color.RGBtoHSB(0, 8, 255, floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        boolean boolean3 = categoryAxis1.isMinorTickMarksVisible();
        boolean boolean4 = categoryAxis1.isAxisLineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        int int6 = categoryAxis1.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = categoryPlot7.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean13 = categoryPlot7.removeDomainMarker(marker11, layer12);
        org.jfree.data.category.CategoryDataset categoryDataset15 = categoryPlot7.getDataset(100);
        boolean boolean16 = categoryPlot7.isRangeCrosshairVisible();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor17 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot7.setDomainGridlinePosition(categoryAnchor17);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor17, 100, 3, rectangle2D21, rectangleEdge22);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(categoryDataset15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(categoryAnchor17);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer4.setAutoPopulateSeriesShape(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer7.setBaseItemLabelGenerator(categoryItemLabelGenerator8, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = new org.jfree.chart.labels.ItemLabelPosition();
        java.awt.Color color12 = java.awt.Color.WHITE;
        java.awt.Color color13 = color12.darker();
        boolean boolean14 = itemLabelPosition11.equals((java.lang.Object) color12);
        barRenderer7.setBasePositiveItemLabelPosition(itemLabelPosition11, false);
        barRenderer4.setBasePositiveItemLabelPosition(itemLabelPosition11, false);
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color21 = java.awt.Color.getColor("", color20);
        barRenderer4.setShadowPaint((java.awt.Paint) color20);
        java.awt.Shape shape23 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener25 = null;
        categoryPlot24.addChangeListener(plotChangeListener25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot24.setBackgroundPaint((java.awt.Paint) color27);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        categoryPlot24.setRenderer(categoryItemRenderer29);
        org.jfree.chart.entity.PlotEntity plotEntity32 = new org.jfree.chart.entity.PlotEntity(shape23, (org.jfree.chart.plot.Plot) categoryPlot24, "");
        barRenderer4.setBaseShape(shape23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator38 = barRenderer34.getItemLabelGenerator(100, 100, false);
        int int39 = barRenderer34.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = barRenderer34.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint42 = barRenderer34.lookupSeriesOutlinePaint(0);
        java.awt.Paint paint46 = barRenderer34.getItemFillPaint(0, (int) (short) 1, true);
        java.awt.Stroke stroke47 = barRenderer34.getBaseOutlineStroke();
        java.awt.Shape shape52 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener54 = null;
        categoryPlot53.addChangeListener(plotChangeListener54);
        java.awt.Color color56 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot53.setBackgroundPaint((java.awt.Paint) color56);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
        categoryPlot53.setRenderer(categoryItemRenderer58);
        org.jfree.chart.entity.PlotEntity plotEntity61 = new org.jfree.chart.entity.PlotEntity(shape52, (org.jfree.chart.plot.Plot) categoryPlot53, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener63 = null;
        categoryPlot62.addChangeListener(plotChangeListener63);
        java.awt.Color color65 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot62.setBackgroundPaint((java.awt.Paint) color65);
        org.jfree.chart.axis.CategoryAxis categoryAxis68 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis71 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font72 = categoryAxis71.getLabelFont();
        categoryAxis68.setTickLabelFont((java.lang.Comparable) 10.0d, font72);
        java.awt.Stroke stroke74 = categoryAxis68.getTickMarkStroke();
        categoryPlot62.setRangeGridlineStroke(stroke74);
        java.awt.Color color77 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color78 = java.awt.Color.getColor("", color77);
        org.jfree.chart.LegendItem legendItem79 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape52, stroke74, (java.awt.Paint) color78);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType80 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer81 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType80);
        legendItem79.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer81);
        java.lang.String str83 = legendItem79.getToolTipText();
        java.awt.Paint paint84 = legendItem79.getOutlinePaint();
        try {
            org.jfree.chart.LegendItem legendItem85 = new org.jfree.chart.LegendItem(attributedString0, "ItemLabelAnchor.OUTSIDE8", "PlotEntity: tooltip = ", "CategoryAnchor.START", shape23, stroke47, paint84);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNull(categoryItemLabelGenerator38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNull(itemLabelPosition40);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(color65);
        org.junit.Assert.assertNotNull(font72);
        org.junit.Assert.assertNotNull(stroke74);
        org.junit.Assert.assertNotNull(color77);
        org.junit.Assert.assertNotNull(color78);
        org.junit.Assert.assertNotNull(gradientPaintTransformType80);
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "hi!" + "'", str83.equals("hi!"));
        org.junit.Assert.assertNotNull(paint84);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = categoryPlot0.getBackgroundImage();
        java.lang.Comparable comparable2 = categoryPlot0.getDomainCrosshairRowKey();
        org.junit.Assert.assertNull(image1);
        org.junit.Assert.assertNull(comparable2);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        boolean boolean22 = categoryPlot1.canSelectByPoint();
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        categoryPlot1.setFixedDomainAxisSpace(axisSpace23);
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.RenderingSource renderingSource28 = null;
        categoryPlot1.select((double) 15, (double) 1L, rectangle2D27, renderingSource28);
        int int30 = categoryPlot1.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot8.setBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryAxis14.setTickLabelFont((java.lang.Comparable) 10.0d, font18);
        java.awt.Stroke stroke20 = categoryAxis14.getTickMarkStroke();
        categoryPlot8.setRangeGridlineStroke(stroke20);
        categoryPlot0.setRangeGridlineStroke(stroke20);
        boolean boolean23 = categoryPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        categoryPlot0.select((double) (-1L), (double) 100, rectangle2D4, renderingSource5);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray7 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray7);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier11 = null;
        categoryPlot0.setDrawingSupplier(drawingSupplier11, true);
        categoryPlot0.setBackgroundImageAlignment(15);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(categoryItemRendererArray7);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        java.lang.String str1 = chartChangeEventType0.toString();
        org.jfree.chart.util.ObjectList objectList3 = new org.jfree.chart.util.ObjectList(100);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        objectList3.set((int) (short) 1, (java.lang.Object) categoryPlot5);
        boolean boolean11 = chartChangeEventType0.equals((java.lang.Object) categoryPlot5);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot5.getLegendItems();
        java.util.Iterator iterator13 = legendItemCollection12.iterator();
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str1.equals("ChartChangeEventType.DATASET_UPDATED"));
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(legendItemCollection12);
        org.junit.Assert.assertNotNull(iterator13);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        java.awt.Paint paint9 = categoryPlot4.getRangeCrosshairPaint();
        categoryPlot4.clearDomainMarkers();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection2 = categoryPlot1.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot1.zoomRangeAxes((double) (short) 10, plotRenderingInfo4, point2D5, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = categoryPlot1.getFixedLegendItems();
        org.jfree.data.KeyedObject keyedObject9 = new org.jfree.data.KeyedObject((java.lang.Comparable) 10, (java.lang.Object) categoryPlot1);
        int int10 = categoryPlot1.getRangeAxisCount();
        org.junit.Assert.assertNull(legendItemCollection2);
        org.junit.Assert.assertNull(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        java.awt.Color color4 = java.awt.Color.green;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        barRenderer0.setSeriesToolTipGenerator(0, categoryToolTipGenerator7, true);
        double double10 = barRenderer0.getShadowYOffset();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font4 = categoryAxis3.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis3.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot6.addChangeListener(plotChangeListener7);
        java.awt.Paint paint9 = categoryPlot6.getDomainGridlinePaint();
        categoryAxis3.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot6);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot6.rendererChanged(rendererChangeEvent12);
        categoryPlot6.configureDomainAxes();
        boolean boolean15 = standardCategorySeriesLabelGenerator1.equals((java.lang.Object) categoryPlot6);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        lineAndShapeRenderer2.clearSeriesPaints(true);
        lineAndShapeRenderer2.setUseFillPaint(true);
        boolean boolean10 = lineAndShapeRenderer2.getAutoPopulateSeriesOutlineStroke();
        lineAndShapeRenderer2.setAutoPopulateSeriesShape(true);
        java.lang.Object obj13 = lineAndShapeRenderer2.clone();
        java.lang.Boolean boolean15 = lineAndShapeRenderer2.getSeriesCreateEntities(35);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(boolean15);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font3 = categoryAxis2.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis2.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis2.setLabelInsets(rectangleInsets5, true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryAxis2.setTickMarkPaint((java.awt.Paint) color8);
        java.awt.Color color10 = java.awt.Color.getColor("ChartChangeEventType.DATASET_UPDATED", color8);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        boolean boolean25 = categoryAxis23.isMinorTickMarksVisible();
        boolean boolean26 = categoryAxis23.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray27 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis23 };
        categoryPlot1.setDomainAxes(categoryAxisArray27);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent29 = null;
        categoryPlot1.rendererChanged(rendererChangeEvent29);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray27);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint8 = barRenderer0.lookupSeriesOutlinePaint(0);
        java.awt.Paint paint12 = barRenderer0.getItemFillPaint(0, (int) (short) 1, true);
        java.awt.Stroke stroke13 = barRenderer0.getBaseOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer15.setAutoPopulateSeriesShape(false);
        barRenderer15.setDefaultEntityRadius(2);
        java.awt.Stroke stroke21 = barRenderer15.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener23 = null;
        categoryPlot22.addChangeListener(plotChangeListener23);
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot22.setBackgroundPaint((java.awt.Paint) color25);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font32 = categoryAxis31.getLabelFont();
        categoryAxis28.setTickLabelFont((java.lang.Comparable) 10.0d, font32);
        java.awt.Stroke stroke34 = categoryAxis28.getTickMarkStroke();
        categoryPlot22.setRangeGridlineStroke(stroke34);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent36 = null;
        categoryPlot22.notifyListeners(plotChangeEvent36);
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot22.getRangeAxisEdge(3);
        barRenderer15.setPlot(categoryPlot22);
        boolean boolean42 = barRenderer15.isSeriesVisible((int) (short) 10);
        java.awt.Shape shape43 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer15.setBaseShape(shape43, false);
        barRenderer0.setLegendShape((int) (byte) 10, shape43);
        java.lang.Boolean boolean48 = barRenderer0.getSeriesVisible((int) '#');
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(shape43);
        org.junit.Assert.assertNull(boolean48);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font4 = categoryAxis3.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis3.getTickLabelInsets();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis3.setLabelPaint((java.awt.Paint) color6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis3, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot10.rendererChanged(rendererChangeEvent11);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        barRenderer0.setSeriesOutlinePaint(0, paint7, true);
        barRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer0.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator14);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font19 = categoryAxis18.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor20 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = categoryAxis18.getCategoryJava2DCoordinate(categoryAnchor20, (int) (byte) 100, (int) (byte) 1, rectangle2D23, rectangleEdge24);
        java.lang.String str27 = categoryAxis18.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        java.awt.Font font29 = categoryAxis18.getTickLabelFont((java.lang.Comparable) 1);
        try {
            barRenderer0.setLegendTextFont((-16727872), font29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNull(str27);
        org.junit.Assert.assertNotNull(font29);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 10, plotRenderingInfo3, point2D4, false);
        org.jfree.chart.util.SortOrder sortOrder7 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            categoryPlot0.drawOutline(graphics2D9, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(sortOrder7);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        categoryPlot0.setRangeCrosshairValue((double) 10);
        categoryPlot0.setAnchorValue((double) 0.0f);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        categoryPlot0.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        categoryPlot21.addChangeListener(plotChangeListener22);
        java.awt.Paint paint24 = categoryPlot21.getDomainGridlinePaint();
        categoryPlot21.clearSelection();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = categoryPlot21.getDatasetRenderingOrder();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot21);
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.RenderingSource renderingSource31 = null;
        categoryPlot21.select((-1.0d), 0.05d, rectangle2D30, renderingSource31);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType32 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType32);
        legendItem31.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        java.lang.String str35 = legendItem31.getToolTipText();
        java.awt.Paint paint36 = legendItem31.getOutlinePaint();
        java.awt.Paint paint37 = legendItem31.getFillPaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot0.getIndexOf(categoryItemRenderer10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot12.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.RenderingSource renderingSource17 = null;
        categoryPlot12.select((double) (-1L), (double) 100, rectangle2D16, renderingSource17);
        boolean boolean19 = categoryPlot12.canSelectByRegion();
        int int20 = categoryPlot12.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot12);
        boolean boolean22 = categoryPlot0.isNotify();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        java.awt.Color color4 = java.awt.Color.green;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color4);
        java.lang.Boolean boolean7 = barRenderer0.getSeriesItemLabelsVisible(4);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = barRenderer0.getGradientPaintTransformer();
        java.awt.Shape shape6 = barRenderer0.lookupLegendShape((int) (short) 10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = barRenderer0.getSeriesToolTipGenerator(1);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setTickMarkOutsideLength(0.0f);
        java.awt.Font font14 = categoryAxis11.getTickLabelFont();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            barRenderer0.drawAnnotations(graphics2D9, rectangle2D10, categoryAxis11, valueAxis15, layer16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        barRenderer0.setDefaultEntityRadius(2);
        java.awt.Stroke stroke6 = barRenderer0.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot8.setBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryAxis14.setTickLabelFont((java.lang.Comparable) 10.0d, font18);
        java.awt.Stroke stroke20 = categoryAxis14.getTickMarkStroke();
        categoryPlot8.setRangeGridlineStroke(stroke20);
        categoryPlot0.setRangeGridlineStroke(stroke20);
        java.awt.Stroke stroke23 = categoryPlot0.getDomainCrosshairStroke();
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = null;
        try {
            categoryPlot0.addRangeMarker(101, marker25, layer26, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        org.jfree.chart.plot.Plot plot10 = plotEntity9.getPlot();
        plotEntity9.setURLText("GradientPaintTransformType.CENTER_VERTICAL");
        java.lang.Object obj13 = plotEntity9.clone();
        java.lang.String str14 = plotEntity9.toString();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PlotEntity: tooltip = " + "'", str14.equals("PlotEntity: tooltip = "));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener10 = null;
        categoryPlot9.addChangeListener(plotChangeListener10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot9.setBackgroundPaint((java.awt.Paint) color12);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        categoryPlot9.setRenderer(categoryItemRenderer14);
        org.jfree.chart.entity.PlotEntity plotEntity17 = new org.jfree.chart.entity.PlotEntity(shape8, (org.jfree.chart.plot.Plot) categoryPlot9, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener19 = null;
        categoryPlot18.addChangeListener(plotChangeListener19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot18.setBackgroundPaint((java.awt.Paint) color21);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font28 = categoryAxis27.getLabelFont();
        categoryAxis24.setTickLabelFont((java.lang.Comparable) 10.0d, font28);
        java.awt.Stroke stroke30 = categoryAxis24.getTickMarkStroke();
        categoryPlot18.setRangeGridlineStroke(stroke30);
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color34 = java.awt.Color.getColor("", color33);
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape8, stroke30, (java.awt.Paint) color34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font41 = categoryAxis40.getLabelFont();
        categoryAxis37.setTickLabelFont((java.lang.Comparable) 10.0d, font41);
        legendItem35.setLabelFont(font41);
        java.awt.Paint paint44 = legendItem35.getLinePaint();
        java.awt.Shape shape45 = legendItem35.getLine();
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener47 = null;
        categoryPlot46.addChangeListener(plotChangeListener47);
        java.awt.Color color49 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot46.setBackgroundPaint((java.awt.Paint) color49);
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font56 = categoryAxis55.getLabelFont();
        categoryAxis52.setTickLabelFont((java.lang.Comparable) 10.0d, font56);
        java.awt.Stroke stroke58 = categoryAxis52.getTickMarkStroke();
        categoryPlot46.setRangeGridlineStroke(stroke58);
        categoryPlot46.setRangeCrosshairValue((double) 10);
        categoryPlot46.setAnchorValue((double) 0.0f);
        java.awt.Graphics2D graphics2D64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        categoryPlot46.drawBackgroundImage(graphics2D64, rectangle2D65);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer67 = categoryPlot46.getRenderer();
        java.awt.Stroke stroke68 = categoryPlot46.getDomainGridlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer69 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator70 = null;
        barRenderer69.setBaseItemLabelGenerator(categoryItemLabelGenerator70, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator74 = null;
        barRenderer69.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator74, false);
        java.lang.Boolean boolean78 = barRenderer69.getSeriesCreateEntities(4);
        java.lang.Object obj79 = barRenderer69.clone();
        java.awt.Paint paint80 = barRenderer69.getBaseItemLabelPaint();
        org.jfree.chart.LegendItem legendItem81 = new org.jfree.chart.LegendItem("java.awt.Color[r=64,g=64,b=64]", "Category Plot", "ItemLabelAnchor.OUTSIDE8", "", shape45, stroke68, paint80);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertNull(categoryItemRenderer67);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNull(boolean78);
        org.junit.Assert.assertNotNull(obj79);
        org.junit.Assert.assertNotNull(paint80);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        categoryPlot3.addChangeListener(plotChangeListener4);
        java.awt.Paint paint6 = categoryPlot3.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        boolean boolean9 = categoryPlot3.removeDomainMarker(marker7, layer8);
        boolean boolean10 = categoryPlot3.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot11.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font21 = categoryAxis20.getLabelFont();
        categoryAxis17.setTickLabelFont((java.lang.Comparable) 10.0d, font21);
        java.awt.Stroke stroke23 = categoryAxis17.getTickMarkStroke();
        categoryPlot11.setRangeGridlineStroke(stroke23);
        categoryPlot3.setRangeGridlineStroke(stroke23);
        keyedObjects0.addObject((java.lang.Comparable) 0.05d, (java.lang.Object) categoryPlot3);
        java.lang.Object obj28 = null;
        keyedObjects0.addObject((java.lang.Comparable) "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", obj28);
        try {
            java.lang.Comparable comparable31 = keyedObjects0.getKey(3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 2");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Paint paint4 = categoryPlot1.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        boolean boolean7 = categoryPlot1.removeDomainMarker(marker5, layer6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = categoryPlot1.getDataset(100);
        boolean boolean10 = categoryPlot1.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot1.getLegendItems();
        categoryPlot1.setRangeCrosshairValue((-9.0d));
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator15 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj16 = standardCategorySeriesLabelGenerator15.clone();
        java.lang.Object obj17 = null;
        boolean boolean18 = standardCategorySeriesLabelGenerator15.equals(obj17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font21 = categoryAxis20.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryAxis20.getTickLabelInsets();
        java.awt.Color color23 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis20.setLabelPaint((java.awt.Paint) color23);
        boolean boolean25 = standardCategorySeriesLabelGenerator15.equals((java.lang.Object) color23);
        categoryPlot1.setDomainGridlinePaint((java.awt.Paint) color23);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator30 = new org.jfree.chart.util.DefaultShadowGenerator(3, color23, (float) (short) 100, 1, 1.0d);
        int int31 = defaultShadowGenerator30.calculateOffsetX();
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(categoryDataset9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(legendItemCollection11);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-3) + "'", int31 == (-3));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape3 = renderAttributes0.getItemShape(8, 8);
        java.awt.Stroke stroke4 = renderAttributes0.getDefaultStroke();
        renderAttributes0.setDefaultCreateEntity((java.lang.Boolean) true);
        org.junit.Assert.assertNull(shape3);
        org.junit.Assert.assertNull(stroke4);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot8.setBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryAxis14.setTickLabelFont((java.lang.Comparable) 10.0d, font18);
        java.awt.Stroke stroke20 = categoryAxis14.getTickMarkStroke();
        categoryPlot8.setRangeGridlineStroke(stroke20);
        categoryPlot0.setRangeGridlineStroke(stroke20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        categoryPlot0.setRenderer((int) (byte) 1, categoryItemRenderer24);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        categoryPlot26.addChangeListener(plotChangeListener27);
        java.awt.Paint paint29 = categoryPlot26.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker30 = null;
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean32 = categoryPlot26.removeDomainMarker(marker30, layer31);
        org.jfree.data.category.CategoryDataset categoryDataset34 = categoryPlot26.getDataset(100);
        boolean boolean35 = categoryPlot26.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        categoryPlot26.panRangeAxes((double) (short) 1, plotRenderingInfo37, point2D38);
        float float40 = categoryPlot26.getBackgroundImageAlpha();
        categoryPlot26.clearSelection();
        org.jfree.chart.util.SortOrder sortOrder42 = categoryPlot26.getRowRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder42);
        int int44 = categoryPlot0.getCrosshairDatasetIndex();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(categoryDataset34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + float40 + "' != '" + 0.5f + "'", float40 == 0.5f);
        org.junit.Assert.assertNotNull(sortOrder42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        lineAndShapeRenderer2.clearSeriesPaints(true);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        lineAndShapeRenderer2.setBaseToolTipGenerator(categoryToolTipGenerator8);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        defaultCategoryDataset22.clearSelection();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        categoryPlot26.addChangeListener(plotChangeListener27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot26.setBackgroundPaint((java.awt.Paint) color29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot26.setRenderer(categoryItemRenderer31);
        org.jfree.chart.entity.PlotEntity plotEntity34 = new org.jfree.chart.entity.PlotEntity(shape25, (org.jfree.chart.plot.Plot) categoryPlot26, "");
        categoryPlot26.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font42 = categoryAxis41.getLabelFont();
        categoryAxis38.setTickLabelFont((java.lang.Comparable) 10.0d, font42);
        java.awt.Stroke stroke44 = categoryAxis38.getTickMarkStroke();
        categoryPlot26.setDomainGridlineStroke(stroke44);
        java.lang.Comparable comparable46 = categoryPlot26.getDomainCrosshairColumnKey();
        boolean boolean47 = categoryPlot26.canSelectByPoint();
        boolean boolean48 = defaultCategoryDataset22.hasListener((java.util.EventListener) categoryPlot26);
        java.awt.Paint paint49 = categoryPlot26.getRangeZeroBaselinePaint();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(comparable46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(paint49);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        boolean boolean10 = categoryPlot1.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis12.setLabelInsets(rectangleInsets13, true);
        java.util.List list16 = categoryPlot1.getCategoriesForAxis(categoryAxis12);
        java.awt.Color color17 = java.awt.Color.ORANGE;
        categoryAxis12.setTickMarkPaint((java.awt.Paint) color17);
        java.lang.String str20 = categoryAxis12.getCategoryLabelToolTip((java.lang.Comparable) 15);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        try {
            java.util.ResourceBundle resourceBundle1 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("UnitType.ABSOLUTE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name UnitType.ABSOLUTE, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Color color1 = java.awt.Color.CYAN;
        barRenderer0.setShadowPaint((java.awt.Paint) color1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = barRenderer0.getBaseURLGenerator();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font6 = categoryAxis5.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis5.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot8.addChangeListener(plotChangeListener9);
        java.awt.Paint paint11 = categoryPlot8.getDomainGridlinePaint();
        categoryAxis5.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        categoryPlot8.clearAnnotations();
        java.awt.Font font14 = categoryPlot8.getNoDataMessageFont();
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryPlot8.setBackgroundPaint((java.awt.Paint) color15);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_GREEN;
        boolean boolean19 = datasetRenderingOrder17.equals((java.lang.Object) color18);
        categoryPlot8.setDatasetRenderingOrder(datasetRenderingOrder17);
        barRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot8);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(categoryURLGenerator3);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot0.setRangeAxis((int) (short) 100, valueAxis11, true);
        boolean boolean14 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        categoryPlot4.clearAnnotations();
        java.awt.Font font10 = categoryPlot4.getNoDataMessageFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        categoryPlot4.setBackgroundPaint((java.awt.Paint) color11);
        categoryPlot4.setDomainCrosshairColumnKey((java.lang.Comparable) 3.0d, false);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.axis.AxisLocation axisLocation7 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation7, plotOrientation8);
        categoryPlot0.setRangeAxisLocation((int) (short) 1, axisLocation7);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot11.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font21 = categoryAxis20.getLabelFont();
        categoryAxis17.setTickLabelFont((java.lang.Comparable) 10.0d, font21);
        java.awt.Stroke stroke23 = categoryAxis17.getTickMarkStroke();
        categoryPlot11.setRangeGridlineStroke(stroke23);
        boolean boolean25 = axisLocation7.equals((java.lang.Object) categoryPlot11);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(font21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot0.getFixedLegendItems();
        java.awt.Paint paint4 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot6.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot6.zoomRangeAxes((double) (short) 10, plotRenderingInfo9, point2D10, false);
        org.jfree.chart.util.SortOrder sortOrder13 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot6.setRowRenderingOrder(sortOrder13);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        java.awt.Paint paint19 = categoryPlot16.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        boolean boolean22 = categoryPlot16.removeDomainMarker(marker20, layer21);
        org.jfree.data.category.CategoryDataset categoryDataset24 = categoryPlot16.getDataset(100);
        boolean boolean25 = categoryPlot16.isRangeCrosshairVisible();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot16.getLegendItems();
        categoryPlot16.setRangeCrosshairValue((-9.0d));
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator30 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("hi!");
        java.lang.Object obj31 = standardCategorySeriesLabelGenerator30.clone();
        java.lang.Object obj32 = null;
        boolean boolean33 = standardCategorySeriesLabelGenerator30.equals(obj32);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font36 = categoryAxis35.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = categoryAxis35.getTickLabelInsets();
        java.awt.Color color38 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis35.setLabelPaint((java.awt.Paint) color38);
        boolean boolean40 = standardCategorySeriesLabelGenerator30.equals((java.lang.Object) color38);
        categoryPlot16.setDomainGridlinePaint((java.awt.Paint) color38);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator45 = new org.jfree.chart.util.DefaultShadowGenerator(3, color38, (float) (short) 100, 1, 1.0d);
        boolean boolean46 = sortOrder13.equals((java.lang.Object) defaultShadowGenerator45);
        categoryPlot0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator45);
        org.junit.Assert.assertNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(sortOrder13);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(categoryDataset24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertNotNull(obj31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        double double6 = barRenderer0.getItemMargin();
        java.awt.Shape shape8 = barRenderer0.lookupLegendShape(8);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = barRenderer0.getPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font13 = categoryAxis12.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis12.getTickLabelInsets();
        java.awt.Color color15 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis12.setLabelPaint((java.awt.Paint) color15);
        java.awt.Shape shape22 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        categoryPlot23.addChangeListener(plotChangeListener24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot23.setBackgroundPaint((java.awt.Paint) color26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        categoryPlot23.setRenderer(categoryItemRenderer28);
        org.jfree.chart.entity.PlotEntity plotEntity31 = new org.jfree.chart.entity.PlotEntity(shape22, (org.jfree.chart.plot.Plot) categoryPlot23, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener33 = null;
        categoryPlot32.addChangeListener(plotChangeListener33);
        java.awt.Color color35 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot32.setBackgroundPaint((java.awt.Paint) color35);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font42 = categoryAxis41.getLabelFont();
        categoryAxis38.setTickLabelFont((java.lang.Comparable) 10.0d, font42);
        java.awt.Stroke stroke44 = categoryAxis38.getTickMarkStroke();
        categoryPlot32.setRangeGridlineStroke(stroke44);
        java.awt.Color color47 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color48 = java.awt.Color.getColor("", color47);
        org.jfree.chart.LegendItem legendItem49 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape22, stroke44, (java.awt.Paint) color48);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font55 = categoryAxis54.getLabelFont();
        categoryAxis51.setTickLabelFont((java.lang.Comparable) 10.0d, font55);
        legendItem49.setLabelFont(font55);
        categoryAxis12.setTickLabelFont((java.lang.Comparable) 10L, font55);
        try {
            barRenderer0.setSeriesItemLabelFont((-1), font55, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(font55);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        float float7 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setLabelAngle((double) (short) 100);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        categoryPlot14.setRenderer(categoryItemRenderer19);
        boolean boolean21 = categoryPlot14.isDomainPannable();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        categoryPlot23.addChangeListener(plotChangeListener24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot23.getDomainAxisLocation();
        categoryPlot14.setDomainAxisLocation(1, axisLocation26, true);
        org.jfree.chart.plot.PlotOrientation plotOrientation29 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation26, plotOrientation29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation13, plotOrientation29);
        org.jfree.chart.axis.AxisState axisState32 = null;
        categoryAxis1.drawTickMarks(graphics2D10, (double) 101, rectangle2D12, rectangleEdge31, axisState32);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(axisLocation13);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(plotOrientation29);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot4.setBackgroundPaint((java.awt.Paint) color7);
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray10 = new java.awt.Paint[] { color7, color9 };
        java.awt.Color color11 = java.awt.Color.YELLOW;
        int int12 = color11.getBlue();
        java.awt.Color color13 = java.awt.Color.ORANGE;
        java.awt.Color color14 = java.awt.Color.WHITE;
        java.awt.Color color15 = color14.darker();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color11, color13, color15, color16 };
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke18, stroke19 };
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font26 = categoryAxis25.getLabelFont();
        categoryAxis22.setTickLabelFont((java.lang.Comparable) 10.0d, font26);
        java.awt.Stroke stroke28 = categoryAxis22.getTickMarkStroke();
        java.awt.Stroke[] strokeArray29 = new java.awt.Stroke[] { stroke28 };
        java.awt.Shape shape30 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray31 = new java.awt.Shape[] { shape30 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray10, paintArray17, strokeArray20, strokeArray29, shapeArray31);
        java.lang.Object obj33 = defaultDrawingSupplier32.clone();
        java.awt.Paint paint34 = defaultDrawingSupplier32.getNextOutlinePaint();
        barRenderer0.setBaseOutlinePaint(paint34, false);
        java.awt.Font font38 = barRenderer0.lookupLegendTextFont(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener40 = null;
        categoryPlot39.addChangeListener(plotChangeListener40);
        java.awt.Paint paint42 = categoryPlot39.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker43 = null;
        org.jfree.chart.util.Layer layer44 = null;
        boolean boolean45 = categoryPlot39.removeDomainMarker(marker43, layer44);
        org.jfree.data.category.CategoryDataset categoryDataset47 = categoryPlot39.getDataset(100);
        boolean boolean48 = categoryPlot39.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        int int50 = categoryPlot39.getIndexOf(categoryItemRenderer49);
        org.jfree.chart.renderer.category.BarRenderer barRenderer51 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer51.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener56 = null;
        categoryPlot55.addChangeListener(plotChangeListener56);
        java.awt.Paint paint58 = categoryPlot55.getDomainGridlinePaint();
        barRenderer51.setSeriesOutlinePaint(0, paint58, true);
        barRenderer51.setBaseItemLabelsVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent63 = null;
        barRenderer51.notifyListeners(rendererChangeEvent63);
        categoryPlot39.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer51);
        org.jfree.chart.renderer.category.BarRenderer barRenderer66 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer66.setBaseSeriesVisibleInLegend(true, false);
        barRenderer66.setItemLabelAnchorOffset((double) 8);
        java.awt.Stroke stroke75 = barRenderer66.getItemOutlineStroke((-16727872), 10, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator76 = null;
        barRenderer66.setBaseURLGenerator(categoryURLGenerator76);
        org.jfree.chart.renderer.category.BarRenderer barRenderer79 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator80 = null;
        barRenderer79.setBaseItemLabelGenerator(categoryItemLabelGenerator80, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition83 = new org.jfree.chart.labels.ItemLabelPosition();
        java.awt.Color color84 = java.awt.Color.WHITE;
        java.awt.Color color85 = color84.darker();
        boolean boolean86 = itemLabelPosition83.equals((java.lang.Object) color84);
        barRenderer79.setBasePositiveItemLabelPosition(itemLabelPosition83, false);
        java.lang.Object obj89 = null;
        boolean boolean90 = itemLabelPosition83.equals(obj89);
        barRenderer66.setSeriesNegativeItemLabelPosition((int) '#', itemLabelPosition83, false);
        barRenderer51.setBaseNegativeItemLabelPosition(itemLabelPosition83);
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition83, true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(paintArray10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(strokeArray29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shapeArray31);
        org.junit.Assert.assertNotNull(obj33);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(font38);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(categoryDataset47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(color84);
        org.junit.Assert.assertNotNull(color85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.Marker marker10 = null;
        boolean boolean11 = categoryPlot0.removeDomainMarker(marker10);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        boolean boolean25 = categoryAxis23.isMinorTickMarksVisible();
        boolean boolean26 = categoryAxis23.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray27 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis23 };
        categoryPlot1.setDomainAxes(categoryAxisArray27);
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        categoryPlot30.addChangeListener(plotChangeListener31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot30.setBackgroundPaint((java.awt.Paint) color33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        categoryPlot30.setRenderer(categoryItemRenderer35);
        org.jfree.chart.entity.PlotEntity plotEntity38 = new org.jfree.chart.entity.PlotEntity(shape29, (org.jfree.chart.plot.Plot) categoryPlot30, "");
        categoryPlot30.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font46 = categoryAxis45.getLabelFont();
        categoryAxis42.setTickLabelFont((java.lang.Comparable) 10.0d, font46);
        java.awt.Stroke stroke48 = categoryAxis42.getTickMarkStroke();
        categoryPlot30.setDomainGridlineStroke(stroke48);
        java.lang.Comparable comparable50 = categoryPlot30.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font53 = categoryAxis52.getLabelFont();
        boolean boolean54 = categoryAxis52.isMinorTickMarksVisible();
        boolean boolean55 = categoryAxis52.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray56 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis52 };
        categoryPlot30.setDomainAxes(categoryAxisArray56);
        categoryPlot1.setDomainAxes(categoryAxisArray56);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 10.0f, (double) 0L, (double) 100, (double) 10.0f);
        categoryPlot1.setAxisOffset(rectangleInsets63);
        categoryPlot1.setDomainCrosshairRowKey((java.lang.Comparable) 0);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent67 = null;
        categoryPlot1.rendererChanged(rendererChangeEvent67);
        categoryPlot1.setCrosshairDatasetIndex((-1));
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(comparable50);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray56);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = null;
        java.awt.geom.Point2D point2D4 = null;
        categoryPlot0.zoomRangeAxes((double) (short) 10, plotRenderingInfo3, point2D4, false);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot8.setBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryAxis14.setTickLabelFont((java.lang.Comparable) 10.0d, font18);
        java.awt.Stroke stroke20 = categoryAxis14.getTickMarkStroke();
        categoryPlot8.setRangeGridlineStroke(stroke20);
        java.awt.Color color23 = java.awt.Color.WHITE;
        java.awt.Color color24 = color23.darker();
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator28 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color23, (float) 100L, 10, (double) 0L);
        categoryPlot8.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator28);
        categoryPlot0.setShadowGenerator((org.jfree.chart.util.ShadowGenerator) defaultShadowGenerator28);
        double double31 = defaultShadowGenerator28.getAngle();
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setSeriesURLGenerator((int) (byte) 1, categoryURLGenerator8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent2 = null;
        categoryPlot0.axisChanged(axisChangeEvent2);
        java.awt.Paint paint4 = categoryPlot0.getDomainCrosshairPaint();
        categoryPlot0.setBackgroundImageAlignment(35);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = barRenderer0.getGradientPaintTransformer();
        java.awt.Shape shape6 = barRenderer0.lookupLegendShape((int) (short) 10);
        java.awt.Color color8 = java.awt.Color.cyan;
        java.awt.Color color9 = java.awt.Color.getColor("{0}", color8);
        boolean boolean10 = barRenderer0.equals((java.lang.Object) color9);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        java.awt.Shape shape7 = barRenderer0.getSeriesShape((int) (byte) 1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemURLGenerator();
        barRenderer0.setShadowXOffset((double) (short) 1);
        org.junit.Assert.assertNull(shape7);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator8);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        boolean boolean25 = categoryAxis23.isMinorTickMarksVisible();
        boolean boolean26 = categoryAxis23.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray27 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis23 };
        categoryPlot1.setDomainAxes(categoryAxisArray27);
        java.awt.Shape shape29 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        categoryPlot30.addChangeListener(plotChangeListener31);
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot30.setBackgroundPaint((java.awt.Paint) color33);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = null;
        categoryPlot30.setRenderer(categoryItemRenderer35);
        org.jfree.chart.entity.PlotEntity plotEntity38 = new org.jfree.chart.entity.PlotEntity(shape29, (org.jfree.chart.plot.Plot) categoryPlot30, "");
        categoryPlot30.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font46 = categoryAxis45.getLabelFont();
        categoryAxis42.setTickLabelFont((java.lang.Comparable) 10.0d, font46);
        java.awt.Stroke stroke48 = categoryAxis42.getTickMarkStroke();
        categoryPlot30.setDomainGridlineStroke(stroke48);
        java.lang.Comparable comparable50 = categoryPlot30.getDomainCrosshairColumnKey();
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font53 = categoryAxis52.getLabelFont();
        boolean boolean54 = categoryAxis52.isMinorTickMarksVisible();
        boolean boolean55 = categoryAxis52.isAxisLineVisible();
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray56 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis52 };
        categoryPlot30.setDomainAxes(categoryAxisArray56);
        categoryPlot1.setDomainAxes(categoryAxisArray56);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = new org.jfree.chart.util.RectangleInsets((double) 10.0f, (double) 0L, (double) 100, (double) 10.0f);
        categoryPlot1.setAxisOffset(rectangleInsets63);
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType66 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType67 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D68 = rectangleInsets63.createAdjustedRectangle(rectangle2D65, lengthAdjustmentType66, lengthAdjustmentType67);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray27);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNull(comparable50);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(categoryAxisArray56);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType32 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer33 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType32);
        legendItem31.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer33);
        java.lang.String str35 = legendItem31.getToolTipText();
        boolean boolean36 = legendItem31.isShapeFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot37.addChangeListener(plotChangeListener38);
        java.awt.Paint paint40 = categoryPlot37.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = null;
        boolean boolean43 = categoryPlot37.removeDomainMarker(marker41, layer42);
        org.jfree.data.category.CategoryDataset categoryDataset45 = categoryPlot37.getDataset(100);
        boolean boolean46 = categoryPlot37.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        int int48 = categoryPlot37.getIndexOf(categoryItemRenderer47);
        org.jfree.chart.renderer.category.BarRenderer barRenderer49 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer49.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener54 = null;
        categoryPlot53.addChangeListener(plotChangeListener54);
        java.awt.Paint paint56 = categoryPlot53.getDomainGridlinePaint();
        barRenderer49.setSeriesOutlinePaint(0, paint56, true);
        barRenderer49.setBaseItemLabelsVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent61 = null;
        barRenderer49.notifyListeners(rendererChangeEvent61);
        categoryPlot37.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer49);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent64 = null;
        categoryPlot37.markerChanged(markerChangeEvent64);
        java.awt.Stroke stroke66 = categoryPlot37.getRangeZeroBaselineStroke();
        legendItem31.setOutlineStroke(stroke66);
        int int68 = legendItem31.getDatasetIndex();
        java.lang.Object obj69 = legendItem31.clone();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(gradientPaintTransformType32);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "hi!" + "'", str35.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(categoryDataset45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(obj69);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(100);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener4 = null;
        categoryPlot3.addChangeListener(plotChangeListener4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot3.setBackgroundPaint((java.awt.Paint) color6);
        objectList1.set((int) (short) 1, (java.lang.Object) categoryPlot3);
        java.lang.Object obj9 = null;
        int int10 = objectList1.indexOf(obj9);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        int int3 = java.awt.Color.HSBtoRGB((float) 35, 0.0f, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-254) + "'", int3 == (-254));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        categoryPlot0.select((double) (-1L), (double) 100, rectangle2D4, renderingSource5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.util.SortOrder sortOrder9 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setColumnRenderingOrder(sortOrder9);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        categoryPlot0.setRangeAxis(valueAxis12);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(sortOrder9);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        int int9 = categoryAxis1.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke10 = categoryAxis1.getTickMarkStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis1.getTickLabelInsets();
        float float12 = categoryAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("PlotEntity: tooltip = ");
        categoryAxis1.setTickLabelsVisible(true);
        categoryAxis1.clearCategoryLabelToolTips();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.junit.Assert.assertNotNull(rectangleInsets5);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setItemLabelAnchorOffset((double) 8);
        double double6 = barRenderer0.getItemMargin();
        java.awt.Shape shape8 = barRenderer0.lookupLegendShape(8);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer0.getNegativeItemLabelPosition(35, 0, true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot0.setRenderer(3, categoryItemRenderer7);
        categoryPlot0.clearAnnotations();
        boolean boolean10 = categoryPlot0.isDomainCrosshairVisible();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            categoryPlot0.drawOutline(graphics2D11, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = categoryPlot0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType8 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets6.createAdjustedRectangle(rectangle2D7, lengthAdjustmentType8, lengthAdjustmentType9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        categoryPlot0.select((double) (-1L), (double) 100, rectangle2D4, renderingSource5);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = null;
        categoryPlot0.axisChanged(axisChangeEvent7);
        org.junit.Assert.assertNull(legendItemCollection1);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        java.awt.Color color4 = java.awt.Color.green;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        barRenderer0.setSeriesToolTipGenerator(0, categoryToolTipGenerator7, true);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener13 = null;
        categoryPlot12.addChangeListener(plotChangeListener13);
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot12.setBackgroundPaint((java.awt.Paint) color15);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = null;
        categoryPlot12.axisChanged(axisChangeEvent17);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryPlot12.getAxisOffset();
        java.awt.Shape shape20 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener22 = null;
        categoryPlot21.addChangeListener(plotChangeListener22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot21.setBackgroundPaint((java.awt.Paint) color24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        categoryPlot21.setRenderer(categoryItemRenderer26);
        org.jfree.chart.entity.PlotEntity plotEntity29 = new org.jfree.chart.entity.PlotEntity(shape20, (org.jfree.chart.plot.Plot) categoryPlot21, "");
        categoryPlot21.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        java.awt.Stroke stroke39 = categoryAxis33.getTickMarkStroke();
        categoryPlot21.setDomainGridlineStroke(stroke39);
        java.lang.Comparable comparable41 = categoryPlot21.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset42 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot21.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset42);
        defaultCategoryDataset42.clearSelection();
        int int45 = defaultCategoryDataset42.getColumnCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState47 = barRenderer0.initialise(graphics2D10, rectangle2D11, categoryPlot12, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset42, plotRenderingInfo46);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(comparable41);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = categoryPlot0.getFixedLegendItems();
        java.awt.Paint paint4 = categoryPlot0.getNoDataMessagePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = null;
        org.jfree.chart.util.Layer layer6 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker5, layer6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(legendItemCollection3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        java.awt.Paint paint9 = categoryPlot4.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot4.getRangeAxisLocation();
        java.lang.String str11 = axisLocation10.toString();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "AxisLocation.TOP_OR_LEFT" + "'", str11.equals("AxisLocation.TOP_OR_LEFT"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot0.getIndexOf(categoryItemRenderer10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection13 = categoryPlot12.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.RenderingSource renderingSource17 = null;
        categoryPlot12.select((double) (-1L), (double) 100, rectangle2D16, renderingSource17);
        boolean boolean19 = categoryPlot12.canSelectByRegion();
        int int20 = categoryPlot12.getDomainAxisCount();
        categoryPlot0.setParent((org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor25 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = null;
        double double30 = categoryAxis23.getCategoryJava2DCoordinate(categoryAnchor25, (int) (byte) 100, (int) (byte) 1, rectangle2D28, rectangleEdge29);
        int int31 = categoryAxis23.getMaximumCategoryLabelLines();
        java.awt.Stroke stroke32 = categoryAxis23.getTickMarkStroke();
        categoryPlot12.setDomainGridlineStroke(stroke32);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        java.awt.Stroke stroke7 = categoryAxis1.getTickMarkStroke();
        java.awt.Font font8 = categoryAxis1.getLabelFont();
        double double9 = categoryAxis1.getLabelAngle();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        categoryPlot0.setRangeAxis((int) (short) 100, valueAxis11, true);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Shape shape15 = defaultDrawingSupplier14.getNextShape();
        java.awt.Shape shape16 = defaultDrawingSupplier14.getNextShape();
        java.awt.Stroke stroke17 = defaultDrawingSupplier14.getNextOutlineStroke();
        categoryPlot0.setRangeCrosshairStroke(stroke17);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent19 = null;
        categoryPlot0.axisChanged(axisChangeEvent19);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = categoryPlot0.getDomainAxisLocation();
        org.jfree.data.general.DatasetGroup datasetGroup4 = categoryPlot0.getDatasetGroup();
        java.awt.Font font5 = categoryPlot0.getNoDataMessageFont();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        categoryPlot0.setRenderer(3, categoryItemRenderer7);
        categoryPlot0.clearRangeMarkers((int) (short) 1);
        categoryPlot0.setWeight((int) ' ');
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNull(datasetGroup4);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        barRenderer0.setSeriesOutlinePaint(0, paint7, true);
        barRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer0.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator14 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator14);
        org.jfree.chart.renderer.category.BarPainter barPainter16 = null;
        try {
            barRenderer0.setBarPainter(barPainter16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot0.getIndexOf(categoryItemRenderer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer12.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        java.awt.Paint paint19 = categoryPlot16.getDomainGridlinePaint();
        barRenderer12.setSeriesOutlinePaint(0, paint19, true);
        barRenderer12.setBaseItemLabelsVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        barRenderer12.notifyListeners(rendererChangeEvent24);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean27 = barRenderer12.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) (byte) 100, (int) (byte) 1, rectangle2D6, rectangleEdge7);
        org.jfree.chart.plot.Plot plot9 = categoryAxis1.getPlot();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(plot9);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        try {
            java.lang.Comparable comparable3 = keyedObjects0.getKey(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 255, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        int int11 = categoryPlot0.getIndexOf(categoryItemRenderer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer12.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener17 = null;
        categoryPlot16.addChangeListener(plotChangeListener17);
        java.awt.Paint paint19 = categoryPlot16.getDomainGridlinePaint();
        barRenderer12.setSeriesOutlinePaint(0, paint19, true);
        barRenderer12.setBaseItemLabelsVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        barRenderer12.notifyListeners(rendererChangeEvent24);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent27 = null;
        categoryPlot0.markerChanged(markerChangeEvent27);
        java.awt.Stroke stroke29 = categoryPlot0.getRangeZeroBaselineStroke();
        categoryPlot0.clearRangeMarkers((int) 'a');
        java.lang.Object obj32 = categoryPlot0.clone();
        org.jfree.chart.event.AnnotationChangeEvent annotationChangeEvent33 = null;
        categoryPlot0.annotationChanged(annotationChangeEvent33);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(obj32);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        barRenderer0.setBase((double) 0.5f);
        barRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot10.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot10.setRenderer(categoryItemRenderer15);
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape9, (org.jfree.chart.plot.Plot) categoryPlot10, "");
        categoryPlot10.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font26 = categoryAxis25.getLabelFont();
        categoryAxis22.setTickLabelFont((java.lang.Comparable) 10.0d, font26);
        java.awt.Stroke stroke28 = categoryAxis22.getTickMarkStroke();
        categoryPlot10.setDomainGridlineStroke(stroke28);
        java.lang.Comparable comparable30 = categoryPlot10.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot10.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset31);
        org.jfree.data.Range range34 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset31, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke39 = barRenderer0.getItemStroke(0, 35, false);
        double double40 = barRenderer0.getBase();
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(comparable30);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNull(itemLabelPosition35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.5d + "'", double40 == 0.5d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        java.awt.Paint paint9 = categoryPlot4.getRangeCrosshairPaint();
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot4.getRangeAxisLocation();
        java.awt.Shape shape12 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener14 = null;
        categoryPlot13.addChangeListener(plotChangeListener14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot13.setBackgroundPaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot13.setRenderer(categoryItemRenderer18);
        org.jfree.chart.entity.PlotEntity plotEntity21 = new org.jfree.chart.entity.PlotEntity(shape12, (org.jfree.chart.plot.Plot) categoryPlot13, "");
        categoryPlot13.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font29 = categoryAxis28.getLabelFont();
        categoryAxis25.setTickLabelFont((java.lang.Comparable) 10.0d, font29);
        java.awt.Stroke stroke31 = categoryAxis25.getTickMarkStroke();
        categoryPlot13.setDomainGridlineStroke(stroke31);
        java.lang.Comparable comparable33 = categoryPlot13.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset34 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot13.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset34);
        defaultCategoryDataset34.clearSelection();
        int int37 = defaultCategoryDataset34.getColumnCount();
        categoryPlot4.setDataset((int) (short) 1, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset34);
        defaultCategoryDataset34.fireSelectionEvent();
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(comparable33);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        categoryPlot5.setRenderer(categoryItemRenderer10);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape4, (org.jfree.chart.plot.Plot) categoryPlot5, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot14.setBackgroundPaint((java.awt.Paint) color17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font24 = categoryAxis23.getLabelFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) 10.0d, font24);
        java.awt.Stroke stroke26 = categoryAxis20.getTickMarkStroke();
        categoryPlot14.setRangeGridlineStroke(stroke26);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color30 = java.awt.Color.getColor("", color29);
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape4, stroke26, (java.awt.Paint) color30);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font37 = categoryAxis36.getLabelFont();
        categoryAxis33.setTickLabelFont((java.lang.Comparable) 10.0d, font37);
        legendItem31.setLabelFont(font37);
        java.awt.Paint paint40 = legendItem31.getLinePaint();
        java.awt.Shape shape41 = legendItem31.getLine();
        legendItem31.setDescription("AxisLocation.BOTTOM_OR_LEFT");
        legendItem31.setDescription("Category Plot");
        java.awt.Paint paint46 = legendItem31.getFillPaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(font37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(shape41);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Shape shape3 = renderAttributes0.getItemShape(8, 8);
        java.awt.Stroke stroke5 = renderAttributes0.getSeriesStroke(100);
        java.awt.Color color7 = java.awt.Color.green;
        renderAttributes0.setSeriesOutlinePaint(4, (java.awt.Paint) color7);
        java.awt.Paint paint9 = renderAttributes0.getDefaultFillPaint();
        org.junit.Assert.assertNull(shape3);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener9 = null;
        categoryPlot8.addChangeListener(plotChangeListener9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot8.setBackgroundPaint((java.awt.Paint) color11);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font18 = categoryAxis17.getLabelFont();
        categoryAxis14.setTickLabelFont((java.lang.Comparable) 10.0d, font18);
        java.awt.Stroke stroke20 = categoryAxis14.getTickMarkStroke();
        categoryPlot8.setRangeGridlineStroke(stroke20);
        categoryPlot0.setRangeGridlineStroke(stroke20);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        categoryPlot0.setRenderer((int) (byte) 1, categoryItemRenderer24);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot0.zoomDomainAxes((double) 1L, plotRenderingInfo28, point2D29);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(drawingSupplier26);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        barRenderer0.setBase((double) 0.5f);
        java.lang.Object obj7 = barRenderer0.clone();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = barRenderer0.removeAnnotation(categoryAnnotation8);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = barRenderer0.getSeriesItemLabelGenerator((int) (short) 10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        categoryPlot14.addChangeListener(plotChangeListener15);
        java.awt.Paint paint17 = categoryPlot14.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean20 = categoryPlot14.removeDomainMarker(marker18, layer19);
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot14.getDataset(100);
        boolean boolean23 = categoryPlot14.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        int int25 = categoryPlot14.getIndexOf(categoryItemRenderer24);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer26.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener31 = null;
        categoryPlot30.addChangeListener(plotChangeListener31);
        java.awt.Paint paint33 = categoryPlot30.getDomainGridlinePaint();
        barRenderer26.setSeriesOutlinePaint(0, paint33, true);
        barRenderer26.setBaseItemLabelsVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent38 = null;
        barRenderer26.notifyListeners(rendererChangeEvent38);
        categoryPlot14.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer26);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent41 = null;
        categoryPlot14.markerChanged(markerChangeEvent41);
        java.awt.Stroke stroke43 = categoryPlot14.getRangeZeroBaselineStroke();
        categoryPlot14.clearRangeMarkers((int) 'a');
        java.lang.Object obj46 = categoryPlot14.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        java.awt.Shape shape49 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener51 = null;
        categoryPlot50.addChangeListener(plotChangeListener51);
        java.awt.Color color53 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot50.setBackgroundPaint((java.awt.Paint) color53);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer55 = null;
        categoryPlot50.setRenderer(categoryItemRenderer55);
        org.jfree.chart.entity.PlotEntity plotEntity58 = new org.jfree.chart.entity.PlotEntity(shape49, (org.jfree.chart.plot.Plot) categoryPlot50, "");
        categoryPlot50.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis65 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font66 = categoryAxis65.getLabelFont();
        categoryAxis62.setTickLabelFont((java.lang.Comparable) 10.0d, font66);
        java.awt.Stroke stroke68 = categoryAxis62.getTickMarkStroke();
        categoryPlot50.setDomainGridlineStroke(stroke68);
        java.lang.Comparable comparable70 = categoryPlot50.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset71 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot50.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset71);
        org.jfree.chart.plot.CategoryPlot categoryPlot73 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection74 = categoryPlot73.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        org.jfree.chart.RenderingSource renderingSource78 = null;
        categoryPlot73.select((double) (-1L), (double) 100, rectangle2D77, renderingSource78);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray80 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot73.setRenderers(categoryItemRendererArray80);
        defaultCategoryDataset71.addChangeListener((org.jfree.data.event.DatasetChangeListener) categoryPlot73);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState86 = null;
        java.awt.geom.Rectangle2D rectangle2D87 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D88 = barRenderer0.createHotSpotBounds(graphics2D12, rectangle2D13, categoryPlot14, categoryAxis47, valueAxis48, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset71, (int) ' ', 0, false, categoryItemRendererState86, rectangle2D87);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNotNull(shape49);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(font66);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNull(comparable70);
        org.junit.Assert.assertNull(legendItemCollection74);
        org.junit.Assert.assertNotNull(categoryItemRendererArray80);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator5, false);
        barRenderer0.setItemMargin((double) 4);
        barRenderer0.setBaseSeriesVisibleInLegend(true);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = categoryPlot0.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.RenderingSource renderingSource5 = null;
        categoryPlot0.select((double) (-1L), (double) 100, rectangle2D4, renderingSource5);
        boolean boolean7 = categoryPlot0.canSelectByRegion();
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.util.SortOrder sortOrder9 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder9);
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) 10.0f, (double) 0L, (double) 100, (double) 10.0f);
        double double17 = rectangleInsets15.trimWidth(1.0d);
        double double19 = rectangleInsets15.trimWidth(0.0d);
        categoryPlot0.setInsets(rectangleInsets15, false);
        org.junit.Assert.assertNull(legendItemCollection1);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-9.0d) + "'", double17 == (-9.0d));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-10.0d) + "'", double19 == (-10.0d));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setSeriesShapesFilled(2, (java.lang.Boolean) true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer2.getItemStroke(100, 0, true);
        lineAndShapeRenderer2.setSeriesCreateEntities(2, (java.lang.Boolean) true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = barRenderer19.getItemLabelGenerator(100, 100, false);
        int int24 = barRenderer19.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = barRenderer19.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint27 = barRenderer19.lookupSeriesOutlinePaint(0);
        java.awt.Paint paint31 = barRenderer19.getItemFillPaint(0, (int) (short) 1, true);
        java.awt.Stroke stroke32 = barRenderer19.getBaseOutlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer34.setAutoPopulateSeriesShape(false);
        barRenderer34.setDefaultEntityRadius(2);
        java.awt.Stroke stroke40 = barRenderer34.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener42 = null;
        categoryPlot41.addChangeListener(plotChangeListener42);
        java.awt.Color color44 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot41.setBackgroundPaint((java.awt.Paint) color44);
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font51 = categoryAxis50.getLabelFont();
        categoryAxis47.setTickLabelFont((java.lang.Comparable) 10.0d, font51);
        java.awt.Stroke stroke53 = categoryAxis47.getTickMarkStroke();
        categoryPlot41.setRangeGridlineStroke(stroke53);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent55 = null;
        categoryPlot41.notifyListeners(plotChangeEvent55);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = categoryPlot41.getRangeAxisEdge(3);
        barRenderer34.setPlot(categoryPlot41);
        boolean boolean61 = barRenderer34.isSeriesVisible((int) (short) 10);
        java.awt.Shape shape62 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        barRenderer34.setBaseShape(shape62, false);
        barRenderer19.setLegendShape((int) (byte) 10, shape62);
        try {
            lineAndShapeRenderer2.setSeriesShape((int) (short) -1, shape62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(font51);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(shape62);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        java.awt.Shape shape24 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener26 = null;
        categoryPlot25.addChangeListener(plotChangeListener26);
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot25.setBackgroundPaint((java.awt.Paint) color28);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot25.setRenderer(categoryItemRenderer30);
        org.jfree.chart.entity.PlotEntity plotEntity33 = new org.jfree.chart.entity.PlotEntity(shape24, (org.jfree.chart.plot.Plot) categoryPlot25, "");
        java.lang.String str34 = plotEntity33.toString();
        boolean boolean35 = defaultCategoryDataset22.equals((java.lang.Object) plotEntity33);
        try {
            java.lang.Comparable comparable37 = defaultCategoryDataset22.getRowKey((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "PlotEntity: tooltip = " + "'", str34.equals("PlotEntity: tooltip = "));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        boolean boolean22 = categoryPlot1.canSelectByPoint();
        java.awt.Shape shape27 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener29 = null;
        categoryPlot28.addChangeListener(plotChangeListener29);
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot28.setBackgroundPaint((java.awt.Paint) color31);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        categoryPlot28.setRenderer(categoryItemRenderer33);
        org.jfree.chart.entity.PlotEntity plotEntity36 = new org.jfree.chart.entity.PlotEntity(shape27, (org.jfree.chart.plot.Plot) categoryPlot28, "");
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener38 = null;
        categoryPlot37.addChangeListener(plotChangeListener38);
        java.awt.Color color40 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot37.setBackgroundPaint((java.awt.Paint) color40);
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font47 = categoryAxis46.getLabelFont();
        categoryAxis43.setTickLabelFont((java.lang.Comparable) 10.0d, font47);
        java.awt.Stroke stroke49 = categoryAxis43.getTickMarkStroke();
        categoryPlot37.setRangeGridlineStroke(stroke49);
        java.awt.Color color52 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Color color53 = java.awt.Color.getColor("", color52);
        org.jfree.chart.LegendItem legendItem54 = new org.jfree.chart.LegendItem("hi!", "hi!", "hi!", "", shape27, stroke49, (java.awt.Paint) color53);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType55 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer56 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType55);
        legendItem54.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer56);
        java.lang.String str58 = legendItem54.getToolTipText();
        java.awt.Paint paint59 = legendItem54.getOutlinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font65 = categoryAxis64.getLabelFont();
        categoryAxis61.setTickLabelFont((java.lang.Comparable) 10.0d, font65);
        java.awt.Stroke stroke67 = categoryAxis61.getTickMarkStroke();
        java.awt.Font font68 = categoryAxis61.getLabelFont();
        legendItem54.setLabelFont(font68);
        org.jfree.chart.axis.CategoryAxis categoryAxis71 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font72 = categoryAxis71.getLabelFont();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor73 = null;
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge77 = null;
        double double78 = categoryAxis71.getCategoryJava2DCoordinate(categoryAnchor73, (int) (byte) 100, (int) (byte) 1, rectangle2D76, rectangleEdge77);
        org.jfree.chart.axis.CategoryAxis categoryAxis80 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font81 = categoryAxis80.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets82 = categoryAxis80.getTickLabelInsets();
        java.awt.Color color83 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis80.setLabelPaint((java.awt.Paint) color83);
        categoryAxis71.setAxisLinePaint((java.awt.Paint) color83);
        legendItem54.setLinePaint((java.awt.Paint) color83);
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color83);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(font47);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertNotNull(gradientPaintTransformType55);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "hi!" + "'", str58.equals("hi!"));
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertNotNull(font72);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertNotNull(font81);
        org.junit.Assert.assertNotNull(rectangleInsets82);
        org.junit.Assert.assertNotNull(color83);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = null;
        barRenderer0.setSeriesItemLabelGenerator(3, categoryItemLabelGenerator5, false);
        java.lang.Boolean boolean9 = barRenderer0.getSeriesCreateEntities(4);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = barRenderer0.getBasePositiveItemLabelPosition();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        try {
            barRenderer0.drawOutline(graphics2D11, categoryPlot12, rectangle2D13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        java.lang.Boolean boolean4 = lineAndShapeRenderer2.getSeriesShapesFilled(0);
        lineAndShapeRenderer2.setSeriesShapesVisible((int) (short) 0, false);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        java.awt.Stroke stroke4 = categoryPlot0.getRangeCrosshairStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot0.getDomainAxis();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener7 = null;
        categoryPlot6.addChangeListener(plotChangeListener7);
        java.awt.Paint paint9 = categoryPlot6.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        boolean boolean12 = categoryPlot6.removeDomainMarker(marker10, layer11);
        org.jfree.data.category.CategoryDataset categoryDataset14 = categoryPlot6.getDataset(100);
        categoryPlot6.clearRangeMarkers();
        org.jfree.chart.util.ShadowGenerator shadowGenerator16 = categoryPlot6.getShadowGenerator();
        categoryPlot0.setShadowGenerator(shadowGenerator16);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categoryDataset14);
        org.junit.Assert.assertNotNull(shadowGenerator16);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        barRenderer0.setBase((double) 0.5f);
        java.lang.Object obj7 = barRenderer0.clone();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        boolean boolean9 = barRenderer0.removeAnnotation(categoryAnnotation8);
        java.awt.Shape shape10 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        categoryPlot11.addChangeListener(plotChangeListener12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot11.setBackgroundPaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        categoryPlot11.setRenderer(categoryItemRenderer16);
        org.jfree.chart.entity.PlotEntity plotEntity19 = new org.jfree.chart.entity.PlotEntity(shape10, (org.jfree.chart.plot.Plot) categoryPlot11, "");
        categoryPlot11.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font27 = categoryAxis26.getLabelFont();
        categoryAxis23.setTickLabelFont((java.lang.Comparable) 10.0d, font27);
        java.awt.Stroke stroke29 = categoryAxis23.getTickMarkStroke();
        categoryPlot11.setDomainGridlineStroke(stroke29);
        java.lang.Comparable comparable31 = categoryPlot11.getDomainCrosshairColumnKey();
        barRenderer0.setPlot(categoryPlot11);
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer33.setBaseSeriesVisibleInLegend(true, false);
        barRenderer33.setItemLabelAnchorOffset((double) 8);
        java.awt.Stroke stroke42 = barRenderer33.getItemOutlineStroke((-16727872), 10, false);
        categoryPlot11.setRangeZeroBaselineStroke(stroke42);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent44 = null;
        categoryPlot11.axisChanged(axisChangeEvent44);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(comparable31);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        barRenderer0.setSeriesOutlinePaint(0, paint7, true);
        barRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer0.notifyListeners(rendererChangeEvent12);
        barRenderer0.setDefaultEntityRadius(8);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font10 = categoryAxis9.getLabelFont();
        categoryAxis6.setTickLabelFont((java.lang.Comparable) 10.0d, font10);
        java.awt.Stroke stroke12 = categoryAxis6.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke12);
        categoryPlot0.setRangeCrosshairValue((double) 10);
        categoryPlot0.setAnchorValue((double) 0.0f);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        categoryPlot0.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot0.getRenderer();
        java.awt.Stroke stroke22 = categoryPlot0.getDomainGridlineStroke();
        java.lang.String str23 = categoryPlot0.getNoDataMessage();
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNull(str23);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setBaseSeriesVisible(false, true);
        barRenderer0.setBaseSeriesVisibleInLegend(false, true);
        java.awt.Stroke stroke13 = barRenderer0.getItemOutlineStroke(1, 0, false);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font2 = categoryAxis1.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Paint paint7 = categoryPlot4.getDomainGridlinePaint();
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        categoryPlot4.clearAnnotations();
        java.awt.Font font10 = categoryPlot4.getNoDataMessageFont();
        org.jfree.chart.axis.AxisLocation axisLocation11 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot4.setDomainAxisLocation(axisLocation11, true);
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 0.2d);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = barRenderer0.getPlot();
        barRenderer0.setBaseCreateEntities(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(categoryPlot2);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener6 = null;
        categoryPlot5.addChangeListener(plotChangeListener6);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot5.setBackgroundPaint((java.awt.Paint) color8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        java.awt.Paint[] paintArray11 = new java.awt.Paint[] { color8, color10 };
        java.awt.Color color12 = java.awt.Color.YELLOW;
        int int13 = color12.getBlue();
        java.awt.Color color14 = java.awt.Color.ORANGE;
        java.awt.Color color15 = java.awt.Color.WHITE;
        java.awt.Color color16 = color15.darker();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        java.awt.Paint[] paintArray18 = new java.awt.Paint[] { color12, color14, color16, color17 };
        java.awt.Stroke stroke19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Stroke[] strokeArray21 = new java.awt.Stroke[] { stroke19, stroke20 };
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font27 = categoryAxis26.getLabelFont();
        categoryAxis23.setTickLabelFont((java.lang.Comparable) 10.0d, font27);
        java.awt.Stroke stroke29 = categoryAxis23.getTickMarkStroke();
        java.awt.Stroke[] strokeArray30 = new java.awt.Stroke[] { stroke29 };
        java.awt.Shape shape31 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Shape[] shapeArray32 = new java.awt.Shape[] { shape31 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier33 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray11, paintArray18, strokeArray21, strokeArray30, shapeArray32);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier33);
        categoryPlot0.setDomainCrosshairVisible(false);
        boolean boolean37 = categoryPlot0.isRangePannable();
        org.jfree.chart.axis.ValueAxis valueAxis39 = categoryPlot0.getRangeAxisForDataset(2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(paintArray11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(paintArray18);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(strokeArray21);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(strokeArray30);
        org.junit.Assert.assertNotNull(shape31);
        org.junit.Assert.assertNotNull(shapeArray32);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(valueAxis39);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setUseOutlinePaint(false);
        int int9 = lineAndShapeRenderer2.getDefaultEntityRadius();
        lineAndShapeRenderer2.setBaseShapesVisible(false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 3 + "'", int9 == 3);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener1 = null;
        categoryPlot0.addChangeListener(plotChangeListener1);
        java.awt.Paint paint3 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        boolean boolean6 = categoryPlot0.removeDomainMarker(marker4, layer5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        boolean boolean9 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot0.panRangeAxes((double) (short) 1, plotRenderingInfo11, point2D12);
        int int14 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.Plot plot15 = categoryPlot0.getParent();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(categoryDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 15 + "'", int14 == 15);
        org.junit.Assert.assertNull(plot15);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        int int5 = barRenderer0.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint8 = barRenderer0.getLegendTextPaint(4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = null;
        barRenderer0.setSeriesToolTipGenerator((int) (short) 1, categoryToolTipGenerator10);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(itemLabelPosition6);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.util.List list1 = defaultCategoryDataset0.getRowKeys();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font4 = categoryAxis3.getLabelFont();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis3.getTickLabelInsets();
        java.awt.Color color6 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryAxis3.setLabelPaint((java.awt.Paint) color6);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis3, valueAxis8, categoryItemRenderer9);
        try {
            java.lang.Number number13 = defaultCategoryDataset0.getValue((java.lang.Comparable) (-16727872), (java.lang.Comparable) 101);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (-16727872) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener2 = null;
        categoryPlot1.addChangeListener(plotChangeListener2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot1.setBackgroundPaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot1.setRenderer(categoryItemRenderer6);
        org.jfree.chart.entity.PlotEntity plotEntity9 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "");
        categoryPlot1.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot1.setDomainGridlineStroke(stroke19);
        java.lang.Comparable comparable21 = categoryPlot1.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset22 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot1.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset22);
        defaultCategoryDataset22.clearSelection();
        java.awt.Shape shape25 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener27 = null;
        categoryPlot26.addChangeListener(plotChangeListener27);
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot26.setBackgroundPaint((java.awt.Paint) color29);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        categoryPlot26.setRenderer(categoryItemRenderer31);
        org.jfree.chart.entity.PlotEntity plotEntity34 = new org.jfree.chart.entity.PlotEntity(shape25, (org.jfree.chart.plot.Plot) categoryPlot26, "");
        categoryPlot26.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font42 = categoryAxis41.getLabelFont();
        categoryAxis38.setTickLabelFont((java.lang.Comparable) 10.0d, font42);
        java.awt.Stroke stroke44 = categoryAxis38.getTickMarkStroke();
        categoryPlot26.setDomainGridlineStroke(stroke44);
        java.lang.Comparable comparable46 = categoryPlot26.getDomainCrosshairColumnKey();
        boolean boolean47 = categoryPlot26.canSelectByPoint();
        boolean boolean48 = defaultCategoryDataset22.hasListener((java.util.EventListener) categoryPlot26);
        categoryPlot26.setRangeCrosshairValue((double) 'a');
        org.jfree.chart.axis.CategoryAxis categoryAxis52 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font53 = categoryAxis52.getLabelFont();
        boolean boolean54 = categoryAxis52.isMinorTickMarksVisible();
        boolean boolean55 = categoryAxis52.isAxisLineVisible();
        categoryAxis52.setAxisLineVisible(false);
        java.util.List list58 = categoryPlot26.getCategoriesForAxis(categoryAxis52);
        categoryPlot26.setDrawSharedDomainAxis(true);
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(comparable21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(comparable46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNotNull(font53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(list58);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getItemLabelGenerator(100, 100, false);
        barRenderer0.setBase((double) 0.5f);
        barRenderer0.setAutoPopulateSeriesStroke(true);
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot10.setBackgroundPaint((java.awt.Paint) color13);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        categoryPlot10.setRenderer(categoryItemRenderer15);
        org.jfree.chart.entity.PlotEntity plotEntity18 = new org.jfree.chart.entity.PlotEntity(shape9, (org.jfree.chart.plot.Plot) categoryPlot10, "");
        categoryPlot10.setBackgroundAlpha((float) 10L);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font26 = categoryAxis25.getLabelFont();
        categoryAxis22.setTickLabelFont((java.lang.Comparable) 10.0d, font26);
        java.awt.Stroke stroke28 = categoryAxis22.getTickMarkStroke();
        categoryPlot10.setDomainGridlineStroke(stroke28);
        java.lang.Comparable comparable30 = categoryPlot10.getDomainCrosshairColumnKey();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset31 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot10.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset31);
        org.jfree.data.Range range34 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset31, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition35 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Stroke stroke37 = barRenderer0.getSeriesStroke(0);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(comparable30);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNull(itemLabelPosition35);
        org.junit.Assert.assertNull(stroke37);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.entity.ChartEntity chartEntity6 = new org.jfree.chart.entity.ChartEntity(shape4, "hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Paint paint10 = categoryPlot7.getDomainGridlinePaint();
        java.awt.Stroke stroke11 = categoryPlot7.getRangeCrosshairStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = barRenderer12.getItemLabelGenerator(100, 100, false);
        int int17 = barRenderer12.getRowCount();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer12.getPositiveItemLabelPositionFallback();
        java.awt.Paint paint20 = barRenderer12.lookupSeriesOutlinePaint(0);
        java.awt.Paint paint24 = barRenderer12.getItemFillPaint(0, (int) (short) 1, true);
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("PlotEntity: tooltip = ", "", "AxisLocation.BOTTOM_OR_LEFT", "Category Plot", shape4, stroke11, paint24);
        boolean boolean26 = legendItem25.isShapeFilled();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font5 = categoryAxis4.getLabelFont();
        categoryAxis1.setTickLabelFont((java.lang.Comparable) 10.0d, font5);
        float float7 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setLabelAngle((double) (short) 100);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener11 = null;
        categoryPlot10.addChangeListener(plotChangeListener11);
        java.awt.Paint paint13 = categoryPlot10.getDomainGridlinePaint();
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot10.removeDomainMarker(marker14, layer15);
        boolean boolean17 = categoryPlot10.canSelectByRegion();
        categoryAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot10);
        categoryPlot10.clearDomainMarkers();
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setAutoPopulateSeriesShape(false);
        barRenderer0.setDefaultEntityRadius(2);
        java.awt.Stroke stroke6 = barRenderer0.lookupSeriesOutlineStroke((int) (byte) 1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot7.addChangeListener(plotChangeListener8);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot7.setBackgroundPaint((java.awt.Paint) color10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis("");
        java.awt.Font font17 = categoryAxis16.getLabelFont();
        categoryAxis13.setTickLabelFont((java.lang.Comparable) 10.0d, font17);
        java.awt.Stroke stroke19 = categoryAxis13.getTickMarkStroke();
        categoryPlot7.setRangeGridlineStroke(stroke19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = null;
        categoryPlot7.notifyListeners(plotChangeEvent21);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot7.getRangeAxisEdge(3);
        barRenderer0.setPlot(categoryPlot7);
        java.awt.Paint paint27 = null;
        barRenderer0.setSeriesItemLabelPaint((int) (short) 1, paint27, true);
        java.lang.Boolean boolean31 = barRenderer0.getSeriesVisible(2);
        barRenderer0.setDefaultEntityRadius((-16727872));
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNull(boolean31);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseSeriesVisibleInLegend(true, false);
        barRenderer0.setBaseSeriesVisible(false, false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("java.awt.Color[r=64,g=64,b=64]");
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        java.awt.Shape shape3 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener5 = null;
        categoryPlot4.addChangeListener(plotChangeListener5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot4.setBackgroundPaint((java.awt.Paint) color7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        categoryPlot4.setRenderer(categoryItemRenderer9);
        org.jfree.chart.entity.PlotEntity plotEntity12 = new org.jfree.chart.entity.PlotEntity(shape3, (org.jfree.chart.plot.Plot) categoryPlot4, "");
        categoryPlot4.setBackgroundAlpha((float) 10L);
        keyedObjects0.setObject((java.lang.Comparable) 10.0f, (java.lang.Object) 10L);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType17 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer18 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType17);
        java.awt.Shape shape19 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot20.addChangeListener(plotChangeListener21);
        java.awt.Color color23 = org.jfree.chart.ChartColor.DARK_CYAN;
        categoryPlot20.setBackgroundPaint((java.awt.Paint) color23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        categoryPlot20.setRenderer(categoryItemRenderer25);
        org.jfree.chart.entity.PlotEntity plotEntity28 = new org.jfree.chart.entity.PlotEntity(shape19, (org.jfree.chart.plot.Plot) categoryPlot20, "");
        boolean boolean29 = categoryPlot20.isRangePannable();
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = new org.jfree.chart.axis.CategoryAxis("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        categoryAxis31.setLabelInsets(rectangleInsets32, true);
        java.util.List list35 = categoryPlot20.getCategoriesForAxis(categoryAxis31);
        java.awt.Color color36 = java.awt.Color.ORANGE;
        categoryAxis31.setTickMarkPaint((java.awt.Paint) color36);
        boolean boolean38 = standardGradientPaintTransformer18.equals((java.lang.Object) categoryAxis31);
        keyedObjects0.setObject((java.lang.Comparable) 0.0d, (java.lang.Object) standardGradientPaintTransformer18);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.LegendItemCollection legendItemCollection41 = categoryPlot40.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Point2D point2D44 = null;
        categoryPlot40.zoomRangeAxes((double) (short) 10, plotRenderingInfo43, point2D44, false);
        org.jfree.chart.util.SortOrder sortOrder47 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot40.setRowRenderingOrder(sortOrder47);
        try {
            keyedObjects0.sortByKeys(sortOrder47);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.Float cannot be cast to java.lang.Double");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(gradientPaintTransformType17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(legendItemCollection41);
        org.junit.Assert.assertNotNull(sortOrder47);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, true);
        lineAndShapeRenderer2.setSeriesLinesVisible((int) (short) 10, true);
        boolean boolean6 = lineAndShapeRenderer2.getDrawOutlines();
        lineAndShapeRenderer2.setUseOutlinePaint(false);
        boolean boolean9 = lineAndShapeRenderer2.getBaseCreateEntities();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = new org.jfree.chart.labels.ItemLabelPosition();
        java.awt.Color color11 = java.awt.Color.WHITE;
        java.awt.Color color12 = color11.darker();
        boolean boolean13 = itemLabelPosition10.equals((java.lang.Object) color11);
        lineAndShapeRenderer2.setBaseNegativeItemLabelPosition(itemLabelPosition10, true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }
}

