import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
//        textTitle3.setURLText("-4,-4,4,4");
//        java.awt.geom.Rectangle2D rectangle2D6 = textTitle3.getBounds();
//        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
//        java.util.EventListener eventListener8 = null;
//        boolean boolean9 = categoryAxis7.hasListener(eventListener8);
//        categoryAxis7.setFixedDimension((double) (short) -1);
//        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = null;
//        java.awt.geom.Rectangle2D rectangle2D15 = null;
//        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
//        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
//        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
//        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
//        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
//        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
//        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
//        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
//        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
//        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
//        org.jfree.chart.util.Layer layer39 = null;
//        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
//        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
//        double double43 = categoryAxis7.getCategoryJava2DCoordinate(categoryAnchor12, (int) 'a', 2, rectangle2D15, rectangleEdge42);
//        double double44 = dateAxis0.valueToJava2D((double) (short) 100, rectangle2D6, rectangleEdge42);
//        org.jfree.data.KeyToGroupMap keyToGroupMap46 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
//        int int48 = keyToGroupMap46.getGroupIndex((java.lang.Comparable) "");
//        org.jfree.data.KeyToGroupMap keyToGroupMap50 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
//        int int52 = keyToGroupMap50.getGroupIndex((java.lang.Comparable) "");
//        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
//        keyToGroupMap50.mapKeyToGroup((java.lang.Comparable) 8, (java.lang.Comparable) dateTickUnit54);
//        java.lang.String str56 = dateTickUnit54.toString();
//        int int57 = keyToGroupMap46.getKeyCount((java.lang.Comparable) dateTickUnit54);
//        org.jfree.data.time.Month month58 = new org.jfree.data.time.Month();
//        java.lang.String str59 = month58.toString();
//        java.util.Date date60 = month58.getEnd();
//        java.util.Date date61 = dateTickUnit54.addToDate(date60);
//        java.util.Date date62 = dateAxis0.calculateLowestVisibleTickValue(dateTickUnit54);
//        org.junit.Assert.assertNotNull(rectangle2D6);
//        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
//        org.junit.Assert.assertNotNull(itemLabelPosition22);
//        org.junit.Assert.assertNotNull(paint24);
//        org.junit.Assert.assertNull(categoryPlot25);
//        org.junit.Assert.assertNotNull(color30);
//        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
//        org.junit.Assert.assertNull(drawingSupplier34);
//        org.junit.Assert.assertNotNull(rectangleEdge42);
//        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
//        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
//        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
//        org.junit.Assert.assertNotNull(dateTickUnit54);
//        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str56.equals("DateTickUnit[DAY, 1]"));
//        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "June 2019" + "'", str59.equals("June 2019"));
//        org.junit.Assert.assertNotNull(date60);
//        org.junit.Assert.assertNotNull(date61);
//        org.junit.Assert.assertNotNull(date62);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        java.awt.Paint paint16 = null;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape4, stroke13, paint16);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity20 = new org.jfree.chart.entity.TickLabelEntity(shape4, "({0}, {1}) = {3} - {4}", "org.jfree.chart.event.ChartChangeEvent[source=]");
        java.lang.String str21 = tickLabelEntity20.getShapeCoords();
        java.lang.String str22 = tickLabelEntity20.getURLText();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-4,-4,4,4" + "'", str21.equals("-4,-4,4,4"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=]" + "'", str22.equals("org.jfree.chart.event.ChartChangeEvent[source=]"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        java.lang.Object obj8 = segmentedTimeline7.clone();
        long long11 = segmentedTimeline7.getExceptionSegmentCount((long) (short) 0, (long) 1900);
        try {
            segmentedTimeline3.setBaseTimeline(segmentedTimeline7);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot19.markerChanged(markerChangeEvent28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        float float31 = jFreeChart30.getBackgroundImageAlpha();
        org.jfree.chart.title.Title title33 = jFreeChart30.getSubtitle(0);
        jFreeChart30.setNotify(true);
        java.util.List list36 = jFreeChart30.getSubtitles();
        org.jfree.chart.event.ChartChangeListener chartChangeListener37 = null;
        try {
            jFreeChart30.addChangeListener(chartChangeListener37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.5f + "'", float31 == 0.5f);
        org.junit.Assert.assertNotNull(title33);
        org.junit.Assert.assertNotNull(list36);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.String str1 = axisLocation0.toString();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str1.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        ringPlot50.setSectionDepth((double) 0.8f);
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
        org.jfree.data.gantt.Task task55 = new org.jfree.data.gantt.Task("rect", (org.jfree.data.time.TimePeriod) month54);
        java.awt.Paint paint56 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        ringPlot50.setSectionOutlinePaint((java.lang.Comparable) "rect", paint56);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(paint56);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "TextAnchor.TOP_CENTER");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 60000L);
        try {
            java.lang.Number number5 = defaultKeyedValues0.getValue(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        layeredBarRenderer0.setSeriesBarWidth((int) (short) 10, (double) 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        java.awt.Stroke stroke51 = ringPlot50.getBaseSectionOutlineStroke();
        java.awt.Paint paint52 = ringPlot50.getLabelShadowPaint();
        double double53 = ringPlot50.getMinimumArcAngleToDraw();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0E-5d + "'", double53 == 1.0E-5d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidWeekdayCode(1900);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        java.awt.Stroke stroke4 = stackedBarRenderer1.getItemStroke((int) (short) 10, 9);
        java.awt.Paint paint7 = stackedBarRenderer1.getItemPaint(11, (int) '#');
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
        int int3 = defaultKeyedValues2D1.getColumnCount();
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("rect", (org.jfree.data.time.TimePeriod) month1);
        task2.setPercentComplete((java.lang.Double) Double.NaN);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        java.awt.Paint paint37 = polarPlot36.getRadiusGridlinePaint();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent38 = null;
        polarPlot36.datasetChanged(datasetChangeEvent38);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int1 = dateTickUnit0.getUnit();
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.util.List list2 = blockContainer1.getBlocks();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range4, (double) (-1));
        try {
            org.jfree.chart.util.Size2D size2D7 = blockContainer1.arrange(graphics2D3, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        int int3 = defaultCategoryDataset0.getColumnCount();
        try {
            java.lang.Comparable comparable5 = defaultCategoryDataset0.getColumnKey((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot7.setOrientation(plotOrientation8);
        xYPlot7.clearDomainAxes();
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color14 = java.awt.Color.magenta;
        valueMarker13.setOutlinePaint((java.awt.Paint) color14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int17 = color16.getGreen();
        valueMarker13.setOutlinePaint((java.awt.Paint) color16);
        java.awt.Color color19 = java.awt.Color.magenta;
        valueMarker13.setLabelPaint((java.awt.Paint) color19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent21 = null;
        valueMarker13.notifyListeners(markerChangeEvent21);
        org.jfree.chart.util.Layer layer23 = null;
        xYPlot7.addRangeMarker(11, (org.jfree.chart.plot.Marker) valueMarker13, layer23);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("{0}", graphics2D1, (float) 900000L, (float) (byte) 0, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        java.awt.Paint paint16 = null;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape4, stroke13, paint16);
        int int18 = legendItem17.getDatasetIndex();
        boolean boolean19 = legendItem17.isShapeOutlineVisible();
        java.awt.Paint paint20 = legendItem17.getFillPaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.awt.Stroke stroke0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot19.getLegendItems();
        int int27 = categoryPlot19.getDatasetCount();
        java.util.List list28 = categoryPlot19.getCategories();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertNull(list28);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
//        int int3 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) "");
//        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
//        keyToGroupMap1.mapKeyToGroup((java.lang.Comparable) 8, (java.lang.Comparable) dateTickUnit5);
//        org.jfree.chart.axis.DateAxis dateAxis7 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
//        textTitle10.setURLText("-4,-4,4,4");
//        java.awt.geom.Rectangle2D rectangle2D13 = textTitle10.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
//        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition20 = lineAndShapeRenderer17.getNegativeItemLabelPosition((int) ' ', 100);
//        java.awt.Paint paint22 = lineAndShapeRenderer17.lookupSeriesPaint((int) (byte) -1);
//        org.jfree.chart.plot.CategoryPlot categoryPlot23 = lineAndShapeRenderer17.getPlot();
//        java.awt.Color color28 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
//        lineAndShapeRenderer17.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color28, true);
//        boolean boolean31 = lineAndShapeRenderer17.getUseFillPaint();
//        org.jfree.chart.plot.DrawingSupplier drawingSupplier32 = lineAndShapeRenderer17.getDrawingSupplier();
//        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer17);
//        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray35 = new org.jfree.chart.axis.ValueAxis[] { valueAxis34 };
//        categoryPlot33.setRangeAxes(valueAxisArray35);
//        categoryPlot33.setDrawSharedDomainAxis(false);
//        boolean boolean39 = categoryPlot33.isRangeGridlinesVisible();
//        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot33.getRangeAxisEdge();
//        double double41 = dateAxis7.valueToJava2D(0.0d, rectangle2D13, rectangleEdge40);
//        java.util.Date date42 = dateAxis7.getMinimumDate();
//        java.lang.String str43 = dateTickUnit5.dateToString(date42);
//        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
//        java.lang.String str45 = month44.toString();
//        java.util.Date date46 = month44.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod47 = new org.jfree.data.time.SimpleTimePeriod(date42, date46);
//        org.jfree.data.time.SerialDate serialDate48 = org.jfree.data.time.SerialDate.createInstance(date42);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertNotNull(dateTickUnit5);
//        org.junit.Assert.assertNotNull(rectangle2D13);
//        org.junit.Assert.assertNotNull(itemLabelPosition20);
//        org.junit.Assert.assertNotNull(paint22);
//        org.junit.Assert.assertNull(categoryPlot23);
//        org.junit.Assert.assertNotNull(color28);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertNull(drawingSupplier32);
//        org.junit.Assert.assertNotNull(valueAxisArray35);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(rectangleEdge40);
//        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
//        org.junit.Assert.assertNotNull(date42);
//        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "12/31/69 4:00 PM" + "'", str43.equals("12/31/69 4:00 PM"));
//        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "June 2019" + "'", str45.equals("June 2019"));
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(serialDate48);
//    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D30.setVerticalTickLabels(true);
        org.jfree.data.Range range33 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        boolean boolean34 = numberAxis3D30.getAutoRangeIncludesZero();
        org.jfree.data.Range range35 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis3D30.setRangeWithMargins(range35, false, false);
        java.awt.Stroke stroke39 = numberAxis3D30.getAxisLineStroke();
        double double40 = numberAxis3D30.getFixedAutoRange();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        java.lang.Comparable comparable1 = null;
        int int2 = taskSeriesCollection0.indexOf(comparable1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Date date1 = year0.getEnd();
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        java.awt.Font font2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] { valueAxis23 };
        categoryPlot22.setRangeAxes(valueAxisArray24);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray26 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot22.setRenderers(categoryItemRendererArray26);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("Sunday", font2, (org.jfree.chart.plot.Plot) categoryPlot22, false);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font2);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(valueAxisArray24);
        org.junit.Assert.assertNotNull(categoryItemRendererArray26);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot7.getRenderer((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer13.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint18 = lineAndShapeRenderer13.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = lineAndShapeRenderer13.getPlot();
        java.awt.Color color24 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer13.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color24, true);
        boolean boolean27 = lineAndShapeRenderer13.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = lineAndShapeRenderer13.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer13);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray31 = new org.jfree.chart.axis.ValueAxis[] { valueAxis30 };
        categoryPlot29.setRangeAxes(valueAxisArray31);
        categoryPlot29.setDrawSharedDomainAxis(false);
        java.awt.Font font35 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean36 = categoryPlot29.equals((java.lang.Object) font35);
        categoryPlot29.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D40.setVerticalTickLabels(true);
        org.jfree.data.Range range43 = categoryPlot29.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D40);
        xYPlot7.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D40);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = xYPlot7.getRangeAxisEdge(15);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        xYPlot7.setRenderer((int) '#', xYItemRenderer48);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(categoryPlot19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(valueAxisArray31);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        boolean boolean5 = lineAndShapeRenderer0.isSeriesVisible((int) ' ');
        java.awt.Paint paint6 = lineAndShapeRenderer0.getBaseItemLabelPaint();
        java.lang.Object obj7 = lineAndShapeRenderer0.clone();
        org.jfree.chart.LegendItem legendItem10 = lineAndShapeRenderer0.getLegendItem((int) '#', 15);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(legendItem10);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test035");
//        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
//        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
//        org.jfree.data.KeyToGroupMap keyToGroupMap4 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
//        int int6 = keyToGroupMap4.getGroupIndex((java.lang.Comparable) "");
//        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
//        keyToGroupMap4.mapKeyToGroup((java.lang.Comparable) 8, (java.lang.Comparable) dateTickUnit8);
//        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
//        textTitle13.setURLText("-4,-4,4,4");
//        java.awt.geom.Rectangle2D rectangle2D16 = textTitle13.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
//        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = lineAndShapeRenderer20.getNegativeItemLabelPosition((int) ' ', 100);
//        java.awt.Paint paint25 = lineAndShapeRenderer20.lookupSeriesPaint((int) (byte) -1);
//        org.jfree.chart.plot.CategoryPlot categoryPlot26 = lineAndShapeRenderer20.getPlot();
//        java.awt.Color color31 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
//        lineAndShapeRenderer20.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color31, true);
//        boolean boolean34 = lineAndShapeRenderer20.getUseFillPaint();
//        org.jfree.chart.plot.DrawingSupplier drawingSupplier35 = lineAndShapeRenderer20.getDrawingSupplier();
//        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
//        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray38 = new org.jfree.chart.axis.ValueAxis[] { valueAxis37 };
//        categoryPlot36.setRangeAxes(valueAxisArray38);
//        categoryPlot36.setDrawSharedDomainAxis(false);
//        boolean boolean42 = categoryPlot36.isRangeGridlinesVisible();
//        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot36.getRangeAxisEdge();
//        double double44 = dateAxis10.valueToJava2D(0.0d, rectangle2D16, rectangleEdge43);
//        java.util.Date date45 = dateAxis10.getMinimumDate();
//        java.lang.String str46 = dateTickUnit8.dateToString(date45);
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        java.lang.String str48 = month47.toString();
//        java.util.Date date49 = month47.getEnd();
//        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod50 = new org.jfree.data.time.SimpleTimePeriod(date45, date49);
//        try {
//            java.lang.Number number52 = taskSeriesCollection0.getPercentComplete((java.lang.Comparable) "DateTickUnit[DAY, 1]", (java.lang.Comparable) date45, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
//        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
//        }
//        org.junit.Assert.assertNull(range1);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
//        org.junit.Assert.assertNotNull(dateTickUnit8);
//        org.junit.Assert.assertNotNull(rectangle2D16);
//        org.junit.Assert.assertNotNull(itemLabelPosition23);
//        org.junit.Assert.assertNotNull(paint25);
//        org.junit.Assert.assertNull(categoryPlot26);
//        org.junit.Assert.assertNotNull(color31);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//        org.junit.Assert.assertNull(drawingSupplier35);
//        org.junit.Assert.assertNotNull(valueAxisArray38);
//        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
//        org.junit.Assert.assertNotNull(rectangleEdge43);
//        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
//        org.junit.Assert.assertNotNull(date45);
//        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "12/31/69 4:00 PM" + "'", str46.equals("12/31/69 4:00 PM"));
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "June 2019" + "'", str48.equals("June 2019"));
//        org.junit.Assert.assertNotNull(date49);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        int int28 = categoryPlot19.getDatasetCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot19.getDomainAxisForDataset((int) (short) -1);
        java.awt.Color color32 = org.jfree.chart.util.PaintUtilities.stringToColor("");
        categoryPlot19.setDomainGridlinePaint((java.awt.Paint) color32);
        java.awt.Paint paint34 = categoryPlot19.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(paint34);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        double[][] doubleArray4 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("-4,-4,4,4", "", doubleArray4);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) categoryDataset5, (java.lang.Comparable) 9999);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.Range range9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint(range9, (double) (-1));
        try {
            org.jfree.chart.util.Size2D size2D12 = legendItemBlockContainer7.arrange(graphics2D8, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeColumn((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent28 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.plot.PlotOrientation plotOrientation29 = categoryPlot19.getOrientation();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(plotOrientation29);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.axis.AxisCollection axisCollection0 = new org.jfree.chart.axis.AxisCollection();
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.util.List list2 = blockContainer1.getBlocks();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle5.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle5.getBounds();
        org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color11 = java.awt.Color.magenta;
        valueMarker10.setOutlinePaint((java.awt.Paint) color11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = valueMarker10.getLabelOffset();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer14.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint19 = lineAndShapeRenderer14.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = lineAndShapeRenderer14.getPlot();
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer14.setSeriesStroke((int) (byte) 1, stroke22, true);
        valueMarker10.setStroke(stroke22);
        try {
            java.lang.Object obj26 = blockContainer1.draw(graphics2D3, rectangle2D8, (java.lang.Object) stroke22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryPlot20);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Paint paint19 = lineAndShapeRenderer0.getItemLabelPaint(0, 10);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = lineAndShapeRenderer0.getLegendItems();
        lineAndShapeRenderer0.setSeriesCreateEntities(2, (java.lang.Boolean) false, false);
        lineAndShapeRenderer0.setSeriesLinesVisible(3, false);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(legendItemCollection20);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        boolean boolean2 = objectList0.equals((java.lang.Object) 100.0f);
        objectList0.clear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        ringPlot50.setSeparatorsVisible(true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot19.markerChanged(markerChangeEvent28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Paint paint31 = jFreeChart30.getBackgroundPaint();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean2 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot22.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.Range range29 = categoryPlot22.getDataRange(valueAxis28);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = categoryPlot22.getDatasetRenderingOrder();
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        numberAxis3D1.setRangeAboutValue((double) 4, (double) '#');
        java.awt.Shape shape35 = numberAxis3D1.getUpArrow();
        numberAxis3D1.setAxisLineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNotNull(shape35);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setFixedDimension((double) (short) -1);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) '4');
        int int7 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setMaximumCategoryLabelLines(0);
        double double10 = categoryAxis0.getFixedDimension();
        categoryAxis0.setCategoryMargin(0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10 == (-1.0d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) year0);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo2 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo2.setName("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo5.setName("TextBlockAnchor.CENTER_LEFT");
        basicProjectInfo2.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo5);
        basicProjectInfo5.setInfo("ERROR : Relative To String");
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = textTitle12.getPosition();
        boolean boolean14 = basicProjectInfo5.equals((java.lang.Object) rectangleEdge13);
        boolean boolean15 = org.jfree.chart.util.ObjectUtilities.equal((java.lang.Object) year0, (java.lang.Object) rectangleEdge13);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot19.markerChanged(markerChangeEvent28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        float float31 = jFreeChart30.getBackgroundImageAlpha();
        org.jfree.chart.title.Title title33 = jFreeChart30.getSubtitle(0);
        boolean boolean34 = jFreeChart30.getAntiAlias();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.5f + "'", float31 == 0.5f);
        org.junit.Assert.assertNotNull(title33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape9 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = lineAndShapeRenderer10.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint15 = lineAndShapeRenderer10.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = lineAndShapeRenderer10.getPlot();
        java.awt.Stroke stroke18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer10.setSeriesStroke((int) (byte) 1, stroke18, true);
        java.awt.Paint paint21 = null;
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape9, stroke18, paint21);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor23 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.util.ShapeList shapeList24 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape26 = null;
        shapeList24.setShape((int) (byte) 10, shape26);
        boolean boolean28 = rectangleAnchor23.equals((java.lang.Object) shape26);
        java.lang.String str29 = rectangleAnchor23.toString();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape9, rectangleAnchor23, (double) 9999, (double) (short) -1);
        java.awt.Color color34 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color38 = java.awt.Color.magenta;
        valueMarker37.setOutlinePaint((java.awt.Paint) color38);
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int41 = color40.getGreen();
        valueMarker37.setOutlinePaint((java.awt.Paint) color40);
        java.awt.Color color43 = java.awt.Color.magenta;
        valueMarker37.setLabelPaint((java.awt.Paint) color43);
        org.jfree.data.KeyToGroupMap keyToGroupMap46 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
        int int48 = keyToGroupMap46.getGroupIndex((java.lang.Comparable) "");
        org.jfree.chart.axis.DateTickUnit dateTickUnit50 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        keyToGroupMap46.mapKeyToGroup((java.lang.Comparable) 8, (java.lang.Comparable) dateTickUnit50);
        java.lang.String str52 = dateTickUnit50.toString();
        int int53 = dateTickUnit50.getRollUnit();
        java.awt.Stroke stroke54 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        int int55 = dateTickUnit50.compareTo((java.lang.Object) stroke54);
        java.awt.Shape shape61 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer62 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition65 = lineAndShapeRenderer62.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint67 = lineAndShapeRenderer62.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = lineAndShapeRenderer62.getPlot();
        java.awt.Stroke stroke70 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer62.setSeriesStroke((int) (byte) 1, stroke70, true);
        java.awt.Paint paint73 = null;
        org.jfree.chart.LegendItem legendItem74 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape61, stroke70, paint73);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity77 = new org.jfree.chart.entity.TickLabelEntity(shape61, "({0}, {1}) = {3} - {4}", "org.jfree.chart.event.ChartChangeEvent[source=]");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer78 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Stroke stroke80 = levelRenderer78.lookupSeriesOutlineStroke(9);
        java.awt.Paint paint81 = null;
        try {
            org.jfree.chart.LegendItem legendItem82 = new org.jfree.chart.LegendItem(attributedString0, "TextAnchor.TOP_CENTER", "TextAnchor.TOP_CENTER", "ThreadContext", false, shape9, false, (java.awt.Paint) color34, false, (java.awt.Paint) color43, stroke54, false, shape61, stroke80, paint81);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryPlot16);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(rectangleAnchor23);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str29.equals("RectangleAnchor.BOTTOM_LEFT"));
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertNotNull(dateTickUnit50);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str52.equals("DateTickUnit[DAY, 1]"));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 2 + "'", int53 == 2);
        org.junit.Assert.assertNotNull(stroke54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1) + "'", int55 == (-1));
        org.junit.Assert.assertNotNull(shape61);
        org.junit.Assert.assertNotNull(itemLabelPosition65);
        org.junit.Assert.assertNotNull(paint67);
        org.junit.Assert.assertNull(categoryPlot68);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNotNull(stroke80);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        int int0 = org.jfree.data.time.SerialDate.THIRD_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = lineAndShapeRenderer1.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint6 = lineAndShapeRenderer1.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = lineAndShapeRenderer1.getPlot();
        java.awt.Color color12 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer1.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color12, true);
        boolean boolean15 = lineAndShapeRenderer1.getUseFillPaint();
        java.lang.Boolean boolean17 = lineAndShapeRenderer1.getSeriesShapesFilled(0);
        boolean boolean18 = axisSpace0.equals((java.lang.Object) lineAndShapeRenderer1);
        java.awt.Shape shape20 = lineAndShapeRenderer1.lookupSeriesShape((int) (byte) -1);
        java.awt.Font font23 = lineAndShapeRenderer1.getItemLabelFont((int) (byte) 0, (int) (byte) 100);
        java.awt.Font font24 = null;
        lineAndShapeRenderer1.setBaseItemLabelFont(font24, true);
        java.awt.Paint paint27 = lineAndShapeRenderer1.getBaseItemLabelPaint();
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryPlot7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        java.awt.Paint paint16 = null;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape4, stroke13, paint16);
        org.jfree.chart.entity.ChartEntity chartEntity20 = new org.jfree.chart.entity.ChartEntity(shape4, "", "VerticalAlignment.BOTTOM");
        java.lang.Object obj21 = chartEntity20.clone();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        boolean boolean5 = lineAndShapeRenderer0.isSeriesVisible((int) ' ');
        java.awt.Paint paint6 = lineAndShapeRenderer0.getBaseItemLabelPaint();
        java.lang.Object obj7 = lineAndShapeRenderer0.clone();
        java.awt.Paint paint9 = lineAndShapeRenderer0.getSeriesItemLabelPaint((int) (short) 0);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNull(paint9);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener3 = null;
        boolean boolean4 = categoryAxis2.hasListener(eventListener3);
        categoryAxis2.setFixedDimension((double) (short) -1);
        java.awt.Font font8 = categoryAxis2.getTickLabelFont((java.lang.Comparable) '4');
        int int9 = categoryAxis2.getMaximumCategoryLabelLines();
        categoryAxis2.setMaximumCategoryLabelLines(0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = null;
        org.jfree.chart.block.BlockBorder blockBorder15 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = blockBorder15.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis17 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle20.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D23 = textTitle20.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition30 = lineAndShapeRenderer27.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint32 = lineAndShapeRenderer27.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = lineAndShapeRenderer27.getPlot();
        java.awt.Color color38 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer27.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color38, true);
        boolean boolean41 = lineAndShapeRenderer27.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier42 = lineAndShapeRenderer27.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer27);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray45 = new org.jfree.chart.axis.ValueAxis[] { valueAxis44 };
        categoryPlot43.setRangeAxes(valueAxisArray45);
        categoryPlot43.setDrawSharedDomainAxis(false);
        boolean boolean49 = categoryPlot43.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot43.getRangeAxisEdge();
        double double51 = dateAxis17.valueToJava2D(0.0d, rectangle2D23, rectangleEdge50);
        java.awt.geom.Rectangle2D rectangle2D52 = rectangleInsets16.createOutsetRectangle(rectangle2D23);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str54 = rectangleEdge53.toString();
        double double55 = categoryAxis2.getCategoryJava2DCoordinate(categoryAnchor12, (int) (byte) 10, 4, rectangle2D23, rectangleEdge53);
        plotRenderingInfo1.setPlotArea(rectangle2D23);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNotNull(blockBorder15);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertNotNull(itemLabelPosition30);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(categoryPlot33);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(drawingSupplier42);
        org.junit.Assert.assertNotNull(valueAxisArray45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "RectangleEdge.LEFT" + "'", str54.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle1.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D4 = textTitle1.getBounds();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getTextAlignment();
        boolean boolean6 = textTitle1.getExpandToFitSpace();
        org.junit.Assert.assertNotNull(rectangle2D4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D30.setVerticalTickLabels(true);
        org.jfree.data.Range range33 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        java.text.NumberFormat numberFormat34 = null;
        numberAxis3D30.setNumberFormatOverride(numberFormat34);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent36 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis3D30);
        org.jfree.data.RangeType rangeType37 = numberAxis3D30.getRangeType();
        boolean boolean39 = rangeType37.equals((java.lang.Object) 10.0f);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(rangeType37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_OUTLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.util.ShapeList shapeList1 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape3 = null;
        shapeList1.setShape((int) (byte) 10, shape3);
        boolean boolean5 = rectangleAnchor0.equals((java.lang.Object) shape3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str7 = textBlockAnchor6.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer12.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint17 = lineAndShapeRenderer12.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = lineAndShapeRenderer12.getPlot();
        java.awt.Color color23 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer12.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color23, true);
        boolean boolean26 = lineAndShapeRenderer12.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = lineAndShapeRenderer12.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer12);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer32 = null;
        categoryPlot28.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker31, layer32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot28.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot28);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent37 = null;
        categoryPlot28.markerChanged(markerChangeEvent37);
        boolean boolean39 = textBlockAnchor6.equals((java.lang.Object) categoryPlot28);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener41 = null;
        boolean boolean42 = categoryAxis40.hasListener(eventListener41);
        categoryAxis40.setTickMarkInsideLength((float) 100L);
        java.awt.Font font46 = categoryAxis40.getTickLabelFont((java.lang.Comparable) ' ');
        boolean boolean47 = categoryAxis40.isTickLabelsVisible();
        float float48 = categoryAxis40.getTickMarkInsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = categoryAxis40.getTickLabelInsets();
        categoryPlot28.setInsets(rectangleInsets49, true);
        java.awt.Stroke stroke52 = categoryPlot28.getOutlineStroke();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str7.equals("TextBlockAnchor.CENTER_LEFT"));
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryPlot18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(drawingSupplier27);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 100.0f + "'", float48 == 100.0f);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(stroke52);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Comparable comparable2 = taskSeriesCollection0.getSeriesKey(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("WMAP_Plot", graphics2D1, (float) (short) 10, (float) 7, textAnchor4, 1.0E-5d, (float) 3, (float) 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle4.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle4.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer11.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint16 = lineAndShapeRenderer11.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = lineAndShapeRenderer11.getPlot();
        java.awt.Color color22 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer11.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color22, true);
        boolean boolean25 = lineAndShapeRenderer11.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = lineAndShapeRenderer11.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot27.setRangeAxes(valueAxisArray29);
        categoryPlot27.setDrawSharedDomainAxis(false);
        boolean boolean33 = categoryPlot27.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot27.getRangeAxisEdge();
        double double35 = dateAxis1.valueToJava2D(0.0d, rectangle2D7, rectangleEdge34);
        java.util.Date date36 = dateAxis1.getMinimumDate();
        java.lang.Number number38 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) date36, (java.lang.Comparable) "Polar Plot");
        try {
            java.lang.Number number41 = defaultStatisticalCategoryDataset0.getStdDevValue((-1), 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(categoryPlot17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(number38);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color2 = java.awt.Color.magenta;
        valueMarker1.setOutlinePaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        valueMarker1.setStroke(stroke13);
        java.lang.Class class17 = null;
        try {
            java.util.EventListener[] eventListenerArray18 = valueMarker1.getListeners(class17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        lineAndShapeRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator1);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getBaseOutlineStroke();
        org.jfree.chart.event.RendererChangeListener rendererChangeListener5 = null;
        try {
            lineAndShapeRenderer0.removeChangeListener(rendererChangeListener5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition0 = org.jfree.chart.axis.DateTickMarkPosition.START;
        org.junit.Assert.assertNotNull(dateTickMarkPosition0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.awt.Paint paint0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setItemMargin((double) ' ');
        levelRenderer0.setBaseSeriesVisible(false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier1 = waterfallBarRenderer0.getDrawingSupplier();
        org.junit.Assert.assertNull(drawingSupplier1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = multiplePiePlot2.getLegendItems();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(legendItemCollection3);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Paint paint19 = lineAndShapeRenderer0.getItemLabelPaint(0, 10);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = lineAndShapeRenderer0.getLegendItems();
        java.awt.Stroke stroke21 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Stroke stroke23 = lineAndShapeRenderer0.lookupSeriesStroke(0);
        lineAndShapeRenderer0.setSeriesShapesVisible(5, true);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.general.PieDataset pieDataset17 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 3);
        java.lang.Comparable comparable20 = null;
        try {
            defaultCategoryDataset0.setValue((java.lang.Number) 0.0d, (java.lang.Comparable) 8, comparable20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(pieDataset17);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean1 = barRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] { valueAxis23 };
        categoryPlot22.setRangeAxes(valueAxisArray24);
        categoryPlot22.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D29.setVerticalTickLabels(true);
        numberAxis3D29.setLowerBound((double) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color36 = java.awt.Color.magenta;
        valueMarker35.setOutlinePaint((java.awt.Paint) color36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int39 = color38.getGreen();
        valueMarker35.setOutlinePaint((java.awt.Paint) color38);
        java.awt.Stroke stroke41 = valueMarker35.getStroke();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        barRenderer3D0.drawRangeMarker(graphics2D2, categoryPlot22, (org.jfree.chart.axis.ValueAxis) numberAxis3D29, (org.jfree.chart.plot.Marker) valueMarker35, rectangle2D42);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit45 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
        numberAxis3D29.setTickUnit(numberTickUnit45, false, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(valueAxisArray24);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int5 = dateTickUnit4.getCalendarField();
        int int6 = dateTickUnit4.getCalendarField();
        defaultKeyedValues2D1.setValue((java.lang.Number) (byte) 0, (java.lang.Comparable) 0L, (java.lang.Comparable) int6);
        int int9 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) 1.0f);
        int int10 = defaultKeyedValues2D1.getColumnCount();
        int int12 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) "UnitType.RELATIVE");
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 60000L);
        java.lang.Object obj4 = null;
        boolean boolean5 = defaultKeyedValues0.equals(obj4);
        try {
            java.lang.Comparable comparable7 = defaultKeyedValues0.getKey(7);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        stackedAreaRenderer1.setBaseSeriesVisible(false);
        boolean boolean4 = stackedAreaRenderer1.getRenderAsPercentages();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("VerticalAlignment.BOTTOM");
        textTitle1.setExpandToFitSpace(false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setXOffset((double) 86400000L);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer7.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint12 = lineAndShapeRenderer7.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = lineAndShapeRenderer7.getPlot();
        java.awt.Color color18 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer7.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color18, true);
        boolean boolean21 = lineAndShapeRenderer7.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = lineAndShapeRenderer7.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer27 = null;
        categoryPlot23.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer27);
        boolean boolean29 = categoryPlot23.isRangeZoomable();
        org.jfree.chart.block.BlockBorder blockBorder30 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = blockBorder30.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis32 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle35 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle35.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D38 = textTitle35.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition45 = lineAndShapeRenderer42.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint47 = lineAndShapeRenderer42.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = lineAndShapeRenderer42.getPlot();
        java.awt.Color color53 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer42.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color53, true);
        boolean boolean56 = lineAndShapeRenderer42.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier57 = lineAndShapeRenderer42.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer42);
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray60 = new org.jfree.chart.axis.ValueAxis[] { valueAxis59 };
        categoryPlot58.setRangeAxes(valueAxisArray60);
        categoryPlot58.setDrawSharedDomainAxis(false);
        boolean boolean64 = categoryPlot58.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = categoryPlot58.getRangeAxisEdge();
        double double66 = dateAxis32.valueToJava2D(0.0d, rectangle2D38, rectangleEdge65);
        java.awt.geom.Rectangle2D rectangle2D67 = rectangleInsets31.createOutsetRectangle(rectangle2D38);
        try {
            lineRenderer3D0.drawDomainGridline(graphics2D3, categoryPlot23, rectangle2D38, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryPlot13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(drawingSupplier22);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(blockBorder30);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(rectangle2D38);
        org.junit.Assert.assertNotNull(itemLabelPosition45);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNull(categoryPlot48);
        org.junit.Assert.assertNotNull(color53);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(drawingSupplier57);
        org.junit.Assert.assertNotNull(valueAxisArray60);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D67);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.time.Month month4 = org.jfree.data.time.Month.parseMonth("June 2019");
        java.util.Date date5 = month4.getEnd();
        try {
            java.lang.Number number7 = taskSeriesCollection0.getEndValue((java.lang.Comparable) 0.2d, (java.lang.Comparable) month4, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(month4);
        org.junit.Assert.assertNotNull(date5);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        java.lang.String str1 = numberAxis3D0.getLabelURL();
        org.junit.Assert.assertNull(str1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis1.hasListener(eventListener2);
        categoryAxis1.setFixedDimension((double) (short) -1);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
        categoryAxis1.configure();
        boolean boolean10 = month0.equals((java.lang.Object) categoryAxis1);
        categoryAxis1.setTickLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        double double2 = blockParams0.getTranslateX();
        blockParams0.setTranslateY((double) ' ');
        blockParams0.setGenerateEntities(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot7.getDomainAxisEdge();
        boolean boolean9 = xYPlot7.isRangeZoomable();
        xYPlot7.setDomainCrosshairValue(0.0d);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D14 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D14.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis3D14, valueAxis17, xYItemRenderer18);
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot19.setOrientation(plotOrientation20);
        org.jfree.chart.axis.AxisSpace axisSpace22 = new org.jfree.chart.axis.AxisSpace();
        axisSpace22.setRight((double) 100L);
        xYPlot19.setFixedRangeAxisSpace(axisSpace22);
        boolean boolean26 = xYPlot7.equals((java.lang.Object) xYPlot19);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        java.awt.Paint paint16 = null;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape4, stroke13, paint16);
        int int18 = legendItem17.getDatasetIndex();
        legendItem17.setDatasetIndex((int) (short) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        int int23 = defaultCategoryDataset21.getRowIndex((java.lang.Comparable) 2.0d);
        legendItem17.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset21);
        boolean boolean25 = legendItem17.isLineVisible();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int5 = dateTickUnit4.getCalendarField();
        int int6 = dateTickUnit4.getCalendarField();
        defaultKeyedValues2D1.setValue((java.lang.Number) (byte) 0, (java.lang.Comparable) 0L, (java.lang.Comparable) int6);
        int int8 = defaultKeyedValues2D1.getColumnCount();
        defaultKeyedValues2D1.removeValue((java.lang.Comparable) 60000L, (java.lang.Comparable) 0.8f);
        int int12 = defaultKeyedValues2D1.getRowCount();
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.setValue((java.lang.Comparable) 6, (double) (-1.0f));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) year0);
        org.jfree.chart.axis.AxisSpace axisSpace2 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        java.lang.Boolean boolean19 = lineAndShapeRenderer3.getSeriesShapesFilled(0);
        boolean boolean20 = axisSpace2.equals((java.lang.Object) lineAndShapeRenderer3);
        java.awt.Shape shape22 = lineAndShapeRenderer3.lookupSeriesShape((int) (byte) -1);
        int int23 = year0.compareTo((java.lang.Object) lineAndShapeRenderer3);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(boolean19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        multiplePiePlot1.setLimit((double) (short) 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) 1, 0, 7);
        java.io.ObjectOutputStream objectOutputStream4 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writePaint((java.awt.Paint) chartColor3, objectOutputStream4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) 1, (double) 3);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer0.setBaseStroke(stroke17);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, true);
        org.jfree.chart.LegendItem legendItem27 = lineAndShapeRenderer0.getLegendItem(0, (int) '#');
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(legendItem27);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot19.getDomainAxisEdge();
        categoryPlot19.configureRangeAxes();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) year0);
        java.lang.Object obj2 = rendererChangeEvent1.getSource();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        java.awt.Color color0 = java.awt.Color.black;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        boolean boolean50 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset49);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot19.markerChanged(markerChangeEvent28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        float float31 = jFreeChart30.getBackgroundImageAlpha();
        org.jfree.chart.title.Title title33 = jFreeChart30.getSubtitle(0);
        java.awt.Stroke stroke34 = jFreeChart30.getBorderStroke();
        jFreeChart30.fireChartChanged();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.5f + "'", float31 == 0.5f);
        org.junit.Assert.assertNotNull(title33);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        boolean boolean28 = intervalCategoryToolTipGenerator0.equals((java.lang.Object) boolean27);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        java.util.Date date0 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) ' ', 100);
        org.jfree.chart.text.TextAnchor textAnchor6 = itemLabelPosition5.getTextAnchor();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer7.getNegativeItemLabelPosition((int) ' ', 100);
        org.jfree.chart.text.TextAnchor textAnchor11 = itemLabelPosition10.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor12 = itemLabelPosition10.getTextAnchor();
        try {
            org.jfree.chart.axis.DateTick dateTick14 = new org.jfree.chart.axis.DateTick(date0, "", textAnchor6, textAnchor12, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(textAnchor11);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        try {
            org.jfree.data.gantt.TaskSeries taskSeries4 = taskSeriesCollection0.getSeries((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Series index out of bounds");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
        java.lang.String str3 = numberTickUnit1.valueToString((double) (-1));
        java.lang.String str5 = numberTickUnit1.valueToString(Double.NaN);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1" + "'", str3.equals("-1"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "�" + "'", str5.equals("�"));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit((int) (byte) 10, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
        int int3 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) "");
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year();
        boolean boolean7 = year5.equals((java.lang.Object) 1.0d);
        java.lang.String str8 = year5.toString();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(3, year5);
        int int10 = keyToGroupMap1.getKeyCount((java.lang.Comparable) month9);
        java.util.Calendar calendar11 = null;
        try {
            long long12 = month9.getFirstMillisecond(calendar11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "2019" + "'", str8.equals("2019"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        java.awt.Color color3 = org.jfree.chart.util.PaintUtilities.stringToColor("");
        float[] floatArray10 = new float[] { 10, (-1.0f), 0.5f, 10.0f, 3, 9999 };
        float[] floatArray11 = color3.getRGBColorComponents(floatArray10);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color14 = java.awt.Color.magenta;
        valueMarker13.setOutlinePaint((java.awt.Paint) color14);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int17 = color16.getGreen();
        valueMarker13.setOutlinePaint((java.awt.Paint) color16);
        java.awt.Stroke stroke19 = valueMarker13.getStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = lineAndShapeRenderer20.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint25 = lineAndShapeRenderer20.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = lineAndShapeRenderer20.getPlot();
        java.awt.Color color31 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer20.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color31, true);
        boolean boolean34 = lineAndShapeRenderer20.getUseFillPaint();
        java.lang.Boolean boolean36 = lineAndShapeRenderer20.getSeriesShapesFilled(0);
        java.awt.Color color37 = java.awt.Color.LIGHT_GRAY;
        lineAndShapeRenderer20.setBaseItemLabelPaint((java.awt.Paint) color37);
        java.awt.Stroke stroke39 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker41 = new org.jfree.chart.plot.IntervalMarker((double) 0.8f, 0.0d, (java.awt.Paint) color3, stroke19, (java.awt.Paint) color37, stroke39, 1.0f);
        double double42 = intervalMarker41.getEndValue();
        java.lang.Object obj43 = intervalMarker41.clone();
        intervalMarker41.setEndValue(Double.NaN);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryPlot26);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(boolean36);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(obj43);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = lineAndShapeRenderer2.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = multiplePiePlot1.getDataset();
        org.junit.Assert.assertNull(categoryDataset2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Color color16 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer5.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color16, true);
        boolean boolean19 = lineAndShapeRenderer5.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = lineAndShapeRenderer5.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer5);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] { valueAxis22 };
        categoryPlot21.setRangeAxes(valueAxisArray23);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Font font27 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean28 = categoryPlot21.equals((java.lang.Object) font27);
        categoryPlot21.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D32.setVerticalTickLabels(true);
        org.jfree.data.Range range35 = categoryPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D32);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, polarItemRenderer36);
        polarPlot37.removeCornerTextItem("ERROR : Relative To String");
        java.awt.Font font40 = polarPlot37.getNoDataMessageFont();
        java.awt.Color color41 = java.awt.Color.GRAY;
        org.jfree.chart.text.TextBlock textBlock42 = org.jfree.chart.text.TextUtilities.createTextBlock("Sunday", font40, (java.awt.Paint) color41);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(textBlock42);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer0 = new org.jfree.chart.renderer.category.WaterfallBarRenderer();
        java.awt.Paint paint1 = waterfallBarRenderer0.getNegativeBarPaint();
        org.junit.Assert.assertNotNull(paint1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean3 = numberAxis3D2.getAutoRangeIncludesZero();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle7.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle7.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer14.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint19 = lineAndShapeRenderer14.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = lineAndShapeRenderer14.getPlot();
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer14.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color25, true);
        boolean boolean28 = lineAndShapeRenderer14.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = lineAndShapeRenderer14.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { valueAxis31 };
        categoryPlot30.setRangeAxes(valueAxisArray32);
        categoryPlot30.setDrawSharedDomainAxis(false);
        boolean boolean36 = categoryPlot30.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot30.getRangeAxisEdge();
        double double38 = dateAxis4.valueToJava2D(0.0d, rectangle2D10, rectangleEdge37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer39);
        java.awt.Paint paint41 = numberAxis3D2.getAxisLinePaint();
        numberAxis3D2.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryPlot20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D5 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D5.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset3, (org.jfree.chart.axis.ValueAxis) numberAxis3D5, valueAxis8, xYItemRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = xYPlot10.getDomainAxisEdge();
        boolean boolean12 = xYPlot10.isRangeZoomable();
        xYPlot10.setDomainCrosshairValue(0.0d);
        org.jfree.chart.event.PlotChangeListener plotChangeListener15 = null;
        xYPlot10.removeChangeListener(plotChangeListener15);
        int int17 = xYPlot10.getRangeAxisCount();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color20 = java.awt.Color.magenta;
        valueMarker19.setOutlinePaint((java.awt.Paint) color20);
        xYPlot10.setRangeCrosshairPaint((java.awt.Paint) color20);
        taskSeriesCollection0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) xYPlot10);
        java.lang.Comparable comparable24 = null;
        java.lang.Comparable comparable25 = null;
        try {
            java.lang.Number number26 = taskSeriesCollection0.getStartValue(comparable24, comparable25);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean3 = numberAxis3D2.getAutoRangeIncludesZero();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle7.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle7.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer14.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint19 = lineAndShapeRenderer14.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = lineAndShapeRenderer14.getPlot();
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer14.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color25, true);
        boolean boolean28 = lineAndShapeRenderer14.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = lineAndShapeRenderer14.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { valueAxis31 };
        categoryPlot30.setRangeAxes(valueAxisArray32);
        categoryPlot30.setDrawSharedDomainAxis(false);
        boolean boolean36 = categoryPlot30.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot30.getRangeAxisEdge();
        double double38 = dateAxis4.valueToJava2D(0.0d, rectangle2D10, rectangleEdge37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer39);
        java.util.TimeZone timeZone41 = dateAxis4.getTimeZone();
        try {
            dateAxis4.setAutoRangeMinimumSize((double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryPlot20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone41);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate6 = serialDate4.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate7 = serialDate2.getEndOfCurrentMonth(serialDate6);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.addMonths((int) (byte) 10, serialDate7);
        java.lang.String str9 = serialDate8.getDescription();
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("hi!", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = multiplePiePlot0.getLegendItems();
        java.awt.Shape shape6 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer7.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint12 = lineAndShapeRenderer7.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = lineAndShapeRenderer7.getPlot();
        java.awt.Stroke stroke15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer7.setSeriesStroke((int) (byte) 1, stroke15, true);
        java.awt.Paint paint18 = null;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape6, stroke15, paint18);
        java.lang.String str20 = legendItem19.getLabel();
        java.awt.Paint paint21 = legendItem19.getLinePaint();
        legendItemCollection1.add(legendItem19);
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryPlot13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "hi!" + "'", str20.equals("hi!"));
        org.junit.Assert.assertNull(paint21);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
        int int3 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) "");
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        keyToGroupMap1.mapKeyToGroup((java.lang.Comparable) 8, (java.lang.Comparable) dateTickUnit5);
        java.lang.String str7 = dateTickUnit5.toString();
        java.util.Date date8 = null;
        try {
            java.util.Date date9 = dateTickUnit5.rollDate(date8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str7.equals("DateTickUnit[DAY, 1]"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod2 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) 5);
        java.lang.Object obj3 = null;
        boolean boolean4 = simpleTimePeriod2.equals(obj3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot7.setOrientation(plotOrientation8);
        xYPlot7.clearDomainAxes();
        boolean boolean11 = xYPlot7.isDomainGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot7.getRangeAxis();
        org.jfree.chart.axis.AxisLocation axisLocation14 = xYPlot7.getRangeAxisLocation(1900);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D1.resizeRange((double) 1, 0.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle4.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle4.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer11.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint16 = lineAndShapeRenderer11.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = lineAndShapeRenderer11.getPlot();
        java.awt.Color color22 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer11.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color22, true);
        boolean boolean25 = lineAndShapeRenderer11.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = lineAndShapeRenderer11.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot27.setRangeAxes(valueAxisArray29);
        categoryPlot27.setDrawSharedDomainAxis(false);
        boolean boolean33 = categoryPlot27.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot27.getRangeAxisEdge();
        double double35 = dateAxis1.valueToJava2D(0.0d, rectangle2D7, rectangleEdge34);
        java.util.Date date36 = dateAxis1.getMinimumDate();
        java.lang.Number number38 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) date36, (java.lang.Comparable) "Polar Plot");
        double double40 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(categoryPlot17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(number38);
        org.junit.Assert.assertEquals((double) double40, Double.NaN, 0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        polarPlot36.removeCornerTextItem("ERROR : Relative To String");
        java.awt.Font font39 = polarPlot36.getNoDataMessageFont();
        boolean boolean40 = polarPlot36.isDomainZoomable();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.OUTSIDE1" + "'", str1.equals("ItemLabelAnchor.OUTSIDE1"));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.KeyToGroupMap keyToGroupMap4 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
        int int6 = keyToGroupMap4.getGroupIndex((java.lang.Comparable) "");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        keyToGroupMap4.mapKeyToGroup((java.lang.Comparable) 8, (java.lang.Comparable) dateTickUnit8);
        java.lang.Comparable comparable10 = null;
        try {
            defaultCategoryDataset0.setValue((double) (short) 0, (java.lang.Comparable) dateTickUnit8, comparable10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(dateTickUnit8);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        java.util.Set<java.lang.String> strSet1 = dataPackageResources0.keySet();
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        ringPlot50.setSectionDepth((double) 0.8f);
        java.awt.Paint paint53 = ringPlot50.getLabelPaint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean1 = barRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] { valueAxis23 };
        categoryPlot22.setRangeAxes(valueAxisArray24);
        categoryPlot22.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D29.setVerticalTickLabels(true);
        numberAxis3D29.setLowerBound((double) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color36 = java.awt.Color.magenta;
        valueMarker35.setOutlinePaint((java.awt.Paint) color36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int39 = color38.getGreen();
        valueMarker35.setOutlinePaint((java.awt.Paint) color38);
        java.awt.Stroke stroke41 = valueMarker35.getStroke();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        barRenderer3D0.drawRangeMarker(graphics2D2, categoryPlot22, (org.jfree.chart.axis.ValueAxis) numberAxis3D29, (org.jfree.chart.plot.Marker) valueMarker35, rectangle2D42);
        double double44 = numberAxis3D29.getUpperBound();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(valueAxisArray24);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.0d + "'", double44 == 2.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TAPER;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        lineAndShapeRenderer3.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Stroke stroke20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer3.setBaseStroke(stroke20);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        lineAndShapeRenderer3.setBaseItemLabelGenerator(categoryItemLabelGenerator22);
        java.awt.Stroke stroke24 = lineAndShapeRenderer3.getBaseOutlineStroke();
        objectList1.set(1, (java.lang.Object) lineAndShapeRenderer3);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setFixedDimension((double) (short) -1);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        java.awt.Font font8 = categoryAxis0.getTickLabelFont();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setXOffset((double) 86400000L);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.DateAxis dateAxis5 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle8.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D11 = textTitle8.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = lineAndShapeRenderer15.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint20 = lineAndShapeRenderer15.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = lineAndShapeRenderer15.getPlot();
        java.awt.Color color26 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer15.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color26, true);
        boolean boolean29 = lineAndShapeRenderer15.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier30 = lineAndShapeRenderer15.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer15);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray33 = new org.jfree.chart.axis.ValueAxis[] { valueAxis32 };
        categoryPlot31.setRangeAxes(valueAxisArray33);
        categoryPlot31.setDrawSharedDomainAxis(false);
        boolean boolean37 = categoryPlot31.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot31.getRangeAxisEdge();
        double double39 = dateAxis5.valueToJava2D(0.0d, rectangle2D11, rectangleEdge38);
        boolean boolean41 = dateAxis5.isHiddenValue((long) 10);
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        lineRenderer3D0.drawRangeGridline(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) dateAxis5, rectangle2D42, (double) 8);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(categoryPlot21);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(drawingSupplier30);
        org.junit.Assert.assertNotNull(valueAxisArray33);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (byte) 10, (double) (short) 10);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range4, true, false);
        double double8 = range4.getUpperBound();
        org.junit.Assert.assertNotNull(range4);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent4 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) (short) -1);
        taskSeriesCollection0.seriesChanged(seriesChangeEvent4);
        java.lang.Comparable comparable6 = null;
        int int7 = taskSeriesCollection0.getRowIndex(comparable6);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        polarPlot36.removeCornerTextItem("ERROR : Relative To String");
        polarPlot36.clearCornerTextItems();
        boolean boolean40 = polarPlot36.isRangeZoomable();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot19.markerChanged(markerChangeEvent28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        java.util.List list31 = jFreeChart30.getSubtitles();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection35 = null;
        chartRenderingInfo34.setEntityCollection(entityCollection35);
        java.awt.image.BufferedImage bufferedImage37 = jFreeChart30.createBufferedImage(1, (int) ' ', chartRenderingInfo34);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(bufferedImage37);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color2 = java.awt.Color.magenta;
        valueMarker1.setOutlinePaint((java.awt.Paint) color2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int5 = color4.getGreen();
        valueMarker1.setOutlinePaint((java.awt.Paint) color4);
        java.awt.Color color7 = java.awt.Color.magenta;
        valueMarker1.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener11 = null;
        boolean boolean12 = categoryAxis10.hasListener(eventListener11);
        categoryAxis10.setTickMarkInsideLength((float) 100L);
        java.awt.Font font16 = categoryAxis10.getTickLabelFont((java.lang.Comparable) ' ');
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.CENTER_LEFT", font16);
        valueMarker1.setLabelFont(font16);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = lineAndShapeRenderer22.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint27 = lineAndShapeRenderer22.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = lineAndShapeRenderer22.getPlot();
        java.awt.Color color33 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer22.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color33, true);
        boolean boolean36 = lineAndShapeRenderer22.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier37 = lineAndShapeRenderer22.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer42 = null;
        categoryPlot38.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker41, layer42);
        boolean boolean44 = categoryPlot38.isRangeZoomable();
        java.lang.String str45 = categoryPlot38.getPlotType();
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot38);
        valueMarker1.setAlpha((float) 0L);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(categoryPlot28);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(drawingSupplier37);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Category Plot" + "'", str45.equals("Category Plot"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint2 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (float) '#', (int) (byte) -1, textMeasurer5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textBlock6.getLineAlignment();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = textBlock6.calculateDimensions(graphics2D8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = textBlock6.getLineAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.Font font15 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint16 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer19 = null;
        org.jfree.chart.text.TextBlock textBlock20 = org.jfree.chart.text.TextUtilities.createTextBlock("", font15, paint16, (float) '#', (int) (byte) -1, textMeasurer19);
        org.jfree.chart.text.TextLine textLine21 = textBlock20.getLastLine();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor25 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        java.awt.Shape shape29 = textBlock20.calculateBounds(graphics2D22, (float) 10L, (float) 4, textBlockAnchor25, (float) (short) 1, (float) 10L, 100.0d);
        textBlock6.draw(graphics2D11, (float) 6, (float) 9, textBlockAnchor25);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(textBlock20);
        org.junit.Assert.assertNull(textLine21);
        org.junit.Assert.assertNotNull(textBlockAnchor25);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        lineAndShapeRenderer2.setAutoPopulateSeriesOutlineStroke(false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        double[][] doubleArray4 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("-4,-4,4,4", "", doubleArray4);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) categoryDataset5, (java.lang.Comparable) 9999);
        legendItemBlockContainer7.setURLText("�");
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        java.awt.Stroke stroke51 = ringPlot50.getBaseSectionOutlineStroke();
        java.awt.Paint paint52 = ringPlot50.getLabelShadowPaint();
        ringPlot50.setLabelLinksVisible(true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint52);
    }

//    @Test
//    public void test144() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test144");
//        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
//        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
//        java.util.EventListener eventListener2 = null;
//        boolean boolean3 = categoryAxis1.hasListener(eventListener2);
//        categoryAxis1.setFixedDimension((double) (short) -1);
//        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) '4');
//        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
//        categoryAxis1.configure();
//        boolean boolean10 = month0.equals((java.lang.Object) categoryAxis1);
//        long long11 = month0.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
//        org.junit.Assert.assertNotNull(font7);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560668399999L + "'", long11 == 1560668399999L);
//    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setName("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setName("TextBlockAnchor.CENTER_LEFT");
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
        basicProjectInfo3.setInfo("ERROR : Relative To String");
        java.lang.String str9 = basicProjectInfo3.getCopyright();
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        int int0 = org.jfree.data.time.SerialDate.SUNDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint2 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (float) '#', (int) (byte) -1, textMeasurer5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textBlock6.getLineAlignment();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = textBlock6.calculateDimensions(graphics2D8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.data.general.Dataset dataset11 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent12 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) lineAndShapeRenderer10, dataset11);
        boolean boolean13 = size2D9.equals((java.lang.Object) lineAndShapeRenderer10);
        double double14 = size2D9.getWidth();
        double double15 = size2D9.getWidth();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setName("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.LegendItemCollection legendItemCollection3 = new org.jfree.chart.LegendItemCollection();
        boolean boolean4 = basicProjectInfo0.equals((java.lang.Object) legendItemCollection3);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.data.general.Dataset dataset6 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent7 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) lineAndShapeRenderer5, dataset6);
        java.lang.Object obj8 = datasetChangeEvent7.getSource();
        boolean boolean9 = legendItemCollection3.equals((java.lang.Object) datasetChangeEvent7);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(obj8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        java.awt.Paint paint16 = null;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape4, stroke13, paint16);
        int int18 = legendItem17.getDatasetIndex();
        legendItem17.setDatasetIndex((int) (short) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        int int23 = defaultCategoryDataset21.getRowIndex((java.lang.Comparable) 2.0d);
        legendItem17.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset21);
        int int25 = defaultCategoryDataset21.getColumnCount();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot7.getDomainAxisEdge();
        xYPlot7.setRangeCrosshairValue((double) (short) 10, false);
        org.junit.Assert.assertNotNull(rectangleEdge8);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) ' ', 100);
        boolean boolean7 = lineAndShapeRenderer2.isSeriesVisible((int) ' ');
        java.awt.Paint paint8 = lineAndShapeRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=]", font1, paint8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = labelBlock9.getMargin();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        labelBlock9.setPaint((java.awt.Paint) color11);
        java.lang.Object obj13 = labelBlock9.clone();
        java.lang.String str14 = labelBlock9.getURLText();
        double double15 = labelBlock9.getContentYOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color1 = java.awt.Color.BLACK;
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color1, false);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        double double2 = blockParams0.getTranslateX();
        blockParams0.setTranslateY((double) ' ');
        boolean boolean5 = blockParams0.getGenerateEntities();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] { valueAxis23 };
        categoryPlot22.setRangeAxes(valueAxisArray24);
        categoryPlot22.setDrawSharedDomainAxis(false);
        java.awt.Font font28 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean29 = categoryPlot22.equals((java.lang.Object) font28);
        categoryPlot22.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D33.setVerticalTickLabels(true);
        org.jfree.data.Range range36 = categoryPlot22.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D33);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer37 = null;
        org.jfree.chart.plot.PolarPlot polarPlot38 = new org.jfree.chart.plot.PolarPlot(xYDataset2, (org.jfree.chart.axis.ValueAxis) numberAxis3D33, polarItemRenderer37);
        org.jfree.data.xy.XYDataset xYDataset39 = polarPlot38.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis40 = polarPlot38.getAxis();
        java.awt.Color color43 = java.awt.Color.getColor("ERROR : Relative To String", 7);
        polarPlot38.setRadiusGridlinePaint((java.awt.Paint) color43);
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) polarPlot38);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(valueAxisArray24);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(range36);
        org.junit.Assert.assertNull(xYDataset39);
        org.junit.Assert.assertNotNull(valueAxis40);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        org.jfree.data.xy.XYDataset xYDataset37 = polarPlot36.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis38 = polarPlot36.getAxis();
        polarPlot36.setRadiusGridlinesVisible(true);
        double double41 = polarPlot36.getMaxRadius();
        org.jfree.chart.axis.ValueAxis valueAxis42 = polarPlot36.getAxis();
        valueAxis42.setNegativeArrowVisible(true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNull(xYDataset37);
        org.junit.Assert.assertNotNull(valueAxis38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.05d + "'", double41 == 1.05d);
        org.junit.Assert.assertNotNull(valueAxis42);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        org.jfree.data.xy.XYDataset xYDataset37 = polarPlot36.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis38 = polarPlot36.getAxis();
        polarPlot36.setRadiusGridlinesVisible(true);
        double double41 = polarPlot36.getMaxRadius();
        org.jfree.chart.axis.ValueAxis valueAxis42 = polarPlot36.getAxis();
        java.awt.Stroke stroke43 = polarPlot36.getRadiusGridlineStroke();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNull(xYDataset37);
        org.junit.Assert.assertNotNull(valueAxis38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.05d + "'", double41 == 1.05d);
        org.junit.Assert.assertNotNull(valueAxis42);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot19.getRenderer();
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot19.getRangeAxisLocation((int) (short) -1);
        java.lang.String str32 = axisLocation31.toString();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(categoryItemRenderer29);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "AxisLocation.BOTTOM_OR_RIGHT" + "'", str32.equals("AxisLocation.BOTTOM_OR_RIGHT"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setTickMarkInsideLength((float) 100L);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) ' ');
        int int7 = categoryAxis0.getCategoryLabelPositionOffset();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer11.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint16 = lineAndShapeRenderer11.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = lineAndShapeRenderer11.getPlot();
        java.awt.Color color22 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer11.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color22, true);
        boolean boolean25 = lineAndShapeRenderer11.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = lineAndShapeRenderer11.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot27.setRangeAxes(valueAxisArray29);
        categoryPlot27.clearRangeMarkers();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot27);
        java.lang.String str33 = categoryPlot27.getPlotType();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(categoryPlot17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Category Plot" + "'", str33.equals("Category Plot"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate6 = serialDate1.getEndOfCurrentMonth(serialDate5);
        org.jfree.data.time.SerialDate serialDate8 = serialDate1.getNearestDayOfWeek((int) (short) 1);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        java.awt.Stroke stroke51 = ringPlot50.getBaseSectionOutlineStroke();
        ringPlot50.setPieIndex(3);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator54 = ringPlot50.getLegendLabelURLGenerator();
        java.awt.Paint paint55 = ringPlot50.getLabelBackgroundPaint();
        double double56 = ringPlot50.getOuterSeparatorExtension();
        double double57 = ringPlot50.getShadowYOffset();
        org.jfree.chart.plot.Plot plot58 = ringPlot50.getParent();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNull(pieURLGenerator54);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.2d + "'", double56 == 0.2d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 4.0d + "'", double57 == 4.0d);
        org.junit.Assert.assertNull(plot58);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 100);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D3.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis6, xYItemRenderer7);
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot8.setOrientation(plotOrientation9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot8.getRendererForDataset(xYDataset11);
        boolean boolean13 = categoryLabelPositions0.equals((java.lang.Object) xYItemRenderer12);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        java.awt.Color color0 = java.awt.Color.magenta;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.data.Range range26 = categoryPlot19.getDataRange(valueAxis25);
        org.jfree.chart.plot.Plot plot27 = categoryPlot19.getRootPlot();
        boolean boolean28 = categoryPlot19.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot19.getRangeAxisEdge();
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = categoryPlot19.getDomainMarkers(layer30);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor32 = null;
        try {
            categoryPlot19.setDomainGridlinePosition(categoryAnchor32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNull(collection31);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        double double3 = rectangleInsets1.trimHeight((double) 10);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.0d + "'", double3 == 6.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        lineAndShapeRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator1);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getBaseOutlineStroke();
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color8 = java.awt.Color.magenta;
        valueMarker7.setOutlinePaint((java.awt.Paint) color8);
        lineAndShapeRenderer0.setSeriesPaint(9999, (java.awt.Paint) color8);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = lineAndShapeRenderer0.getToolTipGenerator(5, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (-1));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) 100);
        double double6 = rectangleConstraint2.getWidth();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        int int1 = booleanList0.size();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline5 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = lineAndShapeRenderer9.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint14 = lineAndShapeRenderer9.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = lineAndShapeRenderer9.getPlot();
        java.awt.Color color20 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer9.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color20, true);
        boolean boolean23 = lineAndShapeRenderer9.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier24 = lineAndShapeRenderer9.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer29 = null;
        categoryPlot25.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker28, layer29);
        java.awt.Paint paint31 = categoryPlot25.getBackgroundPaint();
        boolean boolean32 = segmentedTimeline5.equals((java.lang.Object) categoryPlot25);
        java.awt.Font font34 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint35 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer38 = null;
        org.jfree.chart.text.TextBlock textBlock39 = org.jfree.chart.text.TextUtilities.createTextBlock("", font34, paint35, (float) '#', (int) (byte) -1, textMeasurer38);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment40 = textBlock39.getLineAlignment();
        java.awt.Graphics2D graphics2D41 = null;
        org.jfree.chart.util.Size2D size2D42 = textBlock39.calculateDimensions(graphics2D41);
        boolean boolean43 = categoryPlot25.equals((java.lang.Object) size2D42);
        java.lang.String str44 = categoryPlot25.getPlotType();
        boolean boolean45 = categoryPlot25.isRangeGridlinesVisible();
        java.util.List list46 = categoryPlot25.getAnnotations();
        boolean boolean47 = booleanList0.equals((java.lang.Object) list46);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryPlot15);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(drawingSupplier24);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(textBlock39);
        org.junit.Assert.assertNotNull(horizontalAlignment40);
        org.junit.Assert.assertNotNull(size2D42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Category Plot" + "'", str44.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(list46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot19.markerChanged(markerChangeEvent28);
        org.jfree.chart.plot.Plot plot30 = categoryPlot19.getRootPlot();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot19.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(plot30);
        org.junit.Assert.assertNotNull(rectangleEdge31);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.awt.Color color4 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        org.jfree.data.KeyedObject keyedObject5 = new org.jfree.data.KeyedObject((java.lang.Comparable) 0.5f, (java.lang.Object) 'a');
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, 0.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setFixedDimension((double) (short) -1);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        boolean boolean8 = categoryAxis0.isAxisLineVisible();
        org.jfree.data.time.SerialDate serialDate10 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate12 = serialDate10.getFollowingDayOfWeek((int) (byte) 1);
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) serialDate10, (java.awt.Paint) color13);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint2 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (float) '#', (int) (byte) -1, textMeasurer5);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D7 = new org.jfree.chart.axis.NumberAxis3D();
        boolean boolean8 = textBlock6.equals((java.lang.Object) numberAxis3D7);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Color color16 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer5.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color16, true);
        boolean boolean19 = lineAndShapeRenderer5.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = lineAndShapeRenderer5.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer5);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer25 = null;
        categoryPlot21.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker24, layer25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot21.getRangeAxisEdge(10);
        axisState0.moveCursor((double) 2, rectangleEdge28);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D0 = new org.jfree.chart.axis.CategoryAxis3D();
        java.lang.Object obj1 = categoryAxis3D0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        org.jfree.chart.plot.ValueMarker valueMarker18 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color19 = java.awt.Color.magenta;
        valueMarker18.setOutlinePaint((java.awt.Paint) color19);
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color19, true);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) ' ', 100);
        boolean boolean7 = lineAndShapeRenderer2.isSeriesVisible((int) ' ');
        java.awt.Paint paint8 = lineAndShapeRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=]", font1, paint8);
        labelBlock9.setWidth((double) (byte) -1);
        labelBlock9.setURLText("-4,-4,4,4");
        double double14 = labelBlock9.getHeight();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.addDays(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        java.awt.Paint paint2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        java.awt.Font font5 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint6 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer9 = null;
        org.jfree.chart.text.TextBlock textBlock10 = org.jfree.chart.text.TextUtilities.createTextBlock("", font5, paint6, (float) '#', (int) (byte) -1, textMeasurer9);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textBlock10.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineAndShapeRenderer16.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint21 = lineAndShapeRenderer16.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = lineAndShapeRenderer16.getPlot();
        java.awt.Color color27 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer16.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color27, true);
        boolean boolean30 = lineAndShapeRenderer16.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier31 = lineAndShapeRenderer16.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer16);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] { valueAxis33 };
        categoryPlot32.setRangeAxes(valueAxisArray34);
        categoryPlot32.setDrawSharedDomainAxis(false);
        java.awt.Font font38 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean39 = categoryPlot32.equals((java.lang.Object) font38);
        categoryPlot32.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D43 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D43.setVerticalTickLabels(true);
        org.jfree.data.Range range46 = categoryPlot32.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D43);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = categoryPlot32.getInsets();
        double double49 = rectangleInsets47.calculateTopOutset((double) (short) 0);
        try {
            org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle("RectangleEdge.LEFT", font1, paint2, rectangleEdge3, horizontalAlignment11, verticalAlignment12, rectangleInsets47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'verticalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlock10);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(categoryPlot22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(drawingSupplier31);
        org.junit.Assert.assertNotNull(valueAxisArray34);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(range46);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 4.0d + "'", double49 == 4.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = stackedAreaRenderer1.getSeriesNegativeItemLabelPosition(8);
        int int4 = stackedAreaRenderer1.getPassCount();
        int int5 = stackedAreaRenderer1.getPassCount();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int2 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) 15);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        java.lang.Object obj4 = segmentedTimeline3.clone();
        boolean boolean5 = segmentedTimeline3.getAdjustForDaylightSaving();
        try {
            long long7 = segmentedTimeline3.toTimelineValue((long) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D30.setVerticalTickLabels(true);
        org.jfree.data.Range range33 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryPlot19.getInsets();
        double double36 = rectangleInsets34.trimWidth(0.0d);
        org.jfree.chart.util.UnitType unitType37 = rectangleInsets34.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = new org.jfree.chart.util.RectangleInsets(unitType37, (double) 100.0f, (double) 1559372400000L, (double) (short) -1, (double) (byte) 10);
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        try {
            rectangleInsets42.trim(rectangle2D43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-16.0d) + "'", double36 == (-16.0d));
        org.junit.Assert.assertNotNull(unitType37);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D30.setVerticalTickLabels(true);
        org.jfree.data.Range range33 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        numberAxis3D30.setAutoRange(false);
        org.jfree.data.Range range36 = null;
        org.jfree.data.Range range38 = org.jfree.data.Range.expandToInclude(range36, (double) 100L);
        org.jfree.data.Range range41 = org.jfree.data.Range.shift(range38, (double) 60000L, true);
        numberAxis3D30.setRange(range41, true, true);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(range41);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot1 = new org.jfree.chart.plot.MultiplePiePlot(categoryDataset0);
        java.lang.String str2 = multiplePiePlot1.getPlotType();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Multiple Pie Plot" + "'", str2.equals("Multiple Pie Plot"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        try {
            java.lang.Number number6 = taskSeriesCollection0.getEndValue(7, 11, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        try {
            java.lang.String str2 = dataPackageResources0.getString("org.jfree.chart.event.ChartChangeEvent[source=]");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.data.resources.DataPackageResources, key org.jfree.chart.event.ChartChangeEvent[source=]");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Paint paint19 = lineAndShapeRenderer0.getItemLabelPaint(0, 10);
        org.jfree.chart.LegendItemCollection legendItemCollection20 = lineAndShapeRenderer0.getLegendItems();
        lineAndShapeRenderer0.setSeriesCreateEntities(2, (java.lang.Boolean) false, false);
        boolean boolean27 = lineAndShapeRenderer0.getItemLineVisible(5, 255);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(legendItemCollection20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        org.jfree.data.time.SerialDate serialDate5 = serialDate3.getFollowingDayOfWeek((int) (byte) 1);
        org.jfree.data.time.SerialDate serialDate6 = serialDate1.getEndOfCurrentMonth(serialDate5);
        try {
            org.jfree.data.time.SerialDate serialDate8 = serialDate5.getNearestDayOfWeek(11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertNotNull(serialDate6);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) year0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        rendererChangeEvent1.setType(chartChangeEventType2);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        org.jfree.chart.axis.AxisSpace axisSpace26 = categoryPlot19.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNull(axisSpace26);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.resources.DataPackageResources dataPackageResources0 = new org.jfree.data.resources.DataPackageResources();
        boolean boolean2 = dataPackageResources0.containsKey("");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean2 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot22.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.Range range29 = categoryPlot22.getDataRange(valueAxis28);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = categoryPlot22.getDatasetRenderingOrder();
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = categoryPlot22.getRangeMarkers(layer32);
        try {
            categoryPlot22.zoom((double) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNull(collection33);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        java.awt.Paint paint51 = ringPlot50.getLabelBackgroundPaint();
        org.jfree.chart.plot.AbstractPieLabelDistributor abstractPieLabelDistributor52 = null;
        try {
            ringPlot50.setLabelDistributor(abstractPieLabelDistributor52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'distributor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(paint51);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getRGBColorComponents(floatArray1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range2 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener3 = null;
        defaultCategoryDataset1.addChangeListener(datasetChangeListener3);
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        org.junit.Assert.assertNull(range2);
        org.junit.Assert.assertNull(number5);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test204");
//        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
//        int int3 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) "");
//        org.jfree.data.KeyToGroupMap keyToGroupMap5 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
//        int int7 = keyToGroupMap5.getGroupIndex((java.lang.Comparable) "");
//        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
//        keyToGroupMap5.mapKeyToGroup((java.lang.Comparable) 8, (java.lang.Comparable) dateTickUnit9);
//        java.lang.String str11 = dateTickUnit9.toString();
//        int int12 = keyToGroupMap1.getKeyCount((java.lang.Comparable) dateTickUnit9);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
//        java.lang.String str14 = month13.toString();
//        java.util.Date date15 = month13.getEnd();
//        java.util.Date date16 = dateTickUnit9.addToDate(date15);
//        org.jfree.chart.text.TextAnchor textAnchor18 = null;
//        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor19 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
//        org.jfree.chart.text.TextAnchor textAnchor20 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor19, textAnchor20);
//        org.jfree.chart.text.TextAnchor textAnchor22 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
//        boolean boolean23 = itemLabelPosition21.equals((java.lang.Object) textAnchor22);
//        try {
//            org.jfree.chart.axis.DateTick dateTick25 = new org.jfree.chart.axis.DateTick(date16, "", textAnchor18, textAnchor22, (double) 10L);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
//        org.junit.Assert.assertNotNull(dateTickUnit9);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str11.equals("DateTickUnit[DAY, 1]"));
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
//        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "June 2019" + "'", str14.equals("June 2019"));
//        org.junit.Assert.assertNotNull(date15);
//        org.junit.Assert.assertNotNull(date16);
//        org.junit.Assert.assertNotNull(itemLabelAnchor19);
//        org.junit.Assert.assertNotNull(textAnchor20);
//        org.junit.Assert.assertNotNull(textAnchor22);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str1 = verticalAlignment0.toString();
        java.lang.String str2 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str1.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str2.equals("VerticalAlignment.BOTTOM"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot7.setDomainAxisLocation((int) '4', axisLocation9);
        org.jfree.chart.plot.ValueMarker valueMarker13 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color14 = java.awt.Color.magenta;
        valueMarker13.setOutlinePaint((java.awt.Paint) color14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = valueMarker13.getLabelOffset();
        org.jfree.chart.util.Layer layer17 = null;
        xYPlot7.addRangeMarker(6, (org.jfree.chart.plot.Marker) valueMarker13, layer17);
        java.awt.geom.Point2D point2D19 = null;
        try {
            xYPlot7.setQuadrantOrigin(point2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(rectangleInsets16);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        levelRenderer0.setItemMargin((double) ' ');
        java.lang.Boolean boolean4 = levelRenderer0.getSeriesItemLabelsVisible(3);
        double double5 = levelRenderer0.getItemMargin();
        org.junit.Assert.assertNull(boolean4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 32.0d + "'", double5 == 32.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Stroke stroke2 = levelRenderer0.lookupSeriesOutlineStroke(9);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = levelRenderer0.getBaseItemLabelGenerator();
        boolean boolean4 = levelRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean3 = numberAxis3D2.getAutoRangeIncludesZero();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle7.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle7.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer14.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint19 = lineAndShapeRenderer14.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = lineAndShapeRenderer14.getPlot();
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer14.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color25, true);
        boolean boolean28 = lineAndShapeRenderer14.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = lineAndShapeRenderer14.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { valueAxis31 };
        categoryPlot30.setRangeAxes(valueAxisArray32);
        categoryPlot30.setDrawSharedDomainAxis(false);
        boolean boolean36 = categoryPlot30.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot30.getRangeAxisEdge();
        double double38 = dateAxis4.valueToJava2D(0.0d, rectangle2D10, rectangleEdge37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer39);
        java.awt.Stroke stroke41 = xYPlot40.getDomainCrosshairStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryPlot20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("hi!");
        textTitle1.setWidth((double) (byte) 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        numberAxis3D2.setRange((double) 0.0f, (double) 10L);
        java.awt.Shape shape15 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineAndShapeRenderer16.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint21 = lineAndShapeRenderer16.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = lineAndShapeRenderer16.getPlot();
        java.awt.Stroke stroke24 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer16.setSeriesStroke((int) (byte) 1, stroke24, true);
        java.awt.Paint paint27 = null;
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape15, stroke24, paint27);
        int int29 = legendItem28.getDatasetIndex();
        java.awt.Shape shape30 = legendItem28.getLine();
        numberAxis3D2.setDownArrow(shape30);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(categoryPlot22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(shape30);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (byte) 10, (double) (short) 10);
        org.jfree.data.Range range4 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        dateAxis0.setRange(range4, true, false);
        try {
            dateAxis0.zoomRange((double) 4, (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (4.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setTickMarkInsideLength((float) 100L);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) ' ');
        int int7 = categoryAxis0.getCategoryLabelPositionOffset();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer11.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint16 = lineAndShapeRenderer11.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = lineAndShapeRenderer11.getPlot();
        java.awt.Color color22 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer11.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color22, true);
        boolean boolean25 = lineAndShapeRenderer11.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = lineAndShapeRenderer11.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot27.setRangeAxes(valueAxisArray29);
        categoryPlot27.clearRangeMarkers();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot27);
        categoryAxis0.setTickLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(categoryPlot17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(valueAxisArray29);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle4.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle4.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer11.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint16 = lineAndShapeRenderer11.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = lineAndShapeRenderer11.getPlot();
        java.awt.Color color22 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer11.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color22, true);
        boolean boolean25 = lineAndShapeRenderer11.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = lineAndShapeRenderer11.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot27.setRangeAxes(valueAxisArray29);
        categoryPlot27.setDrawSharedDomainAxis(false);
        boolean boolean33 = categoryPlot27.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot27.getRangeAxisEdge();
        double double35 = dateAxis1.valueToJava2D(0.0d, rectangle2D7, rectangleEdge34);
        java.util.Date date36 = dateAxis1.getMinimumDate();
        java.lang.Number number38 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) date36, (java.lang.Comparable) "Polar Plot");
        java.lang.Number number41 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) Double.NaN, (java.lang.Comparable) "ThreadContext");
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(categoryPlot17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertNull(number38);
        org.junit.Assert.assertNull(number41);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        polarPlot36.removeCornerTextItem("ERROR : Relative To String");
        polarPlot36.clearCornerTextItems();
        boolean boolean40 = polarPlot36.isRadiusGridlinesVisible();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.general.WaferMapDataset waferMapDataset2 = waferMapPlot1.getDataset();
        java.lang.String str3 = waferMapPlot1.getPlotType();
        org.jfree.chart.renderer.WaferMapRenderer waferMapRenderer4 = null;
        waferMapPlot1.setRenderer(waferMapRenderer4);
        org.junit.Assert.assertNull(waferMapDataset2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "WMAP_Plot" + "'", str3.equals("WMAP_Plot"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.util.ShapeList shapeList1 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape3 = null;
        shapeList1.setShape((int) (byte) 10, shape3);
        boolean boolean5 = rectangleAnchor0.equals((java.lang.Object) shape3);
        java.lang.String str6 = rectangleAnchor0.toString();
        java.awt.Font font8 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint9 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font8, paint9, (float) '#', (int) (byte) -1, textMeasurer12);
        org.jfree.chart.text.TextLine textLine14 = textBlock13.getLastLine();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        java.awt.Shape shape22 = textBlock13.calculateBounds(graphics2D15, (float) 10L, (float) 4, textBlockAnchor18, (float) (short) 1, (float) 10L, 100.0d);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType23 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition25 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor18, categoryLabelWidthType23, (float) 100);
        org.jfree.data.category.CategoryDataset categoryDataset26 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer29.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint34 = lineAndShapeRenderer29.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = lineAndShapeRenderer29.getPlot();
        java.awt.Color color40 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer29.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color40, true);
        boolean boolean43 = lineAndShapeRenderer29.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier44 = lineAndShapeRenderer29.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot(categoryDataset26, categoryAxis27, valueAxis28, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer29);
        org.jfree.chart.plot.ValueMarker valueMarker48 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer49 = null;
        categoryPlot45.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker48, layer49);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot45.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart53 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot45);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent54 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot45);
        org.jfree.chart.LegendItemCollection legendItemCollection55 = new org.jfree.chart.LegendItemCollection();
        categoryPlot45.setFixedLegendItems(legendItemCollection55);
        boolean boolean57 = categoryLabelPosition25.equals((java.lang.Object) legendItemCollection55);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str6.equals("RectangleAnchor.BOTTOM_LEFT"));
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(textBlock13);
        org.junit.Assert.assertNull(textLine14);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(categoryLabelWidthType23);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNull(categoryPlot35);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(drawingSupplier44);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        java.awt.Stroke stroke51 = ringPlot50.getBaseSectionOutlineStroke();
        ringPlot50.setPieIndex(3);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator54 = ringPlot50.getLegendLabelURLGenerator();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator55 = null;
        ringPlot50.setLegendLabelURLGenerator(pieURLGenerator55);
        java.awt.Stroke stroke57 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_STROKE;
        ringPlot50.setSeparatorStroke(stroke57);
        org.jfree.chart.util.Rotation rotation59 = null;
        try {
            ringPlot50.setDirection(rotation59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'direction' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNull(pieURLGenerator54);
        org.junit.Assert.assertNotNull(stroke57);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot19.getLegendItems();
        int int27 = categoryPlot19.getDatasetCount();
        int int28 = categoryPlot19.getDatasetCount();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot19.getDomainAxisLocation();
        categoryPlot19.setRangeCrosshairVisible(false);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset26 = new org.jfree.data.category.DefaultCategoryDataset();
        categoryPlot19.setDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset26);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(axisLocation23);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorDown((-1.0d));
        java.lang.Number number6 = null;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list13 = defaultKeyedValues2D12.getRowKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem14 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 3.0d, (java.lang.Number) (-1.0f), (java.lang.Number) (short) 100, number6, (java.lang.Number) (-1.0f), (java.lang.Number) 4.0d, (java.lang.Number) 8.0d, (java.lang.Number) 1.0f, list13);
        axisState0.setTicks(list13);
        axisState0.cursorRight((double) 5);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener21 = null;
        boolean boolean22 = categoryAxis20.hasListener(eventListener21);
        categoryAxis20.setTickMarkInsideLength((float) 100L);
        java.awt.Font font26 = categoryAxis20.getTickLabelFont((java.lang.Comparable) ' ');
        java.awt.Paint paint27 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = lineAndShapeRenderer31.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint36 = lineAndShapeRenderer31.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = lineAndShapeRenderer31.getPlot();
        java.awt.Color color42 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer31.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color42, true);
        boolean boolean45 = lineAndShapeRenderer31.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier46 = lineAndShapeRenderer31.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer31);
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer51 = null;
        categoryPlot47.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker50, layer51);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot47.getRangeAxisEdge(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = categoryPlot47.getDomainAxisEdge();
        java.awt.Font font57 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint58 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer61 = null;
        org.jfree.chart.text.TextBlock textBlock62 = org.jfree.chart.text.TextUtilities.createTextBlock("", font57, paint58, (float) '#', (int) (byte) -1, textMeasurer61);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment63 = textBlock62.getLineAlignment();
        java.awt.Graphics2D graphics2D64 = null;
        org.jfree.chart.util.Size2D size2D65 = textBlock62.calculateDimensions(graphics2D64);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment66 = textBlock62.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment67 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str68 = verticalAlignment67.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets69 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle70 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font26, paint27, rectangleEdge55, horizontalAlignment66, verticalAlignment67, rectangleInsets69);
        axisState0.moveCursor((double) (-1), rectangleEdge55);
        double double72 = axisState0.getMax();
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(categoryPlot37);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(drawingSupplier46);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(textBlock62);
        org.junit.Assert.assertNotNull(horizontalAlignment63);
        org.junit.Assert.assertNotNull(size2D65);
        org.junit.Assert.assertNotNull(horizontalAlignment66);
        org.junit.Assert.assertNotNull(verticalAlignment67);
        org.junit.Assert.assertTrue("'" + str68 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str68.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertNotNull(rectangleInsets69);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot19.getRenderer();
        org.jfree.chart.axis.AxisSpace axisSpace30 = new org.jfree.chart.axis.AxisSpace();
        axisSpace30.setRight((double) 100L);
        categoryPlot19.setFixedRangeAxisSpace(axisSpace30);
        try {
            categoryPlot19.zoom(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(categoryItemRenderer29);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        double double2 = layeredBarRenderer0.getSeriesBarWidth((int) 'a');
        boolean boolean5 = layeredBarRenderer0.getItemVisible(4, 15);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot7.setOrientation(plotOrientation8);
        xYPlot7.clearDomainAxes();
        boolean boolean11 = xYPlot7.isDomainGridlinesVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = lineAndShapeRenderer20.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint25 = lineAndShapeRenderer20.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = lineAndShapeRenderer20.getPlot();
        java.awt.Color color31 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer20.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color31, true);
        boolean boolean34 = lineAndShapeRenderer20.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier35 = lineAndShapeRenderer20.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray38 = new org.jfree.chart.axis.ValueAxis[] { valueAxis37 };
        categoryPlot36.setRangeAxes(valueAxisArray38);
        categoryPlot36.setDrawSharedDomainAxis(false);
        java.awt.Font font42 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean43 = categoryPlot36.equals((java.lang.Object) font42);
        categoryPlot36.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D47.setVerticalTickLabels(true);
        org.jfree.data.Range range50 = categoryPlot36.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D47);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = categoryPlot36.getInsets();
        double double53 = rectangleInsets51.trimWidth(0.0d);
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle55.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D58 = textTitle55.getBounds();
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets51.createOutsetRectangle(rectangle2D58);
        java.awt.geom.Point2D point2D60 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 10, 0.2d, rectangle2D58);
        xYPlot7.zoomRangeAxes(Double.NaN, plotRenderingInfo14, point2D60);
        java.awt.geom.Point2D point2D62 = xYPlot7.getQuadrantOrigin();
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryPlot26);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(drawingSupplier35);
        org.junit.Assert.assertNotNull(valueAxisArray38);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + (-16.0d) + "'", double53 == (-16.0d));
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(point2D60);
        org.junit.Assert.assertNotNull(point2D62);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        boolean boolean24 = textAnchor0.equals((java.lang.Object) valueAxisArray22);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot0 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = multiplePiePlot0.getLegendItems();
        java.awt.Paint paint2 = multiplePiePlot0.getAggregatedItemsPaint();
        org.jfree.chart.axis.DateTickUnit dateTickUnit3 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int4 = dateTickUnit3.getCalendarField();
        int int5 = dateTickUnit3.getCalendarField();
        int int6 = dateTickUnit3.getUnit();
        multiplePiePlot0.setAggregatedItemsKey((java.lang.Comparable) int6);
        org.junit.Assert.assertNotNull(legendItemCollection1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(dateTickUnit3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 5 + "'", int4 == 5);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean1 = barRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Color color16 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer5.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color16, true);
        boolean boolean19 = lineAndShapeRenderer5.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = lineAndShapeRenderer5.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer5);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer25 = null;
        categoryPlot21.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker24, layer25);
        boolean boolean27 = categoryPlot21.isRangeZoomable();
        boolean boolean28 = barRenderer3D0.equals((java.lang.Object) boolean27);
        double double29 = barRenderer3D0.getItemMargin();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(drawingSupplier20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.2d + "'", double29 == 0.2d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot19.markerChanged(markerChangeEvent28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        float float31 = jFreeChart30.getBackgroundImageAlpha();
        org.jfree.chart.title.Title title33 = jFreeChart30.getSubtitle(0);
        jFreeChart30.setNotify(true);
        org.jfree.chart.plot.Plot plot36 = jFreeChart30.getPlot();
        org.jfree.chart.event.ChartChangeListener chartChangeListener37 = null;
        try {
            jFreeChart30.removeChangeListener(chartChangeListener37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.5f + "'", float31 == 0.5f);
        org.junit.Assert.assertNotNull(title33);
        org.junit.Assert.assertNotNull(plot36);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        java.awt.Paint paint16 = null;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape4, stroke13, paint16);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity20 = new org.jfree.chart.entity.TickLabelEntity(shape4, "({0}, {1}) = {3} - {4}", "org.jfree.chart.event.ChartChangeEvent[source=]");
        java.lang.String str21 = tickLabelEntity20.toString();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "ChartEntity: tooltip = ({0}, {1}) = {3} - {4}" + "'", str21.equals("ChartEntity: tooltip = ({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) lineAndShapeRenderer0, dataset1);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true, true);
        boolean boolean8 = lineAndShapeRenderer0.isItemLabelVisible((int) (byte) 100, 1900);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        int int2 = taskSeriesCollection0.getSeriesCount();
        int int3 = taskSeriesCollection0.getRowCount();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        int int3 = defaultKeyedValues2D1.getRowCount();
        try {
            java.lang.Comparable comparable5 = defaultKeyedValues2D1.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color2 = java.awt.Color.magenta;
        valueMarker1.setOutlinePaint((java.awt.Paint) color2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int5 = color4.getGreen();
        valueMarker1.setOutlinePaint((java.awt.Paint) color4);
        java.awt.Color color7 = java.awt.Color.magenta;
        valueMarker1.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener11 = null;
        boolean boolean12 = categoryAxis10.hasListener(eventListener11);
        categoryAxis10.setTickMarkInsideLength((float) 100L);
        java.awt.Font font16 = categoryAxis10.getTickLabelFont((java.lang.Comparable) ' ');
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.CENTER_LEFT", font16);
        valueMarker1.setLabelFont(font16);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType19 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        valueMarker1.setLabelOffsetType(lengthAdjustmentType19);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(lengthAdjustmentType19);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis1.hasListener(eventListener2);
        categoryAxis1.setTickMarkInsideLength((float) 100L);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) ' ');
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.CENTER_LEFT", font7);
        java.lang.String str9 = textFragment8.getText();
        java.awt.Graphics2D graphics2D10 = null;
        try {
            org.jfree.chart.util.Size2D size2D11 = textFragment8.calculateDimensions(graphics2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str9.equals("TextBlockAnchor.CENTER_LEFT"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        java.util.List list4 = defaultCategoryDataset0.getRowKeys();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D6 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int10 = dateTickUnit9.getCalendarField();
        int int11 = dateTickUnit9.getCalendarField();
        defaultKeyedValues2D6.setValue((java.lang.Number) (byte) 0, (java.lang.Comparable) 0L, (java.lang.Comparable) int11);
        boolean boolean13 = defaultCategoryDataset0.equals((java.lang.Object) defaultKeyedValues2D6);
        try {
            java.lang.Comparable comparable15 = defaultKeyedValues2D6.getColumnKey((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.axis.DateTickUnit dateTickUnit0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int1 = dateTickUnit0.getCalendarField();
        java.lang.String str3 = dateTickUnit0.valueToString((double) 1560668399999L);
        org.junit.Assert.assertNotNull(dateTickUnit0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "6/15/19 11:59 PM" + "'", str3.equals("6/15/19 11:59 PM"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setXOffset((double) 86400000L);
        java.lang.Number number4 = null;
        java.lang.Number number6 = null;
        java.lang.Number number10 = null;
        java.util.List list11 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem12 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 3, number4, (java.lang.Number) 10, number6, (java.lang.Number) 12.0d, (java.lang.Number) 10.0f, (java.lang.Number) (short) 1, number10, list11);
        java.lang.Number number13 = boxAndWhiskerItem12.getMinOutlier();
        boolean boolean14 = lineRenderer3D0.equals((java.lang.Object) boxAndWhiskerItem12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (short) 1 + "'", number13.equals((short) 1));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(4.0d, Double.NaN);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot22.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        float float28 = categoryPlot22.getBackgroundImageAlpha();
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot22.setDomainAxisLocation(axisLocation29, true);
        boolean boolean32 = stackedBarRenderer3D2.equals((java.lang.Object) true);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.5f + "'", float28 == 0.5f);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis1.hasListener(eventListener2);
        categoryAxis1.setTickMarkInsideLength((float) 100L);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) ' ');
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer12.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint17 = lineAndShapeRenderer12.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = lineAndShapeRenderer12.getPlot();
        java.awt.Color color23 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer12.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color23, true);
        boolean boolean26 = lineAndShapeRenderer12.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = lineAndShapeRenderer12.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer12);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer32 = null;
        categoryPlot28.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker31, layer32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot28.getRangeAxisEdge(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot28.getDomainAxisEdge();
        java.awt.Font font38 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint39 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer42 = null;
        org.jfree.chart.text.TextBlock textBlock43 = org.jfree.chart.text.TextUtilities.createTextBlock("", font38, paint39, (float) '#', (int) (byte) -1, textMeasurer42);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = textBlock43.getLineAlignment();
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.util.Size2D size2D46 = textBlock43.calculateDimensions(graphics2D45);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment47 = textBlock43.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str49 = verticalAlignment48.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font7, paint8, rectangleEdge36, horizontalAlignment47, verticalAlignment48, rectangleInsets50);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment52 = textTitle51.getTextAlignment();
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo53 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo53.setName("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo56 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo56.setName("TextBlockAnchor.CENTER_LEFT");
        basicProjectInfo53.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo56);
        basicProjectInfo56.setInfo("ERROR : Relative To String");
        org.jfree.chart.title.TextTitle textTitle63 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = textTitle63.getPosition();
        boolean boolean65 = basicProjectInfo56.equals((java.lang.Object) rectangleEdge64);
        textTitle51.setPosition(rectangleEdge64);
        textTitle51.setNotify(false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryPlot18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(drawingSupplier27);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(textBlock43);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(size2D46);
        org.junit.Assert.assertNotNull(horizontalAlignment47);
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str49.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(horizontalAlignment52);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        java.awt.Color color1 = java.awt.Color.BLUE;
        java.awt.Color color2 = java.awt.Color.getColor("WMAP_Plot", color1);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot3 = new org.jfree.chart.plot.MultiplePiePlot();
        org.jfree.chart.LegendItemCollection legendItemCollection4 = multiplePiePlot3.getLegendItems();
        java.awt.Paint paint5 = multiplePiePlot3.getAggregatedItemsPaint();
        java.awt.Paint paint6 = null;
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color9 = java.awt.Color.magenta;
        valueMarker8.setOutlinePaint((java.awt.Paint) color9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int12 = color11.getGreen();
        valueMarker8.setOutlinePaint((java.awt.Paint) color11);
        try {
            org.jfree.chart.renderer.category.WaterfallBarRenderer waterfallBarRenderer14 = new org.jfree.chart.renderer.category.WaterfallBarRenderer((java.awt.Paint) color2, paint5, paint6, (java.awt.Paint) color11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'negativeBarPaint' argument");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(legendItemCollection4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.awt.Color color4 = org.jfree.chart.util.PaintUtilities.stringToColor("");
        float[] floatArray11 = new float[] { 10, (-1.0f), 0.5f, 10.0f, 3, 9999 };
        float[] floatArray12 = color4.getRGBColorComponents(floatArray11);
        float[] floatArray13 = java.awt.Color.RGBtoHSB((int) (byte) 10, (int) (short) -1, (int) (short) 10, floatArray11);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot7.getDomainAxisEdge();
        boolean boolean9 = xYPlot7.isRangeZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer13.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint18 = lineAndShapeRenderer13.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = lineAndShapeRenderer13.getPlot();
        java.awt.Color color24 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer13.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color24, true);
        boolean boolean27 = lineAndShapeRenderer13.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = lineAndShapeRenderer13.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer13);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray31 = new org.jfree.chart.axis.ValueAxis[] { valueAxis30 };
        categoryPlot29.setRangeAxes(valueAxisArray31);
        xYPlot7.setRangeAxes(valueAxisArray31);
        java.awt.Paint paint34 = xYPlot7.getRangeCrosshairPaint();
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        xYPlot7.setDomainCrosshairPaint((java.awt.Paint) color35);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(categoryPlot19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(valueAxisArray31);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot7.getDomainAxisEdge();
        boolean boolean9 = xYPlot7.isRangeZoomable();
        xYPlot7.setDomainCrosshairValue(0.0d);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        xYPlot7.removeChangeListener(plotChangeListener12);
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer15 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        java.awt.Stroke stroke18 = stackedBarRenderer15.getItemStroke((int) (short) 10, 9);
        xYPlot7.setDomainZeroBaselineStroke(stroke18);
        java.awt.Stroke stroke20 = xYPlot7.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint7 = lineAndShapeRenderer2.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = lineAndShapeRenderer2.getPlot();
        java.awt.Color color13 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer2.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color13, true);
        boolean boolean16 = lineAndShapeRenderer2.getUseFillPaint();
        java.lang.Boolean boolean18 = lineAndShapeRenderer2.getSeriesShapesFilled(0);
        boolean boolean19 = axisSpace1.equals((java.lang.Object) lineAndShapeRenderer2);
        boolean boolean20 = blockBorder0.equals((java.lang.Object) lineAndShapeRenderer2);
        boolean boolean22 = lineAndShapeRenderer2.isSeriesItemLabelsVisible(0);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryPlot8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (-1));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint3 = rectangleConstraint2.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toFixedHeight((double) 100);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType6 = rectangleConstraint5.getWidthConstraintType();
        org.junit.Assert.assertNotNull(rectangleConstraint3);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
        org.junit.Assert.assertNotNull(lengthConstraintType6);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setFixedDimension((double) (short) -1);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) '4');
        int int7 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setMaximumCategoryLabelLines(0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = null;
        org.jfree.chart.block.BlockBorder blockBorder13 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = blockBorder13.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis15 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle18.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle18.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition28 = lineAndShapeRenderer25.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint30 = lineAndShapeRenderer25.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = lineAndShapeRenderer25.getPlot();
        java.awt.Color color36 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer25.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color36, true);
        boolean boolean39 = lineAndShapeRenderer25.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier40 = lineAndShapeRenderer25.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer25);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray43 = new org.jfree.chart.axis.ValueAxis[] { valueAxis42 };
        categoryPlot41.setRangeAxes(valueAxisArray43);
        categoryPlot41.setDrawSharedDomainAxis(false);
        boolean boolean47 = categoryPlot41.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot41.getRangeAxisEdge();
        double double49 = dateAxis15.valueToJava2D(0.0d, rectangle2D21, rectangleEdge48);
        java.awt.geom.Rectangle2D rectangle2D50 = rectangleInsets14.createOutsetRectangle(rectangle2D21);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str52 = rectangleEdge51.toString();
        double double53 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor10, (int) (byte) 10, 4, rectangle2D21, rectangleEdge51);
        org.jfree.chart.entity.ChartEntity chartEntity54 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(blockBorder13);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertNotNull(itemLabelPosition28);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(categoryPlot31);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(drawingSupplier40);
        org.junit.Assert.assertNotNull(valueAxisArray43);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleEdge.LEFT" + "'", str52.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) ' ', 100);
        boolean boolean7 = lineAndShapeRenderer2.isSeriesVisible((int) ' ');
        java.awt.Paint paint8 = lineAndShapeRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=]", font1, paint8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = labelBlock9.getMargin();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        labelBlock9.setPaint((java.awt.Paint) color11);
        java.lang.Object obj13 = labelBlock9.clone();
        java.lang.String str14 = labelBlock9.getURLText();
        labelBlock9.setToolTipText("TextAnchor.TOP_CENTER");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertNull(str14);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color2 = java.awt.Color.magenta;
        valueMarker1.setOutlinePaint((java.awt.Paint) color2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int5 = color4.getGreen();
        valueMarker1.setOutlinePaint((java.awt.Paint) color4);
        java.awt.Color color7 = java.awt.Color.magenta;
        valueMarker1.setLabelPaint((java.awt.Paint) color7);
        float float9 = valueMarker1.getAlpha();
        java.awt.Paint paint10 = valueMarker1.getOutlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer14.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint19 = lineAndShapeRenderer14.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = lineAndShapeRenderer14.getPlot();
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer14.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color25, true);
        boolean boolean28 = lineAndShapeRenderer14.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = lineAndShapeRenderer14.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { valueAxis31 };
        categoryPlot30.setRangeAxes(valueAxisArray32);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray34 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot30.setRenderers(categoryItemRendererArray34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double38 = rectangleInsets36.calculateLeftOutset((double) 100.0f);
        categoryPlot30.setInsets(rectangleInsets36);
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot30);
        org.jfree.chart.util.SortOrder sortOrder41 = categoryPlot30.getColumnRenderingOrder();
        categoryPlot30.clearRangeAxes();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.8f + "'", float9 == 0.8f);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryPlot20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertNotNull(categoryItemRendererArray34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 4.0d + "'", double38 == 4.0d);
        org.junit.Assert.assertNotNull(sortOrder41);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int5 = dateTickUnit4.getCalendarField();
        int int6 = dateTickUnit4.getCalendarField();
        defaultKeyedValues2D1.setValue((java.lang.Number) (byte) 0, (java.lang.Comparable) 0L, (java.lang.Comparable) int6);
        int int9 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) 1.0f);
        try {
            java.lang.Comparable comparable11 = defaultKeyedValues2D1.getRowKey((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 900000L, (double) (short) 100);
        java.lang.Number number3 = meanAndStandardDeviation2.getStandardDeviation();
        java.lang.Number number4 = meanAndStandardDeviation2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 100.0d + "'", number4.equals(100.0d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        boolean boolean14 = lineAndShapeRenderer0.getUseFillPaint();
        java.lang.Boolean boolean16 = lineAndShapeRenderer0.getSeriesShapesFilled(0);
        java.awt.Color color17 = java.awt.Color.LIGHT_GRAY;
        lineAndShapeRenderer0.setBaseItemLabelPaint((java.awt.Paint) color17);
        boolean boolean19 = lineAndShapeRenderer0.getDrawOutlines();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false, false);
        java.awt.Font font25 = lineAndShapeRenderer0.getSeriesItemLabelFont(7);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(font25);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        defaultKeyedValues0.setValue((java.lang.Comparable) month1, (double) (byte) 100);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint2 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (float) '#', (int) (byte) -1, textMeasurer5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textBlock6.getLineAlignment();
        java.util.List list8 = textBlock6.getLines();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(100);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] { valueAxis23 };
        categoryPlot22.setRangeAxes(valueAxisArray24);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray26 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot22.setRenderers(categoryItemRendererArray26);
        objectList1.set(15, (java.lang.Object) categoryItemRendererArray26);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(valueAxisArray24);
        org.junit.Assert.assertNotNull(categoryItemRendererArray26);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        boolean boolean14 = lineAndShapeRenderer0.getUseFillPaint();
        java.lang.Boolean boolean16 = lineAndShapeRenderer0.getSeriesShapesFilled(0);
        java.awt.Color color17 = java.awt.Color.LIGHT_GRAY;
        lineAndShapeRenderer0.setBaseItemLabelPaint((java.awt.Paint) color17);
        boolean boolean19 = lineAndShapeRenderer0.getBaseSeriesVisibleInLegend();
        java.awt.Font font22 = lineAndShapeRenderer0.getItemLabelFont((int) (byte) 1, (int) 'a');
        lineAndShapeRenderer0.setSeriesLinesVisible(1, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(font22);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.gantt.TaskSeries taskSeries2 = null;
        try {
            taskSeriesCollection0.remove(taskSeries2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'series' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
        java.util.List list2 = keyToGroupMap1.getGroups();
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = null;
        taskSeriesCollection0.seriesChanged(seriesChangeEvent1);
        org.jfree.data.gantt.TaskSeries taskSeries4 = taskSeriesCollection0.getSeries((java.lang.Comparable) "org.jfree.chart.event.ChartChangeEvent[source=]");
        org.jfree.data.Range range5 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            int int8 = taskSeriesCollection0.getSubIntervalCount(7, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(taskSeries4);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        java.lang.Number number1 = null;
        java.lang.Number number3 = null;
        java.lang.Number number7 = null;
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 3, number1, (java.lang.Number) 10, number3, (java.lang.Number) 12.0d, (java.lang.Number) 10.0f, (java.lang.Number) (short) 1, number7, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getMinOutlier();
        java.lang.Number number11 = boxAndWhiskerItem9.getMean();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (short) 1 + "'", number10.equals((short) 1));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3 + "'", number11.equals(3));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit(1.0d);
        java.lang.String str3 = numberTickUnit1.valueToString((double) (-1));
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer7.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint12 = lineAndShapeRenderer7.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = lineAndShapeRenderer7.getPlot();
        java.awt.Color color18 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer7.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color18, true);
        boolean boolean21 = lineAndShapeRenderer7.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = lineAndShapeRenderer7.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer27 = null;
        categoryPlot23.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = categoryPlot23.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart31 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot23);
        int int32 = categoryPlot23.getDatasetCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = categoryPlot23.getDomainAxisForDataset((int) (short) -1);
        java.awt.Color color36 = org.jfree.chart.util.PaintUtilities.stringToColor("");
        categoryPlot23.setDomainGridlinePaint((java.awt.Paint) color36);
        boolean boolean38 = numberTickUnit1.equals((java.lang.Object) categoryPlot23);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "-1" + "'", str3.equals("-1"));
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryPlot13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNull(categoryAxis34);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.renderer.category.GroupedStackedBarRenderer groupedStackedBarRenderer0 = new org.jfree.chart.renderer.category.GroupedStackedBarRenderer();
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean2 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot22.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.Range range29 = categoryPlot22.getDataRange(valueAxis28);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = categoryPlot22.getDatasetRenderingOrder();
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        numberAxis3D1.setFixedAutoRange((double) (byte) 1);
        java.text.NumberFormat numberFormat34 = null;
        numberAxis3D1.setNumberFormatOverride(numberFormat34);
        numberAxis3D1.configure();
        org.jfree.chart.plot.Plot plot37 = numberAxis3D1.getPlot();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNull(plot37);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("DateTickUnit[DAY, 1]", font1);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.renderer.category.IntervalBarRenderer intervalBarRenderer0 = new org.jfree.chart.renderer.category.IntervalBarRenderer();
        double double1 = intervalBarRenderer0.getBase();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = intervalBarRenderer0.getPositiveItemLabelPosition(7, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        ringPlot50.setLabelGap(100.0d);
        java.lang.Object obj53 = ringPlot50.clone();
        java.awt.Stroke stroke54 = ringPlot50.getBaseSectionOutlineStroke();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(obj53);
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        org.jfree.data.xy.XYDataset xYDataset37 = polarPlot36.getDataset();
        java.lang.String str38 = polarPlot36.getPlotType();
        polarPlot36.setAngleGridlinesVisible(false);
        java.lang.Object obj41 = polarPlot36.clone();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNull(xYDataset37);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "Polar Plot" + "'", str38.equals("Polar Plot"));
        org.junit.Assert.assertNotNull(obj41);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Paint paint28 = jFreeChart27.getBorderPaint();
        jFreeChart27.setBorderVisible(false);
        java.awt.Stroke stroke31 = jFreeChart27.getBorderStroke();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        double[][] doubleArray4 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("-4,-4,4,4", "", doubleArray4);
        org.jfree.chart.title.LegendItemBlockContainer legendItemBlockContainer7 = new org.jfree.chart.title.LegendItemBlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0, (org.jfree.data.general.Dataset) categoryDataset5, (java.lang.Comparable) 9999);
        legendItemBlockContainer7.setURLText("ItemLabelAnchor.OUTSIDE1");
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = textTitle1.getPosition();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle5.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle5.getBounds();
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        java.lang.Object obj10 = textTitle1.draw(graphics2D3, rectangle2D8, (java.lang.Object) axisLocation9);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(obj10);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot7.getDomainAxisEdge();
        boolean boolean9 = xYPlot7.isRangeZoomable();
        xYPlot7.setDomainCrosshairValue(0.0d);
        boolean boolean12 = xYPlot7.isRangeZeroBaselineVisible();
        int int13 = xYPlot7.getSeriesCount();
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        java.awt.Stroke stroke4 = stackedBarRenderer1.getItemStroke((int) (short) 10, 9);
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D5 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean6 = barRenderer3D5.getAutoPopulateSeriesOutlineStroke();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer11.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint16 = lineAndShapeRenderer11.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = lineAndShapeRenderer11.getPlot();
        java.awt.Color color22 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer11.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color22, true);
        boolean boolean25 = lineAndShapeRenderer11.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = lineAndShapeRenderer11.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot27.setRangeAxes(valueAxisArray29);
        categoryPlot27.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D34.setVerticalTickLabels(true);
        numberAxis3D34.setLowerBound((double) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color41 = java.awt.Color.magenta;
        valueMarker40.setOutlinePaint((java.awt.Paint) color41);
        java.awt.Color color43 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int44 = color43.getGreen();
        valueMarker40.setOutlinePaint((java.awt.Paint) color43);
        java.awt.Stroke stroke46 = valueMarker40.getStroke();
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        barRenderer3D5.drawRangeMarker(graphics2D7, categoryPlot27, (org.jfree.chart.axis.ValueAxis) numberAxis3D34, (org.jfree.chart.plot.Marker) valueMarker40, rectangle2D47);
        boolean boolean49 = stackedBarRenderer1.hasListener((java.util.EventListener) categoryPlot27);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier50 = stackedBarRenderer1.getDrawingSupplier();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(categoryPlot17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(valueAxisArray29);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(drawingSupplier50);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(1.0E-5d, (double) (-1.0f), 1.05d, 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray23 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot19.setRenderers(categoryItemRendererArray23);
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot19.getRangeAxisForDataset((int) (byte) -1);
        boolean boolean27 = categoryPlot19.isRangeZoomable();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(categoryItemRendererArray23);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = stackedAreaRenderer1.getSeriesNegativeItemLabelPosition(8);
        int int4 = stackedAreaRenderer1.getPassCount();
        stackedAreaRenderer1.setRenderAsPercentages(false);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot19.markerChanged(markerChangeEvent28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        float float31 = jFreeChart30.getBackgroundImageAlpha();
        org.jfree.chart.title.Title title33 = jFreeChart30.getSubtitle(0);
        jFreeChart30.setNotify(true);
        java.awt.image.BufferedImage bufferedImage38 = jFreeChart30.createBufferedImage(9999, 3);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.5f + "'", float31 == 0.5f);
        org.junit.Assert.assertNotNull(title33);
        org.junit.Assert.assertNotNull(bufferedImage38);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D1 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        polarPlot36.removeCornerTextItem("ERROR : Relative To String");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        java.awt.geom.Point2D point2D41 = null;
        polarPlot36.zoomRangeAxes((double) 10, plotRenderingInfo40, point2D41);
        polarPlot36.setBackgroundAlpha((float) 1560668399999L);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) ' ', 100);
        boolean boolean7 = lineAndShapeRenderer2.isSeriesVisible((int) ' ');
        java.awt.Paint paint8 = lineAndShapeRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=]", font1, paint8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = labelBlock9.getMargin();
        java.awt.Paint paint11 = labelBlock9.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        java.awt.Stroke stroke51 = ringPlot50.getBaseSectionOutlineStroke();
        ringPlot50.setPieIndex(3);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator54 = ringPlot50.getLegendLabelURLGenerator();
        java.awt.Paint paint55 = ringPlot50.getLabelBackgroundPaint();
        double double56 = ringPlot50.getOuterSeparatorExtension();
        double double57 = ringPlot50.getShadowYOffset();
        ringPlot50.setPieIndex((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNull(pieURLGenerator54);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.2d + "'", double56 == 0.2d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 4.0d + "'", double57 == 4.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, 6.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("({0}, {1}) = {3} - {4}");
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand2 = null;
        numberAxis1.setMarkerBand(markerAxisBand2);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        boolean boolean6 = lineAndShapeRenderer0.getUseOutlinePaint();
        lineAndShapeRenderer0.setSeriesShapesVisible(15, true);
        java.awt.Color color10 = java.awt.Color.ORANGE;
        lineAndShapeRenderer0.setBaseItemLabelPaint((java.awt.Paint) color10, true);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        boolean boolean27 = categoryPlot19.isSubplot();
        org.jfree.chart.plot.Plot plot28 = categoryPlot19.getParent();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = categoryPlot19.getAxisOffset();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(plot28);
        org.junit.Assert.assertNotNull(rectangleInsets29);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray23 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot19.setRenderers(categoryItemRendererArray23);
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot19.getRangeAxisForDataset((int) (byte) -1);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection28 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection28);
        java.util.List list30 = taskSeriesCollection28.getRowKeys();
        categoryPlot19.setDataset(10, (org.jfree.data.category.CategoryDataset) taskSeriesCollection28);
        org.jfree.chart.axis.DateTickUnit dateTickUnit34 = new org.jfree.chart.axis.DateTickUnit((int) (byte) 1, (int) (short) 100);
        try {
            java.lang.Number number37 = taskSeriesCollection28.getPercentComplete((java.lang.Comparable) (short) 100, (java.lang.Comparable) (short) -1, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(categoryItemRendererArray23);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(list30);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        lineRenderer3D0.setYOffset((double) (short) 10);
        double double3 = lineRenderer3D0.getXOffset();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 12.0d + "'", double3 == 12.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot19.markerChanged(markerChangeEvent28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        float float31 = jFreeChart30.getBackgroundImageAlpha();
        org.jfree.chart.title.Title title33 = jFreeChart30.getSubtitle(0);
        jFreeChart30.setNotify(true);
        org.jfree.chart.title.LegendTitle legendTitle36 = jFreeChart30.getLegend();
        boolean boolean37 = jFreeChart30.isBorderVisible();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.5f + "'", float31 == 0.5f);
        org.junit.Assert.assertNotNull(title33);
        org.junit.Assert.assertNotNull(legendTitle36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer7.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint12 = lineAndShapeRenderer7.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = lineAndShapeRenderer7.getPlot();
        java.awt.Color color18 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer7.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color18, true);
        boolean boolean21 = lineAndShapeRenderer7.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = lineAndShapeRenderer7.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer27 = null;
        categoryPlot23.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer27);
        java.awt.Paint paint29 = categoryPlot23.getBackgroundPaint();
        boolean boolean30 = segmentedTimeline3.equals((java.lang.Object) categoryPlot23);
        java.awt.Font font32 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint33 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer36 = null;
        org.jfree.chart.text.TextBlock textBlock37 = org.jfree.chart.text.TextUtilities.createTextBlock("", font32, paint33, (float) '#', (int) (byte) -1, textMeasurer36);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment38 = textBlock37.getLineAlignment();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.util.Size2D size2D40 = textBlock37.calculateDimensions(graphics2D39);
        boolean boolean41 = categoryPlot23.equals((java.lang.Object) size2D40);
        java.lang.String str42 = categoryPlot23.getPlotType();
        boolean boolean43 = categoryPlot23.isRangeGridlinesVisible();
        java.util.List list44 = categoryPlot23.getAnnotations();
        org.jfree.chart.util.Layer layer46 = null;
        java.util.Collection collection47 = categoryPlot23.getDomainMarkers(2, layer46);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryPlot13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(textBlock37);
        org.junit.Assert.assertNotNull(horizontalAlignment38);
        org.junit.Assert.assertNotNull(size2D40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Category Plot" + "'", str42.equals("Category Plot"));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(list44);
        org.junit.Assert.assertNull(collection47);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) '#', (int) (byte) -1, textMeasurer6);
        org.jfree.chart.text.TextLine textLine8 = new org.jfree.chart.text.TextLine("TextAnchor.BASELINE_RIGHT", font2);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener11 = null;
        boolean boolean12 = categoryAxis10.hasListener(eventListener11);
        categoryAxis10.setTickMarkInsideLength((float) 100L);
        java.awt.Font font16 = categoryAxis10.getTickLabelFont((java.lang.Comparable) ' ');
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.CENTER_LEFT", font16);
        textLine8.removeFragment(textFragment17);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        dateAxis0.zoomRange((double) (byte) 10, (double) (short) 10);
        java.util.Date date4 = dateAxis0.getMaximumDate();
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot7.getRenderer((int) (short) 0);
        xYPlot7.setDomainCrosshairValue((double) (-1));
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset12 = new org.jfree.data.category.DefaultCategoryDataset();
        int int14 = defaultCategoryDataset12.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener18 = null;
        boolean boolean19 = categoryAxis17.hasListener(eventListener18);
        categoryAxis17.setFixedDimension((double) (short) -1);
        java.awt.Font font23 = categoryAxis17.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis17);
        categoryAxis17.configure();
        boolean boolean26 = month16.equals((java.lang.Object) categoryAxis17);
        int int27 = defaultCategoryDataset12.getRowIndex((java.lang.Comparable) boolean26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = lineAndShapeRenderer31.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint36 = lineAndShapeRenderer31.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = lineAndShapeRenderer31.getPlot();
        java.awt.Color color42 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer31.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color42, true);
        boolean boolean45 = lineAndShapeRenderer31.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier46 = lineAndShapeRenderer31.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer31);
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer51 = null;
        categoryPlot47.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker50, layer51);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot47.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart55 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot47);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent56 = null;
        categoryPlot47.markerChanged(markerChangeEvent56);
        org.jfree.chart.plot.Plot plot58 = categoryPlot47.getRootPlot();
        defaultCategoryDataset12.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot58);
        java.awt.Paint paint60 = plot58.getOutlinePaint();
        xYPlot7.setDomainGridlinePaint(paint60);
        org.jfree.chart.axis.ValueAxis valueAxis63 = xYPlot7.getDomainAxis((int) (byte) 0);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0.0d + "'", number15.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(categoryPlot37);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(drawingSupplier46);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(plot58);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(valueAxis63);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        java.util.List list2 = taskSeriesCollection0.getRowKeys();
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0, true);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertNull(range4);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        int int3 = defaultCategoryDataset0.getColumnCount();
        try {
            java.lang.Number number6 = defaultCategoryDataset0.getValue((java.lang.Comparable) (-1), (java.lang.Comparable) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: 0");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        double double1 = blockParams0.getTranslateY();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D30.setVerticalTickLabels(true);
        org.jfree.data.Range range33 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryPlot19.getInsets();
        double double36 = rectangleInsets34.trimWidth(0.0d);
        org.jfree.chart.util.UnitType unitType37 = rectangleInsets34.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = new org.jfree.chart.util.RectangleInsets(unitType37, (double) 100.0f, (double) 1559372400000L, (double) (short) -1, (double) (byte) 10);
        org.jfree.chart.ChartColor chartColor46 = new org.jfree.chart.ChartColor((int) (short) 1, 0, 7);
        boolean boolean47 = unitType37.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-16.0d) + "'", double36 == (-16.0d));
        org.junit.Assert.assertNotNull(unitType37);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues1 = new org.jfree.data.DefaultKeyedValues();
        org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) "Sunday", (org.jfree.data.KeyedValues) defaultKeyedValues1);
        java.lang.Comparable comparable4 = null;
        try {
            defaultKeyedValues1.insertValue(6, comparable4, (java.lang.Number) 900000L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryDataset2);
    }

//    @Test
//    public void test306() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test306");
//        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
//        dateAxis0.zoomRange((double) (byte) 10, (double) (short) 10);
//        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D5 = new org.jfree.data.DefaultKeyedValues2D(true);
//        java.lang.Number number6 = null;
//        org.jfree.data.KeyToGroupMap keyToGroupMap8 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
//        int int10 = keyToGroupMap8.getGroupIndex((java.lang.Comparable) "");
//        org.jfree.data.KeyToGroupMap keyToGroupMap12 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
//        int int14 = keyToGroupMap12.getGroupIndex((java.lang.Comparable) "");
//        org.jfree.chart.axis.DateTickUnit dateTickUnit16 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
//        keyToGroupMap12.mapKeyToGroup((java.lang.Comparable) 8, (java.lang.Comparable) dateTickUnit16);
//        java.lang.String str18 = dateTickUnit16.toString();
//        int int19 = keyToGroupMap8.getKeyCount((java.lang.Comparable) dateTickUnit16);
//        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
//        java.lang.String str21 = month20.toString();
//        java.util.Date date22 = month20.getEnd();
//        java.util.Date date23 = dateTickUnit16.addToDate(date22);
//        defaultKeyedValues2D5.setValue(number6, (java.lang.Comparable) date23, (java.lang.Comparable) 6);
//        dateAxis0.setMaximumDate(date23);
//        org.jfree.chart.util.RectangleInsets rectangleInsets27 = dateAxis0.getLabelInsets();
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
//        org.junit.Assert.assertNotNull(dateTickUnit16);
//        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str18.equals("DateTickUnit[DAY, 1]"));
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "June 2019" + "'", str21.equals("June 2019"));
//        org.junit.Assert.assertNotNull(date22);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertNotNull(rectangleInsets27);
//    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("rect", (org.jfree.data.time.TimePeriod) month1);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        int int5 = defaultCategoryDataset3.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = categoryAxis8.hasListener(eventListener9);
        categoryAxis8.setFixedDimension((double) (short) -1);
        java.awt.Font font14 = categoryAxis8.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis8);
        categoryAxis8.configure();
        boolean boolean17 = month7.equals((java.lang.Object) categoryAxis8);
        int int18 = defaultCategoryDataset3.getRowIndex((java.lang.Comparable) boolean17);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = lineAndShapeRenderer22.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint27 = lineAndShapeRenderer22.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = lineAndShapeRenderer22.getPlot();
        java.awt.Color color33 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer22.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color33, true);
        boolean boolean36 = lineAndShapeRenderer22.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier37 = lineAndShapeRenderer22.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer42 = null;
        categoryPlot38.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker41, layer42);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot38.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart46 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot38);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent47 = null;
        categoryPlot38.markerChanged(markerChangeEvent47);
        org.jfree.chart.plot.Plot plot49 = categoryPlot38.getRootPlot();
        defaultCategoryDataset3.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot49);
        java.awt.Paint paint51 = plot49.getOutlinePaint();
        boolean boolean52 = task2.equals((java.lang.Object) plot49);
        task2.setPercentComplete((java.lang.Double) 0.05d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(categoryPlot28);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(drawingSupplier37);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(plot49);
        org.junit.Assert.assertNotNull(paint51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot7.setOrientation(plotOrientation8);
        xYPlot7.clearDomainAxes();
        boolean boolean11 = xYPlot7.isDomainGridlinesVisible();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = lineAndShapeRenderer20.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint25 = lineAndShapeRenderer20.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = lineAndShapeRenderer20.getPlot();
        java.awt.Color color31 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer20.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color31, true);
        boolean boolean34 = lineAndShapeRenderer20.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier35 = lineAndShapeRenderer20.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray38 = new org.jfree.chart.axis.ValueAxis[] { valueAxis37 };
        categoryPlot36.setRangeAxes(valueAxisArray38);
        categoryPlot36.setDrawSharedDomainAxis(false);
        java.awt.Font font42 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean43 = categoryPlot36.equals((java.lang.Object) font42);
        categoryPlot36.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D47 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D47.setVerticalTickLabels(true);
        org.jfree.data.Range range50 = categoryPlot36.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D47);
        org.jfree.chart.util.RectangleInsets rectangleInsets51 = categoryPlot36.getInsets();
        double double53 = rectangleInsets51.trimWidth(0.0d);
        org.jfree.chart.title.TextTitle textTitle55 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle55.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D58 = textTitle55.getBounds();
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets51.createOutsetRectangle(rectangle2D58);
        java.awt.geom.Point2D point2D60 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 10, 0.2d, rectangle2D58);
        xYPlot7.zoomRangeAxes(Double.NaN, plotRenderingInfo14, point2D60);
        try {
            org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = plotRenderingInfo14.getSubplotInfo((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(categoryPlot26);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNull(drawingSupplier35);
        org.junit.Assert.assertNotNull(valueAxisArray38);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(range50);
        org.junit.Assert.assertNotNull(rectangleInsets51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + (-16.0d) + "'", double53 == (-16.0d));
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(point2D60);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D3 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D3.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D3, valueAxis6, xYItemRenderer7);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot8.getRenderer((int) (short) 0);
        org.jfree.data.KeyedObject keyedObject11 = new org.jfree.data.KeyedObject((java.lang.Comparable) 4.0d, (java.lang.Object) xYItemRenderer10);
        org.junit.Assert.assertNull(xYItemRenderer10);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = year0.getFirstMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        polarPlot36.removeCornerTextItem("ERROR : Relative To String");
        boolean boolean39 = polarPlot36.isRadiusGridlinesVisible();
        polarPlot36.setAngleGridlinesVisible(true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        java.lang.Number number16 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.0d + "'", number16.equals(0.0d));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer0.setBaseStroke(stroke17);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator19);
        java.awt.Stroke stroke21 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Font font23 = lineAndShapeRenderer0.getSeriesItemLabelFont(5);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(font23);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(true);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        columnArrangement0.clear();
        columnArrangement0.clear();
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer5 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement4);
        java.util.List list6 = blockContainer5.getBlocks();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range8, (double) (-1));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = rectangleConstraint10.toUnconstrainedWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = rectangleConstraint10.toFixedHeight((double) 100);
        try {
            org.jfree.chart.util.Size2D size2D14 = columnArrangement0.arrange(blockContainer5, graphics2D7, rectangleConstraint13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(rectangleConstraint11);
        org.junit.Assert.assertNotNull(rectangleConstraint13);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_MINIMUM_ARC_ANGLE_TO_DRAW;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-5d + "'", double0 == 1.0E-5d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        java.awt.Color color1 = java.awt.Color.getColor("LengthConstraintType.NONE");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray23 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot19.setRenderers(categoryItemRendererArray23);
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot19.getRangeAxisForDataset((int) (byte) -1);
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection28 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range29 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection28);
        java.util.List list30 = taskSeriesCollection28.getRowKeys();
        categoryPlot19.setDataset(10, (org.jfree.data.category.CategoryDataset) taskSeriesCollection28);
        java.util.List list32 = taskSeriesCollection28.getColumnKeys();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(categoryItemRendererArray23);
        org.junit.Assert.assertNull(valueAxis26);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNotNull(list32);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint2 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer5 = null;
        org.jfree.chart.text.TextBlock textBlock6 = org.jfree.chart.text.TextUtilities.createTextBlock("", font1, paint2, (float) '#', (int) (byte) -1, textMeasurer5);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = textBlock6.getLineAlignment();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.util.Size2D size2D9 = textBlock6.calculateDimensions(graphics2D8);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = textBlock6.getLineAlignment();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.util.ShapeList shapeList15 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape17 = null;
        shapeList15.setShape((int) (byte) 10, shape17);
        boolean boolean19 = rectangleAnchor14.equals((java.lang.Object) shape17);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str21 = textBlockAnchor20.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition22 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor14, textBlockAnchor20);
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = lineAndShapeRenderer26.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint31 = lineAndShapeRenderer26.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = lineAndShapeRenderer26.getPlot();
        java.awt.Color color37 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer26.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color37, true);
        boolean boolean40 = lineAndShapeRenderer26.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier41 = lineAndShapeRenderer26.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer26);
        org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer46 = null;
        categoryPlot42.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker45, layer46);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = categoryPlot42.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart50 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot42);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent51 = null;
        categoryPlot42.markerChanged(markerChangeEvent51);
        boolean boolean53 = textBlockAnchor20.equals((java.lang.Object) categoryPlot42);
        java.awt.Shape shape57 = textBlock6.calculateBounds(graphics2D11, 0.8f, (float) 100L, textBlockAnchor20, 100.0f, 0.0f, (double) 2);
        org.jfree.chart.text.TextLine textLine59 = new org.jfree.chart.text.TextLine("LengthConstraintType.NONE");
        textBlock6.addLine(textLine59);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener63 = null;
        boolean boolean64 = categoryAxis62.hasListener(eventListener63);
        categoryAxis62.setTickMarkInsideLength((float) 100L);
        java.awt.Font font68 = categoryAxis62.getTickLabelFont((java.lang.Comparable) ' ');
        org.jfree.chart.text.TextFragment textFragment69 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.CENTER_LEFT", font68);
        textLine59.addFragment(textFragment69);
        java.awt.Graphics2D graphics2D71 = null;
        org.jfree.chart.text.TextAnchor textAnchor74 = null;
        try {
            textLine59.draw(graphics2D71, 0.8f, (float) (short) 10, textAnchor74, 0.0f, (float) 7, (double) 4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(textBlock6);
        org.junit.Assert.assertNotNull(horizontalAlignment7);
        org.junit.Assert.assertNotNull(size2D9);
        org.junit.Assert.assertNotNull(horizontalAlignment10);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str21.equals("TextBlockAnchor.CENTER_LEFT"));
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(categoryPlot32);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(drawingSupplier41);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(shape57);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(font68);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint7 = lineAndShapeRenderer2.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = lineAndShapeRenderer2.getPlot();
        java.awt.Color color13 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer2.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color13, true);
        boolean boolean16 = lineAndShapeRenderer2.getUseFillPaint();
        java.lang.Boolean boolean18 = lineAndShapeRenderer2.getSeriesShapesFilled(0);
        boolean boolean19 = axisSpace1.equals((java.lang.Object) lineAndShapeRenderer2);
        boolean boolean20 = blockBorder0.equals((java.lang.Object) lineAndShapeRenderer2);
        boolean boolean21 = lineAndShapeRenderer2.getBaseLinesVisible();
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryPlot8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(4.0d, Double.NaN);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator4 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("WMAP_Plot");
        stackedBarRenderer3D2.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator4);
        java.awt.Paint paint7 = stackedBarRenderer3D2.getSeriesOutlinePaint((int) 'a');
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean3 = numberAxis3D2.getAutoRangeIncludesZero();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle7.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle7.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer14.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint19 = lineAndShapeRenderer14.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = lineAndShapeRenderer14.getPlot();
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer14.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color25, true);
        boolean boolean28 = lineAndShapeRenderer14.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = lineAndShapeRenderer14.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { valueAxis31 };
        categoryPlot30.setRangeAxes(valueAxisArray32);
        categoryPlot30.setDrawSharedDomainAxis(false);
        boolean boolean36 = categoryPlot30.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot30.getRangeAxisEdge();
        double double38 = dateAxis4.valueToJava2D(0.0d, rectangle2D10, rectangleEdge37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer39);
        boolean boolean41 = xYPlot40.isSubplot();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryPlot20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = stackedAreaRenderer1.getSeriesNegativeItemLabelPosition(8);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = null;
        org.jfree.chart.axis.DateAxis dateAxis6 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle9.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D12 = textTitle9.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineAndShapeRenderer16.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint21 = lineAndShapeRenderer16.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = lineAndShapeRenderer16.getPlot();
        java.awt.Color color27 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer16.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color27, true);
        boolean boolean30 = lineAndShapeRenderer16.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier31 = lineAndShapeRenderer16.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer16);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] { valueAxis33 };
        categoryPlot32.setRangeAxes(valueAxisArray34);
        categoryPlot32.setDrawSharedDomainAxis(false);
        boolean boolean38 = categoryPlot32.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot32.getRangeAxisEdge();
        double double40 = dateAxis6.valueToJava2D(0.0d, rectangle2D12, rectangleEdge39);
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = lineAndShapeRenderer44.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint49 = lineAndShapeRenderer44.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = lineAndShapeRenderer44.getPlot();
        java.awt.Color color55 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer44.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color55, true);
        boolean boolean58 = lineAndShapeRenderer44.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier59 = lineAndShapeRenderer44.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset41, categoryAxis42, valueAxis43, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer44);
        org.jfree.chart.plot.ValueMarker valueMarker63 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer64 = null;
        categoryPlot60.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker63, layer64);
        org.jfree.chart.axis.ValueAxis valueAxis66 = null;
        org.jfree.data.Range range67 = categoryPlot60.getDataRange(valueAxis66);
        org.jfree.chart.plot.Plot plot68 = categoryPlot60.getRootPlot();
        boolean boolean69 = categoryPlot60.isDomainGridlinesVisible();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder70 = categoryPlot60.getDatasetRenderingOrder();
        categoryPlot60.clearDomainAxes();
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener73 = null;
        boolean boolean74 = categoryAxis72.hasListener(eventListener73);
        categoryAxis72.setTickMarkInsideLength((float) 100L);
        java.awt.Font font78 = categoryAxis72.getTickLabelFont((java.lang.Comparable) ' ');
        categoryAxis72.setCategoryLabelPositionOffset((int) (short) 0);
        org.jfree.chart.axis.NumberAxis numberAxis82 = new org.jfree.chart.axis.NumberAxis("({0}, {1}) = {3} - {4}");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset83 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int84 = defaultStatisticalCategoryDataset83.getColumnCount();
        int int85 = defaultStatisticalCategoryDataset83.getRowCount();
        try {
            stackedAreaRenderer1.drawItem(graphics2D4, categoryItemRendererState5, rectangle2D12, categoryPlot60, categoryAxis72, (org.jfree.chart.axis.ValueAxis) numberAxis82, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset83, (int) '#', (int) (byte) 100, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(categoryPlot22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(drawingSupplier31);
        org.junit.Assert.assertNotNull(valueAxisArray34);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNull(categoryPlot50);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNull(drawingSupplier59);
        org.junit.Assert.assertNull(range67);
        org.junit.Assert.assertNotNull(plot68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder70);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(font78);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        double double3 = defaultStatisticalCategoryDataset0.getRangeLowerBound(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setName("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setName("TextBlockAnchor.CENTER_LEFT");
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo7 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo7.setName("TextBlockAnchor.CENTER_LEFT");
        basicProjectInfo3.addLibrary((org.jfree.chart.ui.Library) basicProjectInfo7);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis1.hasListener(eventListener2);
        categoryAxis1.setTickMarkInsideLength((float) 100L);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) ' ');
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer12.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint17 = lineAndShapeRenderer12.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = lineAndShapeRenderer12.getPlot();
        java.awt.Color color23 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer12.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color23, true);
        boolean boolean26 = lineAndShapeRenderer12.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = lineAndShapeRenderer12.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer12);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer32 = null;
        categoryPlot28.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker31, layer32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot28.getRangeAxisEdge(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot28.getDomainAxisEdge();
        java.awt.Font font38 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint39 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer42 = null;
        org.jfree.chart.text.TextBlock textBlock43 = org.jfree.chart.text.TextUtilities.createTextBlock("", font38, paint39, (float) '#', (int) (byte) -1, textMeasurer42);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = textBlock43.getLineAlignment();
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.util.Size2D size2D46 = textBlock43.calculateDimensions(graphics2D45);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment47 = textBlock43.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str49 = verticalAlignment48.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font7, paint8, rectangleEdge36, horizontalAlignment47, verticalAlignment48, rectangleInsets50);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment52 = textTitle51.getTextAlignment();
        textTitle51.setExpandToFitSpace(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryPlot18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(drawingSupplier27);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(textBlock43);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(size2D46);
        org.junit.Assert.assertNotNull(horizontalAlignment47);
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str49.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(horizontalAlignment52);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        java.awt.Shape shape2 = numberAxis3D1.getRightArrow();
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity5 = new org.jfree.chart.entity.TickLabelEntity(shape2, "ChartEntity: tooltip = ({0}, {1}) = {3} - {4}", "TextAnchor.TOP_CENTER");
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setFixedDimension((double) (short) -1);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) '4');
        int int7 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setMaximumCategoryLabelLines(0);
        double double10 = categoryAxis0.getLowerMargin();
        int int11 = categoryAxis0.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.05d + "'", double10 == 0.05d);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        java.awt.Stroke stroke51 = ringPlot50.getBaseSectionOutlineStroke();
        ringPlot50.setPieIndex(3);
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator54 = ringPlot50.getLegendLabelURLGenerator();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator55 = null;
        ringPlot50.setLegendLabelURLGenerator(pieURLGenerator55);
        java.awt.Paint paint57 = ringPlot50.getLabelLinkPaint();
        org.jfree.chart.urls.PieURLGenerator pieURLGenerator58 = ringPlot50.getURLGenerator();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNull(pieURLGenerator54);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNull(pieURLGenerator58);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Color color16 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer5.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color16, true);
        boolean boolean19 = lineAndShapeRenderer5.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = lineAndShapeRenderer5.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer5);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] { valueAxis22 };
        categoryPlot21.setRangeAxes(valueAxisArray23);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Font font27 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean28 = categoryPlot21.equals((java.lang.Object) font27);
        categoryPlot21.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D32.setVerticalTickLabels(true);
        org.jfree.data.Range range35 = categoryPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D32);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, polarItemRenderer36);
        org.jfree.data.xy.XYDataset xYDataset38 = polarPlot37.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis39 = polarPlot37.getAxis();
        java.awt.Color color42 = java.awt.Color.getColor("ERROR : Relative To String", 7);
        polarPlot37.setRadiusGridlinePaint((java.awt.Paint) color42);
        java.awt.Color color44 = color42.darker();
        ganttRenderer0.setIncompletePaint((java.awt.Paint) color42);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertNull(xYDataset38);
        org.junit.Assert.assertNotNull(valueAxis39);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color44);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = null;
        chartRenderingInfo0.setEntityCollection(entityCollection2);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.urls.StandardCategoryURLGenerator standardCategoryURLGenerator0 = new org.jfree.chart.urls.StandardCategoryURLGenerator();
        java.lang.Object obj1 = standardCategoryURLGenerator0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D30.setVerticalTickLabels(true);
        org.jfree.data.Range range33 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        java.text.NumberFormat numberFormat34 = null;
        numberAxis3D30.setNumberFormatOverride(numberFormat34);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent36 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis3D30);
        double double37 = numberAxis3D30.getLowerMargin();
        numberAxis3D30.configure();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test335");
//        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
//        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
//        int int3 = defaultCategoryDataset0.getColumnCount();
//        org.jfree.data.KeyToGroupMap keyToGroupMap6 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
//        int int8 = keyToGroupMap6.getGroupIndex((java.lang.Comparable) "");
//        org.jfree.chart.axis.DateTickUnit dateTickUnit10 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
//        keyToGroupMap6.mapKeyToGroup((java.lang.Comparable) 8, (java.lang.Comparable) dateTickUnit10);
//        org.jfree.chart.axis.DateAxis dateAxis12 = new org.jfree.chart.axis.DateAxis();
//        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
//        textTitle15.setURLText("-4,-4,4,4");
//        java.awt.geom.Rectangle2D rectangle2D18 = textTitle15.getBounds();
//        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
//        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = lineAndShapeRenderer22.getNegativeItemLabelPosition((int) ' ', 100);
//        java.awt.Paint paint27 = lineAndShapeRenderer22.lookupSeriesPaint((int) (byte) -1);
//        org.jfree.chart.plot.CategoryPlot categoryPlot28 = lineAndShapeRenderer22.getPlot();
//        java.awt.Color color33 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
//        lineAndShapeRenderer22.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color33, true);
//        boolean boolean36 = lineAndShapeRenderer22.getUseFillPaint();
//        org.jfree.chart.plot.DrawingSupplier drawingSupplier37 = lineAndShapeRenderer22.getDrawingSupplier();
//        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
//        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
//        org.jfree.chart.axis.ValueAxis[] valueAxisArray40 = new org.jfree.chart.axis.ValueAxis[] { valueAxis39 };
//        categoryPlot38.setRangeAxes(valueAxisArray40);
//        categoryPlot38.setDrawSharedDomainAxis(false);
//        boolean boolean44 = categoryPlot38.isRangeGridlinesVisible();
//        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot38.getRangeAxisEdge();
//        double double46 = dateAxis12.valueToJava2D(0.0d, rectangle2D18, rectangleEdge45);
//        java.util.Date date47 = dateAxis12.getMinimumDate();
//        java.lang.String str48 = dateTickUnit10.dateToString(date47);
//        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
//        java.lang.String str50 = month49.toString();
//        java.util.Date date51 = month49.getEnd();
//        defaultCategoryDataset0.setValue(Double.NaN, (java.lang.Comparable) dateTickUnit10, (java.lang.Comparable) month49);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
//        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
//        org.junit.Assert.assertNotNull(dateTickUnit10);
//        org.junit.Assert.assertNotNull(rectangle2D18);
//        org.junit.Assert.assertNotNull(itemLabelPosition25);
//        org.junit.Assert.assertNotNull(paint27);
//        org.junit.Assert.assertNull(categoryPlot28);
//        org.junit.Assert.assertNotNull(color33);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertNull(drawingSupplier37);
//        org.junit.Assert.assertNotNull(valueAxisArray40);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertNotNull(rectangleEdge45);
//        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
//        org.junit.Assert.assertNotNull(date47);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "12/31/69 4:00 PM" + "'", str48.equals("12/31/69 4:00 PM"));
//        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "June 2019" + "'", str50.equals("June 2019"));
//        org.junit.Assert.assertNotNull(date51);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.String[] strArray1 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[][] numberArray2 = new java.lang.Number[][] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] { (short) 0 };
        java.lang.Number[] numberArray6 = new java.lang.Number[] { (short) 0 };
        java.lang.Number[][] numberArray7 = new java.lang.Number[][] { numberArray4, numberArray6 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset8 = new org.jfree.data.category.DefaultIntervalCategoryDataset((java.lang.Comparable[]) strArray0, (java.lang.Comparable[]) strArray1, numberArray2, numberArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(strArray1);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        boolean boolean14 = lineAndShapeRenderer0.getUseFillPaint();
        java.lang.Boolean boolean16 = lineAndShapeRenderer0.getSeriesShapesFilled(0);
        java.awt.Color color17 = java.awt.Color.LIGHT_GRAY;
        lineAndShapeRenderer0.setBaseItemLabelPaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = lineAndShapeRenderer20.getNegativeItemLabelPosition((int) ' ', 100);
        org.jfree.chart.text.TextAnchor textAnchor24 = itemLabelPosition23.getTextAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor25 = itemLabelPosition23.getItemLabelAnchor();
        lineAndShapeRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition23);
        org.jfree.data.time.Month month28 = org.jfree.data.time.Month.parseMonth("June 2019");
        boolean boolean29 = itemLabelPosition23.equals((java.lang.Object) "June 2019");
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(itemLabelAnchor25);
        org.junit.Assert.assertNotNull(month28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.KeyToGroupMap keyToGroupMap4 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
        int int6 = keyToGroupMap4.getGroupIndex((java.lang.Comparable) "");
        org.jfree.chart.axis.DateTickUnit dateTickUnit8 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        keyToGroupMap4.mapKeyToGroup((java.lang.Comparable) 8, (java.lang.Comparable) dateTickUnit8);
        java.lang.String str10 = dateTickUnit8.toString();
        multiplePiePlot2.setAggregatedItemsKey((java.lang.Comparable) str10);
        org.jfree.chart.util.TableOrder tableOrder12 = multiplePiePlot2.getDataExtractOrder();
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
        org.junit.Assert.assertNotNull(dateTickUnit8);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str10.equals("DateTickUnit[DAY, 1]"));
        org.junit.Assert.assertNotNull(tableOrder12);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        java.lang.Object obj4 = segmentedTimeline3.clone();
        int int5 = segmentedTimeline3.getSegmentsExcluded();
        java.util.List list6 = segmentedTimeline3.getExceptionSegments();
        int int7 = segmentedTimeline3.getGroupSegmentCount();
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 99 + "'", int7 == 99);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean3 = numberAxis3D2.getAutoRangeIncludesZero();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle7.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle7.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer14.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint19 = lineAndShapeRenderer14.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = lineAndShapeRenderer14.getPlot();
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer14.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color25, true);
        boolean boolean28 = lineAndShapeRenderer14.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = lineAndShapeRenderer14.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { valueAxis31 };
        categoryPlot30.setRangeAxes(valueAxisArray32);
        categoryPlot30.setDrawSharedDomainAxis(false);
        boolean boolean36 = categoryPlot30.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot30.getRangeAxisEdge();
        double double38 = dateAxis4.valueToJava2D(0.0d, rectangle2D10, rectangleEdge37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer39);
        dateAxis4.setLowerBound((double) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryPlot20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot7.getRenderer((int) (short) 0);
        xYPlot7.setDomainCrosshairValue((double) (-1));
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset12 = new org.jfree.data.category.DefaultCategoryDataset();
        int int14 = defaultCategoryDataset12.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number15 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset12);
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener18 = null;
        boolean boolean19 = categoryAxis17.hasListener(eventListener18);
        categoryAxis17.setFixedDimension((double) (short) -1);
        java.awt.Font font23 = categoryAxis17.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent24 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis17);
        categoryAxis17.configure();
        boolean boolean26 = month16.equals((java.lang.Object) categoryAxis17);
        int int27 = defaultCategoryDataset12.getRowIndex((java.lang.Comparable) boolean26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = lineAndShapeRenderer31.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint36 = lineAndShapeRenderer31.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = lineAndShapeRenderer31.getPlot();
        java.awt.Color color42 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer31.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color42, true);
        boolean boolean45 = lineAndShapeRenderer31.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier46 = lineAndShapeRenderer31.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer31);
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer51 = null;
        categoryPlot47.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker50, layer51);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot47.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart55 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot47);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent56 = null;
        categoryPlot47.markerChanged(markerChangeEvent56);
        org.jfree.chart.plot.Plot plot58 = categoryPlot47.getRootPlot();
        defaultCategoryDataset12.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot58);
        java.awt.Paint paint60 = plot58.getOutlinePaint();
        xYPlot7.setDomainGridlinePaint(paint60);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder62 = xYPlot7.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 0.0d + "'", number15.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(categoryPlot37);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(drawingSupplier46);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(plot58);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNotNull(datasetRenderingOrder62);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        java.lang.Object obj2 = barRenderer0.clone();
        barRenderer0.setSeriesVisibleInLegend(1, (java.lang.Boolean) true, false);
        java.awt.Color color7 = java.awt.Color.darkGray;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color7, false);
        java.awt.Paint paint11 = barRenderer0.getSeriesPaint(11);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot7.getDomainAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color12 = java.awt.Color.magenta;
        valueMarker11.setOutlinePaint((java.awt.Paint) color12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker11.setLabelTextAnchor(textAnchor14);
        org.jfree.chart.util.Layer layer16 = null;
        xYPlot7.addRangeMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker11, layer16);
        org.jfree.chart.axis.AxisLocation axisLocation19 = xYPlot7.getRangeAxisLocation((int) (short) 100);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(axisLocation19);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Color color16 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer5.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color16, true);
        boolean boolean19 = lineAndShapeRenderer5.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = lineAndShapeRenderer5.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer5);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] { valueAxis22 };
        categoryPlot21.setRangeAxes(valueAxisArray23);
        categoryPlot21.setDrawSharedDomainAxis(false);
        java.awt.Font font27 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean28 = categoryPlot21.equals((java.lang.Object) font27);
        categoryPlot21.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D32 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D32.setVerticalTickLabels(true);
        org.jfree.data.Range range35 = categoryPlot21.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D32);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer36 = null;
        org.jfree.chart.plot.PolarPlot polarPlot37 = new org.jfree.chart.plot.PolarPlot(xYDataset1, (org.jfree.chart.axis.ValueAxis) numberAxis3D32, polarItemRenderer36);
        polarPlot37.removeCornerTextItem("ERROR : Relative To String");
        java.awt.Font font40 = polarPlot37.getNoDataMessageFont();
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = polarPlot37.getOrientation();
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge42 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(range35);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(plotOrientation41);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator2 = null;
        lineRenderer3D0.setSeriesURLGenerator(8, categoryURLGenerator2, false);
        java.awt.Paint paint7 = lineRenderer3D0.getItemLabelPaint(7, 99);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean3 = barRenderer3D0.isItemLabelVisible((int) ' ', (int) 'a');
        java.awt.Paint paint5 = null;
        barRenderer3D0.setSeriesItemLabelPaint(5, paint5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.util.List list1 = keyedObjects2D0.getColumnKeys();
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D30.setVerticalTickLabels(true);
        org.jfree.data.Range range33 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        numberAxis3D30.setAutoRange(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand36 = numberAxis3D30.getMarkerBand();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNull(markerAxisBand36);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        int int1 = defaultStatisticalCategoryDataset0.getColumnCount();
        int int2 = defaultStatisticalCategoryDataset0.getRowCount();
        int int3 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.data.Range range26 = categoryPlot19.getDataRange(valueAxis25);
        org.jfree.chart.plot.Plot plot27 = categoryPlot19.getRootPlot();
        java.awt.Stroke stroke28 = categoryPlot19.getRangeCrosshairStroke();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(plot27);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 100L);
        org.jfree.data.Range range5 = org.jfree.data.Range.shift(range2, (double) 60000L, true);
        double double6 = range2.getLength();
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer17 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = stackedAreaRenderer17.getSeriesNegativeItemLabelPosition(8);
        int int20 = stackedAreaRenderer17.getPassCount();
        boolean boolean21 = defaultCategoryDataset0.equals((java.lang.Object) stackedAreaRenderer17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot7.getDomainAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color12 = java.awt.Color.magenta;
        valueMarker11.setOutlinePaint((java.awt.Paint) color12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker11.setLabelTextAnchor(textAnchor14);
        org.jfree.chart.util.Layer layer16 = null;
        xYPlot7.addRangeMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker11, layer16);
        xYPlot7.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        java.lang.Object obj4 = defaultCategoryDataset0.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot19.getLegendItems();
        int int27 = categoryPlot19.getDatasetCount();
        float float28 = categoryPlot19.getForegroundAlpha();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        categoryPlot19.setRenderer(2, categoryItemRenderer30, false);
        boolean boolean33 = categoryPlot19.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 1.0f + "'", float28 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        java.awt.Paint paint16 = null;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape4, stroke13, paint16);
        int int18 = legendItem17.getDatasetIndex();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType19 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer20 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType19);
        legendItem17.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer20);
        boolean boolean22 = legendItem17.isShapeOutlineVisible();
        java.awt.Paint paint23 = legendItem17.getLinePaint();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        java.awt.Paint paint16 = null;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape4, stroke13, paint16);
        int int18 = legendItem17.getDatasetIndex();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType19 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer20 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType19);
        legendItem17.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer20);
        java.awt.Stroke stroke22 = legendItem17.getLineStroke();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType19);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setTickLabelsVisible(false);
        categoryAxis0.setMaximumCategoryLabelLines((int) (short) 0);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions7 = categoryAxis0.getCategoryLabelPositions();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions7);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.renderer.category.LineRenderer3D lineRenderer3D0 = new org.jfree.chart.renderer.category.LineRenderer3D();
        java.awt.Paint paint1 = lineRenderer3D0.getWallPaint();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer7.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint12 = lineAndShapeRenderer7.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = lineAndShapeRenderer7.getPlot();
        java.awt.Color color18 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer7.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color18, true);
        boolean boolean21 = lineAndShapeRenderer7.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = lineAndShapeRenderer7.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray25 = new org.jfree.chart.axis.ValueAxis[] { valueAxis24 };
        categoryPlot23.setRangeAxes(valueAxisArray25);
        categoryPlot23.setDrawSharedDomainAxis(false);
        java.awt.Font font29 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean30 = categoryPlot23.equals((java.lang.Object) font29);
        categoryPlot23.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D34 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D34.setVerticalTickLabels(true);
        org.jfree.data.Range range37 = categoryPlot23.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D34);
        org.jfree.chart.util.RectangleInsets rectangleInsets38 = categoryPlot23.getInsets();
        double double40 = rectangleInsets38.trimWidth(0.0d);
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle42.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D45 = textTitle42.getBounds();
        java.awt.geom.Rectangle2D rectangle2D46 = rectangleInsets38.createOutsetRectangle(rectangle2D45);
        java.awt.geom.Point2D point2D47 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle((double) 10, 0.2d, rectangle2D45);
        lineRenderer3D0.setBaseShape((java.awt.Shape) rectangle2D45, false);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryPlot13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(valueAxisArray25);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(range37);
        org.junit.Assert.assertNotNull(rectangleInsets38);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + (-16.0d) + "'", double40 == (-16.0d));
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(point2D47);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("-1", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.util.ShapeList shapeList1 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape3 = null;
        shapeList1.setShape((int) (byte) 10, shape3);
        boolean boolean5 = rectangleAnchor0.equals((java.lang.Object) shape3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str7 = textBlockAnchor6.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer12.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint17 = lineAndShapeRenderer12.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = lineAndShapeRenderer12.getPlot();
        java.awt.Color color23 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer12.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color23, true);
        boolean boolean26 = lineAndShapeRenderer12.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = lineAndShapeRenderer12.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer12);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer32 = null;
        categoryPlot28.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker31, layer32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot28.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot28);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent37 = null;
        categoryPlot28.markerChanged(markerChangeEvent37);
        boolean boolean39 = textBlockAnchor6.equals((java.lang.Object) categoryPlot28);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener41 = null;
        boolean boolean42 = categoryAxis40.hasListener(eventListener41);
        categoryAxis40.setTickMarkInsideLength((float) 100L);
        java.awt.Font font46 = categoryAxis40.getTickLabelFont((java.lang.Comparable) ' ');
        boolean boolean47 = categoryAxis40.isTickLabelsVisible();
        float float48 = categoryAxis40.getTickMarkInsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = categoryAxis40.getTickLabelInsets();
        categoryPlot28.setInsets(rectangleInsets49, true);
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D53 = rectangleInsets49.createOutsetRectangle(rectangle2D52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str7.equals("TextBlockAnchor.CENTER_LEFT"));
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryPlot18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(drawingSupplier27);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 100.0f + "'", float48 == 100.0f);
        org.junit.Assert.assertNotNull(rectangleInsets49);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot7.getRenderer((int) (short) 0);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot7.markerChanged(markerChangeEvent10);
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Color color16 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer5.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color16, true);
        boolean boolean19 = lineAndShapeRenderer5.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = lineAndShapeRenderer5.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer5);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] { valueAxis22 };
        categoryPlot21.setRangeAxes(valueAxisArray23);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray25 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot21.setRenderers(categoryItemRendererArray25);
        org.jfree.chart.JFreeChart jFreeChart28 = new org.jfree.chart.JFreeChart("Sunday", font1, (org.jfree.chart.plot.Plot) categoryPlot21, false);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo31);
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot21.zoomRangeAxes((double) 0.5f, (double) 0L, plotRenderingInfo32, point2D33);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(valueAxisArray23);
        org.junit.Assert.assertNotNull(categoryItemRendererArray25);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Boolean boolean2 = booleanList0.getBoolean(1900);
        booleanList0.setBoolean(0, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        double double2 = layeredBarRenderer0.getSeriesBarWidth((int) 'a');
        int int3 = layeredBarRenderer0.getRowCount();
        layeredBarRenderer0.setSeriesBarWidth((int) '4', (double) 0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D2 = new org.jfree.chart.renderer.category.BarRenderer3D((double) 100L, (double) 0.5f);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.chart.renderer.category.GanttRenderer ganttRenderer0 = new org.jfree.chart.renderer.category.GanttRenderer();
        double double1 = ganttRenderer0.getEndPercent();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.65d + "'", double1 == 0.65d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setFixedDimension((double) (short) -1);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        boolean boolean8 = categoryAxis0.isAxisLineVisible();
        categoryAxis0.setAxisLineVisible(false);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = lineAndShapeRenderer16.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint21 = lineAndShapeRenderer16.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = lineAndShapeRenderer16.getPlot();
        java.awt.Color color27 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer16.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color27, true);
        boolean boolean30 = lineAndShapeRenderer16.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier31 = lineAndShapeRenderer16.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer16);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray34 = new org.jfree.chart.axis.ValueAxis[] { valueAxis33 };
        categoryPlot32.setRangeAxes(valueAxisArray34);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray36 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot32.setRenderers(categoryItemRendererArray36);
        org.jfree.chart.JFreeChart jFreeChart39 = new org.jfree.chart.JFreeChart("Sunday", font12, (org.jfree.chart.plot.Plot) categoryPlot32, false);
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot32);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNull(categoryPlot22);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(drawingSupplier31);
        org.junit.Assert.assertNotNull(valueAxisArray34);
        org.junit.Assert.assertNotNull(categoryItemRendererArray36);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int5 = dateTickUnit4.getCalendarField();
        int int6 = dateTickUnit4.getCalendarField();
        defaultKeyedValues2D1.setValue((java.lang.Number) (byte) 0, (java.lang.Comparable) 0L, (java.lang.Comparable) int6);
        int int9 = defaultKeyedValues2D1.getColumnIndex((java.lang.Comparable) 1.0f);
        java.lang.Comparable comparable11 = defaultKeyedValues2D1.getRowKey((int) (short) 0);
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + comparable11 + "' != '" + 0L + "'", comparable11.equals(0L));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot7.getDomainAxisEdge();
        boolean boolean9 = xYPlot7.isRangeZoomable();
        xYPlot7.setDomainCrosshairValue(0.0d);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        xYPlot7.removeChangeListener(plotChangeListener12);
        int int14 = xYPlot7.getRangeAxisCount();
        int int15 = xYPlot7.getRangeAxisCount();
        xYPlot7.setBackgroundAlpha((float) 4);
        try {
            xYPlot7.setBackgroundImageAlpha(100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean3 = numberAxis3D2.getAutoRangeIncludesZero();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle7.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle7.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer14.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint19 = lineAndShapeRenderer14.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = lineAndShapeRenderer14.getPlot();
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer14.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color25, true);
        boolean boolean28 = lineAndShapeRenderer14.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = lineAndShapeRenderer14.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { valueAxis31 };
        categoryPlot30.setRangeAxes(valueAxisArray32);
        categoryPlot30.setDrawSharedDomainAxis(false);
        boolean boolean36 = categoryPlot30.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot30.getRangeAxisEdge();
        double double38 = dateAxis4.valueToJava2D(0.0d, rectangle2D10, rectangleEdge37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer39);
        java.util.TimeZone timeZone41 = dateAxis4.getTimeZone();
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone41;
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryPlot20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone41);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean3 = numberAxis3D2.getAutoRangeIncludesZero();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle7.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle7.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer14.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint19 = lineAndShapeRenderer14.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = lineAndShapeRenderer14.getPlot();
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer14.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color25, true);
        boolean boolean28 = lineAndShapeRenderer14.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = lineAndShapeRenderer14.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { valueAxis31 };
        categoryPlot30.setRangeAxes(valueAxisArray32);
        categoryPlot30.setDrawSharedDomainAxis(false);
        boolean boolean36 = categoryPlot30.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot30.getRangeAxisEdge();
        double double38 = dateAxis4.valueToJava2D(0.0d, rectangle2D10, rectangleEdge37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer39);
        java.awt.Stroke stroke41 = dateAxis4.getTickMarkStroke();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryPlot20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        java.awt.Color color0 = java.awt.Color.gray;
        java.awt.Color color2 = java.awt.Color.BLUE;
        java.awt.Color color3 = java.awt.Color.getColor("WMAP_Plot", color2);
        java.awt.Color color4 = java.awt.Color.orange;
        java.awt.Color color6 = org.jfree.chart.util.PaintUtilities.stringToColor("");
        float[] floatArray13 = new float[] { 10, (-1.0f), 0.5f, 10.0f, 3, 9999 };
        float[] floatArray14 = color6.getRGBColorComponents(floatArray13);
        float[] floatArray15 = color4.getRGBComponents(floatArray13);
        float[] floatArray16 = color3.getRGBComponents(floatArray15);
        float[] floatArray17 = color0.getComponents(floatArray15);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxisForDataset(9999);
        org.jfree.chart.util.SortOrder sortOrder3 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str4 = sortOrder3.toString();
        java.lang.String str5 = sortOrder3.toString();
        java.lang.Number number9 = null;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D15 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list16 = defaultKeyedValues2D15.getRowKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem17 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 3.0d, (java.lang.Number) (-1.0f), (java.lang.Number) (short) 100, number9, (java.lang.Number) (-1.0f), (java.lang.Number) 4.0d, (java.lang.Number) 8.0d, (java.lang.Number) 1.0f, list16);
        boolean boolean18 = sortOrder3.equals((java.lang.Object) (short) 100);
        categoryPlot0.setRowRenderingOrder(sortOrder3);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(sortOrder3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "SortOrder.ASCENDING" + "'", str4.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "SortOrder.ASCENDING" + "'", str5.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        double double51 = ringPlot50.getShadowYOffset();
        java.lang.String str52 = ringPlot50.getPlotType();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 4.0d + "'", double51 == 4.0d);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "Pie Plot" + "'", str52.equals("Pie Plot"));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis1.hasListener(eventListener2);
        categoryAxis1.setTickMarkInsideLength((float) 100L);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) ' ');
        org.jfree.chart.block.BlockBorder blockBorder8 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint9 = blockBorder8.getPaint();
        org.jfree.chart.block.LabelBlock labelBlock10 = new org.jfree.chart.block.LabelBlock("2019", font7, paint9);
        java.lang.String str11 = labelBlock10.getToolTipText();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.DateAxis dateAxis13 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle16.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D19 = textTitle16.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = lineAndShapeRenderer23.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint28 = lineAndShapeRenderer23.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = lineAndShapeRenderer23.getPlot();
        java.awt.Color color34 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer23.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color34, true);
        boolean boolean37 = lineAndShapeRenderer23.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier38 = lineAndShapeRenderer23.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer23);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray41 = new org.jfree.chart.axis.ValueAxis[] { valueAxis40 };
        categoryPlot39.setRangeAxes(valueAxisArray41);
        categoryPlot39.setDrawSharedDomainAxis(false);
        boolean boolean45 = categoryPlot39.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot39.getRangeAxisEdge();
        double double47 = dateAxis13.valueToJava2D(0.0d, rectangle2D19, rectangleEdge46);
        java.awt.Shape shape50 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D19, (double) 15, (double) 1900);
        try {
            labelBlock10.draw(graphics2D12, rectangle2D19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(rectangle2D19);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(categoryPlot29);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNull(drawingSupplier38);
        org.junit.Assert.assertNotNull(valueAxisArray41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(shape50);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = levelRenderer0.getBaseItemLabelGenerator();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] { valueAxis23 };
        categoryPlot22.setRangeAxes(valueAxisArray24);
        categoryPlot22.mapDatasetToDomainAxis(4, 9);
        org.jfree.chart.title.TextTitle textTitle30 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle30.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle30.getBounds();
        try {
            levelRenderer0.drawBackground(graphics2D2, categoryPlot22, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryItemLabelGenerator1);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(valueAxisArray24);
        org.junit.Assert.assertNotNull(rectangle2D33);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        double double2 = range0.constrain((double) 0L);
        double double4 = range0.constrain(0.0d);
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot19.markerChanged(markerChangeEvent28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        float float31 = jFreeChart30.getBackgroundImageAlpha();
        org.jfree.chart.title.Title title33 = jFreeChart30.getSubtitle(0);
        jFreeChart30.setNotify(true);
        org.jfree.chart.title.LegendTitle legendTitle36 = jFreeChart30.getLegend();
        java.awt.RenderingHints renderingHints37 = jFreeChart30.getRenderingHints();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.5f + "'", float31 == 0.5f);
        org.junit.Assert.assertNotNull(title33);
        org.junit.Assert.assertNotNull(legendTitle36);
        org.junit.Assert.assertNotNull(renderingHints37);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color2 = java.awt.Color.magenta;
        valueMarker1.setOutlinePaint((java.awt.Paint) color2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int5 = color4.getGreen();
        valueMarker1.setOutlinePaint((java.awt.Paint) color4);
        java.awt.Color color7 = java.awt.Color.magenta;
        valueMarker1.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener11 = null;
        boolean boolean12 = categoryAxis10.hasListener(eventListener11);
        categoryAxis10.setTickMarkInsideLength((float) 100L);
        java.awt.Font font16 = categoryAxis10.getTickLabelFont((java.lang.Comparable) ' ');
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.CENTER_LEFT", font16);
        valueMarker1.setLabelFont(font16);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = lineAndShapeRenderer22.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint27 = lineAndShapeRenderer22.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = lineAndShapeRenderer22.getPlot();
        java.awt.Color color33 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer22.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color33, true);
        boolean boolean36 = lineAndShapeRenderer22.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier37 = lineAndShapeRenderer22.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer42 = null;
        categoryPlot38.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker41, layer42);
        boolean boolean44 = categoryPlot38.isRangeZoomable();
        java.lang.String str45 = categoryPlot38.getPlotType();
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot38);
        java.lang.Object obj47 = categoryPlot38.clone();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(categoryPlot28);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(drawingSupplier37);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Category Plot" + "'", str45.equals("Category Plot"));
        org.junit.Assert.assertNotNull(obj47);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D30.setVerticalTickLabels(true);
        org.jfree.data.Range range33 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        java.text.NumberFormat numberFormat34 = null;
        numberAxis3D30.setNumberFormatOverride(numberFormat34);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent36 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis3D30);
        double double37 = numberAxis3D30.getLowerMargin();
        org.jfree.data.Range range38 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D39 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D39.removeCategoryLabelToolTip((java.lang.Comparable) "2019");
        boolean boolean42 = range38.equals((java.lang.Object) categoryAxis3D39);
        numberAxis3D30.setRangeWithMargins(range38, false, true);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.05d + "'", double37 == 0.05d);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis1.hasListener(eventListener2);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = lineAndShapeRenderer8.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint13 = lineAndShapeRenderer8.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = lineAndShapeRenderer8.getPlot();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer8.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color19, true);
        boolean boolean22 = lineAndShapeRenderer8.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = lineAndShapeRenderer8.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer8);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray26 = new org.jfree.chart.axis.ValueAxis[] { valueAxis25 };
        categoryPlot24.setRangeAxes(valueAxisArray26);
        categoryPlot24.setDrawSharedDomainAxis(false);
        java.awt.Font font30 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean31 = categoryPlot24.equals((java.lang.Object) font30);
        categoryPlot24.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D35.setVerticalTickLabels(true);
        org.jfree.data.Range range38 = categoryPlot24.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D35);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer39 = null;
        org.jfree.chart.plot.PolarPlot polarPlot40 = new org.jfree.chart.plot.PolarPlot(xYDataset4, (org.jfree.chart.axis.ValueAxis) numberAxis3D35, polarItemRenderer39);
        org.jfree.data.xy.XYDataset xYDataset41 = polarPlot40.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis42 = polarPlot40.getAxis();
        polarPlot40.setRadiusGridlinesVisible(true);
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) polarPlot40);
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year();
        boolean boolean48 = year46.equals((java.lang.Object) 1.0d);
        java.awt.Font font49 = categoryAxis1.getTickLabelFont((java.lang.Comparable) boolean48);
        java.awt.Color color51 = org.jfree.chart.util.PaintUtilities.stringToColor("");
        float[] floatArray58 = new float[] { 10, (-1.0f), 0.5f, 10.0f, 3, 9999 };
        float[] floatArray59 = color51.getRGBColorComponents(floatArray58);
        org.jfree.chart.text.TextFragment textFragment61 = new org.jfree.chart.text.TextFragment("{0}", font49, (java.awt.Paint) color51, 0.5f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryPlot14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(drawingSupplier23);
        org.junit.Assert.assertNotNull(valueAxisArray26);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertNull(xYDataset41);
        org.junit.Assert.assertNotNull(valueAxis42);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(font49);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNotNull(floatArray58);
        org.junit.Assert.assertNotNull(floatArray59);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        try {
            org.jfree.data.time.SerialDate serialDate3 = serialDate1.getPreviousDayOfWeek((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = textTitle1.getPosition();
        boolean boolean3 = textTitle1.getExpandToFitSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = textTitle1.getPosition();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment5 = textTitle1.getHorizontalAlignment();
        java.lang.Object obj6 = null;
        boolean boolean7 = textTitle1.equals(obj6);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(horizontalAlignment5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(4.0d, Double.NaN);
        stackedBarRenderer3D2.setAutoPopulateSeriesStroke(true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        java.util.List list4 = defaultCategoryDataset0.getRowKeys();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D6 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int10 = dateTickUnit9.getCalendarField();
        int int11 = dateTickUnit9.getCalendarField();
        defaultKeyedValues2D6.setValue((java.lang.Number) (byte) 0, (java.lang.Comparable) 0L, (java.lang.Comparable) int11);
        boolean boolean13 = defaultCategoryDataset0.equals((java.lang.Object) defaultKeyedValues2D6);
        org.jfree.data.Range range14 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(range14);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle5.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle5.getBounds();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener10 = null;
        boolean boolean11 = categoryAxis9.hasListener(eventListener10);
        categoryAxis9.setFixedDimension((double) (short) -1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = lineAndShapeRenderer21.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint26 = lineAndShapeRenderer21.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = lineAndShapeRenderer21.getPlot();
        java.awt.Color color32 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer21.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color32, true);
        boolean boolean35 = lineAndShapeRenderer21.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier36 = lineAndShapeRenderer21.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer21);
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer41 = null;
        categoryPlot37.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker40, layer41);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot37.getRangeAxisEdge(10);
        double double45 = categoryAxis9.getCategoryJava2DCoordinate(categoryAnchor14, (int) 'a', 2, rectangle2D17, rectangleEdge44);
        double double46 = dateAxis2.valueToJava2D((double) (short) 100, rectangle2D8, rectangleEdge44);
        plotRenderingInfo1.setPlotArea(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(categoryPlot27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(drawingSupplier36);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 6);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.ValueAxis valueAxis2 = categoryPlot0.getRangeAxisForDataset(9999);
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline6 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = lineAndShapeRenderer10.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint15 = lineAndShapeRenderer10.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = lineAndShapeRenderer10.getPlot();
        java.awt.Color color21 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer10.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color21, true);
        boolean boolean24 = lineAndShapeRenderer10.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = lineAndShapeRenderer10.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer10);
        org.jfree.chart.plot.ValueMarker valueMarker29 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer30 = null;
        categoryPlot26.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker29, layer30);
        java.awt.Paint paint32 = categoryPlot26.getBackgroundPaint();
        boolean boolean33 = segmentedTimeline6.equals((java.lang.Object) categoryPlot26);
        java.awt.Font font35 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint36 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer39 = null;
        org.jfree.chart.text.TextBlock textBlock40 = org.jfree.chart.text.TextUtilities.createTextBlock("", font35, paint36, (float) '#', (int) (byte) -1, textMeasurer39);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment41 = textBlock40.getLineAlignment();
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.util.Size2D size2D43 = textBlock40.calculateDimensions(graphics2D42);
        boolean boolean44 = categoryPlot26.equals((java.lang.Object) size2D43);
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D48 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D48.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset46, (org.jfree.chart.axis.ValueAxis) numberAxis3D48, valueAxis51, xYItemRenderer52);
        org.jfree.chart.axis.AxisLocation axisLocation55 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot53.setDomainAxisLocation((int) '4', axisLocation55);
        categoryPlot26.setRangeAxisLocation(0, axisLocation55);
        boolean boolean58 = categoryPlot26.isSubplot();
        boolean boolean59 = categoryPlot0.equals((java.lang.Object) boolean58);
        org.junit.Assert.assertNull(valueAxis2);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryPlot16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(drawingSupplier25);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNotNull(textBlock40);
        org.junit.Assert.assertNotNull(horizontalAlignment41);
        org.junit.Assert.assertNotNull(size2D43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(axisLocation55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.plot.PolarPlot polarPlot0 = new org.jfree.chart.plot.PolarPlot();
        java.awt.Paint paint1 = null;
        polarPlot0.setRadiusGridlinePaint(paint1);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("2019", graphics2D1, (float) (short) 0, 0.0f, textAnchor4, (double) 3, textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint(0);
        org.junit.Assert.assertNull(paint2);
    }

//    @Test
//    public void test403() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test403");
//        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
//        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("rect", (org.jfree.data.time.TimePeriod) month1);
//        long long3 = month1.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = month1.previous();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1559372400000L + "'", long3 == 1559372400000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod4);
//    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent28 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.LegendItemCollection legendItemCollection29 = new org.jfree.chart.LegendItemCollection();
        categoryPlot19.setFixedLegendItems(legendItemCollection29);
        categoryPlot19.setWeight((int) (short) 10);
        java.awt.Paint paint33 = categoryPlot19.getOutlinePaint();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(paint33);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot7.getRenderer((int) (short) 0);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer13.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint18 = lineAndShapeRenderer13.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = lineAndShapeRenderer13.getPlot();
        java.awt.Color color24 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer13.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color24, true);
        boolean boolean27 = lineAndShapeRenderer13.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = lineAndShapeRenderer13.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer13);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray31 = new org.jfree.chart.axis.ValueAxis[] { valueAxis30 };
        categoryPlot29.setRangeAxes(valueAxisArray31);
        categoryPlot29.setDrawSharedDomainAxis(false);
        java.awt.Font font35 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean36 = categoryPlot29.equals((java.lang.Object) font35);
        categoryPlot29.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D40 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D40.setVerticalTickLabels(true);
        org.jfree.data.Range range43 = categoryPlot29.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D40);
        xYPlot7.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis3D40);
        java.awt.Stroke stroke45 = xYPlot7.getDomainCrosshairStroke();
        org.jfree.chart.axis.AxisSpace axisSpace46 = xYPlot7.getFixedRangeAxisSpace();
        java.awt.Stroke stroke47 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        xYPlot7.setDomainZeroBaselineStroke(stroke47);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(categoryPlot19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(valueAxisArray31);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(range43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNull(axisSpace46);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.ChartProgressListener chartProgressListener24 = null;
        jFreeChart23.removeProgressListener(chartProgressListener24);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        java.awt.Paint paint16 = null;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape4, stroke13, paint16);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity20 = new org.jfree.chart.entity.TickLabelEntity(shape4, "({0}, {1}) = {3} - {4}", "org.jfree.chart.event.ChartChangeEvent[source=]");
        java.lang.String str21 = tickLabelEntity20.getShapeCoords();
        java.lang.String str22 = tickLabelEntity20.toString();
        java.lang.String str23 = tickLabelEntity20.getShapeType();
        java.lang.Object obj24 = null;
        boolean boolean25 = tickLabelEntity20.equals(obj24);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-4,-4,4,4" + "'", str21.equals("-4,-4,4,4"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ChartEntity: tooltip = ({0}, {1}) = {3} - {4}" + "'", str22.equals("ChartEntity: tooltip = ({0}, {1}) = {3} - {4}"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "rect" + "'", str23.equals("rect"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj2 = objectList0.get(255);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 255, 0L, (short) 100, (-1.0d), (-1) };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 255, 0L, (short) 100, (-1.0d), (-1) };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 255, 0L, (short) 100, (-1.0d), (-1) };
        java.lang.Number[] numberArray24 = new java.lang.Number[] { 255, 0L, (short) 100, (-1.0d), (-1) };
        java.lang.Number[] numberArray30 = new java.lang.Number[] { 255, 0L, (short) 100, (-1.0d), (-1) };
        java.lang.Number[][] numberArray31 = new java.lang.Number[][] { numberArray6, numberArray12, numberArray18, numberArray24, numberArray30 };
        java.lang.Number[][] numberArray32 = null;
        org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset33 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray31, numberArray32);
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray24);
        org.junit.Assert.assertNotNull(numberArray30);
        org.junit.Assert.assertNotNull(numberArray31);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        java.awt.Stroke stroke2 = barRenderer3D0.lookupSeriesStroke(0);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot7.getDomainAxisEdge();
        boolean boolean9 = xYPlot7.isRangeZoomable();
        xYPlot7.setDomainZeroBaselineVisible(true);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.data.Range range26 = categoryPlot19.getDataRange(valueAxis25);
        org.jfree.chart.plot.Plot plot27 = categoryPlot19.getRootPlot();
        boolean boolean28 = categoryPlot19.isDomainGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot19.getRangeAxisEdge();
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = categoryPlot19.getDomainMarkers(layer30);
        categoryPlot19.clearDomainAxes();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(plot27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNull(collection31);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("rect", (org.jfree.data.time.TimePeriod) month1);
        java.lang.String str3 = task2.getDescription();
        task2.setPercentComplete((-16.0d));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "rect" + "'", str3.equals("rect"));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot7.getDomainAxisEdge();
        boolean boolean9 = xYPlot7.isRangeZoomable();
        xYPlot7.setDomainCrosshairValue(0.0d);
        boolean boolean12 = xYPlot7.isRangeZeroBaselineVisible();
        boolean boolean13 = xYPlot7.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.lang.Object obj2 = standardGradientPaintTransformer1.clone();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent28 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.LegendItemCollection legendItemCollection29 = new org.jfree.chart.LegendItemCollection();
        categoryPlot19.setFixedLegendItems(legendItemCollection29);
        categoryPlot19.clearDomainAxes();
        java.util.List list32 = categoryPlot19.getCategories();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNull(list32);
    }
}

