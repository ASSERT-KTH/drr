import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.lang.String str0 = org.jfree.chart.labels.IntervalCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str0.equals("({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator2 = null;
        try {
            lineAndShapeRenderer0.setSeriesItemLabelGenerator((int) (byte) -1, categoryItemLabelGenerator2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((int) (byte) -1, (int) (byte) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.awt.Color color1 = java.awt.Color.yellow;
        java.awt.Stroke stroke2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        java.awt.Stroke stroke17 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) ' ', (java.awt.Paint) color1, stroke2, (java.awt.Paint) color14, stroke17, (float) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        int int0 = org.jfree.data.time.SerialDate.MAXIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9999 + "'", int0 == 9999);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.Stroke stroke1 = null;
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder3 = new org.jfree.chart.block.LineBorder((java.awt.Paint) color0, stroke1, rectangleInsets2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        java.lang.String[] strArray3 = new java.lang.String[] { "", "", "hi!" };
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 1.0d };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 1.0d };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 1.0d };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 1.0d };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 1.0d };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 1.0d };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray5, numberArray7, numberArray9, numberArray11, numberArray13, numberArray15 };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 1.0f, 0.0d, (short) -1, 10L, (short) 10 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 1.0f, 0.0d, (short) -1, 10L, (short) 10 };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray22, numberArray28 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset30 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray3, numberArray16, numberArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray3);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Stroke stroke0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Paint paint17 = null;
        try {
            lineAndShapeRenderer0.setBaseOutlinePaint(paint17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        try {
            org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit((int) '#', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DateTickUnit.getMillisecondCount() : unit must be one of the constants YEAR, MONTH, DAY, HOUR, MINUTE, SECOND or MILLISECOND defined in the DateTickUnit class. Do *not* use the constants defined in java.util.Calendar.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.lang.String[] strArray4 = new java.lang.String[] { "", "hi!", "hi!", "({0}, {1}) = {3} - {4}" };
        java.lang.Number[][] numberArray5 = new java.lang.Number[][] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 6 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 6 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 6 };
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 6 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 6 };
        java.lang.Number[][] numberArray16 = new java.lang.Number[][] { numberArray7, numberArray9, numberArray11, numberArray13, numberArray15 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset17 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray4, numberArray5, numberArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray16);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        double double0 = org.jfree.chart.renderer.category.BarRenderer3D.DEFAULT_X_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 12.0d + "'", double0 == 12.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.event.RendererChangeListener rendererChangeListener6 = null;
        try {
            lineAndShapeRenderer0.addChangeListener(rendererChangeListener6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        int int0 = org.jfree.data.time.SerialDate.SERIAL_LOWER_BOUND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.jfree.data.time.SerialDate.SATURDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 7 + "'", int0 == 7);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setFixedDimension((double) (short) -1);
        org.jfree.chart.event.AxisChangeListener axisChangeListener5 = null;
        categoryAxis0.addChangeListener(axisChangeListener5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        java.awt.Paint paint16 = null;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape4, stroke13, paint16);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer18 = null;
        try {
            legendItem17.setFillPaintTransformer(gradientPaintTransformer18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "", jFreeChart1);
        java.lang.String str3 = chartChangeEvent2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=]"));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("({0}, {1}) = {3} - {4}", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.contains(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset3 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (short) 100, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getPreviousDayOfWeek(0, serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            org.jfree.data.Range range2 = new org.jfree.data.Range((double) 100L, (double) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (35.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 100.0f);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions1, categoryLabelPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'top' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.axis.AxisLocation axisLocation25 = null;
        try {
            categoryPlot19.setRangeAxisLocation(axisLocation25, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.lang.Class class0 = null;
        java.util.Date date1 = null;
        java.util.TimeZone timeZone2 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date1, timeZone2);
        org.junit.Assert.assertNull(regularTimePeriod3);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) "", jFreeChart1);
        org.jfree.chart.JFreeChart jFreeChart3 = chartChangeEvent2.getChart();
        org.junit.Assert.assertNull(jFreeChart3);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        int int0 = org.jfree.chart.axis.DateTickUnit.HOUR;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions((double) (short) 0);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.text.TextUtilities.setUseDrawRotatedStringWorkaround(true);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setMaximumBarWidth((double) ' ');
        org.jfree.chart.block.Arrangement arrangement3 = null;
        org.jfree.chart.block.Arrangement arrangement4 = null;
        try {
            org.jfree.chart.title.LegendTitle legendTitle5 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0, arrangement3, arrangement4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.PolarPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.geom.Point2D point2D1 = org.jfree.chart.util.SerialUtilities.readPoint2D(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_Y_OFFSET;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 8.0d + "'", double0 == 8.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("org.jfree.chart.event.ChartChangeEvent[source=]", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) 1);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Sunday" + "'", str1.equals("Sunday"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.lang.Class class1 = null;
        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("({0}, {1}) = {3} - {4}", class1);
        org.junit.Assert.assertNull(uRL2);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        try {
            defaultKeyedValues2D1.removeRow((java.lang.Comparable) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        int int0 = org.jfree.data.time.SerialDate.THURSDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 0.5f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder25 = categoryPlot19.getDatasetRenderingOrder();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor26 = null;
        try {
            categoryPlot19.setDomainGridlinePosition(categoryAnchor26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(datasetRenderingOrder25);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = lineAndShapeRenderer1.getNegativeItemLabelPosition((int) ' ', 100);
        lineAndShapeRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition4);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        java.text.DateFormat dateFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("Sunday", dateFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) 3, 100.0d, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D30.setVerticalTickLabels(true);
        org.jfree.data.Range range33 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        org.jfree.data.Range range34 = null;
        try {
            numberAxis3D30.setRangeWithMargins(range34, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range33);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        java.awt.Color color0 = java.awt.Color.WHITE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.lang.String[] strArray0 = new java.lang.String[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] { 6, 2, 0.0d };
        java.lang.Number[] numberArray8 = new java.lang.Number[] { 6, 2, 0.0d };
        java.lang.Number[][] numberArray9 = new java.lang.Number[][] { numberArray4, numberArray8 };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] {};
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset11 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray9, numberArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = new org.jfree.chart.axis.DateTickUnit((int) (byte) 1, (int) (short) 100);
        java.util.Date date3 = null;
        java.util.TimeZone timeZone4 = null;
        try {
            java.util.Date date5 = dateTickUnit2.addToDate(date3, timeZone4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setFixedDimension((double) (short) -1);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) '4');
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener11 = null;
        boolean boolean12 = categoryAxis10.hasListener(eventListener11);
        categoryAxis10.setFixedDimension((double) (short) -1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor15 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = lineAndShapeRenderer22.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint27 = lineAndShapeRenderer22.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = lineAndShapeRenderer22.getPlot();
        java.awt.Color color33 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer22.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color33, true);
        boolean boolean36 = lineAndShapeRenderer22.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier37 = lineAndShapeRenderer22.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer22);
        org.jfree.chart.plot.ValueMarker valueMarker41 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer42 = null;
        categoryPlot38.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker41, layer42);
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot38.getRangeAxisEdge(10);
        double double46 = categoryAxis10.getCategoryJava2DCoordinate(categoryAnchor15, (int) 'a', 2, rectangle2D18, rectangleEdge45);
        try {
            double double47 = categoryAxis0.getCategoryEnd(6, (int) (byte) -1, rectangle2D9, rectangleEdge45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(categoryPlot28);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(drawingSupplier37);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot22.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.Range range29 = categoryPlot22.getDataRange(valueAxis28);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = categoryPlot22.getDatasetRenderingOrder();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = lineAndShapeRenderer35.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint40 = lineAndShapeRenderer35.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = lineAndShapeRenderer35.getPlot();
        java.awt.Color color46 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer35.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color46, true);
        boolean boolean49 = lineAndShapeRenderer35.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier50 = lineAndShapeRenderer35.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset32, categoryAxis33, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer35);
        org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer55 = null;
        categoryPlot51.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker54, layer55);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = categoryPlot51.getRangeAxisEdge(10);
        org.jfree.chart.axis.AxisSpace axisSpace59 = new org.jfree.chart.axis.AxisSpace();
        try {
            org.jfree.chart.axis.AxisSpace axisSpace60 = numberAxis3D1.reserveSpace(graphics2D2, (org.jfree.chart.plot.Plot) categoryPlot22, rectangle2D31, rectangleEdge58, axisSpace59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNotNull(itemLabelPosition38);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNull(categoryPlot41);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(drawingSupplier50);
        org.junit.Assert.assertNotNull(rectangleEdge58);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D30.setVerticalTickLabels(true);
        org.jfree.data.Range range33 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryPlot19.getInsets();
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D36 = rectangleInsets34.createOutsetRectangle(rectangle2D35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        java.lang.Number[][] numberArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "", numberArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        java.awt.Paint paint16 = null;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape4, stroke13, paint16);
        java.lang.String str18 = legendItem17.getToolTipText();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint7 = lineAndShapeRenderer2.lookupSeriesPaint((int) (byte) -1);
        boolean boolean8 = barRenderer0.equals((java.lang.Object) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.data.time.SerialDate serialDate1 = null;
        try {
            org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.getNearestDayOfWeek((int) ' ', serialDate1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorUp(8.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) '#', (int) (byte) -1, textMeasurer6);
        java.awt.Color color8 = java.awt.Color.ORANGE;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener10 = null;
        boolean boolean11 = categoryAxis9.hasListener(eventListener10);
        categoryAxis9.setFixedDimension((double) (short) -1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = lineAndShapeRenderer21.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint26 = lineAndShapeRenderer21.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = lineAndShapeRenderer21.getPlot();
        java.awt.Color color32 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer21.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color32, true);
        boolean boolean35 = lineAndShapeRenderer21.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier36 = lineAndShapeRenderer21.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer21);
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer41 = null;
        categoryPlot37.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker40, layer41);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot37.getRangeAxisEdge(10);
        double double45 = categoryAxis9.getCategoryJava2DCoordinate(categoryAnchor14, (int) 'a', 2, rectangle2D17, rectangleEdge44);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment46 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment47 = null;
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition54 = lineAndShapeRenderer51.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint56 = lineAndShapeRenderer51.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = lineAndShapeRenderer51.getPlot();
        java.awt.Color color62 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer51.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color62, true);
        boolean boolean65 = lineAndShapeRenderer51.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier66 = lineAndShapeRenderer51.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, valueAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer51);
        org.jfree.chart.axis.ValueAxis valueAxis68 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray69 = new org.jfree.chart.axis.ValueAxis[] { valueAxis68 };
        categoryPlot67.setRangeAxes(valueAxisArray69);
        categoryPlot67.setDrawSharedDomainAxis(false);
        java.awt.Font font73 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean74 = categoryPlot67.equals((java.lang.Object) font73);
        categoryPlot67.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D78 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D78.setVerticalTickLabels(true);
        org.jfree.data.Range range81 = categoryPlot67.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D78);
        org.jfree.chart.util.RectangleInsets rectangleInsets82 = categoryPlot67.getInsets();
        try {
            org.jfree.chart.title.TextTitle textTitle83 = new org.jfree.chart.title.TextTitle("({0}, {1}) = {3} - {4}", font2, (java.awt.Paint) color8, rectangleEdge44, horizontalAlignment46, verticalAlignment47, rectangleInsets82);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'horizontalAlignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(categoryPlot27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(drawingSupplier36);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition54);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNull(categoryPlot57);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNull(drawingSupplier66);
        org.junit.Assert.assertNotNull(valueAxisArray69);
        org.junit.Assert.assertNotNull(font73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNull(range81);
        org.junit.Assert.assertNotNull(rectangleInsets82);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("Sunday", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D30.setVerticalTickLabels(true);
        org.jfree.data.Range range33 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryPlot19.getInsets();
        double double36 = rectangleInsets34.calculateLeftInset((-1.0d));
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 8.0d + "'", double36 == 8.0d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        java.awt.Paint paint16 = null;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape4, stroke13, paint16);
        int int18 = legendItem17.getDatasetIndex();
        boolean boolean19 = legendItem17.isShapeFilled();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
        try {
            java.lang.Comparable comparable4 = defaultKeyedValues2D1.getColumnKey((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        try {
            java.lang.String str3 = standardCategoryToolTipGenerator0.generateColumnLabel(categoryDataset1, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        try {
            org.jfree.chart.title.Title title29 = jFreeChart27.getSubtitle(5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer7.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint12 = lineAndShapeRenderer7.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = lineAndShapeRenderer7.getPlot();
        java.awt.Color color18 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer7.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color18, true);
        boolean boolean21 = lineAndShapeRenderer7.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = lineAndShapeRenderer7.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer27 = null;
        categoryPlot23.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer27);
        java.awt.Paint paint29 = categoryPlot23.getBackgroundPaint();
        boolean boolean30 = segmentedTimeline3.equals((java.lang.Object) categoryPlot23);
        java.util.Date date31 = null;
        try {
            segmentedTimeline3.addBaseTimelineException(date31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryPlot13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        java.lang.Class class1 = null;
        try {
            java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceRelativeAsStream("hi!", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        int int0 = org.jfree.data.time.MonthConstants.AUGUST;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("");
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        java.lang.Comparable comparable3 = null;
        try {
            defaultCategoryDataset0.addValue((double) 100, (java.lang.Comparable) 0, comparable3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setFixedDimension((double) (short) -1);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = lineAndShapeRenderer8.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint13 = lineAndShapeRenderer8.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = lineAndShapeRenderer8.getPlot();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer8.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color19, true);
        lineAndShapeRenderer8.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Paint paint27 = lineAndShapeRenderer8.getItemLabelPaint(0, 10);
        categoryAxis0.setAxisLinePaint(paint27);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryPlot14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.data.Range range26 = categoryPlot19.getDataRange(valueAxis25);
        org.jfree.chart.plot.Plot plot27 = categoryPlot19.getRootPlot();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = null;
        try {
            categoryPlot19.setRangeAxes(valueAxisArray28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(plot27);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        try {
            java.awt.image.BufferedImage bufferedImage30 = jFreeChart27.createBufferedImage((-1), (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-1) and height (97) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = lineAndShapeRenderer8.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint13 = lineAndShapeRenderer8.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = lineAndShapeRenderer8.getPlot();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer8.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color19, true);
        boolean boolean22 = lineAndShapeRenderer8.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = lineAndShapeRenderer8.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer8);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer28 = null;
        categoryPlot24.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker27, layer28);
        float float30 = categoryPlot24.getBackgroundImageAlpha();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot24.getLegendItems();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener33 = null;
        boolean boolean34 = categoryAxis32.hasListener(eventListener33);
        categoryAxis32.setFixedDimension((double) (short) -1);
        java.awt.Font font38 = categoryAxis32.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent39 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis32);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D41 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean42 = numberAxis3D41.getAutoRangeIncludesZero();
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset44 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range45 = barRenderer43.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset44);
        try {
            stackedAreaRenderer1.drawItem(graphics2D2, categoryItemRendererState3, rectangle2D4, categoryPlot24, categoryAxis32, (org.jfree.chart.axis.ValueAxis) numberAxis3D41, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset44, (int) (byte) 10, 10, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryPlot14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(drawingSupplier23);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 0.5f + "'", float30 == 0.5f);
        org.junit.Assert.assertNotNull(legendItemCollection31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNull(range45);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        boolean boolean0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener27 = null;
        boolean boolean28 = categoryAxis26.hasListener(eventListener27);
        categoryAxis26.setFixedDimension((double) (short) -1);
        java.awt.Font font32 = categoryAxis26.getTickLabelFont((java.lang.Comparable) '4');
        int int33 = categoryAxis26.getMaximumCategoryLabelLines();
        try {
            categoryPlot19.setDomainAxis((-1), categoryAxis26, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.Range range2 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        try {
            defaultCategoryDataset1.removeRow(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset4 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset0, (java.lang.Comparable) (byte) -1, (double) 6, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        java.awt.Shape shape0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        try {
            java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape(shape0, rectangleAnchor1, (double) (short) 1, (double) 0.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setFixedDimension((double) (short) -1);
        boolean boolean5 = categoryAxis0.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        java.awt.Shape shape8 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = lineAndShapeRenderer9.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint14 = lineAndShapeRenderer9.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = lineAndShapeRenderer9.getPlot();
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer9.setSeriesStroke((int) (byte) 1, stroke17, true);
        java.awt.Paint paint20 = null;
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape8, stroke17, paint20);
        java.awt.Paint paint22 = null;
        try {
            org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("", "hi!", "", "org.jfree.chart.event.ChartChangeEvent[source=]", shape8, paint22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(categoryPlot15);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.ChartChangeListener chartChangeListener28 = null;
        try {
            jFreeChart27.removeChangeListener(chartChangeListener28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer0.setBaseStroke(stroke17);
        boolean boolean19 = lineAndShapeRenderer0.getBaseLinesVisible();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Color color16 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer5.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color16, true);
        boolean boolean19 = lineAndShapeRenderer5.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = lineAndShapeRenderer5.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer5);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer25 = null;
        categoryPlot21.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker24, layer25);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot21.getRangeAxisEdge(10);
        try {
            java.awt.geom.Rectangle2D rectangle2D29 = axisSpace0.reserved(rectangle2D1, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer7.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint12 = lineAndShapeRenderer7.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = lineAndShapeRenderer7.getPlot();
        java.awt.Color color18 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer7.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color18, true);
        boolean boolean21 = lineAndShapeRenderer7.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = lineAndShapeRenderer7.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer27 = null;
        categoryPlot23.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer27);
        java.awt.Paint paint29 = categoryPlot23.getBackgroundPaint();
        boolean boolean30 = segmentedTimeline3.equals((java.lang.Object) categoryPlot23);
        boolean boolean31 = categoryPlot23.isDomainZoomable();
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryPlot13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'right' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        boolean boolean14 = lineAndShapeRenderer0.getUseFillPaint();
        lineAndShapeRenderer0.setBaseSeriesVisible(false);
        java.lang.Object obj17 = lineAndShapeRenderer0.clone();
        boolean boolean20 = lineAndShapeRenderer0.getItemShapeFilled(100, 0);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) ' ', 100);
        boolean boolean7 = lineAndShapeRenderer2.isSeriesVisible((int) ' ');
        java.awt.Paint paint8 = lineAndShapeRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=]", font1, paint8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            labelBlock9.draw(graphics2D10, rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString(1, false);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "January" + "'", str2.equals("January"));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Color color0 = java.awt.Color.BLACK;
        java.awt.color.ColorSpace colorSpace1 = null;
        float[] floatArray7 = new float[] { 2, (short) 0, (byte) 100, 'a', (-1L) };
        try {
            float[] floatArray8 = color0.getColorComponents(colorSpace1, floatArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray7);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        columnArrangement0.clear();
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        boolean boolean14 = lineAndShapeRenderer0.getUseFillPaint();
        java.lang.Boolean boolean16 = lineAndShapeRenderer0.getSeriesShapesFilled(0);
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(boolean16);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        boolean boolean2 = gradientPaintTransformType0.equals((java.lang.Object) 0);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
        int int3 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) "");
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        keyToGroupMap1.mapKeyToGroup((java.lang.Comparable) 8, (java.lang.Comparable) dateTickUnit5);
        java.util.Date date7 = null;
        try {
            java.lang.String str8 = dateTickUnit5.dateToString(date7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(dateTickUnit5);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str1 = standardCategoryToolTipGenerator0.getLabelFormat();
        java.lang.String str2 = standardCategoryToolTipGenerator0.getLabelFormat();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "({0}, {1}) = {2}" + "'", str1.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "({0}, {1}) = {2}" + "'", str2.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString((int) '4');
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        try {
            int int1 = org.jfree.data.time.SerialDate.monthCodeToQuarter(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToQuarter: invalid month code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        java.lang.String str1 = lengthConstraintType0.toString();
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "LengthConstraintType.NONE" + "'", str1.equals("LengthConstraintType.NONE"));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 100.0f);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.util.ShapeList shapeList3 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape5 = null;
        shapeList3.setShape((int) (byte) 10, shape5);
        boolean boolean7 = rectangleAnchor2.equals((java.lang.Object) shape5);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str9 = textBlockAnchor8.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition10 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor2, textBlockAnchor8);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions11 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions1, categoryLabelPosition10);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str9.equals("TextBlockAnchor.CENTER_LEFT"));
        org.junit.Assert.assertNotNull(categoryLabelPositions11);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        boolean boolean31 = categoryPlot19.render(graphics2D27, rectangle2D28, (int) (byte) -1, plotRenderingInfo30);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) month0, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D30.setVerticalTickLabels(true);
        org.jfree.data.Range range33 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        java.text.NumberFormat numberFormat34 = null;
        numberAxis3D30.setNumberFormatOverride(numberFormat34);
        numberAxis3D30.setInverted(false);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range33);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setTickMarkInsideLength((float) 100L);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) ' ');
        boolean boolean7 = categoryAxis0.isTickLabelsVisible();
        float float8 = categoryAxis0.getTickMarkInsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis0.getTickLabelInsets();
        double double10 = categoryAxis0.getFixedDimension();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer0 = new org.jfree.chart.renderer.category.StackedBarRenderer();
        stackedBarRenderer0.setIncludeBaseInRange(true);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        java.awt.Font font1 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Font font3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        boolean boolean9 = lineAndShapeRenderer4.isSeriesVisible((int) ' ');
        java.awt.Paint paint10 = lineAndShapeRenderer4.getBaseItemLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=]", font3, paint10);
        org.jfree.chart.text.TextMeasurer textMeasurer14 = null;
        try {
            org.jfree.chart.text.TextBlock textBlock15 = org.jfree.chart.text.TextUtilities.createTextBlock("org.jfree.chart.event.ChartChangeEvent[source=]", font1, paint10, (float) 1L, 7, textMeasurer14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.data.time.SimpleTimePeriod simpleTimePeriod3 = new org.jfree.data.time.SimpleTimePeriod((long) (byte) 1, (long) 5);
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.String[] strArray2 = org.jfree.data.time.SerialDate.getMonths(false);
        boolean boolean3 = booleanList0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(strArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_SHADOW_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        int int3 = defaultCategoryDataset1.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        try {
            java.lang.String str6 = standardCategoryToolTipGenerator0.generateColumnLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int0 = org.jfree.data.time.SerialDate.PRECEDING;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-1) + "'", int0 == (-1));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        java.awt.Font font2 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint3 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer6 = null;
        org.jfree.chart.text.TextBlock textBlock7 = org.jfree.chart.text.TextUtilities.createTextBlock("", font2, paint3, (float) '#', (int) (byte) -1, textMeasurer6);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment8 = textBlock7.getLineAlignment();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.Size2D size2D10 = textBlock7.calculateDimensions(graphics2D9);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.data.general.Dataset dataset12 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent13 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) lineAndShapeRenderer11, dataset12);
        boolean boolean14 = size2D10.equals((java.lang.Object) lineAndShapeRenderer11);
        boolean boolean15 = itemLabelAnchor0.equals((java.lang.Object) boolean14);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(textBlock7);
        org.junit.Assert.assertNotNull(horizontalAlignment8);
        org.junit.Assert.assertNotNull(size2D10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis1.hasListener(eventListener2);
        categoryAxis1.setTickMarkInsideLength((float) 100L);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) ' ');
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.CENTER_LEFT", font7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        try {
            float float11 = textFragment8.calculateBaselineOffset(graphics2D9, textAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(textAnchor10);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D30.setVerticalTickLabels(true);
        org.jfree.data.Range range33 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryPlot19.getInsets();
        double double36 = rectangleInsets34.calculateTopOutset((double) (short) 0);
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D38 = rectangleInsets34.createOutsetRectangle(rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 4.0d + "'", double36 == 4.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        int int2 = defaultKeyedValues2D1.getColumnCount();
        try {
            java.lang.Number number5 = defaultKeyedValues2D1.getValue((int) (byte) 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) ' ', 100);
        boolean boolean7 = lineAndShapeRenderer2.isSeriesVisible((int) ' ');
        java.awt.Paint paint8 = lineAndShapeRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=]", font1, paint8);
        java.lang.String str10 = labelBlock9.getURLText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(str10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str1 = standardCategoryToolTipGenerator0.getLabelFormat();
        java.awt.Font font3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        boolean boolean9 = lineAndShapeRenderer4.isSeriesVisible((int) ' ');
        java.awt.Paint paint10 = lineAndShapeRenderer4.getBaseItemLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=]", font3, paint10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = labelBlock11.getMargin();
        boolean boolean13 = standardCategoryToolTipGenerator0.equals((java.lang.Object) rectangleInsets12);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "({0}, {1}) = {2}" + "'", str1.equals("({0}, {1}) = {2}"));
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis1.hasListener(eventListener2);
        categoryAxis1.setFixedDimension((double) (short) -1);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
        categoryAxis1.configure();
        boolean boolean10 = color0.equals((java.lang.Object) categoryAxis1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent25 = null;
        categoryPlot19.markerChanged(markerChangeEvent25);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean1 = barRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        double double2 = barRenderer3D0.getItemMargin();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer0.setBaseStroke(stroke17);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, true);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = lineAndShapeRenderer31.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint36 = lineAndShapeRenderer31.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = lineAndShapeRenderer31.getPlot();
        java.awt.Color color42 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer31.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color42, true);
        boolean boolean45 = lineAndShapeRenderer31.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier46 = lineAndShapeRenderer31.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer31);
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer51 = null;
        categoryPlot47.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker50, layer51);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot47.getRangeAxisEdge(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = categoryPlot47.getDomainAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener57 = null;
        boolean boolean58 = categoryAxis56.hasListener(eventListener57);
        categoryAxis56.setFixedDimension((double) (short) -1);
        java.awt.Font font62 = categoryAxis56.getTickLabelFont((java.lang.Comparable) '4');
        java.lang.String str64 = categoryAxis56.getCategoryLabelToolTip((java.lang.Comparable) "TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D66 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset67 = new org.jfree.data.category.DefaultCategoryDataset();
        int int69 = defaultCategoryDataset67.getRowIndex((java.lang.Comparable) 2.0d);
        try {
            lineAndShapeRenderer0.drawItem(graphics2D25, categoryItemRendererState26, rectangle2D27, categoryPlot47, categoryAxis56, (org.jfree.chart.axis.ValueAxis) numberAxis3D66, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset67, (int) (short) -1, 3, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(categoryPlot37);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(drawingSupplier46);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertNull(str64);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1) + "'", int69 == (-1));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        boolean boolean2 = stackedAreaRenderer1.getRenderAsPercentages();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate(0, (int) '#', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D1.setVerticalTickLabels(true);
        numberAxis3D1.setLowerBound((double) (byte) 1);
        org.jfree.data.Range range6 = null;
        try {
            numberAxis3D1.setRange(range6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("Category Plot", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.lang.Class class0 = null;
        try {
            java.lang.Class class1 = org.jfree.data.time.RegularTimePeriod.downsize(class0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean1 = barRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot22.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        boolean boolean28 = categoryPlot22.isRangeZoomable();
        java.lang.String str29 = categoryPlot22.getPlotType();
        java.awt.Paint paint30 = categoryPlot22.getBackgroundPaint();
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        try {
            barRenderer3D0.drawBackground(graphics2D2, categoryPlot22, rectangle2D31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "Category Plot" + "'", str29.equals("Category Plot"));
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setTickMarkInsideLength((float) 100L);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) ' ');
        int int7 = categoryAxis0.getCategoryLabelPositionOffset();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer11.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint16 = lineAndShapeRenderer11.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = lineAndShapeRenderer11.getPlot();
        java.awt.Color color22 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer11.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color22, true);
        boolean boolean25 = lineAndShapeRenderer11.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = lineAndShapeRenderer11.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray29 = new org.jfree.chart.axis.ValueAxis[] { valueAxis28 };
        categoryPlot27.setRangeAxes(valueAxisArray29);
        categoryPlot27.clearRangeMarkers();
        categoryAxis0.setPlot((org.jfree.chart.plot.Plot) categoryPlot27);
        categoryAxis0.setCategoryMargin(3.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(categoryPlot17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(valueAxisArray29);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Paint paint28 = jFreeChart27.getBorderPaint();
        org.jfree.chart.event.ChartChangeListener chartChangeListener29 = null;
        try {
            jFreeChart27.addChangeListener(chartChangeListener29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D1.setVerticalTickLabels(true);
        numberAxis3D1.setLowerBound((double) (byte) 1);
        org.jfree.data.Range range6 = null;
        try {
            numberAxis3D1.setDefaultAutoRange(range6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = lineAndShapeRenderer8.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint13 = lineAndShapeRenderer8.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = lineAndShapeRenderer8.getPlot();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer8.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color19, true);
        boolean boolean22 = lineAndShapeRenderer8.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = lineAndShapeRenderer8.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer8);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray26 = new org.jfree.chart.axis.ValueAxis[] { valueAxis25 };
        categoryPlot24.setRangeAxes(valueAxisArray26);
        categoryPlot24.clearRangeMarkers();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener30 = null;
        boolean boolean31 = categoryAxis29.hasListener(eventListener30);
        categoryAxis29.setFixedDimension((double) (short) -1);
        java.awt.Font font35 = categoryAxis29.getTickLabelFont((java.lang.Comparable) '4');
        int int36 = categoryAxis29.getMaximumCategoryLabelLines();
        categoryAxis29.setMaximumCategoryLabelLines(0);
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = lineAndShapeRenderer43.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint48 = lineAndShapeRenderer43.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = lineAndShapeRenderer43.getPlot();
        java.awt.Color color54 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer43.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color54, true);
        boolean boolean57 = lineAndShapeRenderer43.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier58 = lineAndShapeRenderer43.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis42, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer43);
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray61 = new org.jfree.chart.axis.ValueAxis[] { valueAxis60 };
        categoryPlot59.setRangeAxes(valueAxisArray61);
        categoryPlot59.setDrawSharedDomainAxis(false);
        java.awt.Font font65 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean66 = categoryPlot59.equals((java.lang.Object) font65);
        categoryPlot59.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D70 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D70.setVerticalTickLabels(true);
        org.jfree.data.Range range73 = categoryPlot59.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D70);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer74 = null;
        org.jfree.chart.plot.PolarPlot polarPlot75 = new org.jfree.chart.plot.PolarPlot(xYDataset39, (org.jfree.chart.axis.ValueAxis) numberAxis3D70, polarItemRenderer74);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset76 = new org.jfree.data.category.DefaultCategoryDataset();
        try {
            stackedAreaRenderer1.drawItem(graphics2D2, categoryItemRendererState3, rectangle2D4, categoryPlot24, categoryAxis29, (org.jfree.chart.axis.ValueAxis) numberAxis3D70, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset76, 3, 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryPlot14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(drawingSupplier23);
        org.junit.Assert.assertNotNull(valueAxisArray26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(itemLabelPosition46);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNull(categoryPlot49);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(drawingSupplier58);
        org.junit.Assert.assertNotNull(valueAxisArray61);
        org.junit.Assert.assertNotNull(font65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNull(range73);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean2 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot22.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.Range range29 = categoryPlot22.getDataRange(valueAxis28);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = categoryPlot22.getDatasetRenderingOrder();
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        numberAxis3D1.setRangeAboutValue((double) 4, (double) '#');
        org.jfree.data.Range range35 = null;
        try {
            numberAxis3D1.setRangeWithMargins(range35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.general.DatasetGroup datasetGroup1 = null;
        try {
            taskSeriesCollection0.setGroup(datasetGroup1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'group' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        blockParams0.setTranslateX(1.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            int int4 = taskSeriesCollection0.getSubIntervalCount((java.lang.Comparable) "January", (java.lang.Comparable) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot19.markerChanged(markerChangeEvent28);
        categoryPlot19.mapDatasetToRangeAxis((int) '#', (int) 'a');
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis1.hasListener(eventListener2);
        categoryAxis1.setTickMarkInsideLength((float) 100L);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) ' ');
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.CENTER_LEFT", font7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor12 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor12, textAnchor13);
        org.jfree.chart.text.TextAnchor textAnchor15 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        boolean boolean16 = itemLabelPosition14.equals((java.lang.Object) textAnchor15);
        try {
            textFragment8.draw(graphics2D9, (float) 4, (float) 0, textAnchor15, (float) 'a', 0.5f, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(itemLabelAnchor12);
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertNotNull(textAnchor15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.lang.Number number1 = null;
        java.lang.Number number3 = null;
        java.lang.Number number7 = null;
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 3, number1, (java.lang.Number) 10, number3, (java.lang.Number) 12.0d, (java.lang.Number) 10.0f, (java.lang.Number) (short) 1, number7, list8);
        java.util.List list10 = boxAndWhiskerItem9.getOutliers();
        org.junit.Assert.assertNull(list10);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, 0.2d, (float) 0L, (float) (-1L));
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer0.setBaseStroke(stroke17);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator19);
        boolean boolean22 = lineAndShapeRenderer0.equals((java.lang.Object) (short) 10);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        double double1 = layeredBarRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        int int0 = org.jfree.data.time.SerialDate.MINIMUM_YEAR_SUPPORTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1900 + "'", int0 == 1900);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.lang.Boolean boolean2 = lineAndShapeRenderer0.getSeriesCreateEntities(6);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = lineAndShapeRenderer0.getItemLabelGenerator((int) (byte) 0, 3);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.Number number3 = taskSeriesCollection0.getValue((int) (byte) -1, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer0.setBaseStroke(stroke17);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        lineAndShapeRenderer0.setSeriesItemLabelGenerator(0, categoryItemLabelGenerator22, true);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator25 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator25);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            int int5 = taskSeriesCollection0.getSubIntervalCount((-1), 5);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean2 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot22.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.Range range29 = categoryPlot22.getDataRange(valueAxis28);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = categoryPlot22.getDatasetRenderingOrder();
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        java.awt.Shape shape32 = numberAxis3D1.getDownArrow();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number5 = taskSeriesCollection0.getPercentComplete(0, (int) ' ', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.util.Date date0 = null;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.LEVEL;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.Point2D point2D4 = null;
        org.jfree.chart.plot.PlotState plotState5 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        try {
            waferMapPlot1.draw(graphics2D2, rectangle2D3, point2D4, plotState5, plotRenderingInfo6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color2 = java.awt.Color.magenta;
        valueMarker1.setOutlinePaint((java.awt.Paint) color2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int5 = color4.getGreen();
        valueMarker1.setOutlinePaint((java.awt.Paint) color4);
        java.awt.Color color7 = java.awt.Color.magenta;
        valueMarker1.setLabelPaint((java.awt.Paint) color7);
        try {
            valueMarker1.setAlpha((float) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot19.markerChanged(markerChangeEvent28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = new org.jfree.chart.ChartRenderingInfo();
        try {
            java.awt.image.BufferedImage bufferedImage35 = jFreeChart30.createBufferedImage((int) (byte) 10, 0, (int) (byte) 0, chartRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.ChartProgressListener chartProgressListener28 = null;
        jFreeChart27.removeProgressListener(chartProgressListener28);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent30 = null;
        try {
            jFreeChart27.titleChanged(titleChangeEvent30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline7 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer11.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint16 = lineAndShapeRenderer11.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = lineAndShapeRenderer11.getPlot();
        java.awt.Color color22 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer11.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color22, true);
        boolean boolean25 = lineAndShapeRenderer11.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier26 = lineAndShapeRenderer11.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer31 = null;
        categoryPlot27.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker30, layer31);
        java.awt.Paint paint33 = categoryPlot27.getBackgroundPaint();
        boolean boolean34 = segmentedTimeline7.equals((java.lang.Object) categoryPlot27);
        java.awt.Font font36 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint37 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer40 = null;
        org.jfree.chart.text.TextBlock textBlock41 = org.jfree.chart.text.TextUtilities.createTextBlock("", font36, paint37, (float) '#', (int) (byte) -1, textMeasurer40);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment42 = textBlock41.getLineAlignment();
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.util.Size2D size2D44 = textBlock41.calculateDimensions(graphics2D43);
        boolean boolean45 = categoryPlot27.equals((java.lang.Object) size2D44);
        try {
            java.lang.Object obj46 = blockContainer1.draw(graphics2D2, rectangle2D3, (java.lang.Object) boolean45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(categoryPlot17);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(drawingSupplier26);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(textBlock41);
        org.junit.Assert.assertNotNull(horizontalAlignment42);
        org.junit.Assert.assertNotNull(size2D44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.weekdayCodeToString((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.text.AttributedString attributedString0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeAttributedString(attributedString0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int5 = dateTickUnit4.getCalendarField();
        int int6 = dateTickUnit4.getCalendarField();
        defaultKeyedValues2D1.setValue((java.lang.Number) (byte) 0, (java.lang.Comparable) 0L, (java.lang.Comparable) int6);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int10 = dateTickUnit9.getCalendarField();
        try {
            defaultKeyedValues2D1.setValue((java.lang.Number) 3.0d, (java.lang.Comparable) dateTickUnit9, (java.lang.Comparable) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.axis.DateTickUnit cannot be cast to java.lang.Long");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        java.awt.Paint paint16 = null;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape4, stroke13, paint16);
        int int18 = legendItem17.getDatasetIndex();
        java.awt.Shape shape19 = legendItem17.getLine();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        java.lang.Comparable comparable23 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity25 = new org.jfree.chart.entity.CategoryItemEntity(shape19, "", "SortOrder.ASCENDING", categoryDataset22, comparable23, (java.lang.Comparable) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D("({0}, {1}) = {2}");
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.FIFTEEN_MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 900000L + "'", long0 == 900000L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = lineAndShapeRenderer8.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint13 = lineAndShapeRenderer8.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = lineAndShapeRenderer8.getPlot();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer8.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color19, true);
        boolean boolean22 = lineAndShapeRenderer8.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = lineAndShapeRenderer8.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer8);
        org.jfree.chart.plot.ValueMarker valueMarker27 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer28 = null;
        categoryPlot24.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker27, layer28);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot24.getRangeAxisEdge(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot24.getDomainAxisEdge();
        try {
            double double33 = categoryAxis0.getCategoryMiddle(1900, 10, rectangle2D4, rectangleEdge32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryPlot14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(drawingSupplier23);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (-1));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedHeight((double) 2);
        org.jfree.data.Range range5 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = rectangleConstraint4.toRangeWidth(range5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        boolean boolean6 = lineAndShapeRenderer0.getItemCreateEntity((int) (byte) -1, (int) (short) 100);
        lineAndShapeRenderer0.setBaseSeriesVisible(true, false);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setTickMarkInsideLength((float) 100L);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) ' ');
        boolean boolean7 = categoryAxis0.isTickLabelsVisible();
        float float8 = categoryAxis0.getTickMarkInsideLength();
        float float9 = categoryAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setTickMarkInsideLength((float) 100L);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) ' ');
        boolean boolean7 = categoryAxis0.isTickLabelsVisible();
        float float8 = categoryAxis0.getTickMarkInsideLength();
        java.awt.Paint paint9 = null;
        try {
            categoryAxis0.setTickMarkPaint(paint9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        java.util.List list4 = defaultCategoryDataset0.getColumnKeys();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = null;
        shapeList0.setShape((int) (byte) 10, shape2);
        java.lang.Object obj4 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color2 = java.awt.Color.magenta;
        valueMarker1.setOutlinePaint((java.awt.Paint) color2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int5 = color4.getGreen();
        valueMarker1.setOutlinePaint((java.awt.Paint) color4);
        java.awt.Color color7 = java.awt.Color.magenta;
        valueMarker1.setLabelPaint((java.awt.Paint) color7);
        org.jfree.chart.block.BlockBorder blockBorder9 = org.jfree.chart.block.BlockBorder.NONE;
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = blockBorder9.getInsets();
        valueMarker1.setLabelOffset(rectangleInsets10);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(blockBorder9);
        org.junit.Assert.assertNotNull(rectangleInsets10);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setTickMarkInsideLength((float) 100L);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) ' ');
        boolean boolean7 = categoryAxis0.isTickLabelsVisible();
        float float8 = categoryAxis0.getTickMarkInsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis0.getTickLabelInsets();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color12 = java.awt.Color.magenta;
        valueMarker11.setOutlinePaint((java.awt.Paint) color12);
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int15 = color14.getGreen();
        valueMarker11.setOutlinePaint((java.awt.Paint) color14);
        categoryAxis0.setTickLabelPaint((java.awt.Paint) color14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color2 = java.awt.Color.magenta;
        valueMarker1.setOutlinePaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = valueMarker1.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setFixedDimension((double) (short) -1);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType8 = axisChangeEvent7.getType();
        org.jfree.chart.JFreeChart jFreeChart9 = axisChangeEvent7.getChart();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(chartChangeEventType8);
        org.junit.Assert.assertNull(jFreeChart9);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.data.Range range26 = categoryPlot19.getDataRange(valueAxis25);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = categoryPlot19.getDatasetRenderingOrder();
        org.jfree.chart.plot.CategoryMarker categoryMarker29 = null;
        org.jfree.chart.util.Layer layer30 = null;
        try {
            categoryPlot19.addDomainMarker(0, categoryMarker29, layer30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Color color1 = java.awt.Color.getColor("ThreadContext");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("ERROR : Relative To String");
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Paint paint28 = jFreeChart27.getBorderPaint();
        org.jfree.chart.event.ChartChangeListener chartChangeListener29 = null;
        try {
            jFreeChart27.removeChangeListener(chartChangeListener29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator2 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator("DateTickUnit[DAY, 1]", numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.block.FlowArrangement flowArrangement0 = new org.jfree.chart.block.FlowArrangement();
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D30.setVerticalTickLabels(true);
        org.jfree.data.Range range33 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        boolean boolean34 = numberAxis3D30.getAutoRangeIncludesZero();
        org.jfree.data.Range range35 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        numberAxis3D30.setRangeWithMargins(range35, false, false);
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.axis.AxisState axisState40 = new org.jfree.chart.axis.AxisState();
        axisState40.cursorDown((-1.0d));
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition50 = lineAndShapeRenderer47.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint52 = lineAndShapeRenderer47.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = lineAndShapeRenderer47.getPlot();
        java.awt.Color color58 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer47.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color58, true);
        boolean boolean61 = lineAndShapeRenderer47.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier62 = lineAndShapeRenderer47.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, valueAxis46, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer47);
        org.jfree.chart.plot.ValueMarker valueMarker66 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer67 = null;
        categoryPlot63.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker66, layer67);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = categoryPlot63.getRangeAxisEdge(10);
        try {
            java.util.List list71 = numberAxis3D30.refreshTicks(graphics2D39, axisState40, rectangle2D43, rectangleEdge70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(itemLabelPosition50);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertNull(categoryPlot53);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNull(drawingSupplier62);
        org.junit.Assert.assertNotNull(rectangleEdge70);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        int int0 = org.jfree.chart.axis.DateTickUnit.MILLISECOND;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = null;
        shapeList0.setShape((int) (byte) 10, shape2);
        int int4 = shapeList0.size();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 11 + "'", int4 == 11);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = null;
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle4.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle4.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener10 = null;
        boolean boolean11 = categoryAxis9.hasListener(eventListener10);
        categoryAxis9.setTickMarkInsideLength((float) 100L);
        java.awt.Font font15 = categoryAxis9.getTickLabelFont((java.lang.Comparable) ' ');
        boolean boolean16 = categoryAxis9.isTickLabelsVisible();
        float float17 = categoryAxis9.getTickMarkInsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryAxis9.getTickLabelInsets();
        categoryAxis9.setTickLabelsVisible(false);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = lineAndShapeRenderer24.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint29 = lineAndShapeRenderer24.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = lineAndShapeRenderer24.getPlot();
        java.awt.Color color35 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer24.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color35, true);
        boolean boolean38 = lineAndShapeRenderer24.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier39 = lineAndShapeRenderer24.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer24);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray42 = new org.jfree.chart.axis.ValueAxis[] { valueAxis41 };
        categoryPlot40.setRangeAxes(valueAxisArray42);
        categoryPlot40.setDrawSharedDomainAxis(false);
        java.awt.Font font46 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean47 = categoryPlot40.equals((java.lang.Object) font46);
        categoryPlot40.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D51 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D51.setVerticalTickLabels(true);
        org.jfree.data.Range range54 = categoryPlot40.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D51);
        java.text.NumberFormat numberFormat55 = null;
        numberAxis3D51.setNumberFormatOverride(numberFormat55);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset57 = new org.jfree.data.category.DefaultCategoryDataset();
        int int59 = defaultCategoryDataset57.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number60 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset57);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener63 = null;
        boolean boolean64 = categoryAxis62.hasListener(eventListener63);
        categoryAxis62.setFixedDimension((double) (short) -1);
        java.awt.Font font68 = categoryAxis62.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent69 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis62);
        categoryAxis62.configure();
        boolean boolean71 = month61.equals((java.lang.Object) categoryAxis62);
        int int72 = defaultCategoryDataset57.getRowIndex((java.lang.Comparable) boolean71);
        try {
            statisticalLineAndShapeRenderer0.drawItem(graphics2D1, categoryItemRendererState2, rectangle2D7, categoryPlot8, categoryAxis9, (org.jfree.chart.axis.ValueAxis) numberAxis3D51, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset57, (int) '#', (int) (short) 1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 100.0f + "'", float17 == 100.0f);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(categoryPlot30);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(drawingSupplier39);
        org.junit.Assert.assertNotNull(valueAxisArray42);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNull(range54);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1) + "'", int59 == (-1));
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + 0.0d + "'", number60.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(font68);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        try {
            org.jfree.data.time.DateRange dateRange2 = new org.jfree.data.time.DateRange((double) (short) 10, (double) 7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (7.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.data.Range range1 = null;
        try {
            dateAxis0.setDefaultAutoRange(range1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle3.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D6 = textTitle3.getBounds();
        try {
            blockBorder0.draw(graphics2D1, rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
        org.junit.Assert.assertNotNull(rectangle2D6);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D30.setVerticalTickLabels(true);
        org.jfree.data.Range range33 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryPlot19.getInsets();
        double double35 = rectangleInsets34.getBottom();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 4.0d + "'", double35 == 4.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.renderer.AreaRendererEndType areaRendererEndType0 = org.jfree.chart.renderer.AreaRendererEndType.TRUNCATE;
        org.junit.Assert.assertNotNull(areaRendererEndType0);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.Date date1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle5.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D8 = textTitle5.getBounds();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener10 = null;
        boolean boolean11 = categoryAxis9.hasListener(eventListener10);
        categoryAxis9.setFixedDimension((double) (short) -1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = lineAndShapeRenderer21.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint26 = lineAndShapeRenderer21.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = lineAndShapeRenderer21.getPlot();
        java.awt.Color color32 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer21.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color32, true);
        boolean boolean35 = lineAndShapeRenderer21.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier36 = lineAndShapeRenderer21.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer21);
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer41 = null;
        categoryPlot37.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker40, layer41);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot37.getRangeAxisEdge(10);
        double double45 = categoryAxis9.getCategoryJava2DCoordinate(categoryAnchor14, (int) 'a', 2, rectangle2D17, rectangleEdge44);
        double double46 = dateAxis2.valueToJava2D((double) (short) 100, rectangle2D8, rectangleEdge44);
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer50 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition53 = lineAndShapeRenderer50.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint55 = lineAndShapeRenderer50.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = lineAndShapeRenderer50.getPlot();
        java.awt.Color color61 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer50.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color61, true);
        boolean boolean64 = lineAndShapeRenderer50.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier65 = lineAndShapeRenderer50.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, valueAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer50);
        org.jfree.chart.plot.ValueMarker valueMarker69 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer70 = null;
        categoryPlot66.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker69, layer70);
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = categoryPlot66.getRangeAxisEdge(10);
        try {
            double double74 = dateAxis0.dateToJava2D(date1, rectangle2D8, rectangleEdge73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(categoryPlot27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(drawingSupplier36);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNull(categoryPlot56);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNull(drawingSupplier65);
        org.junit.Assert.assertNotNull(rectangleEdge73);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.lang.Object obj7 = lineAndShapeRenderer0.clone();
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer14.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint19 = lineAndShapeRenderer14.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = lineAndShapeRenderer14.getPlot();
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer14.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color25, true);
        boolean boolean28 = lineAndShapeRenderer14.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = lineAndShapeRenderer14.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        org.jfree.chart.plot.ValueMarker valueMarker33 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer34 = null;
        categoryPlot30.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker33, layer34);
        float float36 = categoryPlot30.getBackgroundImageAlpha();
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D37 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D37.setCategoryLabelPositionOffset((int) (short) -1);
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = null;
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle42.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D45 = textTitle42.getBounds();
        try {
            lineAndShapeRenderer0.drawDomainMarker(graphics2D10, categoryPlot30, (org.jfree.chart.axis.CategoryAxis) categoryAxis3D37, categoryMarker40, rectangle2D45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryPlot20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(drawingSupplier29);
        org.junit.Assert.assertTrue("'" + float36 + "' != '" + 0.5f + "'", float36 == 0.5f);
        org.junit.Assert.assertNotNull(rectangle2D45);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        java.util.TimeZone timeZone0 = null;
        org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE = timeZone0;
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number4 = taskSeriesCollection0.getValue((int) '4', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 52, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 4);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        java.awt.Paint paint29 = categoryPlot19.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) ' ', 100);
        boolean boolean7 = lineAndShapeRenderer2.isSeriesVisible((int) ' ');
        java.awt.Paint paint8 = lineAndShapeRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=]", font1, paint8);
        labelBlock9.setWidth((double) (byte) -1);
        labelBlock9.setURLText("-4,-4,4,4");
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.data.Range range15 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint17 = new org.jfree.chart.block.RectangleConstraint(range15, (double) (-1));
        try {
            org.jfree.chart.util.Size2D size2D18 = labelBlock9.arrange(graphics2D14, rectangleConstraint17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge26);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.util.Date date0 = null;
        org.jfree.chart.text.TextAnchor textAnchor2 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        try {
            org.jfree.chart.axis.DateTick dateTick5 = new org.jfree.chart.axis.DateTick(date0, "June 2019", textAnchor2, textAnchor3, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number5 = taskSeriesCollection0.getPercentComplete((int) (byte) -1, 1900, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        java.lang.String str1 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "UnitType.RELATIVE" + "'", str1.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D30 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D30.setVerticalTickLabels(true);
        org.jfree.data.Range range33 = categoryPlot19.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D30);
        java.text.NumberFormat numberFormat34 = null;
        numberAxis3D30.setNumberFormatOverride(numberFormat34);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent36 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis3D30);
        java.lang.String str37 = axisChangeEvent36.toString();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener39 = null;
        boolean boolean40 = categoryAxis38.hasListener(eventListener39);
        categoryAxis38.setFixedDimension((double) (short) -1);
        java.awt.Font font44 = categoryAxis38.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent45 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis38);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType46 = axisChangeEvent45.getType();
        axisChangeEvent36.setType(chartChangeEventType46);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(range33);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(font44);
        org.junit.Assert.assertNotNull(chartChangeEventType46);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) year0);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = year0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer7.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint12 = lineAndShapeRenderer7.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = lineAndShapeRenderer7.getPlot();
        java.awt.Color color18 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer7.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color18, true);
        boolean boolean21 = lineAndShapeRenderer7.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = lineAndShapeRenderer7.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer27 = null;
        categoryPlot23.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer27);
        java.awt.Paint paint29 = categoryPlot23.getBackgroundPaint();
        boolean boolean30 = segmentedTimeline3.equals((java.lang.Object) categoryPlot23);
        java.util.Date date31 = null;
        try {
            long long32 = segmentedTimeline3.toTimelineValue(date31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryPlot13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer7.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint12 = lineAndShapeRenderer7.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = lineAndShapeRenderer7.getPlot();
        java.awt.Color color18 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer7.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color18, true);
        boolean boolean21 = lineAndShapeRenderer7.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = lineAndShapeRenderer7.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer27 = null;
        categoryPlot23.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer27);
        java.awt.Paint paint29 = categoryPlot23.getBackgroundPaint();
        boolean boolean30 = segmentedTimeline3.equals((java.lang.Object) categoryPlot23);
        try {
            segmentedTimeline3.addException((long) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryPlot13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Paint paint1 = null;
        java.awt.Color color5 = org.jfree.chart.util.PaintUtilities.stringToColor("");
        float[] floatArray12 = new float[] { 10, (-1.0f), 0.5f, 10.0f, 3, 9999 };
        float[] floatArray13 = color5.getRGBColorComponents(floatArray12);
        org.jfree.chart.plot.ValueMarker valueMarker15 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color16 = java.awt.Color.magenta;
        valueMarker15.setOutlinePaint((java.awt.Paint) color16);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int19 = color18.getGreen();
        valueMarker15.setOutlinePaint((java.awt.Paint) color18);
        java.awt.Stroke stroke21 = valueMarker15.getStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = lineAndShapeRenderer22.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint27 = lineAndShapeRenderer22.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = lineAndShapeRenderer22.getPlot();
        java.awt.Color color33 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer22.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color33, true);
        boolean boolean36 = lineAndShapeRenderer22.getUseFillPaint();
        java.lang.Boolean boolean38 = lineAndShapeRenderer22.getSeriesShapesFilled(0);
        java.awt.Color color39 = java.awt.Color.LIGHT_GRAY;
        lineAndShapeRenderer22.setBaseItemLabelPaint((java.awt.Paint) color39);
        java.awt.Stroke stroke41 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker43 = new org.jfree.chart.plot.IntervalMarker((double) 0.8f, 0.0d, (java.awt.Paint) color5, stroke21, (java.awt.Paint) color39, stroke41, 1.0f);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1, paint1, stroke41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(categoryPlot28);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(boolean38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        categoryPlot19.setDrawSharedDomainAxis(true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = categoryPlot19.getRenderer();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(categoryItemRenderer31);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        try {
            java.lang.Number number6 = taskSeriesCollection0.getPercentComplete((int) 'a', (int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(range1);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) ' ', 100);
        boolean boolean7 = lineAndShapeRenderer2.isSeriesVisible((int) ' ');
        java.awt.Paint paint8 = lineAndShapeRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=]", font1, paint8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle12.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D15 = textTitle12.getBounds();
        try {
            labelBlock9.draw(graphics2D10, rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangle2D15);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double[][] doubleArray4 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset5 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("-4,-4,4,4", "", doubleArray4);
        org.jfree.data.category.CategoryDataset categoryDataset6 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("ChartEntity: tooltip = ({0}, {1}) = {3} - {4}", "TextAnchor.TOP_CENTER", doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(categoryDataset5);
        org.junit.Assert.assertNotNull(categoryDataset6);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer0.setBaseStroke(stroke17);
        java.io.ObjectOutputStream objectOutputStream19 = null;
        try {
            org.jfree.chart.util.SerialUtilities.writeStroke(stroke17, objectOutputStream19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getAutoPopulateSeriesFillPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.Color color0 = java.awt.Color.pink;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        java.lang.Boolean boolean20 = lineAndShapeRenderer4.getSeriesShapesFilled(0);
        java.awt.Color color21 = java.awt.Color.LIGHT_GRAY;
        lineAndShapeRenderer4.setBaseItemLabelPaint((java.awt.Paint) color21);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = lineAndShapeRenderer24.getNegativeItemLabelPosition((int) ' ', 100);
        org.jfree.chart.text.TextAnchor textAnchor28 = itemLabelPosition27.getTextAnchor();
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor29 = itemLabelPosition27.getItemLabelAnchor();
        lineAndShapeRenderer4.setSeriesPositiveItemLabelPosition((int) (byte) 10, itemLabelPosition27);
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition(4, itemLabelPosition27);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(textAnchor28);
        org.junit.Assert.assertNotNull(itemLabelAnchor29);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean2 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot22.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.Range range29 = categoryPlot22.getDataRange(valueAxis28);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = categoryPlot22.getDatasetRenderingOrder();
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        numberAxis3D1.setFixedAutoRange((double) (byte) 1);
        numberAxis3D1.setUpperMargin((double) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot22.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot22.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot22);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent31 = null;
        categoryPlot22.markerChanged(markerChangeEvent31);
        org.jfree.chart.JFreeChart jFreeChart33 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot22);
        float float34 = jFreeChart33.getBackgroundImageAlpha();
        org.jfree.chart.title.Title title36 = jFreeChart33.getSubtitle(0);
        jFreeChart33.setNotify(true);
        try {
            multiplePiePlot2.setPieChart(jFreeChart33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'pieChart' argument must be a chart based on a PiePlot.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + float34 + "' != '" + 0.5f + "'", float34 == 0.5f);
        org.junit.Assert.assertNotNull(title36);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = lineAndShapeRenderer1.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint6 = lineAndShapeRenderer1.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = lineAndShapeRenderer1.getPlot();
        java.awt.Color color12 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer1.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color12, true);
        boolean boolean15 = lineAndShapeRenderer1.getUseFillPaint();
        java.lang.Boolean boolean17 = lineAndShapeRenderer1.getSeriesShapesFilled(0);
        boolean boolean18 = axisSpace0.equals((java.lang.Object) lineAndShapeRenderer1);
        lineAndShapeRenderer1.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryPlot7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        java.util.List list4 = defaultCategoryDataset0.getRowKeys();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D6 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int10 = dateTickUnit9.getCalendarField();
        int int11 = dateTickUnit9.getCalendarField();
        defaultKeyedValues2D6.setValue((java.lang.Number) (byte) 0, (java.lang.Comparable) 0L, (java.lang.Comparable) int11);
        boolean boolean13 = defaultCategoryDataset0.equals((java.lang.Object) defaultKeyedValues2D6);
        try {
            defaultKeyedValues2D6.removeRow((java.lang.Comparable) "RectangleEdge.LEFT");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to java.lang.Long");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.renderer.category.StackedAreaRenderer stackedAreaRenderer1 = new org.jfree.chart.renderer.category.StackedAreaRenderer(false);
        stackedAreaRenderer1.setRenderAsPercentages(false);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker(0.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        java.util.List list4 = defaultCategoryDataset0.getRowKeys();
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D6 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit9 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int10 = dateTickUnit9.getCalendarField();
        int int11 = dateTickUnit9.getCalendarField();
        defaultKeyedValues2D6.setValue((java.lang.Number) (byte) 0, (java.lang.Comparable) 0L, (java.lang.Comparable) int11);
        boolean boolean13 = defaultCategoryDataset0.equals((java.lang.Object) defaultKeyedValues2D6);
        try {
            java.lang.Comparable comparable15 = defaultKeyedValues2D6.getRowKey(9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9999, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(dateTickUnit9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 5 + "'", int10 == 5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 5 + "'", int11 == 5);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        defaultCategoryDataset0.addValue((java.lang.Number) 1.0d, (java.lang.Comparable) (short) 0, (java.lang.Comparable) 900000L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        boolean boolean9 = lineAndShapeRenderer0.isItemLabelVisible(2, (int) (byte) 1);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.data.Range range26 = categoryPlot19.getDataRange(valueAxis25);
        org.jfree.chart.plot.Plot plot27 = categoryPlot19.getRootPlot();
        try {
            plot27.setBackgroundImageAlpha((float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNull(range26);
        org.junit.Assert.assertNotNull(plot27);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean3 = barRenderer3D0.isItemLabelVisible((int) ' ', (int) 'a');
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = lineAndShapeRenderer8.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint13 = lineAndShapeRenderer8.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = lineAndShapeRenderer8.getPlot();
        java.awt.Color color19 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer8.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color19, true);
        boolean boolean22 = lineAndShapeRenderer8.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier23 = lineAndShapeRenderer8.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer8);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray26 = new org.jfree.chart.axis.ValueAxis[] { valueAxis25 };
        categoryPlot24.setRangeAxes(valueAxisArray26);
        categoryPlot24.setDrawSharedDomainAxis(false);
        java.awt.Font font30 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean31 = categoryPlot24.equals((java.lang.Object) font30);
        categoryPlot24.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D35 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D35.setVerticalTickLabels(true);
        org.jfree.data.Range range38 = categoryPlot24.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D35);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = categoryPlot24.getInsets();
        org.jfree.chart.axis.DateAxis dateAxis40 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle43.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D46 = textTitle43.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer50 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition53 = lineAndShapeRenderer50.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint55 = lineAndShapeRenderer50.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = lineAndShapeRenderer50.getPlot();
        java.awt.Color color61 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer50.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color61, true);
        boolean boolean64 = lineAndShapeRenderer50.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier65 = lineAndShapeRenderer50.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, valueAxis49, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer50);
        org.jfree.chart.axis.ValueAxis valueAxis67 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray68 = new org.jfree.chart.axis.ValueAxis[] { valueAxis67 };
        categoryPlot66.setRangeAxes(valueAxisArray68);
        categoryPlot66.setDrawSharedDomainAxis(false);
        boolean boolean72 = categoryPlot66.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge73 = categoryPlot66.getRangeAxisEdge();
        double double74 = dateAxis40.valueToJava2D(0.0d, rectangle2D46, rectangleEdge73);
        try {
            barRenderer3D0.drawBackground(graphics2D4, categoryPlot24, rectangle2D46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(categoryPlot14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(drawingSupplier23);
        org.junit.Assert.assertNotNull(valueAxisArray26);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNull(range38);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertNotNull(itemLabelPosition53);
        org.junit.Assert.assertNotNull(paint55);
        org.junit.Assert.assertNull(categoryPlot56);
        org.junit.Assert.assertNotNull(color61);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNull(drawingSupplier65);
        org.junit.Assert.assertNotNull(valueAxisArray68);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertNotNull(rectangleEdge73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        java.lang.Object obj4 = segmentedTimeline3.clone();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline8 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        try {
            segmentedTimeline3.setBaseTimeline(segmentedTimeline8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        java.awt.Font font3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        boolean boolean9 = lineAndShapeRenderer4.isSeriesVisible((int) ' ');
        java.awt.Paint paint10 = lineAndShapeRenderer4.getBaseItemLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=]", font3, paint10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = labelBlock11.getMargin();
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_BLUE;
        labelBlock11.setPaint((java.awt.Paint) color13);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder(rectangleInsets1, (java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        java.lang.Object obj4 = segmentedTimeline3.clone();
        int int5 = segmentedTimeline3.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        java.lang.Object obj10 = segmentedTimeline9.clone();
        try {
            segmentedTimeline3.setBaseTimeline(segmentedTimeline9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        int int28 = categoryPlot19.getDatasetCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot19.getDomainAxisForDataset((int) (short) -1);
        org.jfree.chart.block.BlockBorder blockBorder31 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint32 = blockBorder31.getPaint();
        categoryPlot19.setBackgroundPaint(paint32);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.data.time.SerialDate serialDate2 = org.jfree.data.time.SerialDate.createInstance((int) (short) 100);
        try {
            org.jfree.data.time.SerialDate serialDate3 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(0, serialDate2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.cursorDown((-1.0d));
        java.lang.Number number6 = null;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D12 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list13 = defaultKeyedValues2D12.getRowKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem14 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 3.0d, (java.lang.Number) (-1.0f), (java.lang.Number) (short) 100, number6, (java.lang.Number) (-1.0f), (java.lang.Number) 4.0d, (java.lang.Number) 8.0d, (java.lang.Number) 1.0f, list13);
        axisState0.setTicks(list13);
        java.util.List list16 = axisState0.getTicks();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener20 = null;
        boolean boolean21 = categoryAxis19.hasListener(eventListener20);
        categoryAxis19.setTickMarkInsideLength((float) 100L);
        java.awt.Font font25 = categoryAxis19.getTickLabelFont((java.lang.Comparable) ' ');
        java.awt.Paint paint26 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition33 = lineAndShapeRenderer30.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint35 = lineAndShapeRenderer30.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = lineAndShapeRenderer30.getPlot();
        java.awt.Color color41 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer30.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color41, true);
        boolean boolean44 = lineAndShapeRenderer30.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier45 = lineAndShapeRenderer30.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer30);
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer50 = null;
        categoryPlot46.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker49, layer50);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = categoryPlot46.getRangeAxisEdge(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = categoryPlot46.getDomainAxisEdge();
        java.awt.Font font56 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint57 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer60 = null;
        org.jfree.chart.text.TextBlock textBlock61 = org.jfree.chart.text.TextUtilities.createTextBlock("", font56, paint57, (float) '#', (int) (byte) -1, textMeasurer60);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment62 = textBlock61.getLineAlignment();
        java.awt.Graphics2D graphics2D63 = null;
        org.jfree.chart.util.Size2D size2D64 = textBlock61.calculateDimensions(graphics2D63);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment65 = textBlock61.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment66 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str67 = verticalAlignment66.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets68 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle69 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font25, paint26, rectangleEdge54, horizontalAlignment65, verticalAlignment66, rectangleInsets68);
        axisState0.moveCursor((double) 10.0f, rectangleEdge54);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(itemLabelPosition33);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNull(categoryPlot36);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(drawingSupplier45);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(textBlock61);
        org.junit.Assert.assertNotNull(horizontalAlignment62);
        org.junit.Assert.assertNotNull(size2D64);
        org.junit.Assert.assertNotNull(horizontalAlignment65);
        org.junit.Assert.assertNotNull(verticalAlignment66);
        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str67.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertNotNull(rectangleInsets68);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(10.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double0 = org.jfree.chart.plot.PiePlot.DEFAULT_INTERIOR_GAP;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.25d + "'", double0 == 0.25d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setFixedDimension((double) (short) -1);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) '4');
        int int7 = categoryAxis0.getMaximumCategoryLabelLines();
        categoryAxis0.setMaximumCategoryLabelLines(0);
        java.awt.Paint paint10 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        categoryAxis0.setTickLabelPaint(paint10);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle3.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D6 = textTitle3.getBounds();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener8 = null;
        boolean boolean9 = categoryAxis7.hasListener(eventListener8);
        categoryAxis7.setFixedDimension((double) (short) -1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        double double43 = categoryAxis7.getCategoryJava2DCoordinate(categoryAnchor12, (int) 'a', 2, rectangle2D15, rectangleEdge42);
        double double44 = dateAxis0.valueToJava2D((double) (short) 100, rectangle2D6, rectangleEdge42);
        java.lang.String str45 = rectangleEdge42.toString();
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "RectangleEdge.RIGHT" + "'", str45.equals("RectangleEdge.RIGHT"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.Range range17 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, true);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(range17);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.DefaultKeyedValue defaultKeyedValue2 = new org.jfree.data.DefaultKeyedValue((java.lang.Comparable) 100.0d, (java.lang.Number) 8);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.util.ShapeList shapeList2 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape4 = null;
        shapeList2.setShape((int) (byte) 10, shape4);
        boolean boolean6 = rectangleAnchor1.equals((java.lang.Object) shape4);
        java.lang.String str7 = rectangleAnchor1.toString();
        java.awt.Font font9 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint10 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer13 = null;
        org.jfree.chart.text.TextBlock textBlock14 = org.jfree.chart.text.TextUtilities.createTextBlock("", font9, paint10, (float) '#', (int) (byte) -1, textMeasurer13);
        org.jfree.chart.text.TextLine textLine15 = textBlock14.getLastLine();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        java.awt.Shape shape23 = textBlock14.calculateBounds(graphics2D16, (float) 10L, (float) 4, textBlockAnchor19, (float) (short) 1, (float) 10L, 100.0d);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType24 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition26 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor19, categoryLabelWidthType24, (float) 100);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions27 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition26);
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str7.equals("RectangleAnchor.BOTTOM_LEFT"));
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(textBlock14);
        org.junit.Assert.assertNull(textLine15);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(categoryLabelWidthType24);
        org.junit.Assert.assertNotNull(categoryLabelPositions27);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.createStandardSeriesShapes();
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) 100.0f);
        java.lang.String str3 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str3.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.lang.Number number3 = null;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D9 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list10 = defaultKeyedValues2D9.getRowKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem11 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 3.0d, (java.lang.Number) (-1.0f), (java.lang.Number) (short) 100, number3, (java.lang.Number) (-1.0f), (java.lang.Number) 4.0d, (java.lang.Number) 8.0d, (java.lang.Number) 1.0f, list10);
        java.lang.Number number12 = boxAndWhiskerItem11.getMinRegularValue();
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0f) + "'", number12.equals((-1.0f)));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        int int28 = categoryPlot19.getDatasetCount();
        java.util.List list29 = categoryPlot19.getCategories();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(list29);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer0.setBaseStroke(stroke17);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) false, true);
        boolean boolean25 = lineAndShapeRenderer0.getUseOutlinePaint();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(2.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.data.Range range0 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(range0, (double) (-1));
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toFixedHeight((double) 2);
        org.jfree.chart.util.Size2D size2D5 = null;
        try {
            org.jfree.chart.util.Size2D size2D6 = rectangleConstraint2.calculateConstrainedSize(size2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleConstraint4);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        boolean boolean14 = lineAndShapeRenderer0.getUseFillPaint();
        lineAndShapeRenderer0.setBaseSeriesVisible(false);
        boolean boolean19 = lineAndShapeRenderer0.getItemShapeVisible(7, 3);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int5 = dateTickUnit4.getCalendarField();
        int int6 = dateTickUnit4.getCalendarField();
        defaultKeyedValues2D1.setValue((java.lang.Number) (byte) 0, (java.lang.Comparable) 0L, (java.lang.Comparable) int6);
        int int8 = defaultKeyedValues2D1.getColumnCount();
        try {
            java.lang.Number number11 = defaultKeyedValues2D1.getValue((java.lang.Comparable) (-1.0f), (java.lang.Comparable) Double.NaN);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Unrecognised columnKey: NaN");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 5 + "'", int5 == 5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        org.jfree.data.gantt.Task task2 = new org.jfree.data.gantt.Task("rect", (org.jfree.data.time.TimePeriod) month1);
        org.jfree.data.gantt.Task task3 = null;
        try {
            task2.addSubtask(task3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtask' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.DAY_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 86400000L + "'", long0 == 86400000L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        boolean boolean14 = lineAndShapeRenderer0.getUseFillPaint();
        java.lang.Boolean boolean16 = lineAndShapeRenderer0.getSeriesShapesFilled(0);
        java.awt.Color color17 = java.awt.Color.LIGHT_GRAY;
        lineAndShapeRenderer0.setBaseItemLabelPaint((java.awt.Paint) color17);
        boolean boolean19 = lineAndShapeRenderer0.getDrawOutlines();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (byte) 0, (java.lang.Boolean) false, false);
        try {
            lineAndShapeRenderer0.setSeriesVisible((int) (short) -1, (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(boolean16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean2 = numberAxis3D1.getAutoRangeIncludesZero();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot22.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker25, layer26);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.Range range29 = categoryPlot22.getDataRange(valueAxis28);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder30 = categoryPlot22.getDatasetRenderingOrder();
        numberAxis3D1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot22);
        numberAxis3D1.setRangeAboutValue((double) 4, (double) '#');
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent35 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) 4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNull(range29);
        org.junit.Assert.assertNotNull(datasetRenderingOrder30);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean1 = barRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] { valueAxis23 };
        categoryPlot22.setRangeAxes(valueAxisArray24);
        categoryPlot22.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D29.setVerticalTickLabels(true);
        numberAxis3D29.setLowerBound((double) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color36 = java.awt.Color.magenta;
        valueMarker35.setOutlinePaint((java.awt.Paint) color36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int39 = color38.getGreen();
        valueMarker35.setOutlinePaint((java.awt.Paint) color38);
        java.awt.Stroke stroke41 = valueMarker35.getStroke();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        barRenderer3D0.drawRangeMarker(graphics2D2, categoryPlot22, (org.jfree.chart.axis.ValueAxis) numberAxis3D29, (org.jfree.chart.plot.Marker) valueMarker35, rectangle2D42);
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color47 = java.awt.Color.magenta;
        valueMarker46.setOutlinePaint((java.awt.Paint) color47);
        barRenderer3D0.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color47, true);
        boolean boolean52 = barRenderer3D0.isSeriesVisibleInLegend((-1));
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(valueAxisArray24);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot7.getDomainAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color12 = java.awt.Color.magenta;
        valueMarker11.setOutlinePaint((java.awt.Paint) color12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker11.setLabelTextAnchor(textAnchor14);
        org.jfree.chart.util.Layer layer16 = null;
        try {
            xYPlot7.addDomainMarker(0, (org.jfree.chart.plot.Marker) valueMarker11, layer16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        java.lang.Object obj4 = segmentedTimeline3.clone();
        int int5 = segmentedTimeline3.getSegmentsExcluded();
        try {
            org.jfree.chart.axis.SegmentedTimeline.Segment segment7 = segmentedTimeline3.getSegment((long) 1900);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        long long0 = org.jfree.chart.axis.SegmentedTimeline.MINUTE_SEGMENT_SIZE;
        org.junit.Assert.assertTrue("'" + long0 + "' != '" + 60000L + "'", long0 == 60000L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis1.hasListener(eventListener2);
        categoryAxis1.setTickMarkInsideLength((float) 100L);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) ' ');
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.CENTER_LEFT", font7);
        java.awt.Graphics2D graphics2D9 = null;
        try {
            org.jfree.chart.util.Size2D size2D10 = textFragment8.calculateDimensions(graphics2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer7.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint12 = lineAndShapeRenderer7.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = lineAndShapeRenderer7.getPlot();
        java.awt.Color color18 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer7.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color18, true);
        boolean boolean21 = lineAndShapeRenderer7.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = lineAndShapeRenderer7.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer27 = null;
        categoryPlot23.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer27);
        java.awt.Paint paint29 = categoryPlot23.getBackgroundPaint();
        boolean boolean30 = segmentedTimeline3.equals((java.lang.Object) categoryPlot23);
        categoryPlot23.setRangeCrosshairVisible(true);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryPlot13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D1 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list2 = defaultKeyedValues2D1.getRowKeys();
        try {
            defaultKeyedValues2D1.removeRow(8);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 8, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list2);
    }

//    @Test
//    public void test327() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test327");
//        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
//        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
//        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer7.getNegativeItemLabelPosition((int) ' ', 100);
//        java.awt.Paint paint12 = lineAndShapeRenderer7.lookupSeriesPaint((int) (byte) -1);
//        org.jfree.chart.plot.CategoryPlot categoryPlot13 = lineAndShapeRenderer7.getPlot();
//        java.awt.Color color18 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
//        lineAndShapeRenderer7.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color18, true);
//        boolean boolean21 = lineAndShapeRenderer7.getUseFillPaint();
//        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = lineAndShapeRenderer7.getDrawingSupplier();
//        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
//        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (-1));
//        org.jfree.chart.util.Layer layer27 = null;
//        categoryPlot23.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer27);
//        java.awt.Paint paint29 = categoryPlot23.getBackgroundPaint();
//        boolean boolean30 = segmentedTimeline3.equals((java.lang.Object) categoryPlot23);
//        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
//        java.lang.String str32 = month31.toString();
//        java.util.Date date33 = month31.getEnd();
//        try {
//            segmentedTimeline3.addBaseTimelineException(date33);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(itemLabelPosition10);
//        org.junit.Assert.assertNotNull(paint12);
//        org.junit.Assert.assertNull(categoryPlot13);
//        org.junit.Assert.assertNotNull(color18);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNull(drawingSupplier22);
//        org.junit.Assert.assertNotNull(paint29);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "June 2019" + "'", str32.equals("June 2019"));
//        org.junit.Assert.assertNotNull(date33);
//    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        org.jfree.data.xy.XYDataset xYDataset37 = polarPlot36.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis38 = polarPlot36.getAxis();
        int int39 = polarPlot36.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNull(xYDataset37);
        org.junit.Assert.assertNotNull(valueAxis38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 15 + "'", int39 == 15);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        java.lang.Object obj4 = segmentedTimeline3.clone();
        int int5 = segmentedTimeline3.getSegmentsExcluded();
        try {
            boolean boolean7 = segmentedTimeline3.containsDomainValue((long) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        boolean boolean27 = categoryPlot19.isSubplot();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot19.zoomRangeAxes(100.0d, plotRenderingInfo29, point2D30);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.Range range0 = null;
        org.jfree.data.Range range2 = org.jfree.data.Range.expandToInclude(range0, (double) 100L);
        org.jfree.data.Range range4 = org.jfree.data.Range.expandToInclude(range2, 12.0d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(range4);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        boolean boolean0 = org.jfree.chart.util.ObjectUtilities.isJDK14();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.block.ColumnArrangement columnArrangement0 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.block.BlockContainer blockContainer1 = new org.jfree.chart.block.BlockContainer((org.jfree.chart.block.Arrangement) columnArrangement0);
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.DateAxis dateAxis3 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle6.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D9 = textTitle6.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer13.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint18 = lineAndShapeRenderer13.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = lineAndShapeRenderer13.getPlot();
        java.awt.Color color24 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer13.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color24, true);
        boolean boolean27 = lineAndShapeRenderer13.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = lineAndShapeRenderer13.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer13);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray31 = new org.jfree.chart.axis.ValueAxis[] { valueAxis30 };
        categoryPlot29.setRangeAxes(valueAxisArray31);
        categoryPlot29.setDrawSharedDomainAxis(false);
        boolean boolean35 = categoryPlot29.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot29.getRangeAxisEdge();
        double double37 = dateAxis3.valueToJava2D(0.0d, rectangle2D9, rectangleEdge36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition44 = lineAndShapeRenderer41.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint46 = lineAndShapeRenderer41.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = lineAndShapeRenderer41.getPlot();
        java.awt.Color color52 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer41.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color52, true);
        boolean boolean55 = lineAndShapeRenderer41.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier56 = lineAndShapeRenderer41.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer41);
        org.jfree.chart.plot.ValueMarker valueMarker60 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer61 = null;
        categoryPlot57.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker60, layer61);
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.data.Range range64 = categoryPlot57.getDataRange(valueAxis63);
        org.jfree.chart.plot.Plot plot65 = categoryPlot57.getRootPlot();
        try {
            java.lang.Object obj66 = blockContainer1.draw(graphics2D2, rectangle2D9, (java.lang.Object) categoryPlot57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D9);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(categoryPlot19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(valueAxisArray31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(itemLabelPosition44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNull(categoryPlot47);
        org.junit.Assert.assertNotNull(color52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNull(drawingSupplier56);
        org.junit.Assert.assertNull(range64);
        org.junit.Assert.assertNotNull(plot65);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setName("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo3 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo3.setName("TextBlockAnchor.CENTER_LEFT");
        basicProjectInfo0.addOptionalLibrary((org.jfree.chart.ui.Library) basicProjectInfo3);
        basicProjectInfo0.setLicenceName("Sunday");
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.block.BlockParams blockParams0 = new org.jfree.chart.block.BlockParams();
        boolean boolean1 = blockParams0.getGenerateEntities();
        blockParams0.setTranslateY(100.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator2 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str3 = standardCategoryToolTipGenerator2.getLabelFormat();
        barRenderer0.setSeriesToolTipGenerator((int) (byte) 10, (org.jfree.chart.labels.CategoryToolTipGenerator) standardCategoryToolTipGenerator2, true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "({0}, {1}) = {2}" + "'", str3.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("VerticalAlignment.BOTTOM");
        textTitle1.setText("");
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle3.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D6 = textTitle3.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = lineAndShapeRenderer10.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint15 = lineAndShapeRenderer10.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = lineAndShapeRenderer10.getPlot();
        java.awt.Color color21 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer10.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color21, true);
        boolean boolean24 = lineAndShapeRenderer10.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = lineAndShapeRenderer10.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer10);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] { valueAxis27 };
        categoryPlot26.setRangeAxes(valueAxisArray28);
        categoryPlot26.setDrawSharedDomainAxis(false);
        boolean boolean32 = categoryPlot26.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot26.getRangeAxisEdge();
        double double34 = dateAxis0.valueToJava2D(0.0d, rectangle2D6, rectangleEdge33);
        java.util.TimeZone timeZone35 = null;
        try {
            dateAxis0.setTimeZone(timeZone35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryPlot16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(drawingSupplier25);
        org.junit.Assert.assertNotNull(valueAxisArray28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean1 = barRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] { valueAxis23 };
        categoryPlot22.setRangeAxes(valueAxisArray24);
        categoryPlot22.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D29.setVerticalTickLabels(true);
        numberAxis3D29.setLowerBound((double) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color36 = java.awt.Color.magenta;
        valueMarker35.setOutlinePaint((java.awt.Paint) color36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int39 = color38.getGreen();
        valueMarker35.setOutlinePaint((java.awt.Paint) color38);
        java.awt.Stroke stroke41 = valueMarker35.getStroke();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        barRenderer3D0.drawRangeMarker(graphics2D2, categoryPlot22, (org.jfree.chart.axis.ValueAxis) numberAxis3D29, (org.jfree.chart.plot.Marker) valueMarker35, rectangle2D42);
        java.awt.Paint paint44 = valueMarker35.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(valueAxisArray24);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer7.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint12 = lineAndShapeRenderer7.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = lineAndShapeRenderer7.getPlot();
        java.awt.Color color18 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer7.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color18, true);
        boolean boolean21 = lineAndShapeRenderer7.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = lineAndShapeRenderer7.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer27 = null;
        categoryPlot23.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer27);
        java.awt.Paint paint29 = categoryPlot23.getBackgroundPaint();
        boolean boolean30 = segmentedTimeline3.equals((java.lang.Object) categoryPlot23);
        java.awt.Font font32 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint33 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer36 = null;
        org.jfree.chart.text.TextBlock textBlock37 = org.jfree.chart.text.TextUtilities.createTextBlock("", font32, paint33, (float) '#', (int) (byte) -1, textMeasurer36);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment38 = textBlock37.getLineAlignment();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.util.Size2D size2D40 = textBlock37.calculateDimensions(graphics2D39);
        boolean boolean41 = categoryPlot23.equals((java.lang.Object) size2D40);
        double double42 = size2D40.getWidth();
        size2D40.width = 0.0d;
        size2D40.setHeight((double) 11);
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryPlot13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(textBlock37);
        org.junit.Assert.assertNotNull(horizontalAlignment38);
        org.junit.Assert.assertNotNull(size2D40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot19.markerChanged(markerChangeEvent28);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        float float31 = jFreeChart30.getBackgroundImageAlpha();
        org.jfree.chart.title.Title title33 = jFreeChart30.getSubtitle(0);
        java.awt.Stroke stroke34 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        jFreeChart30.setBorderStroke(stroke34);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = lineAndShapeRenderer40.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint45 = lineAndShapeRenderer40.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = lineAndShapeRenderer40.getPlot();
        java.awt.Color color51 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer40.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color51, true);
        boolean boolean54 = lineAndShapeRenderer40.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier55 = lineAndShapeRenderer40.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer40);
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray58 = new org.jfree.chart.axis.ValueAxis[] { valueAxis57 };
        categoryPlot56.setRangeAxes(valueAxisArray58);
        categoryPlot56.setDrawSharedDomainAxis(false);
        java.awt.Font font62 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean63 = categoryPlot56.equals((java.lang.Object) font62);
        categoryPlot56.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D67 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D67.setVerticalTickLabels(true);
        org.jfree.data.Range range70 = categoryPlot56.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D67);
        org.jfree.chart.util.RectangleInsets rectangleInsets71 = categoryPlot56.getInsets();
        double double73 = rectangleInsets71.trimWidth(0.0d);
        org.jfree.chart.title.TextTitle textTitle75 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle75.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D78 = textTitle75.getBounds();
        java.awt.geom.Rectangle2D rectangle2D79 = rectangleInsets71.createOutsetRectangle(rectangle2D78);
        java.awt.geom.Point2D point2D80 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo81 = new org.jfree.chart.ChartRenderingInfo();
        org.jfree.chart.entity.EntityCollection entityCollection82 = null;
        chartRenderingInfo81.setEntityCollection(entityCollection82);
        try {
            jFreeChart30.draw(graphics2D36, rectangle2D79, point2D80, chartRenderingInfo81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + float31 + "' != '" + 0.5f + "'", float31 == 0.5f);
        org.junit.Assert.assertNotNull(title33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(itemLabelPosition43);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNull(categoryPlot46);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(drawingSupplier55);
        org.junit.Assert.assertNotNull(valueAxisArray58);
        org.junit.Assert.assertNotNull(font62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNull(range70);
        org.junit.Assert.assertNotNull(rectangleInsets71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + (-16.0d) + "'", double73 == (-16.0d));
        org.junit.Assert.assertNotNull(rectangle2D78);
        org.junit.Assert.assertNotNull(rectangle2D79);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = lineAndShapeRenderer1.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint6 = lineAndShapeRenderer1.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = lineAndShapeRenderer1.getPlot();
        java.awt.Color color12 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer1.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color12, true);
        boolean boolean15 = lineAndShapeRenderer1.getUseFillPaint();
        java.lang.Boolean boolean17 = lineAndShapeRenderer1.getSeriesShapesFilled(0);
        boolean boolean18 = axisSpace0.equals((java.lang.Object) lineAndShapeRenderer1);
        java.awt.Shape shape20 = lineAndShapeRenderer1.lookupSeriesShape((int) (byte) -1);
        java.awt.Font font23 = lineAndShapeRenderer1.getItemLabelFont((int) (byte) 0, (int) (byte) 100);
        lineAndShapeRenderer1.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryPlot7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D0 = new org.jfree.chart.axis.NumberAxis3D();
        numberAxis3D0.setVerticalTickLabels(true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Comparable comparable2 = keyedObjects2D0.getColumnKey((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        int int4 = defaultCategoryDataset2.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number5 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener8 = null;
        boolean boolean9 = categoryAxis7.hasListener(eventListener8);
        categoryAxis7.setFixedDimension((double) (short) -1);
        java.awt.Font font13 = categoryAxis7.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis7);
        categoryAxis7.configure();
        boolean boolean16 = month6.equals((java.lang.Object) categoryAxis7);
        int int17 = defaultCategoryDataset2.getRowIndex((java.lang.Comparable) boolean16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = lineAndShapeRenderer21.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint26 = lineAndShapeRenderer21.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = lineAndShapeRenderer21.getPlot();
        java.awt.Color color32 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer21.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color32, true);
        boolean boolean35 = lineAndShapeRenderer21.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier36 = lineAndShapeRenderer21.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer21);
        org.jfree.chart.plot.ValueMarker valueMarker40 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer41 = null;
        categoryPlot37.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker40, layer41);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = categoryPlot37.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart45 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot37);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent46 = null;
        categoryPlot37.markerChanged(markerChangeEvent46);
        org.jfree.chart.plot.Plot plot48 = categoryPlot37.getRootPlot();
        defaultCategoryDataset2.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot48);
        org.jfree.data.general.PieDataset pieDataset51 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2, 0);
        org.jfree.data.Range range52 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0d + "'", number5.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNull(categoryPlot27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNull(drawingSupplier36);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNotNull(plot48);
        org.junit.Assert.assertNotNull(pieDataset51);
        org.junit.Assert.assertNull(range52);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        java.awt.Paint paint0 = org.jfree.chart.plot.PiePlot.DEFAULT_LABEL_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.util.ShapeList shapeList1 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape3 = null;
        shapeList1.setShape((int) (byte) 10, shape3);
        boolean boolean5 = rectangleAnchor0.equals((java.lang.Object) shape3);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str7 = textBlockAnchor6.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor6);
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer12.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint17 = lineAndShapeRenderer12.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = lineAndShapeRenderer12.getPlot();
        java.awt.Color color23 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer12.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color23, true);
        boolean boolean26 = lineAndShapeRenderer12.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = lineAndShapeRenderer12.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer12);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer32 = null;
        categoryPlot28.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker31, layer32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot28.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart36 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot28);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent37 = null;
        categoryPlot28.markerChanged(markerChangeEvent37);
        boolean boolean39 = textBlockAnchor6.equals((java.lang.Object) categoryPlot28);
        categoryPlot28.mapDatasetToRangeAxis(5, 8);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str7.equals("TextBlockAnchor.CENTER_LEFT"));
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryPlot18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(drawingSupplier27);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        lineAndShapeRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator1);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getBaseOutlineStroke();
        lineAndShapeRenderer0.setSeriesShapesVisible((int) (short) 1, true);
        java.lang.Boolean boolean9 = lineAndShapeRenderer0.getSeriesShapesVisible(0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(boolean9);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) 100.0f, (double) (short) -1);
        java.lang.Number number3 = meanAndStandardDeviation2.getMean();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 100.0d + "'", number3.equals(100.0d));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = lineAndShapeRenderer3.getSeriesToolTipGenerator(4);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.lang.String[] strArray0 = org.jfree.data.time.SerialDate.getMonths();
        java.lang.Number[] numberArray3 = new java.lang.Number[] { 86400000L, (byte) 100 };
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 86400000L, (byte) 100 };
        java.lang.Number[][] numberArray7 = new java.lang.Number[][] { numberArray3, numberArray6 };
        java.lang.Number[] numberArray11 = new java.lang.Number[] { 9999, 0.2d, 7 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 9999, 0.2d, 7 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 9999, 0.2d, 7 };
        java.lang.Number[][] numberArray20 = new java.lang.Number[][] { numberArray11, numberArray15, numberArray19 };
        try {
            org.jfree.data.category.DefaultIntervalCategoryDataset defaultIntervalCategoryDataset21 = new org.jfree.data.category.DefaultIntervalCategoryDataset(strArray0, numberArray7, numberArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: DefaultIntervalCategoryDataset: the number of series in the start value dataset does not match the number of series in the end value dataset.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(strArray0);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray11);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray20);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("({0}, {1}) = {3} - {4}", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        boolean boolean14 = lineAndShapeRenderer0.getUseFillPaint();
        lineAndShapeRenderer0.setSeriesItemLabelsVisible(8, false);
        boolean boolean19 = lineAndShapeRenderer0.isSeriesVisible((int) (byte) 0);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        java.awt.Stroke stroke51 = ringPlot50.getBaseSectionOutlineStroke();
        ringPlot50.setPieIndex(3);
        java.awt.Paint paint54 = ringPlot50.getBaseSectionOutlinePaint();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(paint54);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle3.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D6 = textTitle3.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = lineAndShapeRenderer10.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint15 = lineAndShapeRenderer10.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = lineAndShapeRenderer10.getPlot();
        java.awt.Color color21 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer10.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color21, true);
        boolean boolean24 = lineAndShapeRenderer10.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = lineAndShapeRenderer10.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer10);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] { valueAxis27 };
        categoryPlot26.setRangeAxes(valueAxisArray28);
        categoryPlot26.setDrawSharedDomainAxis(false);
        boolean boolean32 = categoryPlot26.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot26.getRangeAxisEdge();
        double double34 = dateAxis0.valueToJava2D(0.0d, rectangle2D6, rectangleEdge33);
        boolean boolean36 = dateAxis0.isHiddenValue((long) 10);
        org.jfree.data.Range range37 = null;
        org.jfree.data.Range range39 = org.jfree.data.Range.expandToInclude(range37, (double) 100L);
        try {
            dateAxis0.setRangeWithMargins(range37, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryPlot16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(drawingSupplier25);
        org.junit.Assert.assertNotNull(valueAxisArray28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range39);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        java.awt.Paint paint0 = org.jfree.chart.plot.WaferMapPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
        org.jfree.chart.axis.AxisSpace axisSpace1 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint7 = lineAndShapeRenderer2.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = lineAndShapeRenderer2.getPlot();
        java.awt.Color color13 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer2.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color13, true);
        boolean boolean16 = lineAndShapeRenderer2.getUseFillPaint();
        java.lang.Boolean boolean18 = lineAndShapeRenderer2.getSeriesShapesFilled(0);
        boolean boolean19 = axisSpace1.equals((java.lang.Object) lineAndShapeRenderer2);
        boolean boolean20 = blockBorder0.equals((java.lang.Object) lineAndShapeRenderer2);
        boolean boolean23 = lineAndShapeRenderer2.getItemShapeVisible((int) (short) 1, 100);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(categoryPlot8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(boolean18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        java.awt.Color color2 = java.awt.Color.BLACK;
        layeredBarRenderer0.setSeriesOutlinePaint(4, (java.awt.Paint) color2, true);
        double double6 = layeredBarRenderer0.getSeriesBarWidth((int) '#');
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        java.awt.Font font25 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean26 = categoryPlot19.equals((java.lang.Object) font25);
        categoryPlot19.setBackgroundImageAlignment(3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot19.getRenderer();
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot19.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = null;
        try {
            categoryPlot19.addDomainMarker(categoryMarker32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(categoryItemRenderer29);
        org.junit.Assert.assertNotNull(axisLocation31);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D0 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean1 = barRenderer3D0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer6.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint11 = lineAndShapeRenderer6.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = lineAndShapeRenderer6.getPlot();
        java.awt.Color color17 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer6.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color17, true);
        boolean boolean20 = lineAndShapeRenderer6.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = lineAndShapeRenderer6.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray24 = new org.jfree.chart.axis.ValueAxis[] { valueAxis23 };
        categoryPlot22.setRangeAxes(valueAxisArray24);
        categoryPlot22.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D29 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D29.setVerticalTickLabels(true);
        numberAxis3D29.setLowerBound((double) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color36 = java.awt.Color.magenta;
        valueMarker35.setOutlinePaint((java.awt.Paint) color36);
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int39 = color38.getGreen();
        valueMarker35.setOutlinePaint((java.awt.Paint) color38);
        java.awt.Stroke stroke41 = valueMarker35.getStroke();
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        barRenderer3D0.drawRangeMarker(graphics2D2, categoryPlot22, (org.jfree.chart.axis.ValueAxis) numberAxis3D29, (org.jfree.chart.plot.Marker) valueMarker35, rectangle2D42);
        org.jfree.chart.plot.ValueMarker valueMarker46 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color47 = java.awt.Color.magenta;
        valueMarker46.setOutlinePaint((java.awt.Paint) color47);
        barRenderer3D0.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color47, true);
        java.awt.Graphics2D graphics2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = null;
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer56 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition59 = lineAndShapeRenderer56.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint61 = lineAndShapeRenderer56.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = lineAndShapeRenderer56.getPlot();
        java.awt.Color color67 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer56.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color67, true);
        boolean boolean70 = lineAndShapeRenderer56.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier71 = lineAndShapeRenderer56.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot72 = new org.jfree.chart.plot.CategoryPlot(categoryDataset53, categoryAxis54, valueAxis55, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer56);
        org.jfree.chart.plot.ValueMarker valueMarker75 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer76 = null;
        categoryPlot72.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker75, layer76);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder78 = categoryPlot72.getDatasetRenderingOrder();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo80 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState81 = barRenderer3D0.initialise(graphics2D51, rectangle2D52, categoryPlot72, 8, plotRenderingInfo80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(categoryPlot12);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(drawingSupplier21);
        org.junit.Assert.assertNotNull(valueAxisArray24);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(itemLabelPosition59);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNull(categoryPlot62);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNull(drawingSupplier71);
        org.junit.Assert.assertNotNull(datasetRenderingOrder78);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = null;
        org.jfree.chart.util.Layer layer26 = null;
        try {
            categoryPlot19.addDomainMarker((int) (short) 0, categoryMarker25, layer26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        java.awt.Color color0 = java.awt.Color.RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = null;
        lineAndShapeRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator1);
        boolean boolean3 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = lineAndShapeRenderer0.getPlot();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(categoryPlot4);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot7.setOrientation(plotOrientation8);
        xYPlot7.clearDomainAxes();
        boolean boolean11 = xYPlot7.isDomainGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = xYPlot7.getRangeAxis();
        double double13 = xYPlot7.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(valueAxis12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        java.util.List list4 = defaultCategoryDataset0.getRowKeys();
        java.util.List list5 = defaultCategoryDataset0.getColumnKeys();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertNotNull(list4);
        org.junit.Assert.assertNotNull(list5);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        org.jfree.data.xy.XYDataset xYDataset37 = polarPlot36.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis38 = polarPlot36.getAxis();
        java.awt.Color color41 = java.awt.Color.getColor("ERROR : Relative To String", 7);
        polarPlot36.setRadiusGridlinePaint((java.awt.Paint) color41);
        java.awt.Paint paint43 = polarPlot36.getAngleLabelPaint();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNull(xYDataset37);
        org.junit.Assert.assertNotNull(valueAxis38);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertNotNull(paint43);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.ChartProgressListener chartProgressListener28 = null;
        jFreeChart27.removeProgressListener(chartProgressListener28);
        org.jfree.chart.event.ChartChangeListener chartChangeListener30 = null;
        try {
            jFreeChart27.addChangeListener(chartChangeListener30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        org.jfree.chart.text.TextAnchor textAnchor4 = itemLabelPosition3.getTextAnchor();
        org.jfree.chart.text.TextAnchor textAnchor5 = itemLabelPosition3.getTextAnchor();
        java.lang.Object obj6 = null;
        boolean boolean7 = textAnchor5.equals(obj6);
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset1 = new org.jfree.data.category.DefaultCategoryDataset();
        int int3 = defaultCategoryDataset1.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1);
        try {
            java.lang.String str7 = intervalCategoryToolTipGenerator0.generateToolTip((org.jfree.data.category.CategoryDataset) defaultCategoryDataset1, 0, 9999);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.0d + "'", number4.equals(0.0d));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot7.getDomainAxisEdge();
        boolean boolean9 = xYPlot7.isRangeZoomable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        try {
            xYPlot7.handleClick((int) (short) -1, (int) (short) 100, plotRenderingInfo12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.lang.String str0 = org.jfree.chart.ui.Licences.LGPL;
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) ' ', 100);
        boolean boolean7 = lineAndShapeRenderer2.isSeriesVisible((int) ' ');
        java.awt.Paint paint8 = lineAndShapeRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=]", font1, paint8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = labelBlock9.getMargin();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        labelBlock9.setPaint((java.awt.Paint) color11);
        double double13 = labelBlock9.getHeight();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray23 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot19.setRenderers(categoryItemRendererArray23);
        categoryPlot19.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot19.getDomainMarkers(layer27);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(categoryItemRendererArray23);
        org.junit.Assert.assertNull(collection28);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        org.jfree.data.xy.XYDataset xYDataset37 = polarPlot36.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis38 = polarPlot36.getAxis();
        java.awt.Color color41 = java.awt.Color.getColor("ERROR : Relative To String", 7);
        polarPlot36.setRadiusGridlinePaint((java.awt.Paint) color41);
        boolean boolean43 = polarPlot36.isAngleLabelsVisible();
        org.jfree.data.xy.XYDataset xYDataset44 = polarPlot36.getDataset();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNull(xYDataset37);
        org.junit.Assert.assertNotNull(valueAxis38);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNull(xYDataset44);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color4 = java.awt.Color.magenta;
        valueMarker3.setOutlinePaint((java.awt.Paint) color4);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int7 = color6.getGreen();
        valueMarker3.setOutlinePaint((java.awt.Paint) color6);
        java.awt.Color color9 = java.awt.Color.magenta;
        valueMarker3.setLabelPaint((java.awt.Paint) color9);
        java.awt.color.ColorSpace colorSpace11 = color9.getColorSpace();
        float[] floatArray12 = new float[] {};
        try {
            float[] floatArray13 = color0.getComponents(colorSpace11, floatArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertNotNull(floatArray12);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = lineAndShapeRenderer1.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint6 = lineAndShapeRenderer1.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = lineAndShapeRenderer1.getPlot();
        java.awt.Color color12 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer1.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color12, true);
        boolean boolean15 = lineAndShapeRenderer1.getUseFillPaint();
        java.lang.Boolean boolean17 = lineAndShapeRenderer1.getSeriesShapesFilled(0);
        boolean boolean18 = axisSpace0.equals((java.lang.Object) lineAndShapeRenderer1);
        org.jfree.chart.axis.AxisSpace axisSpace19 = new org.jfree.chart.axis.AxisSpace();
        axisSpace19.setRight((double) 100L);
        axisSpace19.setLeft(0.0d);
        axisSpace0.ensureAtLeast(axisSpace19);
        java.lang.Object obj25 = axisSpace0.clone();
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryPlot7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("LengthConstraintType.NONE");
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color7 = java.awt.Color.magenta;
        valueMarker6.setOutlinePaint((java.awt.Paint) color7);
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker6.setLabelTextAnchor(textAnchor9);
        try {
            textLine1.draw(graphics2D2, (float) 'a', (float) 1559372400000L, textAnchor9, (float) (short) -1, (float) 9999, (double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(15);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = lineAndShapeRenderer1.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint6 = lineAndShapeRenderer1.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = lineAndShapeRenderer1.getPlot();
        java.awt.Color color12 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer1.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color12, true);
        boolean boolean15 = lineAndShapeRenderer1.getUseFillPaint();
        java.lang.Boolean boolean17 = lineAndShapeRenderer1.getSeriesShapesFilled(0);
        boolean boolean18 = axisSpace0.equals((java.lang.Object) lineAndShapeRenderer1);
        org.jfree.chart.axis.AxisSpace axisSpace19 = new org.jfree.chart.axis.AxisSpace();
        axisSpace19.setRight((double) 100L);
        axisSpace19.setLeft(0.0d);
        axisSpace0.ensureAtLeast(axisSpace19);
        double double25 = axisSpace0.getLeft();
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryPlot7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = lineAndShapeRenderer1.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint6 = lineAndShapeRenderer1.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = lineAndShapeRenderer1.getPlot();
        java.awt.Color color12 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer1.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color12, true);
        boolean boolean15 = lineAndShapeRenderer1.getUseFillPaint();
        java.lang.Boolean boolean17 = lineAndShapeRenderer1.getSeriesShapesFilled(0);
        boolean boolean18 = axisSpace0.equals((java.lang.Object) lineAndShapeRenderer1);
        java.awt.Shape shape20 = lineAndShapeRenderer1.lookupSeriesShape((int) (byte) -1);
        java.awt.Font font23 = lineAndShapeRenderer1.getItemLabelFont((int) (byte) 0, (int) (byte) 100);
        lineAndShapeRenderer1.setBaseShapesVisible(true);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryPlot7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.labels.StandardCategoryToolTipGenerator standardCategoryToolTipGenerator0 = new org.jfree.chart.labels.StandardCategoryToolTipGenerator();
        java.lang.String str1 = standardCategoryToolTipGenerator0.getLabelFormat();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection2 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.String str5 = standardCategoryToolTipGenerator0.generateToolTip((org.jfree.data.category.CategoryDataset) taskSeriesCollection2, (int) '#', 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "({0}, {1}) = {2}" + "'", str1.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
        int int3 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) "");
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        keyToGroupMap1.mapKeyToGroup((java.lang.Comparable) 8, (java.lang.Comparable) dateTickUnit5);
        java.lang.String str7 = dateTickUnit5.toString();
        int int8 = dateTickUnit5.getRollUnit();
        java.util.Date date9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D12 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean13 = numberAxis3D12.getAutoRangeIncludesZero();
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle17.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle17.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = lineAndShapeRenderer24.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint29 = lineAndShapeRenderer24.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = lineAndShapeRenderer24.getPlot();
        java.awt.Color color35 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer24.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color35, true);
        boolean boolean38 = lineAndShapeRenderer24.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier39 = lineAndShapeRenderer24.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer24);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray42 = new org.jfree.chart.axis.ValueAxis[] { valueAxis41 };
        categoryPlot40.setRangeAxes(valueAxisArray42);
        categoryPlot40.setDrawSharedDomainAxis(false);
        boolean boolean46 = categoryPlot40.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot40.getRangeAxisEdge();
        double double48 = dateAxis14.valueToJava2D(0.0d, rectangle2D20, rectangleEdge47);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset10, (org.jfree.chart.axis.ValueAxis) numberAxis3D12, (org.jfree.chart.axis.ValueAxis) dateAxis14, xYItemRenderer49);
        java.util.TimeZone timeZone51 = dateAxis14.getTimeZone();
        try {
            java.util.Date date52 = dateTickUnit5.rollDate(date9, timeZone51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str7.equals("DateTickUnit[DAY, 1]"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2 + "'", int8 == 2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(rectangle2D20);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(categoryPlot30);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(drawingSupplier39);
        org.junit.Assert.assertNotNull(valueAxisArray42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone51);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        int int0 = org.jfree.data.time.SerialDate.FOURTH_WEEK_IN_MONTH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.general.WaferMapDataset waferMapDataset0 = null;
        org.jfree.chart.plot.WaferMapPlot waferMapPlot1 = new org.jfree.chart.plot.WaferMapPlot(waferMapDataset0);
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Color color16 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer5.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color16, true);
        boolean boolean19 = lineAndShapeRenderer5.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier20 = lineAndShapeRenderer5.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer5);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray23 = new org.jfree.chart.axis.ValueAxis[] { valueAxis22 };
        categoryPlot21.setRangeAxes(valueAxisArray23);
        org.jfree.chart.JFreeChart jFreeChart25 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot21);
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) year26);
        categoryPlot21.rendererChanged(rendererChangeEvent27);
        waferMapPlot1.rendererChanged(rendererChangeEvent27);
        try {
            org.jfree.chart.LegendItemCollection legendItemCollection30 = waferMapPlot1.getLegendItems();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(drawingSupplier20);
        org.junit.Assert.assertNotNull(valueAxisArray23);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        java.lang.Number number1 = null;
        java.lang.Number number3 = null;
        java.lang.Number number7 = null;
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 3, number1, (java.lang.Number) 10, number3, (java.lang.Number) 12.0d, (java.lang.Number) 10.0f, (java.lang.Number) (short) 1, number7, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getMean();
        java.lang.Number number11 = boxAndWhiskerItem9.getQ1();
        java.lang.Number number12 = boxAndWhiskerItem9.getQ1();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 3 + "'", number10.equals(3));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10 + "'", number11.equals(10));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10 + "'", number12.equals(10));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setFixedDimension((double) (short) -1);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        boolean boolean8 = categoryAxis0.isAxisLineVisible();
        double double9 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot19.getDomainAxisLocation();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D26 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D26.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset24, (org.jfree.chart.axis.ValueAxis) numberAxis3D26, valueAxis29, xYItemRenderer30);
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        xYPlot31.setOrientation(plotOrientation32);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation23, plotOrientation32);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(rectangleEdge34);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        int int28 = categoryPlot19.getDatasetCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = categoryPlot19.getDomainAxisForDataset((int) (short) -1);
        java.awt.Color color32 = org.jfree.chart.util.PaintUtilities.stringToColor("");
        categoryPlot19.setDomainGridlinePaint((java.awt.Paint) color32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        try {
            categoryPlot19.handleClick(1, 0, plotRenderingInfo36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertNull(categoryAxis30);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        java.util.TimeZone timeZone0 = org.jfree.chart.axis.SegmentedTimeline.DEFAULT_TIME_ZONE;
        org.junit.Assert.assertNull(timeZone0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        java.awt.Paint paint16 = null;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape4, stroke13, paint16);
        int int18 = legendItem17.getDatasetIndex();
        legendItem17.setDatasetIndex((int) (short) 0);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset21 = new org.jfree.data.category.DefaultCategoryDataset();
        int int23 = defaultCategoryDataset21.getRowIndex((java.lang.Comparable) 2.0d);
        legendItem17.setDataset((org.jfree.data.general.Dataset) defaultCategoryDataset21);
        java.lang.Number number25 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset21);
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0.0d + "'", number25.equals(0.0d));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Stroke stroke8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer0.setSeriesStroke((int) (byte) 1, stroke8, true);
        boolean boolean11 = lineAndShapeRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setRight((double) 100L);
        axisSpace0.setLeft(0.0d);
        axisSpace0.setLeft((double) 0.8f);
        axisSpace0.setTop(Double.NaN);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = textTitle1.getPosition();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.Range range4 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint(range4, (double) (-1));
        try {
            org.jfree.chart.util.Size2D size2D7 = textTitle1.arrange(graphics2D3, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("Category Plot", "SortOrder.ASCENDING", "2019", "");
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener1 = null;
        boolean boolean2 = categoryAxis0.hasListener(eventListener1);
        categoryAxis0.setTickMarkInsideLength((float) 100L);
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) ' ');
        boolean boolean7 = categoryAxis0.isTickLabelsVisible();
        float float8 = categoryAxis0.getTickMarkInsideLength();
        java.awt.Paint paint9 = categoryAxis0.getTickMarkPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 100.0f + "'", float8 == 100.0f);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        java.lang.Object obj2 = barRenderer0.clone();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = null;
        lineAndShapeRenderer3.setLegendItemToolTipGenerator(categorySeriesLabelGenerator4);
        java.awt.Stroke stroke7 = lineAndShapeRenderer3.lookupSeriesOutlineStroke((int) ' ');
        barRenderer0.setBaseOutlineStroke(stroke7, true);
        java.awt.Shape shape11 = barRenderer0.lookupSeriesShape(15);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot19.markerChanged(markerChangeEvent28);
        org.jfree.chart.plot.Plot plot30 = categoryPlot19.getRootPlot();
        org.jfree.chart.axis.AxisSpace axisSpace31 = new org.jfree.chart.axis.AxisSpace();
        axisSpace31.setRight((double) 100L);
        axisSpace31.setLeft(0.0d);
        categoryPlot19.setFixedDomainAxisSpace(axisSpace31);
        categoryPlot19.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(plot30);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.isDrawBarOutline();
        java.lang.Object obj2 = barRenderer0.clone();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator4 = null;
        lineAndShapeRenderer3.setLegendItemToolTipGenerator(categorySeriesLabelGenerator4);
        java.awt.Stroke stroke7 = lineAndShapeRenderer3.lookupSeriesOutlineStroke((int) ' ');
        barRenderer0.setBaseOutlineStroke(stroke7, true);
        java.awt.Color color14 = org.jfree.chart.util.PaintUtilities.stringToColor("");
        float[] floatArray21 = new float[] { 10, (-1.0f), 0.5f, 10.0f, 3, 9999 };
        float[] floatArray22 = color14.getRGBColorComponents(floatArray21);
        org.jfree.chart.plot.ValueMarker valueMarker24 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color25 = java.awt.Color.magenta;
        valueMarker24.setOutlinePaint((java.awt.Paint) color25);
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int28 = color27.getGreen();
        valueMarker24.setOutlinePaint((java.awt.Paint) color27);
        java.awt.Stroke stroke30 = valueMarker24.getStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = lineAndShapeRenderer31.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint36 = lineAndShapeRenderer31.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = lineAndShapeRenderer31.getPlot();
        java.awt.Color color42 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer31.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color42, true);
        boolean boolean45 = lineAndShapeRenderer31.getUseFillPaint();
        java.lang.Boolean boolean47 = lineAndShapeRenderer31.getSeriesShapesFilled(0);
        java.awt.Color color48 = java.awt.Color.LIGHT_GRAY;
        lineAndShapeRenderer31.setBaseItemLabelPaint((java.awt.Paint) color48);
        java.awt.Stroke stroke50 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        org.jfree.chart.plot.IntervalMarker intervalMarker52 = new org.jfree.chart.plot.IntervalMarker((double) 0.8f, 0.0d, (java.awt.Paint) color14, stroke30, (java.awt.Paint) color48, stroke50, 1.0f);
        barRenderer0.setSeriesItemLabelPaint(11, (java.awt.Paint) color14, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(categoryPlot37);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(boolean47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(stroke50);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        float float25 = categoryPlot19.getBackgroundImageAlpha();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot19.getLegendItems();
        org.jfree.chart.axis.ValueAxis valueAxis28 = categoryPlot19.getRangeAxis((int) (byte) 1);
        java.awt.Paint paint29 = null;
        try {
            categoryPlot19.setRangeGridlinePaint(paint29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertNull(valueAxis28);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle3.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D6 = textTitle3.getBounds();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener8 = null;
        boolean boolean9 = categoryAxis7.hasListener(eventListener8);
        categoryAxis7.setFixedDimension((double) (short) -1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor12 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        double double43 = categoryAxis7.getCategoryJava2DCoordinate(categoryAnchor12, (int) 'a', 2, rectangle2D15, rectangleEdge42);
        double double44 = dateAxis0.valueToJava2D((double) (short) 100, rectangle2D6, rectangleEdge42);
        dateAxis0.setRangeWithMargins((double) (short) -1, 0.05d);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance((int) '#');
        serialDate1.setDescription("");
        org.junit.Assert.assertNotNull(serialDate1);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        polarPlot36.removeCornerTextItem("ERROR : Relative To String");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        polarPlot36.zoomDomainAxes(12.0d, (double) (short) 0, plotRenderingInfo41, point2D42);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        java.awt.Shape shape2 = layeredBarRenderer0.getSeriesShape((int) 'a');
        org.junit.Assert.assertNull(shape2);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        org.jfree.chart.labels.PieSectionLabelGenerator pieSectionLabelGenerator51 = null;
        try {
            ringPlot50.setLegendLabelGenerator(pieSectionLabelGenerator51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot19.zoomRangeAxes(8.0d, plotRenderingInfo26, point2D27);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.renderer.category.LayeredBarRenderer layeredBarRenderer0 = new org.jfree.chart.renderer.category.LayeredBarRenderer();
        java.awt.Color color2 = java.awt.Color.BLACK;
        layeredBarRenderer0.setSeriesOutlinePaint(4, (java.awt.Paint) color2, true);
        double double6 = layeredBarRenderer0.getSeriesBarWidth(9);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        java.lang.Number number1 = null;
        java.lang.Number number3 = null;
        java.lang.Number number7 = null;
        java.util.List list8 = null;
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem9 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 3, number1, (java.lang.Number) 10, number3, (java.lang.Number) 12.0d, (java.lang.Number) 10.0f, (java.lang.Number) (short) 1, number7, list8);
        java.lang.Number number10 = boxAndWhiskerItem9.getMean();
        java.lang.Number number11 = boxAndWhiskerItem9.getMaxOutlier();
        java.lang.Number number12 = boxAndWhiskerItem9.getQ1();
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 3 + "'", number10.equals(3));
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 10 + "'", number12.equals(10));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
        java.lang.String str1 = datasetGroup0.getID();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NOID" + "'", str1.equals("NOID"));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.renderer.category.StackedBarRenderer3D stackedBarRenderer3D2 = new org.jfree.chart.renderer.category.StackedBarRenderer3D(4.0d, Double.NaN);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset3 = new org.jfree.data.category.DefaultCategoryDataset();
        int int5 = defaultCategoryDataset3.getRowIndex((java.lang.Comparable) 2.0d);
        org.jfree.data.Range range6 = stackedBarRenderer3D2.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        org.jfree.data.xy.XYDataset xYDataset37 = polarPlot36.getDataset();
        org.jfree.chart.axis.ValueAxis valueAxis38 = polarPlot36.getAxis();
        polarPlot36.setRadiusGridlinesVisible(true);
        double double41 = polarPlot36.getMaxRadius();
        polarPlot36.clearCornerTextItems();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNull(xYDataset37);
        org.junit.Assert.assertNotNull(valueAxis38);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.05d + "'", double41 == 1.05d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setName("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.LegendItemCollection legendItemCollection3 = new org.jfree.chart.LegendItemCollection();
        boolean boolean4 = basicProjectInfo0.equals((java.lang.Object) legendItemCollection3);
        java.lang.String str5 = basicProjectInfo0.getName();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str5.equals("TextBlockAnchor.CENTER_LEFT"));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
        int int3 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) "");
        keyToGroupMap1.mapKeyToGroup((java.lang.Comparable) 1559372400000L, (java.lang.Comparable) 10.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.renderer.category.StackedBarRenderer stackedBarRenderer1 = new org.jfree.chart.renderer.category.StackedBarRenderer(true);
        double double2 = stackedBarRenderer1.getItemMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = xYPlot7.getAxisOffset();
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        boolean boolean37 = numberAxis3D31.isAutoTickUnitSelection();
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo0.setName("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.LegendItemCollection legendItemCollection3 = new org.jfree.chart.LegendItemCollection();
        boolean boolean4 = basicProjectInfo0.equals((java.lang.Object) legendItemCollection3);
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo();
        basicProjectInfo5.setName("TextBlockAnchor.CENTER_LEFT");
        org.jfree.chart.LegendItemCollection legendItemCollection8 = new org.jfree.chart.LegendItemCollection();
        boolean boolean9 = basicProjectInfo5.equals((java.lang.Object) legendItemCollection8);
        legendItemCollection3.addAll(legendItemCollection8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent28 = null;
        categoryPlot19.markerChanged(markerChangeEvent28);
        org.jfree.chart.block.BlockBorder blockBorder30 = new org.jfree.chart.block.BlockBorder();
        java.awt.Paint paint31 = blockBorder30.getPaint();
        categoryPlot19.setRangeGridlinePaint(paint31);
        double[][] doubleArray35 = new double[][] {};
        org.jfree.data.category.CategoryDataset categoryDataset36 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("-4,-4,4,4", "", doubleArray35);
        categoryPlot19.setDataset(categoryDataset36);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(categoryDataset36);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.awt.Font font0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.data.KeyToGroupMap keyToGroupMap2 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
        int int4 = keyToGroupMap2.getGroupIndex((java.lang.Comparable) "");
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        keyToGroupMap2.mapKeyToGroup((java.lang.Comparable) 8, (java.lang.Comparable) dateTickUnit6);
        java.lang.String str8 = dateTickUnit6.toString();
        try {
            org.jfree.chart.axis.TickUnit tickUnit9 = tickUnits0.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit6);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DateTickUnit[DAY, 1]" + "'", str8.equals("DateTickUnit[DAY, 1]"));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        java.lang.Object obj4 = segmentedTimeline3.clone();
        int int5 = segmentedTimeline3.getSegmentsExcluded();
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline9 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = lineAndShapeRenderer13.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint18 = lineAndShapeRenderer13.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = lineAndShapeRenderer13.getPlot();
        java.awt.Color color24 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer13.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color24, true);
        boolean boolean27 = lineAndShapeRenderer13.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier28 = lineAndShapeRenderer13.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer13);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer33 = null;
        categoryPlot29.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker32, layer33);
        java.awt.Paint paint35 = categoryPlot29.getBackgroundPaint();
        boolean boolean36 = segmentedTimeline9.equals((java.lang.Object) categoryPlot29);
        try {
            segmentedTimeline3.setBaseTimeline(segmentedTimeline9);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: / by zero");
        } catch (java.lang.ArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(obj4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(categoryPlot19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(drawingSupplier28);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        int int1 = objectList0.size();
        boolean boolean3 = objectList0.equals((java.lang.Object) "org.jfree.chart.event.ChartChangeEvent[source=]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition3 = lineAndShapeRenderer0.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint5 = lineAndShapeRenderer0.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = lineAndShapeRenderer0.getPlot();
        java.awt.Color color11 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color11, true);
        boolean boolean14 = lineAndShapeRenderer0.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = lineAndShapeRenderer0.getDrawingSupplier();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = null;
        lineAndShapeRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator16);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer0.getDrawingSupplier();
        boolean boolean19 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        org.junit.Assert.assertNotNull(itemLabelPosition3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(categoryPlot6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(drawingSupplier15);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        try {
            defaultKeyedValues0.removeValue(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
        org.jfree.chart.entity.EntityCollection entityCollection1 = blockResult0.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setItemMargin(4.0d);
        barRenderer0.setMaximumBarWidth((double) 0.0f);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis1.hasListener(eventListener2);
        categoryAxis1.setTickMarkInsideLength((float) 100L);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) ' ');
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("TextBlockAnchor.CENTER_LEFT", font7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextAnchor textAnchor10 = null;
        try {
            float float11 = textFragment8.calculateBaselineOffset(graphics2D9, textAnchor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean3 = numberAxis3D2.getAutoRangeIncludesZero();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle7.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle7.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer14.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint19 = lineAndShapeRenderer14.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = lineAndShapeRenderer14.getPlot();
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer14.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color25, true);
        boolean boolean28 = lineAndShapeRenderer14.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = lineAndShapeRenderer14.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { valueAxis31 };
        categoryPlot30.setRangeAxes(valueAxisArray32);
        categoryPlot30.setDrawSharedDomainAxis(false);
        boolean boolean36 = categoryPlot30.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot30.getRangeAxisEdge();
        double double38 = dateAxis4.valueToJava2D(0.0d, rectangle2D10, rectangleEdge37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = xYPlot40.getFixedRangeAxisSpace();
        org.jfree.chart.plot.ValueMarker valueMarker44 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color45 = java.awt.Color.magenta;
        valueMarker44.setOutlinePaint((java.awt.Paint) color45);
        java.awt.Color color47 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int48 = color47.getGreen();
        valueMarker44.setOutlinePaint((java.awt.Paint) color47);
        java.awt.Color color50 = java.awt.Color.magenta;
        valueMarker44.setLabelPaint((java.awt.Paint) color50);
        float float52 = valueMarker44.getAlpha();
        java.awt.Paint paint53 = valueMarker44.getOutlinePaint();
        org.jfree.chart.util.Layer layer54 = null;
        xYPlot40.addRangeMarker((int) (short) 10, (org.jfree.chart.plot.Marker) valueMarker44, layer54);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryPlot20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNull(axisSpace41);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + float52 + "' != '" + 0.8f + "'", float52 == 0.8f);
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        java.lang.Number number3 = null;
        org.jfree.data.DefaultKeyedValues2D defaultKeyedValues2D9 = new org.jfree.data.DefaultKeyedValues2D(true);
        java.util.List list10 = defaultKeyedValues2D9.getRowKeys();
        org.jfree.data.statistics.BoxAndWhiskerItem boxAndWhiskerItem11 = new org.jfree.data.statistics.BoxAndWhiskerItem((java.lang.Number) 3.0d, (java.lang.Number) (-1.0f), (java.lang.Number) (short) 100, number3, (java.lang.Number) (-1.0f), (java.lang.Number) 4.0d, (java.lang.Number) 8.0d, (java.lang.Number) 1.0f, list10);
        java.lang.Number number12 = boxAndWhiskerItem11.getMaxOutlier();
        org.junit.Assert.assertNotNull(list10);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1.0f + "'", number12.equals(1.0f));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        java.awt.Paint paint16 = null;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape4, stroke13, paint16);
        legendItem17.setSeriesKey((java.lang.Comparable) "NOID");
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        java.awt.Stroke stroke51 = ringPlot50.getBaseSectionOutlineStroke();
        java.awt.Graphics2D graphics2D52 = null;
        org.jfree.chart.axis.DateAxis dateAxis53 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle56.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D59 = textTitle56.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset60 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = null;
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer63 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition66 = lineAndShapeRenderer63.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint68 = lineAndShapeRenderer63.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = lineAndShapeRenderer63.getPlot();
        java.awt.Color color74 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer63.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color74, true);
        boolean boolean77 = lineAndShapeRenderer63.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier78 = lineAndShapeRenderer63.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot79 = new org.jfree.chart.plot.CategoryPlot(categoryDataset60, categoryAxis61, valueAxis62, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer63);
        org.jfree.chart.axis.ValueAxis valueAxis80 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray81 = new org.jfree.chart.axis.ValueAxis[] { valueAxis80 };
        categoryPlot79.setRangeAxes(valueAxisArray81);
        categoryPlot79.setDrawSharedDomainAxis(false);
        boolean boolean85 = categoryPlot79.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = categoryPlot79.getRangeAxisEdge();
        double double87 = dateAxis53.valueToJava2D(0.0d, rectangle2D59, rectangleEdge86);
        try {
            ringPlot50.drawOutline(graphics2D52, rectangle2D59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(rectangle2D59);
        org.junit.Assert.assertNotNull(itemLabelPosition66);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNull(categoryPlot69);
        org.junit.Assert.assertNotNull(color74);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNull(drawingSupplier78);
        org.junit.Assert.assertNotNull(valueAxisArray81);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertNotNull(rectangleEdge86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        java.awt.Paint paint0 = org.jfree.chart.renderer.category.LineRenderer3D.DEFAULT_WALL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle3.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D6 = textTitle3.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = lineAndShapeRenderer10.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint15 = lineAndShapeRenderer10.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = lineAndShapeRenderer10.getPlot();
        java.awt.Color color21 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer10.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color21, true);
        boolean boolean24 = lineAndShapeRenderer10.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = lineAndShapeRenderer10.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer10);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] { valueAxis27 };
        categoryPlot26.setRangeAxes(valueAxisArray28);
        categoryPlot26.setDrawSharedDomainAxis(false);
        boolean boolean32 = categoryPlot26.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot26.getRangeAxisEdge();
        double double34 = dateAxis0.valueToJava2D(0.0d, rectangle2D6, rectangleEdge33);
        java.util.Date date35 = dateAxis0.getMinimumDate();
        org.jfree.chart.axis.DateTickUnit dateTickUnit36 = dateAxis0.getTickUnit();
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryPlot16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(drawingSupplier25);
        org.junit.Assert.assertNotNull(valueAxisArray28);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertNotNull(dateTickUnit36);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.data.KeyToGroupMap keyToGroupMap2 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
        int int4 = keyToGroupMap2.getGroupIndex((java.lang.Comparable) "");
        org.jfree.chart.axis.DateTickUnit dateTickUnit6 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        keyToGroupMap2.mapKeyToGroup((java.lang.Comparable) 8, (java.lang.Comparable) dateTickUnit6);
        org.jfree.chart.axis.DateAxis dateAxis8 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle11.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D14 = textTitle11.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = lineAndShapeRenderer18.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint23 = lineAndShapeRenderer18.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = lineAndShapeRenderer18.getPlot();
        java.awt.Color color29 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer18.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color29, true);
        boolean boolean32 = lineAndShapeRenderer18.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier33 = lineAndShapeRenderer18.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer18);
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray36 = new org.jfree.chart.axis.ValueAxis[] { valueAxis35 };
        categoryPlot34.setRangeAxes(valueAxisArray36);
        categoryPlot34.setDrawSharedDomainAxis(false);
        boolean boolean40 = categoryPlot34.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = categoryPlot34.getRangeAxisEdge();
        double double42 = dateAxis8.valueToJava2D(0.0d, rectangle2D14, rectangleEdge41);
        java.util.Date date43 = dateAxis8.getMinimumDate();
        java.lang.String str44 = dateTickUnit6.dateToString(date43);
        java.util.Date date45 = null;
        try {
            org.jfree.data.gantt.Task task46 = new org.jfree.data.gantt.Task("SortOrder.ASCENDING", date43, date45);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(dateTickUnit6);
        org.junit.Assert.assertNotNull(rectangle2D14);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(categoryPlot24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(drawingSupplier33);
        org.junit.Assert.assertNotNull(valueAxisArray36);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "12/31/69 4:00 PM" + "'", str44.equals("12/31/69 4:00 PM"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = lineAndShapeRenderer1.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint6 = lineAndShapeRenderer1.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = lineAndShapeRenderer1.getPlot();
        java.awt.Color color12 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer1.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color12, true);
        boolean boolean15 = lineAndShapeRenderer1.getUseFillPaint();
        java.lang.Boolean boolean17 = lineAndShapeRenderer1.getSeriesShapesFilled(0);
        boolean boolean18 = axisSpace0.equals((java.lang.Object) lineAndShapeRenderer1);
        java.awt.Shape shape20 = lineAndShapeRenderer1.lookupSeriesShape((int) (byte) -1);
        boolean boolean21 = lineAndShapeRenderer1.getBaseSeriesVisible();
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryPlot7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNull(boolean17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis1.hasListener(eventListener2);
        categoryAxis1.setFixedDimension((double) (short) -1);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
        categoryAxis1.configure();
        boolean boolean10 = month0.equals((java.lang.Object) categoryAxis1);
        java.lang.Object obj11 = categoryAxis1.clone();
        categoryAxis1.setLowerMargin((double) (-1L));
        categoryAxis1.setLabelURL("VerticalAlignment.BOTTOM");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline0 = org.jfree.chart.axis.SegmentedTimeline.newMondayThroughFridayTimeline();
        org.junit.Assert.assertNotNull(segmentedTimeline0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.DateTickUnit dateTickUnit1 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        int int2 = dateTickUnit1.getCalendarField();
        try {
            org.jfree.chart.axis.TickUnit tickUnit3 = tickUnits0.getLargerTickUnit((org.jfree.chart.axis.TickUnit) dateTickUnit1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dateTickUnit1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) ' ', 100);
        boolean boolean7 = lineAndShapeRenderer2.isSeriesVisible((int) ' ');
        java.awt.Paint paint8 = lineAndShapeRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=]", font1, paint8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = labelBlock9.getMargin();
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_BLUE;
        labelBlock9.setPaint((java.awt.Paint) color11);
        java.lang.Object obj13 = labelBlock9.clone();
        double double14 = labelBlock9.getContentXOffset();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(obj13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategoryToolTipGenerator.DEFAULT_TOOL_TIP_FORMAT_STRING;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "({0}, {1}) = {2}" + "'", str0.equals("({0}, {1}) = {2}"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean3 = numberAxis3D2.getAutoRangeIncludesZero();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle7.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle7.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer14.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint19 = lineAndShapeRenderer14.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = lineAndShapeRenderer14.getPlot();
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer14.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color25, true);
        boolean boolean28 = lineAndShapeRenderer14.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = lineAndShapeRenderer14.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { valueAxis31 };
        categoryPlot30.setRangeAxes(valueAxisArray32);
        categoryPlot30.setDrawSharedDomainAxis(false);
        boolean boolean36 = categoryPlot30.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot30.getRangeAxisEdge();
        double double38 = dateAxis4.valueToJava2D(0.0d, rectangle2D10, rectangleEdge37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer39);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis42 = xYPlot40.getRangeAxisForDataset((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 'index' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryPlot20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        java.awt.Paint paint16 = null;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape4, stroke13, paint16);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity20 = new org.jfree.chart.entity.TickLabelEntity(shape4, "({0}, {1}) = {3} - {4}", "org.jfree.chart.event.ChartChangeEvent[source=]");
        java.lang.String str21 = tickLabelEntity20.getShapeCoords();
        java.lang.String str22 = tickLabelEntity20.toString();
        tickLabelEntity20.setToolTipText("-4,-4,4,4");
        tickLabelEntity20.setURLText("ERROR : Relative To String");
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "-4,-4,4,4" + "'", str21.equals("-4,-4,4,4"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "ChartEntity: tooltip = ({0}, {1}) = {3} - {4}" + "'", str22.equals("ChartEntity: tooltip = ({0}, {1}) = {3} - {4}"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        java.io.ObjectInputStream objectInputStream0 = null;
        try {
            java.awt.Shape shape1 = org.jfree.chart.util.SerialUtilities.readShape(objectInputStream0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stream' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.chart.plot.XYPlot xYPlot0 = new org.jfree.chart.plot.XYPlot();
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis1.hasListener(eventListener2);
        categoryAxis1.setTickMarkInsideLength((float) 100L);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) ' ');
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer12.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint17 = lineAndShapeRenderer12.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = lineAndShapeRenderer12.getPlot();
        java.awt.Color color23 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer12.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color23, true);
        boolean boolean26 = lineAndShapeRenderer12.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = lineAndShapeRenderer12.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer12);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer32 = null;
        categoryPlot28.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker31, layer32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot28.getRangeAxisEdge(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot28.getDomainAxisEdge();
        java.awt.Font font38 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint39 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer42 = null;
        org.jfree.chart.text.TextBlock textBlock43 = org.jfree.chart.text.TextUtilities.createTextBlock("", font38, paint39, (float) '#', (int) (byte) -1, textMeasurer42);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = textBlock43.getLineAlignment();
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.util.Size2D size2D46 = textBlock43.calculateDimensions(graphics2D45);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment47 = textBlock43.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str49 = verticalAlignment48.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font7, paint8, rectangleEdge36, horizontalAlignment47, verticalAlignment48, rectangleInsets50);
        java.lang.Object obj52 = null;
        boolean boolean53 = horizontalAlignment47.equals(obj52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryPlot18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(drawingSupplier27);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(textBlock43);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(size2D46);
        org.junit.Assert.assertNotNull(horizontalAlignment47);
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str49.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.labels.IntervalCategoryToolTipGenerator intervalCategoryToolTipGenerator0 = new org.jfree.chart.labels.IntervalCategoryToolTipGenerator();
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection1 = new org.jfree.data.gantt.TaskSeriesCollection();
        try {
            java.lang.String str3 = intervalCategoryToolTipGenerator0.generateRowLabel((org.jfree.data.category.CategoryDataset) taskSeriesCollection1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        int int0 = org.jfree.data.time.SerialDate.FRIDAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("RectangleEdge.RIGHT", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        java.awt.Font font1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = lineAndShapeRenderer2.getNegativeItemLabelPosition((int) ' ', 100);
        boolean boolean7 = lineAndShapeRenderer2.isSeriesVisible((int) ' ');
        java.awt.Paint paint8 = lineAndShapeRenderer2.getBaseItemLabelPaint();
        org.jfree.chart.block.LabelBlock labelBlock9 = new org.jfree.chart.block.LabelBlock("org.jfree.chart.event.ChartChangeEvent[source=]", font1, paint8);
        labelBlock9.setWidth((double) (byte) -1);
        labelBlock9.setID("DateTickUnit[DAY, 1]");
        labelBlock9.setURLText("ChartEntity: tooltip = ({0}, {1}) = {3} - {4}");
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color2 = java.awt.Color.magenta;
        valueMarker1.setOutlinePaint((java.awt.Paint) color2);
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int5 = color4.getGreen();
        valueMarker1.setOutlinePaint((java.awt.Paint) color4);
        java.awt.Color color7 = java.awt.Color.magenta;
        valueMarker1.setLabelPaint((java.awt.Paint) color7);
        java.awt.Color color10 = org.jfree.chart.util.PaintUtilities.stringToColor("");
        float[] floatArray17 = new float[] { 10, (-1.0f), 0.5f, 10.0f, 3, 9999 };
        float[] floatArray18 = color10.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color7.getRGBColorComponents(floatArray17);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer statisticalLineAndShapeRenderer0 = new org.jfree.chart.renderer.category.StatisticalLineAndShapeRenderer();
        double double1 = statisticalLineAndShapeRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        java.lang.String str1 = textBlockAnchor0.toString();
        java.lang.String str2 = textBlockAnchor0.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str1.equals("TextBlockAnchor.CENTER_LEFT"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "TextBlockAnchor.CENTER_LEFT" + "'", str2.equals("TextBlockAnchor.CENTER_LEFT"));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        double double51 = ringPlot50.getInteriorGap();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.25d + "'", double51 == 0.25d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        java.lang.String str2 = sortOrder0.toString();
        java.lang.String str3 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "SortOrder.ASCENDING" + "'", str2.equals("SortOrder.ASCENDING"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SortOrder.ASCENDING" + "'", str3.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        boolean boolean2 = lengthConstraintType0.equals((java.lang.Object) (byte) 10);
        java.lang.String str3 = lengthConstraintType0.toString();
        org.jfree.chart.renderer.category.BarRenderer3D barRenderer3D4 = new org.jfree.chart.renderer.category.BarRenderer3D();
        boolean boolean5 = barRenderer3D4.getAutoPopulateSeriesOutlineStroke();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = lineAndShapeRenderer10.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint15 = lineAndShapeRenderer10.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = lineAndShapeRenderer10.getPlot();
        java.awt.Color color21 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer10.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color21, true);
        boolean boolean24 = lineAndShapeRenderer10.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = lineAndShapeRenderer10.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer10);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] { valueAxis27 };
        categoryPlot26.setRangeAxes(valueAxisArray28);
        categoryPlot26.setDrawSharedDomainAxis(false);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D33 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D33.setVerticalTickLabels(true);
        numberAxis3D33.setLowerBound((double) (byte) 1);
        org.jfree.chart.plot.ValueMarker valueMarker39 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color40 = java.awt.Color.magenta;
        valueMarker39.setOutlinePaint((java.awt.Paint) color40);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        int int43 = color42.getGreen();
        valueMarker39.setOutlinePaint((java.awt.Paint) color42);
        java.awt.Stroke stroke45 = valueMarker39.getStroke();
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        barRenderer3D4.drawRangeMarker(graphics2D6, categoryPlot26, (org.jfree.chart.axis.ValueAxis) numberAxis3D33, (org.jfree.chart.plot.Marker) valueMarker39, rectangle2D46);
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color51 = java.awt.Color.magenta;
        valueMarker50.setOutlinePaint((java.awt.Paint) color51);
        barRenderer3D4.setSeriesOutlinePaint((int) '#', (java.awt.Paint) color51, true);
        boolean boolean55 = lengthConstraintType0.equals((java.lang.Object) '#');
        org.junit.Assert.assertNotNull(lengthConstraintType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "LengthConstraintType.NONE" + "'", str3.equals("LengthConstraintType.NONE"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNull(categoryPlot16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(drawingSupplier25);
        org.junit.Assert.assertNotNull(valueAxisArray28);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis1.hasListener(eventListener2);
        categoryAxis1.setTickMarkInsideLength((float) 100L);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) ' ');
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer12.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint17 = lineAndShapeRenderer12.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = lineAndShapeRenderer12.getPlot();
        java.awt.Color color23 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer12.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color23, true);
        boolean boolean26 = lineAndShapeRenderer12.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = lineAndShapeRenderer12.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer12);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer32 = null;
        categoryPlot28.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker31, layer32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot28.getRangeAxisEdge(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot28.getDomainAxisEdge();
        java.awt.Font font38 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint39 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer42 = null;
        org.jfree.chart.text.TextBlock textBlock43 = org.jfree.chart.text.TextUtilities.createTextBlock("", font38, paint39, (float) '#', (int) (byte) -1, textMeasurer42);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = textBlock43.getLineAlignment();
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.util.Size2D size2D46 = textBlock43.calculateDimensions(graphics2D45);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment47 = textBlock43.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str49 = verticalAlignment48.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font7, paint8, rectangleEdge36, horizontalAlignment47, verticalAlignment48, rectangleInsets50);
        java.lang.Object obj52 = null;
        boolean boolean53 = textTitle51.equals(obj52);
        textTitle51.setID("LengthConstraintType.NONE");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryPlot18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(drawingSupplier27);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(textBlock43);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(size2D46);
        org.junit.Assert.assertNotNull(horizontalAlignment47);
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str49.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("NOID", "hi!", "{0}", "RectangleAnchor.BOTTOM_LEFT");
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        int int2 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) 2.0d);
        java.lang.Number number3 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener6 = null;
        boolean boolean7 = categoryAxis5.hasListener(eventListener6);
        categoryAxis5.setFixedDimension((double) (short) -1);
        java.awt.Font font11 = categoryAxis5.getTickLabelFont((java.lang.Comparable) '4');
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent12 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis5);
        categoryAxis5.configure();
        boolean boolean14 = month4.equals((java.lang.Object) categoryAxis5);
        int int15 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) boolean14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = lineAndShapeRenderer19.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint24 = lineAndShapeRenderer19.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = lineAndShapeRenderer19.getPlot();
        java.awt.Color color30 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer19.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color30, true);
        boolean boolean33 = lineAndShapeRenderer19.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier34 = lineAndShapeRenderer19.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer39 = null;
        categoryPlot35.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker38, layer39);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot35.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart43 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot35);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent44 = null;
        categoryPlot35.markerChanged(markerChangeEvent44);
        org.jfree.chart.plot.Plot plot46 = categoryPlot35.getRootPlot();
        defaultCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) plot46);
        org.jfree.data.general.PieDataset pieDataset49 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, 0);
        org.jfree.chart.plot.RingPlot ringPlot50 = new org.jfree.chart.plot.RingPlot(pieDataset49);
        java.awt.Shape shape51 = null;
        try {
            ringPlot50.setLegendItemShape(shape51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'shape' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0.0d + "'", number3.equals(0.0d));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNull(categoryPlot25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(drawingSupplier34);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plot46);
        org.junit.Assert.assertNotNull(pieDataset49);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        java.util.EventListener eventListener2 = null;
        boolean boolean3 = categoryAxis1.hasListener(eventListener2);
        categoryAxis1.setTickMarkInsideLength((float) 100L);
        java.awt.Font font7 = categoryAxis1.getTickLabelFont((java.lang.Comparable) ' ');
        java.awt.Paint paint8 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = lineAndShapeRenderer12.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint17 = lineAndShapeRenderer12.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = lineAndShapeRenderer12.getPlot();
        java.awt.Color color23 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer12.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color23, true);
        boolean boolean26 = lineAndShapeRenderer12.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier27 = lineAndShapeRenderer12.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer12);
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer32 = null;
        categoryPlot28.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker31, layer32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot28.getRangeAxisEdge(10);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot28.getDomainAxisEdge();
        java.awt.Font font38 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint39 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer42 = null;
        org.jfree.chart.text.TextBlock textBlock43 = org.jfree.chart.text.TextUtilities.createTextBlock("", font38, paint39, (float) '#', (int) (byte) -1, textMeasurer42);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment44 = textBlock43.getLineAlignment();
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.util.Size2D size2D46 = textBlock43.calculateDimensions(graphics2D45);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment47 = textBlock43.getLineAlignment();
        org.jfree.chart.util.VerticalAlignment verticalAlignment48 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str49 = verticalAlignment48.toString();
        org.jfree.chart.util.RectangleInsets rectangleInsets50 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.jfree.chart.title.TextTitle textTitle51 = new org.jfree.chart.title.TextTitle("-4,-4,4,4", font7, paint8, rectangleEdge36, horizontalAlignment47, verticalAlignment48, rectangleInsets50);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = textTitle51.getPosition();
        org.jfree.chart.util.RectangleInsets rectangleInsets53 = textTitle51.getPadding();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryPlot18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(drawingSupplier27);
        org.junit.Assert.assertNotNull(rectangleEdge35);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(font38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(textBlock43);
        org.junit.Assert.assertNotNull(horizontalAlignment44);
        org.junit.Assert.assertNotNull(size2D46);
        org.junit.Assert.assertNotNull(horizontalAlignment47);
        org.junit.Assert.assertNotNull(verticalAlignment48);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str49.equals("VerticalAlignment.BOTTOM"));
        org.junit.Assert.assertNotNull(rectangleInsets50);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(rectangleInsets53);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.renderer.category.LevelRenderer levelRenderer0 = new org.jfree.chart.renderer.category.LevelRenderer();
        java.awt.Stroke stroke2 = levelRenderer0.lookupSeriesOutlineStroke(9);
        org.jfree.chart.LegendItem legendItem5 = levelRenderer0.getLegendItem(9, (int) (byte) 100);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(legendItem5);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        numberAxis3D31.setLowerBound(0.05d);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D2.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, valueAxis5, xYItemRenderer6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot7.getDomainAxisEdge();
        org.jfree.chart.plot.ValueMarker valueMarker11 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        java.awt.Color color12 = java.awt.Color.magenta;
        valueMarker11.setOutlinePaint((java.awt.Paint) color12);
        org.jfree.chart.text.TextAnchor textAnchor14 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        valueMarker11.setLabelTextAnchor(textAnchor14);
        org.jfree.chart.util.Layer layer16 = null;
        xYPlot7.addRangeMarker((int) '#', (org.jfree.chart.plot.Marker) valueMarker11, layer16);
        xYPlot7.setRangeCrosshairVisible(false);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(textAnchor14);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("12/31/69 4:00 PM", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Stroke stroke13 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setSeriesStroke((int) (byte) 1, stroke13, true);
        java.awt.Paint paint16 = null;
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!", "({0}, {1}) = {3} - {4}", "", "({0}, {1}) = {3} - {4}", shape4, stroke13, paint16);
        int int18 = legendItem17.getDatasetIndex();
        legendItem17.setDatasetIndex((int) (short) 0);
        java.lang.String str21 = legendItem17.getURLText();
        java.lang.String str22 = legendItem17.getLabel();
        int int23 = legendItem17.getSeriesIndex();
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "({0}, {1}) = {3} - {4}" + "'", str21.equals("({0}, {1}) = {3} - {4}"));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "hi!" + "'", str22.equals("hi!"));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("UnitType.RELATIVE");
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.gantt.TaskSeriesCollection taskSeriesCollection0 = new org.jfree.data.gantt.TaskSeriesCollection();
        org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        org.jfree.chart.plot.MultiplePiePlot multiplePiePlot2 = new org.jfree.chart.plot.MultiplePiePlot((org.jfree.data.category.CategoryDataset) taskSeriesCollection0);
        multiplePiePlot2.setLimit((double) 60000L);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer5.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint10 = lineAndShapeRenderer5.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = lineAndShapeRenderer5.getPlot();
        java.awt.Color color16 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer5.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color16, true);
        lineAndShapeRenderer5.setBaseSeriesVisibleInLegend(true, true);
        java.awt.Stroke stroke22 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        lineAndShapeRenderer5.setBaseStroke(stroke22);
        lineAndShapeRenderer5.setAutoPopulateSeriesFillPaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = lineAndShapeRenderer5.getBaseNegativeItemLabelPosition();
        boolean boolean27 = multiplePiePlot2.equals((java.lang.Object) lineAndShapeRenderer5);
        org.junit.Assert.assertNull(range1);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryPlot11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        polarPlot36.removeCornerTextItem("ERROR : Relative To String");
        java.awt.Font font39 = polarPlot36.getNoDataMessageFont();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        polarPlot36.setAngleLabelPaint((java.awt.Paint) color40);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertNotNull(color40);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.data.DefaultKeyedValues defaultKeyedValues0 = new org.jfree.data.DefaultKeyedValues();
        defaultKeyedValues0.setValue((java.lang.Comparable) 0.0d, (java.lang.Number) 60000L);
        java.lang.Comparable comparable5 = null;
        try {
            defaultKeyedValues0.insertValue(1900, comparable5, (java.lang.Number) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray21 = new org.jfree.chart.axis.ValueAxis[] { valueAxis20 };
        categoryPlot19.setRangeAxes(valueAxisArray21);
        categoryPlot19.setDrawSharedDomainAxis(false);
        categoryPlot19.configureRangeAxes();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(valueAxisArray21);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer3.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = lineAndShapeRenderer3.getPlot();
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer3.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color14, true);
        boolean boolean17 = lineAndShapeRenderer3.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = lineAndShapeRenderer3.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.ValueMarker valueMarker22 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer23 = null;
        categoryPlot19.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker22, layer23);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot19.getRangeAxisEdge(10);
        org.jfree.chart.JFreeChart jFreeChart27 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot19);
        java.awt.Paint paint28 = jFreeChart27.getBorderPaint();
        try {
            org.jfree.chart.plot.XYPlot xYPlot29 = jFreeChart27.getXYPlot();
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.plot.XYPlot");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(categoryPlot9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(drawingSupplier18);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent1 = new org.jfree.chart.event.RendererChangeEvent((java.lang.Object) year0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        org.junit.Assert.assertNotNull(regularTimePeriod2);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.jfree.chart.axis.CategoryAxis3D categoryAxis3D1 = new org.jfree.chart.axis.CategoryAxis3D();
        categoryAxis3D1.removeCategoryLabelToolTip((java.lang.Comparable) "2019");
        boolean boolean4 = range0.equals((java.lang.Object) categoryAxis3D1);
        double double5 = range0.getCentralValue();
        org.junit.Assert.assertNotNull(range0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.5d + "'", double5 == 0.5d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.NumberAxis3D numberAxis3D1 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        java.awt.Shape shape2 = numberAxis3D1.getRightArrow();
        numberAxis3D1.setAutoRange(false);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.axis.SegmentedTimeline segmentedTimeline3 = new org.jfree.chart.axis.SegmentedTimeline(0L, (int) (byte) -1, (int) (byte) 100);
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = lineAndShapeRenderer7.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint12 = lineAndShapeRenderer7.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = lineAndShapeRenderer7.getPlot();
        java.awt.Color color18 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer7.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color18, true);
        boolean boolean21 = lineAndShapeRenderer7.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier22 = lineAndShapeRenderer7.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((double) (-1));
        org.jfree.chart.util.Layer layer27 = null;
        categoryPlot23.addRangeMarker(0, (org.jfree.chart.plot.Marker) valueMarker26, layer27);
        java.awt.Paint paint29 = categoryPlot23.getBackgroundPaint();
        boolean boolean30 = segmentedTimeline3.equals((java.lang.Object) categoryPlot23);
        java.awt.Font font32 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        java.awt.Paint paint33 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.jfree.chart.text.TextMeasurer textMeasurer36 = null;
        org.jfree.chart.text.TextBlock textBlock37 = org.jfree.chart.text.TextUtilities.createTextBlock("", font32, paint33, (float) '#', (int) (byte) -1, textMeasurer36);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment38 = textBlock37.getLineAlignment();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.util.Size2D size2D40 = textBlock37.calculateDimensions(graphics2D39);
        boolean boolean41 = categoryPlot23.equals((java.lang.Object) size2D40);
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D45 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D45.setVerticalTickLabels(true);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset43, (org.jfree.chart.axis.ValueAxis) numberAxis3D45, valueAxis48, xYItemRenderer49);
        org.jfree.chart.axis.AxisLocation axisLocation52 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        xYPlot50.setDomainAxisLocation((int) '4', axisLocation52);
        categoryPlot23.setRangeAxisLocation(0, axisLocation52);
        org.jfree.chart.axis.ValueAxis valueAxis55 = categoryPlot23.getRangeAxis();
        org.junit.Assert.assertNotNull(itemLabelPosition10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryPlot13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(drawingSupplier22);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(textBlock37);
        org.junit.Assert.assertNotNull(horizontalAlignment38);
        org.junit.Assert.assertNotNull(size2D40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(axisLocation52);
        org.junit.Assert.assertNull(valueAxis55);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.awt.Stroke stroke2 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean3 = standardGradientPaintTransformer1.equals((java.lang.Object) stroke2);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BASELINE_RIGHT" + "'", str1.equals("TextAnchor.BASELINE_RIGHT"));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer4.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint9 = lineAndShapeRenderer4.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = lineAndShapeRenderer4.getPlot();
        java.awt.Color color15 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer4.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color15, true);
        boolean boolean18 = lineAndShapeRenderer4.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = lineAndShapeRenderer4.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer4);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray22 = new org.jfree.chart.axis.ValueAxis[] { valueAxis21 };
        categoryPlot20.setRangeAxes(valueAxisArray22);
        categoryPlot20.setDrawSharedDomainAxis(false);
        java.awt.Font font26 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        boolean boolean27 = categoryPlot20.equals((java.lang.Object) font26);
        categoryPlot20.setBackgroundImageAlignment(3);
        org.jfree.chart.axis.NumberAxis3D numberAxis3D31 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        numberAxis3D31.setVerticalTickLabels(true);
        org.jfree.data.Range range34 = categoryPlot20.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis3D31);
        org.jfree.chart.renderer.PolarItemRenderer polarItemRenderer35 = null;
        org.jfree.chart.plot.PolarPlot polarPlot36 = new org.jfree.chart.plot.PolarPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D31, polarItemRenderer35);
        org.jfree.data.Range range37 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint39 = new org.jfree.chart.block.RectangleConstraint(range37, (double) (-1));
        boolean boolean40 = polarPlot36.equals((java.lang.Object) (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryPlot10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNull(drawingSupplier19);
        org.junit.Assert.assertNotNull(valueAxisArray22);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(range34);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.KeyToGroupMap keyToGroupMap1 = new org.jfree.data.KeyToGroupMap((java.lang.Comparable) 100);
        int int3 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) "");
        org.jfree.chart.axis.DateTickUnit dateTickUnit5 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        keyToGroupMap1.mapKeyToGroup((java.lang.Comparable) 8, (java.lang.Comparable) dateTickUnit5);
        int int8 = keyToGroupMap1.getGroupIndex((java.lang.Comparable) "ChartEntity: tooltip = ({0}, {1}) = {3} - {4}");
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
        org.junit.Assert.assertNotNull(dateTickUnit5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis3D numberAxis3D2 = new org.jfree.chart.axis.NumberAxis3D("({0}, {1}) = {3} - {4}");
        boolean boolean3 = numberAxis3D2.getAutoRangeIncludesZero();
        org.jfree.chart.axis.DateAxis dateAxis4 = new org.jfree.chart.axis.DateAxis();
        org.jfree.chart.title.TextTitle textTitle7 = new org.jfree.chart.title.TextTitle("DateTickUnit[DAY, 1]");
        textTitle7.setURLText("-4,-4,4,4");
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle7.getBounds();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = lineAndShapeRenderer14.getNegativeItemLabelPosition((int) ' ', 100);
        java.awt.Paint paint19 = lineAndShapeRenderer14.lookupSeriesPaint((int) (byte) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = lineAndShapeRenderer14.getPlot();
        java.awt.Color color25 = java.awt.Color.getHSBColor((float) (short) 100, 0.0f, (float) 'a');
        lineAndShapeRenderer14.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color25, true);
        boolean boolean28 = lineAndShapeRenderer14.getUseFillPaint();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier29 = lineAndShapeRenderer14.getDrawingSupplier();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer14);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray32 = new org.jfree.chart.axis.ValueAxis[] { valueAxis31 };
        categoryPlot30.setRangeAxes(valueAxisArray32);
        categoryPlot30.setDrawSharedDomainAxis(false);
        boolean boolean36 = categoryPlot30.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot30.getRangeAxisEdge();
        double double38 = dateAxis4.valueToJava2D(0.0d, rectangle2D10, rectangleEdge37);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis3D2, (org.jfree.chart.axis.ValueAxis) dateAxis4, xYItemRenderer39);
        java.util.TimeZone timeZone41 = dateAxis4.getTimeZone();
        java.text.DateFormat dateFormat42 = dateAxis4.getDateFormatOverride();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryPlot20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(drawingSupplier29);
        org.junit.Assert.assertNotNull(valueAxisArray32);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(dateFormat42);
    }
}

