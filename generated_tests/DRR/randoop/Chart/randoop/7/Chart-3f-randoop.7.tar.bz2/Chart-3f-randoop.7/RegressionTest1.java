import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        long long2 = year1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 6);
        long long8 = fixedMillisecond5.getMiddleMillisecond();
        java.util.Calendar calendar9 = null;
        fixedMillisecond5.peg(calendar9);
        java.util.Date date11 = fixedMillisecond5.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 100);
        timeSeriesDataItem13.setSelected(false);
        timeSeriesDataItem13.setValue((java.lang.Number) 11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        timeSeries3.setMaximumItemAge((long) ' ');
        java.util.List list12 = timeSeries3.getItems();
        timeSeries3.setNotify(true);
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener15);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) (-1.0f));
        boolean boolean9 = timeSeriesDataItem8.isSelected();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12);
        int int15 = month14.getMonth();
        boolean boolean16 = timeSeriesDataItem8.equals((java.lang.Object) month14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem18);
        java.lang.Object obj21 = seriesChangeEvent20.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo22 = null;
        seriesChangeEvent20.setSummary(seriesChangeInfo22);
        java.lang.String str24 = seriesChangeEvent20.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(obj21);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.previous();
        int int6 = month4.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 1561921199999L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        int int2 = month1.getYearValue();
        long long3 = month1.getSerialIndex();
        boolean boolean5 = month1.equals((java.lang.Object) "");
        org.jfree.data.time.Year year6 = month1.getYear();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getYearValue();
        boolean boolean9 = year6.equals((java.lang.Object) month7);
        java.lang.String str10 = year6.toString();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(11, year6);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.next();
        int int13 = month11.getYearValue();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2019 + "'", int8 == 2019);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2019" + "'", str10.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2019 + "'", int13 == 2019);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getFirstMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 1.0d);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        int int13 = month12.getMonth();
        java.util.Date date14 = month12.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond17.next();
        java.lang.Class<?> wildcardClass20 = regularTimePeriod19.getClass();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date23, timeZone25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
        timeSeriesDataItem28.setValue((java.lang.Number) (short) 10);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        java.util.Date date8 = month6.getEnd();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = fixedMillisecond11.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11);
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        boolean boolean20 = timeSeries17.getNotify();
        timeSeries17.setRangeDescription("hi!");
        double double23 = timeSeries17.getMinY();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str28 = timeSeries27.getDomainDescription();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        int int30 = month29.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month29, (java.lang.Number) (-1.0f));
        boolean boolean33 = timeSeriesDataItem32.isSelected();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        int int35 = month34.getMonth();
        java.util.Date date36 = month34.getEnd();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date36);
        int int39 = month38.getMonth();
        boolean boolean40 = timeSeriesDataItem32.equals((java.lang.Object) month38);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month38, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries27.addOrUpdate(timeSeriesDataItem42);
        boolean boolean44 = timeSeries17.equals((java.lang.Object) timeSeries27);
        boolean boolean45 = fixedMillisecond11.equals((java.lang.Object) boolean44);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener50 = null;
        timeSeries49.removeChangeListener(seriesChangeListener50);
        boolean boolean52 = timeSeries49.getNotify();
        timeSeries49.setRangeDescription("hi!");
        double double55 = timeSeries49.getMinY();
        timeSeries49.setMaximumItemAge((long) ' ');
        java.util.Collection collection58 = timeSeries49.getTimePeriods();
        timeSeries49.setDomainDescription("June 2019");
        int int61 = fixedMillisecond11.compareTo((java.lang.Object) timeSeries49);
        org.jfree.data.time.TimeSeries timeSeries65 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener66 = null;
        timeSeries65.removeChangeListener(seriesChangeListener66);
        timeSeries65.setNotify(true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener70 = null;
        timeSeries65.addChangeListener(seriesChangeListener70);
        boolean boolean72 = timeSeries49.equals((java.lang.Object) seriesChangeListener70);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "" + "'", str28.equals(""));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertEquals((double) double55, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection58);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 1 + "'", int61 == 1);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.next();
        long long7 = fixedMillisecond5.getSerialIndex();
        long long8 = fixedMillisecond5.getFirstMillisecond();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getFirstMillisecond(calendar9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        long long2 = month0.getSerialIndex();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getLastMillisecond(calendar4);
        java.util.Date date6 = fixedMillisecond1.getTime();
        long long7 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        long long5 = fixedMillisecond1.getFirstMillisecond(calendar4);
        java.lang.Number number6 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond1, number6);
        long long8 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str14 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(timeSeriesDataItem28);
        boolean boolean30 = timeSeries3.equals((java.lang.Object) timeSeries13);
        timeSeries13.setMaximumItemAge(0L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries13.removeChangeListener(seriesChangeListener33);
        java.util.List list35 = timeSeries13.getItems();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.Object obj40 = null;
        boolean boolean41 = timeSeries39.equals(obj40);
        double double42 = timeSeries39.getMaxY();
        org.jfree.data.time.Year year43 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = year43.previous();
        long long45 = year43.getFirstMillisecond();
        long long46 = year43.getFirstMillisecond();
        long long47 = year43.getFirstMillisecond();
        timeSeries39.add((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 8, true);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries54.removeChangeListener(seriesChangeListener55);
        boolean boolean57 = timeSeries54.getNotify();
        timeSeries54.setRangeDescription("hi!");
        double double60 = timeSeries54.getMinY();
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str65 = timeSeries64.getDomainDescription();
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month();
        int int67 = month66.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month66, (java.lang.Number) (-1.0f));
        boolean boolean70 = timeSeriesDataItem69.isSelected();
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month();
        int int72 = month71.getMonth();
        java.util.Date date73 = month71.getEnd();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date73);
        org.jfree.data.time.Month month75 = new org.jfree.data.time.Month(date73);
        int int76 = month75.getMonth();
        boolean boolean77 = timeSeriesDataItem69.equals((java.lang.Object) month75);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month75, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = timeSeries64.addOrUpdate(timeSeriesDataItem79);
        boolean boolean81 = timeSeries54.equals((java.lang.Object) timeSeries64);
        boolean boolean82 = year43.equals((java.lang.Object) boolean81);
        timeSeries13.update((org.jfree.data.time.RegularTimePeriod) year43, (java.lang.Number) 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(list35);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertEquals((double) double42, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1546329600000L + "'", long45 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1546329600000L + "'", long46 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1546329600000L + "'", long47 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertEquals((double) double60, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "" + "'", str65.equals(""));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 6 + "'", int67 == 6);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 6 + "'", int72 == 6);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 6 + "'", int76 == 6);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str14 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(timeSeriesDataItem28);
        boolean boolean30 = timeSeries3.equals((java.lang.Object) timeSeries13);
        timeSeries13.setMaximumItemAge(0L);
        java.lang.String str33 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month34 = new org.jfree.data.time.Month();
        int int35 = month34.getMonth();
        java.util.Date date36 = month34.getEnd();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year(date36);
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month(date36);
        int int39 = month38.getMonth();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        int int45 = month44.getMonth();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) day47, (java.lang.Number) 2019, false);
        long long51 = day47.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries55 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener56 = null;
        timeSeries55.removeChangeListener(seriesChangeListener56);
        boolean boolean58 = timeSeries55.getNotify();
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = year60.next();
        int int62 = timeSeries55.getIndex(regularTimePeriod61);
        int int63 = day47.compareTo((java.lang.Object) int62);
        int int64 = day47.getMonth();
        boolean boolean65 = month38.equals((java.lang.Object) day47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod66 = month38.next();
        timeSeries13.delete(regularTimePeriod66);
        org.jfree.data.time.Year year69 = new org.jfree.data.time.Year(4);
        try {
            timeSeries13.add((org.jfree.data.time.RegularTimePeriod) year69, (java.lang.Number) 1L, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(date36);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 43646L + "'", long51 == 43646L);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 6 + "'", int64 == 6);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod66);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        int int4 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries9.removeChangeListener(seriesChangeListener10);
        boolean boolean12 = timeSeries9.getNotify();
        timeSeries9.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.removeChangeListener(seriesChangeListener19);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries9.addAndOrUpdate(timeSeries18);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries25.removeChangeListener(seriesChangeListener26);
        boolean boolean28 = timeSeries25.getNotify();
        timeSeries25.setRangeDescription("hi!");
        double double31 = timeSeries25.getMinY();
        java.util.Collection collection32 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        java.lang.Class<?> wildcardClass33 = timeSeries9.getClass();
        int int34 = day3.compareTo((java.lang.Object) wildcardClass33);
        java.util.Calendar calendar35 = null;
        try {
            day3.peg(calendar35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection32);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 2019, false);
        int int17 = day3.compareTo((java.lang.Object) timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries23.removeChangeListener(seriesChangeListener24);
        timeSeries23.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        long long29 = month28.getFirstMillisecond();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 1.0d);
        int int32 = timeSeries23.getItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int34 = month33.getMonth();
        java.util.Date date35 = month33.getEnd();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date35);
        long long39 = fixedMillisecond38.getMiddleMillisecond();
        timeSeries23.setKey((java.lang.Comparable) long39);
        java.util.Collection collection41 = timeSeries23.getTimePeriods();
        java.util.Collection collection42 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        timeSeries9.removeAgedItems(1559372400000L, false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1559372400000L + "'", long29 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1561964399999L + "'", long39 == 1561964399999L);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertNotNull(collection42);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.clear();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (-1.0f));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate(timeSeriesDataItem13);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.removeChangeListener(seriesChangeListener19);
        java.lang.Class class21 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.addAndOrUpdate(timeSeries18);
        java.lang.Object obj23 = timeSeries22.clone();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate25 = day24.getSerialDate();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        int int27 = month26.getMonth();
        java.util.Date date28 = month26.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        int int30 = day29.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day29.previous();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener36 = null;
        timeSeries35.removeChangeListener(seriesChangeListener36);
        boolean boolean38 = timeSeries35.getNotify();
        timeSeries35.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener45 = null;
        timeSeries44.removeChangeListener(seriesChangeListener45);
        org.jfree.data.time.TimeSeries timeSeries47 = timeSeries35.addAndOrUpdate(timeSeries44);
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener52 = null;
        timeSeries51.removeChangeListener(seriesChangeListener52);
        boolean boolean54 = timeSeries51.getNotify();
        timeSeries51.setRangeDescription("hi!");
        double double57 = timeSeries51.getMinY();
        java.util.Collection collection58 = timeSeries35.getTimePeriodsUniqueToOtherSeries(timeSeries51);
        java.lang.Class<?> wildcardClass59 = timeSeries35.getClass();
        int int60 = day29.compareTo((java.lang.Object) wildcardClass59);
        boolean boolean61 = day24.equals((java.lang.Object) day29);
        timeSeries22.setKey((java.lang.Comparable) boolean61);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(obj23);
        org.junit.Assert.assertNotNull(serialDate25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(timeSeries47);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertEquals((double) double57, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection58);
        org.junit.Assert.assertNotNull(wildcardClass59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1 + "'", int60 == 1);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.clear();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (-1.0f));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate(timeSeriesDataItem13);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.removeChangeListener(seriesChangeListener19);
        java.lang.Class class21 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.addAndOrUpdate(timeSeries18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        int int29 = month28.getMonth();
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        timeSeries27.add((org.jfree.data.time.RegularTimePeriod) day31, (java.lang.Number) 2019, false);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries27.addPropertyChangeListener(propertyChangeListener35);
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        int int38 = month37.getYearValue();
        long long39 = month37.getSerialIndex();
        boolean boolean41 = month37.equals((java.lang.Object) "");
        org.jfree.data.time.Year year42 = month37.getYear();
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener47 = null;
        timeSeries46.removeChangeListener(seriesChangeListener47);
        boolean boolean49 = timeSeries46.getNotify();
        timeSeries46.setRangeDescription("hi!");
        double double52 = timeSeries46.getMinY();
        timeSeries46.setMaximumItemAge((long) ' ');
        java.util.Collection collection55 = timeSeries46.getTimePeriods();
        timeSeries46.setDomainDescription("June 2019");
        boolean boolean58 = year42.equals((java.lang.Object) "June 2019");
        boolean boolean59 = timeSeries27.equals((java.lang.Object) year42);
        int int60 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year42);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 2019 + "'", int38 == 2019);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 24234L + "'", long39 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(year42);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection55);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getFirstMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 1.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month8.next();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        int int2 = month1.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem4 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month1, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        boolean boolean9 = month1.equals((java.lang.Object) year8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year8.next();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month((int) (byte) 1, year8);
        long long12 = year8.getSerialIndex();
        java.util.Date date13 = year8.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str21 = timeSeries20.getDomainDescription();
        boolean boolean22 = timeSeries20.getNotify();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year24, (java.lang.Number) 24234L);
        boolean boolean27 = timeSeries20.equals((java.lang.Object) 24234L);
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.previous();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        int int31 = month30.getMonth();
        java.util.Date date32 = month30.getEnd();
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date32);
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date32);
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date32);
        long long36 = fixedMillisecond35.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener41 = null;
        timeSeries40.removeChangeListener(seriesChangeListener41);
        boolean boolean43 = timeSeries40.getNotify();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = year45.next();
        int int47 = timeSeries40.getIndex(regularTimePeriod46);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener48 = null;
        timeSeries40.addChangeListener(seriesChangeListener48);
        java.beans.PropertyChangeListener propertyChangeListener50 = null;
        timeSeries40.addPropertyChangeListener(propertyChangeListener50);
        int int52 = fixedMillisecond35.compareTo((java.lang.Object) propertyChangeListener50);
        long long53 = fixedMillisecond35.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries20.createCopy(regularTimePeriod29, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond35);
        int int55 = fixedMillisecond16.compareTo((java.lang.Object) regularTimePeriod29);
        int int56 = day14.compareTo((java.lang.Object) int55);
        int int57 = day14.getYear();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2019L + "'", long12 == 2019L);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "" + "'", str21.equals(""));
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
        org.junit.Assert.assertNotNull(date32);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1561964399999L + "'", long36 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1 + "'", int52 == 1);
        org.junit.Assert.assertTrue("'" + long53 + "' != '" + 1561964399999L + "'", long53 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1 + "'", int56 == 1);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 2019 + "'", int57 == 2019);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date11);
        long long14 = month13.getSerialIndex();
        timeSeries3.setKey((java.lang.Comparable) month13);
        java.util.Calendar calendar16 = null;
        try {
            long long17 = month13.getFirstMillisecond(calendar16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.clear();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (-1.0f));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate(timeSeriesDataItem13);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo15);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.addOrUpdate(timeSeriesDataItem17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        java.lang.Class<?> wildcardClass14 = month9.getClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date17, timeZone19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = fixedMillisecond21.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) ' ', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.previous();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        java.util.Date date10 = month8.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = fixedMillisecond13.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond13.next();
        java.lang.Class<?> wildcardClass16 = regularTimePeriod15.getClass();
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getMonth();
        java.util.Date date19 = month17.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        java.util.TimeZone timeZone21 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass16, date19, timeZone21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date19);
        int int24 = fixedMillisecond5.compareTo((java.lang.Object) day23);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str14 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(timeSeriesDataItem28);
        boolean boolean30 = timeSeries3.equals((java.lang.Object) timeSeries13);
        timeSeries13.setMaximumItemAge(0L);
        java.lang.String str33 = timeSeries13.getDomainDescription();
        double double34 = timeSeries13.getMinY();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 2.0d + "'", double34 == 2.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        int int6 = timeSeries3.getItemCount();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getMonth();
        java.util.Date date9 = month7.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) 1546329600000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month7.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.getDataItem(regularTimePeriod12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        int int15 = month14.getMonth();
        java.util.Date date16 = month14.getEnd();
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date16);
        org.jfree.data.time.SerialDate serialDate18 = day17.getSerialDate();
        long long19 = day17.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        java.util.Date date26 = month24.getEnd();
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date26);
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) day27, (java.lang.Number) 2019, false);
        int int31 = day17.compareTo((java.lang.Object) timeSeries23);
        int int32 = day17.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod33 = day17.previous();
        timeSeries3.add(regularTimePeriod33, (double) 11);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(serialDate18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod33);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (-1.0f));
        boolean boolean14 = timeSeriesDataItem13.isSelected();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17);
        int int20 = month19.getMonth();
        boolean boolean21 = timeSeriesDataItem13.equals((java.lang.Object) month19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (double) 2);
        org.jfree.data.time.Year year24 = month19.getYear();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries28.removeChangeListener(seriesChangeListener29);
        boolean boolean31 = timeSeries28.getNotify();
        timeSeries28.setRangeDescription("hi!");
        double double34 = timeSeries28.getMinY();
        timeSeries28.setMaximumItemAge((long) ' ');
        java.util.List list37 = timeSeries28.getItems();
        boolean boolean38 = month19.equals((java.lang.Object) timeSeries28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month19.next();
        timeSeries3.setKey((java.lang.Comparable) month19);
        java.util.List list41 = timeSeries3.getItems();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertNotNull(list41);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        int int10 = timeSeries3.getIndex(regularTimePeriod9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries3.addChangeListener(seriesChangeListener11);
        timeSeries3.removeAgedItems(false);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int28 = month27.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (-1.0f));
        boolean boolean31 = timeSeriesDataItem18.equals((java.lang.Object) timeSeriesDataItem30);
        timeSeriesDataItem30.setSelected(true);
        timeSeries3.add(timeSeriesDataItem30);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str14 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(timeSeriesDataItem28);
        boolean boolean30 = timeSeries3.equals((java.lang.Object) timeSeries13);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        int int32 = month31.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (-1.0f));
        java.lang.Number number35 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) month31);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = month31.previous();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) regularTimePeriod36, "2019", "30-June-2019");
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str44 = timeSeries43.getDomainDescription();
        long long45 = timeSeries43.getMaximumItemAge();
        java.lang.Object obj46 = timeSeries43.clone();
        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
        int int48 = month47.getMonth();
        java.util.Date date49 = month47.getEnd();
        org.jfree.data.time.Day day50 = new org.jfree.data.time.Day(date49);
        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day(date49);
        org.jfree.data.time.FixedMillisecond fixedMillisecond52 = new org.jfree.data.time.FixedMillisecond(date49);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = fixedMillisecond52.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = fixedMillisecond52.next();
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.Object obj59 = null;
        boolean boolean60 = timeSeries58.equals(obj59);
        double double61 = timeSeries58.getMaxY();
        int int62 = fixedMillisecond52.compareTo((java.lang.Object) double61);
        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month();
        int int64 = month63.getMonth();
        java.util.Date date65 = month63.getEnd();
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date65);
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date65);
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond(date65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = fixedMillisecond68.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = fixedMillisecond68.next();
        org.jfree.data.time.TimeSeries timeSeries71 = timeSeries43.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond52, regularTimePeriod70);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries39.getDataItem(regularTimePeriod70);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = timeSeries39.getTimePeriod((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 2.0d + "'", number35.equals(2.0d));
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 9223372036854775807L + "'", long45 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 6 + "'", int48 == 6);
        org.junit.Assert.assertNotNull(date49);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 6 + "'", int64 == 6);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertNotNull(timeSeries71);
        org.junit.Assert.assertNull(timeSeriesDataItem72);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 2019, false);
        int int17 = day3.compareTo((java.lang.Object) timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener18);
        java.lang.Comparable comparable20 = timeSeries9.getKey();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + "hi!" + "'", comparable20.equals("hi!"));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year0.next();
        long long6 = year0.getSerialIndex();
        java.util.Calendar calendar7 = null;
        try {
            long long8 = year0.getLastMillisecond(calendar7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 2019L + "'", long6 == 2019L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getFirstMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 1.0d);
        int int12 = timeSeries3.getItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date15);
        long long19 = fixedMillisecond18.getMiddleMillisecond();
        timeSeries3.setKey((java.lang.Comparable) long19);
        java.util.Collection collection21 = timeSeries3.getTimePeriods();
        int int22 = timeSeries3.getMaximumItemCount();
        timeSeries3.removeAgedItems(0L, false);
        boolean boolean26 = timeSeries3.getNotify();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        java.util.Date date6 = month4.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 2019, false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
        long long18 = day16.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        int int24 = month23.getMonth();
        java.util.Date date25 = month23.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) 2019, false);
        int int30 = day16.compareTo((java.lang.Object) timeSeries22);
        int int31 = day16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day16.previous();
        java.lang.String str33 = day16.toString();
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10);
        org.jfree.data.time.SerialDate serialDate36 = day16.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = day16.next();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "30-June-2019" + "'", str33.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate36);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        long long8 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1L + "'", long8 == 1L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("June 2019");
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        java.lang.String str14 = year13.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year13);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        int int4 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        int int6 = day3.getMonth();
        long long7 = day3.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561878000000L + "'", long7 == 1561878000000L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        java.util.Date date6 = month4.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 2019, false);
        long long11 = timeSeries3.getMaximumItemAge();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 9223372036854775807L + "'", long11 == 9223372036854775807L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        java.util.Calendar calendar2 = null;
        try {
            long long3 = month0.getLastMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date11);
        long long14 = month13.getSerialIndex();
        timeSeries3.setKey((java.lang.Comparable) month13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month13.next();
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("org.jfree.data.time.TimePeriodFormatException: Value");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        long long5 = timeSeries3.getMaximumItemAge();
        java.lang.String str6 = timeSeries3.getDomainDescription();
        timeSeries3.clear();
        try {
            timeSeries3.update(10, (java.lang.Number) 2147483647);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str9 = timeSeries8.getDomainDescription();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (-1.0f));
        boolean boolean14 = timeSeriesDataItem13.isSelected();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17);
        int int20 = month19.getMonth();
        boolean boolean21 = timeSeriesDataItem13.equals((java.lang.Object) month19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries8.addOrUpdate(timeSeriesDataItem23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        int int26 = month25.getMonth();
        java.util.Date date27 = month25.getEnd();
        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date27);
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month(date27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries8.getDataItem((org.jfree.data.time.RegularTimePeriod) month30);
        java.lang.Number number32 = null;
        timeSeriesDataItem31.setValue(number32);
        boolean boolean34 = day3.equals((java.lang.Object) timeSeriesDataItem31);
        int int35 = day3.getMonth();
        java.util.Date date36 = day3.getStart();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNotNull(timeSeriesDataItem31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(date36);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((int) ' ', (int) (byte) 100, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("30-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        java.util.Date date4 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        java.util.TimeZone timeZone7 = null;
        java.util.Locale locale8 = null;
        try {
            org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(date4, timeZone7, locale8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        java.lang.String str14 = year13.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year13);
        timeSeries3.setDomainDescription("");
        timeSeries3.setRangeDescription("");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 6);
        long long8 = fixedMillisecond5.getMiddleMillisecond();
        java.util.Calendar calendar9 = null;
        fixedMillisecond5.peg(calendar9);
        java.util.Date date11 = fixedMillisecond5.getTime();
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month(date11);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) date11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertNotNull(date11);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.previous();
        long long8 = fixedMillisecond5.getMiddleMillisecond();
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getLastMillisecond(calendar9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond5.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod11);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str14 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(timeSeriesDataItem28);
        boolean boolean30 = timeSeries3.equals((java.lang.Object) timeSeries13);
        timeSeries13.setMaximumItemAge(0L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries13.removeChangeListener(seriesChangeListener33);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        int int36 = month35.getMonth();
        java.lang.String str37 = month35.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month35.previous();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        int int40 = month39.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) (-1.0f));
        boolean boolean43 = timeSeriesDataItem42.isSelected();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        int int45 = month44.getMonth();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date46);
        int int49 = month48.getMonth();
        boolean boolean50 = timeSeriesDataItem42.equals((java.lang.Object) month48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month48, (double) 2);
        java.lang.Class<?> wildcardClass53 = month48.getClass();
        org.jfree.data.time.Year year54 = month48.getYear();
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month35, (org.jfree.data.time.RegularTimePeriod) month48);
        org.jfree.data.time.TimeSeries timeSeries59 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str60 = timeSeries59.getDomainDescription();
        long long61 = timeSeries59.getMaximumItemAge();
        java.lang.Object obj62 = timeSeries59.clone();
        org.jfree.data.time.Month month63 = new org.jfree.data.time.Month();
        int int64 = month63.getMonth();
        java.util.Date date65 = month63.getEnd();
        org.jfree.data.time.Day day66 = new org.jfree.data.time.Day(date65);
        org.jfree.data.time.Day day67 = new org.jfree.data.time.Day(date65);
        org.jfree.data.time.FixedMillisecond fixedMillisecond68 = new org.jfree.data.time.FixedMillisecond(date65);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = fixedMillisecond68.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod70 = fixedMillisecond68.next();
        org.jfree.data.time.TimeSeries timeSeries74 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.Object obj75 = null;
        boolean boolean76 = timeSeries74.equals(obj75);
        double double77 = timeSeries74.getMaxY();
        int int78 = fixedMillisecond68.compareTo((java.lang.Object) double77);
        org.jfree.data.time.Month month79 = new org.jfree.data.time.Month();
        int int80 = month79.getMonth();
        java.util.Date date81 = month79.getEnd();
        org.jfree.data.time.Day day82 = new org.jfree.data.time.Day(date81);
        org.jfree.data.time.Day day83 = new org.jfree.data.time.Day(date81);
        org.jfree.data.time.FixedMillisecond fixedMillisecond84 = new org.jfree.data.time.FixedMillisecond(date81);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod85 = fixedMillisecond84.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod86 = fixedMillisecond84.next();
        org.jfree.data.time.TimeSeries timeSeries87 = timeSeries59.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond68, regularTimePeriod86);
        java.util.Collection collection88 = timeSeries55.getTimePeriodsUniqueToOtherSeries(timeSeries59);
        org.jfree.data.time.FixedMillisecond fixedMillisecond90 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar91 = null;
        long long92 = fixedMillisecond90.getMiddleMillisecond(calendar91);
        java.util.Calendar calendar93 = null;
        fixedMillisecond90.peg(calendar93);
        java.util.Calendar calendar95 = null;
        long long96 = fixedMillisecond90.getFirstMillisecond(calendar95);
        try {
            timeSeries55.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond90, (java.lang.Number) 9, false);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "June 2019" + "'", str37.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "" + "'", str60.equals(""));
        org.junit.Assert.assertTrue("'" + long61 + "' != '" + 9223372036854775807L + "'", long61 == 9223372036854775807L);
        org.junit.Assert.assertNotNull(obj62);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 6 + "'", int64 == 6);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
        org.junit.Assert.assertNotNull(regularTimePeriod70);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertEquals((double) double77, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 1 + "'", int78 == 1);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 6 + "'", int80 == 6);
        org.junit.Assert.assertNotNull(date81);
        org.junit.Assert.assertNotNull(regularTimePeriod85);
        org.junit.Assert.assertNotNull(regularTimePeriod86);
        org.junit.Assert.assertNotNull(timeSeries87);
        org.junit.Assert.assertNotNull(collection88);
        org.junit.Assert.assertTrue("'" + long92 + "' != '" + 1L + "'", long92 == 1L);
        org.junit.Assert.assertTrue("'" + long96 + "' != '" + 1L + "'", long96 == 1L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str14 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(timeSeriesDataItem28);
        boolean boolean30 = timeSeries3.equals((java.lang.Object) timeSeries13);
        timeSeries13.setMaximumItemAge(0L);
        int int33 = timeSeries13.getMaximumItemCount();
        long long34 = timeSeries13.getMaximumItemAge();
        java.lang.Class<?> wildcardClass35 = timeSeries13.getClass();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        int int37 = month36.getMonth();
        java.util.Date date38 = month36.getEnd();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date38);
        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond(date38);
        int int43 = fixedMillisecond41.compareTo((java.lang.Object) 6);
        long long44 = fixedMillisecond41.getMiddleMillisecond();
        java.util.Calendar calendar45 = null;
        fixedMillisecond41.peg(calendar45);
        java.util.Date date47 = fixedMillisecond41.getTime();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent48 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond41);
        try {
            timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, 100.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2147483647 + "'", int33 == 2147483647);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1561964399999L + "'", long44 == 1561964399999L);
        org.junit.Assert.assertNotNull(date47);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        java.util.Date date6 = fixedMillisecond1.getTime();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond1.next();
        java.util.Calendar calendar8 = null;
        long long9 = fixedMillisecond1.getMiddleMillisecond(calendar8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = fixedMillisecond1.next();
        java.util.Calendar calendar11 = null;
        fixedMillisecond1.peg(calendar11);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond1.getLastMillisecond(calendar13);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1L + "'", long14 == 1L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        java.lang.Class<?> wildcardClass14 = month9.getClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date17, timeZone19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date17);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod20);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        int int10 = timeSeries3.getIndex(regularTimePeriod9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries3.addChangeListener(seriesChangeListener11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date17);
        int int22 = fixedMillisecond20.compareTo((java.lang.Object) 6);
        long long23 = fixedMillisecond20.getMiddleMillisecond();
        java.util.Calendar calendar24 = null;
        fixedMillisecond20.peg(calendar24);
        java.util.Date date26 = fixedMillisecond20.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 100);
        java.util.Date date29 = fixedMillisecond20.getTime();
        java.util.Calendar calendar30 = null;
        fixedMillisecond20.peg(calendar30);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 5, false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
        org.junit.Assert.assertNotNull(date26);
        org.junit.Assert.assertNotNull(date29);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        int int2 = month1.getYearValue();
        long long3 = month1.getSerialIndex();
        boolean boolean5 = month1.equals((java.lang.Object) "");
        org.jfree.data.time.Year year6 = month1.getYear();
        java.util.Date date7 = year6.getStart();
        try {
            org.jfree.data.time.Month month8 = new org.jfree.data.time.Month((int) (byte) 0, year6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24234L + "'", long3 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setMaximumItemAge((long) (byte) 100);
        timeSeries3.removeAgedItems(false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year();
        timeSeries15.add((org.jfree.data.time.RegularTimePeriod) year16, (double) (short) 1, true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries15.removeChangeListener(seriesChangeListener20);
        try {
            timeSeries15.delete(9999, (int) (byte) 10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries15);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        java.util.Date date5 = month3.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str12 = timeSeries11.getDomainDescription();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (-1.0f));
        boolean boolean17 = timeSeriesDataItem16.isSelected();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = month18.getMonth();
        java.util.Date date20 = month18.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        int int23 = month22.getMonth();
        boolean boolean24 = timeSeriesDataItem16.equals((java.lang.Object) month22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries11.addOrUpdate(timeSeriesDataItem26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        int int29 = month28.getMonth();
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        java.lang.Number number35 = null;
        timeSeriesDataItem34.setValue(number35);
        boolean boolean37 = day6.equals((java.lang.Object) timeSeriesDataItem34);
        int int38 = day6.getMonth();
        boolean boolean39 = year1.equals((java.lang.Object) int38);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        int int45 = month44.getMonth();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date46);
        timeSeries43.add((org.jfree.data.time.RegularTimePeriod) day47, (java.lang.Number) 2019, false);
        timeSeries43.removeAgedItems((long) (byte) 100, false);
        timeSeries43.clear();
        java.beans.PropertyChangeListener propertyChangeListener55 = null;
        timeSeries43.removePropertyChangeListener(propertyChangeListener55);
        timeSeries43.setMaximumItemAge((long) (byte) 100);
        int int59 = year1.compareTo((java.lang.Object) timeSeries43);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2019, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str14 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(timeSeriesDataItem28);
        boolean boolean30 = timeSeries3.equals((java.lang.Object) timeSeries13);
        timeSeries13.setRangeDescription("org.jfree.data.general.SeriesException: Overwritten values from: hi!");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        int int15 = month14.getYearValue();
        long long16 = month14.getSerialIndex();
        boolean boolean17 = timeSeriesDataItem13.equals((java.lang.Object) month14);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = month18.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (-1.0f));
        boolean boolean22 = timeSeriesDataItem21.isSelected();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        int int24 = month23.getMonth();
        java.util.Date date25 = month23.getEnd();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month(date25);
        int int28 = month27.getMonth();
        boolean boolean29 = timeSeriesDataItem21.equals((java.lang.Object) month27);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (double) 2);
        boolean boolean32 = month14.equals((java.lang.Object) month27);
        java.lang.String str33 = month27.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 43646L);
        java.lang.Number number36 = timeSeriesDataItem35.getValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24234L + "'", long16 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "June 2019" + "'", str33.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 43646L + "'", number36.equals(43646L));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        int int4 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        int int6 = day3.getMonth();
        java.lang.String str7 = day3.toString();
        org.jfree.data.time.SerialDate serialDate8 = day3.getSerialDate();
        long long9 = day3.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "30-June-2019" + "'", str7.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 43646L + "'", long9 == 43646L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setNotify(true);
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.removeChangeListener(seriesChangeListener15);
        timeSeries14.setNotify(true);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        int int20 = month19.getMonth();
        java.util.Date date21 = month19.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 1546329600000L);
        timeSeries14.add(timeSeriesDataItem23, true);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries3.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int28 = month27.getMonth();
        java.util.Date date29 = month27.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        int int31 = day30.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day30.previous();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day30);
        java.util.Calendar calendar34 = null;
        try {
            long long35 = day30.getLastMillisecond(calendar34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        java.util.Date date6 = month4.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 2019, false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
        long long18 = day16.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        int int24 = month23.getMonth();
        java.util.Date date25 = month23.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) 2019, false);
        int int30 = day16.compareTo((java.lang.Object) timeSeries22);
        int int31 = day16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day16.previous();
        java.lang.String str33 = day16.toString();
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10);
        timeSeries3.setNotify(true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "30-June-2019" + "'", str33.equals("30-June-2019"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 2019, false);
        int int17 = day3.compareTo((java.lang.Object) timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries23.removeChangeListener(seriesChangeListener24);
        timeSeries23.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        long long29 = month28.getFirstMillisecond();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 1.0d);
        int int32 = timeSeries23.getItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int34 = month33.getMonth();
        java.util.Date date35 = month33.getEnd();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date35);
        long long39 = fixedMillisecond38.getMiddleMillisecond();
        timeSeries23.setKey((java.lang.Comparable) long39);
        java.util.Collection collection41 = timeSeries23.getTimePeriods();
        java.util.Collection collection42 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        boolean boolean43 = timeSeries23.getNotify();
        double double44 = timeSeries23.getMinY();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int46 = month45.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        int int50 = month49.getMonth();
        java.util.Date date51 = month49.getEnd();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(date51);
        boolean boolean53 = month45.equals((java.lang.Object) year52);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod54 = year52.next();
        try {
            timeSeries23.add(regularTimePeriod54, (java.lang.Number) 1560236399999L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Year, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1559372400000L + "'", long29 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1561964399999L + "'", long39 == 1561964399999L);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod54);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(9);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2);
        java.util.Calendar calendar2 = null;
        try {
            year1.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        int int4 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        int int6 = day3.getMonth();
        java.lang.String str7 = day3.toString();
        org.jfree.data.time.SerialDate serialDate8 = day3.getSerialDate();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = day3.next();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        int int15 = month14.getMonth();
        java.util.Date date16 = month14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        boolean boolean18 = month10.equals((java.lang.Object) year17);
        java.lang.Class<?> wildcardClass19 = month10.getClass();
        java.lang.String str20 = month10.toString();
        boolean boolean21 = day3.equals((java.lang.Object) month10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "30-June-2019" + "'", str7.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "June 2019" + "'", str20.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 2019, false);
        int int17 = day3.compareTo((java.lang.Object) timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener18);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries9.addChangeListener(seriesChangeListener20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        int int23 = month22.getMonth();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        int int26 = day25.getYear();
        long long27 = day25.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) 1.0f);
        long long30 = timeSeries9.getMaximumItemAge();
        timeSeries9.fireSeriesChanged();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43646L + "'", long27 == 43646L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        java.util.Date date4 = day3.getStart();
        java.util.TimeZone timeZone5 = null;
        try {
            org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4, timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(date4);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) (-1.0f));
        boolean boolean9 = timeSeriesDataItem8.isSelected();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12);
        int int15 = month14.getMonth();
        boolean boolean16 = timeSeriesDataItem8.equals((java.lang.Object) month14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent20 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeriesDataItem18);
        java.lang.Object obj21 = timeSeriesDataItem18.clone();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = timeSeriesDataItem18.getPeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = timeSeriesDataItem18.getPeriod();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(obj21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(regularTimePeriod23);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        java.lang.String str13 = year12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year12, (double) 1561964399998L);
        int int18 = year12.getYear();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 6);
        long long8 = fixedMillisecond5.getMiddleMillisecond();
        java.util.Calendar calendar9 = null;
        fixedMillisecond5.peg(calendar9);
        java.util.Date date11 = fixedMillisecond5.getTime();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond5);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo13 = null;
        seriesChangeEvent12.setSummary(seriesChangeInfo13);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = seriesChangeEvent12.getSummary();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNull(seriesChangeInfo15);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        java.lang.Class<?> wildcardClass14 = month9.getClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date17, timeZone19);
        java.lang.Class class21 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        java.lang.Class class22 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass14);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(class21);
        org.junit.Assert.assertNotNull(class22);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Class class6 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.removeChangeListener(seriesChangeListener7);
        timeSeries3.setDomainDescription("30-June-2019");
        java.lang.String str11 = timeSeries3.getDomainDescription();
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "30-June-2019" + "'", str11.equals("30-June-2019"));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.clear();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (-1.0f));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate(timeSeriesDataItem13);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.removeChangeListener(seriesChangeListener19);
        java.lang.Class class21 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.addAndOrUpdate(timeSeries18);
        java.lang.Object obj23 = timeSeries22.clone();
        try {
            org.jfree.data.time.TimeSeries timeSeries26 = timeSeries22.createCopy(12, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1562097599999L, "Value", "June 2019");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        java.lang.Class class5 = timeSeries3.getTimePeriodClass();
        java.lang.String str6 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getMonth();
        java.util.Date date9 = month7.getEnd();
        org.jfree.data.time.Year year10 = new org.jfree.data.time.Year(date9);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date9);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month11.previous();
        timeSeries3.delete(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 1562097599999L + "'", comparable4.equals(1562097599999L));
        org.junit.Assert.assertNull(class5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        java.lang.Class<?> wildcardClass6 = day3.getClass();
        org.jfree.data.time.SerialDate serialDate7 = day3.getSerialDate();
        int int8 = day3.getMonth();
        java.util.Calendar calendar9 = null;
        try {
            day3.peg(calendar9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 5);
//        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
//        java.lang.Number number3 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day2);
//        java.lang.String str4 = day2.toString();
//        java.util.Calendar calendar5 = null;
//        try {
//            long long6 = day2.getLastMillisecond(calendar5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(number3);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "10-June-2019" + "'", str4.equals("10-June-2019"));
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date11);
        org.jfree.data.time.FixedMillisecond fixedMillisecond14 = new org.jfree.data.time.FixedMillisecond(date11);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond14.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = fixedMillisecond14.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond14.next();
        boolean boolean18 = fixedMillisecond5.equals((java.lang.Object) regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 2019, false);
        int int17 = day3.compareTo((java.lang.Object) timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.FixedMillisecond fixedMillisecond25 = new org.jfree.data.time.FixedMillisecond(date22);
        int int27 = fixedMillisecond25.compareTo((java.lang.Object) 6);
        long long28 = fixedMillisecond25.getMiddleMillisecond();
        java.util.Calendar calendar29 = null;
        fixedMillisecond25.peg(calendar29);
        java.lang.Number number31 = timeSeries9.getValue((org.jfree.data.time.RegularTimePeriod) fixedMillisecond25);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1561964399999L + "'", long28 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 2019 + "'", number31.equals(2019));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setNotify(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        java.util.Date date10 = month8.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 1546329600000L);
        timeSeries3.add(timeSeriesDataItem12, true);
        timeSeriesDataItem12.setValue((java.lang.Number) 1);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        java.util.Date date19 = year17.getEnd();
        int int20 = year17.getYear();
        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str25 = timeSeries24.getDomainDescription();
        boolean boolean26 = timeSeries24.getNotify();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year28, (java.lang.Number) 24234L);
        boolean boolean31 = timeSeries24.equals((java.lang.Object) 24234L);
        int int32 = year17.compareTo((java.lang.Object) 24234L);
        int int33 = timeSeriesDataItem12.compareTo((java.lang.Object) year17);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2019 + "'", int20 == 2019);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        org.jfree.data.time.Year year14 = month9.getYear();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.removeChangeListener(seriesChangeListener19);
        boolean boolean21 = timeSeries18.getNotify();
        timeSeries18.setRangeDescription("hi!");
        double double24 = timeSeries18.getMinY();
        timeSeries18.setMaximumItemAge((long) ' ');
        java.util.List list27 = timeSeries18.getItems();
        boolean boolean28 = month9.equals((java.lang.Object) timeSeries18);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        int int30 = month29.getMonth();
        java.util.Date date31 = month29.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        int int33 = day32.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day32.previous();
        int int35 = day32.getMonth();
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) day32, (double) 0L);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        int int43 = month42.getMonth();
        java.util.Date date44 = month42.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        timeSeries41.add((org.jfree.data.time.RegularTimePeriod) day45, (java.lang.Number) 2019, false);
        long long49 = day45.getSerialIndex();
        int int50 = day45.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day45, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries18.addOrUpdate(timeSeriesDataItem52);
        timeSeriesDataItem53.setSelected(false);
        timeSeriesDataItem53.setSelected(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 43646L + "'", long49 == 43646L);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2019 + "'", int50 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem53);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        long long5 = year0.getLastMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = year0.next();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1562097599999L + "'", long3 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        org.jfree.data.time.Year year14 = month9.getYear();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.removeChangeListener(seriesChangeListener19);
        boolean boolean21 = timeSeries18.getNotify();
        timeSeries18.setRangeDescription("hi!");
        double double24 = timeSeries18.getMinY();
        timeSeries18.setMaximumItemAge((long) ' ');
        java.util.List list27 = timeSeries18.getItems();
        boolean boolean28 = month9.equals((java.lang.Object) timeSeries18);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        int int30 = month29.getMonth();
        java.util.Date date31 = month29.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        int int33 = day32.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day32.previous();
        int int35 = day32.getMonth();
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) day32, (double) 0L);
        java.lang.Object obj38 = null;
        int int39 = day32.compareTo(obj38);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str14 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(timeSeriesDataItem28);
        boolean boolean30 = timeSeries3.equals((java.lang.Object) timeSeries13);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries3.removeChangeListener(seriesChangeListener31);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setNotify(true);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        java.util.Date date10 = month8.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 1546329600000L);
        timeSeries3.add(timeSeriesDataItem12, true);
        java.lang.Class class15 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int17 = month16.getYearValue();
        long long18 = month16.getSerialIndex();
        boolean boolean20 = month16.equals((java.lang.Object) "");
        long long21 = month16.getLastMillisecond();
        boolean boolean22 = timeSeries3.equals((java.lang.Object) long21);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(class15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 24234L + "'", long18 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Class class6 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        long long13 = day12.getSerialIndex();
        timeSeries3.setKey((java.lang.Comparable) day12);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo15);
        java.lang.Object obj17 = seriesChangeEvent16.getSource();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo18 = seriesChangeEvent16.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo19 = seriesChangeEvent16.getSummary();
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43646L + "'", long13 == 43646L);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNull(seriesChangeInfo18);
        org.junit.Assert.assertNull(seriesChangeInfo19);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        java.util.Date date6 = month4.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 2019, false);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getFirstMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond18.next();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        int int22 = year11.compareTo((java.lang.Object) wildcardClass21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        int int24 = month23.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) (-1.0f));
        boolean boolean27 = timeSeriesDataItem26.isSelected();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        int int29 = month28.getMonth();
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        int int33 = month32.getMonth();
        boolean boolean34 = timeSeriesDataItem26.equals((java.lang.Object) month32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month32, (double) 2);
        java.lang.Class<?> wildcardClass37 = month32.getClass();
        long long38 = month32.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener44 = null;
        timeSeries43.removeChangeListener(seriesChangeListener44);
        boolean boolean46 = timeSeries43.getNotify();
        timeSeries43.setRangeDescription("hi!");
        double double49 = timeSeries43.getMinY();
        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str54 = timeSeries53.getDomainDescription();
        org.jfree.data.time.Month month55 = new org.jfree.data.time.Month();
        int int56 = month55.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month55, (java.lang.Number) (-1.0f));
        boolean boolean59 = timeSeriesDataItem58.isSelected();
        org.jfree.data.time.Month month60 = new org.jfree.data.time.Month();
        int int61 = month60.getMonth();
        java.util.Date date62 = month60.getEnd();
        org.jfree.data.time.Year year63 = new org.jfree.data.time.Year(date62);
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month(date62);
        int int65 = month64.getMonth();
        boolean boolean66 = timeSeriesDataItem58.equals((java.lang.Object) month64);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem68 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month64, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = timeSeries53.addOrUpdate(timeSeriesDataItem68);
        boolean boolean70 = timeSeries43.equals((java.lang.Object) timeSeries53);
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month();
        int int72 = month71.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month71, (java.lang.Number) (-1.0f));
        java.lang.Number number75 = timeSeries53.getValue((org.jfree.data.time.RegularTimePeriod) month71);
        timeSeries53.clear();
        org.jfree.data.time.Month month77 = new org.jfree.data.time.Month();
        int int78 = month77.getMonth();
        java.util.Date date79 = month77.getEnd();
        org.jfree.data.time.Day day80 = new org.jfree.data.time.Day(date79);
        org.jfree.data.time.Day day81 = new org.jfree.data.time.Day(date79);
        org.jfree.data.time.FixedMillisecond fixedMillisecond82 = new org.jfree.data.time.FixedMillisecond(date79);
        long long83 = fixedMillisecond82.getFirstMillisecond();
        timeSeries53.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond82, (double) 52L);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem86 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond82);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1559372400000L + "'", long38 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertEquals((double) double49, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "" + "'", str54.equals(""));
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 6 + "'", int56 == 6);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 6 + "'", int61 == 6);
        org.junit.Assert.assertNotNull(date62);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 6 + "'", int72 == 6);
        org.junit.Assert.assertTrue("'" + number75 + "' != '" + 2.0d + "'", number75.equals(2.0d));
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 6 + "'", int78 == 6);
        org.junit.Assert.assertNotNull(date79);
        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1561964399999L + "'", long83 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem86);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 24234L);
        boolean boolean10 = timeSeries3.equals((java.lang.Object) 24234L);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener11);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        java.util.Date date6 = month4.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 2019, false);
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        timeSeries3.clear();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener15);
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = year17.previous();
        long long19 = year17.getFirstMillisecond();
        long long20 = year17.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = year17.next();
        timeSeries3.setKey((java.lang.Comparable) year17);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1546329600000L + "'", long19 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1562097599999L + "'", long20 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setNotify(true);
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond20.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond20.previous();
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond20.getMiddleMillisecond(calendar25);
        long long27 = fixedMillisecond20.getFirstMillisecond();
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1561964399999L + "'", long26 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year0.previous();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = regularTimePeriod3.getMiddleMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        int int6 = timeSeries3.getItemCount();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getMonth();
        java.util.Date date9 = month7.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) 1546329600000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month7.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.getDataItem(regularTimePeriod12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        int int15 = month14.getYearValue();
        int int17 = month14.compareTo((java.lang.Object) 1562097599999L);
        org.jfree.data.time.Year year18 = month14.getYear();
        int int19 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) month14);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(year18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        java.util.Date date6 = month4.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 2019, false);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getFirstMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond18.next();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        int int22 = year11.compareTo((java.lang.Object) wildcardClass21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        int int24 = month23.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) (-1.0f));
        boolean boolean27 = timeSeriesDataItem26.isSelected();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        int int29 = month28.getMonth();
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        int int33 = month32.getMonth();
        boolean boolean34 = timeSeriesDataItem26.equals((java.lang.Object) month32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month32, (double) 2);
        java.lang.Class<?> wildcardClass37 = month32.getClass();
        long long38 = month32.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) month32);
        try {
            timeSeries3.delete(2019, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1559372400000L + "'", long38 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries39);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.removeChangeListener(seriesChangeListener7);
        timeSeries3.setRangeDescription("");
        java.lang.Object obj11 = timeSeries3.clone();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = timeSeries3.getNextTimePeriod();
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(obj11);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        long long5 = day4.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day3.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) (-1.0f));
        boolean boolean9 = timeSeriesDataItem8.isSelected();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12);
        int int15 = month14.getMonth();
        boolean boolean16 = timeSeriesDataItem8.equals((java.lang.Object) month14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = timeSeriesDataItem26.getPeriod();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) (-1.0f));
        boolean boolean9 = timeSeriesDataItem8.isSelected();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12);
        int int15 = month14.getMonth();
        boolean boolean16 = timeSeriesDataItem8.equals((java.lang.Object) month14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries3.getNextTimePeriod();
        double double21 = timeSeries3.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str26 = timeSeries25.getDomainDescription();
        boolean boolean27 = timeSeries25.getNotify();
        timeSeries25.removeAgedItems(1L, true);
        java.util.Collection collection31 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = timeSeries3.getNextTimePeriod();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries3.removeChangeListener(seriesChangeListener33);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(collection31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("org.jfree.data.event.SeriesChangeEvent[source=4]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        int int4 = timeSeries3.getMaximumItemCount();
        timeSeries3.removeAgedItems(1L, true);
        java.lang.String str8 = timeSeries3.getRangeDescription();
        java.util.List list9 = timeSeries3.getItems();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.removeChangeListener(seriesChangeListener11);
        boolean boolean13 = timeSeries10.getNotify();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        int int17 = timeSeries10.getIndex(regularTimePeriod16);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries10.addChangeListener(seriesChangeListener18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener20);
        int int22 = fixedMillisecond5.compareTo((java.lang.Object) propertyChangeListener20);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond5.getMiddleMillisecond(calendar23);
        long long25 = fixedMillisecond5.getFirstMillisecond();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent26 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1561964399999L + "'", long25 == 1561964399999L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        boolean boolean12 = timeSeriesDataItem3.isSelected();
        java.lang.Object obj13 = timeSeriesDataItem3.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.removeChangeListener(seriesChangeListener11);
        boolean boolean13 = timeSeries10.getNotify();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        int int17 = timeSeries10.getIndex(regularTimePeriod16);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries10.addChangeListener(seriesChangeListener18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener20);
        int int22 = fixedMillisecond5.compareTo((java.lang.Object) propertyChangeListener20);
        long long23 = fixedMillisecond5.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond5.previous();
        long long25 = fixedMillisecond5.getFirstMillisecond();
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond5.getMiddleMillisecond(calendar26);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1561964399999L + "'", long25 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        java.lang.String str13 = year12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year12);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        int int23 = month22.getMonth();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(date24);
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries19.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries33.removeChangeListener(seriesChangeListener34);
        boolean boolean36 = timeSeries33.getNotify();
        timeSeries33.setRangeDescription("hi!");
        double double39 = timeSeries33.getMinY();
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str44 = timeSeries43.getDomainDescription();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int46 = month45.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem48 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month45, (java.lang.Number) (-1.0f));
        boolean boolean49 = timeSeriesDataItem48.isSelected();
        org.jfree.data.time.Month month50 = new org.jfree.data.time.Month();
        int int51 = month50.getMonth();
        java.util.Date date52 = month50.getEnd();
        org.jfree.data.time.Year year53 = new org.jfree.data.time.Year(date52);
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month(date52);
        int int55 = month54.getMonth();
        boolean boolean56 = timeSeriesDataItem48.equals((java.lang.Object) month54);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem58 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month54, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem59 = timeSeries43.addOrUpdate(timeSeriesDataItem58);
        boolean boolean60 = timeSeries33.equals((java.lang.Object) timeSeries43);
        boolean boolean61 = fixedMillisecond27.equals((java.lang.Object) boolean60);
        int int62 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        int int63 = timeSeries3.getItemCount();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "" + "'", str44.equals(""));
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 6 + "'", int51 == 6);
        org.junit.Assert.assertNotNull(date52);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 6 + "'", int55 == 6);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1) + "'", int62 == (-1));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) (-1.0f));
        boolean boolean9 = timeSeriesDataItem8.isSelected();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12);
        int int15 = month14.getMonth();
        boolean boolean16 = timeSeriesDataItem8.equals((java.lang.Object) month14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries3.getNextTimePeriod();
        java.util.List list22 = timeSeries3.getItems();
        int int23 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNotNull(list22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 6);
        long long8 = fixedMillisecond5.getMiddleMillisecond();
        java.util.Calendar calendar9 = null;
        fixedMillisecond5.peg(calendar9);
        java.util.Date date11 = fixedMillisecond5.getTime();
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent12 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) fixedMillisecond5);
        java.util.Calendar calendar13 = null;
        long long14 = fixedMillisecond5.getFirstMillisecond(calendar13);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1561964399999L + "'", long14 == 1561964399999L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.removeChangeListener(seriesChangeListener11);
        boolean boolean13 = timeSeries10.getNotify();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        int int17 = timeSeries10.getIndex(regularTimePeriod16);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries10.addChangeListener(seriesChangeListener18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener20);
        int int22 = fixedMillisecond5.compareTo((java.lang.Object) propertyChangeListener20);
        long long23 = fixedMillisecond5.getMiddleMillisecond();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        java.lang.String str26 = month24.toString();
        boolean boolean27 = fixedMillisecond5.equals((java.lang.Object) month24);
        java.util.Calendar calendar28 = null;
        try {
            long long29 = month24.getLastMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "June 2019" + "'", str26.equals("June 2019"));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str14 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(timeSeriesDataItem28);
        boolean boolean30 = timeSeries3.equals((java.lang.Object) timeSeries13);
        timeSeries13.setMaximumItemAge(0L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries13.removeChangeListener(seriesChangeListener33);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        int int36 = month35.getMonth();
        java.lang.String str37 = month35.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = month35.previous();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        int int40 = month39.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month39, (java.lang.Number) (-1.0f));
        boolean boolean43 = timeSeriesDataItem42.isSelected();
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        int int45 = month44.getMonth();
        java.util.Date date46 = month44.getEnd();
        org.jfree.data.time.Year year47 = new org.jfree.data.time.Year(date46);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month(date46);
        int int49 = month48.getMonth();
        boolean boolean50 = timeSeriesDataItem42.equals((java.lang.Object) month48);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month48, (double) 2);
        java.lang.Class<?> wildcardClass53 = month48.getClass();
        org.jfree.data.time.Year year54 = month48.getYear();
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) month35, (org.jfree.data.time.RegularTimePeriod) month48);
        timeSeries55.setMaximumItemAge(0L);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "June 2019" + "'", str37.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
        org.junit.Assert.assertNotNull(date46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertNotNull(timeSeries55);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 5);
        java.util.List list2 = timeSeries1.getItems();
        int int3 = timeSeries1.getMaximumItemCount();
        timeSeries1.setDomainDescription("org.jfree.data.event.SeriesChangeEvent[source=4]");
        org.junit.Assert.assertNotNull(list2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2147483647 + "'", int3 == 2147483647);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
        java.util.Calendar calendar1 = null;
        fixedMillisecond0.peg(calendar1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("2018");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        int int12 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        int int17 = day16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.previous();
        long long19 = day16.getLastMillisecond();
        boolean boolean20 = month9.equals((java.lang.Object) day16);
        java.util.Date date21 = month9.getStart();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date21);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        boolean boolean4 = month0.equals((java.lang.Object) "");
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries9.removeChangeListener(seriesChangeListener10);
        boolean boolean12 = timeSeries9.getNotify();
        timeSeries9.setRangeDescription("hi!");
        double double15 = timeSeries9.getMinY();
        timeSeries9.setMaximumItemAge((long) ' ');
        java.util.Collection collection18 = timeSeries9.getTimePeriods();
        timeSeries9.setDomainDescription("June 2019");
        boolean boolean21 = year5.equals((java.lang.Object) "June 2019");
        java.util.Calendar calendar22 = null;
        try {
            long long23 = year5.getLastMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertEquals((double) double15, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str6 = timeSeries5.getDomainDescription();
        boolean boolean7 = timeSeries5.getNotify();
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year9, (java.lang.Number) 24234L);
        boolean boolean12 = timeSeries5.equals((java.lang.Object) 24234L);
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year13.previous();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date17);
        long long21 = fixedMillisecond20.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries25.removeChangeListener(seriesChangeListener26);
        boolean boolean28 = timeSeries25.getNotify();
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = year30.next();
        int int32 = timeSeries25.getIndex(regularTimePeriod31);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries25.addChangeListener(seriesChangeListener33);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries25.addPropertyChangeListener(propertyChangeListener35);
        int int37 = fixedMillisecond20.compareTo((java.lang.Object) propertyChangeListener35);
        long long38 = fixedMillisecond20.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries5.createCopy(regularTimePeriod14, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        int int40 = fixedMillisecond1.compareTo((java.lang.Object) regularTimePeriod14);
        long long41 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1561964399999L + "'", long38 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1L + "'", long41 == 1L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.removeChangeListener(seriesChangeListener7);
        java.lang.String str9 = timeSeries3.getDescription();
        try {
            timeSeries3.delete(100, 2019);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 24234L);
        boolean boolean10 = timeSeries3.equals((java.lang.Object) 24234L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date15);
        long long19 = fixedMillisecond18.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries23.removeChangeListener(seriesChangeListener24);
        boolean boolean26 = timeSeries23.getNotify();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
        int int30 = timeSeries23.getIndex(regularTimePeriod29);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries23.addChangeListener(seriesChangeListener31);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener33);
        int int35 = fixedMillisecond18.compareTo((java.lang.Object) propertyChangeListener33);
        long long36 = fixedMillisecond18.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries3.createCopy(regularTimePeriod12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond18.previous();
        java.util.Calendar calendar39 = null;
        fixedMillisecond18.peg(calendar39);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1561964399999L + "'", long36 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        boolean boolean5 = timeSeries3.getNotify();
        java.lang.Class<?> wildcardClass6 = timeSeries3.getClass();
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = timeSeries3.getTimePeriod(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.lang.Class class0 = null;
        org.jfree.data.time.Month month1 = new org.jfree.data.time.Month();
        int int2 = month1.getMonth();
        java.util.Date date3 = month1.getEnd();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date3);
        org.jfree.data.time.FixedMillisecond fixedMillisecond6 = new org.jfree.data.time.FixedMillisecond(date3);
        long long7 = fixedMillisecond6.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.removeChangeListener(seriesChangeListener12);
        boolean boolean14 = timeSeries11.getNotify();
        org.jfree.data.time.Year year16 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = year16.next();
        int int18 = timeSeries11.getIndex(regularTimePeriod17);
        int int19 = fixedMillisecond6.compareTo((java.lang.Object) regularTimePeriod17);
        java.util.Date date20 = fixedMillisecond6.getTime();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        java.util.TimeZone timeZone22 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date20, timeZone22);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertNotNull(date3);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(regularTimePeriod23);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.next();
        java.util.Date date7 = fixedMillisecond5.getTime();
        java.util.TimeZone timeZone8 = null;
        try {
            org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7, timeZone8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        timeSeries3.setDomainDescription("");
        int int12 = timeSeries3.getItemCount();
        timeSeries3.removeAgedItems(true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        try {
            org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(0, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        int int12 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        int int17 = day16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.previous();
        long long19 = day16.getLastMillisecond();
        boolean boolean20 = month9.equals((java.lang.Object) day16);
        java.util.Date date21 = month9.getStart();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        java.lang.String str23 = day22.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "1-June-2019" + "'", str23.equals("1-June-2019"));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1562097599999L, "Value", "June 2019");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        timeSeries3.setDescription("hi!");
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 1562097599999L + "'", comparable4.equals(1562097599999L));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        timeSeries3.setDomainDescription("");
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        long long17 = day16.getSerialIndex();
        long long18 = day16.getSerialIndex();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day16);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (-1.0f));
        boolean boolean24 = timeSeriesDataItem23.isSelected();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        int int26 = month25.getMonth();
        java.util.Date date27 = month25.getEnd();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date27);
        int int30 = month29.getMonth();
        boolean boolean31 = timeSeriesDataItem23.equals((java.lang.Object) month29);
        int int32 = month29.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month29, "hi!", "June 2019");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        int int37 = month36.getMonth();
        java.util.Date date38 = month36.getEnd();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        int int40 = day39.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day39.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries35.getDataItem(regularTimePeriod41);
        int int43 = day16.compareTo((java.lang.Object) timeSeries35);
        long long44 = day16.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43646L + "'", long17 == 43646L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43646L + "'", long18 == 43646L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 1561878000000L + "'", long44 == 1561878000000L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 6);
        long long8 = fixedMillisecond5.getMiddleMillisecond();
        java.util.Calendar calendar9 = null;
        fixedMillisecond5.peg(calendar9);
        java.util.Date date11 = fixedMillisecond5.getTime();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 100);
        java.util.Date date14 = fixedMillisecond5.getTime();
        java.util.Calendar calendar15 = null;
        fixedMillisecond5.peg(calendar15);
        org.jfree.data.time.Month month17 = new org.jfree.data.time.Month();
        int int18 = month17.getMonth();
        java.util.Date date19 = month17.getEnd();
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(date19);
        org.jfree.data.time.SerialDate serialDate21 = day20.getSerialDate();
        long long22 = day20.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int28 = month27.getMonth();
        java.util.Date date29 = month27.getEnd();
        org.jfree.data.time.Day day30 = new org.jfree.data.time.Day(date29);
        timeSeries26.add((org.jfree.data.time.RegularTimePeriod) day30, (java.lang.Number) 2019, false);
        int int34 = day20.compareTo((java.lang.Object) timeSeries26);
        java.beans.PropertyChangeListener propertyChangeListener35 = null;
        timeSeries26.removePropertyChangeListener(propertyChangeListener35);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener37 = null;
        timeSeries26.addChangeListener(seriesChangeListener37);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        int int40 = month39.getMonth();
        java.util.Date date41 = month39.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        int int43 = day42.getYear();
        long long44 = day42.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day42, (java.lang.Number) 1.0f);
        java.lang.String str47 = timeSeries26.getRangeDescription();
        boolean boolean48 = fixedMillisecond5.equals((java.lang.Object) str47);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 6 + "'", int18 == 6);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561964399999L + "'", long22 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertTrue("'" + long44 + "' != '" + 43646L + "'", long44 == 43646L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem46);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "hi!" + "'", str47.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("Value");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        int int3 = month0.compareTo((java.lang.Object) 1562097599999L);
        java.lang.String str4 = month0.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "June 2019" + "'", str4.equals("June 2019"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 2019, false);
        int int17 = day3.compareTo((java.lang.Object) timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries9.addPropertyChangeListener(propertyChangeListener20);
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        int int27 = month26.getMonth();
        java.util.Date date28 = month26.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 2019, false);
        long long33 = day29.getSerialIndex();
        int int34 = day29.getYear();
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) day29);
        double double36 = timeSeries9.getMinY();
        org.jfree.data.time.Year year37 = new org.jfree.data.time.Year();
        long long38 = year37.getFirstMillisecond();
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        int int40 = month39.getMonth();
        java.util.Date date41 = month39.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day(date41);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(date41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = fixedMillisecond44.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = fixedMillisecond44.next();
        java.lang.Class<?> wildcardClass47 = regularTimePeriod46.getClass();
        int int48 = year37.compareTo((java.lang.Object) wildcardClass47);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = year37.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) year37, (double) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43646L + "'", long33 == 43646L);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2019 + "'", int34 == 2019);
        org.junit.Assert.assertEquals((double) double36, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1546329600000L + "'", long38 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        timeSeries3.setMaximumItemAge((long) ' ');
        timeSeries3.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries17.removeChangeListener(seriesChangeListener18);
        boolean boolean20 = timeSeries17.getNotify();
        timeSeries17.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener27 = null;
        timeSeries26.removeChangeListener(seriesChangeListener27);
        org.jfree.data.time.TimeSeries timeSeries29 = timeSeries17.addAndOrUpdate(timeSeries26);
        org.jfree.data.time.Year year30 = new org.jfree.data.time.Year();
        timeSeries29.add((org.jfree.data.time.RegularTimePeriod) year30, (double) (short) 1, true);
        timeSeries29.setDescription("June 2019");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        int int37 = month36.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month36, (java.lang.Number) (-1.0f));
        boolean boolean40 = timeSeriesDataItem39.isSelected();
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        int int42 = month41.getMonth();
        java.util.Date date43 = month41.getEnd();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(date43);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date43);
        int int46 = month45.getMonth();
        boolean boolean47 = timeSeriesDataItem39.equals((java.lang.Object) month45);
        int int48 = month45.getYearValue();
        int int49 = month45.getMonth();
        java.util.Date date50 = month45.getEnd();
        int int51 = timeSeries29.getIndex((org.jfree.data.time.RegularTimePeriod) month45);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month45, (double) 100.0f);
        timeSeries3.clear();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(timeSeries29);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 2019 + "'", int48 == 2019);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        java.lang.Class<?> wildcardClass14 = month9.getClass();
        org.jfree.data.time.Year year15 = month9.getYear();
        java.util.Date date16 = year15.getStart();
        java.util.Calendar calendar17 = null;
        try {
            year15.peg(calendar17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(date16);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getFirstMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 1.0d);
        java.lang.Object obj12 = null;
        boolean boolean13 = timeSeries3.equals(obj12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Calendar calendar18 = null;
        fixedMillisecond15.peg(calendar18);
        java.util.Date date20 = fixedMillisecond15.getTime();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.lang.Class class22 = timeSeries3.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(class22);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        java.lang.String str13 = year12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year12);
        timeSeries3.setRangeDescription("Overwritten values from: hi!");
        try {
            timeSeries3.delete(0, 1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) (-1.0f));
        boolean boolean9 = timeSeriesDataItem8.isSelected();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12);
        int int15 = month14.getMonth();
        boolean boolean16 = timeSeriesDataItem8.equals((java.lang.Object) month14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener26 = null;
        timeSeries25.removeChangeListener(seriesChangeListener26);
        boolean boolean28 = timeSeries25.getNotify();
        timeSeries25.setRangeDescription("hi!");
        double double31 = timeSeries25.getMinY();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str36 = timeSeries35.getDomainDescription();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        int int38 = month37.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem40 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month37, (java.lang.Number) (-1.0f));
        boolean boolean41 = timeSeriesDataItem40.isSelected();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        int int43 = month42.getMonth();
        java.util.Date date44 = month42.getEnd();
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date44);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date44);
        int int47 = month46.getMonth();
        boolean boolean48 = timeSeriesDataItem40.equals((java.lang.Object) month46);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month46, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem51 = timeSeries35.addOrUpdate(timeSeriesDataItem50);
        boolean boolean52 = timeSeries25.equals((java.lang.Object) timeSeries35);
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        int int54 = month53.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month53, (java.lang.Number) (-1.0f));
        java.lang.Number number57 = timeSeries35.getValue((org.jfree.data.time.RegularTimePeriod) month53);
        long long58 = month53.getMiddleMillisecond();
        java.lang.Number number59 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month53);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertEquals((double) double31, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "" + "'", str36.equals(""));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 6 + "'", int47 == 6);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + 2.0d + "'", number57.equals(2.0d));
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560668399999L + "'", long58 == 1560668399999L);
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 2.0d + "'", number59.equals(2.0d));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Class class6 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        long long13 = day12.getSerialIndex();
        timeSeries3.setKey((java.lang.Comparable) day12);
        long long15 = day12.getSerialIndex();
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43646L + "'", long13 == 43646L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 43646L + "'", long15 == 43646L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((int) (short) 10);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        java.lang.Class<?> wildcardClass14 = month9.getClass();
        long long15 = month9.getFirstMillisecond();
        long long16 = month9.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1559372400000L + "'", long15 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        long long5 = timeSeries3.getMaximumItemAge();
        java.lang.String str6 = timeSeries3.getDomainDescription();
        timeSeries3.clear();
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        java.util.Date date10 = month8.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.SerialDate serialDate12 = day11.getSerialDate();
        long long13 = day11.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = month18.getMonth();
        java.util.Date date20 = month18.getEnd();
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date20);
        timeSeries17.add((org.jfree.data.time.RegularTimePeriod) day21, (java.lang.Number) 2019, false);
        int int25 = day11.compareTo((java.lang.Object) timeSeries17);
        java.lang.String str26 = day11.toString();
        int int27 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) day11);
        java.util.Calendar calendar28 = null;
        try {
            long long29 = day11.getMiddleMillisecond(calendar28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "30-June-2019" + "'", str26.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day((-1), 30, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        java.lang.Class<?> wildcardClass14 = month9.getClass();
        org.jfree.data.time.Year year15 = month9.getYear();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int17 = month16.getMonth();
        java.util.Date date18 = month16.getEnd();
        org.jfree.data.time.Day day19 = new org.jfree.data.time.Day(date18);
        org.jfree.data.time.SerialDate serialDate20 = day19.getSerialDate();
        long long21 = day19.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries25 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        int int27 = month26.getMonth();
        java.util.Date date28 = month26.getEnd();
        org.jfree.data.time.Day day29 = new org.jfree.data.time.Day(date28);
        timeSeries25.add((org.jfree.data.time.RegularTimePeriod) day29, (java.lang.Number) 2019, false);
        int int33 = day19.compareTo((java.lang.Object) timeSeries25);
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries25.removePropertyChangeListener(propertyChangeListener34);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener40 = null;
        timeSeries39.removeChangeListener(seriesChangeListener40);
        timeSeries39.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.Month month44 = new org.jfree.data.time.Month();
        long long45 = month44.getFirstMillisecond();
        timeSeries39.add((org.jfree.data.time.RegularTimePeriod) month44, (java.lang.Number) 1.0d);
        int int48 = timeSeries39.getItemCount();
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month();
        int int50 = month49.getMonth();
        java.util.Date date51 = month49.getEnd();
        org.jfree.data.time.Day day52 = new org.jfree.data.time.Day(date51);
        org.jfree.data.time.Day day53 = new org.jfree.data.time.Day(date51);
        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(date51);
        long long55 = fixedMillisecond54.getMiddleMillisecond();
        timeSeries39.setKey((java.lang.Comparable) long55);
        java.util.Collection collection57 = timeSeries39.getTimePeriods();
        java.util.Collection collection58 = timeSeries25.getTimePeriodsUniqueToOtherSeries(timeSeries39);
        double double59 = timeSeries39.getMaxY();
        boolean boolean60 = year15.equals((java.lang.Object) double59);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1561964399999L + "'", long21 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 6 + "'", int27 == 6);
        org.junit.Assert.assertNotNull(date28);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertTrue("'" + long45 + "' != '" + 1559372400000L + "'", long45 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1 + "'", int48 == 1);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
        org.junit.Assert.assertNotNull(date51);
        org.junit.Assert.assertTrue("'" + long55 + "' != '" + 1561964399999L + "'", long55 == 1561964399999L);
        org.junit.Assert.assertNotNull(collection57);
        org.junit.Assert.assertNotNull(collection58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.0d + "'", double59 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        int int4 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        int int6 = day3.getMonth();
        java.lang.String str7 = day3.toString();
        org.jfree.data.time.SerialDate serialDate8 = day3.getSerialDate();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(serialDate8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "30-June-2019" + "'", str7.equals("30-June-2019"));
        org.junit.Assert.assertNotNull(serialDate8);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        timeSeries3.setDomainDescription("");
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (-1.0f));
        boolean boolean17 = timeSeriesDataItem16.isSelected();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = month18.getMonth();
        java.util.Date date20 = month18.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        int int23 = month22.getMonth();
        boolean boolean24 = timeSeriesDataItem16.equals((java.lang.Object) month22);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        int int26 = month25.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) (-1.0f));
        boolean boolean29 = timeSeriesDataItem16.equals((java.lang.Object) timeSeriesDataItem28);
        java.lang.Object obj30 = null;
        boolean boolean31 = timeSeriesDataItem28.equals(obj30);
        timeSeries3.setKey((java.lang.Comparable) boolean31);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 2019, false);
        int int17 = day3.compareTo((java.lang.Object) timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener18);
        java.lang.Class class20 = timeSeries9.getTimePeriodClass();
        int int21 = timeSeries9.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 2147483647 + "'", int21 == 2147483647);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 2019, false);
        int int17 = day3.compareTo((java.lang.Object) timeSeries9);
        int int18 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day3.previous();
        long long20 = day3.getFirstMillisecond();
        java.util.Date date21 = day3.getStart();
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        int int23 = month22.getMonth();
        org.jfree.data.time.Year year24 = month22.getYear();
        int int25 = month22.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str30 = timeSeries29.getDomainDescription();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        int int32 = month31.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (-1.0f));
        boolean boolean35 = timeSeriesDataItem34.isSelected();
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        int int37 = month36.getMonth();
        java.util.Date date38 = month36.getEnd();
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(date38);
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month(date38);
        int int41 = month40.getMonth();
        boolean boolean42 = timeSeriesDataItem34.equals((java.lang.Object) month40);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries29.addOrUpdate(timeSeriesDataItem44);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = timeSeries29.getNextTimePeriod();
        double double47 = timeSeries29.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str52 = timeSeries51.getDomainDescription();
        boolean boolean53 = timeSeries51.getNotify();
        timeSeries51.removeAgedItems(1L, true);
        java.util.Collection collection57 = timeSeries29.getTimePeriodsUniqueToOtherSeries(timeSeries51);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = timeSeries29.getNextTimePeriod();
        int int59 = month22.compareTo((java.lang.Object) timeSeries29);
        int int60 = day3.compareTo((java.lang.Object) month22);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + long20 + "' != '" + 1561878000000L + "'", long20 == 1561878000000L);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 2.0d + "'", double47 == 2.0d);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "" + "'", str52.equals(""));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(collection57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 1 + "'", int59 == 1);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        long long5 = timeSeries3.getMaximumItemAge();
        java.lang.String str6 = timeSeries3.getDomainDescription();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        java.util.Date date13 = month11.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        timeSeries10.add((org.jfree.data.time.RegularTimePeriod) day14, (java.lang.Number) 2019, false);
        timeSeries10.removeAgedItems((long) (byte) 100, false);
        org.jfree.data.time.TimeSeries timeSeries21 = timeSeries3.addAndOrUpdate(timeSeries10);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        int int23 = month22.getMonth();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date24);
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond(date24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = fixedMillisecond27.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = fixedMillisecond27.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = fixedMillisecond27.next();
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (double) 9999);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.FixedMillisecond, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(timeSeries21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        int int4 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (-1.0f));
        boolean boolean10 = timeSeriesDataItem9.isSelected();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        java.util.Date date13 = month11.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date13);
        int int16 = month15.getMonth();
        boolean boolean17 = timeSeriesDataItem9.equals((java.lang.Object) month15);
        int int18 = day3.compareTo((java.lang.Object) boolean17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        int int20 = month19.getMonth();
        java.util.Date date21 = month19.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond24.next();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.Object obj31 = null;
        boolean boolean32 = timeSeries30.equals(obj31);
        double double33 = timeSeries30.getMaxY();
        int int34 = fixedMillisecond24.compareTo((java.lang.Object) double33);
        int int35 = day3.compareTo((java.lang.Object) double33);
        long long36 = day3.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 0);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar41 = null;
        long long42 = fixedMillisecond40.getMiddleMillisecond(calendar41);
        java.util.Calendar calendar43 = null;
        fixedMillisecond40.peg(calendar43);
        int int45 = timeSeriesDataItem38.compareTo((java.lang.Object) fixedMillisecond40);
        java.util.Calendar calendar46 = null;
        long long47 = fixedMillisecond40.getFirstMillisecond(calendar46);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1561921199999L + "'", long36 == 1561921199999L);
        org.junit.Assert.assertTrue("'" + long42 + "' != '" + 1L + "'", long42 == 1L);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 1 + "'", int45 == 1);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 1L + "'", long47 == 1L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod0 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem2 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod0, (java.lang.Number) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setNotify(true);
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries3.addChangeListener(seriesChangeListener9);
        java.util.Collection collection11 = timeSeries3.getTimePeriods();
        timeSeries3.setRangeDescription("Value");
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertNotNull(collection11);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.lang.String str4 = year3.toString();
        java.util.Calendar calendar5 = null;
        try {
            long long6 = year3.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str14 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(timeSeriesDataItem28);
        boolean boolean30 = timeSeries3.equals((java.lang.Object) timeSeries13);
        timeSeries13.setMaximumItemAge(0L);
        int int33 = timeSeries13.getMaximumItemCount();
        java.lang.String str34 = timeSeries13.getDescription();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2147483647 + "'", int33 == 2147483647);
        org.junit.Assert.assertNull(str34);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        int int4 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        long long6 = day3.getLastMillisecond();
        org.jfree.data.time.SerialDate serialDate7 = day3.getSerialDate();
        java.util.Calendar calendar8 = null;
        try {
            long long9 = day3.getFirstMillisecond(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertNotNull(serialDate7);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        java.lang.String str13 = year12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year12);
        try {
            java.lang.Number number17 = timeSeries3.getValue(6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 6, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        int int4 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (-1.0f));
        boolean boolean10 = timeSeriesDataItem9.isSelected();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        java.util.Date date13 = month11.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date13);
        int int16 = month15.getMonth();
        boolean boolean17 = timeSeriesDataItem9.equals((java.lang.Object) month15);
        int int18 = day3.compareTo((java.lang.Object) boolean17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        int int20 = month19.getMonth();
        java.util.Date date21 = month19.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond24.next();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.Object obj31 = null;
        boolean boolean32 = timeSeries30.equals(obj31);
        double double33 = timeSeries30.getMaxY();
        int int34 = fixedMillisecond24.compareTo((java.lang.Object) double33);
        int int35 = day3.compareTo((java.lang.Object) double33);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (double) 'a');
        long long38 = day3.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43646L + "'", long38 == 43646L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Year year12 = new org.jfree.data.time.Year(date11);
        java.lang.String str13 = year12.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = year12.previous();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) year12);
        timeSeries3.setRangeDescription("Overwritten values from: hi!");
        java.lang.Object obj18 = timeSeries3.clone();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "2019" + "'", str13.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(obj18);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.Object obj4 = null;
        boolean boolean5 = timeSeries3.equals(obj4);
        double double6 = timeSeries3.getMaxY();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = year7.previous();
        long long9 = year7.getFirstMillisecond();
        long long10 = year7.getFirstMillisecond();
        long long11 = year7.getFirstMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 8, true);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.removeChangeListener(seriesChangeListener19);
        boolean boolean21 = timeSeries18.getNotify();
        timeSeries18.setRangeDescription("hi!");
        double double24 = timeSeries18.getMinY();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str29 = timeSeries28.getDomainDescription();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        int int31 = month30.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month30, (java.lang.Number) (-1.0f));
        boolean boolean34 = timeSeriesDataItem33.isSelected();
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        int int36 = month35.getMonth();
        java.util.Date date37 = month35.getEnd();
        org.jfree.data.time.Year year38 = new org.jfree.data.time.Year(date37);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month(date37);
        int int40 = month39.getMonth();
        boolean boolean41 = timeSeriesDataItem33.equals((java.lang.Object) month39);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month39, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem44 = timeSeries28.addOrUpdate(timeSeriesDataItem43);
        boolean boolean45 = timeSeries18.equals((java.lang.Object) timeSeries28);
        boolean boolean46 = year7.equals((java.lang.Object) boolean45);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year7.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = year7.next();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1546329600000L + "'", long10 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1546329600000L + "'", long11 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertNotNull(regularTimePeriod48);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 2019, false);
        int int17 = day3.compareTo((java.lang.Object) timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener18);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries9.addChangeListener(seriesChangeListener20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        int int23 = month22.getMonth();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        int int26 = day25.getYear();
        long long27 = day25.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) 1.0f);
        java.util.Date date30 = day25.getEnd();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month(date30);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43646L + "'", long27 == 43646L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(date30);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        timeSeries3.setMaximumItemAge((long) ' ');
        java.beans.PropertyChangeListener propertyChangeListener12 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener12);
        timeSeries3.setDomainDescription("30-June-2019");
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month((int) (byte) 10, (int) (byte) 1);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNull(timeSeriesDataItem20);
    }

//    @Test
//    public void test161() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test161");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = month4.getMonth();
//        java.util.Date date6 = month4.getEnd();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 2019, false);
//        long long11 = day7.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = timeSeriesDataItem13.compareTo((java.lang.Object) day14);
//        long long16 = day14.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day14, (double) (byte) 100);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43646L + "'", long11 == 43646L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 43626L + "'", long16 == 43626L);
//    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.removeChangeListener(seriesChangeListener11);
        boolean boolean13 = timeSeries10.getNotify();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        int int17 = timeSeries10.getIndex(regularTimePeriod16);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries10.addChangeListener(seriesChangeListener18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener20);
        int int22 = fixedMillisecond5.compareTo((java.lang.Object) propertyChangeListener20);
        long long23 = fixedMillisecond5.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond5.previous();
        long long25 = fixedMillisecond5.getFirstMillisecond();
        long long26 = fixedMillisecond5.getLastMillisecond();
        long long27 = fixedMillisecond5.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1561964399999L + "'", long25 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1561964399999L + "'", long26 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        org.jfree.data.time.Year year14 = month9.getYear();
        int int15 = year14.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2019 + "'", int15 == 2019);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (-1.0f));
        boolean boolean14 = timeSeriesDataItem13.isSelected();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17);
        int int20 = month19.getMonth();
        boolean boolean21 = timeSeriesDataItem13.equals((java.lang.Object) month19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (double) 2);
        org.jfree.data.time.Year year24 = month19.getYear();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries28.removeChangeListener(seriesChangeListener29);
        boolean boolean31 = timeSeries28.getNotify();
        timeSeries28.setRangeDescription("hi!");
        double double34 = timeSeries28.getMinY();
        timeSeries28.setMaximumItemAge((long) ' ');
        java.util.List list37 = timeSeries28.getItems();
        boolean boolean38 = month19.equals((java.lang.Object) timeSeries28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month19.next();
        timeSeries3.setKey((java.lang.Comparable) month19);
        org.jfree.data.time.Month month41 = new org.jfree.data.time.Month();
        int int42 = month41.getMonth();
        java.util.Date date43 = month41.getEnd();
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date43);
        org.jfree.data.time.SerialDate serialDate45 = day44.getSerialDate();
        long long46 = day44.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        int int52 = month51.getMonth();
        java.util.Date date53 = month51.getEnd();
        org.jfree.data.time.Day day54 = new org.jfree.data.time.Day(date53);
        timeSeries50.add((org.jfree.data.time.RegularTimePeriod) day54, (java.lang.Number) 2019, false);
        int int58 = day44.compareTo((java.lang.Object) timeSeries50);
        java.beans.PropertyChangeListener propertyChangeListener59 = null;
        timeSeries50.removePropertyChangeListener(propertyChangeListener59);
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener65 = null;
        timeSeries64.removeChangeListener(seriesChangeListener65);
        timeSeries64.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month();
        long long70 = month69.getFirstMillisecond();
        timeSeries64.add((org.jfree.data.time.RegularTimePeriod) month69, (java.lang.Number) 1.0d);
        int int73 = timeSeries64.getItemCount();
        org.jfree.data.time.Month month74 = new org.jfree.data.time.Month();
        int int75 = month74.getMonth();
        java.util.Date date76 = month74.getEnd();
        org.jfree.data.time.Day day77 = new org.jfree.data.time.Day(date76);
        org.jfree.data.time.Day day78 = new org.jfree.data.time.Day(date76);
        org.jfree.data.time.FixedMillisecond fixedMillisecond79 = new org.jfree.data.time.FixedMillisecond(date76);
        long long80 = fixedMillisecond79.getMiddleMillisecond();
        timeSeries64.setKey((java.lang.Comparable) long80);
        java.util.Collection collection82 = timeSeries64.getTimePeriods();
        java.util.Collection collection83 = timeSeries50.getTimePeriodsUniqueToOtherSeries(timeSeries64);
        int int84 = month19.compareTo((java.lang.Object) timeSeries50);
        try {
            org.jfree.data.time.TimeSeries timeSeries87 = timeSeries50.createCopy((int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 6 + "'", int42 == 6);
        org.junit.Assert.assertNotNull(date43);
        org.junit.Assert.assertNotNull(serialDate45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1561964399999L + "'", long46 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 6 + "'", int52 == 6);
        org.junit.Assert.assertNotNull(date53);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
        org.junit.Assert.assertTrue("'" + long70 + "' != '" + 1559372400000L + "'", long70 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 1 + "'", int73 == 1);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 6 + "'", int75 == 6);
        org.junit.Assert.assertNotNull(date76);
        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1561964399999L + "'", long80 == 1561964399999L);
        org.junit.Assert.assertNotNull(collection82);
        org.junit.Assert.assertNotNull(collection83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 1 + "'", int84 == 1);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        timeSeries3.setMaximumItemAge((long) ' ');
        java.util.Collection collection12 = timeSeries3.getTimePeriods();
        timeSeries3.setDomainDescription("June 2019");
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        long long16 = month15.getFirstMillisecond();
        long long17 = month15.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, (double) (byte) 1);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries3.getDataItem(30);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 30, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection12);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1559372400000L + "'", long16 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 24234L + "'", long17 == 24234L);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getFirstMillisecond();
        long long4 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, year1);
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 9, "org.jfree.data.event.SeriesChangeEvent[source=4]", "Value");
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        int int10 = timeSeries3.getIndex(regularTimePeriod9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries3.addChangeListener(seriesChangeListener11);
        java.beans.PropertyChangeListener propertyChangeListener13 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        int int30 = month29.getYearValue();
        long long31 = month29.getSerialIndex();
        boolean boolean32 = timeSeriesDataItem28.equals((java.lang.Object) month29);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int34 = month33.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) (-1.0f));
        boolean boolean37 = timeSeriesDataItem36.isSelected();
        org.jfree.data.time.Month month38 = new org.jfree.data.time.Month();
        int int39 = month38.getMonth();
        java.util.Date date40 = month38.getEnd();
        org.jfree.data.time.Year year41 = new org.jfree.data.time.Year(date40);
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month(date40);
        int int43 = month42.getMonth();
        boolean boolean44 = timeSeriesDataItem36.equals((java.lang.Object) month42);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem46 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month42, (double) 2);
        boolean boolean47 = month29.equals((java.lang.Object) month42);
        java.lang.Number number48 = timeSeries3.getValue((org.jfree.data.time.RegularTimePeriod) month42);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2019 + "'", int30 == 2019);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 24234L + "'", long31 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNull(number48);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond0 = new org.jfree.data.time.FixedMillisecond();
//        java.lang.String str1 = fixedMillisecond0.toString();
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "Mon Jun 10 09:13:08 PDT 2019" + "'", str1.equals("Mon Jun 10 09:13:08 PDT 2019"));
//    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Class class6 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.removeChangeListener(seriesChangeListener7);
        timeSeries3.setNotify(true);
        org.junit.Assert.assertNull(class6);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        boolean boolean4 = month0.equals((java.lang.Object) "");
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = timeSeries6.getDataItem(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(year5);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        try {
            org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(2019, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        long long5 = timeSeries3.getMaximumItemAge();
        java.lang.String str6 = timeSeries3.getDomainDescription();
        int int7 = timeSeries3.getItemCount();
        try {
            org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy((-9999), 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 2019, false);
        int int17 = day3.compareTo((java.lang.Object) timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener18);
        java.lang.Class class20 = timeSeries9.getTimePeriodClass();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance(class20, date23, timeZone25);
        java.util.TimeZone timeZone27 = null;
        java.util.Locale locale28 = null;
        try {
            org.jfree.data.time.Year year29 = new org.jfree.data.time.Year(date23, timeZone27, locale28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(class20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod26);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = null;
        try {
            timeSeries3.add(regularTimePeriod10, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem8 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month5, (java.lang.Number) (-1.0f));
        boolean boolean9 = timeSeriesDataItem8.isSelected();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date12);
        int int15 = month14.getMonth();
        boolean boolean16 = timeSeriesDataItem8.equals((java.lang.Object) month14);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = timeSeries3.addOrUpdate(timeSeriesDataItem18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date22);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) month25);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month25, (java.lang.Number) 100);
        org.jfree.data.time.Year year29 = month25.getYear();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertNotNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(year29);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getFirstMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 1.0d);
        java.lang.Object obj12 = null;
        boolean boolean13 = timeSeries3.equals(obj12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Calendar calendar18 = null;
        fixedMillisecond15.peg(calendar18);
        java.util.Date date20 = fixedMillisecond15.getTime();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.lang.String str22 = timeSeries3.getDescription();
        try {
            timeSeries3.delete((int) ' ', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(str22);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        timeSeries3.setDomainDescription("");
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        long long17 = day16.getSerialIndex();
        long long18 = day16.getSerialIndex();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) day16);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month20, (java.lang.Number) (-1.0f));
        boolean boolean24 = timeSeriesDataItem23.isSelected();
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
        int int26 = month25.getMonth();
        java.util.Date date27 = month25.getEnd();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(date27);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month(date27);
        int int30 = month29.getMonth();
        boolean boolean31 = timeSeriesDataItem23.equals((java.lang.Object) month29);
        int int32 = month29.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries35 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month29, "hi!", "June 2019");
        org.jfree.data.time.Month month36 = new org.jfree.data.time.Month();
        int int37 = month36.getMonth();
        java.util.Date date38 = month36.getEnd();
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date38);
        int int40 = day39.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod41 = day39.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem42 = timeSeries35.getDataItem(regularTimePeriod41);
        int int43 = day16.compareTo((java.lang.Object) timeSeries35);
        org.jfree.data.time.SerialDate serialDate44 = day16.getSerialDate();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 43646L + "'", long17 == 43646L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 43646L + "'", long18 == 43646L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 2019 + "'", int32 == 2019);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 6 + "'", int37 == 6);
        org.junit.Assert.assertNotNull(date38);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 2019 + "'", int40 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod41);
        org.junit.Assert.assertNull(timeSeriesDataItem42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
        org.junit.Assert.assertNotNull(serialDate44);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        int int12 = month9.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9, "hi!", "June 2019");
        java.lang.String str16 = timeSeries15.getDescription();
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) 2019, false);
        long long28 = day24.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod31 = day24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day24.next();
        timeSeries15.add(regularTimePeriod32, (double) ' ', true);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNull(str16);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43646L + "'", long28 == 43646L);
        org.junit.Assert.assertNotNull(regularTimePeriod31);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.Year year2 = month0.getYear();
        int int3 = month0.getYearValue();
        org.jfree.data.time.TimeSeries timeSeries7 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str8 = timeSeries7.getDomainDescription();
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem12 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (java.lang.Number) (-1.0f));
        boolean boolean13 = timeSeriesDataItem12.isSelected();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        int int15 = month14.getMonth();
        java.util.Date date16 = month14.getEnd();
        org.jfree.data.time.Year year17 = new org.jfree.data.time.Year(date16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month(date16);
        int int19 = month18.getMonth();
        boolean boolean20 = timeSeriesDataItem12.equals((java.lang.Object) month18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries7.addOrUpdate(timeSeriesDataItem22);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = timeSeries7.getNextTimePeriod();
        double double25 = timeSeries7.getMaxY();
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str30 = timeSeries29.getDomainDescription();
        boolean boolean31 = timeSeries29.getNotify();
        timeSeries29.removeAgedItems(1L, true);
        java.util.Collection collection35 = timeSeries7.getTimePeriodsUniqueToOtherSeries(timeSeries29);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = timeSeries7.getNextTimePeriod();
        int int37 = month0.compareTo((java.lang.Object) timeSeries7);
        timeSeries7.clear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(year2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.0d + "'", double25 == 2.0d);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertNotNull(regularTimePeriod36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 1 + "'", int37 == 1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.removeChangeListener(seriesChangeListener11);
        boolean boolean13 = timeSeries10.getNotify();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        int int17 = timeSeries10.getIndex(regularTimePeriod16);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries10.addChangeListener(seriesChangeListener18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener20);
        int int22 = fixedMillisecond5.compareTo((java.lang.Object) propertyChangeListener20);
        long long23 = fixedMillisecond5.getMiddleMillisecond();
        java.util.Calendar calendar24 = null;
        long long25 = fixedMillisecond5.getMiddleMillisecond(calendar24);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1561964399999L + "'", long25 == 1561964399999L);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        java.lang.Class<?> wildcardClass14 = month9.getClass();
        org.jfree.data.time.Year year15 = month9.getYear();
        java.util.Date date16 = year15.getStart();
        int int17 = year15.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.clear();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (-1.0f));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate(timeSeriesDataItem13);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo15 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent16 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) timeSeries3, seriesChangeInfo15);
        boolean boolean17 = timeSeries3.getNotify();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond5.getMiddleMillisecond(calendar7);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
    }

//    @Test
//    public void test185() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test185");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        int int6 = day5.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.previous();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener12);
//        boolean boolean14 = timeSeries11.getNotify();
//        timeSeries11.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries20.removeChangeListener(seriesChangeListener21);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries11.addAndOrUpdate(timeSeries20);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries27.removeChangeListener(seriesChangeListener28);
//        boolean boolean30 = timeSeries27.getNotify();
//        timeSeries27.setRangeDescription("hi!");
//        double double33 = timeSeries27.getMinY();
//        java.util.Collection collection34 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries27);
//        java.lang.Class<?> wildcardClass35 = timeSeries11.getClass();
//        int int36 = day5.compareTo((java.lang.Object) wildcardClass35);
//        boolean boolean37 = day0.equals((java.lang.Object) day5);
//        long long38 = day0.getLastMillisecond();
//        int int39 = day0.getYear();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560236399999L + "'", long38 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 2019 + "'", int39 == 2019);
//    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = month4.next();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month4.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        try {
            org.jfree.data.time.Year year1 = org.jfree.data.time.Year.parseYear("Mon Jun 10 09:13:08 PDT 2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Cannot parse string.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Overwritten values from: hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Overwritten values from: hi!");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("Wed Dec 31 16:00:00 PST 1969");
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        int int4 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (-1.0f));
        boolean boolean10 = timeSeriesDataItem9.isSelected();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        java.util.Date date13 = month11.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date13);
        int int16 = month15.getMonth();
        boolean boolean17 = timeSeriesDataItem9.equals((java.lang.Object) month15);
        int int18 = day3.compareTo((java.lang.Object) boolean17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        int int20 = month19.getMonth();
        java.util.Date date21 = month19.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond24.next();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.Object obj31 = null;
        boolean boolean32 = timeSeries30.equals(obj31);
        double double33 = timeSeries30.getMaxY();
        int int34 = fixedMillisecond24.compareTo((java.lang.Object) double33);
        int int35 = day3.compareTo((java.lang.Object) double33);
        long long36 = day3.getMiddleMillisecond();
        java.util.Calendar calendar37 = null;
        try {
            day3.peg(calendar37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1561921199999L + "'", long36 == 1561921199999L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        java.lang.Class<?> wildcardClass14 = month9.getClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date17, timeZone19);
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month(date17);
        java.util.Calendar calendar22 = null;
        try {
            month21.peg(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod20);
    }

//    @Test
//    public void test191() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test191");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        int int2 = day0.getYear();
//        long long3 = day0.getSerialIndex();
//        int int4 = day0.getMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day0.next();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//        org.junit.Assert.assertNotNull(regularTimePeriod5);
//    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries12);
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries19.removeChangeListener(seriesChangeListener20);
        boolean boolean22 = timeSeries19.getNotify();
        timeSeries19.setRangeDescription("hi!");
        double double25 = timeSeries19.getMinY();
        java.util.Collection collection26 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        timeSeries19.fireSeriesChanged();
        boolean boolean29 = timeSeries19.equals((java.lang.Object) false);
        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener34 = null;
        timeSeries33.removeChangeListener(seriesChangeListener34);
        boolean boolean36 = timeSeries33.getNotify();
        timeSeries33.setRangeDescription("hi!");
        double double39 = timeSeries33.getMinY();
        timeSeries33.setMaximumItemAge((long) ' ');
        java.util.Collection collection42 = timeSeries33.getTimePeriods();
        timeSeries33.setDomainDescription("June 2019");
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        long long46 = month45.getFirstMillisecond();
        long long47 = month45.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries33.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month45, (double) (byte) 1);
        boolean boolean50 = timeSeries19.equals((java.lang.Object) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries15);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertEquals((double) double25, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertEquals((double) double39, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1559372400000L + "'", long46 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long47 + "' != '" + 24234L + "'", long47 == 24234L);
        org.junit.Assert.assertNull(timeSeriesDataItem49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        int int10 = timeSeries3.getIndex(regularTimePeriod9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries3.addChangeListener(seriesChangeListener11);
        timeSeries3.fireSeriesChanged();
        timeSeries3.clear();
        try {
            timeSeries3.delete((-1), (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener6 = null;
        timeSeries3.addChangeListener(seriesChangeListener6);
        org.jfree.data.time.TimeSeries timeSeries10 = timeSeries3.createCopy(0, 10);
        timeSeries10.setDomainDescription("");
        org.junit.Assert.assertNotNull(timeSeries10);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (-1.0f));
        boolean boolean14 = timeSeriesDataItem13.isSelected();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17);
        int int20 = month19.getMonth();
        boolean boolean21 = timeSeriesDataItem13.equals((java.lang.Object) month19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (double) 2);
        org.jfree.data.time.Year year24 = month19.getYear();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries28.removeChangeListener(seriesChangeListener29);
        boolean boolean31 = timeSeries28.getNotify();
        timeSeries28.setRangeDescription("hi!");
        double double34 = timeSeries28.getMinY();
        timeSeries28.setMaximumItemAge((long) ' ');
        java.util.List list37 = timeSeries28.getItems();
        boolean boolean38 = month19.equals((java.lang.Object) timeSeries28);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = month19.next();
        timeSeries3.setKey((java.lang.Comparable) month19);
        try {
            java.lang.Number number42 = timeSeries3.getValue((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        try {
            org.jfree.data.time.Month month1 = org.jfree.data.time.Month.parseMonth("1-June-2019");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.time.TimePeriodFormatException; message: Can't evaluate the month.");
        } catch (org.jfree.data.time.TimePeriodFormatException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str14 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(timeSeriesDataItem28);
        boolean boolean30 = timeSeries3.equals((java.lang.Object) timeSeries13);
        timeSeries13.setMaximumItemAge(0L);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries13.removePropertyChangeListener(propertyChangeListener33);
        java.lang.Class class35 = timeSeries13.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(class35);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        boolean boolean4 = month0.equals((java.lang.Object) "");
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.TimeSeries timeSeries6 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) year5);
        java.lang.Object obj7 = timeSeries6.clone();
        boolean boolean8 = timeSeries6.isEmpty();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        boolean boolean4 = month0.equals((java.lang.Object) "");
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getYearValue();
        boolean boolean8 = year5.equals((java.lang.Object) month6);
        int int9 = year5.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year5.previous();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2019 + "'", int9 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Class class6 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.Year year9 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year9.previous();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year9);
        java.lang.String str12 = year9.toString();
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
        org.junit.Assert.assertNull(timeSeriesDataItem11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "2019" + "'", str12.equals("2019"));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        boolean boolean4 = month0.equals((java.lang.Object) "");
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getYearValue();
        boolean boolean8 = year5.equals((java.lang.Object) month6);
        long long9 = year5.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = year5.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2019 + "'", int7 == 2019);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1546329600000L + "'", long9 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod10);
    }

//    @Test
//    public void test202() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test202");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = month4.getMonth();
//        java.util.Date date6 = month4.getEnd();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 2019, false);
//        timeSeries3.removeAgedItems((long) (byte) 100, false);
//        timeSeries3.clear();
//        java.beans.PropertyChangeListener propertyChangeListener15 = null;
//        timeSeries3.removePropertyChangeListener(propertyChangeListener15);
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
//        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
//        int int22 = month21.getMonth();
//        java.util.Date date23 = month21.getEnd();
//        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
//        timeSeries20.add((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) 2019, false);
//        long long28 = day24.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day24, (java.lang.Number) 8);
//        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day();
//        int int32 = timeSeriesDataItem30.compareTo((java.lang.Object) day31);
//        long long33 = day31.getSerialIndex();
//        boolean boolean34 = timeSeries3.equals((java.lang.Object) day31);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
//        org.junit.Assert.assertNotNull(date23);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 43646L + "'", long28 == 43646L);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 43626L + "'", long33 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
//    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = year2.next();
        boolean boolean5 = year2.equals((java.lang.Object) 100.0d);
        try {
            org.jfree.data.time.Month month6 = new org.jfree.data.time.Month((int) (short) 100, year2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getFirstMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 1.0d);
        int int12 = timeSeries3.getItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date15);
        long long19 = fixedMillisecond18.getMiddleMillisecond();
        timeSeries3.setKey((java.lang.Comparable) long19);
        java.util.Collection collection21 = timeSeries3.getTimePeriods();
        int int22 = timeSeries3.getMaximumItemCount();
        int int23 = timeSeries3.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        java.util.Date date6 = month4.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 2019, false);
        timeSeries3.removeAgedItems((long) (byte) 100, false);
        timeSeries3.clear();
        java.beans.PropertyChangeListener propertyChangeListener15 = null;
        timeSeries3.removePropertyChangeListener(propertyChangeListener15);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str22 = timeSeries21.getDomainDescription();
        boolean boolean23 = timeSeries21.getNotify();
        org.jfree.data.time.Year year25 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year25, (java.lang.Number) 24234L);
        boolean boolean28 = timeSeries21.equals((java.lang.Object) 24234L);
        org.jfree.data.time.Year year29 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod30 = year29.previous();
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        int int32 = month31.getMonth();
        java.util.Date date33 = month31.getEnd();
        org.jfree.data.time.Day day34 = new org.jfree.data.time.Day(date33);
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date33);
        org.jfree.data.time.FixedMillisecond fixedMillisecond36 = new org.jfree.data.time.FixedMillisecond(date33);
        long long37 = fixedMillisecond36.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener42 = null;
        timeSeries41.removeChangeListener(seriesChangeListener42);
        boolean boolean44 = timeSeries41.getNotify();
        org.jfree.data.time.Year year46 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod47 = year46.next();
        int int48 = timeSeries41.getIndex(regularTimePeriod47);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener49 = null;
        timeSeries41.addChangeListener(seriesChangeListener49);
        java.beans.PropertyChangeListener propertyChangeListener51 = null;
        timeSeries41.addPropertyChangeListener(propertyChangeListener51);
        int int53 = fixedMillisecond36.compareTo((java.lang.Object) propertyChangeListener51);
        long long54 = fixedMillisecond36.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries21.createCopy(regularTimePeriod30, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond36);
        java.util.Collection collection56 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries21);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertNotNull(date33);
        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1561964399999L + "'", long37 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 1 + "'", int53 == 1);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1561964399999L + "'", long54 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(collection56);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.removeChangeListener(seriesChangeListener7);
        try {
            org.jfree.data.time.RegularTimePeriod regularTimePeriod10 = timeSeries3.getTimePeriod((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        org.jfree.data.time.Year year14 = month9.getYear();
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.removeChangeListener(seriesChangeListener19);
        boolean boolean21 = timeSeries18.getNotify();
        timeSeries18.setRangeDescription("hi!");
        double double24 = timeSeries18.getMinY();
        timeSeries18.setMaximumItemAge((long) ' ');
        java.util.List list27 = timeSeries18.getItems();
        boolean boolean28 = month9.equals((java.lang.Object) timeSeries18);
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        int int30 = month29.getMonth();
        java.util.Date date31 = month29.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        int int33 = day32.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = day32.previous();
        int int35 = day32.getMonth();
        timeSeries18.add((org.jfree.data.time.RegularTimePeriod) day32, (double) 0L);
        org.jfree.data.time.Year year39 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod40 = year39.next();
        int int41 = timeSeries18.getIndex((org.jfree.data.time.RegularTimePeriod) year39);
        try {
            org.jfree.data.time.TimeSeries timeSeries44 = timeSeries18.createCopy((int) (short) 1, 6);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(year14);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertEquals((double) double24, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2019 + "'", int33 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 6 + "'", int35 == 6);
        org.junit.Assert.assertNotNull(regularTimePeriod40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 24234L);
        timeSeries3.add(timeSeriesDataItem15, true);
        org.jfree.data.time.TimeSeries timeSeries21 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries21.removeChangeListener(seriesChangeListener22);
        boolean boolean24 = timeSeries21.getNotify();
        timeSeries21.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries30.removeChangeListener(seriesChangeListener31);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries21.addAndOrUpdate(timeSeries30);
        org.jfree.data.time.Year year34 = new org.jfree.data.time.Year();
        timeSeries33.add((org.jfree.data.time.RegularTimePeriod) year34, (double) (short) 1, true);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
        timeSeries33.removeChangeListener(seriesChangeListener38);
        java.lang.String str40 = timeSeries33.getRangeDescription();
        java.util.Collection collection41 = timeSeries3.getTimePeriodsUniqueToOtherSeries(timeSeries33);
        timeSeries3.setMaximumItemAge((long) 9999);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(timeSeries33);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Value" + "'", str40.equals("Value"));
        org.junit.Assert.assertNotNull(collection41);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        int int12 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        int int17 = day16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.previous();
        long long19 = day16.getLastMillisecond();
        boolean boolean20 = month9.equals((java.lang.Object) day16);
        org.jfree.data.time.Year year21 = month9.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(year21);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.next();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.Object obj12 = null;
        boolean boolean13 = timeSeries11.equals(obj12);
        double double14 = timeSeries11.getMaxY();
        int int15 = fixedMillisecond5.compareTo((java.lang.Object) double14);
        long long16 = fixedMillisecond5.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        java.util.TimeZone timeZone6 = null;
        try {
            org.jfree.data.time.Month month7 = new org.jfree.data.time.Month(date2, timeZone6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        int int7 = fixedMillisecond5.compareTo((java.lang.Object) 6);
        long long8 = fixedMillisecond5.getMiddleMillisecond();
        java.util.Calendar calendar9 = null;
        fixedMillisecond5.peg(calendar9);
        java.util.Date date11 = fixedMillisecond5.getTime();
        java.util.Calendar calendar12 = null;
        long long13 = fixedMillisecond5.getFirstMillisecond(calendar12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        long long1 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year0.previous();
        java.lang.String str3 = year0.toString();
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1546329600000L + "'", long1 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "2019" + "'", str3.equals("2019"));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Class class6 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener7 = null;
        timeSeries3.removeChangeListener(seriesChangeListener7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month();
        int int10 = month9.getMonth();
        java.util.Date date11 = month9.getEnd();
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date11);
        long long13 = day12.getSerialIndex();
        timeSeries3.setKey((java.lang.Comparable) day12);
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.previous();
        long long17 = year15.getFirstMillisecond();
        long long18 = year15.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = year15.next();
        int int20 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) year15);
        long long21 = year15.getLastMillisecond();
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertNotNull(date11);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 43646L + "'", long13 == 43646L);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1546329600000L + "'", long17 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1562097599999L + "'", long18 == 1562097599999L);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1577865599999L + "'", long21 == 1577865599999L);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        java.lang.String str5 = year3.toString();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener10 = null;
        timeSeries9.removeChangeListener(seriesChangeListener10);
        boolean boolean12 = timeSeries9.getNotify();
        timeSeries9.setRangeDescription("hi!");
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        java.lang.String str19 = year18.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = year18.previous();
        timeSeries9.delete((org.jfree.data.time.RegularTimePeriod) year18);
        timeSeries9.setRangeDescription("Overwritten values from: hi!");
        boolean boolean24 = year3.equals((java.lang.Object) timeSeries9);
        timeSeries9.setDomainDescription("30-June-2019");
        org.jfree.data.time.Month month27 = new org.jfree.data.time.Month();
        int int28 = month27.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) (-1.0f));
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) month27, (java.lang.Number) 9999);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "2019" + "'", str19.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 6 + "'", int28 == 6);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod3 = month0.previous();
        java.util.Date date4 = regularTimePeriod3.getEnd();
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date4);
        java.lang.String str7 = day6.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod3);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "31-May-2019" + "'", str7.equals("31-May-2019"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        long long6 = fixedMillisecond5.getFirstMillisecond();
        long long7 = fixedMillisecond5.getFirstMillisecond();
        long long8 = fixedMillisecond5.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        boolean boolean5 = timeSeries3.getNotify();
        timeSeries3.removeAgedItems(1L, true);
        timeSeries3.removeAgedItems(true);
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        java.util.Date date13 = month11.getEnd();
        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date13);
        org.jfree.data.time.FixedMillisecond fixedMillisecond16 = new org.jfree.data.time.FixedMillisecond(date13);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = fixedMillisecond16.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = timeSeries3.getDataItem(regularTimePeriod17);
        int int19 = timeSeries3.getMaximumItemCount();
        int int20 = timeSeries3.getItemCount();
        try {
            timeSeries3.delete(9, 11);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 9, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
        org.junit.Assert.assertNull(timeSeriesDataItem18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 2147483647 + "'", int19 == 2147483647);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, (int) (short) 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        timeSeries3.setMaximumItemAge((long) ' ');
        java.util.List list12 = timeSeries3.getItems();
        timeSeries3.setMaximumItemCount((int) (byte) 100);
        long long15 = timeSeries3.getMaximumItemAge();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int17 = month16.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month16, (java.lang.Number) (-1.0f));
        boolean boolean20 = timeSeriesDataItem19.isSelected();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month(date23);
        int int26 = month25.getMonth();
        boolean boolean27 = timeSeriesDataItem19.equals((java.lang.Object) month25);
        boolean boolean28 = timeSeriesDataItem19.isSelected();
        timeSeriesDataItem19.setSelected(false);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries3.addOrUpdate(timeSeriesDataItem19);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 32L + "'", long15 == 32L);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 6 + "'", int26 == 6);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem31);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        java.lang.Class<?> wildcardClass14 = month9.getClass();
        org.jfree.data.time.Year year15 = month9.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month9.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Year year2 = new org.jfree.data.time.Year(date1);
        int int3 = year2.getYear();
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.clear();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (-1.0f));
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries3.addOrUpdate(timeSeriesDataItem13);
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries18.removeChangeListener(seriesChangeListener19);
        java.lang.Class class21 = timeSeries18.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries22 = timeSeries3.addAndOrUpdate(timeSeries18);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar25 = null;
        long long26 = fixedMillisecond24.getMiddleMillisecond(calendar25);
        java.util.Calendar calendar27 = null;
        fixedMillisecond24.peg(calendar27);
        java.util.Date date29 = fixedMillisecond24.getTime();
        int int30 = timeSeries3.getIndex((org.jfree.data.time.RegularTimePeriod) fixedMillisecond24);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNull(timeSeriesDataItem14);
        org.junit.Assert.assertNull(class21);
        org.junit.Assert.assertNotNull(timeSeries22);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 1L + "'", long26 == 1L);
        org.junit.Assert.assertNotNull(date29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        timeSeries3.setMaximumItemAge((long) ' ');
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year13, (java.lang.Number) 24234L);
        timeSeries3.add(timeSeriesDataItem15, true);
        java.lang.Number number18 = timeSeriesDataItem15.getValue();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 24234L + "'", number18.equals(24234L));
    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        int int6 = day5.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.previous();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener12);
//        boolean boolean14 = timeSeries11.getNotify();
//        timeSeries11.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries20.removeChangeListener(seriesChangeListener21);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries11.addAndOrUpdate(timeSeries20);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries27.removeChangeListener(seriesChangeListener28);
//        boolean boolean30 = timeSeries27.getNotify();
//        timeSeries27.setRangeDescription("hi!");
//        double double33 = timeSeries27.getMinY();
//        java.util.Collection collection34 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries27);
//        java.lang.Class<?> wildcardClass35 = timeSeries11.getClass();
//        int int36 = day5.compareTo((java.lang.Object) wildcardClass35);
//        boolean boolean37 = day0.equals((java.lang.Object) day5);
//        long long38 = day0.getLastMillisecond();
//        int int39 = day0.getMonth();
//        java.lang.String str40 = day0.toString();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1560236399999L + "'", long38 == 1560236399999L);
//        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 6 + "'", int39 == 6);
//        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "10-June-2019" + "'", str40.equals("10-June-2019"));
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Year year4 = new org.jfree.data.time.Year(date2);
        long long5 = year4.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 1562097599999L, "Value", "June 2019");
        java.lang.Comparable comparable4 = timeSeries3.getKey();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener5 = null;
        timeSeries3.removeChangeListener(seriesChangeListener5);
        org.junit.Assert.assertTrue("'" + comparable4 + "' != '" + 1562097599999L + "'", comparable4.equals(1562097599999L));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        long long4 = day3.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 43646L + "'", long4 == 43646L);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
        int int3 = month2.getMonth();
        java.util.Date date4 = month2.getEnd();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
        int int6 = day5.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.previous();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
        timeSeries11.removeChangeListener(seriesChangeListener12);
        boolean boolean14 = timeSeries11.getNotify();
        timeSeries11.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
        timeSeries20.removeChangeListener(seriesChangeListener21);
        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries11.addAndOrUpdate(timeSeries20);
        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
        timeSeries27.removeChangeListener(seriesChangeListener28);
        boolean boolean30 = timeSeries27.getNotify();
        timeSeries27.setRangeDescription("hi!");
        double double33 = timeSeries27.getMinY();
        java.util.Collection collection34 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries27);
        java.lang.Class<?> wildcardClass35 = timeSeries11.getClass();
        int int36 = day5.compareTo((java.lang.Object) wildcardClass35);
        boolean boolean37 = day0.equals((java.lang.Object) day5);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day5, (double) 1561921199999L);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
        org.junit.Assert.assertNotNull(date4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(timeSeries23);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection34);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate4);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day6.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        java.util.Calendar calendar7 = null;
        long long8 = fixedMillisecond5.getLastMillisecond(calendar7);
        java.util.Calendar calendar9 = null;
        long long10 = fixedMillisecond5.getLastMillisecond(calendar9);
        java.util.Calendar calendar11 = null;
        fixedMillisecond5.peg(calendar11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1561964399999L + "'", long10 == 1561964399999L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str14 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(timeSeriesDataItem28);
        boolean boolean30 = timeSeries3.equals((java.lang.Object) timeSeries13);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        int int32 = month31.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (-1.0f));
        java.lang.Number number35 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) month31);
        timeSeries13.clear();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        int int38 = month37.getMonth();
        java.util.Date date39 = month37.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date39);
        long long43 = fixedMillisecond42.getFirstMillisecond();
        timeSeries13.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond42, (double) 52L);
        org.jfree.data.general.SeriesException seriesException47 = new org.jfree.data.general.SeriesException("org.jfree.data.general.SeriesException: Overwritten values from: hi!");
        boolean boolean48 = fixedMillisecond42.equals((java.lang.Object) "org.jfree.data.general.SeriesException: Overwritten values from: hi!");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 2.0d + "'", number35.equals(2.0d));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1561964399999L + "'", long43 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(5, 8);
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month2.getFirstMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        long long4 = fixedMillisecond1.getLastMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1L + "'", long4 == 1L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getFirstMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 1.0d);
        int int12 = timeSeries3.getItemCount();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date15);
        long long19 = fixedMillisecond18.getMiddleMillisecond();
        timeSeries3.setKey((java.lang.Comparable) long19);
        java.util.Collection collection21 = timeSeries3.getTimePeriods();
        int int22 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries3.addOrUpdate(regularTimePeriod23, (java.lang.Number) 1560668399999L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertNotNull(collection21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 2147483647 + "'", int22 == 2147483647);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Overwritten values from: hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("Overwritten values from: hi!");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("Overwritten values from: hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.String str10 = seriesException1.toString();
        java.lang.Throwable throwable11 = null;
        try {
            seriesException1.addSuppressed(throwable11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: Overwritten values from: hi!" + "'", str10.equals("org.jfree.data.general.SeriesException: Overwritten values from: hi!"));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.TimeSeries timeSeries15 = timeSeries3.addAndOrUpdate(timeSeries12);
        try {
            java.lang.Number number17 = timeSeries3.getValue((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(timeSeries15);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        int int10 = timeSeries3.getIndex(regularTimePeriod9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries3.addChangeListener(seriesChangeListener11);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy(6, 9999);
        boolean boolean17 = timeSeries3.isEmpty();
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar20 = null;
        long long21 = fixedMillisecond19.getFirstMillisecond(calendar20);
        java.util.Calendar calendar22 = null;
        long long23 = fixedMillisecond19.getFirstMillisecond(calendar22);
        java.lang.Number number24 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, number24);
        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem25);
        timeSeries3.add(timeSeriesDataItem25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod28 = timeSeries3.getNextTimePeriod();
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries32.removeChangeListener(seriesChangeListener33);
        timeSeries32.setNotify(true);
        java.lang.Class class37 = timeSeries32.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener38 = null;
        timeSeries32.addChangeListener(seriesChangeListener38);
        org.jfree.data.time.TimeSeries timeSeries43 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener44 = null;
        timeSeries43.removeChangeListener(seriesChangeListener44);
        timeSeries43.setNotify(true);
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        int int49 = month48.getMonth();
        java.util.Date date50 = month48.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month48, (java.lang.Number) 1546329600000L);
        timeSeries43.add(timeSeriesDataItem52, true);
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries32.addAndOrUpdate(timeSeries43);
        org.jfree.data.time.Month month56 = new org.jfree.data.time.Month();
        int int57 = month56.getMonth();
        java.util.Date date58 = month56.getEnd();
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date58);
        int int60 = day59.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = day59.previous();
        timeSeries32.delete((org.jfree.data.time.RegularTimePeriod) day59);
        java.lang.String str63 = timeSeries32.getDomainDescription();
        org.jfree.data.time.Month month64 = new org.jfree.data.time.Month();
        int int65 = month64.getMonth();
        java.util.Date date66 = month64.getEnd();
        org.jfree.data.time.Year year67 = new org.jfree.data.time.Year(date66);
        org.jfree.data.time.Month month68 = new org.jfree.data.time.Month(date66);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = month68.next();
        timeSeries32.delete((org.jfree.data.time.RegularTimePeriod) month68);
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month68, (double) 1561921199999L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.FixedMillisecond.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 1L + "'", long21 == 1L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1L + "'", long23 == 1L);
        org.junit.Assert.assertNotNull(regularTimePeriod28);
        org.junit.Assert.assertNull(class37);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 6 + "'", int49 == 6);
        org.junit.Assert.assertNotNull(date50);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 6 + "'", int57 == 6);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 2019 + "'", int60 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 6 + "'", int65 == 6);
        org.junit.Assert.assertNotNull(date66);
        org.junit.Assert.assertNotNull(regularTimePeriod69);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        long long7 = regularTimePeriod6.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod6, (double) 6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399998L + "'", long7 == 1561964399998L);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        long long6 = fixedMillisecond5.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.removeChangeListener(seriesChangeListener11);
        boolean boolean13 = timeSeries10.getNotify();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        int int17 = timeSeries10.getIndex(regularTimePeriod16);
        int int18 = fixedMillisecond5.compareTo((java.lang.Object) regularTimePeriod16);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = new org.jfree.data.time.TimeSeriesDataItem(regularTimePeriod16, (java.lang.Number) 9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
        java.lang.Object obj2 = null;
        int int3 = year1.compareTo(obj2);
        long long4 = year1.getSerialIndex();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 3L + "'", long4 == 3L);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = month4.getMiddleMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str14 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(timeSeriesDataItem28);
        boolean boolean30 = timeSeries3.equals((java.lang.Object) timeSeries13);
        timeSeries13.setMaximumItemAge(0L);
        int int33 = timeSeries13.getMaximumItemCount();
        long long34 = timeSeries13.getMaximumItemAge();
        java.lang.Class<?> wildcardClass35 = timeSeries13.getClass();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener40 = null;
        timeSeries39.removeChangeListener(seriesChangeListener40);
        boolean boolean42 = timeSeries39.getNotify();
        timeSeries39.setRangeDescription("hi!");
        double double45 = timeSeries39.getMinY();
        timeSeries39.setMaximumItemAge((long) ' ');
        java.beans.PropertyChangeListener propertyChangeListener48 = null;
        timeSeries39.addPropertyChangeListener(propertyChangeListener48);
        java.util.Collection collection50 = timeSeries39.getTimePeriods();
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries13.addAndOrUpdate(timeSeries39);
        double double52 = timeSeries39.getMinY();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2147483647 + "'", int33 == 2147483647);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 0L + "'", long34 == 0L);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection50);
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertEquals((double) double52, Double.NaN, 0);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        java.util.Date date6 = month4.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 2019, false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
        long long18 = day16.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        int int24 = month23.getMonth();
        java.util.Date date25 = month23.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) 2019, false);
        int int30 = day16.compareTo((java.lang.Object) timeSeries22);
        int int31 = day16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day16.previous();
        java.lang.String str33 = day16.toString();
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10);
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener40 = null;
        timeSeries39.removeChangeListener(seriesChangeListener40);
        boolean boolean42 = timeSeries39.getNotify();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year44.next();
        int int46 = timeSeries39.getIndex(regularTimePeriod45);
        boolean boolean47 = day16.equals((java.lang.Object) int46);
        java.util.Calendar calendar48 = null;
        try {
            long long49 = day16.getFirstMillisecond(calendar48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "30-June-2019" + "'", str33.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month((int) (short) 1, 11);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.lang.String str2 = month0.toString();
        org.jfree.data.time.Year year3 = month0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "June 2019" + "'", str2.equals("June 2019"));
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        int int14 = month9.getYearValue();
        java.lang.String str15 = month9.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = month9.next();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) month9);
        timeSeries17.setDescription("hi!");
        timeSeries17.removeAgedItems(0L, false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "June 2019" + "'", str15.equals("June 2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod16);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        int int12 = month9.getYearValue();
        int int13 = month9.getMonth();
        java.util.Date date14 = month9.getEnd();
        java.util.Calendar calendar15 = null;
        try {
            month9.peg(calendar15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Overwritten values from: hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.String str3 = seriesException1.toString();
        java.lang.String str4 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.data.general.SeriesException: Overwritten values from: hi!" + "'", str3.equals("org.jfree.data.general.SeriesException: Overwritten values from: hi!"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: Overwritten values from: hi!" + "'", str4.equals("org.jfree.data.general.SeriesException: Overwritten values from: hi!"));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str14 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(timeSeriesDataItem28);
        boolean boolean30 = timeSeries3.equals((java.lang.Object) timeSeries13);
        timeSeries13.setMaximumItemAge(0L);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries13.removeChangeListener(seriesChangeListener33);
        java.util.List list35 = timeSeries13.getItems();
        java.beans.PropertyChangeListener propertyChangeListener36 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener36);
        try {
            org.jfree.data.time.TimeSeries timeSeries40 = timeSeries13.createCopy(0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(list35);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("org.jfree.data.event.SeriesChangeEvent[source=4]");
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) "org.jfree.data.event.SeriesChangeEvent[source=4]");
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        java.lang.Class<?> wildcardClass14 = month9.getClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date17, timeZone19);
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond(date17);
        long long22 = fixedMillisecond21.getMiddleMillisecond();
        long long23 = fixedMillisecond21.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod20);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1561964399999L + "'", long22 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Date date2 = year0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        int int5 = day3.compareTo((java.lang.Object) 10);
        int int6 = day3.getMonth();
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("Overwritten values from: hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        org.jfree.data.general.SeriesException seriesException4 = new org.jfree.data.general.SeriesException("Overwritten values from: hi!");
        org.jfree.data.general.SeriesException seriesException6 = new org.jfree.data.general.SeriesException("Overwritten values from: hi!");
        java.lang.Throwable[] throwableArray7 = seriesException6.getSuppressed();
        seriesException4.addSuppressed((java.lang.Throwable) seriesException6);
        seriesException1.addSuppressed((java.lang.Throwable) seriesException4);
        java.lang.String str10 = seriesException1.toString();
        org.jfree.data.general.SeriesException seriesException12 = new org.jfree.data.general.SeriesException("Overwritten values from: hi!");
        java.lang.Throwable[] throwableArray13 = seriesException12.getSuppressed();
        seriesException1.addSuppressed((java.lang.Throwable) seriesException12);
        java.lang.String str15 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.jfree.data.general.SeriesException: Overwritten values from: hi!" + "'", str10.equals("org.jfree.data.general.SeriesException: Overwritten values from: hi!"));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.jfree.data.general.SeriesException: Overwritten values from: hi!" + "'", str15.equals("org.jfree.data.general.SeriesException: Overwritten values from: hi!"));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        timeSeries3.clear();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (-1.0f));
        boolean boolean14 = timeSeriesDataItem13.isSelected();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17);
        int int20 = month19.getMonth();
        boolean boolean21 = timeSeriesDataItem13.equals((java.lang.Object) month19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (double) 2);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getYearValue();
        long long26 = month24.getSerialIndex();
        boolean boolean27 = timeSeriesDataItem23.equals((java.lang.Object) month24);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month24, (java.lang.Number) 0L, true);
        int int31 = month24.getMonth();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2019 + "'", int25 == 2019);
        org.junit.Assert.assertTrue("'" + long26 + "' != '" + 24234L + "'", long26 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 2019, false);
        int int17 = day3.compareTo((java.lang.Object) timeSeries9);
        java.lang.Comparable comparable18 = timeSeries9.getKey();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener19 = null;
        timeSeries9.addChangeListener(seriesChangeListener19);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + comparable18 + "' != '" + "hi!" + "'", comparable18.equals("hi!"));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        timeSeries3.setMaximumItemAge((long) ' ');
        timeSeries3.setMaximumItemCount((int) '#');
        try {
            timeSeries3.delete((int) (byte) 1, 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = fixedMillisecond5.previous();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = fixedMillisecond5.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod8 = fixedMillisecond5.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod6);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(regularTimePeriod8);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test259");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.SerialDate serialDate1 = day0.getSerialDate();
//        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month();
//        int int3 = month2.getMonth();
//        java.util.Date date4 = month2.getEnd();
//        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(date4);
//        int int6 = day5.getYear();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = day5.previous();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener12 = null;
//        timeSeries11.removeChangeListener(seriesChangeListener12);
//        boolean boolean14 = timeSeries11.getNotify();
//        timeSeries11.setRangeDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener21 = null;
//        timeSeries20.removeChangeListener(seriesChangeListener21);
//        org.jfree.data.time.TimeSeries timeSeries23 = timeSeries11.addAndOrUpdate(timeSeries20);
//        org.jfree.data.time.TimeSeries timeSeries27 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
//        org.jfree.data.event.SeriesChangeListener seriesChangeListener28 = null;
//        timeSeries27.removeChangeListener(seriesChangeListener28);
//        boolean boolean30 = timeSeries27.getNotify();
//        timeSeries27.setRangeDescription("hi!");
//        double double33 = timeSeries27.getMinY();
//        java.util.Collection collection34 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries27);
//        java.lang.Class<?> wildcardClass35 = timeSeries11.getClass();
//        int int36 = day5.compareTo((java.lang.Object) wildcardClass35);
//        boolean boolean37 = day0.equals((java.lang.Object) day5);
//        long long38 = day0.getSerialIndex();
//        java.lang.Object obj39 = null;
//        boolean boolean40 = day0.equals(obj39);
//        int int41 = day0.getDayOfMonth();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
//        org.junit.Assert.assertNotNull(date4);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2019 + "'", int6 == 2019);
//        org.junit.Assert.assertNotNull(regularTimePeriod7);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
//        org.junit.Assert.assertNotNull(timeSeries23);
//        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
//        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
//        org.junit.Assert.assertNotNull(collection34);
//        org.junit.Assert.assertNotNull(wildcardClass35);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
//        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
//        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 43626L + "'", long38 == 43626L);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 2019, false);
        int int17 = day3.compareTo((java.lang.Object) timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem20 = null;
        try {
            timeSeries9.add(timeSeriesDataItem20, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'item' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        timeSeries3.setDomainDescription("");
        timeSeries3.fireSeriesChanged();
        timeSeries3.clear();
        timeSeries3.setDescription("10-June-2019");
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(3);
        java.lang.Object obj2 = null;
        int int3 = year1.compareTo(obj2);
        int int4 = year1.getYear();
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries8.removeChangeListener(seriesChangeListener9);
        boolean boolean11 = timeSeries8.getNotify();
        timeSeries8.setRangeDescription("hi!");
        double double14 = timeSeries8.getMinY();
        timeSeries8.setMaximumItemAge((long) ' ');
        java.beans.PropertyChangeListener propertyChangeListener17 = null;
        timeSeries8.addPropertyChangeListener(propertyChangeListener17);
        java.util.Collection collection19 = timeSeries8.getTimePeriods();
        boolean boolean20 = year1.equals((java.lang.Object) collection19);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
        org.junit.Assert.assertNotNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        timeSeries3.setDomainDescription("");
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date15);
        long long19 = fixedMillisecond18.getMiddleMillisecond();
        int int21 = fixedMillisecond18.compareTo((java.lang.Object) 2147483647);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) fixedMillisecond18, (double) 1560150000000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = fixedMillisecond18.next();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod24);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("10-June-2019");
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test265");
//        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
//        int int5 = month4.getMonth();
//        java.util.Date date6 = month4.getEnd();
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
//        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 2019, false);
//        long long11 = day7.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 8);
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        int int15 = timeSeriesDataItem13.compareTo((java.lang.Object) day14);
//        long long16 = day14.getLastMillisecond();
//        java.util.Calendar calendar17 = null;
//        try {
//            day14.peg(calendar17);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
//        org.junit.Assert.assertNotNull(date6);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43646L + "'", long11 == 43646L);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
//        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1560236399999L + "'", long16 == 1560236399999L);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        java.util.Date date6 = month4.getEnd();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(date6);
        boolean boolean8 = month0.equals((java.lang.Object) year7);
        java.lang.Class<?> wildcardClass9 = month0.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        java.lang.Class class11 = org.jfree.data.time.RegularTimePeriod.downsize(class10);
        java.lang.Class class12 = org.jfree.data.time.RegularTimePeriod.downsize(class11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
        org.junit.Assert.assertNotNull(class11);
        org.junit.Assert.assertNotNull(class12);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo1 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent2 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) '4', seriesChangeInfo1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo3 = seriesChangeEvent2.getSummary();
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo4 = seriesChangeEvent2.getSummary();
        java.lang.Object obj5 = seriesChangeEvent2.getSource();
        org.junit.Assert.assertNull(seriesChangeInfo3);
        org.junit.Assert.assertNull(seriesChangeInfo4);
        org.junit.Assert.assertTrue("'" + obj5 + "' != '" + '4' + "'", obj5.equals('4'));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        int int14 = month9.getYearValue();
        long long15 = month9.getSerialIndex();
        int int16 = month9.getMonth();
        java.lang.String str17 = month9.toString();
        org.jfree.data.time.Year year18 = month9.getYear();
        java.util.Calendar calendar19 = null;
        try {
            year18.peg(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "June 2019" + "'", str17.equals("June 2019"));
        org.junit.Assert.assertNotNull(year18);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        java.util.Date date6 = month4.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 2019, false);
        java.beans.PropertyChangeListener propertyChangeListener11 = null;
        timeSeries3.addPropertyChangeListener(propertyChangeListener11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.SerialDate serialDate17 = day16.getSerialDate();
        long long18 = day16.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        int int24 = month23.getMonth();
        java.util.Date date25 = month23.getEnd();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day(date25);
        timeSeries22.add((org.jfree.data.time.RegularTimePeriod) day26, (java.lang.Number) 2019, false);
        int int30 = day16.compareTo((java.lang.Object) timeSeries22);
        int int31 = day16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day16.previous();
        java.lang.String str33 = day16.toString();
        timeSeries3.update((org.jfree.data.time.RegularTimePeriod) day16, (java.lang.Number) 10);
        java.lang.Comparable comparable36 = timeSeries3.getKey();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(serialDate17);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2019 + "'", int31 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "30-June-2019" + "'", str33.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + "hi!" + "'", comparable36.equals("hi!"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str14 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(timeSeriesDataItem28);
        boolean boolean30 = timeSeries3.equals((java.lang.Object) timeSeries13);
        timeSeries13.setMaximumItemAge(0L);
        int int33 = timeSeries13.getMaximumItemCount();
        java.beans.PropertyChangeListener propertyChangeListener34 = null;
        timeSeries13.addPropertyChangeListener(propertyChangeListener34);
        org.jfree.data.time.Year year36 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod37 = year36.previous();
        timeSeries13.update((org.jfree.data.time.RegularTimePeriod) year36, (java.lang.Number) 0.0d);
        long long40 = timeSeries13.getMaximumItemAge();
        try {
            java.lang.Number number42 = timeSeries13.getValue(12);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2147483647 + "'", int33 == 2147483647);
        org.junit.Assert.assertNotNull(regularTimePeriod37);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 0L + "'", long40 == 0L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        int int5 = day4.getMonth();
        int int7 = day4.compareTo((java.lang.Object) 100.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        java.util.Date date1 = month0.getEnd();
        org.jfree.data.time.Year year2 = month0.getYear();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = month0.getLastMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date1);
        org.junit.Assert.assertNotNull(year2);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        java.util.Date date6 = month4.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 2019, false);
        long long11 = day7.getSerialIndex();
        java.util.Calendar calendar12 = null;
        try {
            day7.peg(calendar12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43646L + "'", long11 == 43646L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        boolean boolean5 = timeSeries3.getNotify();
        java.lang.Class<?> wildcardClass6 = timeSeries3.getClass();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getMonth();
        java.util.Date date9 = month7.getEnd();
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date9);
        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond(date9);
        long long13 = fixedMillisecond12.getMiddleMillisecond();
        java.util.Calendar calendar14 = null;
        long long15 = fixedMillisecond12.getLastMillisecond(calendar14);
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond12.getFirstMillisecond(calendar16);
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = month18.getMonth();
        java.util.Date date20 = month18.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month18, (java.lang.Number) 1546329600000L);
        java.util.Date date23 = month18.getEnd();
        org.jfree.data.time.Year year24 = new org.jfree.data.time.Year(date23);
        org.jfree.data.time.TimeSeries timeSeries25 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (org.jfree.data.time.RegularTimePeriod) year24);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1561964399999L + "'", long13 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1561964399999L + "'", long15 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1561964399999L + "'", long17 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNotNull(timeSeries25);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.previous();
        long long3 = year1.getFirstMillisecond();
        long long4 = year1.getFirstMillisecond();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month(9, year1);
        org.jfree.data.general.SeriesChangeInfo seriesChangeInfo6 = null;
        org.jfree.data.event.SeriesChangeEvent seriesChangeEvent7 = new org.jfree.data.event.SeriesChangeEvent((java.lang.Object) month5, seriesChangeInfo6);
        java.util.Calendar calendar8 = null;
        try {
            month5.peg(calendar8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        int int6 = timeSeries3.getItemCount();
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        int int8 = month7.getMonth();
        java.util.Date date9 = month7.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month7, (java.lang.Number) 1546329600000L);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = month7.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries3.getDataItem(regularTimePeriod12);
        double double14 = timeSeries3.getMinY();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 6 + "'", int8 == 6);
        org.junit.Assert.assertNotNull(date9);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        org.jfree.data.time.Year year6 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod7 = year6.previous();
        java.util.Date date8 = year6.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        int int11 = day9.compareTo((java.lang.Object) 10);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        long long13 = month12.getFirstMillisecond();
        long long14 = month12.getSerialIndex();
        long long15 = month12.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) day9, (org.jfree.data.time.RegularTimePeriod) month12);
        org.junit.Assert.assertNotNull(regularTimePeriod7);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1559372400000L + "'", long13 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 24234L + "'", long15 == 24234L);
        org.junit.Assert.assertNotNull(timeSeries16);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getFirstMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 1.0d);
        try {
            timeSeries3.update(7, (java.lang.Number) 3L);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 7, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        long long5 = timeSeries3.getMaximumItemAge();
        java.lang.String str6 = timeSeries3.getDomainDescription();
        double double7 = timeSeries3.getMinY();
        timeSeries3.setDomainDescription("org.jfree.data.general.SeriesException: Overwritten values from: hi!");
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 9223372036854775807L + "'", long5 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        int int4 = day3.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day3.previous();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month6, (java.lang.Number) (-1.0f));
        boolean boolean10 = timeSeriesDataItem9.isSelected();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        java.util.Date date13 = month11.getEnd();
        org.jfree.data.time.Year year14 = new org.jfree.data.time.Year(date13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month(date13);
        int int16 = month15.getMonth();
        boolean boolean17 = timeSeriesDataItem9.equals((java.lang.Object) month15);
        int int18 = day3.compareTo((java.lang.Object) boolean17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        int int20 = month19.getMonth();
        java.util.Date date21 = month19.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.FixedMillisecond fixedMillisecond24 = new org.jfree.data.time.FixedMillisecond(date21);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod25 = fixedMillisecond24.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = fixedMillisecond24.next();
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.Object obj31 = null;
        boolean boolean32 = timeSeries30.equals(obj31);
        double double33 = timeSeries30.getMaxY();
        int int34 = fixedMillisecond24.compareTo((java.lang.Object) double33);
        int int35 = day3.compareTo((java.lang.Object) double33);
        long long36 = day3.getMiddleMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem38 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day3, (java.lang.Number) 0);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = timeSeriesDataItem38.getPeriod();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2019 + "'", int4 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertNotNull(date13);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertEquals((double) double33, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1561921199999L + "'", long36 == 1561921199999L);
        org.junit.Assert.assertNotNull(regularTimePeriod39);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        int int10 = timeSeries3.getIndex(regularTimePeriod9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries3.addChangeListener(seriesChangeListener11);
        timeSeries3.removeAgedItems(false);
        timeSeries3.setMaximumItemAge((long) 5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str14 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(timeSeriesDataItem28);
        boolean boolean30 = timeSeries3.equals((java.lang.Object) timeSeries13);
        org.jfree.data.time.Month month31 = new org.jfree.data.time.Month();
        int int32 = month31.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month31, (java.lang.Number) (-1.0f));
        java.lang.Number number35 = timeSeries13.getValue((org.jfree.data.time.RegularTimePeriod) month31);
        timeSeries13.clear();
        org.jfree.data.time.Month month37 = new org.jfree.data.time.Month();
        int int38 = month37.getMonth();
        java.util.Date date39 = month37.getEnd();
        org.jfree.data.time.Day day40 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.Day day41 = new org.jfree.data.time.Day(date39);
        org.jfree.data.time.FixedMillisecond fixedMillisecond42 = new org.jfree.data.time.FixedMillisecond(date39);
        long long43 = fixedMillisecond42.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener48 = null;
        timeSeries47.removeChangeListener(seriesChangeListener48);
        boolean boolean50 = timeSeries47.getNotify();
        org.jfree.data.time.Year year52 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod53 = year52.next();
        int int54 = timeSeries47.getIndex(regularTimePeriod53);
        int int55 = fixedMillisecond42.compareTo((java.lang.Object) regularTimePeriod53);
        java.util.Date date56 = fixedMillisecond42.getTime();
        org.jfree.data.time.Day day57 = new org.jfree.data.time.Day(date56);
        long long58 = day57.getFirstMillisecond();
        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month();
        int int60 = month59.getMonth();
        java.util.Date date61 = month59.getEnd();
        org.jfree.data.time.Day day62 = new org.jfree.data.time.Day(date61);
        org.jfree.data.time.Day day63 = new org.jfree.data.time.Day(date61);
        org.jfree.data.time.FixedMillisecond fixedMillisecond64 = new org.jfree.data.time.FixedMillisecond(date61);
        long long65 = fixedMillisecond64.getFirstMillisecond();
        long long66 = fixedMillisecond64.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries67 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) day57, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond64);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 6 + "'", int32 == 6);
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 2.0d + "'", number35.equals(2.0d));
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertNotNull(date39);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1561964399999L + "'", long43 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1561878000000L + "'", long58 == 1561878000000L);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 6 + "'", int60 == 6);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + long65 + "' != '" + 1561964399999L + "'", long65 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long66 + "' != '" + 1561964399999L + "'", long66 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries67);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        int int13 = month12.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month12, (java.lang.Number) (-1.0f));
        boolean boolean16 = timeSeriesDataItem3.equals((java.lang.Object) timeSeriesDataItem15);
        timeSeriesDataItem15.setSelected(true);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        int int20 = month19.getMonth();
        java.util.Date date21 = month19.getEnd();
        org.jfree.data.time.Day day22 = new org.jfree.data.time.Day(date21);
        org.jfree.data.time.SerialDate serialDate23 = day22.getSerialDate();
        long long24 = day22.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        int int30 = month29.getMonth();
        java.util.Date date31 = month29.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) day32, (java.lang.Number) 2019, false);
        int int36 = day22.compareTo((java.lang.Object) timeSeries28);
        java.beans.PropertyChangeListener propertyChangeListener37 = null;
        timeSeries28.removePropertyChangeListener(propertyChangeListener37);
        java.lang.Class class39 = timeSeries28.getTimePeriodClass();
        org.jfree.data.time.Month month40 = new org.jfree.data.time.Month();
        int int41 = month40.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month40, (java.lang.Number) (-1.0f));
        boolean boolean44 = timeSeriesDataItem43.isSelected();
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month();
        int int46 = month45.getMonth();
        java.util.Date date47 = month45.getEnd();
        org.jfree.data.time.Year year48 = new org.jfree.data.time.Year(date47);
        org.jfree.data.time.Month month49 = new org.jfree.data.time.Month(date47);
        int int50 = month49.getMonth();
        boolean boolean51 = timeSeriesDataItem43.equals((java.lang.Object) month49);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month49, (double) 2);
        org.jfree.data.time.Year year54 = month49.getYear();
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener59 = null;
        timeSeries58.removeChangeListener(seriesChangeListener59);
        boolean boolean61 = timeSeries58.getNotify();
        timeSeries58.setRangeDescription("hi!");
        double double64 = timeSeries58.getMinY();
        timeSeries58.setMaximumItemAge((long) ' ');
        java.util.List list67 = timeSeries58.getItems();
        boolean boolean68 = month49.equals((java.lang.Object) timeSeries58);
        org.jfree.data.time.Month month69 = new org.jfree.data.time.Month();
        int int70 = month69.getMonth();
        java.util.Date date71 = month69.getEnd();
        org.jfree.data.time.Day day72 = new org.jfree.data.time.Day(date71);
        int int73 = day72.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod74 = day72.previous();
        int int75 = day72.getMonth();
        timeSeries58.add((org.jfree.data.time.RegularTimePeriod) day72, (double) 0L);
        org.jfree.data.time.TimeSeries timeSeries81 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month82 = new org.jfree.data.time.Month();
        int int83 = month82.getMonth();
        java.util.Date date84 = month82.getEnd();
        org.jfree.data.time.Day day85 = new org.jfree.data.time.Day(date84);
        timeSeries81.add((org.jfree.data.time.RegularTimePeriod) day85, (java.lang.Number) 2019, false);
        long long89 = day85.getSerialIndex();
        int int90 = day85.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem92 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day85, (java.lang.Number) 9999);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem93 = timeSeries58.addOrUpdate(timeSeriesDataItem92);
        timeSeries28.setKey((java.lang.Comparable) timeSeriesDataItem93);
        int int95 = timeSeriesDataItem15.compareTo((java.lang.Object) timeSeries28);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1 + "'", int36 == 1);
        org.junit.Assert.assertNotNull(class39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 6 + "'", int41 == 6);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 6 + "'", int46 == 6);
        org.junit.Assert.assertNotNull(date47);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 6 + "'", int50 == 6);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(year54);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertEquals((double) double64, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 6 + "'", int70 == 6);
        org.junit.Assert.assertNotNull(date71);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2019 + "'", int73 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod74);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 6 + "'", int75 == 6);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 6 + "'", int83 == 6);
        org.junit.Assert.assertNotNull(date84);
        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 43646L + "'", long89 == 43646L);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 2019 + "'", int90 == 2019);
        org.junit.Assert.assertNotNull(timeSeriesDataItem93);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 1 + "'", int95 == 1);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getFirstMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 1.0d);
        org.jfree.data.time.Month month12 = new org.jfree.data.time.Month();
        int int13 = month12.getMonth();
        java.util.Date date14 = month12.getEnd();
        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date14);
        org.jfree.data.time.FixedMillisecond fixedMillisecond17 = new org.jfree.data.time.FixedMillisecond(date14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = fixedMillisecond17.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond17.next();
        java.lang.Class<?> wildcardClass20 = regularTimePeriod19.getClass();
        org.jfree.data.time.Month month21 = new org.jfree.data.time.Month();
        int int22 = month21.getMonth();
        java.util.Date date23 = month21.getEnd();
        org.jfree.data.time.Day day24 = new org.jfree.data.time.Day(date23);
        java.util.TimeZone timeZone25 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass20, date23, timeZone25);
        org.jfree.data.time.Day day27 = new org.jfree.data.time.Day(date23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) day27);
        java.util.List list29 = timeSeries3.getItems();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 6 + "'", int13 == 6);
        org.junit.Assert.assertNotNull(date14);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 6 + "'", int22 == 6);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertNull(regularTimePeriod26);
        org.junit.Assert.assertNotNull(timeSeriesDataItem28);
        org.junit.Assert.assertNotNull(list29);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        java.util.Date date6 = month4.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 2019, false);
        long long11 = day7.getSerialIndex();
        int int12 = day7.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 9999);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day7.previous();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43646L + "'", long11 == 43646L);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.removeChangeListener(seriesChangeListener11);
        boolean boolean13 = timeSeries10.getNotify();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        int int17 = timeSeries10.getIndex(regularTimePeriod16);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries10.addChangeListener(seriesChangeListener18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener20);
        int int22 = fixedMillisecond5.compareTo((java.lang.Object) propertyChangeListener20);
        long long23 = fixedMillisecond5.getMiddleMillisecond();
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month();
        int int25 = month24.getMonth();
        org.jfree.data.time.Year year26 = month24.getYear();
        boolean boolean27 = fixedMillisecond5.equals((java.lang.Object) year26);
        java.util.Calendar calendar28 = null;
        long long29 = fixedMillisecond5.getMiddleMillisecond(calendar28);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 1561964399999L + "'", long23 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertNotNull(year26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1561964399999L + "'", long29 == 1561964399999L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
        java.lang.String str14 = year13.toString();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) year13);
        java.lang.String str16 = year13.toString();
        java.lang.String str17 = year13.toString();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "2019" + "'", str14.equals("2019"));
        org.junit.Assert.assertNull(timeSeriesDataItem15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "2019" + "'", str16.equals("2019"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "2019" + "'", str17.equals("2019"));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(2L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year((-9999));
        java.lang.String str2 = year1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "-9999" + "'", str2.equals("-9999"));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 2019, false);
        int int17 = day3.compareTo((java.lang.Object) timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener18);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries9.addChangeListener(seriesChangeListener20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        int int23 = month22.getMonth();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        int int26 = day25.getYear();
        long long27 = day25.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) 1.0f);
        java.lang.Object obj30 = timeSeries9.clone();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = year31.previous();
        long long33 = year31.getFirstMillisecond();
        long long34 = year31.getFirstMillisecond();
        java.lang.String str35 = year31.toString();
        long long36 = year31.getFirstMillisecond();
        timeSeries9.update((org.jfree.data.time.RegularTimePeriod) year31, (java.lang.Number) 100.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43646L + "'", long27 == 43646L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertNotNull(regularTimePeriod32);
        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1546329600000L + "'", long33 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1546329600000L + "'", long34 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "2019" + "'", str35.equals("2019"));
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1546329600000L + "'", long36 == 1546329600000L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = year8.next();
        int int10 = timeSeries3.getIndex(regularTimePeriod9);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries3.addChangeListener(seriesChangeListener11);
        timeSeries3.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries16 = timeSeries3.createCopy(6, 9999);
        java.lang.String str17 = timeSeries16.getDescription();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(timeSeries16);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        int int8 = fixedMillisecond5.compareTo((java.lang.Object) 2147483647);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = fixedMillisecond5.next();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(regularTimePeriod9);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        java.lang.Number number12 = timeSeriesDataItem3.getValue();
        java.lang.Number number13 = timeSeriesDataItem3.getValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-1.0f) + "'", number12.equals((-1.0f)));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + (-1.0f) + "'", number13.equals((-1.0f)));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 2019, false);
        int int17 = day3.compareTo((java.lang.Object) timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener18);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener20 = null;
        timeSeries9.addChangeListener(seriesChangeListener20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month();
        int int23 = month22.getMonth();
        java.util.Date date24 = month22.getEnd();
        org.jfree.data.time.Day day25 = new org.jfree.data.time.Day(date24);
        int int26 = day25.getYear();
        long long27 = day25.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day25, (java.lang.Number) 1.0f);
        long long30 = timeSeries9.getMaximumItemAge();
        try {
            timeSeries9.delete((int) 'a', (int) (short) 1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires start <= end.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2019 + "'", int26 == 2019);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 43646L + "'", long27 == 43646L);
        org.junit.Assert.assertNotNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 9223372036854775807L + "'", long30 == 9223372036854775807L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        long long2 = year0.getFirstMillisecond();
        long long3 = year0.getFirstMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year0.previous();
        long long5 = year0.getLastMillisecond();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = year0.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1546329600000L + "'", long2 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1546329600000L + "'", long3 == 1546329600000L);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1577865599999L + "'", long5 == 1577865599999L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setNotify(true);
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener13 = null;
        timeSeries12.removeChangeListener(seriesChangeListener13);
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17);
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond(date17);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod21 = fixedMillisecond20.next();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries12.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries3.getDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20);
        try {
            timeSeries3.update(3, (java.lang.Number) 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 3, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNotNull(regularTimePeriod21);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 2019, false);
        int int17 = day3.compareTo((java.lang.Object) timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries23.removeChangeListener(seriesChangeListener24);
        timeSeries23.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        long long29 = month28.getFirstMillisecond();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 1.0d);
        int int32 = timeSeries23.getItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int34 = month33.getMonth();
        java.util.Date date35 = month33.getEnd();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date35);
        long long39 = fixedMillisecond38.getMiddleMillisecond();
        timeSeries23.setKey((java.lang.Comparable) long39);
        java.util.Collection collection41 = timeSeries23.getTimePeriods();
        java.util.Collection collection42 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        boolean boolean43 = timeSeries23.getNotify();
        try {
            org.jfree.data.time.TimeSeries timeSeries46 = timeSeries23.createCopy(12, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 12, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1559372400000L + "'", long29 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1561964399999L + "'", long39 == 1561964399999L);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond(date2);
        long long6 = fixedMillisecond5.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries10 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener11 = null;
        timeSeries10.removeChangeListener(seriesChangeListener11);
        boolean boolean13 = timeSeries10.getNotify();
        org.jfree.data.time.Year year15 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod16 = year15.next();
        int int17 = timeSeries10.getIndex(regularTimePeriod16);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries10.addChangeListener(seriesChangeListener18);
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries10.addPropertyChangeListener(propertyChangeListener20);
        int int22 = fixedMillisecond5.compareTo((java.lang.Object) propertyChangeListener20);
        java.util.Calendar calendar23 = null;
        long long24 = fixedMillisecond5.getMiddleMillisecond(calendar23);
        long long25 = fixedMillisecond5.getFirstMillisecond();
        java.util.Calendar calendar26 = null;
        long long27 = fixedMillisecond5.getMiddleMillisecond(calendar26);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 1561964399999L + "'", long6 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 1561964399999L + "'", long24 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long25 + "' != '" + 1561964399999L + "'", long25 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1561964399999L + "'", long27 == 1561964399999L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month9, (double) 2);
        java.lang.Class<?> wildcardClass14 = month9.getClass();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day(date17);
        java.util.TimeZone timeZone19 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass14, date17, timeZone19);
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date17);
        java.util.Calendar calendar22 = null;
        try {
            long long23 = year21.getFirstMillisecond(calendar22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertNull(regularTimePeriod20);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str14 = timeSeries13.getDomainDescription();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem18 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month15, (java.lang.Number) (-1.0f));
        boolean boolean19 = timeSeriesDataItem18.isSelected();
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month();
        int int21 = month20.getMonth();
        java.util.Date date22 = month20.getEnd();
        org.jfree.data.time.Year year23 = new org.jfree.data.time.Year(date22);
        org.jfree.data.time.Month month24 = new org.jfree.data.time.Month(date22);
        int int25 = month24.getMonth();
        boolean boolean26 = timeSeriesDataItem18.equals((java.lang.Object) month24);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month24, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = timeSeries13.addOrUpdate(timeSeriesDataItem28);
        boolean boolean30 = timeSeries3.equals((java.lang.Object) timeSeries13);
        timeSeries13.setMaximumItemAge(0L);
        java.lang.String str33 = timeSeries13.getDomainDescription();
        int int34 = timeSeries13.getMaximumItemCount();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertNotNull(date22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 6 + "'", int25 == 6);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "" + "'", str33.equals(""));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 2147483647 + "'", int34 == 2147483647);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod4 = year3.previous();
        java.lang.String str5 = year3.toString();
        org.jfree.data.time.Month month6 = new org.jfree.data.time.Month();
        int int7 = month6.getMonth();
        java.util.Date date8 = month6.getEnd();
        org.jfree.data.time.Day day9 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.Day day10 = new org.jfree.data.time.Day(date8);
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond(date8);
        long long12 = fixedMillisecond11.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener17 = null;
        timeSeries16.removeChangeListener(seriesChangeListener17);
        boolean boolean19 = timeSeries16.getNotify();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = year21.next();
        int int23 = timeSeries16.getIndex(regularTimePeriod22);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries16.addChangeListener(seriesChangeListener24);
        java.beans.PropertyChangeListener propertyChangeListener26 = null;
        timeSeries16.addPropertyChangeListener(propertyChangeListener26);
        int int28 = fixedMillisecond11.compareTo((java.lang.Object) propertyChangeListener26);
        long long29 = fixedMillisecond11.getMiddleMillisecond();
        org.jfree.data.time.Month month30 = new org.jfree.data.time.Month();
        int int31 = month30.getMonth();
        org.jfree.data.time.Year year32 = month30.getYear();
        boolean boolean33 = fixedMillisecond11.equals((java.lang.Object) year32);
        boolean boolean34 = year3.equals((java.lang.Object) year32);
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        int int36 = month35.getMonth();
        java.util.Date date37 = month35.getEnd();
        org.jfree.data.time.Day day38 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.Day day39 = new org.jfree.data.time.Day(date37);
        org.jfree.data.time.FixedMillisecond fixedMillisecond40 = new org.jfree.data.time.FixedMillisecond(date37);
        int int42 = fixedMillisecond40.compareTo((java.lang.Object) 6);
        long long43 = fixedMillisecond40.getMiddleMillisecond();
        boolean boolean44 = year3.equals((java.lang.Object) long43);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(regularTimePeriod4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "2019" + "'", str5.equals("2019"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertNotNull(date8);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1561964399999L + "'", long12 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1561964399999L + "'", long29 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 6 + "'", int31 == 6);
        org.junit.Assert.assertNotNull(year32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 6 + "'", int36 == 6);
        org.junit.Assert.assertNotNull(date37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1 + "'", int42 == 1);
        org.junit.Assert.assertTrue("'" + long43 + "' != '" + 1561964399999L + "'", long43 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        java.util.Calendar calendar4 = null;
        fixedMillisecond1.peg(calendar4);
        java.util.Calendar calendar6 = null;
        long long7 = fixedMillisecond1.getFirstMillisecond(calendar6);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        int int9 = month8.getMonth();
        java.util.Date date10 = month8.getEnd();
        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.Day day12 = new org.jfree.data.time.Day(date10);
        org.jfree.data.time.FixedMillisecond fixedMillisecond13 = new org.jfree.data.time.FixedMillisecond(date10);
        long long14 = fixedMillisecond13.getMiddleMillisecond();
        java.util.Calendar calendar15 = null;
        long long16 = fixedMillisecond13.getLastMillisecond(calendar15);
        java.util.Calendar calendar17 = null;
        long long18 = fixedMillisecond13.getFirstMillisecond(calendar17);
        int int19 = fixedMillisecond1.compareTo((java.lang.Object) long18);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1L + "'", long7 == 1L);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 6 + "'", int9 == 6);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 1561964399999L + "'", long14 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 1561964399999L + "'", long16 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setNotify(true);
        java.lang.Class class8 = timeSeries3.getTimePeriodClass();
        org.jfree.data.event.SeriesChangeListener seriesChangeListener9 = null;
        timeSeries3.addChangeListener(seriesChangeListener9);
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener15 = null;
        timeSeries14.removeChangeListener(seriesChangeListener15);
        timeSeries14.setNotify(true);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        int int20 = month19.getMonth();
        java.util.Date date21 = month19.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (java.lang.Number) 1546329600000L);
        timeSeries14.add(timeSeriesDataItem23, true);
        org.jfree.data.time.TimeSeries timeSeries26 = timeSeries3.addAndOrUpdate(timeSeries14);
        int int27 = timeSeries3.getMaximumItemCount();
        org.jfree.data.time.TimeSeries timeSeries31 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        int int33 = month32.getMonth();
        java.util.Date date34 = month32.getEnd();
        org.jfree.data.time.Day day35 = new org.jfree.data.time.Day(date34);
        timeSeries31.add((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 2019, false);
        long long39 = day35.getSerialIndex();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) 8);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = day35.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = day35.next();
        try {
            timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day35, (java.lang.Number) (-9999));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Day, but the TimeSeries is expecting an instance of org.jfree.data.time.Month.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(class8);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(timeSeries26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 2147483647 + "'", int27 == 2147483647);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
        org.junit.Assert.assertNotNull(date34);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 43646L + "'", long39 == 43646L);
        org.junit.Assert.assertNotNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getFirstMillisecond(calendar2);
        java.lang.String str4 = fixedMillisecond1.toString();
        long long5 = fixedMillisecond1.getFirstMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str4.equals("Wed Dec 31 16:00:00 PST 1969"));
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = year0.previous();
        java.util.Date date2 = year0.getEnd();
        int int3 = year0.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem5 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year0, (java.lang.Number) 2L);
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str10 = timeSeries9.getDomainDescription();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month();
        int int12 = month11.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month11, (java.lang.Number) (-1.0f));
        boolean boolean15 = timeSeriesDataItem14.isSelected();
        org.jfree.data.time.Month month16 = new org.jfree.data.time.Month();
        int int17 = month16.getMonth();
        java.util.Date date18 = month16.getEnd();
        org.jfree.data.time.Year year19 = new org.jfree.data.time.Year(date18);
        org.jfree.data.time.Month month20 = new org.jfree.data.time.Month(date18);
        int int21 = month20.getMonth();
        boolean boolean22 = timeSeriesDataItem14.equals((java.lang.Object) month20);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month20, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries9.addOrUpdate(timeSeriesDataItem24);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod26 = timeSeries9.getNextTimePeriod();
        int int27 = timeSeriesDataItem5.compareTo((java.lang.Object) regularTimePeriod26);
        org.junit.Assert.assertNotNull(regularTimePeriod1);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 2019 + "'", int3 == 2019);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 6 + "'", int12 == 6);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 6 + "'", int17 == 6);
        org.junit.Assert.assertNotNull(date18);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 6 + "'", int21 == 6);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem25);
        org.junit.Assert.assertNotNull(regularTimePeriod26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 1 + "'", int27 == 1);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        java.lang.Class class6 = timeSeries3.getTimePeriodClass();
        java.lang.Object obj7 = timeSeries3.clone();
        org.junit.Assert.assertNull(class6);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.Year year5 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 2019, false);
        int int17 = day3.compareTo((java.lang.Object) timeSeries9);
        int int18 = day3.getYear();
        java.lang.String str19 = day3.toString();
        int int20 = day3.getDayOfMonth();
        int int21 = day3.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2019 + "'", int18 == 2019);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "30-June-2019" + "'", str19.equals("30-June-2019"));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 30 + "'", int20 == 30);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 30 + "'", int21 == 30);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str4 = timeSeries3.getDomainDescription();
        boolean boolean5 = timeSeries3.getNotify();
        org.jfree.data.time.Year year7 = new org.jfree.data.time.Year(0);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year7, (java.lang.Number) 24234L);
        boolean boolean10 = timeSeries3.equals((java.lang.Object) 24234L);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = year11.previous();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date15);
        long long19 = fixedMillisecond18.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries23.removeChangeListener(seriesChangeListener24);
        boolean boolean26 = timeSeries23.getNotify();
        org.jfree.data.time.Year year28 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod29 = year28.next();
        int int30 = timeSeries23.getIndex(regularTimePeriod29);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener31 = null;
        timeSeries23.addChangeListener(seriesChangeListener31);
        java.beans.PropertyChangeListener propertyChangeListener33 = null;
        timeSeries23.addPropertyChangeListener(propertyChangeListener33);
        int int35 = fixedMillisecond18.compareTo((java.lang.Object) propertyChangeListener33);
        long long36 = fixedMillisecond18.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries37 = timeSeries3.createCopy(regularTimePeriod12, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond18);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = fixedMillisecond18.previous();
        java.util.Calendar calendar39 = null;
        long long40 = fixedMillisecond18.getLastMillisecond(calendar39);
        long long41 = fixedMillisecond18.getSerialIndex();
        org.jfree.data.time.Month month42 = new org.jfree.data.time.Month();
        int int43 = month42.getMonth();
        java.util.Date date44 = month42.getEnd();
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day(date44);
        org.jfree.data.time.Day day46 = new org.jfree.data.time.Day(date44);
        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond(date44);
        long long48 = fixedMillisecond47.getMiddleMillisecond();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod49 = fixedMillisecond47.previous();
        java.lang.Class<?> wildcardClass50 = fixedMillisecond47.getClass();
        int int51 = fixedMillisecond18.compareTo((java.lang.Object) wildcardClass50);
        java.util.Date date52 = fixedMillisecond18.getEnd();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1561964399999L + "'", long36 == 1561964399999L);
        org.junit.Assert.assertNotNull(timeSeries37);
        org.junit.Assert.assertNotNull(regularTimePeriod38);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1561964399999L + "'", long40 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long41 + "' != '" + 1561964399999L + "'", long41 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 6 + "'", int43 == 6);
        org.junit.Assert.assertNotNull(date44);
        org.junit.Assert.assertTrue("'" + long48 + "' != '" + 1561964399999L + "'", long48 == 1561964399999L);
        org.junit.Assert.assertNotNull(regularTimePeriod49);
        org.junit.Assert.assertNotNull(wildcardClass50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertNotNull(date52);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = month0.previous();
        long long3 = regularTimePeriod2.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1558033199999L + "'", long3 == 1558033199999L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.data.time.Year year1 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod2 = year1.next();
        org.jfree.data.time.Month month3 = new org.jfree.data.time.Month();
        int int4 = month3.getMonth();
        java.util.Date date5 = month3.getEnd();
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(date5);
        org.jfree.data.time.SerialDate serialDate7 = day6.getSerialDate();
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str12 = timeSeries11.getDomainDescription();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (-1.0f));
        boolean boolean17 = timeSeriesDataItem16.isSelected();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = month18.getMonth();
        java.util.Date date20 = month18.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        int int23 = month22.getMonth();
        boolean boolean24 = timeSeriesDataItem16.equals((java.lang.Object) month22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries11.addOrUpdate(timeSeriesDataItem26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        int int29 = month28.getMonth();
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.Day day31 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date30);
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month(date30);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries11.getDataItem((org.jfree.data.time.RegularTimePeriod) month33);
        java.lang.Number number35 = null;
        timeSeriesDataItem34.setValue(number35);
        boolean boolean37 = day6.equals((java.lang.Object) timeSeriesDataItem34);
        int int38 = day6.getMonth();
        boolean boolean39 = year1.equals((java.lang.Object) int38);
        java.util.Calendar calendar40 = null;
        try {
            long long41 = year1.getFirstMillisecond(calendar40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(regularTimePeriod2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
        org.junit.Assert.assertNotNull(date5);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertNotNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 6 + "'", int38 == 6);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        org.jfree.data.time.Year year3 = month0.getYear();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertNotNull(year3);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        int int12 = month9.getYearValue();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        int int17 = day16.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day16.previous();
        long long19 = day16.getLastMillisecond();
        boolean boolean20 = month9.equals((java.lang.Object) day16);
        java.util.Date date21 = month9.getStart();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month9.next();
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        int int24 = month23.getMonth();
        java.util.Date date25 = month23.getEnd();
        org.jfree.data.time.Year year26 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod27 = year26.previous();
        java.lang.String str28 = year26.toString();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        int int30 = month29.getMonth();
        java.util.Date date31 = month29.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.Day day33 = new org.jfree.data.time.Day(date31);
        org.jfree.data.time.FixedMillisecond fixedMillisecond34 = new org.jfree.data.time.FixedMillisecond(date31);
        long long35 = fixedMillisecond34.getMiddleMillisecond();
        org.jfree.data.time.TimeSeries timeSeries39 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener40 = null;
        timeSeries39.removeChangeListener(seriesChangeListener40);
        boolean boolean42 = timeSeries39.getNotify();
        org.jfree.data.time.Year year44 = new org.jfree.data.time.Year(2019);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod45 = year44.next();
        int int46 = timeSeries39.getIndex(regularTimePeriod45);
        org.jfree.data.event.SeriesChangeListener seriesChangeListener47 = null;
        timeSeries39.addChangeListener(seriesChangeListener47);
        java.beans.PropertyChangeListener propertyChangeListener49 = null;
        timeSeries39.addPropertyChangeListener(propertyChangeListener49);
        int int51 = fixedMillisecond34.compareTo((java.lang.Object) propertyChangeListener49);
        long long52 = fixedMillisecond34.getMiddleMillisecond();
        org.jfree.data.time.Month month53 = new org.jfree.data.time.Month();
        int int54 = month53.getMonth();
        org.jfree.data.time.Year year55 = month53.getYear();
        boolean boolean56 = fixedMillisecond34.equals((java.lang.Object) year55);
        boolean boolean57 = year26.equals((java.lang.Object) year55);
        int int58 = month9.compareTo((java.lang.Object) year26);
        org.jfree.data.time.Month month59 = new org.jfree.data.time.Month();
        int int60 = month59.getMonth();
        java.util.Date date61 = month59.getEnd();
        org.jfree.data.time.Year year62 = new org.jfree.data.time.Year(date61);
        boolean boolean63 = year26.equals((java.lang.Object) date61);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2019 + "'", int17 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod18);
        org.junit.Assert.assertTrue("'" + long19 + "' != '" + 1561964399999L + "'", long19 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertNotNull(regularTimePeriod27);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "2019" + "'", str28.equals("2019"));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1561964399999L + "'", long35 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(regularTimePeriod45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + long52 + "' != '" + 1561964399999L + "'", long52 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 6 + "'", int54 == 6);
        org.junit.Assert.assertNotNull(year55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 6 + "'", int60 == 6);
        org.junit.Assert.assertNotNull(date61);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        boolean boolean6 = timeSeries3.getNotify();
        timeSeries3.setRangeDescription("hi!");
        double double9 = timeSeries3.getMinY();
        timeSeries3.setMaximumItemAge((long) ' ');
        java.util.List list12 = timeSeries3.getItems();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month13, (java.lang.Number) (-1.0f));
        boolean boolean17 = timeSeriesDataItem16.isSelected();
        org.jfree.data.time.Month month18 = new org.jfree.data.time.Month();
        int int19 = month18.getMonth();
        java.util.Date date20 = month18.getEnd();
        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(date20);
        org.jfree.data.time.Month month22 = new org.jfree.data.time.Month(date20);
        int int23 = month22.getMonth();
        boolean boolean24 = timeSeriesDataItem16.equals((java.lang.Object) month22);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month22, (double) 2);
        boolean boolean27 = timeSeries3.equals((java.lang.Object) month22);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertEquals((double) double9, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 6 + "'", int19 == 6);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 6 + "'", int23 == 6);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getYearValue();
        long long2 = month0.getSerialIndex();
        boolean boolean4 = month0.equals((java.lang.Object) "");
        org.jfree.data.time.Year year5 = month0.getYear();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (byte) 0);
        java.lang.Object obj8 = null;
        boolean boolean9 = timeSeriesDataItem7.equals(obj8);
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) timeSeriesDataItem7, "", "10-June-2019");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2019 + "'", int1 == 2019);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 24234L + "'", long2 == 24234L);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(year5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) 5);
        org.jfree.data.time.Day day2 = new org.jfree.data.time.Day();
        java.lang.Number number3 = timeSeries1.getValue((org.jfree.data.time.RegularTimePeriod) day2);
        org.jfree.data.time.SerialDate serialDate4 = day2.getSerialDate();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate4);
        org.jfree.data.time.Day day6 = new org.jfree.data.time.Day(serialDate4);
        org.junit.Assert.assertNull(number3);
        org.junit.Assert.assertNotNull(serialDate4);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        java.lang.String str4 = year3.toString();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = year3.previous();
        java.lang.Object obj6 = null;
        int int7 = year3.compareTo(obj6);
        java.lang.Number number8 = null;
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) year3, number8);
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month10, (java.lang.Number) (-1.0f));
        boolean boolean14 = timeSeriesDataItem13.isSelected();
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        int int16 = month15.getMonth();
        java.util.Date date17 = month15.getEnd();
        org.jfree.data.time.Year year18 = new org.jfree.data.time.Year(date17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date17);
        int int20 = month19.getMonth();
        boolean boolean21 = timeSeriesDataItem13.equals((java.lang.Object) month19);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month19, (double) 2);
        org.jfree.data.time.Year year24 = month19.getYear();
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener29 = null;
        timeSeries28.removeChangeListener(seriesChangeListener29);
        boolean boolean31 = timeSeries28.getNotify();
        timeSeries28.setRangeDescription("hi!");
        double double34 = timeSeries28.getMinY();
        timeSeries28.setMaximumItemAge((long) ' ');
        java.util.List list37 = timeSeries28.getItems();
        boolean boolean38 = month19.equals((java.lang.Object) timeSeries28);
        org.jfree.data.time.Month month39 = new org.jfree.data.time.Month();
        int int40 = month39.getMonth();
        java.util.Date date41 = month39.getEnd();
        org.jfree.data.time.Day day42 = new org.jfree.data.time.Day(date41);
        int int43 = day42.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = day42.previous();
        int int45 = day42.getMonth();
        timeSeries28.add((org.jfree.data.time.RegularTimePeriod) day42, (double) 0L);
        timeSeries28.removeAgedItems(0L, false);
        org.jfree.data.time.TimeSeries timeSeries54 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener55 = null;
        timeSeries54.removeChangeListener(seriesChangeListener55);
        boolean boolean57 = timeSeries54.getNotify();
        timeSeries54.setRangeDescription("hi!");
        double double60 = timeSeries54.getMinY();
        org.jfree.data.time.TimeSeries timeSeries64 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        java.lang.String str65 = timeSeries64.getDomainDescription();
        org.jfree.data.time.Month month66 = new org.jfree.data.time.Month();
        int int67 = month66.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem69 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month66, (java.lang.Number) (-1.0f));
        boolean boolean70 = timeSeriesDataItem69.isSelected();
        org.jfree.data.time.Month month71 = new org.jfree.data.time.Month();
        int int72 = month71.getMonth();
        java.util.Date date73 = month71.getEnd();
        org.jfree.data.time.Year year74 = new org.jfree.data.time.Year(date73);
        org.jfree.data.time.Month month75 = new org.jfree.data.time.Month(date73);
        int int76 = month75.getMonth();
        boolean boolean77 = timeSeriesDataItem69.equals((java.lang.Object) month75);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month75, (double) 2);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem80 = timeSeries64.addOrUpdate(timeSeriesDataItem79);
        boolean boolean81 = timeSeries54.equals((java.lang.Object) timeSeries64);
        org.jfree.data.time.Month month82 = new org.jfree.data.time.Month();
        int int83 = month82.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month82, (java.lang.Number) (-1.0f));
        java.lang.Number number86 = timeSeries64.getValue((org.jfree.data.time.RegularTimePeriod) month82);
        timeSeries64.clear();
        timeSeries64.setDescription("30-June-2019");
        org.jfree.data.time.TimeSeries timeSeries90 = timeSeries28.addAndOrUpdate(timeSeries64);
        boolean boolean91 = timeSeriesDataItem9.equals((java.lang.Object) timeSeries90);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "2019" + "'", str4.equals("2019"));
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 6 + "'", int16 == 6);
        org.junit.Assert.assertNotNull(date17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(year24);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertEquals((double) double34, Double.NaN, 0);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 6 + "'", int40 == 6);
        org.junit.Assert.assertNotNull(date41);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 2019 + "'", int43 == 2019);
        org.junit.Assert.assertNotNull(regularTimePeriod44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 6 + "'", int45 == 6);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertEquals((double) double60, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "" + "'", str65.equals(""));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 6 + "'", int67 == 6);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 6 + "'", int72 == 6);
        org.junit.Assert.assertNotNull(date73);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 6 + "'", int76 == 6);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 6 + "'", int83 == 6);
        org.junit.Assert.assertTrue("'" + number86 + "' != '" + 2.0d + "'", number86.equals(2.0d));
        org.junit.Assert.assertNotNull(timeSeries90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
        long long5 = day3.getLastMillisecond();
        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month();
        int int11 = month10.getMonth();
        java.util.Date date12 = month10.getEnd();
        org.jfree.data.time.Day day13 = new org.jfree.data.time.Day(date12);
        timeSeries9.add((org.jfree.data.time.RegularTimePeriod) day13, (java.lang.Number) 2019, false);
        int int17 = day3.compareTo((java.lang.Object) timeSeries9);
        java.beans.PropertyChangeListener propertyChangeListener18 = null;
        timeSeries9.removePropertyChangeListener(propertyChangeListener18);
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener24 = null;
        timeSeries23.removeChangeListener(seriesChangeListener24);
        timeSeries23.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        long long29 = month28.getFirstMillisecond();
        timeSeries23.add((org.jfree.data.time.RegularTimePeriod) month28, (java.lang.Number) 1.0d);
        int int32 = timeSeries23.getItemCount();
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        int int34 = month33.getMonth();
        java.util.Date date35 = month33.getEnd();
        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date35);
        org.jfree.data.time.FixedMillisecond fixedMillisecond38 = new org.jfree.data.time.FixedMillisecond(date35);
        long long39 = fixedMillisecond38.getMiddleMillisecond();
        timeSeries23.setKey((java.lang.Comparable) long39);
        java.util.Collection collection41 = timeSeries23.getTimePeriods();
        java.util.Collection collection42 = timeSeries9.getTimePeriodsUniqueToOtherSeries(timeSeries23);
        boolean boolean43 = timeSeries23.getNotify();
        double double44 = timeSeries23.getMinY();
        java.lang.Class class45 = timeSeries23.getTimePeriodClass();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1561964399999L + "'", long5 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 6 + "'", int11 == 6);
        org.junit.Assert.assertNotNull(date12);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1559372400000L + "'", long29 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 6 + "'", int34 == 6);
        org.junit.Assert.assertNotNull(date35);
        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1561964399999L + "'", long39 == 1561964399999L);
        org.junit.Assert.assertNotNull(collection41);
        org.junit.Assert.assertNotNull(collection42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
        org.junit.Assert.assertNotNull(class45);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem3 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month0, (java.lang.Number) (-1.0f));
        boolean boolean4 = timeSeriesDataItem3.isSelected();
        org.jfree.data.time.Month month5 = new org.jfree.data.time.Month();
        int int6 = month5.getMonth();
        java.util.Date date7 = month5.getEnd();
        org.jfree.data.time.Year year8 = new org.jfree.data.time.Year(date7);
        org.jfree.data.time.Month month9 = new org.jfree.data.time.Month(date7);
        int int10 = month9.getMonth();
        boolean boolean11 = timeSeriesDataItem3.equals((java.lang.Object) month9);
        int int12 = month9.getYearValue();
        long long13 = month9.getFirstMillisecond();
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        int int15 = month14.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month14, (java.lang.Number) (-1.0f));
        boolean boolean18 = timeSeriesDataItem17.isSelected();
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month();
        int int20 = month19.getMonth();
        java.util.Date date21 = month19.getEnd();
        org.jfree.data.time.Year year22 = new org.jfree.data.time.Year(date21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month(date21);
        int int24 = month23.getMonth();
        boolean boolean25 = timeSeriesDataItem17.equals((java.lang.Object) month23);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month23, (double) 2);
        java.lang.Class<?> wildcardClass28 = month23.getClass();
        org.jfree.data.time.Month month29 = new org.jfree.data.time.Month();
        int int30 = month29.getMonth();
        java.util.Date date31 = month29.getEnd();
        org.jfree.data.time.Day day32 = new org.jfree.data.time.Day(date31);
        java.util.TimeZone timeZone33 = null;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = org.jfree.data.time.RegularTimePeriod.createInstance((java.lang.Class) wildcardClass28, date31, timeZone33);
        boolean boolean35 = month9.equals((java.lang.Object) timeZone33);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 6 + "'", int6 == 6);
        org.junit.Assert.assertNotNull(date7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 6 + "'", int10 == 6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2019 + "'", int12 == 2019);
        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1559372400000L + "'", long13 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 6 + "'", int15 == 6);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 6 + "'", int20 == 6);
        org.junit.Assert.assertNotNull(date21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 6 + "'", int30 == 6);
        org.junit.Assert.assertNotNull(date31);
        org.junit.Assert.assertNull(regularTimePeriod34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond((long) 4);
        java.lang.String str2 = fixedMillisecond1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Wed Dec 31 16:00:00 PST 1969" + "'", str2.equals("Wed Dec 31 16:00:00 PST 1969"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.event.SeriesChangeListener seriesChangeListener4 = null;
        timeSeries3.removeChangeListener(seriesChangeListener4);
        timeSeries3.setMaximumItemAge((long) (byte) 100);
        org.jfree.data.time.Month month8 = new org.jfree.data.time.Month();
        long long9 = month8.getFirstMillisecond();
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) month8, (java.lang.Number) 1.0d);
        java.lang.Object obj12 = null;
        boolean boolean13 = timeSeries3.equals(obj12);
        org.jfree.data.time.FixedMillisecond fixedMillisecond15 = new org.jfree.data.time.FixedMillisecond((long) (short) 1);
        java.util.Calendar calendar16 = null;
        long long17 = fixedMillisecond15.getMiddleMillisecond(calendar16);
        java.util.Calendar calendar18 = null;
        fixedMillisecond15.peg(calendar18);
        java.util.Date date20 = fixedMillisecond15.getTime();
        timeSeries3.delete((org.jfree.data.time.RegularTimePeriod) fixedMillisecond15);
        java.lang.String str22 = timeSeries3.getDescription();
        boolean boolean23 = timeSeries3.getNotify();
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1559372400000L + "'", long9 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1L + "'", long17 == 1L);
        org.junit.Assert.assertNotNull(date20);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.data.time.Month month0 = new org.jfree.data.time.Month();
        int int1 = month0.getMonth();
        java.util.Date date2 = month0.getEnd();
        org.jfree.data.time.Year year3 = new org.jfree.data.time.Year(date2);
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date2);
        long long5 = month4.getSerialIndex();
        java.util.Calendar calendar6 = null;
        try {
            long long7 = month4.getLastMillisecond(calendar6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 6 + "'", int1 == 6);
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 24234L + "'", long5 == 24234L);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.data.time.TimeSeries timeSeries3 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) "hi!", "", "hi!");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        int int5 = month4.getMonth();
        java.util.Date date6 = month4.getEnd();
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(date6);
        timeSeries3.add((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 2019, false);
        org.jfree.data.time.Year year11 = new org.jfree.data.time.Year();
        long long12 = year11.getFirstMillisecond();
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month();
        int int14 = month13.getMonth();
        java.util.Date date15 = month13.getEnd();
        org.jfree.data.time.Day day16 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.Day day17 = new org.jfree.data.time.Day(date15);
        org.jfree.data.time.FixedMillisecond fixedMillisecond18 = new org.jfree.data.time.FixedMillisecond(date15);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = fixedMillisecond18.next();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = fixedMillisecond18.next();
        java.lang.Class<?> wildcardClass21 = regularTimePeriod20.getClass();
        int int22 = year11.compareTo((java.lang.Object) wildcardClass21);
        org.jfree.data.time.Month month23 = new org.jfree.data.time.Month();
        int int24 = month23.getMonth();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month23, (java.lang.Number) (-1.0f));
        boolean boolean27 = timeSeriesDataItem26.isSelected();
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        int int29 = month28.getMonth();
        java.util.Date date30 = month28.getEnd();
        org.jfree.data.time.Year year31 = new org.jfree.data.time.Year(date30);
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month(date30);
        int int33 = month32.getMonth();
        boolean boolean34 = timeSeriesDataItem26.equals((java.lang.Object) month32);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem36 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month32, (double) 2);
        java.lang.Class<?> wildcardClass37 = month32.getClass();
        long long38 = month32.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries39 = timeSeries3.createCopy((org.jfree.data.time.RegularTimePeriod) year11, (org.jfree.data.time.RegularTimePeriod) month32);
        boolean boolean40 = timeSeries3.getNotify();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 6 + "'", int5 == 6);
        org.junit.Assert.assertNotNull(date6);
        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1546329600000L + "'", long12 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 6 + "'", int14 == 6);
        org.junit.Assert.assertNotNull(date15);
        org.junit.Assert.assertNotNull(regularTimePeriod19);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(wildcardClass21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 6 + "'", int24 == 6);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 6 + "'", int29 == 6);
        org.junit.Assert.assertNotNull(date30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 6 + "'", int33 == 6);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1559372400000L + "'", long38 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
    }
}

