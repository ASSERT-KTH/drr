import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Paint paint2 = null;
        java.awt.Stroke stroke3 = null;
        java.awt.Paint paint4 = null;
        java.awt.Stroke stroke5 = null;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker7 = new org.jfree.chart.plot.IntervalMarker((double) (-1), (double) (-1.0f), paint2, stroke3, paint4, stroke5, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.data.time.SerialDate serialDate0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(serialDate0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'serialDate' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        boolean boolean0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.plot.Marker marker7 = null;
        try {
            boolean boolean8 = xYPlot4.removeRangeMarker(marker7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) '4');
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = rectangleInsets0.createInsetRectangle(rectangle2D3, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean8 = xYPlot4.isRangeZoomable();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation9 = null;
        try {
            xYPlot4.addAnnotation(xYAnnotation9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation17 = null;
        try {
            boolean boolean19 = categoryPlot4.removeAnnotation(categoryAnnotation17, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        java.awt.Font font10 = null;
        try {
            xYPlot4.setNoDataMessageFont(font10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Stroke stroke8 = xYPlot4.getRangeCrosshairStroke();
        org.jfree.chart.plot.Marker marker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            xYPlot4.addRangeMarker(10, marker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        try {
            int int8 = categoryPlot4.getDomainAxisIndex(categoryAxis7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis5 = xYPlot4.getRangeAxis();
        org.jfree.chart.plot.Marker marker6 = null;
        try {
            xYPlot4.addRangeMarker(marker6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(valueAxis5);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int0 = org.jfree.chart.axis.ValueAxis.MAXIMUM_TICK_COUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 500 + "'", int0 == 500);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        try {
            categoryPlot4.addRangeMarker(0, marker18, layer19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        try {
            numberAxis14.setRange(0.0d, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (0.0) <= upper (-1.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        try {
            int int2 = categoryPlot0.getDomainAxisIndex(categoryAxis1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color17);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        int int10 = xYPlot4.getSeriesCount();
        org.jfree.chart.plot.Marker marker11 = null;
        try {
            xYPlot4.addRangeMarker(marker11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        try {
            categoryPlot4.addDomainMarker((int) '#', categoryMarker17, layer18, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        try {
            categoryPlot4.zoom(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        xYPlot6.drawBackgroundImage(graphics2D7, rectangle2D8);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = null;
        java.awt.geom.Point2D point2D15 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D13, rectangleAnchor14);
        org.jfree.chart.plot.PlotState plotState16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        try {
            xYPlot6.draw(graphics2D11, rectangle2D12, point2D15, plotState16, plotRenderingInfo17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(point2D15);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        try {
            int int6 = categoryPlot4.getDomainAxisIndex(categoryAxis5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation10 = null;
        try {
            boolean boolean11 = xYPlot4.removeAnnotation(xYAnnotation10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        java.awt.Font font15 = null;
        try {
            numberAxis13.setTickLabelFont(font15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, (int) (byte) -1, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        categoryPlot4.setRangeCrosshairValue((double) 100.0f);
        categoryPlot4.setAnchorValue((double) (byte) 1);
        try {
            categoryPlot4.zoom((double) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.util.Date date0 = null;
        try {
            org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'time' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        java.awt.Shape shape16 = null;
        try {
            numberAxis14.setUpArrow(shape16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.lang.Object obj0 = null;
        org.jfree.data.general.Dataset dataset1 = null;
        try {
            org.jfree.data.general.DatasetChangeEvent datasetChangeEvent2 = new org.jfree.data.general.DatasetChangeEvent(obj0, dataset1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        try {
            xYPlot4.setRangeAxisLocation(axisLocation8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomRangeAxes(0.0d, plotRenderingInfo22, point2D23, false);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset27, valueAxis28, valueAxis29, xYItemRenderer30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        xYPlot31.drawBackgroundImage(graphics2D32, rectangle2D33);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = xYPlot31.getRendererForDataset(xYDataset35);
        xYPlot31.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = null;
        java.awt.geom.Point2D point2D44 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D42, rectangleAnchor43);
        xYPlot31.zoomRangeAxes(4.0d, plotRenderingInfo41, point2D44);
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = xYPlot31.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace48 = numberAxis13.reserveSpace(graphics2D15, (org.jfree.chart.plot.Plot) categoryPlot20, rectangle2D26, rectangleEdge46, axisSpace47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer36);
        org.junit.Assert.assertNotNull(point2D44);
        org.junit.Assert.assertNotNull(rectangleEdge46);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Stroke stroke8 = xYPlot4.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot4.getRangeAxis(10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        xYPlot16.drawBackgroundImage(graphics2D17, rectangle2D18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = xYPlot16.getRendererForDataset(xYDataset20);
        xYPlot16.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        int int26 = xYPlot16.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis25);
        double double27 = numberAxis25.getUpperBound();
        numberAxis25.setLabelURL("");
        xYPlot4.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis25);
        double double31 = numberAxis25.getLabelAngle();
        java.awt.Shape shape32 = null;
        try {
            numberAxis25.setUpArrow(shape32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]");
        try {
            categoryPlot4.setRangeAxis((int) (short) -1, (org.jfree.chart.axis.ValueAxis) numberAxis18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot4.getOrientation();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        try {
            xYPlot4.setDomainAxisLocation((int) (short) 0, axisLocation10, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        boolean boolean7 = categoryPlot4.isRangeGridlinesVisible();
        boolean boolean8 = categoryPlot4.isSubplot();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        try {
            int int10 = categoryPlot4.getDomainAxisIndex(categoryAxis9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot4.setRenderer(categoryItemRenderer17);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation19 = null;
        try {
            boolean boolean20 = categoryPlot4.removeAnnotation(categoryAnnotation19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.awt.Color color2 = java.awt.Color.LIGHT_GRAY;
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke5 = categoryMarker4.getOutlineStroke();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        java.awt.Stroke stroke7 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker9 = new org.jfree.chart.plot.IntervalMarker(0.0d, (double) 'a', (java.awt.Paint) color2, stroke5, (java.awt.Paint) color6, stroke7, (float) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        int int0 = org.jfree.data.time.MonthConstants.OCTOBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYPlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot5.getRendererForDataset(xYDataset9);
        xYPlot5.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot5.zoomRangeAxes(4.0d, plotRenderingInfo15, point2D18);
        boolean boolean20 = chartChangeEventType0.equals((java.lang.Object) 4.0d);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot21.drawBackgroundImage(graphics2D22, rectangle2D23);
        java.awt.Stroke stroke25 = xYPlot21.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot21.getRangeAxis(10);
        xYPlot21.setDomainCrosshairValue(0.0d, false);
        numberAxis14.setPlot((org.jfree.chart.plot.Plot) xYPlot21);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation32 = null;
        try {
            xYPlot21.addAnnotation(xYAnnotation32, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(valueAxis27);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        java.lang.String str12 = categoryPlot4.getPlotType();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            categoryPlot4.drawOutline(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.centerRange((double) 10);
        numberAxis13.setTickMarkOutsideLength((float) (short) 0);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        xYPlot4.setRangeAxisLocation((int) 'a', axisLocation11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            xYPlot4.drawBackground(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double0 = org.jfree.chart.axis.DateAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE_IN_MILLISECONDS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.0d + "'", double0 == 2.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        org.jfree.chart.plot.Plot plot10 = xYPlot4.getRootPlot();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder11 = null;
        try {
            xYPlot4.setSeriesRenderingOrder(seriesRenderingOrder11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(plot10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot4.setNoDataMessagePaint((java.awt.Paint) color13);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation15 = null;
        try {
            boolean boolean17 = xYPlot4.removeAnnotation(xYAnnotation15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        int int0 = org.jfree.data.time.MonthConstants.MARCH;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) unitType0, jFreeChart1, chartChangeEventType2);
        java.lang.String str4 = chartChangeEvent3.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType5 = chartChangeEvent3.getType();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]"));
        org.junit.Assert.assertNull(chartChangeEventType5);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str1.equals("TextAnchor.BOTTOM_CENTER"));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        xYPlot4.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker21);
        java.awt.Font font23 = null;
        try {
            categoryMarker21.setLabelFont(font23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        boolean boolean12 = categoryPlot4.isDomainZoomable();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace13);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        int int0 = org.jfree.data.time.MonthConstants.FEBRUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        xYPlot6.drawBackgroundImage(graphics2D7, rectangle2D8);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]");
        xYPlot6.setDomainAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getFixedDimension();
        java.awt.Paint paint16 = numberAxis13.getAxisLinePaint();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        categoryPlot4.setRangeCrosshairValue((double) 100.0f);
        categoryPlot4.setAnchorValue((double) (byte) 1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot4.addChangeListener(plotChangeListener21);
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = org.jfree.chart.axis.CategoryAnchor.END;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot32.zoomRangeAxes(0.0d, plotRenderingInfo34, point2D35, false);
        org.jfree.chart.plot.Marker marker39 = null;
        org.jfree.chart.util.Layer layer40 = null;
        boolean boolean42 = categoryPlot32.removeDomainMarker((int) (byte) 0, marker39, layer40, false);
        categoryPlot32.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = null;
        java.awt.geom.Point2D point2D48 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D46, rectangleAnchor47);
        categoryPlot32.zoomDomainAxes((double) 0L, plotRenderingInfo45, point2D48, false);
        boolean boolean51 = categoryAnchor27.equals((java.lang.Object) point2D48);
        org.jfree.chart.plot.PlotState plotState52 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
        try {
            categoryPlot4.draw(graphics2D25, rectangle2D26, point2D48, plotState52, plotRenderingInfo53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(categoryAnchor27);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(point2D48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        try {
            numberAxis0.setRange(10.0d, 5.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (10.0) <= upper (5.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setFixedAutoRange((double) 100);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = numberAxis13.getMarkerBand();
        numberAxis13.resizeRange(1.0d);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNull(markerAxisBand18);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        int int0 = org.jfree.data.time.MonthConstants.NOVEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 11 + "'", int0 == 11);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        xYPlot6.drawBackgroundImage(graphics2D7, rectangle2D8);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        xYPlot6.clearDomainMarkers();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = org.jfree.chart.axis.CategoryAnchor.END;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot19.zoomRangeAxes(0.0d, plotRenderingInfo21, point2D22, false);
        org.jfree.chart.plot.Marker marker26 = null;
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = categoryPlot19.removeDomainMarker((int) (byte) 0, marker26, layer27, false);
        categoryPlot19.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = null;
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor34);
        categoryPlot19.zoomDomainAxes((double) 0L, plotRenderingInfo32, point2D35, false);
        boolean boolean38 = categoryAnchor14.equals((java.lang.Object) point2D35);
        org.jfree.chart.plot.PlotState plotState39 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo40 = null;
        try {
            xYPlot6.draw(graphics2D12, rectangle2D13, point2D35, plotState39, plotRenderingInfo40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Stroke stroke8 = xYPlot4.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot4.getRangeAxis(10);
        xYPlot4.setDomainCrosshairValue(0.0d, false);
        int int14 = xYPlot4.getRangeAxisCount();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        xYPlot4.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker21);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        xYPlot28.drawBackgroundImage(graphics2D29, rectangle2D30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot28.getRendererForDataset(xYDataset32);
        xYPlot28.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        int int38 = xYPlot28.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis37);
        double double39 = numberAxis37.getUpperBound();
        numberAxis37.setFixedAutoRange((double) 100);
        xYPlot4.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis37);
        java.awt.Color color43 = java.awt.Color.WHITE;
        float[] floatArray44 = null;
        float[] floatArray45 = color43.getComponents(floatArray44);
        numberAxis37.setTickLabelPaint((java.awt.Paint) color43);
        org.jfree.data.Range range47 = null;
        try {
            numberAxis37.setDefaultAutoRange(range47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(color43);
        org.junit.Assert.assertNotNull(floatArray45);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.util.TimeZone timeZone1 = null;
        try {
            dateAxis0.setTimeZone(timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setLabelURL("");
        java.awt.Font font18 = numberAxis13.getLabelFont();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        categoryPlot24.setAnchorValue((double) 0L);
        boolean boolean27 = categoryPlot24.isRangeGridlinesVisible();
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = xYPlot33.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace37 = numberAxis13.reserveSpace(graphics2D19, (org.jfree.chart.plot.Plot) categoryPlot24, rectangle2D28, rectangleEdge35, axisSpace36);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("TextAnchor.BOTTOM_CENTER");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        boolean boolean12 = categoryPlot4.isDomainZoomable();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            categoryPlot4.drawBackground(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYPlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot5.getRendererForDataset(xYDataset9);
        xYPlot5.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        java.awt.Color color14 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot5.setNoDataMessagePaint((java.awt.Paint) color14);
        java.awt.Stroke stroke16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot21.zoomRangeAxes(0.0d, plotRenderingInfo23, point2D24, false);
        org.jfree.chart.plot.Marker marker28 = null;
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean31 = categoryPlot21.removeDomainMarker((int) (byte) 0, marker28, layer29, false);
        categoryPlot21.setBackgroundAlpha((float) 0);
        categoryPlot21.setRangeCrosshairValue((double) 100.0f);
        java.awt.Color color36 = java.awt.Color.BLACK;
        categoryPlot21.setDomainGridlinePaint((java.awt.Paint) color36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot42.zoomRangeAxes(0.0d, plotRenderingInfo44, point2D45, false);
        org.jfree.chart.axis.AxisSpace axisSpace48 = categoryPlot42.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace49 = null;
        categoryPlot42.setFixedRangeAxisSpace(axisSpace49, false);
        java.awt.Stroke stroke52 = categoryPlot42.getRangeCrosshairStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker54 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color14, stroke16, (java.awt.Paint) color36, stroke52, (float) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertNull(axisSpace48);
        org.junit.Assert.assertNotNull(stroke52);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainCrosshairPaint();
        int int10 = xYPlot4.getRangeAxisCount();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        try {
            xYPlot4.addAnnotation(xYAnnotation11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) '4');
        double double4 = rectangleInsets0.extendHeight((double) 1.0f);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType7 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets0.createAdjustedRectangle(rectangle2D5, lengthAdjustmentType6, lengthAdjustmentType7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.0d + "'", double4 == 5.0d);
        org.junit.Assert.assertNotNull(lengthAdjustmentType6);
        org.junit.Assert.assertNotNull(lengthAdjustmentType7);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        int int15 = categoryPlot4.getBackgroundImageAlignment();
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        try {
            categoryPlot4.setRangeAxisLocation(axisLocation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.configureDomainAxes();
        xYPlot4.setRangeCrosshairValue((double) (byte) 0, true);
        java.lang.Class<?> wildcardClass9 = xYPlot4.getClass();
        java.lang.Class class10 = org.jfree.data.time.RegularTimePeriod.downsize((java.lang.Class) wildcardClass9);
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertNotNull(class10);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup6 = xYPlot4.getDatasetGroup();
        boolean boolean7 = xYPlot4.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        xYPlot13.drawBackgroundImage(graphics2D14, rectangle2D15);
        org.jfree.chart.plot.PlotOrientation plotOrientation17 = xYPlot13.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        categoryPlot23.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke28 = categoryMarker27.getOutlineStroke();
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean30 = categoryPlot23.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker27, layer29);
        java.lang.Comparable comparable31 = categoryMarker27.getKey();
        java.awt.Paint paint32 = categoryMarker27.getPaint();
        org.jfree.chart.util.Layer layer33 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot13.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker27, layer33);
        java.util.Collection collection35 = xYPlot4.getRangeMarkers((int) (short) 100, layer33);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation36 = null;
        try {
            xYPlot4.addAnnotation(xYAnnotation36, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(plotOrientation17);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + (byte) 0 + "'", comparable31.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(layer33);
        org.junit.Assert.assertNull(collection35);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) '4');
        double double4 = rectangleInsets0.extendHeight((double) 1.0f);
        double double5 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createInsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.0d + "'", double4 == 5.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        boolean boolean2 = numberAxis0.isVisible();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot(categoryDataset6, categoryAxis7, valueAxis8, categoryItemRenderer9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot10.zoomRangeAxes(0.0d, plotRenderingInfo12, point2D13, false);
        org.jfree.chart.plot.Marker marker17 = null;
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean20 = categoryPlot10.removeDomainMarker((int) (byte) 0, marker17, layer18, false);
        categoryPlot10.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot10.getRangeAxisEdge();
        try {
            java.util.List list23 = numberAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        float[] floatArray1 = null;
        float[] floatArray2 = color0.getColorComponents(floatArray1);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.java2DToValue((double) 10.0f, rectangle2D2, rectangleEdge3);
        java.util.TimeZone timeZone5 = null;
        try {
            dateAxis0.setTimeZone(timeZone5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.223372036854776E18d + "'", double4 == 9.223372036854776E18d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke2 = categoryMarker1.getStroke();
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setLabelURL("");
        double double18 = numberAxis13.getLowerBound();
        double double19 = numberAxis13.getLowerBound();
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setLabelURL("");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double20 = rectangleInsets18.calculateRightInset((double) '4');
        double double22 = rectangleInsets18.extendHeight((double) 1.0f);
        numberAxis13.setLabelInsets(rectangleInsets18);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D27 = rectangleInsets18.createInsetRectangle(rectangle2D24, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.0d + "'", double22 == 5.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setLabelURL("");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double20 = rectangleInsets18.calculateRightInset((double) '4');
        double double22 = rectangleInsets18.extendHeight((double) 1.0f);
        numberAxis13.setLabelInsets(rectangleInsets18);
        double double24 = numberAxis13.getFixedDimension();
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.0d + "'", double22 == 5.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        java.awt.Paint paint2 = null;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot7.zoomRangeAxes(0.0d, plotRenderingInfo9, point2D10, false);
        org.jfree.chart.plot.Marker marker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean17 = categoryPlot7.removeDomainMarker((int) (byte) 0, marker14, layer15, false);
        categoryPlot7.clearAnnotations();
        java.awt.Stroke stroke19 = categoryPlot7.getDomainGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, valueAxis22, xYItemRenderer23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        xYPlot24.drawBackgroundImage(graphics2D25, rectangle2D26);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = xYPlot24.getRendererForDataset(xYDataset28);
        xYPlot24.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot24.setNoDataMessagePaint((java.awt.Paint) color33);
        java.awt.Color color35 = color33.brighter();
        java.awt.Stroke stroke36 = null;
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker38 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, (double) (byte) -1, paint2, stroke19, (java.awt.Paint) color33, stroke36, 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNull(xYItemRenderer29);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(color35);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis0.setTickUnit(dateTickUnit2, false, true);
        java.util.Date date6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = xYPlot12.getRangeAxisEdge((int) (byte) 10);
        try {
            double double15 = dateAxis0.dateToJava2D(date6, rectangle2D7, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        int int0 = org.jfree.data.time.MonthConstants.MAY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 5 + "'", int0 == 5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Color color0 = java.awt.Color.green;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 2.0f);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        numberAxis14.setRangeAboutValue((double) (byte) 0, 0.0d);
        double double19 = numberAxis14.getFixedAutoRange();
        numberAxis14.setRange(0.0d, 9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot6.setDomainAxisLocation((int) '4', axisLocation8);
        boolean boolean11 = xYPlot6.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot6.markerChanged(markerChangeEvent12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double16 = rectangleInsets14.calculateRightInset((double) '4');
        double double18 = rectangleInsets14.extendHeight((double) 1.0f);
        xYPlot6.setAxisOffset(rectangleInsets14);
        xYPlot6.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker23);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYPlot30.drawBackgroundImage(graphics2D31, rectangle2D32);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = xYPlot30.getRendererForDataset(xYDataset34);
        xYPlot30.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        int int40 = xYPlot30.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis39);
        double double41 = numberAxis39.getUpperBound();
        numberAxis39.setFixedAutoRange((double) 100);
        xYPlot6.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis39);
        numberAxis39.setUpperBound((-1.0d));
        java.awt.Stroke stroke47 = numberAxis39.getTickMarkStroke();
        dateAxis0.setAxisLineStroke(stroke47);
        dateAxis0.configure();
        java.lang.Object obj50 = dateAxis0.clone();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 5.0d + "'", double18 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(obj50);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot21.drawBackgroundImage(graphics2D22, rectangle2D23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot21.getRendererForDataset(xYDataset25);
        xYPlot21.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        int int31 = xYPlot21.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis30);
        double double32 = numberAxis30.getUpperBound();
        numberAxis30.setLabelURL("");
        java.awt.Font font35 = numberAxis30.getLabelFont();
        numberAxis14.setTickLabelFont(font35);
        org.jfree.data.RangeType rangeType37 = null;
        try {
            numberAxis14.setRangeType(rangeType37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(font35);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) '4');
        double double4 = rectangleInsets0.extendHeight((double) 1.0f);
        double double6 = rectangleInsets0.extendHeight(9.223372036854776E18d);
        double double8 = rectangleInsets0.calculateBottomInset((-1.0d));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.0d + "'", double4 == 5.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.223372036854776E18d + "'", double6 == 9.223372036854776E18d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot4.getRangeAxis(0);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = null;
        java.awt.geom.Point2D point2D26 = null;
        categoryPlot23.zoomRangeAxes(0.0d, plotRenderingInfo25, point2D26, false);
        org.jfree.chart.plot.Marker marker30 = null;
        org.jfree.chart.util.Layer layer31 = null;
        boolean boolean33 = categoryPlot23.removeDomainMarker((int) (byte) 0, marker30, layer31, false);
        categoryPlot23.setBackgroundAlpha((float) 0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder36 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset37, valueAxis38, valueAxis39, xYItemRenderer40);
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        xYPlot41.drawBackgroundImage(graphics2D42, rectangle2D43);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = xYPlot41.getRendererForDataset(xYDataset45);
        xYPlot41.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor53 = null;
        java.awt.geom.Point2D point2D54 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D52, rectangleAnchor53);
        xYPlot41.zoomRangeAxes(4.0d, plotRenderingInfo51, point2D54);
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = xYPlot41.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset57 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = null;
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset57, categoryAxis58, valueAxis59, categoryItemRenderer60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        java.awt.geom.Point2D point2D64 = null;
        categoryPlot61.zoomRangeAxes(0.0d, plotRenderingInfo63, point2D64, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis68 = null;
        categoryPlot61.setDomainAxis((int) 'a', categoryAxis68, false);
        xYPlot41.setParent((org.jfree.chart.plot.Plot) categoryPlot61);
        boolean boolean72 = datasetRenderingOrder36.equals((java.lang.Object) xYPlot41);
        categoryPlot23.setDatasetRenderingOrder(datasetRenderingOrder36);
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder36);
        boolean boolean75 = categoryPlot4.isRangeCrosshairVisible();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder36);
        org.junit.Assert.assertNull(xYItemRenderer46);
        org.junit.Assert.assertNotNull(point2D54);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        int int0 = org.jfree.data.time.MonthConstants.SEPTEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 9 + "'", int0 == 9);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("TextAnchor.BOTTOM_CENTER", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        xYPlot4.configureRangeAxes();
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        xYPlot4.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker21);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        xYPlot28.drawBackgroundImage(graphics2D29, rectangle2D30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot28.getRendererForDataset(xYDataset32);
        xYPlot28.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        int int38 = xYPlot28.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis37);
        double double39 = numberAxis37.getUpperBound();
        numberAxis37.setFixedAutoRange((double) 100);
        xYPlot4.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis37);
        double double43 = xYPlot4.getRangeCrosshairValue();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        xYPlot4.zoomDomainAxes((double) 100.0f, plotRenderingInfo45, point2D46, false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Stroke stroke8 = xYPlot4.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot4.getRangeAxis(10);
        xYPlot4.setDomainCrosshairValue(0.0d, false);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = xYPlot4.getSeriesRenderingOrder();
        java.lang.String str15 = seriesRenderingOrder14.toString();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str15.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis1.configure();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.Plot plot7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = null;
        org.jfree.chart.plot.XYPlot xYPlot13 = new org.jfree.chart.plot.XYPlot(xYDataset9, valueAxis10, valueAxis11, xYItemRenderer12);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        xYPlot13.drawBackgroundImage(graphics2D14, rectangle2D15);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = xYPlot13.getRendererForDataset(xYDataset17);
        xYPlot13.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor25 = null;
        java.awt.geom.Point2D point2D26 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D24, rectangleAnchor25);
        xYPlot13.zoomRangeAxes(4.0d, plotRenderingInfo23, point2D26);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = xYPlot13.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace30 = categoryAxis1.reserveSpace(graphics2D6, plot7, rectangle2D8, rectangleEdge28, axisSpace29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer18);
        org.junit.Assert.assertNotNull(point2D26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray15 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot4.setRangeAxes(valueAxisArray15);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent17);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(valueAxisArray15);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        org.jfree.chart.util.Layer layer16 = null;
        xYPlot4.addRangeMarker((int) (short) -1, (org.jfree.chart.plot.Marker) intervalMarker15, layer16);
        double double18 = intervalMarker15.getStartValue();
        java.awt.Font font19 = null;
        try {
            intervalMarker15.setLabelFont(font19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        java.awt.Shape[] shapeArray1 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        boolean boolean2 = chartChangeEventType0.equals((java.lang.Object) shapeArray1);
        org.junit.Assert.assertNotNull(chartChangeEventType0);
        org.junit.Assert.assertNotNull(shapeArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) unitType0, jFreeChart1, chartChangeEventType2);
        java.lang.Object obj4 = chartChangeEvent3.getSource();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertNotNull(obj4);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Stroke stroke8 = xYPlot4.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot4.getRangeAxis(10);
        xYPlot4.setDomainCrosshairValue(0.0d, false);
        java.awt.Font font14 = xYPlot4.getNoDataMessageFont();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = xYPlot4.getOrientation();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot4.getRangeAxisForDataset((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(plotOrientation15);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getUpperBound();
        numberAxis14.setTickMarkOutsideLength((float) 500);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainCrosshairPaint();
        int int10 = xYPlot4.getRangeAxisCount();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation11 = null;
        try {
            xYPlot4.addAnnotation(xYAnnotation11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Paint paint8 = xYPlot4.getRangeGridlinePaint();
        xYPlot4.clearRangeMarkers(9);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 5.0d, "org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]");
        java.lang.String str9 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) "Layer.FOREGROUND");
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        categoryPlot4.setRangeCrosshairValue((double) 100.0f);
        java.awt.Color color19 = java.awt.Color.BLACK;
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke24 = categoryMarker23.getOutlineStroke();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        xYPlot29.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup31 = xYPlot29.getDatasetGroup();
        boolean boolean32 = xYPlot29.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset34, valueAxis35, valueAxis36, xYItemRenderer37);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        xYPlot38.drawBackgroundImage(graphics2D39, rectangle2D40);
        org.jfree.chart.plot.PlotOrientation plotOrientation42 = xYPlot38.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, valueAxis46, categoryItemRenderer47);
        categoryPlot48.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke53 = categoryMarker52.getOutlineStroke();
        org.jfree.chart.util.Layer layer54 = null;
        boolean boolean55 = categoryPlot48.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker52, layer54);
        java.lang.Comparable comparable56 = categoryMarker52.getKey();
        java.awt.Paint paint57 = categoryMarker52.getPaint();
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot38.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker52, layer58);
        java.util.Collection collection60 = xYPlot29.getRangeMarkers((int) (short) 100, layer58);
        categoryPlot4.addDomainMarker(0, categoryMarker23, layer58);
        org.jfree.data.category.CategoryDataset categoryDataset63 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = null;
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer66 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot(categoryDataset63, categoryAxis64, valueAxis65, categoryItemRenderer66);
        categoryPlot67.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker71 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke72 = categoryMarker71.getOutlineStroke();
        org.jfree.chart.util.Layer layer73 = null;
        boolean boolean74 = categoryPlot67.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker71, layer73);
        org.jfree.chart.axis.AxisLocation axisLocation76 = categoryPlot67.getDomainAxisLocation((int) '#');
        org.jfree.data.xy.XYDataset xYDataset77 = null;
        org.jfree.chart.axis.ValueAxis valueAxis78 = null;
        org.jfree.chart.axis.ValueAxis valueAxis79 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer80 = null;
        org.jfree.chart.plot.XYPlot xYPlot81 = new org.jfree.chart.plot.XYPlot(xYDataset77, valueAxis78, valueAxis79, xYItemRenderer80);
        java.awt.Graphics2D graphics2D82 = null;
        java.awt.geom.Rectangle2D rectangle2D83 = null;
        xYPlot81.drawBackgroundImage(graphics2D82, rectangle2D83);
        org.jfree.chart.plot.PlotOrientation plotOrientation85 = xYPlot81.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation76, plotOrientation85);
        org.jfree.chart.axis.AxisLocation axisLocation87 = axisLocation76.getOpposite();
        try {
            categoryPlot4.setDomainAxisLocation((int) (short) -1, axisLocation76, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(datasetGroup31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(plotOrientation42);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + comparable56 + "' != '" + (byte) 0 + "'", comparable56.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertNull(collection60);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(axisLocation76);
        org.junit.Assert.assertNotNull(plotOrientation85);
        org.junit.Assert.assertNotNull(rectangleEdge86);
        org.junit.Assert.assertNotNull(axisLocation87);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        categoryPlot4.drawBackgroundImage(graphics2D12, rectangle2D13);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot21.drawBackgroundImage(graphics2D22, rectangle2D23);
        java.awt.Stroke stroke25 = xYPlot21.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot21.getRangeAxis(10);
        xYPlot21.setDomainCrosshairValue(0.0d, false);
        numberAxis14.setPlot((org.jfree.chart.plot.Plot) xYPlot21);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        xYPlot36.drawBackgroundImage(graphics2D37, rectangle2D38);
        java.awt.Stroke stroke40 = xYPlot36.getRangeCrosshairStroke();
        xYPlot21.setRangeCrosshairStroke(stroke40);
        boolean boolean42 = xYPlot21.isRangeZoomable();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        try {
            java.awt.Color color1 = java.awt.Color.decode("PlotOrientation.HORIZONTAL");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"PlotOrientation.HORIZONTAL\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker2.setLabelPaint(paint3);
        java.lang.Comparable comparable5 = categoryMarker2.getKey();
        org.jfree.chart.util.Layer layer6 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker2, layer6);
        java.awt.Stroke stroke8 = null;
        categoryMarker2.setOutlineStroke(stroke8);
        java.awt.Paint paint10 = categoryMarker2.getPaint();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (byte) 0 + "'", comparable5.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot4.getOrientation();
        xYPlot4.clearDomainMarkers((int) (byte) -1);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot4.getFixedLegendItems();
        xYPlot4.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(legendItemCollection11);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder0 = org.jfree.chart.plot.SeriesRenderingOrder.FORWARD;
        org.junit.Assert.assertNotNull(seriesRenderingOrder0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        int int15 = categoryPlot4.getBackgroundImageAlignment();
        categoryPlot4.setWeight(10);
        java.awt.Image image18 = null;
        categoryPlot4.setBackgroundImage(image18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot4.getDomainAxis(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        int int24 = categoryPlot4.getIndexOf(categoryItemRenderer23);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.resizeRange((double) '#');
        boolean boolean18 = numberAxis13.isVisible();
        org.jfree.data.Range range19 = null;
        try {
            numberAxis13.setRangeWithMargins(range19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot4.getDomainAxis((int) (short) 100);
        boolean boolean9 = categoryPlot4.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot14.zoomRangeAxes(0.0d, plotRenderingInfo16, point2D17, false);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, valueAxis22, xYItemRenderer23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        xYPlot24.setDomainAxisLocation((int) '4', axisLocation26);
        boolean boolean29 = xYPlot24.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        xYPlot24.markerChanged(markerChangeEvent30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double34 = rectangleInsets32.calculateRightInset((double) '4');
        double double36 = rectangleInsets32.extendHeight((double) 1.0f);
        xYPlot24.setAxisOffset(rectangleInsets32);
        xYPlot24.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot24.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker41);
        categoryPlot14.addDomainMarker(categoryMarker41);
        boolean boolean44 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker41);
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        try {
            categoryPlot4.drawBackground(graphics2D45, rectangle2D46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 4.0d + "'", double34 == 4.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 5.0d + "'", double36 == 5.0d);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot4.setDomainAxis((int) (byte) 0, categoryAxis17);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation19 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.axis.AxisState axisState2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = xYPlot8.getRangeAxisEdge((int) (byte) 10);
        try {
            java.util.List list11 = dateAxis0.refreshTicks(graphics2D1, axisState2, rectangle2D3, rectangleEdge10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge10);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot4.getOrientation();
        xYPlot4.clearDomainMarkers((int) (byte) -1);
        boolean boolean11 = xYPlot4.isDomainGridlinesVisible();
        xYPlot4.setBackgroundAlpha((float) 0);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.resizeRange((double) '#');
        numberAxis13.setVerticalTickLabels(true);
        numberAxis13.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        xYPlot4.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker21);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        xYPlot28.drawBackgroundImage(graphics2D29, rectangle2D30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot28.getRendererForDataset(xYDataset32);
        xYPlot28.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        int int38 = xYPlot28.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis37);
        double double39 = numberAxis37.getUpperBound();
        numberAxis37.setFixedAutoRange((double) 100);
        xYPlot4.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis37);
        numberAxis37.setUpperBound((-1.0d));
        java.awt.Shape shape45 = numberAxis37.getLeftArrow();
        boolean boolean46 = numberAxis37.isVisible();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setFixedAutoRange((double) 100);
        boolean boolean18 = numberAxis13.isVisible();
        org.jfree.chart.plot.Plot plot19 = numberAxis13.getPlot();
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(plot19);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot4.getRangeAxis(0);
        categoryPlot4.configureRangeAxes();
        org.jfree.chart.plot.Marker marker20 = null;
        try {
            categoryPlot4.addRangeMarker(marker20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(valueAxis18);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 100L, (float) (short) 10, (float) 3);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot5.zoomRangeAxes(0.0d, plotRenderingInfo7, point2D8, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot5.setDomainAxis((int) 'a', categoryAxis12, false);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        int int16 = categoryPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis15);
        numberAxis15.setRangeAboutValue((double) (byte) 0, 0.0d);
        double double20 = numberAxis15.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        xYPlot25.drawBackgroundImage(graphics2D26, rectangle2D27);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = xYPlot25.getRendererForDataset(xYDataset29);
        xYPlot25.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        int int35 = xYPlot25.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis34);
        double double36 = numberAxis34.getUpperBound();
        numberAxis34.setLabelURL("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis34, xYItemRenderer39);
        xYPlot40.setDomainCrosshairVisible(false);
        double double43 = xYPlot40.getRangeCrosshairValue();
        org.jfree.chart.event.PlotChangeListener plotChangeListener44 = null;
        xYPlot40.addChangeListener(plotChangeListener44);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot4.setDomainAxis((int) (byte) 0, categoryAxis17);
        java.awt.Image image19 = categoryPlot4.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot4.getDomainAxisEdge();
        categoryPlot4.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        numberAxis14.centerRange((double) 0L);
        numberAxis14.setAutoRangeIncludesZero(true);
        try {
            numberAxis14.setRange((double) 9, (double) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (9.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace18, true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint5 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker4.setLabelPaint(paint5);
        java.lang.Comparable comparable7 = categoryMarker4.getKey();
        org.jfree.chart.util.Layer layer8 = null;
        categoryPlot2.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker4, layer8);
        java.awt.Paint paint10 = categoryMarker4.getLabelPaint();
        numberAxis0.setLabelPaint(paint10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (byte) 0 + "'", comparable7.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis("", timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        numberAxis13.setAutoRangeStickyZero(false);
        java.awt.Font font17 = numberAxis13.getTickLabelFont();
        numberAxis13.setLabelToolTip("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]");
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Stroke stroke8 = xYPlot4.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot4.getRangeAxis(10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        xYPlot16.drawBackgroundImage(graphics2D17, rectangle2D18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = xYPlot16.getRendererForDataset(xYDataset20);
        xYPlot16.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        int int26 = xYPlot16.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis25);
        double double27 = numberAxis25.getUpperBound();
        numberAxis25.setLabelURL("");
        xYPlot4.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis25);
        boolean boolean31 = numberAxis25.isAxisLineVisible();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = org.jfree.data.time.MonthConstants.APRIL;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean8 = xYPlot4.isRangeZoomable();
        float float9 = xYPlot4.getBackgroundImageAlpha();
        java.awt.Paint paint10 = xYPlot4.getDomainTickBandPaint();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNull(paint10);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        org.jfree.chart.util.UnitType unitType18 = rectangleInsets12.getUnitType();
        double double20 = rectangleInsets12.calculateBottomOutset(0.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
        org.junit.Assert.assertNotNull(unitType18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot6.setDomainAxisLocation((int) '4', axisLocation8);
        boolean boolean11 = xYPlot6.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot6.markerChanged(markerChangeEvent12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double16 = rectangleInsets14.calculateRightInset((double) '4');
        double double18 = rectangleInsets14.extendHeight((double) 1.0f);
        xYPlot6.setAxisOffset(rectangleInsets14);
        xYPlot6.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker23);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYPlot30.drawBackgroundImage(graphics2D31, rectangle2D32);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = xYPlot30.getRendererForDataset(xYDataset34);
        xYPlot30.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        int int40 = xYPlot30.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis39);
        double double41 = numberAxis39.getUpperBound();
        numberAxis39.setFixedAutoRange((double) 100);
        xYPlot6.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis39);
        numberAxis39.setUpperBound((-1.0d));
        java.awt.Stroke stroke47 = numberAxis39.getTickMarkStroke();
        dateAxis0.setAxisLineStroke(stroke47);
        dateAxis0.configure();
        dateAxis0.configure();
        java.util.TimeZone timeZone51 = null;
        try {
            dateAxis0.setTimeZone(timeZone51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 5.0d + "'", double18 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot21.drawBackgroundImage(graphics2D22, rectangle2D23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot21.getRendererForDataset(xYDataset25);
        xYPlot21.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        int int31 = xYPlot21.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis30);
        double double32 = numberAxis30.getUpperBound();
        numberAxis30.setLabelURL("");
        java.awt.Font font35 = numberAxis30.getLabelFont();
        numberAxis14.setTickLabelFont(font35);
        double double37 = numberAxis14.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0E-8d + "'", double37 == 1.0E-8d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot15.drawBackgroundImage(graphics2D16, rectangle2D17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = xYPlot15.getRendererForDataset(xYDataset19);
        xYPlot15.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        int int25 = xYPlot15.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis24);
        double double26 = numberAxis24.getUpperBound();
        numberAxis24.setLabelURL("");
        java.awt.Font font29 = numberAxis24.getLabelFont();
        categoryPlot9.setRangeAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis24, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot9.getDomainAxisEdge();
        try {
            double double33 = categoryAxis1.getCategoryEnd(10, 500, rectangle2D4, rectangleEdge32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.0d + "'", double26 == 1.0d);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(rectangleEdge32);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        java.awt.Color color1 = java.awt.Color.getColor("XY Plot");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        xYPlot6.drawBackgroundImage(graphics2D7, rectangle2D8);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]");
        xYPlot6.setDomainAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.jfree.chart.plot.Plot plot15 = null;
        numberAxis13.setPlot(plot15);
        java.text.NumberFormat numberFormat17 = numberAxis13.getNumberFormatOverride();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(numberFormat17);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        int int15 = categoryPlot4.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot4.getDataset();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        int int18 = categoryPlot4.getIndexOf(categoryItemRenderer17);
        categoryPlot4.setRangeCrosshairValue(1.0E-8d, false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot6.setDomainAxisLocation((int) '4', axisLocation8);
        boolean boolean11 = xYPlot6.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot6.markerChanged(markerChangeEvent12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double16 = rectangleInsets14.calculateRightInset((double) '4');
        double double18 = rectangleInsets14.extendHeight((double) 1.0f);
        xYPlot6.setAxisOffset(rectangleInsets14);
        xYPlot6.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker23);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYPlot30.drawBackgroundImage(graphics2D31, rectangle2D32);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = xYPlot30.getRendererForDataset(xYDataset34);
        xYPlot30.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        int int40 = xYPlot30.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis39);
        double double41 = numberAxis39.getUpperBound();
        numberAxis39.setFixedAutoRange((double) 100);
        xYPlot6.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis39);
        numberAxis39.setUpperBound((-1.0d));
        java.awt.Stroke stroke47 = numberAxis39.getTickMarkStroke();
        dateAxis0.setAxisLineStroke(stroke47);
        dateAxis0.configure();
        dateAxis0.configure();
        java.lang.Object obj51 = dateAxis0.clone();
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        org.jfree.data.category.CategoryDataset categoryDataset54 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis55 = null;
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot(categoryDataset54, categoryAxis55, valueAxis56, categoryItemRenderer57);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo60 = null;
        java.awt.geom.Point2D point2D61 = null;
        categoryPlot58.zoomRangeAxes(0.0d, plotRenderingInfo60, point2D61, false);
        org.jfree.chart.plot.Marker marker65 = null;
        org.jfree.chart.util.Layer layer66 = null;
        boolean boolean68 = categoryPlot58.removeDomainMarker((int) (byte) 0, marker65, layer66, false);
        int int69 = categoryPlot58.getBackgroundImageAlignment();
        categoryPlot58.setWeight(10);
        java.awt.Image image72 = null;
        categoryPlot58.setBackgroundImage(image72);
        org.jfree.chart.util.RectangleEdge rectangleEdge74 = categoryPlot58.getRangeAxisEdge();
        try {
            double double75 = dateAxis0.java2DToValue((double) 255, rectangle2D53, rectangleEdge74);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 5.0d + "'", double18 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 15 + "'", int69 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge74);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.awt.Color color2 = java.awt.Color.getColor("XY Plot", 0);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        xYPlot10.drawBackgroundImage(graphics2D11, rectangle2D12);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot10.getRendererForDataset(xYDataset14);
        xYPlot10.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        int int20 = xYPlot10.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis19);
        double double21 = numberAxis19.getUpperBound();
        numberAxis19.setLabelURL("");
        java.awt.Font font24 = numberAxis19.getLabelFont();
        categoryPlot4.setRangeAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis19, true);
        categoryPlot4.setAnchorValue(0.0d, false);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomRangeAxes(0.0d, plotRenderingInfo22, point2D23, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        categoryPlot20.setDomainAxis((int) 'a', categoryAxis27, false);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        int int31 = categoryPlot20.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis30);
        numberAxis30.centerRange((double) 0L);
        org.jfree.data.Range range34 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis30);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot4.setFixedDomainAxisSpace(axisSpace35);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNull(range34);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        boolean boolean2 = dateAxis0.isTickMarksVisible();
        java.awt.Paint paint3 = null;
        try {
            dateAxis0.setAxisLinePaint(paint3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) '4');
        double double3 = rectangleInsets0.getBottom();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createOutsetRectangle(rectangle2D4, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        categoryPlot22.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke27 = categoryMarker26.getOutlineStroke();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot22.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot22.getDomainAxisLocation((int) '#');
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        xYPlot36.drawBackgroundImage(graphics2D37, rectangle2D38);
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = xYPlot36.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation31, plotOrientation40);
        org.jfree.chart.axis.AxisLocation axisLocation42 = axisLocation31.getOpposite();
        categoryPlot4.setRangeAxisLocation(4, axisLocation31);
        try {
            categoryPlot4.zoom((double) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(axisLocation42);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.resizeRange((double) '#');
        boolean boolean18 = numberAxis13.isVisible();
        numberAxis13.setAutoRangeStickyZero(false);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot21.drawBackgroundImage(graphics2D22, rectangle2D23);
        java.awt.Stroke stroke25 = xYPlot21.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot21.getRangeAxis(10);
        xYPlot21.setDomainCrosshairValue(0.0d, false);
        numberAxis14.setPlot((org.jfree.chart.plot.Plot) xYPlot21);
        java.awt.Shape shape32 = numberAxis14.getUpArrow();
        boolean boolean33 = numberAxis14.isNegativeArrowVisible();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.configureDomainAxes();
        xYPlot4.setRangeCrosshairValue(0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = numberAxis14.getStandardTickUnits();
        java.lang.Object obj17 = numberAxis14.clone();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str1.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        int int10 = xYPlot4.getSeriesCount();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot4.getRangeAxisEdge();
        java.awt.Color color16 = java.awt.Color.orange;
        xYPlot4.setDomainCrosshairPaint((java.awt.Paint) color16);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        int int0 = org.jfree.data.time.MonthConstants.JUNE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 6 + "'", int0 == 6);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.configureDomainAxes();
        xYPlot4.setRangeCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = xYPlot4.getDatasetRenderingOrder();
        org.jfree.chart.axis.ValueAxis[] valueAxisArray10 = null;
        try {
            xYPlot4.setRangeAxes(valueAxisArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.jfree.chart.axis.TickUnitSource tickUnitSource16 = numberAxis14.getStandardTickUnits();
        org.jfree.chart.axis.TickUnitSource tickUnitSource17 = null;
        numberAxis14.setStandardTickUnits(tickUnitSource17);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier19 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke20 = defaultDrawingSupplier19.getNextOutlineStroke();
        java.awt.Stroke stroke21 = defaultDrawingSupplier19.getNextStroke();
        java.awt.Paint paint22 = defaultDrawingSupplier19.getNextOutlinePaint();
        numberAxis14.setTickLabelPaint(paint22);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(tickUnitSource16);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = dateAxis2.java2DToValue((double) 10.0f, rectangle2D4, rectangleEdge5);
        java.text.DateFormat dateFormat7 = null;
        dateAxis2.setDateFormatOverride(dateFormat7);
        org.jfree.chart.axis.Timeline timeline9 = dateAxis2.getTimeline();
        dateAxis0.setTimeline(timeline9);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.223372036854776E18d + "'", double6 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(timeline9);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        java.util.TimeZone timeZone0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.DateAxis.createStandardDateTickUnits(timeZone0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        numberAxis14.setRangeAboutValue((double) (byte) 0, 0.0d);
        double double19 = numberAxis14.getFixedAutoRange();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot26.zoomRangeAxes(0.0d, plotRenderingInfo28, point2D29, false);
        org.jfree.chart.axis.AxisSpace axisSpace32 = categoryPlot26.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        categoryPlot26.setFixedRangeAxisSpace(axisSpace33, false);
        java.awt.Stroke stroke36 = categoryPlot26.getRangeCrosshairStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection37 = categoryPlot26.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot26.getRangeAxisEdge(15);
        try {
            double double40 = numberAxis14.valueToJava2D((double) 0.0f, rectangle2D21, rectangleEdge39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNull(axisSpace32);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(legendItemCollection37);
        org.junit.Assert.assertNotNull(rectangleEdge39);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj2 = numberAxis1.clone();
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        xYPlot7.drawBackgroundImage(graphics2D8, rectangle2D9);
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot7);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]");
        xYPlot7.setDomainAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedDimension();
        boolean boolean17 = rectangleAnchor0.equals((java.lang.Object) double16);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot8.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.plot.Marker marker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        boolean boolean18 = categoryPlot8.removeDomainMarker((int) (byte) 0, marker15, layer16, false);
        int int19 = categoryPlot8.getBackgroundImageAlignment();
        categoryPlot8.setWeight(10);
        java.awt.Image image22 = null;
        categoryPlot8.setBackgroundImage(image22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot8.getRangeAxisEdge();
        try {
            double double25 = categoryAxis0.getCategoryMiddle(0, 9, rectangle2D3, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 15 + "'", int19 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.awt.Color color0 = java.awt.Color.LIGHT_GRAY;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray9 = new float[] { 'a', (short) -1, ' ', 10.0f, 0, 0 };
        float[] floatArray10 = color2.getRGBColorComponents(floatArray9);
        float[] floatArray11 = color0.getRGBColorComponents(floatArray10);
        java.lang.String str12 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "java.awt.Color[r=192,g=192,b=192]" + "'", str12.equals("java.awt.Color[r=192,g=192,b=192]"));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        xYPlot4.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker21);
        org.jfree.chart.JFreeChart jFreeChart23 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryMarker21, jFreeChart23);
        org.jfree.chart.JFreeChart jFreeChart25 = chartChangeEvent24.getChart();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
        org.junit.Assert.assertNull(jFreeChart25);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean8 = xYPlot4.isRangeZoomable();
        float float9 = xYPlot4.getBackgroundImageAlpha();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot15.drawBackgroundImage(graphics2D16, rectangle2D17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = xYPlot15.getRendererForDataset(xYDataset19);
        xYPlot15.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        java.awt.Color color24 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot15.setNoDataMessagePaint((java.awt.Paint) color24);
        java.awt.Color color26 = color24.brighter();
        try {
            xYPlot4.setQuadrantPaint(255, (java.awt.Paint) color24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (255) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.5f + "'", float9 == 0.5f);
        org.junit.Assert.assertNull(xYItemRenderer20);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace6 = xYPlot4.getFixedRangeAxisSpace();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis8 = xYPlot4.getDomainAxisForDataset(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 15 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace6);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        boolean boolean2 = numberAxis0.isAutoRange();
        boolean boolean3 = numberAxis0.isVisible();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        xYPlot8.configureDomainAxes();
        xYPlot8.setRangeCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = xYPlot8.getDatasetRenderingOrder();
        boolean boolean14 = numberAxis0.hasListener((java.util.EventListener) xYPlot8);
        xYPlot8.setRangeCrosshairValue((double) '#');
        xYPlot8.setOutlineVisible(false);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent19 = null;
        xYPlot8.datasetChanged(datasetChangeEvent19);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        java.awt.Image image17 = categoryPlot4.getBackgroundImage();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis19.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis19.configure();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot28.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = xYPlot28.getLegendItems();
        boolean boolean32 = categoryAxis19.equals((java.lang.Object) legendItemCollection31);
        categoryPlot4.setDomainAxis(categoryAxis19);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint37 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker36.setLabelPaint(paint37);
        java.lang.Comparable comparable39 = categoryMarker36.getKey();
        org.jfree.chart.util.Layer layer40 = null;
        categoryPlot34.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker36, layer40);
        java.awt.Paint paint42 = categoryMarker36.getLabelPaint();
        categoryPlot4.setDomainGridlinePaint(paint42);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(legendItemCollection31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + (byte) 0 + "'", comparable39.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot5.zoomRangeAxes(0.0d, plotRenderingInfo7, point2D8, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot5.setDomainAxis((int) 'a', categoryAxis12, false);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        int int16 = categoryPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis15);
        numberAxis15.setRangeAboutValue((double) (byte) 0, 0.0d);
        double double20 = numberAxis15.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        xYPlot25.drawBackgroundImage(graphics2D26, rectangle2D27);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = xYPlot25.getRendererForDataset(xYDataset29);
        xYPlot25.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        int int35 = xYPlot25.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis34);
        double double36 = numberAxis34.getUpperBound();
        numberAxis34.setLabelURL("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis34, xYItemRenderer39);
        java.awt.Graphics2D graphics2D41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        org.jfree.chart.plot.CrosshairState crosshairState45 = null;
        boolean boolean46 = xYPlot40.render(graphics2D41, rectangle2D42, 5, plotRenderingInfo44, crosshairState45);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        java.awt.Color color2 = java.awt.Color.WHITE;
        numberAxis0.setTickMarkPaint((java.awt.Paint) color2);
        boolean boolean4 = numberAxis0.isTickLabelsVisible();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        xYPlot4.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker21);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        xYPlot28.drawBackgroundImage(graphics2D29, rectangle2D30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot28.getRendererForDataset(xYDataset32);
        xYPlot28.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        int int38 = xYPlot28.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis37);
        double double39 = numberAxis37.getUpperBound();
        numberAxis37.setFixedAutoRange((double) 100);
        xYPlot4.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis37);
        double double43 = xYPlot4.getRangeCrosshairValue();
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset44, valueAxis45, valueAxis46, xYItemRenderer47);
        org.jfree.chart.axis.AxisLocation axisLocation50 = null;
        xYPlot48.setDomainAxisLocation((int) '4', axisLocation50);
        boolean boolean53 = xYPlot48.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent54 = null;
        xYPlot48.markerChanged(markerChangeEvent54);
        org.jfree.chart.plot.IntervalMarker intervalMarker59 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        org.jfree.chart.util.Layer layer60 = null;
        xYPlot48.addRangeMarker((int) (short) -1, (org.jfree.chart.plot.Marker) intervalMarker59, layer60);
        java.lang.String str62 = intervalMarker59.getLabel();
        boolean boolean63 = xYPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) intervalMarker59);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer64 = null;
        intervalMarker59.setGradientPaintTransformer(gradientPaintTransformer64);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.05d + "'", double43 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.axis.AxisState axisState3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        categoryPlot9.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke14 = categoryMarker13.getOutlineStroke();
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot9.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13, layer15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot9.getDomainAxisLocation((int) '#');
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        xYPlot23.drawBackgroundImage(graphics2D24, rectangle2D25);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = xYPlot23.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation18, plotOrientation27);
        try {
            java.util.List list29 = dateAxis0.refreshTicks(graphics2D2, axisState3, rectangle2D4, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        org.jfree.chart.plot.Plot plot10 = xYPlot4.getRootPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (byte) -1, (double) 0.5f, (double) 0L, (double) (short) -1);
        double double17 = rectangleInsets15.calculateLeftInset(0.0d);
        double double19 = rectangleInsets15.calculateRightOutset(101.0d);
        xYPlot4.setAxisOffset(rectangleInsets15);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D22 = rectangleInsets15.createOutsetRectangle(rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5d + "'", double17 == 0.5d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        java.lang.String str12 = categoryPlot4.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot4.getDomainAxisEdge(0);
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot19.zoomRangeAxes(0.0d, plotRenderingInfo21, point2D22, false);
        org.jfree.chart.plot.Marker marker26 = null;
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = categoryPlot19.removeDomainMarker((int) (byte) 0, marker26, layer27, false);
        categoryPlot19.setBackgroundAlpha((float) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = null;
        categoryPlot19.setRenderer(categoryItemRenderer32);
        categoryPlot19.clearRangeAxes();
        org.jfree.chart.util.SortOrder sortOrder35 = categoryPlot19.getRowRenderingOrder();
        categoryPlot4.setColumnRenderingOrder(sortOrder35);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(sortOrder35);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setLabelURL("");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double20 = rectangleInsets18.calculateRightInset((double) '4');
        double double22 = rectangleInsets18.extendHeight((double) 1.0f);
        numberAxis13.setLabelInsets(rectangleInsets18);
        boolean boolean24 = numberAxis13.getAutoRangeIncludesZero();
        java.awt.Stroke stroke25 = numberAxis13.getTickMarkStroke();
        java.awt.Paint paint26 = numberAxis13.getTickLabelPaint();
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.0d + "'", double22 == 5.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        java.lang.String str12 = categoryPlot4.getPlotType();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot4.getRendererForDataset(categoryDataset13);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "Category Plot" + "'", str12.equals("Category Plot"));
        org.junit.Assert.assertNull(categoryItemRenderer14);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis1.setCategoryMargin((double) '4');
        float float4 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = null;
        try {
            categoryAxis1.setTickLabelInsets(rectangleInsets5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) '4');
        double double4 = rectangleInsets0.trimWidth((double) 500);
        double double6 = rectangleInsets0.calculateBottomInset((double) 6);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 492.0d + "'", double4 == 492.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        xYPlot4.setRangeCrosshairValue(0.05d);
        xYPlot4.configureRangeAxes();
        org.jfree.chart.annotations.XYAnnotation xYAnnotation21 = null;
        try {
            boolean boolean22 = xYPlot4.removeAnnotation(xYAnnotation21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis1.setCategoryMargin((double) '4');
        java.lang.Comparable comparable4 = null;
        try {
            categoryAxis1.removeCategoryLabelToolTip(comparable4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        org.jfree.data.Range range2 = numberAxis0.getDefaultAutoRange();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        xYPlot8.configureDomainAxes();
        xYPlot8.setRangeCrosshairValue((double) (byte) 0, true);
        java.lang.Class<?> wildcardClass13 = xYPlot8.getClass();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        categoryPlot19.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot19.getDomainAxis((int) (short) 100);
        boolean boolean24 = categoryPlot19.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot(categoryDataset25, categoryAxis26, valueAxis27, categoryItemRenderer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot29.zoomRangeAxes(0.0d, plotRenderingInfo31, point2D32, false);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset35, valueAxis36, valueAxis37, xYItemRenderer38);
        org.jfree.chart.axis.AxisLocation axisLocation41 = null;
        xYPlot39.setDomainAxisLocation((int) '4', axisLocation41);
        boolean boolean44 = xYPlot39.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent45 = null;
        xYPlot39.markerChanged(markerChangeEvent45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double49 = rectangleInsets47.calculateRightInset((double) '4');
        double double51 = rectangleInsets47.extendHeight((double) 1.0f);
        xYPlot39.setAxisOffset(rectangleInsets47);
        xYPlot39.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker56 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot39.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker56);
        categoryPlot29.addDomainMarker(categoryMarker56);
        boolean boolean59 = categoryPlot19.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker56);
        categoryPlot19.setRangeCrosshairValue((double) 100, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer63 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray64 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer63 };
        categoryPlot19.setRenderers(categoryItemRendererArray64);
        org.jfree.chart.axis.AxisLocation axisLocation67 = categoryPlot19.getDomainAxisLocation((int) (short) 100);
        xYPlot8.setDomainAxisLocation((int) ' ', axisLocation67, false);
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.data.category.CategoryDataset categoryDataset71 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = null;
        org.jfree.chart.axis.ValueAxis valueAxis73 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer74 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset71, categoryAxis72, valueAxis73, categoryItemRenderer74);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo77 = null;
        java.awt.geom.Point2D point2D78 = null;
        categoryPlot75.zoomRangeAxes(0.0d, plotRenderingInfo77, point2D78, false);
        org.jfree.chart.plot.Marker marker82 = null;
        org.jfree.chart.util.Layer layer83 = null;
        boolean boolean85 = categoryPlot75.removeDomainMarker((int) (byte) 0, marker82, layer83, false);
        categoryPlot75.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis88 = null;
        categoryPlot75.setDomainAxis((int) (byte) 0, categoryAxis88);
        java.awt.Image image90 = categoryPlot75.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace91 = categoryPlot75.getFixedRangeAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge92 = categoryPlot75.getDomainAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace93 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace94 = numberAxis0.reserveSpace(graphics2D3, (org.jfree.chart.plot.Plot) xYPlot8, rectangle2D70, rectangleEdge92, axisSpace93);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(range2);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNull(categoryAxis23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 4.0d + "'", double49 == 4.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 5.0d + "'", double51 == 5.0d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererArray64);
        org.junit.Assert.assertNotNull(axisLocation67);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertNull(image90);
        org.junit.Assert.assertNull(axisSpace91);
        org.junit.Assert.assertNotNull(rectangleEdge92);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        java.util.TimeZone timeZone1 = null;
        try {
            org.jfree.data.time.Day day2 = new org.jfree.data.time.Day(date0, timeZone1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'zone' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        xYPlot6.drawBackgroundImage(graphics2D7, rectangle2D8);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]");
        xYPlot6.setDomainAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.jfree.chart.plot.Plot plot15 = null;
        numberAxis13.setPlot(plot15);
        numberAxis13.setPositiveArrowVisible(true);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace11, false);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot4.getLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot4.getRangeAxisEdge();
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot4.getDomainAxisEdge();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot4.setRangeZeroBaselineStroke(stroke16);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker2.setLabelPaint(paint3);
        java.lang.Comparable comparable5 = categoryMarker2.getKey();
        org.jfree.chart.util.Layer layer6 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker2, layer6);
        categoryPlot0.clearAnnotations();
        double double9 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (byte) 0 + "'", comparable5.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setFixedAutoRange((double) 100);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = numberAxis13.getMarkerBand();
        numberAxis13.setLowerBound((double) 1);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNull(markerAxisBand18);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup6 = xYPlot4.getDatasetGroup();
        xYPlot4.configureRangeAxes();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot(categoryDataset9, categoryAxis10, valueAxis11, categoryItemRenderer12);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot13.zoomRangeAxes(0.0d, plotRenderingInfo15, point2D16, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        categoryPlot13.setDomainAxis((int) 'a', categoryAxis20, false);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        int int24 = categoryPlot13.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis23);
        numberAxis23.setRangeAboutValue((double) (byte) 0, 0.0d);
        double double28 = numberAxis23.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        xYPlot33.drawBackgroundImage(graphics2D34, rectangle2D35);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = xYPlot33.getRendererForDataset(xYDataset37);
        xYPlot33.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis();
        int int43 = xYPlot33.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis42);
        double double44 = numberAxis42.getUpperBound();
        numberAxis42.setLabelURL("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset8, (org.jfree.chart.axis.ValueAxis) numberAxis23, (org.jfree.chart.axis.ValueAxis) numberAxis42, xYItemRenderer47);
        xYPlot48.setDomainCrosshairVisible(false);
        xYPlot4.setParent((org.jfree.chart.plot.Plot) xYPlot48);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer53 = null;
        xYPlot48.setRenderer(500, xYItemRenderer53);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer38);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.0d + "'", double44 == 1.0d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace11, false);
        java.awt.Stroke stroke14 = categoryPlot4.getRangeCrosshairStroke();
        float float15 = categoryPlot4.getBackgroundImageAlpha();
        boolean boolean16 = categoryPlot4.isOutlineVisible();
        float float17 = categoryPlot4.getForegroundAlpha();
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 1.0f + "'", float17 == 1.0f);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        xYPlot4.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker21);
        org.jfree.chart.JFreeChart jFreeChart23 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent24 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryMarker21, jFreeChart23);
        categoryMarker21.setDrawAsLine(false);
        java.lang.Comparable comparable27 = categoryMarker21.getKey();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
        org.junit.Assert.assertTrue("'" + comparable27 + "' != '" + (byte) 0 + "'", comparable27.equals((byte) 0));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        categoryPlot4.setNoDataMessage("hi!");
        boolean boolean12 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        xYPlot18.drawBackgroundImage(graphics2D19, rectangle2D20);
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = xYPlot18.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        categoryPlot28.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke33 = categoryMarker32.getOutlineStroke();
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean35 = categoryPlot28.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker32, layer34);
        java.lang.Comparable comparable36 = categoryMarker32.getKey();
        java.awt.Paint paint37 = categoryMarker32.getPaint();
        org.jfree.chart.util.Layer layer38 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot18.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker32, layer38);
        java.lang.String str40 = layer38.toString();
        try {
            categoryPlot4.addDomainMarker(categoryMarker13, layer38);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + comparable36 + "' != '" + (byte) 0 + "'", comparable36.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(layer38);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "Layer.FOREGROUND" + "'", str40.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = xYPlot4.getRendererForDataset(xYDataset7);
        xYPlot4.configureDomainAxes();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(xYItemRenderer8);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        xYPlot4.setRangeAxisLocation((int) 'a', axisLocation11);
        boolean boolean13 = xYPlot4.isDomainZeroBaselineVisible();
        java.awt.Font font14 = xYPlot4.getNoDataMessageFont();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        categoryPlot19.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke24 = categoryMarker23.getOutlineStroke();
        org.jfree.chart.util.Layer layer25 = null;
        boolean boolean26 = categoryPlot19.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker23, layer25);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder27 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot19.setDatasetRenderingOrder(datasetRenderingOrder27);
        xYPlot4.setDatasetRenderingOrder(datasetRenderingOrder27);
        org.jfree.chart.plot.Marker marker30 = null;
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset31, valueAxis32, valueAxis33, xYItemRenderer34);
        xYPlot35.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup37 = xYPlot35.getDatasetGroup();
        boolean boolean38 = xYPlot35.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset40, valueAxis41, valueAxis42, xYItemRenderer43);
        java.awt.Graphics2D graphics2D45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        xYPlot44.drawBackgroundImage(graphics2D45, rectangle2D46);
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = xYPlot44.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset50 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, categoryAxis51, valueAxis52, categoryItemRenderer53);
        categoryPlot54.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker58 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke59 = categoryMarker58.getOutlineStroke();
        org.jfree.chart.util.Layer layer60 = null;
        boolean boolean61 = categoryPlot54.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker58, layer60);
        java.lang.Comparable comparable62 = categoryMarker58.getKey();
        java.awt.Paint paint63 = categoryMarker58.getPaint();
        org.jfree.chart.util.Layer layer64 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot44.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker58, layer64);
        java.util.Collection collection66 = xYPlot35.getRangeMarkers((int) (short) 100, layer64);
        try {
            xYPlot4.addDomainMarker(marker30, layer64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder27);
        org.junit.Assert.assertNull(datasetGroup37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(plotOrientation48);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + comparable62 + "' != '" + (byte) 0 + "'", comparable62.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint63);
        org.junit.Assert.assertNotNull(layer64);
        org.junit.Assert.assertNull(collection66);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        numberAxis14.centerRange((double) 0L);
        numberAxis14.setAutoRangeIncludesZero(true);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = categoryPlot25.getRenderer(10);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = null;
        org.jfree.chart.plot.XYPlot xYPlot33 = new org.jfree.chart.plot.XYPlot(xYDataset29, valueAxis30, valueAxis31, xYItemRenderer32);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        xYPlot33.drawBackgroundImage(graphics2D34, rectangle2D35);
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = xYPlot33.getRendererForDataset(xYDataset37);
        xYPlot33.mapDatasetToRangeAxis((int) (short) 1, 0);
        xYPlot33.setWeight((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation44 = xYPlot33.getRangeAxisLocation();
        categoryPlot25.setRangeAxisLocation((int) (short) 10, axisLocation44, true);
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, valueAxis50, categoryItemRenderer51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        categoryPlot52.zoomRangeAxes(0.0d, plotRenderingInfo54, point2D55, false);
        org.jfree.chart.plot.Marker marker59 = null;
        org.jfree.chart.util.Layer layer60 = null;
        boolean boolean62 = categoryPlot52.removeDomainMarker((int) (byte) 0, marker59, layer60, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray63 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot52.setRangeAxes(valueAxisArray63);
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = categoryPlot52.getDomainAxisEdge(1);
        org.jfree.chart.axis.AxisSpace axisSpace67 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace68 = numberAxis14.reserveSpace(graphics2D20, (org.jfree.chart.plot.Plot) categoryPlot25, rectangle2D47, rectangleEdge66, axisSpace67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(categoryItemRenderer27);
        org.junit.Assert.assertNull(xYItemRenderer38);
        org.junit.Assert.assertNotNull(axisLocation44);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(valueAxisArray63);
        org.junit.Assert.assertNotNull(rectangleEdge66);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = xYPlot4.getLegendItems();
        java.awt.Paint paint8 = xYPlot4.getNoDataMessagePaint();
        xYPlot4.clearRangeMarkers();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.java2DToValue((double) 10.0f, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.Timeline timeline5 = dateAxis0.getTimeline();
        try {
            dateAxis0.setRange((double) (byte) 0, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.223372036854776E18d + "'", double4 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(timeline5);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker2.setLabelPaint(paint3);
        java.lang.Comparable comparable5 = categoryMarker2.getKey();
        org.jfree.chart.util.Layer layer6 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker2, layer6);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (byte) 0 + "'", comparable5.equals((byte) 0));
        org.junit.Assert.assertNull(legendItemCollection9);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Stroke stroke8 = xYPlot4.getDomainZeroBaselineStroke();
        java.awt.Paint paint9 = xYPlot4.getDomainZeroBaselinePaint();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        int int10 = xYPlot4.getSeriesCount();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace13);
        org.jfree.chart.axis.ValueAxis valueAxis15 = xYPlot4.getRangeAxis();
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(valueAxis15);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis0.setTickUnit(dateTickUnit2, false, true);
        dateAxis0.setRange((double) (byte) 1, (double) 10);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition9 = null;
        try {
            dateAxis0.setTickMarkPosition(dateTickMarkPosition9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateFormat1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        int int15 = categoryPlot4.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot4.getDataset();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        xYPlot21.setDomainAxisLocation((int) '4', axisLocation23);
        boolean boolean26 = xYPlot21.equals((java.lang.Object) 1.0f);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        categoryPlot31.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke36 = categoryMarker35.getOutlineStroke();
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker35, layer37);
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot31.getDomainAxisLocation((int) '#');
        xYPlot21.setDomainAxisLocation(axisLocation40, false);
        categoryPlot4.setRangeAxisLocation(axisLocation40, true);
        org.jfree.chart.axis.AxisLocation axisLocation45 = categoryPlot4.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(axisLocation45);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot21.drawBackgroundImage(graphics2D22, rectangle2D23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot21.getRendererForDataset(xYDataset25);
        xYPlot21.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        int int31 = xYPlot21.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis30);
        double double32 = numberAxis30.getUpperBound();
        numberAxis30.setLabelURL("");
        java.awt.Font font35 = numberAxis30.getLabelFont();
        numberAxis14.setTickLabelFont(font35);
        java.lang.String str37 = numberAxis14.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = null;
        numberAxis14.setMarkerBand(markerAxisBand38);
        numberAxis14.setAutoTickUnitSelection(true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNull(str37);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setAnchorValue((double) 2.0f, false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean8 = xYPlot4.isRangeZoomable();
        boolean boolean9 = xYPlot4.isRangeZeroBaselineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot14.zoomRangeAxes(0.0d, plotRenderingInfo16, point2D17, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot14.setDomainAxis((int) 'a', categoryAxis21, false);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        int int25 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis24);
        numberAxis24.centerRange((double) 0L);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis24.setTickUnit(numberTickUnit28, false, false);
        xYPlot4.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis24);
        double double33 = numberAxis24.getLabelAngle();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset34, valueAxis35, valueAxis36, xYItemRenderer37);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        xYPlot38.drawBackgroundImage(graphics2D39, rectangle2D40);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = xYPlot38.getRendererForDataset(xYDataset42);
        int int44 = xYPlot38.getSeriesCount();
        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
        xYPlot38.setFixedRangeAxisSpace(axisSpace45);
        org.jfree.chart.axis.AxisSpace axisSpace47 = null;
        xYPlot38.setFixedDomainAxisSpace(axisSpace47);
        org.jfree.chart.axis.ValueAxis valueAxis49 = xYPlot38.getDomainAxis();
        java.awt.Paint paint50 = xYPlot38.getDomainGridlinePaint();
        numberAxis24.setLabelPaint(paint50);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(numberTickUnit28);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNull(valueAxis49);
        org.junit.Assert.assertNotNull(paint50);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 5.0d, "org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]");
        java.awt.Paint paint8 = null;
        try {
            categoryAxis1.setTickMarkPaint(paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot6.setDomainAxisLocation((int) '4', axisLocation8);
        boolean boolean11 = xYPlot6.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot6.markerChanged(markerChangeEvent12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double16 = rectangleInsets14.calculateRightInset((double) '4');
        double double18 = rectangleInsets14.extendHeight((double) 1.0f);
        xYPlot6.setAxisOffset(rectangleInsets14);
        xYPlot6.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker23);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYPlot30.drawBackgroundImage(graphics2D31, rectangle2D32);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = xYPlot30.getRendererForDataset(xYDataset34);
        xYPlot30.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        int int40 = xYPlot30.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis39);
        double double41 = numberAxis39.getUpperBound();
        numberAxis39.setFixedAutoRange((double) 100);
        xYPlot6.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis39);
        numberAxis39.setUpperBound((-1.0d));
        java.awt.Stroke stroke47 = numberAxis39.getTickMarkStroke();
        dateAxis0.setAxisLineStroke(stroke47);
        dateAxis0.configure();
        dateAxis0.configure();
        java.lang.Object obj51 = dateAxis0.clone();
        org.jfree.chart.axis.DateTickUnit dateTickUnit52 = null;
        dateAxis0.setTickUnit(dateTickUnit52);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 5.0d + "'", double18 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(obj51);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        float float17 = numberAxis14.getTickMarkOutsideLength();
        try {
            numberAxis14.setAutoRangeMinimumSize((double) (byte) -1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot4.getOrientation();
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace9, false);
        org.junit.Assert.assertNotNull(plotOrientation8);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (-3.0d), (double) 6, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup6 = xYPlot4.getDatasetGroup();
        xYPlot4.configureRangeAxes();
        org.jfree.chart.axis.ValueAxis valueAxis9 = xYPlot4.getDomainAxis(10);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNull(valueAxis9);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        xYPlot4.setRangeCrosshairValue(0.05d);
        java.awt.Paint paint20 = xYPlot4.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        categoryPlot4.setNoDataMessage("hi!");
        java.awt.Stroke stroke12 = categoryPlot4.getRangeCrosshairStroke();
        org.jfree.chart.plot.Marker marker13 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker(marker13);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setLabelURL("");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double20 = rectangleInsets18.calculateRightInset((double) '4');
        double double22 = rectangleInsets18.extendHeight((double) 1.0f);
        numberAxis13.setLabelInsets(rectangleInsets18);
        boolean boolean24 = numberAxis13.getAutoRangeIncludesZero();
        java.awt.Stroke stroke25 = numberAxis13.getTickMarkStroke();
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis13, jFreeChart26, chartChangeEventType27);
        java.lang.Object obj29 = chartChangeEvent28.getSource();
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.0d + "'", double22 == 5.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(chartChangeEventType27);
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) unitType0, jFreeChart1, chartChangeEventType2);
        java.lang.String str4 = chartChangeEvent3.toString();
        org.jfree.chart.JFreeChart jFreeChart5 = chartChangeEvent3.getChart();
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        chartChangeEvent3.setChart(jFreeChart6);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]" + "'", str4.equals("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]"));
        org.junit.Assert.assertNull(jFreeChart5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Paint paint0 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.java2DToValue((double) 10.0f, rectangle2D2, rectangleEdge3);
        java.lang.Object obj5 = dateAxis0.clone();
        org.jfree.chart.axis.Timeline timeline6 = dateAxis0.getTimeline();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.223372036854776E18d + "'", double4 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(timeline6);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        java.util.Calendar calendar2 = null;
        try {
            long long3 = day1.getFirstMillisecond(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        org.jfree.chart.LegendItemCollection legendItemCollection18 = xYPlot4.getFixedLegendItems();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        xYPlot25.drawBackgroundImage(graphics2D26, rectangle2D27);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = xYPlot25.getRendererForDataset(xYDataset29);
        xYPlot25.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        xYPlot25.setRenderer((int) (short) 10, xYItemRenderer35, true);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot(categoryDataset40, categoryAxis41, valueAxis42, categoryItemRenderer43);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        java.awt.geom.Point2D point2D47 = null;
        categoryPlot44.zoomRangeAxes(0.0d, plotRenderingInfo46, point2D47, false);
        org.jfree.chart.plot.Marker marker51 = null;
        org.jfree.chart.util.Layer layer52 = null;
        boolean boolean54 = categoryPlot44.removeDomainMarker((int) (byte) 0, marker51, layer52, false);
        categoryPlot44.setBackgroundAlpha((float) 0);
        org.jfree.chart.axis.ValueAxis valueAxis58 = categoryPlot44.getRangeAxis(0);
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot(xYDataset59, valueAxis60, valueAxis61, xYItemRenderer62);
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = xYPlot63.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace66 = null;
        xYPlot63.setFixedRangeAxisSpace(axisSpace66);
        java.awt.Paint paint68 = xYPlot63.getDomainGridlinePaint();
        categoryPlot44.setParent((org.jfree.chart.plot.Plot) xYPlot63);
        org.jfree.chart.axis.CategoryAxis categoryAxis70 = null;
        java.util.List list71 = categoryPlot44.getCategoriesForAxis(categoryAxis70);
        xYPlot25.drawRangeTickBands(graphics2D38, rectangle2D39, list71);
        xYPlot4.drawDomainTickBands(graphics2D19, rectangle2D20, list71);
        int int74 = xYPlot4.getDomainAxisCount();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo76 = null;
        org.jfree.data.xy.XYDataset xYDataset77 = null;
        org.jfree.chart.axis.ValueAxis valueAxis78 = null;
        org.jfree.chart.axis.ValueAxis valueAxis79 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer80 = null;
        org.jfree.chart.plot.XYPlot xYPlot81 = new org.jfree.chart.plot.XYPlot(xYDataset77, valueAxis78, valueAxis79, xYItemRenderer80);
        org.jfree.chart.axis.AxisLocation axisLocation83 = null;
        xYPlot81.setDomainAxisLocation((int) '4', axisLocation83);
        boolean boolean86 = xYPlot81.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent87 = null;
        xYPlot81.markerChanged(markerChangeEvent87);
        org.jfree.chart.util.RectangleInsets rectangleInsets89 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double91 = rectangleInsets89.calculateRightInset((double) '4');
        double double93 = rectangleInsets89.extendHeight((double) 1.0f);
        xYPlot81.setAxisOffset(rectangleInsets89);
        java.awt.geom.Point2D point2D95 = xYPlot81.getQuadrantOrigin();
        xYPlot4.zoomDomainAxes((double) (byte) -1, plotRenderingInfo76, point2D95, false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
        org.junit.Assert.assertNull(legendItemCollection18);
        org.junit.Assert.assertNull(xYItemRenderer30);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNull(valueAxis58);
        org.junit.Assert.assertNotNull(rectangleEdge65);
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(list71);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(rectangleInsets89);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 4.0d + "'", double91 == 4.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 5.0d + "'", double93 == 5.0d);
        org.junit.Assert.assertNotNull(point2D95);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis3.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis3.configure();
        double double8 = categoryAxis3.getCategoryMargin();
        int int9 = categoryAxis3.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat11 = dateAxis10.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis10.setTickUnit(dateTickUnit12, false, true);
        dateAxis10.setRange((double) (byte) 1, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        double double22 = numberAxis21.getUpperBound();
        java.awt.Color color23 = java.awt.Color.WHITE;
        numberAxis21.setTickMarkPaint((java.awt.Paint) color23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer25);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = org.jfree.chart.axis.CategoryAnchor.END;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot32.zoomRangeAxes(0.0d, plotRenderingInfo34, point2D35, false);
        org.jfree.chart.plot.Marker marker39 = null;
        org.jfree.chart.util.Layer layer40 = null;
        boolean boolean42 = categoryPlot32.removeDomainMarker((int) (byte) 0, marker39, layer40, false);
        categoryPlot32.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = null;
        java.awt.geom.Point2D point2D48 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D46, rectangleAnchor47);
        categoryPlot32.zoomDomainAxes((double) 0L, plotRenderingInfo45, point2D48, false);
        boolean boolean51 = categoryAnchor27.equals((java.lang.Object) point2D48);
        java.awt.geom.Rectangle2D rectangle2D54 = null;
        org.jfree.data.xy.XYDataset xYDataset55 = null;
        org.jfree.chart.axis.ValueAxis valueAxis56 = null;
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = null;
        org.jfree.chart.plot.XYPlot xYPlot59 = new org.jfree.chart.plot.XYPlot(xYDataset55, valueAxis56, valueAxis57, xYItemRenderer58);
        java.awt.Graphics2D graphics2D60 = null;
        java.awt.geom.Rectangle2D rectangle2D61 = null;
        xYPlot59.drawBackgroundImage(graphics2D60, rectangle2D61);
        org.jfree.data.xy.XYDataset xYDataset63 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer64 = xYPlot59.getRendererForDataset(xYDataset63);
        int int65 = xYPlot59.getSeriesCount();
        org.jfree.chart.axis.AxisSpace axisSpace66 = null;
        xYPlot59.setFixedRangeAxisSpace(axisSpace66);
        org.jfree.chart.axis.AxisSpace axisSpace68 = null;
        xYPlot59.setFixedDomainAxisSpace(axisSpace68);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = xYPlot59.getRangeAxisEdge();
        try {
            double double71 = categoryAxis3.getCategoryJava2DCoordinate(categoryAnchor27, (int) (byte) -1, 1, rectangle2D54, rectangleEdge70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(dateFormat11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(categoryAnchor27);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(point2D48);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(xYItemRenderer64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge70);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        numberAxis14.centerRange((double) 0L);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset22, valueAxis23, valueAxis24, xYItemRenderer25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        xYPlot26.drawBackgroundImage(graphics2D27, rectangle2D28);
        org.jfree.data.xy.XYDataset xYDataset30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = xYPlot26.getRendererForDataset(xYDataset30);
        int int32 = xYPlot26.getSeriesCount();
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        xYPlot26.setFixedRangeAxisSpace(axisSpace33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        xYPlot26.setFixedDomainAxisSpace(axisSpace35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot26.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        try {
            org.jfree.chart.axis.AxisState axisState39 = numberAxis14.draw(graphics2D18, 0.0d, rectangle2D20, rectangle2D21, rectangleEdge37, plotRenderingInfo38);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot4.setRenderer(categoryItemRenderer17);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation19 = null;
        try {
            boolean boolean21 = categoryPlot4.removeAnnotation(categoryAnnotation19, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        java.awt.Stroke stroke16 = categoryPlot4.getDomainGridlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) (byte) -1, (double) 0.5f, (double) 0L, (double) (short) -1);
        double double23 = rectangleInsets21.calculateLeftInset(0.0d);
        categoryPlot4.setInsets(rectangleInsets21, false);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYPlot30.drawBackgroundImage(graphics2D31, rectangle2D32);
        java.awt.Paint paint34 = xYPlot30.getRangeGridlinePaint();
        boolean boolean35 = rectangleInsets21.equals((java.lang.Object) xYPlot30);
        boolean boolean36 = xYPlot30.isDomainZeroBaselineVisible();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.5d + "'", double23 == 0.5d);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot4.setRenderer(categoryItemRenderer17);
        java.util.List list19 = categoryPlot4.getCategories();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int21 = color20.getAlpha();
        categoryPlot4.setOutlinePaint((java.awt.Paint) color20);
        categoryPlot4.clearDomainMarkers(0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(list19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.plot.IntervalMarker intervalMarker15 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        org.jfree.chart.util.Layer layer16 = null;
        xYPlot4.addRangeMarker((int) (short) -1, (org.jfree.chart.plot.Marker) intervalMarker15, layer16);
        double double18 = intervalMarker15.getEndValue();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        categoryPlot23.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke28 = categoryMarker27.getOutlineStroke();
        org.jfree.chart.util.Layer layer29 = null;
        boolean boolean30 = categoryPlot23.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker27, layer29);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder31 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot23.setDatasetRenderingOrder(datasetRenderingOrder31);
        boolean boolean33 = intervalMarker15.equals((java.lang.Object) datasetRenderingOrder31);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18 == (-1.0d));
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, Double.NaN, (double) '4', rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot4.setRenderer(categoryItemRenderer17);
        java.util.List list19 = categoryPlot4.getCategories();
        java.util.List list20 = categoryPlot4.getAnnotations();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(list19);
        org.junit.Assert.assertNotNull(list20);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) unitType0, jFreeChart1, chartChangeEventType2);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType0, 0.0d, (double) 'a', 0.0d, (double) 'a');
        java.lang.String str9 = unitType0.toString();
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "UnitType.RELATIVE" + "'", str9.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EXPAND" + "'", str1.equals("EXPAND"));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        xYPlot4.zoomRangeAxes(4.0d, plotRenderingInfo14, point2D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot4.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot24.zoomRangeAxes(0.0d, plotRenderingInfo26, point2D27, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        categoryPlot24.setDomainAxis((int) 'a', categoryAxis31, false);
        xYPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot24);
        boolean boolean35 = xYPlot4.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke36 = xYPlot4.getDomainZeroBaselineStroke();
        org.jfree.chart.plot.IntervalMarker intervalMarker39 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        double double40 = intervalMarker39.getEndValue();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent41 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker39);
        org.jfree.chart.plot.Marker marker42 = markerChangeEvent41.getMarker();
        xYPlot4.markerChanged(markerChangeEvent41);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + (-1.0d) + "'", double40 == (-1.0d));
        org.junit.Assert.assertNotNull(marker42);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis2.configure();
        double double7 = categoryAxis2.getCategoryMargin();
        int int8 = categoryAxis2.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat10 = dateAxis9.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis9.setTickUnit(dateTickUnit11, false, true);
        dateAxis9.setRange((double) (byte) 1, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer18);
        dateAxis9.setFixedDimension((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(dateFormat10);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        categoryPlot4.mapDatasetToDomainAxis((int) ' ', (int) '4');
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot21.drawBackgroundImage(graphics2D22, rectangle2D23);
        java.awt.Stroke stroke25 = xYPlot21.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot21.getRangeAxis(10);
        xYPlot21.setDomainCrosshairValue(0.0d, false);
        numberAxis14.setPlot((org.jfree.chart.plot.Plot) xYPlot21);
        java.awt.geom.Point2D point2D32 = xYPlot21.getQuadrantOrigin();
        boolean boolean33 = xYPlot21.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYPlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot5.getRendererForDataset(xYDataset9);
        xYPlot5.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot5.zoomRangeAxes(4.0d, plotRenderingInfo15, point2D18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot5.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot25.zoomRangeAxes(0.0d, plotRenderingInfo27, point2D28, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot25.setDomainAxis((int) 'a', categoryAxis32, false);
        xYPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot25);
        boolean boolean36 = datasetRenderingOrder0.equals((java.lang.Object) xYPlot5);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        xYPlot5.setDataset(1, xYDataset38);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation40 = null;
        try {
            boolean boolean42 = xYPlot5.removeAnnotation(xYAnnotation40, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = xYPlot4.getLegendItems();
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray8 = new org.jfree.chart.renderer.xy.XYItemRenderer[] {};
        xYPlot4.setRenderers(xYItemRendererArray8);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(xYItemRendererArray8);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        int int10 = xYPlot4.getSeriesCount();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot4.getRangeAxisEdge();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot4.removeChangeListener(plotChangeListener16);
        float float18 = xYPlot4.getBackgroundAlpha();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            xYPlot4.drawBackground(graphics2D19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + float18 + "' != '" + 1.0f + "'", float18 == 1.0f);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        dateAxis0.setAutoTickUnitSelection(false);
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition4 = null;
        try {
            dateAxis0.setTickMarkPosition(dateTickMarkPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateFormat1);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("PlotOrientation.HORIZONTAL");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis1.configure();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot10.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = xYPlot10.getLegendItems();
        boolean boolean14 = categoryAxis1.equals((java.lang.Object) legendItemCollection13);
        categoryAxis1.setCategoryLabelPositionOffset(0);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.AxisState axisState18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, valueAxis22, xYItemRenderer23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        xYPlot24.drawBackgroundImage(graphics2D25, rectangle2D26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot24.getDomainAxisEdge((int) (short) 0);
        try {
            java.util.List list30 = categoryAxis1.refreshTicks(graphics2D17, axisState18, rectangle2D19, rectangleEdge29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        xYPlot4.zoomRangeAxes(4.0d, plotRenderingInfo14, point2D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot4.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot24.zoomRangeAxes(0.0d, plotRenderingInfo26, point2D27, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        categoryPlot24.setDomainAxis((int) 'a', categoryAxis31, false);
        xYPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot24);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace35, true);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.LEFT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 5.0d, (double) 5, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.java2DToValue((double) 10.0f, rectangle2D2, rectangleEdge3);
        org.jfree.chart.axis.Timeline timeline5 = dateAxis0.getTimeline();
        java.lang.String str6 = dateAxis0.getLabel();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.223372036854776E18d + "'", double4 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(timeline5);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            xYPlot4.handleClick(500, (int) (byte) 10, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup6 = xYPlot4.getDatasetGroup();
        xYPlot4.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot4.getRangeAxisLocation((-1));
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot15.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        xYPlot15.setFixedRangeAxisSpace(axisSpace18);
        java.awt.Paint paint20 = xYPlot15.getDomainGridlinePaint();
        boolean boolean21 = xYPlot15.isDomainCrosshairVisible();
        boolean boolean22 = xYPlot15.isRangeZeroBaselineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot27.zoomRangeAxes(0.0d, plotRenderingInfo29, point2D30, false);
        org.jfree.chart.plot.Marker marker34 = null;
        org.jfree.chart.util.Layer layer35 = null;
        boolean boolean37 = categoryPlot27.removeDomainMarker((int) (byte) 0, marker34, layer35, false);
        int int38 = categoryPlot27.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset39 = categoryPlot27.getDataset();
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset40, valueAxis41, valueAxis42, xYItemRenderer43);
        org.jfree.chart.axis.AxisLocation axisLocation46 = null;
        xYPlot44.setDomainAxisLocation((int) '4', axisLocation46);
        boolean boolean49 = xYPlot44.equals((java.lang.Object) 1.0f);
        org.jfree.data.category.CategoryDataset categoryDataset50 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, categoryAxis51, valueAxis52, categoryItemRenderer53);
        categoryPlot54.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker58 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke59 = categoryMarker58.getOutlineStroke();
        org.jfree.chart.util.Layer layer60 = null;
        boolean boolean61 = categoryPlot54.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker58, layer60);
        org.jfree.chart.axis.AxisLocation axisLocation63 = categoryPlot54.getDomainAxisLocation((int) '#');
        xYPlot44.setDomainAxisLocation(axisLocation63, false);
        categoryPlot27.setRangeAxisLocation(axisLocation63, true);
        xYPlot15.setRangeAxisLocation(axisLocation63);
        xYPlot4.setRangeAxisLocation((int) (byte) 100, axisLocation63);
        int int70 = xYPlot4.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(axisLocation63);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 15 + "'", int70 == 15);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setLabelURL("");
        boolean boolean18 = numberAxis13.isNegativeArrowVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis13.getLabelInsets();
        numberAxis13.zoomRange(0.5d, (double) 100);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        java.awt.Image image17 = categoryPlot4.getBackgroundImage();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis19.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis19.configure();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        org.jfree.chart.util.RectangleEdge rectangleEdge30 = xYPlot28.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.LegendItemCollection legendItemCollection31 = xYPlot28.getLegendItems();
        boolean boolean32 = categoryAxis19.equals((java.lang.Object) legendItemCollection31);
        categoryPlot4.setDomainAxis(categoryAxis19);
        java.awt.Graphics2D graphics2D34 = null;
        java.awt.geom.Rectangle2D rectangle2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = null;
        org.jfree.chart.plot.XYPlot xYPlot42 = new org.jfree.chart.plot.XYPlot(xYDataset38, valueAxis39, valueAxis40, xYItemRenderer41);
        org.jfree.chart.util.RectangleEdge rectangleEdge44 = xYPlot42.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace45 = null;
        xYPlot42.setFixedRangeAxisSpace(axisSpace45);
        java.awt.Paint paint47 = xYPlot42.getDomainGridlinePaint();
        boolean boolean48 = xYPlot42.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = xYPlot42.getRangeAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        try {
            org.jfree.chart.axis.AxisState axisState52 = categoryAxis19.draw(graphics2D34, (double) 6, rectangle2D36, rectangle2D37, rectangleEdge50, plotRenderingInfo51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(image17);
        org.junit.Assert.assertNotNull(rectangleEdge30);
        org.junit.Assert.assertNotNull(legendItemCollection31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleEdge44);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        org.jfree.data.RangeType rangeType16 = null;
        try {
            numberAxis13.setRangeType(rangeType16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rangeType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Layer.FOREGROUND");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomRangeAxes(0.0d, plotRenderingInfo8, point2D9, false);
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        boolean boolean16 = categoryPlot6.removeDomainMarker((int) (byte) 0, marker13, layer14, false);
        categoryPlot6.setBackgroundAlpha((float) 0);
        categoryPlot6.setRangeCrosshairValue((double) 100.0f);
        categoryPlot6.setAnchorValue((double) (byte) 1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor23 = org.jfree.chart.axis.CategoryAnchor.END;
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot28.zoomRangeAxes(0.0d, plotRenderingInfo30, point2D31, false);
        org.jfree.chart.plot.Marker marker35 = null;
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean38 = categoryPlot28.removeDomainMarker((int) (byte) 0, marker35, layer36, false);
        categoryPlot28.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = null;
        java.awt.geom.Point2D point2D44 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D42, rectangleAnchor43);
        categoryPlot28.zoomDomainAxes((double) 0L, plotRenderingInfo41, point2D44, false);
        boolean boolean47 = categoryAnchor23.equals((java.lang.Object) point2D44);
        categoryPlot6.setDomainGridlinePosition(categoryAnchor23);
        java.lang.String str49 = categoryAnchor23.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation50 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str51 = plotOrientation50.toString();
        boolean boolean52 = categoryAnchor23.equals((java.lang.Object) plotOrientation50);
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis57, valueAxis58, categoryItemRenderer59);
        categoryPlot60.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker64 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke65 = categoryMarker64.getOutlineStroke();
        org.jfree.chart.util.Layer layer66 = null;
        boolean boolean67 = categoryPlot60.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker64, layer66);
        org.jfree.chart.axis.AxisLocation axisLocation69 = categoryPlot60.getDomainAxisLocation((int) '#');
        org.jfree.data.xy.XYDataset xYDataset70 = null;
        org.jfree.chart.axis.ValueAxis valueAxis71 = null;
        org.jfree.chart.axis.ValueAxis valueAxis72 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer73 = null;
        org.jfree.chart.plot.XYPlot xYPlot74 = new org.jfree.chart.plot.XYPlot(xYDataset70, valueAxis71, valueAxis72, xYItemRenderer73);
        java.awt.Graphics2D graphics2D75 = null;
        java.awt.geom.Rectangle2D rectangle2D76 = null;
        xYPlot74.drawBackgroundImage(graphics2D75, rectangle2D76);
        org.jfree.chart.plot.PlotOrientation plotOrientation78 = xYPlot74.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge79 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation69, plotOrientation78);
        try {
            double double80 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor23, (int) (byte) 0, 9, rectangle2D55, rectangleEdge79);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(categoryAnchor23);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(point2D44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "CategoryAnchor.END" + "'", str49.equals("CategoryAnchor.END"));
        org.junit.Assert.assertNotNull(plotOrientation50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str51.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(axisLocation69);
        org.junit.Assert.assertNotNull(plotOrientation78);
        org.junit.Assert.assertNotNull(rectangleEdge79);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot4.getDomainAxis((int) (short) 100);
        boolean boolean9 = categoryPlot4.isRangeGridlinesVisible();
        java.awt.Paint paint10 = categoryPlot4.getRangeCrosshairPaint();
        int int11 = categoryPlot4.getDatasetCount();
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        categoryPlot18.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke23 = categoryMarker22.getOutlineStroke();
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean25 = categoryPlot18.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker22, layer24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = categoryPlot18.getDomainAxisLocation((int) '#');
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        xYPlot32.drawBackgroundImage(graphics2D33, rectangle2D34);
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = xYPlot32.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation27, plotOrientation36);
        org.jfree.chart.axis.AxisLocation axisLocation38 = axisLocation27.getOpposite();
        categoryPlot4.setDomainAxisLocation(axisLocation27, false);
        org.jfree.chart.LegendItemCollection legendItemCollection41 = categoryPlot4.getFixedLegendItems();
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertNotNull(plotOrientation36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(axisLocation38);
        org.junit.Assert.assertNull(legendItemCollection41);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = xYPlot4.getRendererForDataset(xYDataset7);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        int int10 = xYPlot4.getIndexOf(xYItemRenderer9);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(xYItemRenderer8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot4.setDomainAxis((int) (byte) 0, categoryAxis17);
        java.awt.Image image19 = categoryPlot4.getBackgroundImage();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis22.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis22.configure();
        double double27 = categoryAxis22.getCategoryMargin();
        int int28 = categoryAxis22.getMaximumCategoryLabelLines();
        try {
            categoryPlot4.setDomainAxis((int) (short) -1, categoryAxis22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.2d + "'", double27 == 0.2d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = categoryPlot4.getRenderer(10);
        categoryPlot4.setDrawSharedDomainAxis(false);
        categoryPlot4.clearDomainAxes();
        org.jfree.chart.LegendItemCollection legendItemCollection10 = categoryPlot4.getFixedLegendItems();
        java.awt.Paint paint11 = null;
        try {
            categoryPlot4.setRangeCrosshairPaint(paint11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer6);
        org.junit.Assert.assertNull(legendItemCollection10);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        boolean boolean2 = numberAxis0.isAutoRange();
        boolean boolean3 = numberAxis0.isVisible();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot(categoryDataset4, categoryAxis5, valueAxis6, categoryItemRenderer7);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot8.zoomRangeAxes(0.0d, plotRenderingInfo10, point2D11, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        categoryPlot8.setDomainAxis((int) 'a', categoryAxis15, false);
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot(categoryDataset18, categoryAxis19, valueAxis20, categoryItemRenderer21);
        categoryPlot22.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker26 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke27 = categoryMarker26.getOutlineStroke();
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean29 = categoryPlot22.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker26, layer28);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot22.getDomainAxisLocation((int) '#');
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        xYPlot36.drawBackgroundImage(graphics2D37, rectangle2D38);
        org.jfree.chart.plot.PlotOrientation plotOrientation40 = xYPlot36.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation31, plotOrientation40);
        org.jfree.chart.axis.AxisLocation axisLocation42 = axisLocation31.getOpposite();
        categoryPlot8.setDomainAxisLocation(axisLocation31, false);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot8);
        numberAxis0.setTickLabelsVisible(false);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(plotOrientation40);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertNotNull(axisLocation42);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        java.util.Calendar calendar1 = null;
        try {
            long long2 = day0.getLastMillisecond(calendar1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        numberAxis13.setAutoRangeStickyZero(false);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        xYPlot21.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, valueAxis25, xYItemRenderer26);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot27.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace30 = null;
        xYPlot27.setFixedRangeAxisSpace(axisSpace30);
        java.awt.Paint paint32 = xYPlot27.getDomainCrosshairPaint();
        xYPlot21.setNoDataMessagePaint(paint32);
        numberAxis13.setTickMarkPaint(paint32);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean8 = xYPlot4.isRangeZoomable();
        boolean boolean9 = xYPlot4.isRangeZeroBaselineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot14.zoomRangeAxes(0.0d, plotRenderingInfo16, point2D17, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot14.setDomainAxis((int) 'a', categoryAxis21, false);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        int int25 = categoryPlot14.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis24);
        numberAxis24.centerRange((double) 0L);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit28 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis24.setTickUnit(numberTickUnit28, false, false);
        xYPlot4.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis24);
        java.awt.Stroke stroke33 = xYPlot4.getRangeGridlineStroke();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertNotNull(numberTickUnit28);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot21.drawBackgroundImage(graphics2D22, rectangle2D23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot21.getRendererForDataset(xYDataset25);
        xYPlot21.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        int int31 = xYPlot21.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis30);
        double double32 = numberAxis30.getUpperBound();
        numberAxis30.setLabelURL("");
        java.awt.Font font35 = numberAxis30.getLabelFont();
        numberAxis14.setTickLabelFont(font35);
        java.lang.String str37 = numberAxis14.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = null;
        numberAxis14.setMarkerBand(markerAxisBand38);
        numberAxis14.centerRange(0.0d);
        numberAxis14.setAutoRange(true);
        java.awt.Color color44 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        java.awt.Color color45 = color44.darker();
        numberAxis14.setTickLabelPaint((java.awt.Paint) color45);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color45);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        xYPlot4.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation12 = null;
        try {
            boolean boolean14 = xYPlot4.removeAnnotation(xYAnnotation12, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.configureDomainAxes();
        xYPlot4.setRangeCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = xYPlot4.getDatasetRenderingOrder();
        java.awt.Stroke stroke10 = xYPlot4.getOutlineStroke();
        boolean boolean11 = xYPlot4.isRangeZeroBaselineVisible();
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis1.setCategoryMargin((double) '4');
        float float4 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        java.lang.String str6 = categoryAxis1.getCategoryLabelToolTip((java.lang.Comparable) "");
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        categoryPlot16.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke21 = categoryMarker20.getOutlineStroke();
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = categoryPlot16.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker20, layer22);
        java.lang.String str24 = categoryPlot16.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot16.getDomainAxisEdge(0);
        try {
            double double27 = categoryAxis1.getCategorySeriesMiddle((java.lang.Comparable) "Layer.FOREGROUND", (java.lang.Comparable) (byte) 0, categoryDataset9, (double) 500, rectangle2D11, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
        org.junit.Assert.assertNull(str6);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Category Plot" + "'", str24.equals("Category Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot5.zoomRangeAxes(0.0d, plotRenderingInfo7, point2D8, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot5.setDomainAxis((int) 'a', categoryAxis12, false);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        int int16 = categoryPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis15);
        numberAxis15.setRangeAboutValue((double) (byte) 0, 0.0d);
        double double20 = numberAxis15.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        xYPlot25.drawBackgroundImage(graphics2D26, rectangle2D27);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = xYPlot25.getRendererForDataset(xYDataset29);
        xYPlot25.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        int int35 = xYPlot25.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis34);
        double double36 = numberAxis34.getUpperBound();
        numberAxis34.setLabelURL("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis34, xYItemRenderer39);
        numberAxis15.setRangeAboutValue((double) 100L, 492.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        xYPlot4.zoomRangeAxes(4.0d, plotRenderingInfo14, point2D17);
        boolean boolean19 = xYPlot4.isRangeZeroBaselineVisible();
        boolean boolean20 = xYPlot4.isRangeZeroBaselineVisible();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        xYPlot4.setDataset(xYDataset21);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        xYPlot4.setRangeAxisLocation((int) 'a', axisLocation11);
        boolean boolean13 = xYPlot4.isDomainZeroBaselineVisible();
        try {
            java.awt.Paint paint15 = xYPlot4.getQuadrantPaint(255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (255) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.configureDomainAxes();
        xYPlot4.setRangeCrosshairValue((double) (byte) 0, true);
        int int9 = xYPlot4.getSeriesCount();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot4.setDomainAxis((int) (byte) 0, categoryAxis17);
        categoryPlot4.clearDomainMarkers((int) 'a');
        categoryPlot4.clearRangeMarkers();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 1, 0);
        xYPlot4.setWeight((int) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation15 = xYPlot4.getRangeAxisLocation();
        java.lang.String str16 = xYPlot4.getPlotType();
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        categoryPlot23.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot23.getDomainAxis((int) (short) 100);
        boolean boolean28 = categoryPlot23.isRangeGridlinesVisible();
        java.awt.Paint paint29 = categoryPlot23.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot23.getDataset(0);
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean33 = categoryPlot23.equals((java.lang.Object) color32);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset35, valueAxis36, valueAxis37, xYItemRenderer38);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        xYPlot39.drawBackgroundImage(graphics2D40, rectangle2D41);
        org.jfree.chart.plot.PlotOrientation plotOrientation43 = xYPlot39.getOrientation();
        org.jfree.data.general.DatasetGroup datasetGroup44 = xYPlot39.getDatasetGroup();
        org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke47 = categoryMarker46.getOutlineStroke();
        xYPlot39.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker46);
        org.jfree.chart.util.Layer layer49 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean51 = categoryPlot23.removeDomainMarker(500, (org.jfree.chart.plot.Marker) categoryMarker46, layer49, false);
        try {
            xYPlot4.addDomainMarker(11, marker18, layer49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "XY Plot" + "'", str16.equals("XY Plot"));
        org.junit.Assert.assertNull(categoryAxis27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(categoryDataset31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(plotOrientation43);
        org.junit.Assert.assertNull(datasetGroup44);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(layer49);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot4.setRenderer(categoryItemRenderer17);
        java.util.List list19 = categoryPlot4.getCategories();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent20);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = categoryPlot4.getDomainGridlinePosition();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(list19);
        org.junit.Assert.assertNotNull(categoryAnchor22);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace11, false);
        java.awt.Stroke stroke14 = categoryPlot4.getRangeCrosshairStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot4.getRangeAxisEdge(15);
        int int18 = categoryPlot4.getRangeAxisCount();
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(legendItemCollection15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1 + "'", int18 == 1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setLabelURL("");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double20 = rectangleInsets18.calculateRightInset((double) '4');
        double double22 = rectangleInsets18.extendHeight((double) 1.0f);
        numberAxis13.setLabelInsets(rectangleInsets18);
        boolean boolean24 = numberAxis13.getAutoRangeIncludesZero();
        java.awt.Stroke stroke25 = numberAxis13.getTickMarkStroke();
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis13, jFreeChart26, chartChangeEventType27);
        org.jfree.chart.JFreeChart jFreeChart29 = null;
        chartChangeEvent28.setChart(jFreeChart29);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.0d + "'", double22 == 5.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(chartChangeEventType27);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setLabelURL("");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double20 = rectangleInsets18.calculateRightInset((double) '4');
        double double22 = rectangleInsets18.extendHeight((double) 1.0f);
        numberAxis13.setLabelInsets(rectangleInsets18);
        numberAxis13.setAutoRangeMinimumSize((double) 11);
        numberAxis13.setLabelToolTip("PlotOrientation.HORIZONTAL");
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        categoryPlot32.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = categoryPlot32.getDomainAxis((int) (short) 100);
        boolean boolean37 = categoryPlot32.isRangeGridlinesVisible();
        java.awt.Paint paint38 = categoryPlot32.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset40 = categoryPlot32.getDataset(0);
        java.awt.Paint paint41 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot32.setBackgroundPaint(paint41);
        numberAxis13.setTickLabelPaint(paint41);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.0d + "'", double22 == 5.0d);
        org.junit.Assert.assertNull(categoryAxis36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(categoryDataset40);
        org.junit.Assert.assertNotNull(paint41);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_INCLUDES_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        xYPlot7.drawBackgroundImage(graphics2D8, rectangle2D9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot7.getRendererForDataset(xYDataset11);
        xYPlot7.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color16);
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        java.awt.color.ColorSpace colorSpace19 = color18.getColorSpace();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray27 = new float[] { 'a', (short) -1, ' ', 10.0f, 0, 0 };
        float[] floatArray28 = color20.getRGBColorComponents(floatArray27);
        float[] floatArray29 = color16.getColorComponents(colorSpace19, floatArray28);
        float[] floatArray30 = java.awt.Color.RGBtoHSB(100, 5, 100, floatArray29);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(colorSpace19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot4.setRenderer(categoryItemRenderer17);
        java.util.List list19 = categoryPlot4.getCategories();
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        boolean boolean24 = categoryPlot4.render(graphics2D20, rectangle2D21, (int) (byte) 100, plotRenderingInfo23);
        java.awt.Paint paint25 = categoryPlot4.getRangeGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(list19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        int int0 = org.jfree.data.time.MonthConstants.DECEMBER;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 12 + "'", int0 == 12);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.clearDomainMarkers();
        double double11 = xYPlot4.getDomainCrosshairValue();
        xYPlot4.setDomainCrosshairValue((double) 0L, false);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        categoryPlot5.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = categoryPlot5.getDomainAxis((int) (short) 100);
        boolean boolean10 = categoryPlot5.isRangeGridlinesVisible();
        java.awt.Paint paint11 = categoryPlot5.getRangeCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        xYPlot16.configureDomainAxes();
        xYPlot16.setRangeCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke23 = categoryMarker22.getOutlineStroke();
        xYPlot16.setDomainGridlineStroke(stroke23);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Color color27 = java.awt.Color.getColor("RectangleAnchor.BOTTOM", color26);
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot32.zoomRangeAxes(0.0d, plotRenderingInfo34, point2D35, false);
        org.jfree.chart.plot.Marker marker39 = null;
        org.jfree.chart.util.Layer layer40 = null;
        boolean boolean42 = categoryPlot32.removeDomainMarker((int) (byte) 0, marker39, layer40, false);
        categoryPlot32.clearAnnotations();
        java.awt.Stroke stroke44 = categoryPlot32.getDomainGridlineStroke();
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 100, paint11, stroke23, (java.awt.Paint) color26, stroke44, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset18, valueAxis19, valueAxis20, xYItemRenderer21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot22.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot22.getRendererForDataset(xYDataset26);
        xYPlot22.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = null;
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor34);
        xYPlot22.zoomRangeAxes(4.0d, plotRenderingInfo32, point2D35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot22.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot42.zoomRangeAxes(0.0d, plotRenderingInfo44, point2D45, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        categoryPlot42.setDomainAxis((int) 'a', categoryAxis49, false);
        xYPlot22.setParent((org.jfree.chart.plot.Plot) categoryPlot42);
        boolean boolean53 = datasetRenderingOrder17.equals((java.lang.Object) xYPlot22);
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder17);
        categoryPlot4.clearRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot4.getIndexOf(xYItemRenderer10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot17.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot17.setDomainAxis((int) 'a', categoryAxis24, false);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        int int28 = categoryPlot17.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis27);
        numberAxis27.setRangeAboutValue((double) (byte) 0, 0.0d);
        double double32 = numberAxis27.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset33, valueAxis34, valueAxis35, xYItemRenderer36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        xYPlot37.drawBackgroundImage(graphics2D38, rectangle2D39);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = xYPlot37.getRendererForDataset(xYDataset41);
        xYPlot37.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis();
        int int47 = xYPlot37.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis46);
        double double48 = numberAxis46.getUpperBound();
        numberAxis46.setLabelURL("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis46, xYItemRenderer51);
        java.awt.Stroke stroke53 = xYPlot52.getDomainZeroBaselineStroke();
        xYPlot4.setParent((org.jfree.chart.plot.Plot) xYPlot52);
        xYPlot4.setDomainCrosshairVisible(true);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(stroke53);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(15, 2, 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomRangeAxes(0.0d, plotRenderingInfo22, point2D23, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        categoryPlot20.setDomainAxis((int) 'a', categoryAxis27, false);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        int int31 = categoryPlot20.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis30);
        numberAxis30.centerRange((double) 0L);
        org.jfree.data.Range range34 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis30);
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = null;
        try {
            categoryPlot4.addDomainMarker(categoryMarker35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertNull(range34);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        xYPlot4.zoomRangeAxes(4.0d, plotRenderingInfo14, point2D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot4.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot24.zoomRangeAxes(0.0d, plotRenderingInfo26, point2D27, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        categoryPlot24.setDomainAxis((int) 'a', categoryAxis31, false);
        xYPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot24);
        xYPlot4.setDomainZeroBaselineVisible(true);
        xYPlot4.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot4.getOrientation();
        org.jfree.data.general.DatasetGroup datasetGroup9 = xYPlot4.getDatasetGroup();
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke12 = categoryMarker11.getOutlineStroke();
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Point2D point2D16 = null;
        xYPlot4.zoomDomainAxes((double) (byte) -1, plotRenderingInfo15, point2D16, true);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(datasetGroup9);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot4.getIndexOf(xYItemRenderer10);
        org.jfree.chart.event.PlotChangeListener plotChangeListener12 = null;
        xYPlot4.removeChangeListener(plotChangeListener12);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double1 = rectangleInsets0.getLeft();
        double double3 = rectangleInsets0.calculateTopInset(Double.NaN);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("java.awt.Color[r=192,g=192,b=192]");
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = xYPlot4.getLegendItems();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        xYPlot4.setDataset(xYDataset8);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot21.drawBackgroundImage(graphics2D22, rectangle2D23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot21.getRendererForDataset(xYDataset25);
        xYPlot21.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        int int31 = xYPlot21.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis30);
        double double32 = numberAxis30.getUpperBound();
        numberAxis30.setLabelURL("");
        java.awt.Font font35 = numberAxis30.getLabelFont();
        numberAxis14.setTickLabelFont(font35);
        java.lang.String str37 = numberAxis14.getLabelURL();
        boolean boolean38 = numberAxis14.getAutoRangeIncludesZero();
        numberAxis14.setTickLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        xYPlot4.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker21);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        xYPlot28.drawBackgroundImage(graphics2D29, rectangle2D30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot28.getRendererForDataset(xYDataset32);
        xYPlot28.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        int int38 = xYPlot28.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis37);
        double double39 = numberAxis37.getUpperBound();
        numberAxis37.setFixedAutoRange((double) 100);
        xYPlot4.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis37);
        numberAxis37.setUpperBound((-1.0d));
        java.awt.Stroke stroke45 = numberAxis37.getTickMarkStroke();
        org.jfree.chart.plot.Plot plot46 = numberAxis37.getPlot();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(plot46);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        xYPlot10.drawBackgroundImage(graphics2D11, rectangle2D12);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot10.getRendererForDataset(xYDataset14);
        xYPlot10.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        int int20 = xYPlot10.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis19);
        double double21 = numberAxis19.getUpperBound();
        numberAxis19.setLabelURL("");
        java.awt.Font font24 = numberAxis19.getLabelFont();
        categoryPlot4.setRangeAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis19, true);
        categoryPlot4.setDrawSharedDomainAxis(false);
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(font24);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = xYPlot4.getDomainAxisEdge((int) (short) 0);
        xYPlot4.clearRangeMarkers(3);
        xYPlot4.clearRangeMarkers(8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot4.getDomainAxis((int) (short) 100);
        boolean boolean9 = categoryPlot4.isRangeGridlinesVisible();
        java.awt.Paint paint10 = categoryPlot4.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot4.getDataset(0);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYPlot17.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = xYPlot17.getRendererForDataset(xYDataset21);
        xYPlot17.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        int int27 = xYPlot17.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis26);
        numberAxis26.setAutoRangeStickyZero(false);
        java.awt.Font font30 = numberAxis26.getTickLabelFont();
        categoryPlot4.setNoDataMessageFont(font30);
        categoryPlot4.setRangeCrosshairValue(0.0d, false);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset35, valueAxis36, valueAxis37, xYItemRenderer38);
        java.awt.Graphics2D graphics2D40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        xYPlot39.drawBackgroundImage(graphics2D40, rectangle2D41);
        org.jfree.data.xy.XYDataset xYDataset43 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = xYPlot39.getRendererForDataset(xYDataset43);
        xYPlot39.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor51 = null;
        java.awt.geom.Point2D point2D52 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D50, rectangleAnchor51);
        xYPlot39.zoomRangeAxes(4.0d, plotRenderingInfo49, point2D52);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = xYPlot39.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = null;
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis56, valueAxis57, categoryItemRenderer58);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo61 = null;
        java.awt.geom.Point2D point2D62 = null;
        categoryPlot59.zoomRangeAxes(0.0d, plotRenderingInfo61, point2D62, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis66 = null;
        categoryPlot59.setDomainAxis((int) 'a', categoryAxis66, false);
        xYPlot39.setParent((org.jfree.chart.plot.Plot) categoryPlot59);
        boolean boolean70 = xYPlot39.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke71 = xYPlot39.getDomainZeroBaselineStroke();
        categoryPlot4.setRangeCrosshairStroke(stroke71);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNull(xYItemRenderer44);
        org.junit.Assert.assertNotNull(point2D52);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(stroke71);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setFixedAutoRange((double) 100);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand18 = numberAxis13.getMarkerBand();
        boolean boolean19 = numberAxis13.isAutoTickUnitSelection();
        numberAxis13.resizeRange(1.0E-8d, (double) (byte) -1);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNull(markerAxisBand18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.configureDomainAxes();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot10.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot10.setFixedRangeAxisSpace(axisSpace13);
        java.awt.Paint paint15 = xYPlot10.getDomainCrosshairPaint();
        xYPlot4.setNoDataMessagePaint(paint15);
        boolean boolean17 = xYPlot4.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        numberAxis14.setRangeWithMargins(0.0d, (double) 100.0f);
        numberAxis14.setUpperMargin((double) (byte) 0);
        java.awt.Shape shape22 = numberAxis14.getDownArrow();
        boolean boolean23 = numberAxis14.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]");
        java.util.Date date2 = dateAxis1.getMinimumDate();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        xYPlot9.drawBackgroundImage(graphics2D10, rectangle2D11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = xYPlot9.getRendererForDataset(xYDataset13);
        xYPlot9.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = null;
        java.awt.geom.Point2D point2D22 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D20, rectangleAnchor21);
        xYPlot9.zoomRangeAxes(4.0d, plotRenderingInfo19, point2D22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = xYPlot9.getDomainAxisEdge();
        try {
            double double25 = dateAxis1.java2DToValue(2.0d, rectangle2D4, rectangleEdge24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date2);
        org.junit.Assert.assertNull(xYItemRenderer14);
        org.junit.Assert.assertNotNull(point2D22);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot4.setRenderer(categoryItemRenderer17);
        org.jfree.chart.axis.ValueAxis valueAxis19 = categoryPlot4.getRangeAxis();
        java.lang.String str20 = categoryPlot4.getNoDataMessage();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(valueAxis19);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot4.getDomainAxisEdge();
        java.awt.Stroke stroke16 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_STROKE;
        xYPlot4.setOutlineStroke(stroke16);
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot(categoryDataset19, categoryAxis20, valueAxis21, categoryItemRenderer22);
        categoryPlot23.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = categoryPlot23.getDomainAxis((int) (short) 100);
        boolean boolean28 = categoryPlot23.isRangeGridlinesVisible();
        java.awt.Paint paint29 = categoryPlot23.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset31 = categoryPlot23.getDataset(0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer32 = categoryPlot23.getRenderer();
        java.awt.Color color33 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        categoryPlot23.setRangeGridlinePaint((java.awt.Paint) color33);
        try {
            xYPlot4.setQuadrantPaint((int) ' ', (java.awt.Paint) color33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (32) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryAxis27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNull(categoryDataset31);
        org.junit.Assert.assertNull(categoryItemRenderer32);
        org.junit.Assert.assertNotNull(color33);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        java.awt.Color color13 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot4.setNoDataMessagePaint((java.awt.Paint) color13);
        java.awt.Color color15 = color13.brighter();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent16 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) color13);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType17 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj20 = numberAxis19.clone();
        boolean boolean21 = numberAxis19.isAutoRange();
        boolean boolean22 = numberAxis19.isVisible();
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, valueAxis25, xYItemRenderer26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        xYPlot27.drawBackgroundImage(graphics2D28, rectangle2D29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = xYPlot27.getRendererForDataset(xYDataset31);
        xYPlot27.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        int int37 = xYPlot27.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis36);
        double double38 = numberAxis36.getUpperBound();
        numberAxis36.setFixedAutoRange((double) 100);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand41 = numberAxis36.getMarkerBand();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset18, (org.jfree.chart.axis.ValueAxis) numberAxis19, (org.jfree.chart.axis.ValueAxis) numberAxis36, xYItemRenderer42);
        boolean boolean44 = chartChangeEventType17.equals((java.lang.Object) xYPlot43);
        chartChangeEvent16.setType(chartChangeEventType17);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(chartChangeEventType17);
        org.junit.Assert.assertNotNull(obj20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNull(xYItemRenderer32);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertNull(markerAxisBand41);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        boolean boolean7 = categoryPlot4.isRangeGridlinesVisible();
        boolean boolean8 = categoryPlot4.isSubplot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot4.getRangeAxisForDataset((int) (short) -1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = categoryPlot4.getDomainGridlinePosition();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(categoryAnchor11);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.java2DToValue((double) 10.0f, rectangle2D2, rectangleEdge3);
        java.lang.Object obj5 = dateAxis0.clone();
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.util.UnitType unitType7 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) unitType7, jFreeChart8, chartChangeEventType9);
        java.lang.String str11 = chartChangeEvent10.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent10.setType(chartChangeEventType12);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) dateAxis0, jFreeChart6, chartChangeEventType12);
        double double15 = dateAxis0.getUpperBound();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.223372036854776E18d + "'", double4 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]" + "'", str11.equals("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]"));
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot4.setRenderer(categoryItemRenderer17);
        java.util.List list19 = categoryPlot4.getCategories();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        categoryPlot4.rendererChanged(rendererChangeEvent20);
        float float22 = categoryPlot4.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(list19);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 1.0f + "'", float22 == 1.0f);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        xYPlot4.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker21);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = xYPlot4.getRendererForDataset(xYDataset23);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer24);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        try {
            org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(0, 0, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setLabelURL("");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double20 = rectangleInsets18.calculateRightInset((double) '4');
        double double22 = rectangleInsets18.extendHeight((double) 1.0f);
        numberAxis13.setLabelInsets(rectangleInsets18);
        boolean boolean24 = numberAxis13.getAutoRangeIncludesZero();
        java.awt.Stroke stroke25 = numberAxis13.getTickMarkStroke();
        org.jfree.chart.JFreeChart jFreeChart26 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType27 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent28 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis13, jFreeChart26, chartChangeEventType27);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj30 = numberAxis29.clone();
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset31, valueAxis32, valueAxis33, xYItemRenderer34);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        xYPlot35.drawBackgroundImage(graphics2D36, rectangle2D37);
        numberAxis29.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot35);
        double double40 = numberAxis29.getFixedAutoRange();
        org.jfree.chart.plot.Plot plot41 = numberAxis29.getPlot();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit42 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis29.setTickUnit(numberTickUnit42, true, false);
        numberAxis13.setTickUnit(numberTickUnit42, false, true);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.0d + "'", double22 == 5.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(chartChangeEventType27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNull(plot41);
        org.junit.Assert.assertNotNull(numberTickUnit42);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = intervalMarker2.getLabelOffsetType();
        java.lang.String str4 = lengthAdjustmentType3.toString();
        java.lang.String str5 = lengthAdjustmentType3.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "CONTRACT" + "'", str4.equals("CONTRACT"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "CONTRACT" + "'", str5.equals("CONTRACT"));
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        xYPlot10.drawBackgroundImage(graphics2D11, rectangle2D12);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot10.getRendererForDataset(xYDataset14);
        xYPlot10.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        int int20 = xYPlot10.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis19);
        double double21 = numberAxis19.getUpperBound();
        numberAxis19.setLabelURL("");
        java.awt.Font font24 = numberAxis19.getLabelFont();
        categoryPlot4.setRangeAxis((int) (byte) 1, (org.jfree.chart.axis.ValueAxis) numberAxis19, true);
        java.awt.Shape shape27 = numberAxis19.getDownArrow();
        org.junit.Assert.assertNull(xYItemRenderer15);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(shape27);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        int int3 = java.awt.Color.HSBtoRGB((float) 100, (float) 4, (float) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-225) + "'", int3 == (-225));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        xYPlot5.configureDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace7 = xYPlot5.getFixedRangeAxisSpace();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot(categoryDataset8, categoryAxis9, valueAxis10, categoryItemRenderer11);
        categoryPlot12.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke17 = categoryMarker16.getOutlineStroke();
        org.jfree.chart.util.Layer layer18 = null;
        boolean boolean19 = categoryPlot12.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker16, layer18);
        java.lang.Comparable comparable20 = categoryMarker16.getKey();
        java.awt.Paint paint21 = categoryMarker16.getPaint();
        java.awt.Paint paint22 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        categoryMarker16.setOutlinePaint(paint22);
        xYPlot5.setNoDataMessagePaint(paint22);
        boolean boolean25 = textAnchor0.equals((java.lang.Object) xYPlot5);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + comparable20 + "' != '" + (byte) 0 + "'", comparable20.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot4.getOrientation();
        float float9 = xYPlot4.getBackgroundAlpha();
        int int10 = xYPlot4.getDatasetCount();
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        java.awt.Graphics2D graphics2D16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        xYPlot15.drawBackgroundImage(graphics2D16, rectangle2D17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = xYPlot15.getRendererForDataset(xYDataset19);
        xYPlot15.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis();
        int int25 = xYPlot15.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis24);
        numberAxis24.setAutoRangeStickyZero(false);
        org.jfree.chart.JFreeChart jFreeChart28 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent29 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis24, jFreeChart28);
        xYPlot4.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        xYPlot4.zoomRangeAxes((double) (-1.0f), (double) 255, plotRenderingInfo33, point2D34);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(xYItemRenderer20);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.END" + "'", str1.equals("CategoryAnchor.END"));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        java.lang.String str1 = textAnchor0.toString();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "TextAnchor.BOTTOM_LEFT" + "'", str1.equals("TextAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        java.awt.Color color2 = java.awt.Color.magenta;
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot7.getDomainAxis((int) (short) 100);
        boolean boolean12 = categoryPlot7.isRangeGridlinesVisible();
        java.awt.Paint paint13 = categoryPlot7.getRangeCrosshairPaint();
        java.awt.Stroke stroke14 = categoryPlot7.getRangeCrosshairStroke();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.color.ColorSpace colorSpace16 = color15.getColorSpace();
        java.awt.image.ColorModel colorModel17 = null;
        java.awt.Rectangle rectangle18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        java.awt.geom.AffineTransform affineTransform20 = null;
        java.awt.RenderingHints renderingHints21 = null;
        java.awt.PaintContext paintContext22 = color15.createContext(colorModel17, rectangle18, rectangle2D19, affineTransform20, renderingHints21);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, valueAxis25, xYItemRenderer26);
        java.awt.Graphics2D graphics2D28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        xYPlot27.drawBackgroundImage(graphics2D28, rectangle2D29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer32 = xYPlot27.getRendererForDataset(xYDataset31);
        xYPlot27.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor39 = null;
        java.awt.geom.Point2D point2D40 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D38, rectangleAnchor39);
        xYPlot27.zoomRangeAxes(4.0d, plotRenderingInfo37, point2D40);
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = xYPlot27.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, valueAxis45, categoryItemRenderer46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        categoryPlot47.zoomRangeAxes(0.0d, plotRenderingInfo49, point2D50, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = null;
        categoryPlot47.setDomainAxis((int) 'a', categoryAxis54, false);
        xYPlot27.setParent((org.jfree.chart.plot.Plot) categoryPlot47);
        boolean boolean58 = xYPlot27.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke59 = xYPlot27.getDomainZeroBaselineStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker61 = new org.jfree.chart.plot.IntervalMarker((double) (short) 100, (double) 0L, (java.awt.Paint) color2, stroke14, (java.awt.Paint) color15, stroke59, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(colorSpace16);
        org.junit.Assert.assertNotNull(paintContext22);
        org.junit.Assert.assertNull(xYItemRenderer32);
        org.junit.Assert.assertNotNull(point2D40);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(stroke59);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis1.configure();
        double double6 = categoryAxis1.getLowerMargin();
        float float7 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot15.zoomRangeAxes(0.0d, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot15.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        categoryPlot15.setFixedRangeAxisSpace(axisSpace22, false);
        java.awt.Stroke stroke25 = categoryPlot15.getRangeCrosshairStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection26 = categoryPlot15.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = categoryPlot15.getRangeAxisEdge(15);
        try {
            java.util.List list29 = categoryAxis1.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(legendItemCollection26);
        org.junit.Assert.assertNotNull(rectangleEdge28);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainGridlinePaint();
        boolean boolean10 = xYPlot4.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot4.getRangeAxisEdge(0);
        xYPlot4.setRangeGridlinesVisible(false);
        java.awt.Stroke stroke15 = xYPlot4.getDomainGridlineStroke();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = xYPlot4.getDomainAxisEdge((int) (short) 0);
        xYPlot4.clearRangeMarkers(3);
        xYPlot4.setRangeZeroBaselineVisible(false);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = xYPlot4.getDomainAxisEdge((int) (short) 0);
        java.lang.String str10 = xYPlot4.getPlotType();
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "XY Plot" + "'", str10.equals("XY Plot"));
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYPlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot5.getRendererForDataset(xYDataset9);
        xYPlot5.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor17 = null;
        java.awt.geom.Point2D point2D18 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D16, rectangleAnchor17);
        xYPlot5.zoomRangeAxes(4.0d, plotRenderingInfo15, point2D18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = xYPlot5.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot25.zoomRangeAxes(0.0d, plotRenderingInfo27, point2D28, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot25.setDomainAxis((int) 'a', categoryAxis32, false);
        xYPlot5.setParent((org.jfree.chart.plot.Plot) categoryPlot25);
        boolean boolean36 = datasetRenderingOrder0.equals((java.lang.Object) xYPlot5);
        org.jfree.data.xy.XYDataset xYDataset38 = null;
        xYPlot5.setDataset(1, xYDataset38);
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        boolean boolean42 = xYPlot5.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker41);
        java.lang.Object obj43 = categoryMarker41.clone();
        categoryMarker41.setLabel("SortOrder.ASCENDING");
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(obj43);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset18, valueAxis19, valueAxis20, xYItemRenderer21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot22.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot22.getRendererForDataset(xYDataset26);
        xYPlot22.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = null;
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor34);
        xYPlot22.zoomRangeAxes(4.0d, plotRenderingInfo32, point2D35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot22.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot42.zoomRangeAxes(0.0d, plotRenderingInfo44, point2D45, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        categoryPlot42.setDomainAxis((int) 'a', categoryAxis49, false);
        xYPlot22.setParent((org.jfree.chart.plot.Plot) categoryPlot42);
        boolean boolean53 = datasetRenderingOrder17.equals((java.lang.Object) xYPlot22);
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder17);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent55 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent55);
        org.jfree.chart.plot.CategoryMarker categoryMarker58 = null;
        org.jfree.data.category.CategoryDataset categoryDataset59 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis60 = null;
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer62 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot63 = new org.jfree.chart.plot.CategoryPlot(categoryDataset59, categoryAxis60, valueAxis61, categoryItemRenderer62);
        categoryPlot63.setAnchorValue((double) 0L);
        boolean boolean66 = categoryPlot63.isRangeGridlinesVisible();
        boolean boolean67 = categoryPlot63.isSubplot();
        org.jfree.chart.axis.ValueAxis valueAxis69 = categoryPlot63.getRangeAxisForDataset((int) (short) -1);
        org.jfree.chart.plot.CategoryMarker categoryMarker72 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        java.lang.Comparable comparable73 = categoryMarker72.getKey();
        org.jfree.chart.util.Layer layer74 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean76 = categoryPlot63.removeDomainMarker(15, (org.jfree.chart.plot.Marker) categoryMarker72, layer74, false);
        try {
            categoryPlot4.addDomainMarker((int) (byte) 10, categoryMarker58, layer74);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNull(valueAxis69);
        org.junit.Assert.assertTrue("'" + comparable73 + "' != '" + 'a' + "'", comparable73.equals('a'));
        org.junit.Assert.assertNotNull(layer74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot4.getRangeAxis(0);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot23.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot23.setFixedRangeAxisSpace(axisSpace26);
        java.awt.Paint paint28 = xYPlot23.getDomainGridlinePaint();
        categoryPlot4.setParent((org.jfree.chart.plot.Plot) xYPlot23);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = null;
        java.util.List list31 = categoryPlot4.getCategoriesForAxis(categoryAxis30);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint35 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker34.setLabelPaint(paint35);
        java.lang.Comparable comparable37 = categoryMarker34.getKey();
        org.jfree.chart.util.Layer layer38 = null;
        categoryPlot32.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker34, layer38);
        java.awt.Paint paint40 = categoryMarker34.getLabelPaint();
        java.awt.Stroke stroke41 = categoryMarker34.getOutlineStroke();
        boolean boolean42 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker34);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(list31);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + comparable37 + "' != '" + (byte) 0 + "'", comparable37.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        xYPlot6.drawBackgroundImage(graphics2D7, rectangle2D8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot6.getRendererForDataset(xYDataset10);
        xYPlot6.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = null;
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D17, rectangleAnchor18);
        xYPlot6.zoomRangeAxes(4.0d, plotRenderingInfo16, point2D19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot6.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot26.zoomRangeAxes(0.0d, plotRenderingInfo28, point2D29, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        categoryPlot26.setDomainAxis((int) 'a', categoryAxis33, false);
        xYPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot26);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot26.setDatasetRenderingOrder(datasetRenderingOrder37);
        java.awt.Color color39 = java.awt.Color.LIGHT_GRAY;
        boolean boolean40 = datasetRenderingOrder37.equals((java.lang.Object) color39);
        categoryMarker1.setPaint((java.awt.Paint) color39);
        int int42 = color39.getRGB();
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-4144960) + "'", int42 == (-4144960));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        java.awt.Color color3 = java.awt.Color.WHITE;
        java.awt.Color color4 = java.awt.Color.LIGHT_GRAY;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray13 = new float[] { 'a', (short) -1, ' ', 10.0f, 0, 0 };
        float[] floatArray14 = color6.getRGBColorComponents(floatArray13);
        float[] floatArray15 = color4.getRGBColorComponents(floatArray14);
        float[] floatArray16 = color3.getComponents(floatArray15);
        float[] floatArray17 = java.awt.Color.RGBtoHSB(4, 12, (int) (byte) 0, floatArray15);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj2 = numberAxis1.clone();
        boolean boolean3 = numberAxis1.isAutoRange();
        boolean boolean4 = numberAxis1.isVisible();
        org.jfree.data.xy.XYDataset xYDataset5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = null;
        org.jfree.chart.plot.XYPlot xYPlot9 = new org.jfree.chart.plot.XYPlot(xYDataset5, valueAxis6, valueAxis7, xYItemRenderer8);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        xYPlot9.drawBackgroundImage(graphics2D10, rectangle2D11);
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = xYPlot9.getRendererForDataset(xYDataset13);
        xYPlot9.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis();
        int int19 = xYPlot9.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis18);
        double double20 = numberAxis18.getUpperBound();
        numberAxis18.setFixedAutoRange((double) 100);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand23 = numberAxis18.getMarkerBand();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis18, xYItemRenderer24);
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis();
        double double27 = numberAxis26.getAutoRangeMinimumSize();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        double double29 = numberAxis28.getUpperBound();
        org.jfree.data.Range range30 = numberAxis28.getDefaultAutoRange();
        numberAxis26.setRangeWithMargins(range30, false, false);
        numberAxis1.setRange(range30);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(xYItemRenderer14);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0d + "'", double20 == 1.0d);
        org.junit.Assert.assertNull(markerAxisBand23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0E-8d + "'", double27 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
        org.junit.Assert.assertNotNull(range30);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor19 = null;
        java.awt.geom.Point2D point2D20 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D18, rectangleAnchor19);
        categoryPlot4.zoomDomainAxes((double) 0L, plotRenderingInfo17, point2D20, false);
        categoryPlot4.setBackgroundAlpha(10.0f);
        categoryPlot4.configureRangeAxes();
        java.awt.Stroke stroke26 = null;
        try {
            categoryPlot4.setDomainGridlineStroke(stroke26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(point2D20);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.CategoryMarker categoryMarker1 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        xYPlot6.drawBackgroundImage(graphics2D7, rectangle2D8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot6.getRendererForDataset(xYDataset10);
        xYPlot6.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor18 = null;
        java.awt.geom.Point2D point2D19 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D17, rectangleAnchor18);
        xYPlot6.zoomRangeAxes(4.0d, plotRenderingInfo16, point2D19);
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = xYPlot6.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot26.zoomRangeAxes(0.0d, plotRenderingInfo28, point2D29, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        categoryPlot26.setDomainAxis((int) 'a', categoryAxis33, false);
        xYPlot6.setParent((org.jfree.chart.plot.Plot) categoryPlot26);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot26.setDatasetRenderingOrder(datasetRenderingOrder37);
        java.awt.Color color39 = java.awt.Color.LIGHT_GRAY;
        boolean boolean40 = datasetRenderingOrder37.equals((java.lang.Object) color39);
        categoryMarker1.setPaint((java.awt.Paint) color39);
        java.awt.Paint paint42 = categoryMarker1.getPaint();
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertNotNull(point2D19);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(paint42);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        java.util.Calendar calendar2 = null;
        try {
            day1.peg(calendar2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = null;
        try {
            categoryAxis1.setCategoryLabelPositions(categoryLabelPositions5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'positions' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        xYPlot4.zoomRangeAxes(4.0d, plotRenderingInfo14, point2D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot4.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot24.zoomRangeAxes(0.0d, plotRenderingInfo26, point2D27, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        categoryPlot24.setDomainAxis((int) 'a', categoryAxis31, false);
        xYPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot24);
        boolean boolean35 = xYPlot4.isRangeZeroBaselineVisible();
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace36);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset18, valueAxis19, valueAxis20, xYItemRenderer21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot22.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot22.getRendererForDataset(xYDataset26);
        xYPlot22.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = null;
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor34);
        xYPlot22.zoomRangeAxes(4.0d, plotRenderingInfo32, point2D35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot22.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot42.zoomRangeAxes(0.0d, plotRenderingInfo44, point2D45, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        categoryPlot42.setDomainAxis((int) 'a', categoryAxis49, false);
        xYPlot22.setParent((org.jfree.chart.plot.Plot) categoryPlot42);
        boolean boolean53 = datasetRenderingOrder17.equals((java.lang.Object) xYPlot22);
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder17);
        java.lang.String str55 = datasetRenderingOrder17.toString();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str55.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setLabelURL("");
        java.awt.Color color18 = java.awt.Color.RED;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color18);
        org.jfree.chart.axis.DateAxis dateAxis20 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        double double24 = dateAxis20.java2DToValue((double) 10.0f, rectangle2D22, rectangleEdge23);
        java.text.DateFormat dateFormat25 = null;
        dateAxis20.setDateFormatOverride(dateFormat25);
        java.awt.Stroke stroke27 = dateAxis20.getAxisLineStroke();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        xYPlot32.drawBackgroundImage(graphics2D33, rectangle2D34);
        java.awt.Stroke stroke36 = xYPlot32.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis38 = xYPlot32.getRangeAxis(10);
        xYPlot32.setDomainCrosshairValue(0.0d, false);
        java.awt.Font font42 = xYPlot32.getNoDataMessageFont();
        dateAxis20.setTickLabelFont(font42);
        numberAxis13.setLabelFont(font42);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 9.223372036854776E18d + "'", double24 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertNotNull(font42);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot6.setDomainAxisLocation((int) '4', axisLocation8);
        boolean boolean11 = xYPlot6.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot6.markerChanged(markerChangeEvent12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double16 = rectangleInsets14.calculateRightInset((double) '4');
        double double18 = rectangleInsets14.extendHeight((double) 1.0f);
        xYPlot6.setAxisOffset(rectangleInsets14);
        xYPlot6.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker23);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYPlot30.drawBackgroundImage(graphics2D31, rectangle2D32);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = xYPlot30.getRendererForDataset(xYDataset34);
        xYPlot30.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        int int40 = xYPlot30.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis39);
        double double41 = numberAxis39.getUpperBound();
        numberAxis39.setFixedAutoRange((double) 100);
        xYPlot6.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis39);
        numberAxis39.setUpperBound((-1.0d));
        java.awt.Stroke stroke47 = numberAxis39.getTickMarkStroke();
        dateAxis0.setAxisLineStroke(stroke47);
        dateAxis0.configure();
        dateAxis0.setInverted(true);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 5.0d + "'", double18 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        java.awt.Stroke stroke16 = categoryPlot4.getDomainGridlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = new org.jfree.chart.util.RectangleInsets((double) (byte) -1, (double) 0.5f, (double) 0L, (double) (short) -1);
        double double23 = rectangleInsets21.calculateLeftInset(0.0d);
        categoryPlot4.setInsets(rectangleInsets21, false);
        double double26 = rectangleInsets21.getBottom();
        double double28 = rectangleInsets21.calculateRightInset((double) '#');
        double double30 = rectangleInsets21.extendHeight(0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.5d + "'", double23 == 0.5d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-1.0d) + "'", double28 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-1.0d) + "'", double30 == (-1.0d));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        int int0 = org.jfree.data.time.MonthConstants.JANUARY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) '4');
        double double4 = rectangleInsets0.extendHeight((double) 1.0f);
        double double6 = rectangleInsets0.extendHeight(9.223372036854776E18d);
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D10 = rectangleInsets0.createInsetRectangle(rectangle2D7, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.0d + "'", double4 == 5.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.223372036854776E18d + "'", double6 == 9.223372036854776E18d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        double double1 = dateAxis0.getFixedAutoRange();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        java.util.Date date3 = dateAxis0.calculateHighestVisibleTickValue(dateTickUnit2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(dateTickUnit2);
        org.junit.Assert.assertNotNull(date3);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Stroke stroke8 = xYPlot4.getDomainZeroBaselineStroke();
        boolean boolean9 = xYPlot4.isOutlineVisible();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(4.0d, (double) 2, (double) 5, (double) 0.0f);
        java.lang.String str5 = rectangleInsets4.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=4.0,l=2.0,b=5.0,r=0.0]" + "'", str5.equals("RectangleInsets[t=4.0,l=2.0,b=5.0,r=0.0]"));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) -1, (double) 0.5f, (double) 0L, (double) (short) -1);
        double double6 = rectangleInsets4.trimHeight((double) (byte) 100);
        double double8 = rectangleInsets4.calculateRightOutset((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 101.0d + "'", double6 == 101.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        xYPlot4.setDataset(xYDataset18);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) -1, (double) 0.5f, (double) 0L, (double) (short) -1);
        double double6 = rectangleInsets4.calculateLeftInset(0.0d);
        double double8 = rectangleInsets4.calculateRightOutset(101.0d);
        double double10 = rectangleInsets4.trimWidth(492.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.5d + "'", double6 == 0.5d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 492.5d + "'", double10 == 492.5d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextOutlineStroke();
        java.awt.Stroke stroke3 = defaultDrawingSupplier1.getNextStroke();
        java.awt.Paint paint4 = defaultDrawingSupplier1.getNextOutlinePaint();
        boolean boolean5 = objectList0.equals((java.lang.Object) defaultDrawingSupplier1);
        int int6 = objectList0.size();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot21.drawBackgroundImage(graphics2D22, rectangle2D23);
        java.awt.Stroke stroke25 = xYPlot21.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot21.getRangeAxis(10);
        xYPlot21.setDomainCrosshairValue(0.0d, false);
        numberAxis14.setPlot((org.jfree.chart.plot.Plot) xYPlot21);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        java.awt.Graphics2D graphics2D37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        xYPlot36.drawBackgroundImage(graphics2D37, rectangle2D38);
        java.awt.Stroke stroke40 = xYPlot36.getRangeCrosshairStroke();
        xYPlot21.setRangeCrosshairStroke(stroke40);
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        int int43 = xYPlot21.indexOf(xYDataset42);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainCrosshairPaint();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        org.jfree.chart.plot.CrosshairState crosshairState14 = null;
        boolean boolean15 = xYPlot4.render(graphics2D10, rectangle2D11, (-225), plotRenderingInfo13, crosshairState14);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("Category Plot");
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        xYPlot4.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker21);
        java.awt.geom.Point2D point2D23 = null;
        try {
            xYPlot4.setQuadrantOrigin(point2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'origin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis1.configure();
        double double6 = categoryAxis1.getCategoryMargin();
        int int7 = categoryAxis1.getMaximumCategoryLabelLines();
        double double8 = categoryAxis1.getUpperMargin();
        double double9 = categoryAxis1.getUpperMargin();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.AxisState axisState11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot17.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.Marker marker24 = null;
        org.jfree.chart.util.Layer layer25 = null;
        boolean boolean27 = categoryPlot17.removeDomainMarker((int) (byte) 0, marker24, layer25, false);
        int int28 = categoryPlot17.getBackgroundImageAlignment();
        categoryPlot17.setWeight(10);
        java.awt.Image image31 = null;
        categoryPlot17.setBackgroundImage(image31);
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = categoryPlot17.getRangeAxisEdge();
        try {
            java.util.List list34 = categoryAxis1.refreshTicks(graphics2D10, axisState11, rectangle2D12, rectangleEdge33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.05d + "'", double8 == 0.05d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.05d + "'", double9 == 0.05d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 15 + "'", int28 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge33);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        boolean boolean2 = numberAxis0.isAutoRange();
        boolean boolean3 = numberAxis0.isVisible();
        org.jfree.chart.axis.TickUnitSource tickUnitSource4 = numberAxis0.getStandardTickUnits();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(tickUnitSource4);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker2.setLabelPaint(paint3);
        java.lang.Comparable comparable5 = categoryMarker2.getKey();
        org.jfree.chart.util.Layer layer6 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker2, layer6);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation9);
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (byte) 0 + "'", comparable5.equals((byte) 0));
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis3.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis3.configure();
        double double8 = categoryAxis3.getCategoryMargin();
        int int9 = categoryAxis3.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat11 = dateAxis10.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis10.setTickUnit(dateTickUnit12, false, true);
        dateAxis10.setRange((double) (byte) 1, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        double double22 = numberAxis21.getUpperBound();
        java.awt.Color color23 = java.awt.Color.WHITE;
        numberAxis21.setTickMarkPaint((java.awt.Paint) color23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer25);
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, categoryItemRenderer33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        categoryPlot34.zoomRangeAxes(0.0d, plotRenderingInfo36, point2D37, false);
        org.jfree.chart.plot.Marker marker41 = null;
        org.jfree.chart.util.Layer layer42 = null;
        boolean boolean44 = categoryPlot34.removeDomainMarker((int) (byte) 0, marker41, layer42, false);
        categoryPlot34.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        categoryPlot34.setDomainAxis((int) (byte) 0, categoryAxis47);
        java.awt.Image image49 = categoryPlot34.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace50 = categoryPlot34.getFixedRangeAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot34.getDomainAxisEdge();
        try {
            double double52 = categoryAxis3.getCategoryStart(0, 4, rectangle2D29, rectangleEdge51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(dateFormat11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(image49);
        org.junit.Assert.assertNull(axisSpace50);
        org.junit.Assert.assertNotNull(rectangleEdge51);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot4.setRenderer(categoryItemRenderer17);
        java.util.List list19 = categoryPlot4.getCategories();
        categoryPlot4.clearDomainAxes();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            categoryPlot4.drawBackground(graphics2D21, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(list19);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        org.jfree.chart.plot.Plot plot10 = xYPlot4.getRootPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (byte) -1, (double) 0.5f, (double) 0L, (double) (short) -1);
        double double17 = rectangleInsets15.calculateLeftInset(0.0d);
        double double19 = rectangleInsets15.calculateRightOutset(101.0d);
        xYPlot4.setAxisOffset(rectangleInsets15);
        java.lang.String str21 = rectangleInsets15.toString();
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5d + "'", double17 == 0.5d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleInsets[t=-1.0,l=0.5,b=0.0,r=-1.0]" + "'", str21.equals("RectangleInsets[t=-1.0,l=0.5,b=0.0,r=-1.0]"));
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) '4');
        double double3 = rectangleInsets0.getBottom();
        double double5 = rectangleInsets0.calculateBottomInset(0.5d);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets0.createInsetRectangle(rectangle2D6, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.0d + "'", double3 == 2.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 2.0d + "'", double5 == 2.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        java.awt.Paint paint16 = numberAxis14.getTickMarkPaint();
        java.awt.Shape shape17 = numberAxis14.getDownArrow();
        boolean boolean18 = numberAxis14.isAutoRange();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.lang.String str1 = categoryAnchor0.toString();
        org.junit.Assert.assertNotNull(categoryAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "CategoryAnchor.MIDDLE" + "'", str1.equals("CategoryAnchor.MIDDLE"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) '4');
        java.lang.String str3 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str3.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit2 = null;
        dateAxis0.setTickUnit(dateTickUnit2, false, true);
        boolean boolean6 = dateAxis0.isAxisLineVisible();
        java.util.Date date7 = dateAxis0.getMinimumDate();
        dateAxis0.setLowerBound(492.0d);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(date7);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        boolean boolean2 = numberAxis0.isVisible();
        java.awt.Color color3 = java.awt.Color.orange;
        numberAxis0.setAxisLinePaint((java.awt.Paint) color3);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        categoryPlot14.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke19 = categoryMarker18.getOutlineStroke();
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot14.getDomainAxisLocation((int) '#');
        xYPlot4.setDomainAxisLocation(axisLocation23, false);
        java.awt.Paint paint26 = xYPlot4.getRangeTickBandPaint();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNull(paint26);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot4.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        categoryPlot14.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke19 = categoryMarker18.getOutlineStroke();
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer20);
        java.lang.Comparable comparable22 = categoryMarker18.getKey();
        java.awt.Paint paint23 = categoryMarker18.getPaint();
        org.jfree.chart.util.Layer layer24 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot4.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker18, layer24);
        java.awt.Paint paint26 = xYPlot4.getDomainZeroBaselinePaint();
        boolean boolean27 = xYPlot4.isSubplot();
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + comparable22 + "' != '" + (byte) 0 + "'", comparable22.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(layer24);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot4.getRangeAxisEdge();
        org.jfree.data.general.DatasetGroup datasetGroup17 = categoryPlot4.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot4.getDomainAxisForDataset((int) (byte) 10);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot4.getDomainAxisLocation(8);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        boolean boolean7 = categoryPlot4.isRangeGridlinesVisible();
        boolean boolean8 = categoryPlot4.isSubplot();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot4.getDomainAxis((int) (short) 100);
        boolean boolean9 = categoryPlot4.isRangeGridlinesVisible();
        java.awt.Paint paint10 = categoryPlot4.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot4.getDataset(0);
        java.awt.Paint paint13 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot4.setBackgroundPaint(paint13);
        categoryPlot4.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        int int10 = xYPlot4.getSeriesCount();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot4.getRangeAxisEdge();
        org.jfree.chart.event.PlotChangeListener plotChangeListener16 = null;
        xYPlot4.removeChangeListener(plotChangeListener16);
        java.awt.Paint paint18 = null;
        try {
            xYPlot4.setRangeGridlinePaint(paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (byte) 100, 500, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Green");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) '4');
        double double4 = rectangleInsets0.extendHeight((double) 1.0f);
        double double5 = rectangleInsets0.getLeft();
        double double7 = rectangleInsets0.calculateRightInset((double) (short) -1);
        double double9 = rectangleInsets0.calculateLeftOutset(0.5d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5.0d + "'", double4 == 5.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 4.0d + "'", double9 == 4.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis2.configure();
        double double7 = categoryAxis2.getCategoryMargin();
        int int8 = categoryAxis2.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat10 = dateAxis9.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis9.setTickUnit(dateTickUnit11, false, true);
        dateAxis9.setRange((double) (byte) 1, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer18);
        categoryAxis2.configure();
        java.lang.Object obj21 = null;
        boolean boolean22 = categoryAxis2.equals(obj21);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setLabelURL("");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double20 = rectangleInsets18.calculateRightInset((double) '4');
        double double22 = rectangleInsets18.extendHeight((double) 1.0f);
        numberAxis13.setLabelInsets(rectangleInsets18);
        java.lang.String str24 = numberAxis13.getLabel();
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.0d + "'", double22 == 5.0d);
        org.junit.Assert.assertNull(str24);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        categoryPlot4.setRangeCrosshairValue((double) 100.0f);
        java.awt.Color color19 = java.awt.Color.BLACK;
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke24 = categoryMarker23.getOutlineStroke();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        xYPlot29.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup31 = xYPlot29.getDatasetGroup();
        boolean boolean32 = xYPlot29.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset34, valueAxis35, valueAxis36, xYItemRenderer37);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        xYPlot38.drawBackgroundImage(graphics2D39, rectangle2D40);
        org.jfree.chart.plot.PlotOrientation plotOrientation42 = xYPlot38.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, valueAxis46, categoryItemRenderer47);
        categoryPlot48.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke53 = categoryMarker52.getOutlineStroke();
        org.jfree.chart.util.Layer layer54 = null;
        boolean boolean55 = categoryPlot48.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker52, layer54);
        java.lang.Comparable comparable56 = categoryMarker52.getKey();
        java.awt.Paint paint57 = categoryMarker52.getPaint();
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot38.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker52, layer58);
        java.util.Collection collection60 = xYPlot29.getRangeMarkers((int) (short) 100, layer58);
        categoryPlot4.addDomainMarker(0, categoryMarker23, layer58);
        java.awt.Paint paint62 = categoryMarker23.getOutlinePaint();
        java.awt.Stroke stroke63 = categoryMarker23.getOutlineStroke();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(datasetGroup31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(plotOrientation42);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + comparable56 + "' != '" + (byte) 0 + "'", comparable56.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertNull(collection60);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNotNull(stroke63);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        java.awt.Paint paint1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        categoryPlot6.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot6.getDomainAxis((int) (short) 100);
        boolean boolean11 = categoryPlot6.isRangeGridlinesVisible();
        java.awt.Paint paint12 = categoryPlot6.getRangeCrosshairPaint();
        java.awt.Stroke stroke13 = categoryPlot6.getRangeCrosshairStroke();
        try {
            org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker(4.0d, paint1, stroke13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        float float8 = xYPlot4.getBackgroundImageAlpha();
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.5f + "'", float8 == 0.5f);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot4.setRenderer(categoryItemRenderer17);
        java.util.List list19 = categoryPlot4.getCategories();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        int int21 = color20.getAlpha();
        categoryPlot4.setOutlinePaint((java.awt.Paint) color20);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation23 = null;
        try {
            boolean boolean24 = categoryPlot4.removeAnnotation(categoryAnnotation23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(list19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot21.drawBackgroundImage(graphics2D22, rectangle2D23);
        java.awt.Stroke stroke25 = xYPlot21.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot21.getRangeAxis(10);
        xYPlot21.setDomainCrosshairValue(0.0d, false);
        numberAxis14.setPlot((org.jfree.chart.plot.Plot) xYPlot21);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        int int33 = xYPlot21.indexOf(xYDataset32);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint37 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker36.setLabelPaint(paint37);
        java.lang.Comparable comparable39 = categoryMarker36.getKey();
        org.jfree.chart.util.Layer layer40 = null;
        categoryPlot34.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker36, layer40);
        boolean boolean42 = xYPlot21.equals((java.lang.Object) categoryPlot34);
        org.jfree.chart.axis.AxisLocation axisLocation44 = null;
        categoryPlot34.setDomainAxisLocation(500, axisLocation44, false);
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.DateAxis dateAxis49 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat50 = dateAxis49.getDateFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot(xYDataset51, valueAxis52, valueAxis53, xYItemRenderer54);
        org.jfree.chart.axis.AxisLocation axisLocation57 = null;
        xYPlot55.setDomainAxisLocation((int) '4', axisLocation57);
        boolean boolean60 = xYPlot55.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent61 = null;
        xYPlot55.markerChanged(markerChangeEvent61);
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double65 = rectangleInsets63.calculateRightInset((double) '4');
        double double67 = rectangleInsets63.extendHeight((double) 1.0f);
        xYPlot55.setAxisOffset(rectangleInsets63);
        xYPlot55.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker72 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot55.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker72);
        org.jfree.data.xy.XYDataset xYDataset75 = null;
        org.jfree.chart.axis.ValueAxis valueAxis76 = null;
        org.jfree.chart.axis.ValueAxis valueAxis77 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer78 = null;
        org.jfree.chart.plot.XYPlot xYPlot79 = new org.jfree.chart.plot.XYPlot(xYDataset75, valueAxis76, valueAxis77, xYItemRenderer78);
        java.awt.Graphics2D graphics2D80 = null;
        java.awt.geom.Rectangle2D rectangle2D81 = null;
        xYPlot79.drawBackgroundImage(graphics2D80, rectangle2D81);
        org.jfree.data.xy.XYDataset xYDataset83 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer84 = xYPlot79.getRendererForDataset(xYDataset83);
        xYPlot79.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis88 = new org.jfree.chart.axis.NumberAxis();
        int int89 = xYPlot79.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis88);
        double double90 = numberAxis88.getUpperBound();
        numberAxis88.setFixedAutoRange((double) 100);
        xYPlot55.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis88);
        numberAxis88.setUpperBound((-1.0d));
        java.awt.Stroke stroke96 = numberAxis88.getTickMarkStroke();
        dateAxis49.setAxisLineStroke(stroke96);
        org.jfree.chart.plot.CategoryMarker categoryMarker98 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1, (java.awt.Paint) color48, stroke96);
        boolean boolean99 = categoryPlot34.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker98);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + (byte) 0 + "'", comparable39.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNull(dateFormat50);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 4.0d + "'", double65 == 4.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 5.0d + "'", double67 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer84);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-1) + "'", int89 == (-1));
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 1.0d + "'", double90 == 1.0d);
        org.junit.Assert.assertNotNull(stroke96);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        int int10 = xYPlot4.getSeriesCount();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace11);
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        xYPlot4.setFixedDomainAxisSpace(axisSpace13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot4.getRangeAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomRangeAxes(0.0d, plotRenderingInfo22, point2D23, false);
        org.jfree.chart.plot.Marker marker27 = null;
        org.jfree.chart.util.Layer layer28 = null;
        boolean boolean30 = categoryPlot20.removeDomainMarker((int) (byte) 0, marker27, layer28, false);
        int int31 = categoryPlot20.getBackgroundImageAlignment();
        categoryPlot20.setWeight(10);
        java.awt.Image image34 = null;
        categoryPlot20.setBackgroundImage(image34);
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot20.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = categoryPlot20.getDomainAxis(0);
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean40 = categoryPlot20.equals((java.lang.Object) color39);
        int int41 = color39.getRGB();
        java.awt.color.ColorSpace colorSpace42 = color39.getColorSpace();
        xYPlot4.setRangeCrosshairPaint((java.awt.Paint) color39);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 15 + "'", int31 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNull(categoryAxis38);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-8388480) + "'", int41 == (-8388480));
        org.junit.Assert.assertNotNull(colorSpace42);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.awt.Paint paint1 = null;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat3 = dateAxis2.getDateFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        xYPlot8.setDomainAxisLocation((int) '4', axisLocation10);
        boolean boolean13 = xYPlot8.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot8.markerChanged(markerChangeEvent14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double18 = rectangleInsets16.calculateRightInset((double) '4');
        double double20 = rectangleInsets16.extendHeight((double) 1.0f);
        xYPlot8.setAxisOffset(rectangleInsets16);
        xYPlot8.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot8.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker25);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        xYPlot32.drawBackgroundImage(graphics2D33, rectangle2D34);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = xYPlot32.getRendererForDataset(xYDataset36);
        xYPlot32.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        int int42 = xYPlot32.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis41);
        double double43 = numberAxis41.getUpperBound();
        numberAxis41.setFixedAutoRange((double) 100);
        xYPlot8.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis41);
        numberAxis41.setUpperBound((-1.0d));
        java.awt.Stroke stroke49 = numberAxis41.getTickMarkStroke();
        dateAxis2.setAxisLineStroke(stroke49);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker(0.0d, paint1, stroke49);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(dateFormat3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 5.0d + "'", double20 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(stroke49);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        try {
            java.awt.Color color1 = java.awt.Color.decode("CategoryAnchor.MIDDLE");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"CategoryAnchor.MIDDLE\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat2 = dateAxis1.getDateFormatOverride();
        dateAxis1.setAutoTickUnitSelection(false);
        boolean boolean5 = color0.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNull(dateFormat2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        categoryPlot4.setNoDataMessage("hi!");
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        categoryPlot4.setDomainAxisLocation((int) ' ', axisLocation13, false);
        org.jfree.data.category.CategoryDataset categoryDataset17 = categoryPlot4.getDataset((int) (short) 1);
        org.junit.Assert.assertNull(categoryDataset17);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace9);
        java.awt.Paint paint11 = xYPlot6.getDomainCrosshairPaint();
        int int12 = xYPlot6.getRangeAxisCount();
        boolean boolean13 = plotOrientation0.equals((java.lang.Object) xYPlot6);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot18.zoomRangeAxes(0.0d, plotRenderingInfo20, point2D21, false);
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = null;
        boolean boolean28 = categoryPlot18.removeDomainMarker((int) (byte) 0, marker25, layer26, false);
        boolean boolean29 = categoryPlot18.isDomainZoomable();
        boolean boolean30 = xYPlot6.equals((java.lang.Object) categoryPlot18);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot18.setFixedDomainAxisSpace(axisSpace31, false);
        org.jfree.chart.LegendItemCollection legendItemCollection34 = categoryPlot18.getLegendItems();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(legendItemCollection34);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot4.setDomainAxis((int) (byte) 0, categoryAxis17);
        java.awt.Image image19 = categoryPlot4.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot4.getDomainAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot4.getRangeAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot27.zoomRangeAxes(0.0d, plotRenderingInfo29, point2D30, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        categoryPlot27.setDomainAxis((int) 'a', categoryAxis34, false);
        org.jfree.data.category.CategoryDataset categoryDataset37 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot(categoryDataset37, categoryAxis38, valueAxis39, categoryItemRenderer40);
        categoryPlot41.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke46 = categoryMarker45.getOutlineStroke();
        org.jfree.chart.util.Layer layer47 = null;
        boolean boolean48 = categoryPlot41.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker45, layer47);
        org.jfree.chart.axis.AxisLocation axisLocation50 = categoryPlot41.getDomainAxisLocation((int) '#');
        org.jfree.data.xy.XYDataset xYDataset51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer54 = null;
        org.jfree.chart.plot.XYPlot xYPlot55 = new org.jfree.chart.plot.XYPlot(xYDataset51, valueAxis52, valueAxis53, xYItemRenderer54);
        java.awt.Graphics2D graphics2D56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        xYPlot55.drawBackgroundImage(graphics2D56, rectangle2D57);
        org.jfree.chart.plot.PlotOrientation plotOrientation59 = xYPlot55.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation50, plotOrientation59);
        org.jfree.chart.axis.AxisLocation axisLocation61 = axisLocation50.getOpposite();
        categoryPlot27.setDomainAxisLocation(axisLocation50, false);
        categoryPlot4.setDomainAxisLocation(axisLocation50);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(axisLocation50);
        org.junit.Assert.assertNotNull(plotOrientation59);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNotNull(axisLocation61);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.lang.Object obj0 = null;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent(obj0, jFreeChart1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset18, valueAxis19, valueAxis20, xYItemRenderer21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot22.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot22.getRendererForDataset(xYDataset26);
        xYPlot22.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = null;
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor34);
        xYPlot22.zoomRangeAxes(4.0d, plotRenderingInfo32, point2D35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot22.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot42.zoomRangeAxes(0.0d, plotRenderingInfo44, point2D45, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        categoryPlot42.setDomainAxis((int) 'a', categoryAxis49, false);
        xYPlot22.setParent((org.jfree.chart.plot.Plot) categoryPlot42);
        boolean boolean53 = datasetRenderingOrder17.equals((java.lang.Object) xYPlot22);
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder17);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent55 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent55);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor57 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor57);
        org.jfree.data.xy.XYDataset xYDataset60 = null;
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer63 = null;
        org.jfree.chart.plot.XYPlot xYPlot64 = new org.jfree.chart.plot.XYPlot(xYDataset60, valueAxis61, valueAxis62, xYItemRenderer63);
        java.awt.Graphics2D graphics2D65 = null;
        java.awt.geom.Rectangle2D rectangle2D66 = null;
        xYPlot64.drawBackgroundImage(graphics2D65, rectangle2D66);
        java.awt.Stroke stroke68 = xYPlot64.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation70 = xYPlot64.getDomainAxisLocation(9);
        categoryPlot4.setDomainAxisLocation(15, axisLocation70);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(categoryAnchor57);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNotNull(axisLocation70);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("UnitType.RELATIVE");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        xYPlot6.drawBackgroundImage(graphics2D7, rectangle2D8);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        xYPlot6.clearDomainMarkers();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        categoryPlot16.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke21 = categoryMarker20.getOutlineStroke();
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = categoryPlot16.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker20, layer22);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot16.setDatasetRenderingOrder(datasetRenderingOrder24);
        categoryPlot16.setForegroundAlpha((float) (short) 100);
        org.jfree.data.general.Dataset dataset28 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent29 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (short) 100, dataset28);
        xYPlot6.datasetChanged(datasetChangeEvent29);
        org.jfree.data.general.Dataset dataset31 = datasetChangeEvent29.getDataset();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertNull(dataset31);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.java2DToValue((double) 10.0f, rectangle2D2, rectangleEdge3);
        java.text.DateFormat dateFormat5 = null;
        dateAxis0.setDateFormatOverride(dateFormat5);
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        categoryPlot11.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke16 = categoryMarker15.getOutlineStroke();
        org.jfree.chart.util.Layer layer17 = null;
        boolean boolean18 = categoryPlot11.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker15, layer17);
        boolean boolean19 = categoryPlot11.isDomainZoomable();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        categoryPlot24.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = categoryPlot24.getDomainAxis((int) (short) 100);
        boolean boolean29 = categoryPlot24.isRangeGridlinesVisible();
        java.awt.Paint paint30 = categoryPlot24.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset32 = categoryPlot24.getDataset(0);
        java.awt.Paint paint33 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryPlot24.setBackgroundPaint(paint33);
        java.awt.Stroke stroke35 = categoryPlot24.getDomainGridlineStroke();
        categoryPlot11.setOutlineStroke(stroke35);
        dateAxis0.setTickMarkStroke(stroke35);
        dateAxis0.setFixedDimension((double) 10L);
        org.jfree.chart.axis.DateAxis dateAxis41 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]");
        java.util.Date date42 = dateAxis41.getMinimumDate();
        org.jfree.chart.axis.DateAxis dateAxis44 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]");
        java.util.Date date45 = dateAxis44.getMinimumDate();
        try {
            dateAxis0.setRange(date42, date45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 'lower' < 'upper'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.223372036854776E18d + "'", double4 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(categoryAxis28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(categoryDataset32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(date45);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        xYPlot6.drawBackgroundImage(graphics2D7, rectangle2D8);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        double double11 = numberAxis0.getFixedAutoRange();
        org.jfree.chart.plot.Plot plot12 = numberAxis0.getPlot();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit13 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis0.setTickUnit(numberTickUnit13, true, false);
        numberAxis0.setAutoRangeStickyZero(true);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(plot12);
        org.junit.Assert.assertNotNull(numberTickUnit13);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj3 = numberAxis2.clone();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        xYPlot8.drawBackgroundImage(graphics2D9, rectangle2D10);
        numberAxis2.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot8);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]");
        xYPlot8.setDomainAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis15);
        double double17 = numberAxis15.getFixedDimension();
        org.jfree.chart.plot.IntervalMarker intervalMarker20 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        java.awt.Paint paint21 = intervalMarker20.getPaint();
        numberAxis15.setLabelPaint(paint21);
        java.awt.Font font23 = numberAxis15.getLabelFont();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, (org.jfree.chart.axis.ValueAxis) numberAxis15, xYItemRenderer24);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot21.drawBackgroundImage(graphics2D22, rectangle2D23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot21.getRendererForDataset(xYDataset25);
        xYPlot21.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        int int31 = xYPlot21.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis30);
        double double32 = numberAxis30.getUpperBound();
        numberAxis30.setLabelURL("");
        java.awt.Font font35 = numberAxis30.getLabelFont();
        numberAxis14.setTickLabelFont(font35);
        java.lang.String str37 = numberAxis14.getLabelURL();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand38 = null;
        numberAxis14.setMarkerBand(markerAxisBand38);
        numberAxis14.centerRange(0.0d);
        numberAxis14.setAutoRange(true);
        java.lang.String str44 = numberAxis14.getLabelURL();
        java.awt.Paint paint45 = numberAxis14.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNull(str44);
        org.junit.Assert.assertNotNull(paint45);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot6.setDomainAxisLocation((int) '4', axisLocation8);
        boolean boolean11 = xYPlot6.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot6.markerChanged(markerChangeEvent12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double16 = rectangleInsets14.calculateRightInset((double) '4');
        double double18 = rectangleInsets14.extendHeight((double) 1.0f);
        xYPlot6.setAxisOffset(rectangleInsets14);
        xYPlot6.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker23);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYPlot30.drawBackgroundImage(graphics2D31, rectangle2D32);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = xYPlot30.getRendererForDataset(xYDataset34);
        xYPlot30.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        int int40 = xYPlot30.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis39);
        double double41 = numberAxis39.getUpperBound();
        numberAxis39.setFixedAutoRange((double) 100);
        xYPlot6.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis39);
        numberAxis39.setUpperBound((-1.0d));
        java.awt.Stroke stroke47 = numberAxis39.getTickMarkStroke();
        dateAxis0.setAxisLineStroke(stroke47);
        double double49 = dateAxis0.getLowerBound();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 5.0d + "'", double18 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.configureDomainAxes();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        try {
            xYPlot4.setRenderer((int) (short) -1, xYItemRenderer7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset18, valueAxis19, valueAxis20, xYItemRenderer21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot22.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot22.getRendererForDataset(xYDataset26);
        xYPlot22.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = null;
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor34);
        xYPlot22.zoomRangeAxes(4.0d, plotRenderingInfo32, point2D35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot22.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot42.zoomRangeAxes(0.0d, plotRenderingInfo44, point2D45, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        categoryPlot42.setDomainAxis((int) 'a', categoryAxis49, false);
        xYPlot22.setParent((org.jfree.chart.plot.Plot) categoryPlot42);
        boolean boolean53 = datasetRenderingOrder17.equals((java.lang.Object) xYPlot22);
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder17);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor55 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        boolean boolean56 = datasetRenderingOrder17.equals((java.lang.Object) rectangleAnchor55);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot4.setDomainAxis((int) (byte) 1, categoryAxis12);
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis15.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis15.configure();
        java.util.List list20 = categoryPlot4.getCategoriesForAxis(categoryAxis15);
        float float21 = categoryAxis15.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 0.0f + "'", float21 == 0.0f);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace11, false);
        java.awt.Stroke stroke14 = categoryPlot4.getRangeCrosshairStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(legendItemCollection15);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot4.getRangeAxisEdge((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-4144960));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot4.setDomainAxis((int) (byte) 0, categoryAxis17);
        java.awt.Image image19 = categoryPlot4.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint24 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker23.setLabelPaint(paint24);
        java.lang.Comparable comparable26 = categoryMarker23.getKey();
        org.jfree.chart.util.Layer layer27 = null;
        try {
            categoryPlot4.addDomainMarker((int) (byte) 1, categoryMarker23, layer27, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + comparable26 + "' != '" + (byte) 0 + "'", comparable26.equals((byte) 0));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        categoryPlot4.setRangeCrosshairValue((double) 100.0f);
        categoryPlot4.setAnchorValue((double) (byte) 1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = org.jfree.chart.axis.CategoryAnchor.END;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot26.zoomRangeAxes(0.0d, plotRenderingInfo28, point2D29, false);
        org.jfree.chart.plot.Marker marker33 = null;
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean36 = categoryPlot26.removeDomainMarker((int) (byte) 0, marker33, layer34, false);
        categoryPlot26.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = null;
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D40, rectangleAnchor41);
        categoryPlot26.zoomDomainAxes((double) 0L, plotRenderingInfo39, point2D42, false);
        boolean boolean45 = categoryAnchor21.equals((java.lang.Object) point2D42);
        categoryPlot4.setDomainGridlinePosition(categoryAnchor21);
        java.lang.String str47 = categoryAnchor21.toString();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent48 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryAnchor21);
        java.lang.Object obj49 = chartChangeEvent48.getSource();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "CategoryAnchor.END" + "'", str47.equals("CategoryAnchor.END"));
        org.junit.Assert.assertNotNull(obj49);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Stroke stroke8 = xYPlot4.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot4.getRangeAxis(10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        xYPlot16.drawBackgroundImage(graphics2D17, rectangle2D18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = xYPlot16.getRendererForDataset(xYDataset20);
        xYPlot16.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        int int26 = xYPlot16.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis25);
        double double27 = numberAxis25.getUpperBound();
        numberAxis25.setLabelURL("");
        xYPlot4.setDomainAxis((int) ' ', (org.jfree.chart.axis.ValueAxis) numberAxis25);
        double double31 = numberAxis25.getLabelAngle();
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand32 = numberAxis25.getMarkerBand();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0d + "'", double27 == 1.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNull(markerAxisBand32);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        int int16 = xYPlot4.getIndexOf(xYItemRenderer15);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        java.awt.geom.Point2D point2D18 = xYPlot4.getQuadrantOrigin();
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) 10);
        boolean boolean22 = xYPlot4.isRangeCrosshairVisible();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        try {
            xYPlot4.drawOutline(graphics2D23, rectangle2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        xYPlot6.drawBackgroundImage(graphics2D7, rectangle2D8);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]");
        xYPlot6.setDomainAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getFixedDimension();
        double double16 = numberAxis13.getLabelAngle();
        try {
            numberAxis13.zoomRange(492.5d, (double) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (517.125) <= upper (33.6).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup6 = xYPlot4.getDatasetGroup();
        boolean boolean7 = xYPlot4.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(xYItemRenderer9);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot4.getDomainAxisEdge();
        try {
            org.jfree.chart.axis.ValueAxis valueAxis17 = xYPlot4.getRangeAxisForDataset(1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 1 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) '4');
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        java.awt.geom.Point2D point2D18 = xYPlot4.getQuadrantOrigin();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint22 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker21.setLabelPaint(paint22);
        java.lang.Comparable comparable24 = categoryMarker21.getKey();
        org.jfree.chart.util.Layer layer25 = null;
        categoryPlot19.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker21, layer25);
        java.awt.Stroke stroke27 = categoryPlot19.getRangeGridlineStroke();
        xYPlot4.setDomainZeroBaselineStroke(stroke27);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + comparable24 + "' != '" + (byte) 0 + "'", comparable24.equals((byte) 0));
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        boolean boolean7 = categoryPlot4.isRangeGridlinesVisible();
        boolean boolean8 = categoryPlot4.isSubplot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot4.getRangeAxisForDataset((int) (short) -1);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        java.lang.Comparable comparable14 = categoryMarker13.getKey();
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean17 = categoryPlot4.removeDomainMarker(15, (org.jfree.chart.plot.Marker) categoryMarker13, layer15, false);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        xYPlot23.drawBackgroundImage(graphics2D24, rectangle2D25);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = xYPlot23.getOrientation();
        org.jfree.data.general.DatasetGroup datasetGroup28 = xYPlot23.getDatasetGroup();
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke31 = categoryMarker30.getOutlineStroke();
        xYPlot23.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker30);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset33, valueAxis34, valueAxis35, xYItemRenderer36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        xYPlot37.drawBackgroundImage(graphics2D38, rectangle2D39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = xYPlot37.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, valueAxis45, categoryItemRenderer46);
        categoryPlot47.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker51 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke52 = categoryMarker51.getOutlineStroke();
        org.jfree.chart.util.Layer layer53 = null;
        boolean boolean54 = categoryPlot47.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker51, layer53);
        java.lang.Comparable comparable55 = categoryMarker51.getKey();
        java.awt.Paint paint56 = categoryMarker51.getPaint();
        org.jfree.chart.util.Layer layer57 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot37.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker51, layer57);
        java.lang.String str59 = layer57.toString();
        categoryPlot4.addRangeMarker(100, (org.jfree.chart.plot.Marker) categoryMarker30, layer57, true);
        boolean boolean62 = categoryMarker30.getDrawAsLine();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 'a' + "'", comparable14.equals('a'));
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNull(datasetGroup28);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + comparable55 + "' != '" + (byte) 0 + "'", comparable55.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(layer57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Layer.FOREGROUND" + "'", str59.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        categoryPlot14.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke19 = categoryMarker18.getOutlineStroke();
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot14.getDomainAxisLocation((int) '#');
        xYPlot4.setDomainAxisLocation(axisLocation23, false);
        boolean boolean26 = xYPlot4.isRangeGridlinesVisible();
        org.jfree.chart.plot.IntervalMarker intervalMarker30 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        double double31 = intervalMarker30.getEndValue();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent32 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker30);
        double double33 = intervalMarker30.getEndValue();
        java.lang.Object obj34 = intervalMarker30.clone();
        org.jfree.data.category.CategoryDataset categoryDataset35 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot(categoryDataset35, categoryAxis36, valueAxis37, categoryItemRenderer38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        categoryPlot39.zoomRangeAxes(0.0d, plotRenderingInfo41, point2D42, false);
        org.jfree.chart.plot.Marker marker46 = null;
        org.jfree.chart.util.Layer layer47 = null;
        boolean boolean49 = categoryPlot39.removeDomainMarker((int) (byte) 0, marker46, layer47, false);
        categoryPlot39.setBackgroundAlpha((float) 0);
        org.jfree.chart.axis.ValueAxis valueAxis53 = categoryPlot39.getRangeAxis(0);
        categoryPlot39.configureRangeAxes();
        org.jfree.chart.util.Layer layer55 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection56 = categoryPlot39.getDomainMarkers(layer55);
        xYPlot4.addRangeMarker((int) '4', (org.jfree.chart.plot.Marker) intervalMarker30, layer55, false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-1.0d) + "'", double31 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + (-1.0d) + "'", double33 == (-1.0d));
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(valueAxis53);
        org.junit.Assert.assertNotNull(layer55);
        org.junit.Assert.assertNull(collection56);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        int int15 = categoryPlot4.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot4.setDataset(categoryDataset16);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, valueAxis22, xYItemRenderer23);
        xYPlot24.configureDomainAxes();
        xYPlot24.setRangeCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = xYPlot24.getDatasetRenderingOrder();
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint33 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker32.setLabelPaint(paint33);
        java.lang.Comparable comparable35 = categoryMarker32.getKey();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset36, valueAxis37, valueAxis38, xYItemRenderer39);
        xYPlot40.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup42 = xYPlot40.getDatasetGroup();
        boolean boolean43 = xYPlot40.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset45, valueAxis46, valueAxis47, xYItemRenderer48);
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        xYPlot49.drawBackgroundImage(graphics2D50, rectangle2D51);
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = xYPlot49.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = null;
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis56, valueAxis57, categoryItemRenderer58);
        categoryPlot59.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker63 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke64 = categoryMarker63.getOutlineStroke();
        org.jfree.chart.util.Layer layer65 = null;
        boolean boolean66 = categoryPlot59.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker63, layer65);
        java.lang.Comparable comparable67 = categoryMarker63.getKey();
        java.awt.Paint paint68 = categoryMarker63.getPaint();
        org.jfree.chart.util.Layer layer69 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot49.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker63, layer69);
        java.util.Collection collection71 = xYPlot40.getRangeMarkers((int) (short) 100, layer69);
        xYPlot24.addDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) categoryMarker32, layer69);
        boolean boolean74 = categoryPlot4.removeDomainMarker(2, marker19, layer69, false);
        categoryPlot4.clearAnnotations();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + (byte) 0 + "'", comparable35.equals((byte) 0));
        org.junit.Assert.assertNull(datasetGroup42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(plotOrientation53);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + comparable67 + "' != '" + (byte) 0 + "'", comparable67.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(layer69);
        org.junit.Assert.assertNull(collection71);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot4.setDomainAxis((int) (byte) 0, categoryAxis17);
        java.awt.Image image19 = categoryPlot4.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot4.getFixedRangeAxisSpace();
        categoryPlot4.configureRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot26.zoomRangeAxes(0.0d, plotRenderingInfo28, point2D29, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        categoryPlot26.setDomainAxis((int) 'a', categoryAxis33, false);
        org.jfree.chart.axis.NumberAxis numberAxis36 = new org.jfree.chart.axis.NumberAxis();
        int int37 = categoryPlot26.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis36);
        double double38 = numberAxis36.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset39, valueAxis40, valueAxis41, xYItemRenderer42);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        xYPlot43.drawBackgroundImage(graphics2D44, rectangle2D45);
        java.awt.Stroke stroke47 = xYPlot43.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis49 = xYPlot43.getRangeAxis(10);
        xYPlot43.setDomainCrosshairValue(0.0d, false);
        numberAxis36.setPlot((org.jfree.chart.plot.Plot) xYPlot43);
        java.awt.geom.Point2D point2D54 = xYPlot43.getQuadrantOrigin();
        org.jfree.chart.axis.AxisLocation axisLocation56 = xYPlot43.getRangeAxisLocation(1);
        categoryPlot4.setDomainAxisLocation(axisLocation56, false);
        org.jfree.chart.plot.Marker marker60 = null;
        org.jfree.data.xy.XYDataset xYDataset61 = null;
        org.jfree.chart.axis.ValueAxis valueAxis62 = null;
        org.jfree.chart.axis.ValueAxis valueAxis63 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer64 = null;
        org.jfree.chart.plot.XYPlot xYPlot65 = new org.jfree.chart.plot.XYPlot(xYDataset61, valueAxis62, valueAxis63, xYItemRenderer64);
        java.awt.Graphics2D graphics2D66 = null;
        java.awt.geom.Rectangle2D rectangle2D67 = null;
        xYPlot65.drawBackgroundImage(graphics2D66, rectangle2D67);
        org.jfree.chart.plot.PlotOrientation plotOrientation69 = xYPlot65.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset71 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis72 = null;
        org.jfree.chart.axis.ValueAxis valueAxis73 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer74 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot75 = new org.jfree.chart.plot.CategoryPlot(categoryDataset71, categoryAxis72, valueAxis73, categoryItemRenderer74);
        categoryPlot75.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker79 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke80 = categoryMarker79.getOutlineStroke();
        org.jfree.chart.util.Layer layer81 = null;
        boolean boolean82 = categoryPlot75.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker79, layer81);
        java.lang.Comparable comparable83 = categoryMarker79.getKey();
        java.awt.Paint paint84 = categoryMarker79.getPaint();
        org.jfree.chart.util.Layer layer85 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot65.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker79, layer85);
        try {
            categoryPlot4.addRangeMarker(5, marker60, layer85, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNull(valueAxis49);
        org.junit.Assert.assertNotNull(point2D54);
        org.junit.Assert.assertNotNull(axisLocation56);
        org.junit.Assert.assertNotNull(plotOrientation69);
        org.junit.Assert.assertNotNull(stroke80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + comparable83 + "' != '" + (byte) 0 + "'", comparable83.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint84);
        org.junit.Assert.assertNotNull(layer85);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot21.drawBackgroundImage(graphics2D22, rectangle2D23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot21.getRendererForDataset(xYDataset25);
        xYPlot21.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        int int31 = xYPlot21.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis30);
        double double32 = numberAxis30.getUpperBound();
        numberAxis30.setLabelURL("");
        java.awt.Font font35 = numberAxis30.getLabelFont();
        numberAxis14.setTickLabelFont(font35);
        java.lang.String str37 = numberAxis14.getLabelURL();
        java.awt.Shape shape38 = numberAxis14.getDownArrow();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNull(str37);
        org.junit.Assert.assertNotNull(shape38);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        boolean boolean2 = numberAxis0.isAutoRange();
        boolean boolean3 = numberAxis0.isVisible();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        xYPlot8.configureDomainAxes();
        xYPlot8.setRangeCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = xYPlot8.getDatasetRenderingOrder();
        boolean boolean14 = numberAxis0.hasListener((java.util.EventListener) xYPlot8);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = xYPlot8.getRendererForDataset(xYDataset15);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(xYItemRenderer16);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.lang.Object obj2 = defaultDrawingSupplier0.clone();
        boolean boolean4 = defaultDrawingSupplier0.equals((java.lang.Object) 0.05d);
        java.awt.Stroke stroke5 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.lang.Object obj6 = defaultDrawingSupplier0.clone();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(obj2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        categoryPlot4.setRangeCrosshairValue((double) 100.0f);
        categoryPlot4.setAnchorValue((double) (byte) 1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot4.addChangeListener(plotChangeListener21);
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent25 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent25);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer28 = categoryPlot4.getRendererForDataset(categoryDataset27);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation29 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(categoryItemRenderer28);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        categoryPlot4.setRangeCrosshairValue((double) 100.0f);
        categoryPlot4.setAnchorValue((double) (byte) 1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot4.addChangeListener(plotChangeListener21);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = categoryPlot4.getDomainAxis();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(categoryAxis23);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.DateAxis dateAxis1 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]");
        java.util.Date date2 = dateAxis1.getMinimumDate();
        org.jfree.chart.axis.DateTickMarkPosition dateTickMarkPosition3 = null;
        try {
            dateAxis1.setTickMarkPosition(dateTickMarkPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(date2);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
        java.util.Calendar calendar3 = null;
        try {
            long long4 = day1.getMiddleMillisecond(calendar3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(serialDate2);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setLabelURL("");
        java.awt.Color color18 = java.awt.Color.RED;
        numberAxis13.setTickLabelPaint((java.awt.Paint) color18);
        boolean boolean20 = numberAxis13.isAutoTickUnitSelection();
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        xYPlot4.zoomRangeAxes(4.0d, plotRenderingInfo14, point2D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot4.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot24.zoomRangeAxes(0.0d, plotRenderingInfo26, point2D27, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        categoryPlot24.setDomainAxis((int) 'a', categoryAxis31, false);
        xYPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot24);
        xYPlot4.setDomainZeroBaselineVisible(true);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        xYPlot4.setRenderer(9, xYItemRenderer38, true);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        double double5 = categoryAxis1.getLowerMargin();
        categoryAxis1.setCategoryMargin((double) 10);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        numberAxis14.centerRange((double) 0L);
        java.awt.Stroke stroke18 = numberAxis14.getAxisLineStroke();
        double double19 = numberAxis14.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0E-8d + "'", double19 == 1.0E-8d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot21.drawBackgroundImage(graphics2D22, rectangle2D23);
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = xYPlot21.getRendererForDataset(xYDataset25);
        xYPlot21.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        int int31 = xYPlot21.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis30);
        double double32 = numberAxis30.getUpperBound();
        numberAxis30.setLabelURL("");
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double37 = rectangleInsets35.calculateRightInset((double) '4');
        double double39 = rectangleInsets35.extendHeight((double) 1.0f);
        numberAxis30.setLabelInsets(rectangleInsets35);
        boolean boolean41 = numberAxis30.getAutoRangeIncludesZero();
        java.awt.Stroke stroke42 = numberAxis30.getTickMarkStroke();
        categoryPlot4.setDomainGridlineStroke(stroke42);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(xYItemRenderer26);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 1.0d + "'", double32 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 5.0d + "'", double39 == 5.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(stroke42);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        xYPlot4.zoomRangeAxes(4.0d, plotRenderingInfo14, point2D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot4.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot24.zoomRangeAxes(0.0d, plotRenderingInfo26, point2D27, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        categoryPlot24.setDomainAxis((int) 'a', categoryAxis31, false);
        xYPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot24);
        boolean boolean35 = xYPlot4.isRangeZeroBaselineVisible();
        java.awt.Stroke stroke36 = xYPlot4.getDomainZeroBaselineStroke();
        xYPlot4.setDomainCrosshairLockedOnData(true);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.awt.Color color3 = java.awt.Color.getHSBColor(0.0f, (float) (short) 0, 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Paint paint1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomRangeAxes(0.0d, plotRenderingInfo8, point2D9, false);
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        boolean boolean16 = categoryPlot6.removeDomainMarker((int) (byte) 0, marker13, layer14, false);
        categoryPlot6.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot6.getRangeAxisEdge();
        org.jfree.data.general.DatasetGroup datasetGroup19 = categoryPlot6.getDatasetGroup();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker22 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint23 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker22.setLabelPaint(paint23);
        java.lang.Comparable comparable25 = categoryMarker22.getKey();
        org.jfree.chart.util.Layer layer26 = null;
        categoryPlot20.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker22, layer26);
        java.awt.Paint paint28 = categoryMarker22.getLabelPaint();
        java.awt.Stroke stroke29 = categoryMarker22.getOutlineStroke();
        categoryPlot6.setRangeCrosshairStroke(stroke29);
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset31, valueAxis32, valueAxis33, xYItemRenderer34);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot35.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        xYPlot35.setFixedRangeAxisSpace(axisSpace38);
        java.awt.Paint paint40 = xYPlot35.getDomainGridlinePaint();
        java.awt.Color color41 = java.awt.Color.WHITE;
        xYPlot35.setOutlinePaint((java.awt.Paint) color41);
        java.awt.Stroke stroke43 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker45 = new org.jfree.chart.plot.ValueMarker((double) (-8388480), paint1, stroke29, (java.awt.Paint) color41, stroke43, (float) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNull(datasetGroup19);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertTrue("'" + comparable25 + "' != '" + (byte) 0 + "'", comparable25.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        java.awt.Color color5 = java.awt.Color.getHSBColor(2.0f, (float) 1, (float) 0);
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot11.zoomRangeAxes(0.0d, plotRenderingInfo13, point2D14, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        categoryPlot11.setDomainAxis((int) 'a', categoryAxis18, false);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        int int22 = categoryPlot11.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis21);
        numberAxis21.setRangeAboutValue((double) (byte) 0, 0.0d);
        double double26 = numberAxis21.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset27, valueAxis28, valueAxis29, xYItemRenderer30);
        java.awt.Graphics2D graphics2D32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        xYPlot31.drawBackgroundImage(graphics2D32, rectangle2D33);
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = xYPlot31.getRendererForDataset(xYDataset35);
        xYPlot31.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis40 = new org.jfree.chart.axis.NumberAxis();
        int int41 = xYPlot31.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis40);
        double double42 = numberAxis40.getUpperBound();
        numberAxis40.setLabelURL("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset6, (org.jfree.chart.axis.ValueAxis) numberAxis21, (org.jfree.chart.axis.ValueAxis) numberAxis40, xYItemRenderer45);
        java.awt.Stroke stroke47 = xYPlot46.getDomainZeroBaselineStroke();
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray55 = new float[] { 'a', (short) -1, ' ', 10.0f, 0, 0 };
        float[] floatArray56 = color48.getRGBColorComponents(floatArray55);
        org.jfree.data.category.CategoryDataset categoryDataset57 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = null;
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset57, categoryAxis58, valueAxis59, categoryItemRenderer60);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo63 = null;
        java.awt.geom.Point2D point2D64 = null;
        categoryPlot61.zoomRangeAxes(0.0d, plotRenderingInfo63, point2D64, false);
        org.jfree.chart.axis.AxisSpace axisSpace67 = categoryPlot61.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace68 = null;
        categoryPlot61.setFixedRangeAxisSpace(axisSpace68, false);
        java.awt.Stroke stroke71 = categoryPlot61.getRangeCrosshairStroke();
        try {
            org.jfree.chart.plot.IntervalMarker intervalMarker73 = new org.jfree.chart.plot.IntervalMarker((double) (-225), Double.NaN, (java.awt.Paint) color5, stroke47, (java.awt.Paint) color48, stroke71, (float) 5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer36);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0d + "'", double42 == 1.0d);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertNotNull(floatArray55);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNull(axisSpace67);
        org.junit.Assert.assertNotNull(stroke71);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot4.setDomainAxis((int) (byte) 0, categoryAxis17);
        java.awt.Image image19 = categoryPlot4.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot4.getFixedRangeAxisSpace();
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearDomainMarkers();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = categoryPlot4.getRendererForDataset(categoryDataset23);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNull(categoryItemRenderer24);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.configureDomainAxes();
        xYPlot4.setRangeCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = xYPlot4.getDatasetRenderingOrder();
        org.jfree.chart.axis.ValueAxis valueAxis11 = xYPlot4.getRangeAxis(0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(valueAxis11);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        int int15 = categoryPlot4.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot4.setDataset(categoryDataset16);
        org.jfree.data.category.CategoryDataset categoryDataset18 = categoryPlot4.getDataset();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNull(categoryDataset18);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis1.configure();
        double double6 = categoryAxis1.getCategoryMargin();
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = xYPlot14.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        xYPlot14.setFixedRangeAxisSpace(axisSpace17);
        java.awt.Paint paint19 = xYPlot14.getDomainGridlinePaint();
        boolean boolean20 = xYPlot14.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot14.getRangeAxisEdge(0);
        try {
            double double23 = categoryAxis1.getCategoryMiddle(12, (-225), rectangle2D9, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.2d + "'", double6 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 12, (double) (short) 100, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        int int15 = categoryPlot4.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot4.setDataset(categoryDataset16);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, valueAxis22, xYItemRenderer23);
        xYPlot24.configureDomainAxes();
        xYPlot24.setRangeCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = xYPlot24.getDatasetRenderingOrder();
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint33 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker32.setLabelPaint(paint33);
        java.lang.Comparable comparable35 = categoryMarker32.getKey();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset36, valueAxis37, valueAxis38, xYItemRenderer39);
        xYPlot40.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup42 = xYPlot40.getDatasetGroup();
        boolean boolean43 = xYPlot40.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset45, valueAxis46, valueAxis47, xYItemRenderer48);
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        xYPlot49.drawBackgroundImage(graphics2D50, rectangle2D51);
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = xYPlot49.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = null;
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis56, valueAxis57, categoryItemRenderer58);
        categoryPlot59.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker63 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke64 = categoryMarker63.getOutlineStroke();
        org.jfree.chart.util.Layer layer65 = null;
        boolean boolean66 = categoryPlot59.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker63, layer65);
        java.lang.Comparable comparable67 = categoryMarker63.getKey();
        java.awt.Paint paint68 = categoryMarker63.getPaint();
        org.jfree.chart.util.Layer layer69 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot49.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker63, layer69);
        java.util.Collection collection71 = xYPlot40.getRangeMarkers((int) (short) 100, layer69);
        xYPlot24.addDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) categoryMarker32, layer69);
        boolean boolean74 = categoryPlot4.removeDomainMarker(2, marker19, layer69, false);
        try {
            categoryPlot4.zoom(0.2d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + (byte) 0 + "'", comparable35.equals((byte) 0));
        org.junit.Assert.assertNull(datasetGroup42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(plotOrientation53);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + comparable67 + "' != '" + (byte) 0 + "'", comparable67.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(layer69);
        org.junit.Assert.assertNull(collection71);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot6.setDomainAxisLocation((int) '4', axisLocation8);
        boolean boolean11 = xYPlot6.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot6.markerChanged(markerChangeEvent12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double16 = rectangleInsets14.calculateRightInset((double) '4');
        double double18 = rectangleInsets14.extendHeight((double) 1.0f);
        xYPlot6.setAxisOffset(rectangleInsets14);
        xYPlot6.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker23);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYPlot30.drawBackgroundImage(graphics2D31, rectangle2D32);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = xYPlot30.getRendererForDataset(xYDataset34);
        xYPlot30.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        int int40 = xYPlot30.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis39);
        double double41 = numberAxis39.getUpperBound();
        numberAxis39.setFixedAutoRange((double) 100);
        xYPlot6.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis39);
        numberAxis39.setUpperBound((-1.0d));
        java.awt.Stroke stroke47 = numberAxis39.getTickMarkStroke();
        dateAxis0.setAxisLineStroke(stroke47);
        org.jfree.chart.axis.NumberAxis numberAxis49 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj50 = numberAxis49.clone();
        boolean boolean51 = numberAxis49.isAutoRange();
        boolean boolean52 = numberAxis49.isVisible();
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis();
        double double54 = numberAxis53.getAutoRangeMinimumSize();
        org.jfree.chart.axis.NumberAxis numberAxis55 = new org.jfree.chart.axis.NumberAxis();
        double double56 = numberAxis55.getUpperBound();
        org.jfree.data.Range range57 = numberAxis55.getDefaultAutoRange();
        numberAxis53.setRangeWithMargins(range57, false, false);
        numberAxis49.setRangeWithMargins(range57);
        dateAxis0.setRange(range57);
        boolean boolean63 = dateAxis0.isTickMarksVisible();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 5.0d + "'", double18 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(obj50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.0E-8d + "'", double54 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0d + "'", double56 == 1.0d);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        java.awt.Color color0 = java.awt.Color.PINK;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray8 = new float[] { 'a', (short) -1, ' ', 10.0f, 0, 0 };
        float[] floatArray9 = color1.getRGBColorComponents(floatArray8);
        float[] floatArray10 = color0.getColorComponents(floatArray9);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        xYPlot4.setRangeAxisLocation((int) 'a', axisLocation11);
        java.lang.String str13 = xYPlot4.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot4.getDomainAxisEdge(0);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        xYPlot4.setDataset(xYDataset16);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "XY Plot" + "'", str13.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setLabelURL("");
        boolean boolean18 = numberAxis13.isNegativeArrowVisible();
        numberAxis13.setAutoRangeStickyZero(false);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis2.configure();
        double double7 = categoryAxis2.getCategoryMargin();
        int int8 = categoryAxis2.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat10 = dateAxis9.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis9.setTickUnit(dateTickUnit11, false, true);
        dateAxis9.setRange((double) (byte) 1, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.data.category.CategoryDataset categoryDataset24 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot(categoryDataset24, categoryAxis25, valueAxis26, categoryItemRenderer27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot28.zoomRangeAxes(0.0d, plotRenderingInfo30, point2D31, false);
        org.jfree.chart.plot.Marker marker35 = null;
        org.jfree.chart.util.Layer layer36 = null;
        boolean boolean38 = categoryPlot28.removeDomainMarker((int) (byte) 0, marker35, layer36, false);
        categoryPlot28.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot28.getRangeAxisEdge();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        try {
            org.jfree.chart.axis.AxisState axisState42 = categoryAxis2.draw(graphics2D20, (-3.0d), rectangle2D22, rectangle2D23, rectangleEdge40, plotRenderingInfo41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangleEdge40);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot4.setDomainAxis((int) (byte) 0, categoryAxis17);
        java.awt.Image image19 = categoryPlot4.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot4.getFixedRangeAxisSpace();
        categoryPlot4.configureRangeAxes();
        categoryPlot4.clearDomainMarkers();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation23 = null;
        try {
            categoryPlot4.addAnnotation(categoryAnnotation23, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNull(axisSpace20);
    }
}

