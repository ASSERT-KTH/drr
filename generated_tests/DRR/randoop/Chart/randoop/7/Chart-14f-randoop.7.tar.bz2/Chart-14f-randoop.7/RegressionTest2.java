import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis1.configure();
        double double6 = categoryAxis1.getLowerMargin();
        categoryAxis1.setMaximumCategoryLabelLines(255);
        categoryAxis1.setCategoryMargin(0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker2.setLabelPaint(paint3);
        java.lang.Comparable comparable5 = categoryMarker2.getKey();
        org.jfree.chart.util.Layer layer6 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker2, layer6);
        java.awt.Stroke stroke8 = categoryPlot0.getRangeGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        xYPlot14.setDomainAxisLocation((int) '4', axisLocation16);
        boolean boolean18 = xYPlot14.isRangeZoomable();
        xYPlot14.setRangeCrosshairValue((double) 1, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke24 = categoryMarker23.getOutlineStroke();
        xYPlot14.setRangeGridlineStroke(stroke24);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        xYPlot14.setRangeTickBandPaint((java.awt.Paint) color26);
        org.jfree.chart.axis.AxisLocation axisLocation28 = xYPlot14.getDomainAxisLocation();
        categoryPlot0.setRangeAxisLocation(2, axisLocation28, false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (byte) 0 + "'", comparable5.equals((byte) 0));
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(axisLocation28);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        numberAxis14.centerRange((double) 0L);
        org.jfree.chart.plot.Plot plot18 = numberAxis14.getPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis14.setTickMarkPaint((java.awt.Paint) color19);
        int int21 = color19.getGreen();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 255 + "'", int21 == 255);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        numberAxis14.setRangeAboutValue((double) (byte) 0, 0.0d);
        double double19 = numberAxis14.getFixedAutoRange();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis14.java2DToValue((double) 15, rectangle2D21, rectangleEdge22);
        double double24 = numberAxis14.getLowerMargin();
        numberAxis14.setAutoRange(true);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.05d + "'", double24 == 0.05d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker3 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint4 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker3.setLabelPaint(paint4);
        java.lang.Comparable comparable6 = categoryMarker3.getKey();
        org.jfree.chart.util.Layer layer7 = null;
        categoryPlot1.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker3, layer7);
        java.awt.Paint paint9 = categoryMarker3.getLabelPaint();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        xYPlot14.drawBackgroundImage(graphics2D15, rectangle2D16);
        org.jfree.chart.plot.PlotOrientation plotOrientation18 = xYPlot14.getOrientation();
        org.jfree.chart.axis.ValueAxis valueAxis20 = xYPlot14.getRangeAxis((int) (byte) 0);
        org.jfree.chart.plot.IntervalMarker intervalMarker23 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        java.awt.Paint paint24 = intervalMarker23.getPaint();
        xYPlot14.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker23);
        double double26 = intervalMarker23.getEndValue();
        java.awt.Stroke stroke27 = intervalMarker23.getStroke();
        org.jfree.chart.plot.ValueMarker valueMarker28 = new org.jfree.chart.plot.ValueMarker((double) 1560409200000L, paint9, stroke27);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (byte) 0 + "'", comparable6.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(plotOrientation18);
        org.junit.Assert.assertNull(valueAxis20);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + (-1.0d) + "'", double26 == (-1.0d));
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace11, false);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot4.getLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray15 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray15);
        java.awt.Paint paint17 = categoryPlot4.getBackgroundPaint();
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(categoryItemRendererArray15);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis3.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis3.configure();
        double double8 = categoryAxis3.getCategoryMargin();
        int int9 = categoryAxis3.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat11 = dateAxis10.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis10.setTickUnit(dateTickUnit12, false, true);
        dateAxis10.setRange((double) (byte) 1, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        double double22 = numberAxis21.getUpperBound();
        java.awt.Color color23 = java.awt.Color.WHITE;
        numberAxis21.setTickMarkPaint((java.awt.Paint) color23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer25);
        java.lang.String str28 = categoryAxis3.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        int int29 = categoryAxis3.getCategoryLabelPositionOffset();
        boolean boolean31 = categoryAxis3.equals((java.lang.Object) "RectangleAnchor.RIGHT");
        org.jfree.chart.plot.IntervalMarker intervalMarker35 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        double double36 = intervalMarker35.getEndValue();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset37, valueAxis38, valueAxis39, xYItemRenderer40);
        java.awt.Graphics2D graphics2D42 = null;
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        xYPlot41.drawBackgroundImage(graphics2D42, rectangle2D43);
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer46 = xYPlot41.getRendererForDataset(xYDataset45);
        xYPlot41.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis();
        int int51 = xYPlot41.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis50);
        numberAxis50.setAutoRangeStickyZero(false);
        java.awt.Font font54 = numberAxis50.getTickLabelFont();
        intervalMarker35.setLabelFont(font54);
        categoryAxis3.setTickLabelFont((java.lang.Comparable) "hi!", font54);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(dateFormat11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + (-1.0d) + "'", double36 == (-1.0d));
        org.junit.Assert.assertNull(xYItemRenderer46);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(font54);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        boolean boolean7 = categoryPlot4.isRangeGridlinesVisible();
        boolean boolean8 = categoryPlot4.isSubplot();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot4.getRangeAxisForDataset((int) (short) -1);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 'a');
        java.lang.Comparable comparable14 = categoryMarker13.getKey();
        org.jfree.chart.util.Layer layer15 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean17 = categoryPlot4.removeDomainMarker(15, (org.jfree.chart.plot.Marker) categoryMarker13, layer15, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double19 = rectangleInsets18.getLeft();
        categoryMarker13.setLabelOffset(rectangleInsets18);
        org.jfree.chart.util.UnitType unitType21 = rectangleInsets18.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D25 = rectangleInsets18.createInsetRectangle(rectangle2D22, true, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + comparable14 + "' != '" + 'a' + "'", comparable14.equals('a'));
        org.junit.Assert.assertNotNull(layer15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertNotNull(unitType21);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot4.getRangeAxisEdge();
        org.jfree.data.general.DatasetGroup datasetGroup17 = categoryPlot4.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot4.getDomainAxisForDataset((int) (byte) 10);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot4.getRangeAxisForDataset((int) (byte) 1);
        categoryPlot4.setRangeCrosshairValue((-3.0d), true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertNull(valueAxis21);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker2.setLabelPaint(paint3);
        java.lang.Comparable comparable5 = categoryMarker2.getKey();
        org.jfree.chart.util.Layer layer6 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker2, layer6);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.axis.AxisLocation axisLocation9 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace11, false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (byte) 0 + "'", comparable5.equals((byte) 0));
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        categoryPlot9.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke14 = categoryMarker13.getOutlineStroke();
        org.jfree.chart.util.Layer layer15 = null;
        boolean boolean16 = categoryPlot9.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker13, layer15);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot9.setDatasetRenderingOrder(datasetRenderingOrder17);
        categoryPlot9.setForegroundAlpha((float) (short) 100);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot9.getDomainAxisLocation(8);
        org.jfree.chart.axis.AxisLocation axisLocation24 = categoryPlot9.getRangeAxisLocation(5);
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot9.getRangeAxisLocation(100);
        xYPlot4.setDomainAxisLocation(axisLocation26, false);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(axisLocation26);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        xYPlot4.zoomRangeAxes(4.0d, plotRenderingInfo14, point2D17);
        boolean boolean19 = xYPlot4.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray21 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer20 };
        xYPlot4.setRenderers(xYItemRendererArray21);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        xYPlot4.setDataset(xYDataset23);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(xYItemRendererArray21);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        boolean boolean12 = categoryPlot4.isDomainZoomable();
        categoryPlot4.clearDomainAxes();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        boolean boolean18 = categoryPlot4.render(graphics2D14, rectangle2D15, (int) (byte) 100, plotRenderingInfo17);
        boolean boolean19 = categoryPlot4.isRangeGridlinesVisible();
        java.awt.Color color20 = java.awt.Color.white;
        categoryPlot4.setRangeGridlinePaint((java.awt.Paint) color20);
        java.awt.Color color22 = color20.brighter();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setLabelURL("");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double20 = rectangleInsets18.calculateRightInset((double) '4');
        double double22 = rectangleInsets18.extendHeight((double) 1.0f);
        numberAxis13.setLabelInsets(rectangleInsets18);
        boolean boolean24 = numberAxis13.getAutoRangeIncludesZero();
        java.awt.Stroke stroke25 = numberAxis13.getTickMarkStroke();
        numberAxis13.setRange(9.223372036854776E18d, 9.223372036854776E18d);
        numberAxis13.setTickLabelsVisible(false);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.0d + "'", double22 == 5.0d);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot4.getOrientation();
        float float9 = xYPlot4.getBackgroundAlpha();
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        xYPlot14.drawBackgroundImage(graphics2D15, rectangle2D16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot14.getRendererForDataset(xYDataset18);
        xYPlot14.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis();
        int int24 = xYPlot14.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis23);
        double double25 = numberAxis23.getUpperBound();
        numberAxis23.resizeRange((double) '#');
        boolean boolean29 = numberAxis23.equals((java.lang.Object) 1L);
        xYPlot4.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis23);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 1.0f + "'", float9 == 1.0f);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        double double14 = intervalMarker13.getEndValue();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker13);
        double double16 = intervalMarker13.getEndValue();
        java.lang.Object obj17 = intervalMarker13.clone();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset18, valueAxis19, valueAxis20, xYItemRenderer21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot22.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.chart.plot.PlotOrientation plotOrientation26 = xYPlot22.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        categoryPlot32.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke37 = categoryMarker36.getOutlineStroke();
        org.jfree.chart.util.Layer layer38 = null;
        boolean boolean39 = categoryPlot32.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker36, layer38);
        java.lang.Comparable comparable40 = categoryMarker36.getKey();
        java.awt.Paint paint41 = categoryMarker36.getPaint();
        org.jfree.chart.util.Layer layer42 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot22.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker36, layer42);
        java.lang.String str44 = layer42.toString();
        java.lang.String str45 = layer42.toString();
        xYPlot4.addDomainMarker(2, (org.jfree.chart.plot.Marker) intervalMarker13, layer42, false);
        java.awt.Stroke stroke48 = null;
        try {
            intervalMarker13.setStroke(stroke48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertNotNull(plotOrientation26);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + comparable40 + "' != '" + (byte) 0 + "'", comparable40.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertNotNull(layer42);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "Layer.FOREGROUND" + "'", str44.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "Layer.FOREGROUND" + "'", str45.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot20.zoomRangeAxes(0.0d, plotRenderingInfo22, point2D23, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        categoryPlot20.setDomainAxis((int) 'a', categoryAxis27, false);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis();
        int int31 = categoryPlot20.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis30);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot20);
        categoryPlot4.notifyListeners(plotChangeEvent32);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean8 = xYPlot4.isRangeZoomable();
        xYPlot4.setRangeCrosshairValue((double) 1, false);
        org.jfree.chart.axis.AxisLocation axisLocation13 = xYPlot4.getRangeAxisLocation(100);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 1);
        java.lang.Object obj2 = objectList1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        java.lang.String str1 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.BOTTOM_LEFT" + "'", str1.equals("RectangleAnchor.BOTTOM_LEFT"));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.centerRange((double) 10);
        numberAxis13.setPositiveArrowVisible(true);
        org.jfree.chart.plot.Plot plot20 = null;
        numberAxis13.setPlot(plot20);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        numberAxis13.setAutoRangeStickyZero(false);
        org.jfree.chart.JFreeChart jFreeChart17 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent18 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis13, jFreeChart17);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis20.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis20.configure();
        double double25 = categoryAxis20.getCategoryMargin();
        int int26 = categoryAxis20.getMaximumCategoryLabelLines();
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        xYPlot32.drawBackgroundImage(graphics2D33, rectangle2D34);
        java.awt.Stroke stroke36 = xYPlot32.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis38 = xYPlot32.getRangeAxis(10);
        xYPlot32.setDomainCrosshairValue(0.0d, false);
        java.awt.Font font42 = xYPlot32.getNoDataMessageFont();
        categoryAxis20.setTickLabelFont((java.lang.Comparable) ' ', font42);
        numberAxis13.setTickLabelFont(font42);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.2d + "'", double25 == 0.2d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1 + "'", int26 == 1);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(valueAxis38);
        org.junit.Assert.assertNotNull(font42);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainCrosshairPaint();
        boolean boolean10 = xYPlot4.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainCrosshairPaint();
        org.jfree.data.xy.XYDataset xYDataset11 = xYPlot4.getDataset(9);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(xYDataset11);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainGridlinePaint();
        boolean boolean10 = xYPlot4.isDomainCrosshairVisible();
        boolean boolean11 = xYPlot4.isRangeGridlinesVisible();
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = null;
        org.jfree.chart.plot.XYPlot xYPlot16 = new org.jfree.chart.plot.XYPlot(xYDataset12, valueAxis13, valueAxis14, xYItemRenderer15);
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        xYPlot16.drawBackgroundImage(graphics2D17, rectangle2D18);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = xYPlot16.getRendererForDataset(xYDataset20);
        xYPlot16.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis();
        int int26 = xYPlot16.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis25);
        org.jfree.chart.plot.CategoryMarker categoryMarker28 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke29 = categoryMarker28.getOutlineStroke();
        numberAxis25.setTickMarkStroke(stroke29);
        xYPlot4.setDomainCrosshairStroke(stroke29);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(xYItemRenderer21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1) + "'", int26 == (-1));
        org.junit.Assert.assertNotNull(stroke29);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = intervalMarker2.getLabelOffsetType();
        double double4 = intervalMarker2.getStartValue();
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot21.drawBackgroundImage(graphics2D22, rectangle2D23);
        java.awt.Stroke stroke25 = xYPlot21.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot21.getRangeAxis(10);
        xYPlot21.setDomainCrosshairValue(0.0d, false);
        numberAxis14.setPlot((org.jfree.chart.plot.Plot) xYPlot21);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        int int33 = xYPlot21.indexOf(xYDataset32);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint37 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker36.setLabelPaint(paint37);
        java.lang.Comparable comparable39 = categoryMarker36.getKey();
        org.jfree.chart.util.Layer layer40 = null;
        categoryPlot34.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker36, layer40);
        boolean boolean42 = xYPlot21.equals((java.lang.Object) categoryPlot34);
        org.jfree.chart.axis.AxisLocation axisLocation44 = null;
        categoryPlot34.setDomainAxisLocation(500, axisLocation44, false);
        org.jfree.chart.plot.Marker marker47 = null;
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, valueAxis50, categoryItemRenderer51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        categoryPlot52.zoomRangeAxes(0.0d, plotRenderingInfo54, point2D55, false);
        org.jfree.chart.plot.Marker marker59 = null;
        org.jfree.chart.util.Layer layer60 = null;
        boolean boolean62 = categoryPlot52.removeDomainMarker((int) (byte) 0, marker59, layer60, false);
        categoryPlot52.setBackgroundAlpha((float) 0);
        org.jfree.chart.axis.ValueAxis valueAxis66 = categoryPlot52.getRangeAxis(0);
        categoryPlot52.configureRangeAxes();
        org.jfree.chart.util.Layer layer68 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection69 = categoryPlot52.getDomainMarkers(layer68);
        try {
            boolean boolean70 = categoryPlot34.removeRangeMarker(marker47, layer68);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + comparable39 + "' != '" + (byte) 0 + "'", comparable39.equals((byte) 0));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNull(valueAxis66);
        org.junit.Assert.assertNotNull(layer68);
        org.junit.Assert.assertNull(collection69);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot4.setRenderer(categoryItemRenderer17);
        categoryPlot4.clearRangeAxes();
        org.jfree.chart.util.SortOrder sortOrder20 = categoryPlot4.getRowRenderingOrder();
        java.lang.Object obj21 = null;
        boolean boolean22 = sortOrder20.equals(obj21);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(sortOrder20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        boolean boolean16 = categoryPlot4.isRangeCrosshairVisible();
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace17, true);
        double double20 = categoryPlot4.getAnchorValue();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot(categoryDataset21, categoryAxis22, valueAxis23, categoryItemRenderer24);
        categoryPlot25.setAnchorValue((double) 0L);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = categoryPlot25.getDatasetRenderingOrder();
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder28);
        java.awt.Image image30 = null;
        categoryPlot4.setBackgroundImage(image30);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(datasetRenderingOrder28);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = categoryPlot4.getRenderer(10);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = org.jfree.chart.axis.CategoryAnchor.END;
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot15.zoomRangeAxes(0.0d, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.util.Layer layer23 = null;
        boolean boolean25 = categoryPlot15.removeDomainMarker((int) (byte) 0, marker22, layer23, false);
        categoryPlot15.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor30 = null;
        java.awt.geom.Point2D point2D31 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D29, rectangleAnchor30);
        categoryPlot15.zoomDomainAxes((double) 0L, plotRenderingInfo28, point2D31, false);
        boolean boolean34 = categoryAnchor10.equals((java.lang.Object) point2D31);
        categoryPlot4.zoomDomainAxes(9.223372036854776E18d, plotRenderingInfo9, point2D31);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextOutlineStroke();
        java.lang.Object obj38 = defaultDrawingSupplier36.clone();
        java.awt.Paint paint39 = defaultDrawingSupplier36.getNextOutlinePaint();
        java.awt.Shape shape40 = defaultDrawingSupplier36.getNextShape();
        java.awt.Stroke stroke41 = defaultDrawingSupplier36.getNextStroke();
        categoryPlot4.setRangeGridlineStroke(stroke41);
        org.junit.Assert.assertNull(categoryItemRenderer6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(point2D31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis2.configure();
        double double7 = categoryAxis2.getCategoryMargin();
        int int8 = categoryAxis2.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.DateAxis dateAxis9 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat10 = dateAxis9.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit11 = null;
        dateAxis9.setTickUnit(dateTickUnit11, false, true);
        dateAxis9.setRange((double) (byte) 1, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) dateAxis9, categoryItemRenderer18);
        int int20 = categoryPlot19.getWeight();
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer25 = null;
        org.jfree.chart.plot.XYPlot xYPlot26 = new org.jfree.chart.plot.XYPlot(xYDataset22, valueAxis23, valueAxis24, xYItemRenderer25);
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        xYPlot26.drawBackgroundImage(graphics2D27, rectangle2D28);
        org.jfree.chart.plot.PlotOrientation plotOrientation30 = xYPlot26.getOrientation();
        org.jfree.chart.axis.ValueAxis valueAxis32 = xYPlot26.getRangeAxis((int) (byte) 0);
        org.jfree.chart.plot.IntervalMarker intervalMarker35 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        java.awt.Paint paint36 = intervalMarker35.getPaint();
        xYPlot26.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker35);
        double double38 = intervalMarker35.getEndValue();
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj40 = numberAxis39.clone();
        boolean boolean41 = numberAxis39.isAutoRange();
        boolean boolean42 = numberAxis39.isVisible();
        org.jfree.data.category.CategoryDataset categoryDataset43 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot(categoryDataset43, categoryAxis44, valueAxis45, categoryItemRenderer46);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = null;
        java.awt.geom.Point2D point2D50 = null;
        categoryPlot47.zoomRangeAxes(0.0d, plotRenderingInfo49, point2D50, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = null;
        categoryPlot47.setDomainAxis((int) 'a', categoryAxis54, false);
        org.jfree.data.category.CategoryDataset categoryDataset57 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis58 = null;
        org.jfree.chart.axis.ValueAxis valueAxis59 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer60 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot61 = new org.jfree.chart.plot.CategoryPlot(categoryDataset57, categoryAxis58, valueAxis59, categoryItemRenderer60);
        categoryPlot61.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker65 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke66 = categoryMarker65.getOutlineStroke();
        org.jfree.chart.util.Layer layer67 = null;
        boolean boolean68 = categoryPlot61.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker65, layer67);
        org.jfree.chart.axis.AxisLocation axisLocation70 = categoryPlot61.getDomainAxisLocation((int) '#');
        org.jfree.data.xy.XYDataset xYDataset71 = null;
        org.jfree.chart.axis.ValueAxis valueAxis72 = null;
        org.jfree.chart.axis.ValueAxis valueAxis73 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer74 = null;
        org.jfree.chart.plot.XYPlot xYPlot75 = new org.jfree.chart.plot.XYPlot(xYDataset71, valueAxis72, valueAxis73, xYItemRenderer74);
        java.awt.Graphics2D graphics2D76 = null;
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        xYPlot75.drawBackgroundImage(graphics2D76, rectangle2D77);
        org.jfree.chart.plot.PlotOrientation plotOrientation79 = xYPlot75.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation70, plotOrientation79);
        org.jfree.chart.axis.AxisLocation axisLocation81 = axisLocation70.getOpposite();
        categoryPlot47.setDomainAxisLocation(axisLocation70, false);
        numberAxis39.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot47);
        categoryPlot47.setRangeCrosshairValue(100.0d, false);
        boolean boolean88 = intervalMarker35.equals((java.lang.Object) 100.0d);
        org.jfree.chart.util.Layer layer89 = null;
        boolean boolean91 = categoryPlot19.removeDomainMarker((int) (byte) -1, (org.jfree.chart.plot.Marker) intervalMarker35, layer89, false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(dateFormat10);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(plotOrientation30);
        org.junit.Assert.assertNull(valueAxis32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + (-1.0d) + "'", double38 == (-1.0d));
        org.junit.Assert.assertNotNull(obj40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(axisLocation70);
        org.junit.Assert.assertNotNull(plotOrientation79);
        org.junit.Assert.assertNotNull(rectangleEdge80);
        org.junit.Assert.assertNotNull(axisLocation81);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        numberAxis14.setAutoRangeMinimumSize((double) (short) 100);
        numberAxis14.setRange((double) (-1), Double.NaN);
        double double22 = numberAxis14.getFixedDimension();
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot4.getOrientation();
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot4.getRangeAxis((int) (byte) 0);
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot(categoryDataset11, categoryAxis12, valueAxis13, categoryItemRenderer14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot15.zoomRangeAxes(0.0d, plotRenderingInfo17, point2D18, false);
        org.jfree.chart.plot.Marker marker22 = null;
        org.jfree.chart.util.Layer layer23 = null;
        boolean boolean25 = categoryPlot15.removeDomainMarker((int) (byte) 0, marker22, layer23, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray26 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot15.setRangeAxes(valueAxisArray26);
        xYPlot4.setDomainAxes(valueAxisArray26);
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(valueAxisArray26);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = xYPlot4.getOrientation();
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot4.getRangeAxis((int) (byte) 0);
        org.jfree.chart.plot.IntervalMarker intervalMarker13 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        java.awt.Paint paint14 = intervalMarker13.getPaint();
        xYPlot4.addRangeMarker((org.jfree.chart.plot.Marker) intervalMarker13);
        double double16 = intervalMarker13.getEndValue();
        java.awt.Stroke stroke17 = intervalMarker13.getStroke();
        java.lang.String str18 = intervalMarker13.getLabel();
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-1.0d) + "'", double16 == (-1.0d));
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(str18);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean8 = xYPlot4.isRangeZoomable();
        xYPlot4.setRangeCrosshairValue((double) 1, false);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot16.zoomRangeAxes(0.0d, plotRenderingInfo18, point2D19, false);
        org.jfree.chart.plot.Marker marker23 = null;
        org.jfree.chart.util.Layer layer24 = null;
        boolean boolean26 = categoryPlot16.removeDomainMarker((int) (byte) 0, marker23, layer24, false);
        categoryPlot16.setBackgroundAlpha((float) 0);
        categoryPlot16.setRangeCrosshairValue((double) 100.0f);
        java.awt.Color color31 = java.awt.Color.BLACK;
        categoryPlot16.setDomainGridlinePaint((java.awt.Paint) color31);
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke36 = categoryMarker35.getOutlineStroke();
        org.jfree.data.xy.XYDataset xYDataset37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer40 = null;
        org.jfree.chart.plot.XYPlot xYPlot41 = new org.jfree.chart.plot.XYPlot(xYDataset37, valueAxis38, valueAxis39, xYItemRenderer40);
        xYPlot41.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup43 = xYPlot41.getDatasetGroup();
        boolean boolean44 = xYPlot41.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset46, valueAxis47, valueAxis48, xYItemRenderer49);
        java.awt.Graphics2D graphics2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        xYPlot50.drawBackgroundImage(graphics2D51, rectangle2D52);
        org.jfree.chart.plot.PlotOrientation plotOrientation54 = xYPlot50.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis57 = null;
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot(categoryDataset56, categoryAxis57, valueAxis58, categoryItemRenderer59);
        categoryPlot60.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker64 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke65 = categoryMarker64.getOutlineStroke();
        org.jfree.chart.util.Layer layer66 = null;
        boolean boolean67 = categoryPlot60.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker64, layer66);
        java.lang.Comparable comparable68 = categoryMarker64.getKey();
        java.awt.Paint paint69 = categoryMarker64.getPaint();
        org.jfree.chart.util.Layer layer70 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot50.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker64, layer70);
        java.util.Collection collection72 = xYPlot41.getRangeMarkers((int) (short) 100, layer70);
        categoryPlot16.addDomainMarker(0, categoryMarker35, layer70);
        java.lang.String str74 = categoryMarker35.getLabel();
        java.awt.Stroke stroke75 = org.jfree.chart.plot.XYPlot.DEFAULT_CROSSHAIR_STROKE;
        categoryMarker35.setStroke(stroke75);
        xYPlot4.setRangeGridlineStroke(stroke75);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(datasetGroup43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(plotOrientation54);
        org.junit.Assert.assertNotNull(stroke65);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + comparable68 + "' != '" + (byte) 0 + "'", comparable68.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNotNull(layer70);
        org.junit.Assert.assertNull(collection72);
        org.junit.Assert.assertNull(str74);
        org.junit.Assert.assertNotNull(stroke75);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder12);
        categoryPlot4.setForegroundAlpha((float) (short) 100);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryPlot4.getAxisOffset();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = categoryPlot4.getRenderer((-8355840));
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertNull(categoryItemRenderer18);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        boolean boolean2 = numberAxis0.isAutoRange();
        boolean boolean3 = numberAxis0.isVisible();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        xYPlot8.configureDomainAxes();
        xYPlot8.setRangeCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = xYPlot8.getDatasetRenderingOrder();
        boolean boolean14 = numberAxis0.hasListener((java.util.EventListener) xYPlot8);
        numberAxis0.setAutoRangeMinimumSize((double) 0.5f, false);
        numberAxis0.centerRange(100.0d);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        xYPlot4.setRangeAxisLocation((int) 'a', axisLocation11);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot17.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.plot.Marker marker24 = null;
        org.jfree.chart.util.Layer layer25 = null;
        boolean boolean27 = categoryPlot17.removeDomainMarker((int) (byte) 0, marker24, layer25, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray28 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot17.setRangeAxes(valueAxisArray28);
        xYPlot4.setRangeAxes(valueAxisArray28);
        java.awt.Paint paint32 = xYPlot4.getQuadrantPaint(0);
        xYPlot4.clearRangeAxes();
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(valueAxisArray28);
        org.junit.Assert.assertNull(paint32);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        int int15 = categoryPlot4.getBackgroundImageAlignment();
        categoryPlot4.setWeight(10);
        java.awt.Image image18 = null;
        categoryPlot4.setBackgroundImage(image18);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot4.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = categoryPlot4.getDomainAxis(0);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean24 = categoryPlot4.equals((java.lang.Object) color23);
        org.jfree.chart.axis.AxisSpace axisSpace25 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace25);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        xYPlot32.configureDomainAxes();
        xYPlot32.setRangeCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder37 = xYPlot32.getDatasetRenderingOrder();
        org.jfree.chart.plot.CategoryMarker categoryMarker40 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint41 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker40.setLabelPaint(paint41);
        java.lang.Comparable comparable43 = categoryMarker40.getKey();
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer47 = null;
        org.jfree.chart.plot.XYPlot xYPlot48 = new org.jfree.chart.plot.XYPlot(xYDataset44, valueAxis45, valueAxis46, xYItemRenderer47);
        xYPlot48.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup50 = xYPlot48.getDatasetGroup();
        boolean boolean51 = xYPlot48.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot(xYDataset53, valueAxis54, valueAxis55, xYItemRenderer56);
        java.awt.Graphics2D graphics2D58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        xYPlot57.drawBackgroundImage(graphics2D58, rectangle2D59);
        org.jfree.chart.plot.PlotOrientation plotOrientation61 = xYPlot57.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset63 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis64 = null;
        org.jfree.chart.axis.ValueAxis valueAxis65 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer66 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot(categoryDataset63, categoryAxis64, valueAxis65, categoryItemRenderer66);
        categoryPlot67.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker71 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke72 = categoryMarker71.getOutlineStroke();
        org.jfree.chart.util.Layer layer73 = null;
        boolean boolean74 = categoryPlot67.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker71, layer73);
        java.lang.Comparable comparable75 = categoryMarker71.getKey();
        java.awt.Paint paint76 = categoryMarker71.getPaint();
        org.jfree.chart.util.Layer layer77 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot57.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker71, layer77);
        java.util.Collection collection79 = xYPlot48.getRangeMarkers((int) (short) 100, layer77);
        xYPlot32.addDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) categoryMarker40, layer77);
        org.jfree.chart.util.Layer layer81 = null;
        try {
            categoryPlot4.addDomainMarker((int) (byte) -1, categoryMarker40, layer81, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNull(categoryAxis22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder37);
        org.junit.Assert.assertNotNull(paint41);
        org.junit.Assert.assertTrue("'" + comparable43 + "' != '" + (byte) 0 + "'", comparable43.equals((byte) 0));
        org.junit.Assert.assertNull(datasetGroup50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(plotOrientation61);
        org.junit.Assert.assertNotNull(stroke72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + comparable75 + "' != '" + (byte) 0 + "'", comparable75.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertNotNull(layer77);
        org.junit.Assert.assertNull(collection79);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        java.awt.Paint paint2 = numberAxis0.getAxisLinePaint();
        numberAxis0.setLabel("");
        java.awt.Shape shape5 = numberAxis0.getUpArrow();
        numberAxis0.setAutoRangeMinimumSize((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace9);
        java.awt.Paint paint11 = xYPlot6.getDomainCrosshairPaint();
        int int12 = xYPlot6.getRangeAxisCount();
        boolean boolean13 = plotOrientation0.equals((java.lang.Object) xYPlot6);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot18.zoomRangeAxes(0.0d, plotRenderingInfo20, point2D21, false);
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = null;
        boolean boolean28 = categoryPlot18.removeDomainMarker((int) (byte) 0, marker25, layer26, false);
        boolean boolean29 = categoryPlot18.isDomainZoomable();
        boolean boolean30 = xYPlot6.equals((java.lang.Object) categoryPlot18);
        java.awt.Paint paint31 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.axis.ValueAxis valueAxis33 = categoryPlot18.getRangeAxisForDataset((int) '4');
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNull(valueAxis33);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test042");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        int int2 = day1.getMonth();
//        org.jfree.data.xy.XYDataset xYDataset3 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
//        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
//        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
//        xYPlot7.setDomainAxisLocation((int) '4', axisLocation9);
//        boolean boolean12 = xYPlot7.equals((java.lang.Object) 1.0f);
//        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent13 = null;
//        xYPlot7.markerChanged(markerChangeEvent13);
//        org.jfree.chart.util.RectangleInsets rectangleInsets15 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
//        double double17 = rectangleInsets15.calculateRightInset((double) '4');
//        double double19 = rectangleInsets15.extendHeight((double) 1.0f);
//        xYPlot7.setAxisOffset(rectangleInsets15);
//        org.jfree.chart.util.UnitType unitType21 = rectangleInsets15.getUnitType();
//        double double23 = rectangleInsets15.calculateLeftOutset(0.0d);
//        org.jfree.chart.util.UnitType unitType24 = rectangleInsets15.getUnitType();
//        boolean boolean25 = day1.equals((java.lang.Object) unitType24);
//        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder26 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
//        org.jfree.data.xy.XYDataset xYDataset27 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = null;
//        org.jfree.chart.plot.XYPlot xYPlot31 = new org.jfree.chart.plot.XYPlot(xYDataset27, valueAxis28, valueAxis29, xYItemRenderer30);
//        java.awt.Graphics2D graphics2D32 = null;
//        java.awt.geom.Rectangle2D rectangle2D33 = null;
//        xYPlot31.drawBackgroundImage(graphics2D32, rectangle2D33);
//        org.jfree.data.xy.XYDataset xYDataset35 = null;
//        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = xYPlot31.getRendererForDataset(xYDataset35);
//        xYPlot31.mapDatasetToRangeAxis((int) (short) 1, 0);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
//        java.awt.geom.Rectangle2D rectangle2D42 = null;
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor43 = null;
//        java.awt.geom.Point2D point2D44 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D42, rectangleAnchor43);
//        xYPlot31.zoomRangeAxes(4.0d, plotRenderingInfo41, point2D44);
//        org.jfree.chart.util.RectangleEdge rectangleEdge46 = xYPlot31.getDomainAxisEdge();
//        org.jfree.data.category.CategoryDataset categoryDataset47 = null;
//        org.jfree.chart.axis.CategoryAxis categoryAxis48 = null;
//        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
//        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer50 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot(categoryDataset47, categoryAxis48, valueAxis49, categoryItemRenderer50);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo53 = null;
//        java.awt.geom.Point2D point2D54 = null;
//        categoryPlot51.zoomRangeAxes(0.0d, plotRenderingInfo53, point2D54, false);
//        org.jfree.chart.axis.CategoryAxis categoryAxis58 = null;
//        categoryPlot51.setDomainAxis((int) 'a', categoryAxis58, false);
//        xYPlot31.setParent((org.jfree.chart.plot.Plot) categoryPlot51);
//        boolean boolean62 = datasetRenderingOrder26.equals((java.lang.Object) xYPlot31);
//        xYPlot31.mapDatasetToDomainAxis(3, (int) ' ');
//        boolean boolean66 = day1.equals((java.lang.Object) 3);
//        java.lang.Object obj67 = null;
//        boolean boolean68 = day1.equals(obj67);
//        long long69 = day1.getSerialIndex();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(rectangleInsets15);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 4.0d + "'", double17 == 4.0d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 5.0d + "'", double19 == 5.0d);
//        org.junit.Assert.assertNotNull(unitType21);
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 4.0d + "'", double23 == 4.0d);
//        org.junit.Assert.assertNotNull(unitType24);
//        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
//        org.junit.Assert.assertNotNull(datasetRenderingOrder26);
//        org.junit.Assert.assertNull(xYItemRenderer36);
//        org.junit.Assert.assertNotNull(point2D44);
//        org.junit.Assert.assertNotNull(rectangleEdge46);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
//        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
//        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
//        org.junit.Assert.assertTrue("'" + long69 + "' != '" + 43629L + "'", long69 == 43629L);
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Stroke stroke8 = xYPlot4.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis10 = xYPlot4.getRangeAxis(10);
        xYPlot4.setDomainCrosshairValue(0.0d, false);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder14 = xYPlot4.getSeriesRenderingOrder();
        java.lang.Class<?> wildcardClass15 = seriesRenderingOrder14.getClass();
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = xYPlot20.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace23 = null;
        xYPlot20.setFixedRangeAxisSpace(axisSpace23);
        java.awt.Paint paint25 = xYPlot20.getDomainGridlinePaint();
        boolean boolean26 = xYPlot20.isDomainCrosshairVisible();
        boolean boolean27 = xYPlot20.isRangeZeroBaselineVisible();
        boolean boolean28 = seriesRenderingOrder14.equals((java.lang.Object) xYPlot20);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(seriesRenderingOrder14);
        org.junit.Assert.assertNotNull(wildcardClass15);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        java.awt.geom.Point2D point2D18 = xYPlot4.getQuadrantOrigin();
        java.awt.Paint paint19 = xYPlot4.getNoDataMessagePaint();
        org.jfree.chart.axis.AxisLocation axisLocation21 = xYPlot4.getDomainAxisLocation(9);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
        org.junit.Assert.assertNotNull(point2D18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        int int5 = xYPlot4.getSeriesCount();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = xYPlot4.getFixedLegendItems();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = xYPlot4.getLegendItems();
        java.awt.Image image8 = null;
        xYPlot4.setBackgroundImage(image8);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis3.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis3.configure();
        double double8 = categoryAxis3.getCategoryMargin();
        int int9 = categoryAxis3.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat11 = dateAxis10.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis10.setTickUnit(dateTickUnit12, false, true);
        dateAxis10.setRange((double) (byte) 1, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        double double22 = numberAxis21.getUpperBound();
        java.awt.Color color23 = java.awt.Color.WHITE;
        numberAxis21.setTickMarkPaint((java.awt.Paint) color23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer25);
        java.lang.String str28 = categoryAxis3.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        int int29 = categoryAxis3.getCategoryLabelPositionOffset();
        boolean boolean31 = categoryAxis3.equals((java.lang.Object) "RectangleAnchor.RIGHT");
        categoryAxis3.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(dateFormat11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 4 + "'", int29 == 4);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot4.getRangeAxisEdge();
        double double17 = categoryPlot4.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        numberAxis14.setAutoRangeMinimumSize((double) (short) 100);
        numberAxis14.setRange((double) (-1), Double.NaN);
        numberAxis14.setRange((double) (-8355840), (double) 100);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CONTRACT");
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        numberAxis13.setAutoRangeStickyZero(false);
        double double17 = numberAxis13.getLowerMargin();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit18 = null;
        try {
            numberAxis13.setTickUnit(numberTickUnit18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unit' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.05d + "'", double17 == 0.05d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextOutlineStroke();
        java.awt.Stroke stroke3 = defaultDrawingSupplier1.getNextStroke();
        java.awt.Paint paint4 = defaultDrawingSupplier1.getNextOutlinePaint();
        boolean boolean5 = objectList0.equals((java.lang.Object) defaultDrawingSupplier1);
        java.lang.Object obj7 = objectList0.get(0);
        java.awt.Color color9 = java.awt.Color.red;
        objectList0.set((int) (short) 1, (java.lang.Object) color9);
        java.awt.Color color11 = java.awt.Color.LIGHT_GRAY;
        java.awt.color.ColorSpace colorSpace12 = color11.getColorSpace();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray20 = new float[] { 'a', (short) -1, ' ', 10.0f, 0, 0 };
        float[] floatArray21 = color13.getRGBColorComponents(floatArray20);
        float[] floatArray22 = color11.getRGBColorComponents(floatArray21);
        float[] floatArray23 = color9.getRGBComponents(floatArray22);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(colorSpace12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder12 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot4.setDomainAxisLocation((int) ' ', axisLocation15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot4.getAxisOffset();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder12);
        org.junit.Assert.assertNotNull(rectangleInsets17);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        java.awt.Color color3 = java.awt.Color.getHSBColor(2.0f, (float) 1, (float) 0);
        java.awt.Color color4 = java.awt.Color.BLACK;
        int int5 = color4.getGreen();
        java.awt.Color color6 = java.awt.Color.LIGHT_GRAY;
        java.awt.color.ColorSpace colorSpace7 = color6.getColorSpace();
        java.awt.Color color8 = java.awt.Color.LIGHT_GRAY;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray17 = new float[] { 'a', (short) -1, ' ', 10.0f, 0, 0 };
        float[] floatArray18 = color10.getRGBColorComponents(floatArray17);
        float[] floatArray19 = color8.getRGBColorComponents(floatArray18);
        float[] floatArray20 = color4.getColorComponents(colorSpace7, floatArray18);
        float[] floatArray21 = color3.getRGBColorComponents(floatArray18);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(colorSpace7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertNotNull(floatArray20);
        org.junit.Assert.assertNotNull(floatArray21);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test054");
//        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
//        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
//        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
//        int int4 = day1.getDayOfMonth();
//        org.junit.Assert.assertNotNull(date0);
//        org.junit.Assert.assertNotNull(serialDate2);
//        org.junit.Assert.assertNotNull(serialDate3);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 13 + "'", int4 == 13);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace11, false);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot4.getLegendItems();
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot4.getRangeAxisLocation();
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        boolean boolean2 = numberAxis0.isAutoRange();
        java.awt.Shape shape3 = numberAxis0.getDownArrow();
        numberAxis0.centerRange(0.0d);
        java.text.NumberFormat numberFormat6 = null;
        numberAxis0.setNumberFormatOverride(numberFormat6);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(shape3);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        xYPlot6.drawBackgroundImage(graphics2D7, rectangle2D8);
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = xYPlot6.getRendererForDataset(xYDataset10);
        int int12 = xYPlot6.getSeriesCount();
        boolean boolean13 = lengthAdjustmentType0.equals((java.lang.Object) xYPlot6);
        xYPlot6.setWeight(10);
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "NO_CHANGE" + "'", str1.equals("NO_CHANGE"));
        org.junit.Assert.assertNull(xYItemRenderer11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        int int15 = categoryPlot4.getBackgroundImageAlignment();
        boolean boolean16 = categoryPlot4.isDomainZoomable();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        xYPlot21.setDomainAxisLocation((int) '4', axisLocation23);
        boolean boolean25 = xYPlot21.isRangeZoomable();
        xYPlot21.setRangeCrosshairValue((double) 1, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker30 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke31 = categoryMarker30.getOutlineStroke();
        xYPlot21.setRangeGridlineStroke(stroke31);
        categoryPlot4.setRangeCrosshairStroke(stroke31);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) '4');
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        xYPlot7.drawBackgroundImage(graphics2D8, rectangle2D9);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = xYPlot7.getOrientation();
        org.jfree.data.general.DatasetGroup datasetGroup12 = xYPlot7.getDatasetGroup();
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke15 = categoryMarker14.getOutlineStroke();
        xYPlot7.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker14);
        java.lang.String str17 = xYPlot7.getPlotType();
        org.jfree.data.xy.XYDataset xYDataset19 = xYPlot7.getDataset((int) (byte) 0);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot26.zoomRangeAxes(0.0d, plotRenderingInfo28, point2D29, false);
        org.jfree.chart.axis.AxisSpace axisSpace32 = categoryPlot26.getFixedDomainAxisSpace();
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        categoryPlot26.setDomainAxis((int) (byte) 1, categoryAxis34);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis37.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis37.configure();
        java.util.List list42 = categoryPlot26.getCategoriesForAxis(categoryAxis37);
        xYPlot7.drawRangeTickBands(graphics2D20, rectangle2D21, list42);
        try {
            objectList1.set((int) (short) -1, (java.lang.Object) rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNull(datasetGroup12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "XY Plot" + "'", str17.equals("XY Plot"));
        org.junit.Assert.assertNull(xYDataset19);
        org.junit.Assert.assertNull(axisSpace32);
        org.junit.Assert.assertNotNull(list42);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean8 = xYPlot4.isRangeZoomable();
        xYPlot4.setRangeCrosshairValue((double) 1, false);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        categoryPlot16.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke21 = categoryMarker20.getOutlineStroke();
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = categoryPlot16.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker20, layer22);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot16.setDatasetRenderingOrder(datasetRenderingOrder24);
        categoryPlot16.setForegroundAlpha((float) (short) 100);
        org.jfree.data.general.Dataset dataset28 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent29 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (short) 100, dataset28);
        xYPlot4.datasetChanged(datasetChangeEvent29);
        org.jfree.chart.plot.Marker marker32 = null;
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis35, categoryItemRenderer36);
        categoryPlot37.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = categoryPlot37.getDomainAxis((int) (short) 100);
        boolean boolean42 = categoryPlot37.isRangeGridlinesVisible();
        java.awt.Paint paint43 = categoryPlot37.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset45 = categoryPlot37.getDataset(0);
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean47 = categoryPlot37.equals((java.lang.Object) color46);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset49, valueAxis50, valueAxis51, xYItemRenderer52);
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        xYPlot53.drawBackgroundImage(graphics2D54, rectangle2D55);
        org.jfree.chart.plot.PlotOrientation plotOrientation57 = xYPlot53.getOrientation();
        org.jfree.data.general.DatasetGroup datasetGroup58 = xYPlot53.getDatasetGroup();
        org.jfree.chart.plot.CategoryMarker categoryMarker60 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke61 = categoryMarker60.getOutlineStroke();
        xYPlot53.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker60);
        org.jfree.chart.util.Layer layer63 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean65 = categoryPlot37.removeDomainMarker(500, (org.jfree.chart.plot.Marker) categoryMarker60, layer63, false);
        java.lang.String str66 = layer63.toString();
        try {
            xYPlot4.addRangeMarker((int) ' ', marker32, layer63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertNull(categoryAxis41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNull(categoryDataset45);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(plotOrientation57);
        org.junit.Assert.assertNull(datasetGroup58);
        org.junit.Assert.assertNotNull(stroke61);
        org.junit.Assert.assertNotNull(layer63);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + str66 + "' != '" + "Layer.FOREGROUND" + "'", str66.equals("Layer.FOREGROUND"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot6.setDomainAxisLocation((int) '4', axisLocation8);
        boolean boolean11 = xYPlot6.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot6.markerChanged(markerChangeEvent12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double16 = rectangleInsets14.calculateRightInset((double) '4');
        double double18 = rectangleInsets14.extendHeight((double) 1.0f);
        xYPlot6.setAxisOffset(rectangleInsets14);
        xYPlot6.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker23);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYPlot30.drawBackgroundImage(graphics2D31, rectangle2D32);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = xYPlot30.getRendererForDataset(xYDataset34);
        xYPlot30.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        int int40 = xYPlot30.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis39);
        double double41 = numberAxis39.getUpperBound();
        numberAxis39.setFixedAutoRange((double) 100);
        xYPlot6.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis39);
        numberAxis39.setUpperBound((-1.0d));
        java.awt.Stroke stroke47 = numberAxis39.getTickMarkStroke();
        dateAxis0.setAxisLineStroke(stroke47);
        dateAxis0.configure();
        dateAxis0.configure();
        dateAxis0.configure();
        boolean boolean53 = dateAxis0.isHiddenValue(0L);
        java.lang.String str54 = dateAxis0.getLabel();
        boolean boolean55 = dateAxis0.isAutoTickUnitSelection();
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 5.0d + "'", double18 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis3.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis3.configure();
        double double8 = categoryAxis3.getCategoryMargin();
        int int9 = categoryAxis3.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat11 = dateAxis10.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis10.setTickUnit(dateTickUnit12, false, true);
        dateAxis10.setRange((double) (byte) 1, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        double double22 = numberAxis21.getUpperBound();
        java.awt.Color color23 = java.awt.Color.WHITE;
        numberAxis21.setTickMarkPaint((java.awt.Paint) color23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer25);
        java.lang.String str28 = categoryAxis3.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        double double29 = categoryAxis3.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(dateFormat11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        java.awt.Color color0 = java.awt.Color.gray;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 128 + "'", int1 == 128);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean8 = xYPlot4.isRangeZoomable();
        boolean boolean9 = xYPlot4.isRangeZeroBaselineVisible();
        boolean boolean10 = xYPlot4.isDomainZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        org.jfree.data.xy.XYDataset xYDataset13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer16 = null;
        org.jfree.chart.plot.XYPlot xYPlot17 = new org.jfree.chart.plot.XYPlot(xYDataset13, valueAxis14, valueAxis15, xYItemRenderer16);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        xYPlot17.drawBackgroundImage(graphics2D18, rectangle2D19);
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = xYPlot17.getRendererForDataset(xYDataset21);
        xYPlot17.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor29 = null;
        java.awt.geom.Point2D point2D30 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D28, rectangleAnchor29);
        xYPlot17.zoomRangeAxes(4.0d, plotRenderingInfo27, point2D30);
        xYPlot4.zoomRangeAxes((double) (byte) 10, plotRenderingInfo12, point2D30);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset33, valueAxis34, valueAxis35, xYItemRenderer36);
        org.jfree.chart.axis.AxisLocation axisLocation39 = null;
        xYPlot37.setDomainAxisLocation((int) '4', axisLocation39);
        boolean boolean42 = xYPlot37.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent43 = null;
        xYPlot37.markerChanged(markerChangeEvent43);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double47 = rectangleInsets45.calculateRightInset((double) '4');
        double double49 = rectangleInsets45.extendHeight((double) 1.0f);
        xYPlot37.setAxisOffset(rectangleInsets45);
        java.awt.Font font51 = xYPlot37.getNoDataMessageFont();
        xYPlot4.setNoDataMessageFont(font51);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNull(xYItemRenderer22);
        org.junit.Assert.assertNotNull(point2D30);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 4.0d + "'", double47 == 4.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 5.0d + "'", double49 == 5.0d);
        org.junit.Assert.assertNotNull(font51);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        xYPlot4.zoomRangeAxes(4.0d, plotRenderingInfo14, point2D17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = xYPlot4.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot(categoryDataset20, categoryAxis21, valueAxis22, categoryItemRenderer23);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot24.zoomRangeAxes(0.0d, plotRenderingInfo26, point2D27, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        categoryPlot24.setDomainAxis((int) 'a', categoryAxis31, false);
        xYPlot4.setParent((org.jfree.chart.plot.Plot) categoryPlot24);
        org.jfree.chart.axis.DateAxis dateAxis35 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = null;
        double double39 = dateAxis35.java2DToValue((double) 10.0f, rectangle2D37, rectangleEdge38);
        java.text.DateFormat dateFormat40 = null;
        dateAxis35.setDateFormatOverride(dateFormat40);
        org.jfree.chart.axis.Timeline timeline42 = dateAxis35.getTimeline();
        org.jfree.data.Range range43 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis35);
        org.jfree.chart.event.PlotChangeListener plotChangeListener44 = null;
        xYPlot4.removeChangeListener(plotChangeListener44);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 9.223372036854776E18d + "'", double39 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(timeline42);
        org.junit.Assert.assertNull(range43);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        int int5 = day4.getYear();
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.jfree.data.time.DateRange dateRange0 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_RANGE;
        org.junit.Assert.assertNotNull(dateRange0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        xYPlot4.setRenderer((int) (short) 10, xYItemRenderer14, true);
        java.awt.Paint paint17 = xYPlot4.getRangeGridlinePaint();
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset18, valueAxis19, valueAxis20, xYItemRenderer21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot22.drawBackgroundImage(graphics2D23, rectangle2D24);
        java.awt.Stroke stroke26 = xYPlot22.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis28 = xYPlot22.getRangeAxis(10);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = xYPlot22.getRenderer();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent30 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) xYPlot22);
        xYPlot4.notifyListeners(plotChangeEvent30);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(valueAxis28);
        org.junit.Assert.assertNull(xYItemRenderer29);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot4.getRangeAxis(0);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot23.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot23.setFixedRangeAxisSpace(axisSpace26);
        java.awt.Paint paint28 = xYPlot23.getDomainGridlinePaint();
        categoryPlot4.setParent((org.jfree.chart.plot.Plot) xYPlot23);
        xYPlot23.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.axis.DateAxis dateAxis33 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat34 = dateAxis33.getDateFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer38 = null;
        org.jfree.chart.plot.XYPlot xYPlot39 = new org.jfree.chart.plot.XYPlot(xYDataset35, valueAxis36, valueAxis37, xYItemRenderer38);
        org.jfree.chart.axis.AxisLocation axisLocation41 = null;
        xYPlot39.setDomainAxisLocation((int) '4', axisLocation41);
        boolean boolean44 = xYPlot39.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent45 = null;
        xYPlot39.markerChanged(markerChangeEvent45);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double49 = rectangleInsets47.calculateRightInset((double) '4');
        double double51 = rectangleInsets47.extendHeight((double) 1.0f);
        xYPlot39.setAxisOffset(rectangleInsets47);
        xYPlot39.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker56 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot39.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker56);
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot(xYDataset59, valueAxis60, valueAxis61, xYItemRenderer62);
        java.awt.Graphics2D graphics2D64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        xYPlot63.drawBackgroundImage(graphics2D64, rectangle2D65);
        org.jfree.data.xy.XYDataset xYDataset67 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = xYPlot63.getRendererForDataset(xYDataset67);
        xYPlot63.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis72 = new org.jfree.chart.axis.NumberAxis();
        int int73 = xYPlot63.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis72);
        double double74 = numberAxis72.getUpperBound();
        numberAxis72.setFixedAutoRange((double) 100);
        xYPlot39.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis72);
        numberAxis72.setUpperBound((-1.0d));
        java.awt.Stroke stroke80 = numberAxis72.getTickMarkStroke();
        dateAxis33.setAxisLineStroke(stroke80);
        dateAxis33.configure();
        dateAxis33.configure();
        xYPlot23.setRangeAxis((int) (short) 100, (org.jfree.chart.axis.ValueAxis) dateAxis33);
        xYPlot23.mapDatasetToDomainAxis(500, 11);
        xYPlot23.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(dateFormat34);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 4.0d + "'", double49 == 4.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 5.0d + "'", double51 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer68);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 1.0d + "'", double74 == 1.0d);
        org.junit.Assert.assertNotNull(stroke80);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        categoryPlot4.setNoDataMessage("hi!");
        boolean boolean12 = categoryPlot4.isDomainGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        categoryPlot4.setDataset(categoryDataset13);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = categoryPlot4.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(drawingSupplier15);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        xYPlot4.setRangeAxisLocation((int) 'a', axisLocation11);
        boolean boolean13 = xYPlot4.isDomainZeroBaselineVisible();
        java.awt.Font font14 = xYPlot4.getNoDataMessageFont();
        boolean boolean15 = xYPlot4.isOutlineVisible();
        boolean boolean16 = xYPlot4.isDomainCrosshairLockedOnData();
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        int int3 = java.awt.Color.HSBtoRGB((float) 8, (float) 100, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-83) + "'", int3 == (-83));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat3 = dateAxis2.getDateFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        xYPlot8.setDomainAxisLocation((int) '4', axisLocation10);
        boolean boolean13 = xYPlot8.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot8.markerChanged(markerChangeEvent14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double18 = rectangleInsets16.calculateRightInset((double) '4');
        double double20 = rectangleInsets16.extendHeight((double) 1.0f);
        xYPlot8.setAxisOffset(rectangleInsets16);
        xYPlot8.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot8.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker25);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        xYPlot32.drawBackgroundImage(graphics2D33, rectangle2D34);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = xYPlot32.getRendererForDataset(xYDataset36);
        xYPlot32.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        int int42 = xYPlot32.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis41);
        double double43 = numberAxis41.getUpperBound();
        numberAxis41.setFixedAutoRange((double) 100);
        xYPlot8.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis41);
        numberAxis41.setUpperBound((-1.0d));
        java.awt.Stroke stroke49 = numberAxis41.getTickMarkStroke();
        dateAxis2.setAxisLineStroke(stroke49);
        org.jfree.chart.plot.CategoryMarker categoryMarker51 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) -1, (java.awt.Paint) color1, stroke49);
        org.jfree.chart.text.TextAnchor textAnchor52 = categoryMarker51.getLabelTextAnchor();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNull(dateFormat3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 5.0d + "'", double20 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNotNull(textAnchor52);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        xYPlot4.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker21);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        xYPlot28.drawBackgroundImage(graphics2D29, rectangle2D30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot28.getRendererForDataset(xYDataset32);
        xYPlot28.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        int int38 = xYPlot28.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis37);
        double double39 = numberAxis37.getUpperBound();
        numberAxis37.setFixedAutoRange((double) 100);
        xYPlot4.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis37);
        org.jfree.chart.JFreeChart jFreeChart43 = null;
        org.jfree.chart.util.UnitType unitType44 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.JFreeChart jFreeChart45 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType46 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent47 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) unitType44, jFreeChart45, chartChangeEventType46);
        java.lang.String str48 = chartChangeEvent47.toString();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType49 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        chartChangeEvent47.setType(chartChangeEventType49);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent51 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) numberAxis37, jFreeChart43, chartChangeEventType49);
        java.lang.String str52 = numberAxis37.getLabelToolTip();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(unitType44);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]" + "'", str48.equals("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]"));
        org.junit.Assert.assertNotNull(chartChangeEventType49);
        org.junit.Assert.assertNull(str52);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup6 = xYPlot4.getDatasetGroup();
        xYPlot4.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot4.getRangeAxisLocation((-1));
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = xYPlot15.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace18 = null;
        xYPlot15.setFixedRangeAxisSpace(axisSpace18);
        java.awt.Paint paint20 = xYPlot15.getDomainGridlinePaint();
        boolean boolean21 = xYPlot15.isDomainCrosshairVisible();
        boolean boolean22 = xYPlot15.isRangeZeroBaselineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset23 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot(categoryDataset23, categoryAxis24, valueAxis25, categoryItemRenderer26);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot27.zoomRangeAxes(0.0d, plotRenderingInfo29, point2D30, false);
        org.jfree.chart.plot.Marker marker34 = null;
        org.jfree.chart.util.Layer layer35 = null;
        boolean boolean37 = categoryPlot27.removeDomainMarker((int) (byte) 0, marker34, layer35, false);
        int int38 = categoryPlot27.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset39 = categoryPlot27.getDataset();
        org.jfree.data.xy.XYDataset xYDataset40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer43 = null;
        org.jfree.chart.plot.XYPlot xYPlot44 = new org.jfree.chart.plot.XYPlot(xYDataset40, valueAxis41, valueAxis42, xYItemRenderer43);
        org.jfree.chart.axis.AxisLocation axisLocation46 = null;
        xYPlot44.setDomainAxisLocation((int) '4', axisLocation46);
        boolean boolean49 = xYPlot44.equals((java.lang.Object) 1.0f);
        org.jfree.data.category.CategoryDataset categoryDataset50 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot(categoryDataset50, categoryAxis51, valueAxis52, categoryItemRenderer53);
        categoryPlot54.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker58 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke59 = categoryMarker58.getOutlineStroke();
        org.jfree.chart.util.Layer layer60 = null;
        boolean boolean61 = categoryPlot54.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker58, layer60);
        org.jfree.chart.axis.AxisLocation axisLocation63 = categoryPlot54.getDomainAxisLocation((int) '#');
        xYPlot44.setDomainAxisLocation(axisLocation63, false);
        categoryPlot27.setRangeAxisLocation(axisLocation63, true);
        xYPlot15.setRangeAxisLocation(axisLocation63);
        xYPlot4.setRangeAxisLocation((int) (byte) 100, axisLocation63);
        org.jfree.chart.annotations.XYAnnotation xYAnnotation70 = null;
        try {
            boolean boolean72 = xYPlot4.removeAnnotation(xYAnnotation70, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 15 + "'", int38 == 15);
        org.junit.Assert.assertNull(categoryDataset39);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(axisLocation63);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = categoryPlot4.getRenderer(10);
        categoryPlot4.setDrawSharedDomainAxis(false);
        categoryPlot4.clearDomainAxes();
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace10, false);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot4.getRendererForDataset(categoryDataset13);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation15 = null;
        try {
            boolean boolean17 = categoryPlot4.removeAnnotation(categoryAnnotation15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer6);
        org.junit.Assert.assertNull(categoryItemRenderer14);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        int int15 = categoryPlot4.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        categoryPlot4.setDataset(categoryDataset16);
        org.jfree.chart.plot.Marker marker19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, valueAxis22, xYItemRenderer23);
        xYPlot24.configureDomainAxes();
        xYPlot24.setRangeCrosshairValue((double) (byte) 0, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder29 = xYPlot24.getDatasetRenderingOrder();
        org.jfree.chart.plot.CategoryMarker categoryMarker32 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint33 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker32.setLabelPaint(paint33);
        java.lang.Comparable comparable35 = categoryMarker32.getKey();
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset36, valueAxis37, valueAxis38, xYItemRenderer39);
        xYPlot40.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup42 = xYPlot40.getDatasetGroup();
        boolean boolean43 = xYPlot40.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer48 = null;
        org.jfree.chart.plot.XYPlot xYPlot49 = new org.jfree.chart.plot.XYPlot(xYDataset45, valueAxis46, valueAxis47, xYItemRenderer48);
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        xYPlot49.drawBackgroundImage(graphics2D50, rectangle2D51);
        org.jfree.chart.plot.PlotOrientation plotOrientation53 = xYPlot49.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset55 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis56 = null;
        org.jfree.chart.axis.ValueAxis valueAxis57 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer58 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot(categoryDataset55, categoryAxis56, valueAxis57, categoryItemRenderer58);
        categoryPlot59.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker63 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke64 = categoryMarker63.getOutlineStroke();
        org.jfree.chart.util.Layer layer65 = null;
        boolean boolean66 = categoryPlot59.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker63, layer65);
        java.lang.Comparable comparable67 = categoryMarker63.getKey();
        java.awt.Paint paint68 = categoryMarker63.getPaint();
        org.jfree.chart.util.Layer layer69 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot49.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker63, layer69);
        java.util.Collection collection71 = xYPlot40.getRangeMarkers((int) (short) 100, layer69);
        xYPlot24.addDomainMarker((int) (short) -1, (org.jfree.chart.plot.Marker) categoryMarker32, layer69);
        boolean boolean74 = categoryPlot4.removeDomainMarker(2, marker19, layer69, false);
        org.jfree.chart.plot.IntervalMarker intervalMarker77 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        double double78 = intervalMarker77.getEndValue();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent79 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker77);
        double double80 = intervalMarker77.getEndValue();
        intervalMarker77.setEndValue(0.05d);
        java.awt.Paint paint83 = intervalMarker77.getLabelPaint();
        org.jfree.chart.plot.IntervalMarker intervalMarker86 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        double double87 = intervalMarker86.getEndValue();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent88 = new org.jfree.chart.event.MarkerChangeEvent((org.jfree.chart.plot.Marker) intervalMarker86);
        org.jfree.chart.plot.Marker marker89 = markerChangeEvent88.getMarker();
        intervalMarker77.notifyListeners(markerChangeEvent88);
        categoryPlot4.markerChanged(markerChangeEvent88);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder29);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + comparable35 + "' != '" + (byte) 0 + "'", comparable35.equals((byte) 0));
        org.junit.Assert.assertNull(datasetGroup42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(plotOrientation53);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + comparable67 + "' != '" + (byte) 0 + "'", comparable67.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint68);
        org.junit.Assert.assertNotNull(layer69);
        org.junit.Assert.assertNull(collection71);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + (-1.0d) + "'", double78 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + (-1.0d) + "'", double80 == (-1.0d));
        org.junit.Assert.assertNotNull(paint83);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + (-1.0d) + "'", double87 == (-1.0d));
        org.junit.Assert.assertNotNull(marker89);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean8 = xYPlot4.isRangeZoomable();
        boolean boolean9 = xYPlot4.isRangeZeroBaselineVisible();
        java.lang.Object obj10 = xYPlot4.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = xYPlot4.getLegendItems();
        xYPlot4.setRangeCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.java2DToValue((double) 10.0f, rectangle2D2, rectangleEdge3);
        java.lang.Object obj5 = dateAxis0.clone();
        float float6 = dateAxis0.getTickMarkInsideLength();
        double double7 = dateAxis0.getAutoRangeMinimumSize();
        dateAxis0.zoomRange((double) 15, (double) '#');
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.223372036854776E18d + "'", double4 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.0d + "'", double7 == 2.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (byte) -1, (double) 0.5f, (double) 0L, (double) (short) -1);
        double double6 = rectangleInsets4.calculateBottomInset((double) (byte) 100);
        double double8 = rectangleInsets4.trimHeight((double) 1);
        double double10 = rectangleInsets4.trimHeight((double) 1560495599999L);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.5604956E12d + "'", double10 == 1.5604956E12d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setLabelURL("");
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double20 = rectangleInsets18.calculateRightInset((double) '4');
        double double22 = rectangleInsets18.extendHeight((double) 1.0f);
        numberAxis13.setLabelInsets(rectangleInsets18);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint26 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker25.setLabelPaint(paint26);
        numberAxis13.setAxisLinePaint(paint26);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand29 = null;
        numberAxis13.setMarkerBand(markerAxisBand29);
        numberAxis13.setTickMarkInsideLength((float) 5);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 4.0d + "'", double20 == 4.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 5.0d + "'", double22 == 5.0d);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot11.zoomRangeAxes(0.0d, plotRenderingInfo13, point2D14, false);
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean21 = categoryPlot11.removeDomainMarker((int) (byte) 0, marker18, layer19, false);
        categoryPlot11.setBackgroundAlpha((float) 0);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot11.getRangeAxis(0);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = xYPlot30.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace33);
        java.awt.Paint paint35 = xYPlot30.getDomainGridlinePaint();
        categoryPlot11.setParent((org.jfree.chart.plot.Plot) xYPlot30);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        java.util.List list38 = categoryPlot11.getCategoriesForAxis(categoryAxis37);
        xYPlot4.drawRangeTickBands(graphics2D5, rectangle2D6, list38);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer41 = xYPlot4.getRenderer((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNull(xYItemRenderer41);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.data.category.CategoryDataset categoryDataset7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset7, categoryAxis8, valueAxis9, categoryItemRenderer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot11.zoomRangeAxes(0.0d, plotRenderingInfo13, point2D14, false);
        org.jfree.chart.plot.Marker marker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        boolean boolean21 = categoryPlot11.removeDomainMarker((int) (byte) 0, marker18, layer19, false);
        categoryPlot11.setBackgroundAlpha((float) 0);
        org.jfree.chart.axis.ValueAxis valueAxis25 = categoryPlot11.getRangeAxis(0);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = xYPlot30.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace33 = null;
        xYPlot30.setFixedRangeAxisSpace(axisSpace33);
        java.awt.Paint paint35 = xYPlot30.getDomainGridlinePaint();
        categoryPlot11.setParent((org.jfree.chart.plot.Plot) xYPlot30);
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        java.util.List list38 = categoryPlot11.getCategoriesForAxis(categoryAxis37);
        xYPlot4.drawRangeTickBands(graphics2D5, rectangle2D6, list38);
        xYPlot4.clearDomainMarkers(2);
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder42 = xYPlot4.getSeriesRenderingOrder();
        try {
            java.awt.Paint paint44 = xYPlot4.getQuadrantPaint((-4144960));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The index value (-4144960) should be in the range 0 to 3.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(valueAxis25);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(list38);
        org.junit.Assert.assertNotNull(seriesRenderingOrder42);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        java.awt.Paint paint3 = intervalMarker2.getPaint();
        intervalMarker2.setEndValue(2.0d);
        java.awt.Paint paint6 = intervalMarker2.getPaint();
        intervalMarker2.setEndValue(10.0d);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.plot.CategoryMarker categoryMarker17 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke18 = categoryMarker17.getOutlineStroke();
        org.jfree.chart.text.TextAnchor textAnchor19 = categoryMarker17.getLabelTextAnchor();
        boolean boolean20 = categoryPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) categoryMarker17);
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        categoryPlot4.setDataset(categoryDataset21);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(textAnchor19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        java.awt.Stroke stroke16 = categoryPlot4.getDomainGridlineStroke();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        xYPlot21.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup23 = xYPlot21.getDatasetGroup();
        boolean boolean24 = xYPlot21.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        java.awt.Graphics2D graphics2D30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        xYPlot29.drawBackgroundImage(graphics2D30, rectangle2D31);
        org.jfree.chart.plot.PlotOrientation plotOrientation33 = xYPlot29.getOrientation();
        org.jfree.data.general.DatasetGroup datasetGroup34 = xYPlot29.getDatasetGroup();
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke37 = categoryMarker36.getOutlineStroke();
        xYPlot29.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker36);
        org.jfree.data.category.CategoryDataset categoryDataset39 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot(categoryDataset39, categoryAxis40, valueAxis41, categoryItemRenderer42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        categoryPlot43.zoomRangeAxes(0.0d, plotRenderingInfo45, point2D46, false);
        org.jfree.chart.axis.AxisSpace axisSpace49 = categoryPlot43.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace50 = null;
        categoryPlot43.setFixedRangeAxisSpace(axisSpace50, false);
        org.jfree.chart.LegendItemCollection legendItemCollection53 = categoryPlot43.getLegendItems();
        xYPlot29.setFixedLegendItems(legendItemCollection53);
        xYPlot21.setFixedLegendItems(legendItemCollection53);
        categoryPlot4.setFixedLegendItems(legendItemCollection53);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder57 = categoryPlot4.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(datasetGroup23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(plotOrientation33);
        org.junit.Assert.assertNull(datasetGroup34);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(axisSpace49);
        org.junit.Assert.assertNotNull(legendItemCollection53);
        org.junit.Assert.assertNotNull(datasetRenderingOrder57);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainGridlinePaint();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = null;
        xYPlot4.axisChanged(axisChangeEvent10);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        java.awt.Paint paint3 = intervalMarker2.getPaint();
        intervalMarker2.setEndValue(2.0d);
        java.awt.Paint paint6 = intervalMarker2.getPaint();
        org.jfree.chart.util.UnitType unitType7 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) unitType7, jFreeChart8, chartChangeEventType9);
        java.lang.String str11 = unitType7.toString();
        java.lang.String str12 = unitType7.toString();
        boolean boolean13 = intervalMarker2.equals((java.lang.Object) str12);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(unitType7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "UnitType.RELATIVE" + "'", str11.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "UnitType.RELATIVE" + "'", str12.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.java2DToValue((double) 10.0f, rectangle2D2, rectangleEdge3);
        java.text.DateFormat dateFormat5 = null;
        dateAxis0.setDateFormatOverride(dateFormat5);
        org.jfree.chart.axis.Timeline timeline7 = dateAxis0.getTimeline();
        org.jfree.chart.plot.Plot plot8 = dateAxis0.getPlot();
        dateAxis0.configure();
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        xYPlot18.drawBackgroundImage(graphics2D19, rectangle2D20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = xYPlot18.getRendererForDataset(xYDataset22);
        org.jfree.chart.axis.AxisLocation axisLocation25 = null;
        xYPlot18.setRangeAxisLocation((int) 'a', axisLocation25);
        java.lang.String str27 = xYPlot18.getPlotType();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot18.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            org.jfree.chart.axis.AxisState axisState31 = dateAxis0.draw(graphics2D10, (double) (-83), rectangle2D12, rectangle2D13, rectangleEdge29, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.223372036854776E18d + "'", double4 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(timeline7);
        org.junit.Assert.assertNull(plot8);
        org.junit.Assert.assertNull(xYItemRenderer23);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "XY Plot" + "'", str27.equals("XY Plot"));
        org.junit.Assert.assertNotNull(rectangleEdge29);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot4.getRangeAxis(0);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot23.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot23.setFixedRangeAxisSpace(axisSpace26);
        java.awt.Paint paint28 = xYPlot23.getDomainGridlinePaint();
        categoryPlot4.setParent((org.jfree.chart.plot.Plot) xYPlot23);
        java.lang.String str30 = xYPlot23.getNoDataMessage();
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = null;
        org.jfree.chart.plot.XYPlot xYPlot36 = new org.jfree.chart.plot.XYPlot(xYDataset32, valueAxis33, valueAxis34, xYItemRenderer35);
        xYPlot36.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup38 = xYPlot36.getDatasetGroup();
        xYPlot36.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation41 = xYPlot36.getRangeAxisLocation((-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker45 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint46 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker45.setLabelPaint(paint46);
        java.lang.Comparable comparable48 = categoryMarker45.getKey();
        org.jfree.chart.util.Layer layer49 = null;
        categoryPlot43.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker45, layer49);
        org.jfree.chart.axis.AxisLocation axisLocation51 = categoryPlot43.getRangeAxisLocation();
        xYPlot36.setDomainAxisLocation(0, axisLocation51);
        xYPlot23.setDomainAxisLocation((int) '#', axisLocation51);
        org.jfree.chart.plot.Plot plot54 = xYPlot23.getParent();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertNull(datasetGroup38);
        org.junit.Assert.assertNotNull(axisLocation41);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertTrue("'" + comparable48 + "' != '" + (byte) 0 + "'", comparable48.equals((byte) 0));
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNull(plot54);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        boolean boolean7 = categoryPlot4.isRangeGridlinesVisible();
        boolean boolean8 = categoryPlot4.isSubplot();
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        boolean boolean13 = categoryPlot4.render(graphics2D9, rectangle2D10, (int) (short) -1, plotRenderingInfo12);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        double double18 = dateAxis14.java2DToValue((double) 10.0f, rectangle2D16, rectangleEdge17);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot23.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot23.setFixedRangeAxisSpace(axisSpace26);
        java.awt.Paint paint28 = xYPlot23.getDomainCrosshairPaint();
        java.awt.Color color29 = java.awt.Color.BLACK;
        xYPlot23.setRangeZeroBaselinePaint((java.awt.Paint) color29);
        dateAxis14.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot23);
        dateAxis14.zoomRange((double) 4, (double) 11);
        org.jfree.data.Range range35 = categoryPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 9.223372036854776E18d + "'", double18 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNull(range35);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        double double15 = numberAxis13.getUpperBound();
        numberAxis13.setLabelURL("");
        boolean boolean18 = numberAxis13.isNegativeArrowVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = numberAxis13.getLabelInsets();
        double double20 = numberAxis13.getAutoRangeMinimumSize();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
        xYPlot25.setDomainAxisLocation((int) '4', axisLocation27);
        boolean boolean29 = xYPlot25.isRangeZoomable();
        xYPlot25.setRangeCrosshairValue((double) 1, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker34 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke35 = categoryMarker34.getOutlineStroke();
        xYPlot25.setRangeGridlineStroke(stroke35);
        numberAxis13.setTickMarkStroke(stroke35);
        org.jfree.chart.axis.TickUnitSource tickUnitSource38 = numberAxis13.getStandardTickUnits();
        double double39 = numberAxis13.getLowerBound();
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.0d + "'", double15 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0E-8d + "'", double20 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(tickUnitSource38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat3 = dateAxis2.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit4 = null;
        dateAxis2.setTickUnit(dateTickUnit4, false, true);
        boolean boolean8 = dateAxis2.isAxisLineVisible();
        java.util.Date date9 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        dateAxis2.setMinimumDate(date9);
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) date9);
        org.junit.Assert.assertNull(dateFormat3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(date9);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        java.awt.Graphics2D graphics2D22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        xYPlot21.drawBackgroundImage(graphics2D22, rectangle2D23);
        java.awt.Stroke stroke25 = xYPlot21.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis27 = xYPlot21.getRangeAxis(10);
        xYPlot21.setDomainCrosshairValue(0.0d, false);
        numberAxis14.setPlot((org.jfree.chart.plot.Plot) xYPlot21);
        java.awt.Shape shape32 = numberAxis14.getUpArrow();
        java.awt.Paint paint33 = numberAxis14.getAxisLinePaint();
        java.awt.Color color34 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        numberAxis14.setTickLabelPaint((java.awt.Paint) color34);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(valueAxis27);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(color34);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot4.getIndexOf(xYItemRenderer10);
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_YELLOW;
        int int13 = color12.getBlue();
        xYPlot4.setOutlinePaint((java.awt.Paint) color12);
        org.jfree.chart.plot.Marker marker16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = categoryPlot21.getDomainAxis((int) (short) 100);
        boolean boolean26 = categoryPlot21.isRangeGridlinesVisible();
        java.awt.Paint paint27 = categoryPlot21.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset29 = categoryPlot21.getDataset(0);
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean31 = categoryPlot21.equals((java.lang.Object) color30);
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset33, valueAxis34, valueAxis35, xYItemRenderer36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        xYPlot37.drawBackgroundImage(graphics2D38, rectangle2D39);
        org.jfree.chart.plot.PlotOrientation plotOrientation41 = xYPlot37.getOrientation();
        org.jfree.data.general.DatasetGroup datasetGroup42 = xYPlot37.getDatasetGroup();
        org.jfree.chart.plot.CategoryMarker categoryMarker44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke45 = categoryMarker44.getOutlineStroke();
        xYPlot37.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker44);
        org.jfree.chart.util.Layer layer47 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean49 = categoryPlot21.removeDomainMarker(500, (org.jfree.chart.plot.Marker) categoryMarker44, layer47, false);
        java.lang.String str50 = layer47.toString();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj52 = numberAxis51.clone();
        org.jfree.data.xy.XYDataset xYDataset53 = null;
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer56 = null;
        org.jfree.chart.plot.XYPlot xYPlot57 = new org.jfree.chart.plot.XYPlot(xYDataset53, valueAxis54, valueAxis55, xYItemRenderer56);
        java.awt.Graphics2D graphics2D58 = null;
        java.awt.geom.Rectangle2D rectangle2D59 = null;
        xYPlot57.drawBackgroundImage(graphics2D58, rectangle2D59);
        numberAxis51.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot57);
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]");
        xYPlot57.setDomainAxis((int) '4', (org.jfree.chart.axis.ValueAxis) numberAxis64);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo67 = null;
        org.jfree.data.xy.XYDataset xYDataset68 = null;
        org.jfree.chart.axis.ValueAxis valueAxis69 = null;
        org.jfree.chart.axis.ValueAxis valueAxis70 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer71 = null;
        org.jfree.chart.plot.XYPlot xYPlot72 = new org.jfree.chart.plot.XYPlot(xYDataset68, valueAxis69, valueAxis70, xYItemRenderer71);
        org.jfree.chart.axis.AxisLocation axisLocation74 = null;
        xYPlot72.setDomainAxisLocation((int) '4', axisLocation74);
        boolean boolean77 = xYPlot72.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent78 = null;
        xYPlot72.markerChanged(markerChangeEvent78);
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double82 = rectangleInsets80.calculateRightInset((double) '4');
        double double84 = rectangleInsets80.extendHeight((double) 1.0f);
        xYPlot72.setAxisOffset(rectangleInsets80);
        java.awt.geom.Point2D point2D86 = xYPlot72.getQuadrantOrigin();
        xYPlot57.zoomDomainAxes(492.0d, plotRenderingInfo67, point2D86, false);
        boolean boolean89 = layer47.equals((java.lang.Object) 492.0d);
        boolean boolean91 = xYPlot4.removeDomainMarker((-8355840), marker16, layer47, false);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNull(categoryAxis25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNull(categoryDataset29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(plotOrientation41);
        org.junit.Assert.assertNull(datasetGroup42);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNotNull(layer47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Layer.FOREGROUND" + "'", str50.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(rectangleInsets80);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 4.0d + "'", double82 == 4.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 5.0d + "'", double84 == 5.0d);
        org.junit.Assert.assertNotNull(point2D86);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace11, false);
        java.awt.Stroke stroke14 = categoryPlot4.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot4.getRangeAxis(100);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace17);
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, valueAxis22, xYItemRenderer23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        xYPlot24.setDomainAxisLocation((int) '4', axisLocation26);
        boolean boolean29 = xYPlot24.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent30 = null;
        xYPlot24.markerChanged(markerChangeEvent30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double34 = rectangleInsets32.calculateRightInset((double) '4');
        double double36 = rectangleInsets32.extendHeight((double) 1.0f);
        xYPlot24.setAxisOffset(rectangleInsets32);
        xYPlot24.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker41 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot24.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker41);
        org.jfree.chart.JFreeChart jFreeChart43 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent44 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) categoryMarker41, jFreeChart43);
        java.awt.Paint paint45 = categoryMarker41.getLabelPaint();
        org.jfree.data.category.CategoryDataset categoryDataset46 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot(categoryDataset46, categoryAxis47, valueAxis48, categoryItemRenderer49);
        categoryPlot50.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis54 = categoryPlot50.getDomainAxis((int) (short) 100);
        boolean boolean55 = categoryPlot50.isRangeGridlinesVisible();
        java.awt.Paint paint56 = categoryPlot50.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset58 = categoryPlot50.getDataset(0);
        org.jfree.data.xy.XYDataset xYDataset59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.axis.ValueAxis valueAxis61 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer62 = null;
        org.jfree.chart.plot.XYPlot xYPlot63 = new org.jfree.chart.plot.XYPlot(xYDataset59, valueAxis60, valueAxis61, xYItemRenderer62);
        java.awt.Graphics2D graphics2D64 = null;
        java.awt.geom.Rectangle2D rectangle2D65 = null;
        xYPlot63.drawBackgroundImage(graphics2D64, rectangle2D65);
        org.jfree.data.xy.XYDataset xYDataset67 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = xYPlot63.getRendererForDataset(xYDataset67);
        xYPlot63.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis72 = new org.jfree.chart.axis.NumberAxis();
        int int73 = xYPlot63.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis72);
        numberAxis72.setAutoRangeStickyZero(false);
        java.awt.Font font76 = numberAxis72.getTickLabelFont();
        categoryPlot50.setNoDataMessageFont(font76);
        categoryMarker41.setLabelFont(font76);
        org.jfree.chart.util.Layer layer79 = null;
        try {
            categoryPlot4.addDomainMarker((int) (byte) -1, categoryMarker41, layer79, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'layer' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(valueAxis16);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 4.0d + "'", double34 == 4.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 5.0d + "'", double36 == 5.0d);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertNull(categoryAxis54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNull(categoryDataset58);
        org.junit.Assert.assertNull(xYItemRenderer68);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-1) + "'", int73 == (-1));
        org.junit.Assert.assertNotNull(font76);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainGridlinePaint();
        java.awt.Color color10 = java.awt.Color.WHITE;
        xYPlot4.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]");
        xYPlot4.setRangeAxis(500, (org.jfree.chart.axis.ValueAxis) dateAxis14);
        int int16 = xYPlot4.getDatasetCount();
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        try {
            xYPlot4.setDomainAxisLocation(0, axisLocation18, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        java.lang.String str12 = categoryMarker8.getLabel();
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        java.lang.String str4 = rectangleAnchor3.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, 1.0d, (double) 13, rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleAnchor.RIGHT" + "'", str4.equals("RectangleAnchor.RIGHT"));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        xYPlot6.drawBackgroundImage(graphics2D7, rectangle2D8);
        numberAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot6);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = xYPlot6.getDatasetRenderingOrder();
        java.lang.String str12 = datasetRenderingOrder11.toString();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DatasetRenderingOrder.REVERSE" + "'", str12.equals("DatasetRenderingOrder.REVERSE"));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        int int2 = day1.getMonth();
        int int3 = day1.getMonth();
        java.util.Calendar calendar4 = null;
        try {
            long long5 = day1.getFirstMillisecond(calendar4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 6 + "'", int3 == 6);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        java.awt.Paint paint1 = null;
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot(categoryDataset2, categoryAxis3, valueAxis4, categoryItemRenderer5);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot6.zoomRangeAxes(0.0d, plotRenderingInfo8, point2D9, false);
        java.awt.Stroke stroke12 = categoryPlot6.getRangeCrosshairStroke();
        java.awt.Color color13 = java.awt.Color.gray;
        java.awt.Color color14 = color13.darker();
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset15, valueAxis16, valueAxis17, xYItemRenderer18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        xYPlot19.drawBackgroundImage(graphics2D20, rectangle2D21);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = xYPlot19.getRendererForDataset(xYDataset23);
        xYPlot19.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor31 = null;
        java.awt.geom.Point2D point2D32 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D30, rectangleAnchor31);
        xYPlot19.zoomRangeAxes(4.0d, plotRenderingInfo29, point2D32);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = xYPlot19.getDomainAxisEdge();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint38 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker37.setLabelPaint(paint38);
        java.lang.Comparable comparable40 = categoryMarker37.getKey();
        org.jfree.chart.util.Layer layer41 = null;
        categoryPlot35.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker37, layer41);
        java.awt.Paint paint43 = categoryMarker37.getLabelPaint();
        java.awt.Stroke stroke44 = categoryMarker37.getOutlineStroke();
        xYPlot19.setRangeCrosshairStroke(stroke44);
        try {
            org.jfree.chart.plot.CategoryMarker categoryMarker47 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) 1560409200000L, paint1, stroke12, (java.awt.Paint) color13, stroke44, (float) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNull(xYItemRenderer24);
        org.junit.Assert.assertNotNull(point2D32);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertTrue("'" + comparable40 + "' != '" + (byte) 0 + "'", comparable40.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint43);
        org.junit.Assert.assertNotNull(stroke44);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor16 = null;
        java.awt.geom.Point2D point2D17 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D15, rectangleAnchor16);
        xYPlot4.zoomRangeAxes(4.0d, plotRenderingInfo14, point2D17);
        boolean boolean19 = xYPlot4.isRangeZeroBaselineVisible();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer[] xYItemRendererArray21 = new org.jfree.chart.renderer.xy.XYItemRenderer[] { xYItemRenderer20 };
        xYPlot4.setRenderers(xYItemRendererArray21);
        xYPlot4.setRangeCrosshairValue((double) ' ', true);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(point2D17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(xYItemRendererArray21);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.util.SortOrder sortOrder1 = categoryPlot0.getRowRenderingOrder();
        org.jfree.chart.axis.DateAxis dateAxis2 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat3 = dateAxis2.getDateFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        xYPlot8.setDomainAxisLocation((int) '4', axisLocation10);
        boolean boolean13 = xYPlot8.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent14 = null;
        xYPlot8.markerChanged(markerChangeEvent14);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double18 = rectangleInsets16.calculateRightInset((double) '4');
        double double20 = rectangleInsets16.extendHeight((double) 1.0f);
        xYPlot8.setAxisOffset(rectangleInsets16);
        xYPlot8.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot8.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker25);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer31 = null;
        org.jfree.chart.plot.XYPlot xYPlot32 = new org.jfree.chart.plot.XYPlot(xYDataset28, valueAxis29, valueAxis30, xYItemRenderer31);
        java.awt.Graphics2D graphics2D33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        xYPlot32.drawBackgroundImage(graphics2D33, rectangle2D34);
        org.jfree.data.xy.XYDataset xYDataset36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = xYPlot32.getRendererForDataset(xYDataset36);
        xYPlot32.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis();
        int int42 = xYPlot32.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis41);
        double double43 = numberAxis41.getUpperBound();
        numberAxis41.setFixedAutoRange((double) 100);
        xYPlot8.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis41);
        numberAxis41.setUpperBound((-1.0d));
        java.awt.Stroke stroke49 = numberAxis41.getTickMarkStroke();
        dateAxis2.setAxisLineStroke(stroke49);
        dateAxis2.configure();
        dateAxis2.configure();
        org.jfree.data.Range range53 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis2);
        org.jfree.chart.axis.DateTickUnit dateTickUnit54 = org.jfree.chart.axis.DateAxis.DEFAULT_DATE_TICK_UNIT;
        dateAxis2.setTickUnit(dateTickUnit54);
        org.junit.Assert.assertNotNull(sortOrder1);
        org.junit.Assert.assertNull(dateFormat3);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 4.0d + "'", double18 == 4.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 5.0d + "'", double20 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer37);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1) + "'", int42 == (-1));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.0d + "'", double43 == 1.0d);
        org.junit.Assert.assertNotNull(stroke49);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(dateTickUnit54);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot5.zoomRangeAxes(0.0d, plotRenderingInfo7, point2D8, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot5.setDomainAxis((int) 'a', categoryAxis12, false);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        int int16 = categoryPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis15);
        numberAxis15.setRangeAboutValue((double) (byte) 0, 0.0d);
        double double20 = numberAxis15.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        xYPlot25.drawBackgroundImage(graphics2D26, rectangle2D27);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = xYPlot25.getRendererForDataset(xYDataset29);
        xYPlot25.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        int int35 = xYPlot25.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis34);
        double double36 = numberAxis34.getUpperBound();
        numberAxis34.setLabelURL("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis34, xYItemRenderer39);
        xYPlot40.configureRangeAxes();
        java.awt.Color color42 = java.awt.Color.WHITE;
        xYPlot40.setRangeGridlinePaint((java.awt.Paint) color42);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertNotNull(color42);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("Layer.FOREGROUND");
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 10.0d, "");
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets((double) (byte) -1, (double) 0.5f, (double) 0L, (double) (short) -1);
        double double11 = rectangleInsets9.calculateBottomInset((double) (byte) 100);
        categoryAxis1.setLabelInsets(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot4.getDomainAxis((int) (short) 100);
        boolean boolean9 = categoryPlot4.isRangeGridlinesVisible();
        java.awt.Paint paint10 = categoryPlot4.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot4.getDataset(0);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        xYPlot18.drawBackgroundImage(graphics2D19, rectangle2D20);
        org.jfree.data.xy.XYDataset xYDataset22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = xYPlot18.getRendererForDataset(xYDataset22);
        xYPlot18.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        int int28 = xYPlot18.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis27);
        double double29 = numberAxis27.getUpperBound();
        numberAxis27.resizeRange((double) '#');
        numberAxis27.setUpperMargin(0.05d);
        categoryPlot4.setRangeAxis(15, (org.jfree.chart.axis.ValueAxis) numberAxis27, true);
        java.awt.Graphics2D graphics2D36 = null;
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        try {
            categoryPlot4.drawBackground(graphics2D36, rectangle2D37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertNull(xYItemRenderer23);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 1.0d + "'", double29 == 1.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        xYPlot4.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup6 = xYPlot4.getDatasetGroup();
        xYPlot4.configureRangeAxes();
        org.jfree.chart.axis.AxisLocation axisLocation9 = xYPlot4.getRangeAxisLocation((-1));
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot4.getRenderer();
        org.junit.Assert.assertNull(datasetGroup6);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNull(xYItemRenderer10);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = xYPlot4.getDomainAxisEdge();
        boolean boolean16 = xYPlot4.isRangeGridlinesVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = xYPlot4.getDomainAxisEdge(0);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(rectangleEdge18);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        numberAxis14.centerRange((double) 0L);
        org.jfree.chart.plot.Plot plot18 = numberAxis14.getPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        numberAxis14.setTickMarkPaint((java.awt.Paint) color19);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        java.awt.color.ColorSpace colorSpace22 = color21.getColorSpace();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color24 = java.awt.Color.LIGHT_GRAY;
        java.awt.color.ColorSpace colorSpace25 = color24.getColorSpace();
        java.awt.Color color26 = java.awt.Color.BLACK;
        int int27 = color26.getGreen();
        java.awt.Color color28 = java.awt.Color.LIGHT_GRAY;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        java.awt.Color color30 = java.awt.Color.LIGHT_GRAY;
        java.awt.color.ColorSpace colorSpace31 = color30.getColorSpace();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray39 = new float[] { 'a', (short) -1, ' ', 10.0f, 0, 0 };
        float[] floatArray40 = color32.getRGBColorComponents(floatArray39);
        float[] floatArray41 = color30.getRGBColorComponents(floatArray40);
        float[] floatArray42 = color26.getColorComponents(colorSpace29, floatArray40);
        float[] floatArray43 = color23.getColorComponents(colorSpace25, floatArray42);
        float[] floatArray44 = color19.getColorComponents(colorSpace22, floatArray42);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNull(plot18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(colorSpace22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(colorSpace31);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(floatArray39);
        org.junit.Assert.assertNotNull(floatArray40);
        org.junit.Assert.assertNotNull(floatArray41);
        org.junit.Assert.assertNotNull(floatArray42);
        org.junit.Assert.assertNotNull(floatArray43);
        org.junit.Assert.assertNotNull(floatArray44);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot4.getIndexOf(xYItemRenderer10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot17.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot17.setDomainAxis((int) 'a', categoryAxis24, false);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        int int28 = categoryPlot17.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis27);
        numberAxis27.setRangeAboutValue((double) (byte) 0, 0.0d);
        double double32 = numberAxis27.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset33, valueAxis34, valueAxis35, xYItemRenderer36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        xYPlot37.drawBackgroundImage(graphics2D38, rectangle2D39);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = xYPlot37.getRendererForDataset(xYDataset41);
        xYPlot37.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis();
        int int47 = xYPlot37.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis46);
        double double48 = numberAxis46.getUpperBound();
        numberAxis46.setLabelURL("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis46, xYItemRenderer51);
        java.awt.Stroke stroke53 = xYPlot52.getDomainZeroBaselineStroke();
        xYPlot4.setParent((org.jfree.chart.plot.Plot) xYPlot52);
        xYPlot4.setRangeCrosshairVisible(false);
        boolean boolean57 = xYPlot4.isRangeZoomable();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot4.setDomainAxis((int) (byte) 0, categoryAxis17);
        java.awt.Image image19 = categoryPlot4.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot4.getFixedRangeAxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot4.getDomainAxisEdge();
        java.awt.Paint paint22 = categoryPlot4.getDomainGridlinePaint();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis3.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis3.configure();
        double double8 = categoryAxis3.getCategoryMargin();
        int int9 = categoryAxis3.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.DateAxis dateAxis10 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat11 = dateAxis10.getDateFormatOverride();
        org.jfree.chart.axis.DateTickUnit dateTickUnit12 = null;
        dateAxis10.setTickUnit(dateTickUnit12, false, true);
        dateAxis10.setRange((double) (byte) 1, (double) 10);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis3, (org.jfree.chart.axis.ValueAxis) dateAxis10, categoryItemRenderer19);
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis();
        double double22 = numberAxis21.getUpperBound();
        java.awt.Color color23 = java.awt.Color.WHITE;
        numberAxis21.setTickMarkPaint((java.awt.Paint) color23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis3, (org.jfree.chart.axis.ValueAxis) numberAxis21, categoryItemRenderer25);
        java.lang.String str28 = categoryAxis3.getCategoryLabelToolTip((java.lang.Comparable) 0.0f);
        int int29 = categoryAxis3.getMaximumCategoryLabelLines();
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.2d + "'", double8 == 0.2d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertNull(dateFormat11);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNull(str28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 1 + "'", int29 == 1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace11, false);
        java.awt.Stroke stroke14 = categoryPlot4.getRangeCrosshairStroke();
        float float15 = categoryPlot4.getBackgroundImageAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke25 = categoryMarker24.getOutlineStroke();
        org.jfree.chart.util.Layer layer26 = null;
        boolean boolean27 = categoryPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker24, layer26);
        java.lang.Comparable comparable28 = categoryMarker24.getKey();
        java.awt.Paint paint29 = categoryMarker24.getPaint();
        boolean boolean30 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker24);
        org.jfree.data.category.CategoryDataset categoryDataset31 = null;
        categoryPlot4.setDataset(categoryDataset31);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (byte) 0 + "'", comparable28.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot9.zoomRangeAxes(0.0d, plotRenderingInfo11, point2D12, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        categoryPlot9.setDomainAxis((int) 'a', categoryAxis16, false);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis();
        int int20 = categoryPlot9.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis19);
        numberAxis19.setRangeAboutValue((double) (byte) 0, 0.0d);
        double double24 = numberAxis19.getFixedAutoRange();
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = null;
        double double28 = numberAxis19.java2DToValue((double) 15, rectangle2D26, rectangleEdge27);
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = null;
        double double32 = numberAxis19.lengthToJava2D((double) 12, rectangle2D30, rectangleEdge31);
        int int33 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertEquals((double) double28, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        xYPlot4.setRangeCrosshairLockedOnData(false);
        double double12 = xYPlot4.getRangeCrosshairValue();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke14 = defaultDrawingSupplier13.getNextOutlineStroke();
        java.lang.Object obj15 = defaultDrawingSupplier13.clone();
        java.awt.Paint paint16 = defaultDrawingSupplier13.getNextOutlinePaint();
        java.awt.Shape shape17 = defaultDrawingSupplier13.getNextShape();
        xYPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier13);
        java.awt.Paint paint19 = defaultDrawingSupplier13.getNextOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis1.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis1.configure();
        org.jfree.data.xy.XYDataset xYDataset6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = null;
        org.jfree.chart.plot.XYPlot xYPlot10 = new org.jfree.chart.plot.XYPlot(xYDataset6, valueAxis7, valueAxis8, xYItemRenderer9);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot10.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.LegendItemCollection legendItemCollection13 = xYPlot10.getLegendItems();
        boolean boolean14 = categoryAxis1.equals((java.lang.Object) legendItemCollection13);
        categoryAxis1.setCategoryLabelPositionOffset(0);
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot(categoryDataset17, categoryAxis18, valueAxis19, categoryItemRenderer20);
        categoryPlot21.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke26 = categoryMarker25.getOutlineStroke();
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean28 = categoryPlot21.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker25, layer27);
        boolean boolean29 = categoryPlot21.isDomainZoomable();
        categoryPlot21.clearDomainAxes();
        categoryAxis1.setPlot((org.jfree.chart.plot.Plot) categoryPlot21);
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot21.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis35.setCategoryMargin((double) '4');
        float float38 = categoryAxis35.getMaximumCategoryLabelWidthRatio();
        java.lang.String str40 = categoryAxis35.getCategoryLabelToolTip((java.lang.Comparable) "");
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer44 = null;
        org.jfree.chart.plot.XYPlot xYPlot45 = new org.jfree.chart.plot.XYPlot(xYDataset41, valueAxis42, valueAxis43, xYItemRenderer44);
        java.awt.Graphics2D graphics2D46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        xYPlot45.drawBackgroundImage(graphics2D46, rectangle2D47);
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer50 = xYPlot45.getRendererForDataset(xYDataset49);
        org.jfree.chart.plot.Plot plot51 = xYPlot45.getRootPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets56 = new org.jfree.chart.util.RectangleInsets((double) (byte) -1, (double) 0.5f, (double) 0L, (double) (short) -1);
        double double58 = rectangleInsets56.calculateLeftInset(0.0d);
        double double60 = rectangleInsets56.calculateRightOutset(101.0d);
        xYPlot45.setAxisOffset(rectangleInsets56);
        categoryAxis35.setLabelInsets(rectangleInsets56);
        categoryAxis35.setUpperMargin((double) 11);
        categoryPlot21.setDomainAxis(128, categoryAxis35, false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertNotNull(legendItemCollection13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + float38 + "' != '" + 0.0f + "'", float38 == 0.0f);
        org.junit.Assert.assertNull(str40);
        org.junit.Assert.assertNull(xYItemRenderer50);
        org.junit.Assert.assertNotNull(plot51);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.5d + "'", double58 == 0.5d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + (-1.0d) + "'", double60 == (-1.0d));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainCrosshairPaint();
        java.awt.Stroke stroke10 = xYPlot4.getOutlineStroke();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 1, 0);
        xYPlot4.setWeight((int) (short) 100);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        xYPlot4.zoomDomainAxes((double) (short) 100, plotRenderingInfo16, point2D17, false);
        xYPlot4.clearRangeMarkers(15);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        double double23 = numberAxis22.getUpperBound();
        java.awt.Color color24 = java.awt.Color.WHITE;
        numberAxis22.setTickMarkPaint((java.awt.Paint) color24);
        xYPlot4.setRangeGridlinePaint((java.awt.Paint) color24);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(color24);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        categoryPlot4.setRangeCrosshairValue((double) 100.0f);
        categoryPlot4.setAnchorValue((double) (byte) 1);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot4.addChangeListener(plotChangeListener21);
        categoryPlot4.clearDomainMarkers((int) (short) 10);
        boolean boolean25 = categoryPlot4.isSubplot();
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = null;
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer31 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot(categoryDataset28, categoryAxis29, valueAxis30, categoryItemRenderer31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot32.zoomRangeAxes(0.0d, plotRenderingInfo34, point2D35, false);
        org.jfree.chart.axis.AxisSpace axisSpace38 = categoryPlot32.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        categoryPlot32.setFixedRangeAxisSpace(axisSpace39, false);
        java.awt.Stroke stroke42 = categoryPlot32.getRangeCrosshairStroke();
        org.jfree.data.category.CategoryDataset categoryDataset44 = categoryPlot32.getDataset((int) (byte) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = null;
        org.jfree.data.xy.XYDataset xYDataset47 = null;
        org.jfree.data.category.CategoryDataset categoryDataset48 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot(categoryDataset48, categoryAxis49, valueAxis50, categoryItemRenderer51);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = null;
        java.awt.geom.Point2D point2D55 = null;
        categoryPlot52.zoomRangeAxes(0.0d, plotRenderingInfo54, point2D55, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = null;
        categoryPlot52.setDomainAxis((int) 'a', categoryAxis59, false);
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis();
        int int63 = categoryPlot52.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis62);
        numberAxis62.setRangeAboutValue((double) (byte) 0, 0.0d);
        double double67 = numberAxis62.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset68 = null;
        org.jfree.chart.axis.ValueAxis valueAxis69 = null;
        org.jfree.chart.axis.ValueAxis valueAxis70 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer71 = null;
        org.jfree.chart.plot.XYPlot xYPlot72 = new org.jfree.chart.plot.XYPlot(xYDataset68, valueAxis69, valueAxis70, xYItemRenderer71);
        java.awt.Graphics2D graphics2D73 = null;
        java.awt.geom.Rectangle2D rectangle2D74 = null;
        xYPlot72.drawBackgroundImage(graphics2D73, rectangle2D74);
        org.jfree.data.xy.XYDataset xYDataset76 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer77 = xYPlot72.getRendererForDataset(xYDataset76);
        xYPlot72.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis81 = new org.jfree.chart.axis.NumberAxis();
        int int82 = xYPlot72.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis81);
        double double83 = numberAxis81.getUpperBound();
        numberAxis81.setLabelURL("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer86 = null;
        org.jfree.chart.plot.XYPlot xYPlot87 = new org.jfree.chart.plot.XYPlot(xYDataset47, (org.jfree.chart.axis.ValueAxis) numberAxis62, (org.jfree.chart.axis.ValueAxis) numberAxis81, xYItemRenderer86);
        xYPlot87.setDomainCrosshairVisible(false);
        java.awt.geom.Rectangle2D rectangle2D90 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor91 = null;
        java.awt.geom.Point2D point2D92 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D90, rectangleAnchor91);
        xYPlot87.setQuadrantOrigin(point2D92);
        categoryPlot32.zoomDomainAxes((double) (short) 1, plotRenderingInfo46, point2D92, false);
        org.jfree.chart.plot.PlotState plotState96 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo97 = null;
        try {
            categoryPlot4.draw(graphics2D26, rectangle2D27, point2D92, plotState96, plotRenderingInfo97);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(axisSpace38);
        org.junit.Assert.assertNotNull(stroke42);
        org.junit.Assert.assertNull(categoryDataset44);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer77);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1) + "'", int82 == (-1));
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 1.0d + "'", double83 == 1.0d);
        org.junit.Assert.assertNotNull(point2D92);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis2.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis2.configure();
        double double7 = categoryAxis2.getCategoryMargin();
        int int8 = categoryAxis2.getMaximumCategoryLabelLines();
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis2, valueAxis9, categoryItemRenderer10);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.2d + "'", double7 == 0.2d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        categoryPlot4.setRangeCrosshairValue((double) 100.0f);
        categoryPlot4.setRangeCrosshairValue((double) 0L);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker8 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke9 = categoryMarker8.getOutlineStroke();
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker8, layer10);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis14.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis14.configure();
        categoryPlot4.setDomainAxis(2, categoryAxis14, false);
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = categoryAxis14.getCategoryStart(13, (int) (byte) 10, rectangle2D23, rectangleEdge24);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.awt.Color color0 = java.awt.Color.CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        int int15 = categoryPlot4.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset16 = categoryPlot4.getDataset();
        org.jfree.data.xy.XYDataset xYDataset17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer20 = null;
        org.jfree.chart.plot.XYPlot xYPlot21 = new org.jfree.chart.plot.XYPlot(xYDataset17, valueAxis18, valueAxis19, xYItemRenderer20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = null;
        xYPlot21.setDomainAxisLocation((int) '4', axisLocation23);
        boolean boolean26 = xYPlot21.equals((java.lang.Object) 1.0f);
        org.jfree.data.category.CategoryDataset categoryDataset27 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer30 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot(categoryDataset27, categoryAxis28, valueAxis29, categoryItemRenderer30);
        categoryPlot31.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker35 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke36 = categoryMarker35.getOutlineStroke();
        org.jfree.chart.util.Layer layer37 = null;
        boolean boolean38 = categoryPlot31.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker35, layer37);
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot31.getDomainAxisLocation((int) '#');
        xYPlot21.setDomainAxisLocation(axisLocation40, false);
        categoryPlot4.setRangeAxisLocation(axisLocation40, true);
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = categoryPlot4.getAxisOffset();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer46 = categoryPlot4.getRenderer();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 15 + "'", int15 == 15);
        org.junit.Assert.assertNull(categoryDataset16);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertNull(categoryItemRenderer46);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.java2DToValue((double) 10.0f, rectangle2D2, rectangleEdge3);
        java.text.DateFormat dateFormat5 = null;
        dateAxis0.setDateFormatOverride(dateFormat5);
        java.awt.Stroke stroke7 = dateAxis0.getAxisLineStroke();
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer11 = null;
        org.jfree.chart.plot.XYPlot xYPlot12 = new org.jfree.chart.plot.XYPlot(xYDataset8, valueAxis9, valueAxis10, xYItemRenderer11);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        xYPlot12.drawBackgroundImage(graphics2D13, rectangle2D14);
        java.awt.Stroke stroke16 = xYPlot12.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis18 = xYPlot12.getRangeAxis(10);
        xYPlot12.setDomainCrosshairValue(0.0d, false);
        java.awt.Font font22 = xYPlot12.getNoDataMessageFont();
        dateAxis0.setTickLabelFont(font22);
        boolean boolean24 = dateAxis0.isVisible();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.223372036854776E18d + "'", double4 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

//    @Test
//    public void test127() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test127");
//        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
//        int int1 = categoryAxis0.getMaximumCategoryLabelLines();
//        java.util.Date date2 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
//        org.jfree.data.time.Day day3 = new org.jfree.data.time.Day(date2);
//        org.jfree.data.time.SerialDate serialDate4 = day3.getSerialDate();
//        long long5 = day3.getLastMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod6 = day3.next();
//        java.lang.String str7 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) regularTimePeriod6);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
//        org.junit.Assert.assertNotNull(date2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1560495599999L + "'", long5 == 1560495599999L);
//        org.junit.Assert.assertNotNull(regularTimePeriod6);
//        org.junit.Assert.assertNull(str7);
//    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace11, false);
        org.jfree.chart.LegendItemCollection legendItemCollection14 = categoryPlot4.getLegendItems();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray15 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot4.setRenderers(categoryItemRendererArray15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        org.jfree.data.xy.XYDataset xYDataset20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer23 = null;
        org.jfree.chart.plot.XYPlot xYPlot24 = new org.jfree.chart.plot.XYPlot(xYDataset20, valueAxis21, valueAxis22, xYItemRenderer23);
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        xYPlot24.drawBackgroundImage(graphics2D25, rectangle2D26);
        org.jfree.data.xy.XYDataset xYDataset28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = xYPlot24.getRendererForDataset(xYDataset28);
        xYPlot24.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot(categoryDataset33, categoryAxis34, valueAxis35, categoryItemRenderer36);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        categoryPlot37.zoomRangeAxes(0.0d, plotRenderingInfo39, point2D40, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = null;
        categoryPlot37.setDomainAxis((int) 'a', categoryAxis44, false);
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis();
        int int48 = categoryPlot37.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis47);
        double double49 = numberAxis47.getFixedAutoRange();
        numberAxis47.setAutoRangeMinimumSize((double) (short) 100);
        numberAxis47.setRange((double) (-1), Double.NaN);
        xYPlot24.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis47);
        java.awt.geom.Point2D point2D56 = xYPlot24.getQuadrantOrigin();
        categoryPlot4.zoomRangeAxes(9.223372036854776E18d, (double) 2019, plotRenderingInfo19, point2D56);
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(legendItemCollection14);
        org.junit.Assert.assertNotNull(categoryItemRendererArray15);
        org.junit.Assert.assertNull(xYItemRenderer29);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1) + "'", int48 == (-1));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(point2D56);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        int int10 = xYPlot4.getSeriesCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double13 = rectangleInsets11.calculateRightInset((double) '4');
        double double14 = rectangleInsets11.getBottom();
        double double16 = rectangleInsets11.calculateBottomInset(0.5d);
        xYPlot4.setInsets(rectangleInsets11);
        xYPlot4.setDomainCrosshairLockedOnData(false);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace20, false);
        int int23 = xYPlot4.getSeriesCount();
        org.jfree.chart.event.PlotChangeListener plotChangeListener24 = null;
        xYPlot4.addChangeListener(plotChangeListener24);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.0d + "'", double13 == 4.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.0d + "'", double14 == 2.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 2.0d + "'", double16 == 2.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainCrosshairPaint();
        int int10 = xYPlot4.getRangeAxisCount();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        xYPlot4.drawAnnotations(graphics2D11, rectangle2D12, plotRenderingInfo13);
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer15 = xYPlot4.getRenderer();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNull(xYItemRenderer15);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot4.getRangeAxisEdge();
        org.jfree.data.general.DatasetGroup datasetGroup17 = categoryPlot4.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot4.getDomainAxisForDataset((int) (byte) 10);
        categoryPlot4.mapDatasetToDomainAxis(0, 5);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot4.getRenderer();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertNull(categoryItemRenderer23);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) 8);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace11, false);
        org.jfree.data.xy.XYDataset xYDataset14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer17 = null;
        org.jfree.chart.plot.XYPlot xYPlot18 = new org.jfree.chart.plot.XYPlot(xYDataset14, valueAxis15, valueAxis16, xYItemRenderer17);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        xYPlot18.drawBackgroundImage(graphics2D19, rectangle2D20);
        java.awt.Stroke stroke22 = xYPlot18.getDomainZeroBaselineStroke();
        org.jfree.chart.axis.AxisLocation axisLocation24 = xYPlot18.getDomainAxisLocation(9);
        categoryPlot4.setDomainAxisLocation(axisLocation24);
        org.jfree.chart.axis.AxisLocation axisLocation26 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot4.setRangeAxisLocation(axisLocation26, false);
        org.jfree.chart.plot.Marker marker30 = null;
        org.jfree.data.xy.XYDataset xYDataset31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer34 = null;
        org.jfree.chart.plot.XYPlot xYPlot35 = new org.jfree.chart.plot.XYPlot(xYDataset31, valueAxis32, valueAxis33, xYItemRenderer34);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot35.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        xYPlot35.setFixedRangeAxisSpace(axisSpace38);
        java.awt.Paint paint40 = xYPlot35.getDomainGridlinePaint();
        java.awt.Stroke stroke41 = xYPlot35.getRangeCrosshairStroke();
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot(categoryDataset42, categoryAxis43, valueAxis44, categoryItemRenderer45);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        categoryPlot46.zoomRangeAxes(0.0d, plotRenderingInfo48, point2D49, false);
        org.jfree.chart.plot.Marker marker53 = null;
        org.jfree.chart.util.Layer layer54 = null;
        boolean boolean56 = categoryPlot46.removeDomainMarker((int) (byte) 0, marker53, layer54, false);
        int int57 = categoryPlot46.getBackgroundImageAlignment();
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = null;
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer61 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot(categoryDataset58, categoryAxis59, valueAxis60, categoryItemRenderer61);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo64 = null;
        java.awt.geom.Point2D point2D65 = null;
        categoryPlot62.zoomRangeAxes(0.0d, plotRenderingInfo64, point2D65, false);
        org.jfree.chart.plot.Marker marker69 = null;
        org.jfree.chart.util.Layer layer70 = null;
        boolean boolean72 = categoryPlot62.removeDomainMarker((int) (byte) 0, marker69, layer70, false);
        categoryPlot62.setBackgroundAlpha((float) 0);
        org.jfree.chart.axis.ValueAxis valueAxis76 = categoryPlot62.getRangeAxis(0);
        categoryPlot62.configureRangeAxes();
        org.jfree.chart.util.Layer layer78 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection79 = categoryPlot62.getDomainMarkers(layer78);
        java.util.Collection collection80 = categoryPlot46.getDomainMarkers(layer78);
        java.util.Collection collection81 = xYPlot35.getDomainMarkers(layer78);
        try {
            categoryPlot4.addRangeMarker(8, marker30, layer78, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(axisLocation24);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 15 + "'", int57 == 15);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNull(valueAxis76);
        org.junit.Assert.assertNotNull(layer78);
        org.junit.Assert.assertNull(collection79);
        org.junit.Assert.assertNull(collection80);
        org.junit.Assert.assertNull(collection81);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        categoryPlot4.setRangeCrosshairValue((double) 100.0f);
        categoryPlot4.setAnchorValue((double) (byte) 1);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor21 = org.jfree.chart.axis.CategoryAnchor.END;
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot26.zoomRangeAxes(0.0d, plotRenderingInfo28, point2D29, false);
        org.jfree.chart.plot.Marker marker33 = null;
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean36 = categoryPlot26.removeDomainMarker((int) (byte) 0, marker33, layer34, false);
        categoryPlot26.clearAnnotations();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor41 = null;
        java.awt.geom.Point2D point2D42 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D40, rectangleAnchor41);
        categoryPlot26.zoomDomainAxes((double) 0L, plotRenderingInfo39, point2D42, false);
        boolean boolean45 = categoryAnchor21.equals((java.lang.Object) point2D42);
        categoryPlot4.setDomainGridlinePosition(categoryAnchor21);
        org.jfree.chart.axis.ValueAxis valueAxis48 = categoryPlot4.getRangeAxisForDataset(100);
        try {
            categoryPlot4.mapDatasetToRangeAxis((-83), (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(categoryAnchor21);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(point2D42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(valueAxis48);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        java.util.Date date0 = org.jfree.chart.axis.DateAxis.DEFAULT_ANCHOR_DATE;
        org.jfree.data.time.Day day1 = new org.jfree.data.time.Day(date0);
        org.jfree.data.time.SerialDate serialDate2 = day1.getSerialDate();
        org.jfree.data.time.SerialDate serialDate3 = day1.getSerialDate();
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate3);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day(serialDate3);
        org.junit.Assert.assertNotNull(date0);
        org.junit.Assert.assertNotNull(serialDate2);
        org.junit.Assert.assertNotNull(serialDate3);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.jfree.chart.plot.IntervalMarker intervalMarker2 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        java.lang.Object obj3 = intervalMarker2.clone();
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) (short) 10, (float) 255, 2.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis1.setCategoryMargin((double) '4');
        float float4 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot(categoryDataset5, categoryAxis6, valueAxis7, categoryItemRenderer8);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot9.zoomRangeAxes(0.0d, plotRenderingInfo11, point2D12, false);
        categoryAxis1.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot9);
        categoryPlot9.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.0f + "'", float4 == 0.0f);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = categoryPlot4.getRenderer(10);
        org.jfree.chart.LegendItemCollection legendItemCollection7 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot4.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        categoryPlot14.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = categoryPlot14.getDomainAxis((int) (short) 100);
        boolean boolean19 = categoryPlot14.isRangeGridlinesVisible();
        java.awt.Paint paint20 = categoryPlot14.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot14.getDataset(0);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        boolean boolean24 = categoryPlot14.equals((java.lang.Object) color23);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYPlot30.drawBackgroundImage(graphics2D31, rectangle2D32);
        org.jfree.chart.plot.PlotOrientation plotOrientation34 = xYPlot30.getOrientation();
        org.jfree.data.general.DatasetGroup datasetGroup35 = xYPlot30.getDatasetGroup();
        org.jfree.chart.plot.CategoryMarker categoryMarker37 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke38 = categoryMarker37.getOutlineStroke();
        xYPlot30.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker37);
        org.jfree.chart.util.Layer layer40 = org.jfree.chart.util.Layer.FOREGROUND;
        boolean boolean42 = categoryPlot14.removeDomainMarker(500, (org.jfree.chart.plot.Marker) categoryMarker37, layer40, false);
        java.lang.String str43 = layer40.toString();
        java.util.Collection collection44 = categoryPlot4.getDomainMarkers(100, layer40);
        org.junit.Assert.assertNull(categoryItemRenderer6);
        org.junit.Assert.assertNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNull(categoryAxis18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(categoryDataset22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(plotOrientation34);
        org.junit.Assert.assertNull(datasetGroup35);
        org.junit.Assert.assertNotNull(stroke38);
        org.junit.Assert.assertNotNull(layer40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Layer.FOREGROUND" + "'", str43.equals("Layer.FOREGROUND"));
        org.junit.Assert.assertNull(collection44);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.data.xy.XYDataset xYDataset1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer4 = null;
        org.jfree.chart.plot.XYPlot xYPlot5 = new org.jfree.chart.plot.XYPlot(xYDataset1, valueAxis2, valueAxis3, xYItemRenderer4);
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        xYPlot5.drawBackgroundImage(graphics2D6, rectangle2D7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = xYPlot5.getRendererForDataset(xYDataset9);
        xYPlot5.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot18.zoomRangeAxes(0.0d, plotRenderingInfo20, point2D21, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        categoryPlot18.setDomainAxis((int) 'a', categoryAxis25, false);
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis();
        int int29 = categoryPlot18.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis28);
        double double30 = numberAxis28.getFixedAutoRange();
        numberAxis28.setAutoRangeMinimumSize((double) (short) 100);
        numberAxis28.setRange((double) (-1), Double.NaN);
        xYPlot5.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis28);
        boolean boolean37 = textAnchor0.equals((java.lang.Object) xYPlot5);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNull(xYItemRenderer10);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.axis.ValueAxis valueAxis6 = categoryPlot4.getRangeAxisForDataset(1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.plot.Plot plot8 = categoryPlot4.getParent();
        categoryPlot4.setRangeCrosshairValue((double) (short) 100, true);
        org.junit.Assert.assertNull(valueAxis6);
        org.junit.Assert.assertNull(plot8);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace11, false);
        java.awt.Stroke stroke14 = categoryPlot4.getRangeCrosshairStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot4.getFixedLegendItems();
        categoryPlot4.clearDomainMarkers();
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(legendItemCollection15);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        double double4 = dateAxis0.java2DToValue((double) 10.0f, rectangle2D2, rectangleEdge3);
        java.text.DateFormat dateFormat5 = null;
        dateAxis0.setDateFormatOverride(dateFormat5);
        java.awt.Stroke stroke7 = dateAxis0.getAxisLineStroke();
        boolean boolean8 = dateAxis0.isInverted();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 9.223372036854776E18d + "'", double4 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot4.getDomainAxis((int) (short) 100);
        boolean boolean9 = categoryPlot4.isRangeGridlinesVisible();
        java.awt.Paint paint10 = categoryPlot4.getRangeCrosshairPaint();
        org.jfree.data.category.CategoryDataset categoryDataset12 = categoryPlot4.getDataset(0);
        boolean boolean13 = categoryPlot4.getDrawSharedDomainAxis();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot(categoryDataset15, categoryAxis16, valueAxis17, categoryItemRenderer18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot19.zoomRangeAxes(0.0d, plotRenderingInfo21, point2D22, false);
        org.jfree.chart.plot.Marker marker26 = null;
        org.jfree.chart.util.Layer layer27 = null;
        boolean boolean29 = categoryPlot19.removeDomainMarker((int) (byte) 0, marker26, layer27, false);
        categoryPlot19.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        categoryPlot19.setDomainAxis((int) (byte) 0, categoryAxis32);
        java.awt.Image image34 = categoryPlot19.getBackgroundImage();
        org.jfree.chart.axis.AxisSpace axisSpace35 = categoryPlot19.getFixedRangeAxisSpace();
        categoryPlot19.configureRangeAxes();
        categoryPlot19.clearDomainMarkers();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        categoryPlot42.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker46 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke47 = categoryMarker46.getOutlineStroke();
        org.jfree.chart.util.Layer layer48 = null;
        boolean boolean49 = categoryPlot42.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker46, layer48);
        org.jfree.chart.axis.AxisLocation axisLocation51 = categoryPlot42.getDomainAxisLocation((int) '#');
        org.jfree.data.xy.XYDataset xYDataset52 = null;
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer55 = null;
        org.jfree.chart.plot.XYPlot xYPlot56 = new org.jfree.chart.plot.XYPlot(xYDataset52, valueAxis53, valueAxis54, xYItemRenderer55);
        java.awt.Graphics2D graphics2D57 = null;
        java.awt.geom.Rectangle2D rectangle2D58 = null;
        xYPlot56.drawBackgroundImage(graphics2D57, rectangle2D58);
        org.jfree.chart.plot.PlotOrientation plotOrientation60 = xYPlot56.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation51, plotOrientation60);
        org.jfree.chart.axis.AxisLocation axisLocation62 = axisLocation51.getOpposite();
        categoryPlot19.setRangeAxisLocation(axisLocation62);
        categoryPlot4.setRangeAxisLocation((int) '#', axisLocation62);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(categoryDataset12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNull(image34);
        org.junit.Assert.assertNull(axisSpace35);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(axisLocation51);
        org.junit.Assert.assertNotNull(plotOrientation60);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertNotNull(axisLocation62);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean8 = xYPlot4.isRangeZoomable();
        xYPlot4.setRangeCrosshairValue((double) 1, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke14 = categoryMarker13.getOutlineStroke();
        xYPlot4.setRangeGridlineStroke(stroke14);
        xYPlot4.setOutlineVisible(true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        org.jfree.chart.axis.DateAxis dateAxis0 = new org.jfree.chart.axis.DateAxis();
        java.text.DateFormat dateFormat1 = dateAxis0.getDateFormatOverride();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        xYPlot6.setDomainAxisLocation((int) '4', axisLocation8);
        boolean boolean11 = xYPlot6.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent12 = null;
        xYPlot6.markerChanged(markerChangeEvent12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double16 = rectangleInsets14.calculateRightInset((double) '4');
        double double18 = rectangleInsets14.extendHeight((double) 1.0f);
        xYPlot6.setAxisOffset(rectangleInsets14);
        xYPlot6.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot6.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker23);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer29 = null;
        org.jfree.chart.plot.XYPlot xYPlot30 = new org.jfree.chart.plot.XYPlot(xYDataset26, valueAxis27, valueAxis28, xYItemRenderer29);
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        xYPlot30.drawBackgroundImage(graphics2D31, rectangle2D32);
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer35 = xYPlot30.getRendererForDataset(xYDataset34);
        xYPlot30.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis();
        int int40 = xYPlot30.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis39);
        double double41 = numberAxis39.getUpperBound();
        numberAxis39.setFixedAutoRange((double) 100);
        xYPlot6.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis39);
        numberAxis39.setUpperBound((-1.0d));
        java.awt.Stroke stroke47 = numberAxis39.getTickMarkStroke();
        dateAxis0.setAxisLineStroke(stroke47);
        dateAxis0.configure();
        dateAxis0.configure();
        java.lang.Object obj51 = dateAxis0.clone();
        java.lang.Object obj52 = dateAxis0.clone();
        java.lang.Object obj53 = null;
        boolean boolean54 = dateAxis0.equals(obj53);
        org.junit.Assert.assertNull(dateFormat1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 5.0d + "'", double18 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer35);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1) + "'", int40 == (-1));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 1.0d + "'", double41 == 1.0d);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(obj51);
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        categoryPlot4.setRangeCrosshairValue((double) 100.0f);
        java.awt.Color color19 = java.awt.Color.BLACK;
        categoryPlot4.setDomainGridlinePaint((java.awt.Paint) color19);
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke24 = categoryMarker23.getOutlineStroke();
        org.jfree.data.xy.XYDataset xYDataset25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer28 = null;
        org.jfree.chart.plot.XYPlot xYPlot29 = new org.jfree.chart.plot.XYPlot(xYDataset25, valueAxis26, valueAxis27, xYItemRenderer28);
        xYPlot29.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup31 = xYPlot29.getDatasetGroup();
        boolean boolean32 = xYPlot29.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer37 = null;
        org.jfree.chart.plot.XYPlot xYPlot38 = new org.jfree.chart.plot.XYPlot(xYDataset34, valueAxis35, valueAxis36, xYItemRenderer37);
        java.awt.Graphics2D graphics2D39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        xYPlot38.drawBackgroundImage(graphics2D39, rectangle2D40);
        org.jfree.chart.plot.PlotOrientation plotOrientation42 = xYPlot38.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.ValueAxis valueAxis46 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer47 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot(categoryDataset44, categoryAxis45, valueAxis46, categoryItemRenderer47);
        categoryPlot48.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker52 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke53 = categoryMarker52.getOutlineStroke();
        org.jfree.chart.util.Layer layer54 = null;
        boolean boolean55 = categoryPlot48.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker52, layer54);
        java.lang.Comparable comparable56 = categoryMarker52.getKey();
        java.awt.Paint paint57 = categoryMarker52.getPaint();
        org.jfree.chart.util.Layer layer58 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot38.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker52, layer58);
        java.util.Collection collection60 = xYPlot29.getRangeMarkers((int) (short) 100, layer58);
        categoryPlot4.addDomainMarker(0, categoryMarker23, layer58);
        java.lang.String str62 = categoryMarker23.getLabel();
        boolean boolean64 = categoryMarker23.equals((java.lang.Object) "CategoryAnchor.END");
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(datasetGroup31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(plotOrientation42);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + comparable56 + "' != '" + (byte) 0 + "'", comparable56.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(layer58);
        org.junit.Assert.assertNull(collection60);
        org.junit.Assert.assertNull(str62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainGridlinePaint();
        boolean boolean10 = xYPlot4.isDomainCrosshairVisible();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = xYPlot4.getRangeAxisEdge(0);
        try {
            org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot4.getDomainAxisForDataset((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index 97 out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        categoryPlot4.setDomainAxis((int) (byte) 0, categoryAxis17);
        java.awt.Image image19 = categoryPlot4.getBackgroundImage();
        categoryPlot4.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot26.zoomRangeAxes(0.0d, plotRenderingInfo28, point2D29, false);
        org.jfree.chart.plot.Marker marker33 = null;
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean36 = categoryPlot26.removeDomainMarker((int) (byte) 0, marker33, layer34, false);
        categoryPlot26.setBackgroundAlpha((float) 0);
        java.awt.Image image39 = categoryPlot26.getBackgroundImage();
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis41.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        categoryAxis41.configure();
        org.jfree.data.xy.XYDataset xYDataset46 = null;
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer49 = null;
        org.jfree.chart.plot.XYPlot xYPlot50 = new org.jfree.chart.plot.XYPlot(xYDataset46, valueAxis47, valueAxis48, xYItemRenderer49);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = xYPlot50.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.LegendItemCollection legendItemCollection53 = xYPlot50.getLegendItems();
        boolean boolean54 = categoryAxis41.equals((java.lang.Object) legendItemCollection53);
        categoryPlot26.setDomainAxis(categoryAxis41);
        double double56 = categoryAxis41.getUpperMargin();
        categoryPlot4.setDomainAxis(3, categoryAxis41);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(image19);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(image39);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(legendItemCollection53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.05d + "'", double56 == 0.05d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("CategoryAnchor.END");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis();
        double double3 = numberAxis2.getUpperBound();
        java.awt.Paint paint4 = numberAxis2.getAxisLinePaint();
        numberAxis2.setLabel("");
        java.awt.Shape shape7 = numberAxis2.getUpArrow();
        numberAxis1.setLeftArrow(shape7);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        org.jfree.data.xy.XYDataset xYDataset3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer6 = null;
        org.jfree.chart.plot.XYPlot xYPlot7 = new org.jfree.chart.plot.XYPlot(xYDataset3, valueAxis4, valueAxis5, xYItemRenderer6);
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        xYPlot7.drawBackgroundImage(graphics2D8, rectangle2D9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer12 = xYPlot7.getRendererForDataset(xYDataset11);
        xYPlot7.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        java.awt.Color color16 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        xYPlot7.setNoDataMessagePaint((java.awt.Paint) color16);
        java.awt.Color color18 = java.awt.Color.LIGHT_GRAY;
        java.awt.color.ColorSpace colorSpace19 = color18.getColorSpace();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_GREEN;
        float[] floatArray27 = new float[] { 'a', (short) -1, ' ', 10.0f, 0, 0 };
        float[] floatArray28 = color20.getRGBColorComponents(floatArray27);
        float[] floatArray29 = color16.getColorComponents(colorSpace19, floatArray28);
        float[] floatArray30 = java.awt.Color.RGBtoHSB(5, (int) '#', 0, floatArray29);
        org.junit.Assert.assertNull(xYItemRenderer12);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(colorSpace19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertNotNull(floatArray29);
        org.junit.Assert.assertNotNull(floatArray30);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        org.jfree.chart.plot.Plot plot10 = xYPlot4.getRootPlot();
        org.jfree.chart.util.RectangleInsets rectangleInsets15 = new org.jfree.chart.util.RectangleInsets((double) (byte) -1, (double) 0.5f, (double) 0L, (double) (short) -1);
        double double17 = rectangleInsets15.calculateLeftInset(0.0d);
        double double19 = rectangleInsets15.calculateRightOutset(101.0d);
        xYPlot4.setAxisOffset(rectangleInsets15);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier21 = xYPlot4.getDrawingSupplier();
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertNotNull(plot10);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.5d + "'", double17 == 0.5d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertNotNull(drawingSupplier21);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent10 = null;
        xYPlot4.markerChanged(markerChangeEvent10);
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double14 = rectangleInsets12.calculateRightInset((double) '4');
        double double16 = rectangleInsets12.extendHeight((double) 1.0f);
        xYPlot4.setAxisOffset(rectangleInsets12);
        xYPlot4.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot4.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker21);
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        xYPlot28.drawBackgroundImage(graphics2D29, rectangle2D30);
        org.jfree.data.xy.XYDataset xYDataset32 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer33 = xYPlot28.getRendererForDataset(xYDataset32);
        xYPlot28.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        int int38 = xYPlot28.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis37);
        double double39 = numberAxis37.getUpperBound();
        numberAxis37.setFixedAutoRange((double) 100);
        xYPlot4.setRangeAxis(1, (org.jfree.chart.axis.ValueAxis) numberAxis37);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier43 = xYPlot4.getDrawingSupplier();
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 5.0d + "'", double16 == 5.0d);
        org.junit.Assert.assertNull(xYItemRenderer33);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1) + "'", int38 == (-1));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0d + "'", double39 == 1.0d);
        org.junit.Assert.assertNotNull(drawingSupplier43);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot4.getIndexOf(xYItemRenderer10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot17.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot17.setDomainAxis((int) 'a', categoryAxis24, false);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        int int28 = categoryPlot17.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis27);
        numberAxis27.setRangeAboutValue((double) (byte) 0, 0.0d);
        double double32 = numberAxis27.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset33, valueAxis34, valueAxis35, xYItemRenderer36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        xYPlot37.drawBackgroundImage(graphics2D38, rectangle2D39);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = xYPlot37.getRendererForDataset(xYDataset41);
        xYPlot37.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis();
        int int47 = xYPlot37.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis46);
        double double48 = numberAxis46.getUpperBound();
        numberAxis46.setLabelURL("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis46, xYItemRenderer51);
        java.awt.Stroke stroke53 = xYPlot52.getDomainZeroBaselineStroke();
        xYPlot4.setParent((org.jfree.chart.plot.Plot) xYPlot52);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder55 = xYPlot52.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(datasetRenderingOrder55);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) unitType0, jFreeChart1, chartChangeEventType2);
        java.lang.String str4 = unitType0.toString();
        java.lang.String str5 = unitType0.toString();
        org.jfree.chart.JFreeChart jFreeChart6 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) unitType0, jFreeChart6);
        org.junit.Assert.assertNotNull(unitType0);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UnitType.RELATIVE" + "'", str4.equals("UnitType.RELATIVE"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "UnitType.RELATIVE" + "'", str5.equals("UnitType.RELATIVE"));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("XY Plot");
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        java.awt.Color color1 = null;
        java.awt.Color color2 = java.awt.Color.getColor("", color1);
        org.junit.Assert.assertNull(color2);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean8 = xYPlot4.isRangeZoomable();
        xYPlot4.setRangeCrosshairValue((double) 1, false);
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot(categoryDataset12, categoryAxis13, valueAxis14, categoryItemRenderer15);
        categoryPlot16.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker20 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke21 = categoryMarker20.getOutlineStroke();
        org.jfree.chart.util.Layer layer22 = null;
        boolean boolean23 = categoryPlot16.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker20, layer22);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot16.setDatasetRenderingOrder(datasetRenderingOrder24);
        categoryPlot16.setForegroundAlpha((float) (short) 100);
        org.jfree.data.general.Dataset dataset28 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent29 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (short) 100, dataset28);
        xYPlot4.datasetChanged(datasetChangeEvent29);
        java.awt.Image image31 = xYPlot4.getBackgroundImage();
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
        org.junit.Assert.assertNull(image31);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder17 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer21 = null;
        org.jfree.chart.plot.XYPlot xYPlot22 = new org.jfree.chart.plot.XYPlot(xYDataset18, valueAxis19, valueAxis20, xYItemRenderer21);
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        xYPlot22.drawBackgroundImage(graphics2D23, rectangle2D24);
        org.jfree.data.xy.XYDataset xYDataset26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = xYPlot22.getRendererForDataset(xYDataset26);
        xYPlot22.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor34 = null;
        java.awt.geom.Point2D point2D35 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D33, rectangleAnchor34);
        xYPlot22.zoomRangeAxes(4.0d, plotRenderingInfo32, point2D35);
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = xYPlot22.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot(categoryDataset38, categoryAxis39, valueAxis40, categoryItemRenderer41);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot42.zoomRangeAxes(0.0d, plotRenderingInfo44, point2D45, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        categoryPlot42.setDomainAxis((int) 'a', categoryAxis49, false);
        xYPlot22.setParent((org.jfree.chart.plot.Plot) categoryPlot42);
        boolean boolean53 = datasetRenderingOrder17.equals((java.lang.Object) xYPlot22);
        categoryPlot4.setDatasetRenderingOrder(datasetRenderingOrder17);
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent55 = null;
        categoryPlot4.datasetChanged(datasetChangeEvent55);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor57 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot4.setDomainGridlinePosition(categoryAnchor57);
        java.lang.String str59 = categoryAnchor57.toString();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder17);
        org.junit.Assert.assertNull(xYItemRenderer27);
        org.junit.Assert.assertNotNull(point2D35);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(categoryAnchor57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "CategoryAnchor.END" + "'", str59.equals("CategoryAnchor.END"));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot17.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot17.setDomainAxis((int) 'a', categoryAxis24, false);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        int int28 = categoryPlot17.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis27);
        double double29 = numberAxis27.getFixedAutoRange();
        numberAxis27.setAutoRangeMinimumSize((double) (short) 100);
        numberAxis27.setRange((double) (-1), Double.NaN);
        xYPlot4.setDomainAxis((org.jfree.chart.axis.ValueAxis) numberAxis27);
        org.jfree.chart.axis.AxisLocation axisLocation36 = xYPlot4.getRangeAxisLocation();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj38 = numberAxis37.clone();
        org.jfree.data.xy.XYDataset xYDataset39 = null;
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = null;
        org.jfree.chart.plot.XYPlot xYPlot43 = new org.jfree.chart.plot.XYPlot(xYDataset39, valueAxis40, valueAxis41, xYItemRenderer42);
        java.awt.Graphics2D graphics2D44 = null;
        java.awt.geom.Rectangle2D rectangle2D45 = null;
        xYPlot43.drawBackgroundImage(graphics2D44, rectangle2D45);
        numberAxis37.removeChangeListener((org.jfree.chart.event.AxisChangeListener) xYPlot43);
        xYPlot43.clearDomainMarkers();
        org.jfree.data.category.CategoryDataset categoryDataset49 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer52 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot(categoryDataset49, categoryAxis50, valueAxis51, categoryItemRenderer52);
        categoryPlot53.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker57 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke58 = categoryMarker57.getOutlineStroke();
        org.jfree.chart.util.Layer layer59 = null;
        boolean boolean60 = categoryPlot53.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker57, layer59);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder61 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot53.setDatasetRenderingOrder(datasetRenderingOrder61);
        categoryPlot53.setForegroundAlpha((float) (short) 100);
        org.jfree.data.general.Dataset dataset65 = null;
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent66 = new org.jfree.data.general.DatasetChangeEvent((java.lang.Object) (short) 100, dataset65);
        xYPlot43.datasetChanged(datasetChangeEvent66);
        xYPlot4.datasetChanged(datasetChangeEvent66);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(axisLocation36);
        org.junit.Assert.assertNotNull(obj38);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder61);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.clearAnnotations();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot4.getRangeAxisEdge();
        org.jfree.data.general.DatasetGroup datasetGroup17 = categoryPlot4.getDatasetGroup();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot4.getDomainAxisForDataset((int) (byte) 10);
        org.jfree.chart.axis.ValueAxis valueAxis21 = categoryPlot4.getRangeAxisForDataset((int) (byte) 1);
        categoryPlot4.clearDomainMarkers(1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNull(datasetGroup17);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertNull(valueAxis21);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.axis.ValueAxis valueAxis18 = categoryPlot4.getRangeAxis(0);
        org.jfree.data.xy.XYDataset xYDataset19 = null;
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer22 = null;
        org.jfree.chart.plot.XYPlot xYPlot23 = new org.jfree.chart.plot.XYPlot(xYDataset19, valueAxis20, valueAxis21, xYItemRenderer22);
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = xYPlot23.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        xYPlot23.setFixedRangeAxisSpace(axisSpace26);
        java.awt.Paint paint28 = xYPlot23.getDomainGridlinePaint();
        categoryPlot4.setParent((org.jfree.chart.plot.Plot) xYPlot23);
        xYPlot23.clearDomainMarkers((int) (short) 10);
        xYPlot23.setDomainCrosshairVisible(true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(valueAxis18);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        numberAxis14.setRangeAboutValue((double) (byte) 0, 0.0d);
        double double19 = numberAxis14.getFixedAutoRange();
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = null;
        double double23 = numberAxis14.java2DToValue((double) 15, rectangle2D21, rectangleEdge22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = numberAxis14.getTickLabelInsets();
        numberAxis14.setPositiveArrowVisible(false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertEquals((double) double23, Double.NaN, 0);
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainCrosshairPaint();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer10 = null;
        int int11 = xYPlot4.getIndexOf(xYItemRenderer10);
        org.jfree.data.xy.XYDataset xYDataset12 = null;
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot17.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = null;
        categoryPlot17.setDomainAxis((int) 'a', categoryAxis24, false);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis();
        int int28 = categoryPlot17.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis27);
        numberAxis27.setRangeAboutValue((double) (byte) 0, 0.0d);
        double double32 = numberAxis27.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset33 = null;
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.axis.ValueAxis valueAxis35 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer36 = null;
        org.jfree.chart.plot.XYPlot xYPlot37 = new org.jfree.chart.plot.XYPlot(xYDataset33, valueAxis34, valueAxis35, xYItemRenderer36);
        java.awt.Graphics2D graphics2D38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        xYPlot37.drawBackgroundImage(graphics2D38, rectangle2D39);
        org.jfree.data.xy.XYDataset xYDataset41 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer42 = xYPlot37.getRendererForDataset(xYDataset41);
        xYPlot37.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis();
        int int47 = xYPlot37.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis46);
        double double48 = numberAxis46.getUpperBound();
        numberAxis46.setLabelURL("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer51 = null;
        org.jfree.chart.plot.XYPlot xYPlot52 = new org.jfree.chart.plot.XYPlot(xYDataset12, (org.jfree.chart.axis.ValueAxis) numberAxis27, (org.jfree.chart.axis.ValueAxis) numberAxis46, xYItemRenderer51);
        java.awt.Stroke stroke53 = xYPlot52.getDomainZeroBaselineStroke();
        xYPlot4.setParent((org.jfree.chart.plot.Plot) xYPlot52);
        org.jfree.chart.plot.CategoryMarker categoryMarker56 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke57 = categoryMarker56.getOutlineStroke();
        org.jfree.chart.text.TextAnchor textAnchor58 = categoryMarker56.getLabelTextAnchor();
        boolean boolean59 = xYPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker56);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer42);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(textAnchor58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        int int5 = xYPlot4.getSeriesCount();
        org.jfree.chart.LegendItemCollection legendItemCollection6 = xYPlot4.getFixedLegendItems();
        java.awt.Paint paint7 = xYPlot4.getDomainGridlinePaint();
        org.jfree.chart.plot.SeriesRenderingOrder seriesRenderingOrder8 = xYPlot4.getSeriesRenderingOrder();
        java.lang.String str9 = seriesRenderingOrder8.toString();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNull(legendItemCollection6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(seriesRenderingOrder8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "SeriesRenderingOrder.REVERSE" + "'", str9.equals("SeriesRenderingOrder.REVERSE"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        boolean boolean15 = categoryPlot4.isDomainZoomable();
        boolean boolean16 = categoryPlot4.isRangeCrosshairVisible();
        int int17 = categoryPlot4.getWeight();
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        boolean boolean22 = categoryPlot4.render(graphics2D18, rectangle2D19, (-1), plotRenderingInfo21);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot4.setDomainAxis((int) 'a', categoryAxis11, false);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis();
        int int15 = categoryPlot4.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis14);
        double double16 = numberAxis14.getFixedAutoRange();
        numberAxis14.setAutoRangeMinimumSize((double) (short) 100);
        numberAxis14.setRange((double) (-1), Double.NaN);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot(categoryDataset22, categoryAxis23, valueAxis24, categoryItemRenderer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot26.zoomRangeAxes(0.0d, plotRenderingInfo28, point2D29, false);
        org.jfree.chart.plot.Marker marker33 = null;
        org.jfree.chart.util.Layer layer34 = null;
        boolean boolean36 = categoryPlot26.removeDomainMarker((int) (byte) 0, marker33, layer34, false);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray37 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot26.setRangeAxes(valueAxisArray37);
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot26.getDomainAxisEdge(1);
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        categoryPlot26.setFixedDomainAxisSpace(axisSpace41);
        org.jfree.data.xy.XYDataset xYDataset44 = null;
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj46 = numberAxis45.clone();
        boolean boolean47 = numberAxis45.isAutoRange();
        boolean boolean48 = numberAxis45.isVisible();
        org.jfree.data.xy.XYDataset xYDataset49 = null;
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer52 = null;
        org.jfree.chart.plot.XYPlot xYPlot53 = new org.jfree.chart.plot.XYPlot(xYDataset49, valueAxis50, valueAxis51, xYItemRenderer52);
        java.awt.Graphics2D graphics2D54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        xYPlot53.drawBackgroundImage(graphics2D54, rectangle2D55);
        org.jfree.data.xy.XYDataset xYDataset57 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer58 = xYPlot53.getRendererForDataset(xYDataset57);
        xYPlot53.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis();
        int int63 = xYPlot53.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis62);
        double double64 = numberAxis62.getUpperBound();
        numberAxis62.setFixedAutoRange((double) 100);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand67 = numberAxis62.getMarkerBand();
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer68 = null;
        org.jfree.chart.plot.XYPlot xYPlot69 = new org.jfree.chart.plot.XYPlot(xYDataset44, (org.jfree.chart.axis.ValueAxis) numberAxis45, (org.jfree.chart.axis.ValueAxis) numberAxis62, xYItemRenderer68);
        categoryPlot26.setRangeAxis((int) (byte) 100, (org.jfree.chart.axis.ValueAxis) numberAxis45, false);
        numberAxis14.setPlot((org.jfree.chart.plot.Plot) categoryPlot26);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer73 = null;
        categoryPlot26.setRenderer(categoryItemRenderer73, false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(valueAxisArray37);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
        org.junit.Assert.assertNull(xYItemRenderer58);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1) + "'", int63 == (-1));
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 1.0d + "'", double64 == 1.0d);
        org.junit.Assert.assertNull(markerAxisBand67);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        categoryPlot4.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot4.getDomainAxis((int) (short) 100);
        boolean boolean9 = categoryPlot4.isRangeGridlinesVisible();
        java.awt.Paint paint10 = categoryPlot4.getRangeCrosshairPaint();
        java.awt.Stroke stroke11 = categoryPlot4.getRangeCrosshairStroke();
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((double) (byte) 1);
        org.jfree.data.xy.XYDataset xYDataset15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer18 = null;
        org.jfree.chart.plot.XYPlot xYPlot19 = new org.jfree.chart.plot.XYPlot(xYDataset15, valueAxis16, valueAxis17, xYItemRenderer18);
        xYPlot19.configureDomainAxes();
        org.jfree.data.general.DatasetGroup datasetGroup21 = xYPlot19.getDatasetGroup();
        boolean boolean22 = xYPlot19.isRangeZoomable();
        org.jfree.data.xy.XYDataset xYDataset24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer27 = null;
        org.jfree.chart.plot.XYPlot xYPlot28 = new org.jfree.chart.plot.XYPlot(xYDataset24, valueAxis25, valueAxis26, xYItemRenderer27);
        java.awt.Graphics2D graphics2D29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        xYPlot28.drawBackgroundImage(graphics2D29, rectangle2D30);
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = xYPlot28.getOrientation();
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.ValueAxis valueAxis36 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot(categoryDataset34, categoryAxis35, valueAxis36, categoryItemRenderer37);
        categoryPlot38.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker42 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke43 = categoryMarker42.getOutlineStroke();
        org.jfree.chart.util.Layer layer44 = null;
        boolean boolean45 = categoryPlot38.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker42, layer44);
        java.lang.Comparable comparable46 = categoryMarker42.getKey();
        java.awt.Paint paint47 = categoryMarker42.getPaint();
        org.jfree.chart.util.Layer layer48 = org.jfree.chart.util.Layer.FOREGROUND;
        xYPlot28.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) categoryMarker42, layer48);
        java.util.Collection collection50 = xYPlot19.getRangeMarkers((int) (short) 100, layer48);
        categoryPlot4.addRangeMarker(100, (org.jfree.chart.plot.Marker) valueMarker14, layer48, false);
        double double53 = valueMarker14.getValue();
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(datasetGroup21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + comparable46 + "' != '" + (byte) 0 + "'", comparable46.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNotNull(layer48);
        org.junit.Assert.assertNull(collection50);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset3 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot(categoryDataset3, categoryAxis4, valueAxis5, categoryItemRenderer6);
        categoryPlot7.setAnchorValue((double) 0L);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot7.getDomainAxis((int) (short) 100);
        boolean boolean12 = categoryPlot7.isRangeGridlinesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot(categoryDataset13, categoryAxis14, valueAxis15, categoryItemRenderer16);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot17.zoomRangeAxes(0.0d, plotRenderingInfo19, point2D20, false);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, valueAxis25, xYItemRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot27.setDomainAxisLocation((int) '4', axisLocation29);
        boolean boolean32 = xYPlot27.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = null;
        xYPlot27.markerChanged(markerChangeEvent33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double37 = rectangleInsets35.calculateRightInset((double) '4');
        double double39 = rectangleInsets35.extendHeight((double) 1.0f);
        xYPlot27.setAxisOffset(rectangleInsets35);
        xYPlot27.setRangeCrosshairValue(0.05d);
        org.jfree.chart.plot.CategoryMarker categoryMarker44 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        xYPlot27.addDomainMarker((org.jfree.chart.plot.Marker) categoryMarker44);
        categoryPlot17.addDomainMarker(categoryMarker44);
        boolean boolean47 = categoryPlot7.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker44);
        categoryPlot7.setRangeCrosshairValue((double) 100, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer51 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray52 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { categoryItemRenderer51 };
        categoryPlot7.setRenderers(categoryItemRendererArray52);
        org.jfree.chart.axis.AxisLocation axisLocation55 = categoryPlot7.getDomainAxisLocation((int) (short) 100);
        try {
            categoryPlot0.setRangeAxisLocation((-1), axisLocation55);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 5.0d + "'", double39 == 5.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(categoryItemRendererArray52);
        org.junit.Assert.assertNotNull(axisLocation55);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = null;
        xYPlot4.setDomainAxisLocation((int) '4', axisLocation6);
        boolean boolean9 = xYPlot4.equals((java.lang.Object) 1.0f);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot(categoryDataset10, categoryAxis11, valueAxis12, categoryItemRenderer13);
        categoryPlot14.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke19 = categoryMarker18.getOutlineStroke();
        org.jfree.chart.util.Layer layer20 = null;
        boolean boolean21 = categoryPlot14.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker18, layer20);
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot14.getDomainAxisLocation((int) '#');
        xYPlot4.setDomainAxisLocation(axisLocation23, false);
        java.awt.Paint paint26 = xYPlot4.getRangeCrosshairPaint();
        java.awt.Graphics2D graphics2D27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        xYPlot4.drawAnnotations(graphics2D27, rectangle2D28, plotRenderingInfo29);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryMarker categoryMarker2 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Paint paint3 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        categoryMarker2.setLabelPaint(paint3);
        java.lang.Comparable comparable5 = categoryMarker2.getKey();
        org.jfree.chart.util.Layer layer6 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) categoryMarker2, layer6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.jfree.data.xy.XYDataset xYDataset10 = null;
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer13 = null;
        org.jfree.chart.plot.XYPlot xYPlot14 = new org.jfree.chart.plot.XYPlot(xYDataset10, valueAxis11, valueAxis12, xYItemRenderer13);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        xYPlot14.drawBackgroundImage(graphics2D15, rectangle2D16);
        org.jfree.data.xy.XYDataset xYDataset18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = xYPlot14.getRendererForDataset(xYDataset18);
        xYPlot14.mapDatasetToRangeAxis((int) (short) 1, 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor26 = null;
        java.awt.geom.Point2D point2D27 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D25, rectangleAnchor26);
        xYPlot14.zoomRangeAxes(4.0d, plotRenderingInfo24, point2D27);
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = xYPlot14.getDomainAxisEdge();
        org.jfree.data.category.CategoryDataset categoryDataset30 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis31 = null;
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot(categoryDataset30, categoryAxis31, valueAxis32, categoryItemRenderer33);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        categoryPlot34.zoomRangeAxes(0.0d, plotRenderingInfo36, point2D37, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = null;
        categoryPlot34.setDomainAxis((int) 'a', categoryAxis41, false);
        xYPlot14.setParent((org.jfree.chart.plot.Plot) categoryPlot34);
        boolean boolean45 = datasetRenderingOrder9.equals((java.lang.Object) xYPlot14);
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder9);
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + comparable5 + "' != '" + (byte) 0 + "'", comparable5.equals((byte) 0));
        org.junit.Assert.assertNotNull(axisLocation8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNull(xYItemRenderer19);
        org.junit.Assert.assertNotNull(point2D27);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.data.category.CategoryDataset categoryDataset1 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot(categoryDataset1, categoryAxis2, valueAxis3, categoryItemRenderer4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot5.zoomRangeAxes(0.0d, plotRenderingInfo7, point2D8, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot5.setDomainAxis((int) 'a', categoryAxis12, false);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis();
        int int16 = categoryPlot5.getRangeAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis15);
        numberAxis15.setRangeAboutValue((double) (byte) 0, 0.0d);
        double double20 = numberAxis15.getFixedAutoRange();
        org.jfree.data.xy.XYDataset xYDataset21 = null;
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer24 = null;
        org.jfree.chart.plot.XYPlot xYPlot25 = new org.jfree.chart.plot.XYPlot(xYDataset21, valueAxis22, valueAxis23, xYItemRenderer24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        xYPlot25.drawBackgroundImage(graphics2D26, rectangle2D27);
        org.jfree.data.xy.XYDataset xYDataset29 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer30 = xYPlot25.getRendererForDataset(xYDataset29);
        xYPlot25.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis();
        int int35 = xYPlot25.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis34);
        double double36 = numberAxis34.getUpperBound();
        numberAxis34.setLabelURL("");
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer39 = null;
        org.jfree.chart.plot.XYPlot xYPlot40 = new org.jfree.chart.plot.XYPlot(xYDataset0, (org.jfree.chart.axis.ValueAxis) numberAxis15, (org.jfree.chart.axis.ValueAxis) numberAxis34, xYItemRenderer39);
        boolean boolean41 = xYPlot40.isOutlineVisible();
        org.jfree.data.xy.XYDataset xYDataset42 = null;
        org.jfree.chart.axis.ValueAxis valueAxis43 = null;
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer45 = null;
        org.jfree.chart.plot.XYPlot xYPlot46 = new org.jfree.chart.plot.XYPlot(xYDataset42, valueAxis43, valueAxis44, xYItemRenderer45);
        java.awt.Graphics2D graphics2D47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        xYPlot46.drawBackgroundImage(graphics2D47, rectangle2D48);
        java.awt.Stroke stroke50 = xYPlot46.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis52 = xYPlot46.getRangeAxis(10);
        xYPlot46.setDomainCrosshairValue(0.0d, false);
        java.awt.Font font56 = xYPlot46.getNoDataMessageFont();
        org.jfree.chart.plot.PlotOrientation plotOrientation57 = xYPlot46.getOrientation();
        xYPlot40.setOrientation(plotOrientation57);
        org.jfree.chart.axis.ValueAxis valueAxis59 = xYPlot40.getRangeAxis();
        xYPlot40.setRangeZeroBaselineVisible(true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNull(xYItemRenderer30);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0d + "'", double36 == 1.0d);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNull(valueAxis52);
        org.junit.Assert.assertNotNull(font56);
        org.junit.Assert.assertNotNull(plotOrientation57);
        org.junit.Assert.assertNotNull(valueAxis59);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        xYPlot4.setFixedRangeAxisSpace(axisSpace7);
        java.awt.Paint paint9 = xYPlot4.getDomainGridlinePaint();
        java.awt.Color color10 = java.awt.Color.WHITE;
        xYPlot4.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.axis.DateAxis dateAxis14 = new org.jfree.chart.axis.DateAxis("org.jfree.chart.event.ChartChangeEvent[source=UnitType.RELATIVE]");
        xYPlot4.setRangeAxis(500, (org.jfree.chart.axis.ValueAxis) dateAxis14);
        org.jfree.data.xy.XYDataset xYDataset16 = null;
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer19 = null;
        org.jfree.chart.plot.XYPlot xYPlot20 = new org.jfree.chart.plot.XYPlot(xYDataset16, valueAxis17, valueAxis18, xYItemRenderer19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        xYPlot20.setDomainAxisLocation((int) '4', axisLocation22);
        boolean boolean25 = xYPlot20.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        xYPlot20.markerChanged(markerChangeEvent26);
        org.jfree.chart.plot.IntervalMarker intervalMarker31 = new org.jfree.chart.plot.IntervalMarker((double) 1L, (double) (-1L));
        org.jfree.chart.util.Layer layer32 = null;
        xYPlot20.addRangeMarker((int) (short) -1, (org.jfree.chart.plot.Marker) intervalMarker31, layer32);
        java.lang.String str34 = intervalMarker31.getLabel();
        boolean boolean35 = xYPlot4.removeDomainMarker((org.jfree.chart.plot.Marker) intervalMarker31);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(str34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.plot.Marker marker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        boolean boolean14 = categoryPlot4.removeDomainMarker((int) (byte) 0, marker11, layer12, false);
        categoryPlot4.setBackgroundAlpha((float) 0);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        categoryPlot4.setRenderer(categoryItemRenderer17);
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = categoryPlot4.getOrientation();
        java.lang.String str20 = plotOrientation19.toString();
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "PlotOrientation.VERTICAL" + "'", str20.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        org.jfree.data.xy.XYDataset xYDataset8 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer9 = xYPlot4.getRendererForDataset(xYDataset8);
        xYPlot4.mapDatasetToRangeAxis((int) (short) 0, (int) (byte) -1);
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis();
        int int14 = xYPlot4.getDomainAxisIndex((org.jfree.chart.axis.ValueAxis) numberAxis13);
        org.jfree.chart.plot.CategoryMarker categoryMarker16 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke17 = categoryMarker16.getOutlineStroke();
        numberAxis13.setTickMarkStroke(stroke17);
        numberAxis13.setAutoTickUnitSelection(false);
        numberAxis13.setTickMarkInsideLength((float) 2019);
        org.jfree.data.xy.XYDataset xYDataset23 = null;
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer26 = null;
        org.jfree.chart.plot.XYPlot xYPlot27 = new org.jfree.chart.plot.XYPlot(xYDataset23, valueAxis24, valueAxis25, xYItemRenderer26);
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        xYPlot27.setDomainAxisLocation((int) '4', axisLocation29);
        boolean boolean32 = xYPlot27.equals((java.lang.Object) 1.0f);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent33 = null;
        xYPlot27.markerChanged(markerChangeEvent33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double37 = rectangleInsets35.calculateRightInset((double) '4');
        double double39 = rectangleInsets35.extendHeight((double) 1.0f);
        xYPlot27.setAxisOffset(rectangleInsets35);
        org.jfree.chart.util.UnitType unitType41 = rectangleInsets35.getUnitType();
        double double43 = rectangleInsets35.calculateLeftOutset(0.0d);
        numberAxis13.setTickLabelInsets(rectangleInsets35);
        org.junit.Assert.assertNull(xYItemRenderer9);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 4.0d + "'", double37 == 4.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 5.0d + "'", double39 == 5.0d);
        org.junit.Assert.assertNotNull(unitType41);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 4.0d + "'", double43 == 4.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = xYPlot4.getRangeAxisEdge((int) (byte) 10);
        org.jfree.data.xy.XYDataset xYDataset7 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer8 = xYPlot4.getRendererForDataset(xYDataset7);
        org.jfree.data.xy.XYDataset xYDataset9 = null;
        xYPlot4.setDataset(xYDataset9);
        org.jfree.data.xy.XYDataset xYDataset11 = null;
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer14 = null;
        org.jfree.chart.plot.XYPlot xYPlot15 = new org.jfree.chart.plot.XYPlot(xYDataset11, valueAxis12, valueAxis13, xYItemRenderer14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        xYPlot15.setDomainAxisLocation((int) '4', axisLocation17);
        boolean boolean19 = xYPlot15.isRangeZoomable();
        org.jfree.chart.axis.DateAxis dateAxis21 = new org.jfree.chart.axis.DateAxis();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = null;
        double double25 = dateAxis21.java2DToValue((double) 10.0f, rectangle2D23, rectangleEdge24);
        java.text.DateFormat dateFormat26 = null;
        dateAxis21.setDateFormatOverride(dateFormat26);
        org.jfree.chart.axis.Timeline timeline28 = dateAxis21.getTimeline();
        java.lang.Object obj29 = dateAxis21.clone();
        xYPlot15.setDomainAxis((int) (short) 1, (org.jfree.chart.axis.ValueAxis) dateAxis21, true);
        java.lang.Object obj32 = dateAxis21.clone();
        org.jfree.data.Range range33 = xYPlot4.getDataRange((org.jfree.chart.axis.ValueAxis) dateAxis21);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(xYItemRenderer8);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 9.223372036854776E18d + "'", double25 == 9.223372036854776E18d);
        org.junit.Assert.assertNotNull(timeline28);
        org.junit.Assert.assertNotNull(obj29);
        org.junit.Assert.assertNotNull(obj32);
        org.junit.Assert.assertNull(range33);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        org.jfree.chart.axis.ValueAxis valueAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer3 = null;
        org.jfree.chart.plot.XYPlot xYPlot4 = new org.jfree.chart.plot.XYPlot(xYDataset0, valueAxis1, valueAxis2, xYItemRenderer3);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        xYPlot4.drawBackgroundImage(graphics2D5, rectangle2D6);
        java.awt.Stroke stroke8 = xYPlot4.getDomainZeroBaselineStroke();
        java.lang.String str9 = xYPlot4.getNoDataMessage();
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(str9);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        org.jfree.chart.axis.ValueAxis valueAxis2 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot(categoryDataset0, categoryAxis1, valueAxis2, categoryItemRenderer3);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot4.zoomRangeAxes(0.0d, plotRenderingInfo6, point2D7, false);
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot4.getFixedDomainAxisSpace();
        org.jfree.chart.axis.AxisSpace axisSpace11 = null;
        categoryPlot4.setFixedRangeAxisSpace(axisSpace11, false);
        java.awt.Stroke stroke14 = categoryPlot4.getRangeCrosshairStroke();
        float float15 = categoryPlot4.getBackgroundImageAlpha();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = null;
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot(categoryDataset16, categoryAxis17, valueAxis18, categoryItemRenderer19);
        categoryPlot20.setAnchorValue((double) 0L);
        org.jfree.chart.plot.CategoryMarker categoryMarker24 = new org.jfree.chart.plot.CategoryMarker((java.lang.Comparable) (byte) 0);
        java.awt.Stroke stroke25 = categoryMarker24.getOutlineStroke();
        org.jfree.chart.util.Layer layer26 = null;
        boolean boolean27 = categoryPlot20.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker24, layer26);
        java.lang.Comparable comparable28 = categoryMarker24.getKey();
        java.awt.Paint paint29 = categoryMarker24.getPaint();
        boolean boolean30 = categoryPlot4.removeRangeMarker((org.jfree.chart.plot.Marker) categoryMarker24);
        boolean boolean31 = categoryPlot4.isRangeCrosshairVisible();
        org.junit.Assert.assertNull(axisSpace10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.5f + "'", float15 == 0.5f);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + comparable28 + "' != '" + (byte) 0 + "'", comparable28.equals((byte) 0));
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        double double1 = numberAxis0.getUpperBound();
        numberAxis0.setTickLabelsVisible(true);
        org.jfree.data.xy.XYDataset xYDataset4 = null;
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer7 = null;
        org.jfree.chart.plot.XYPlot xYPlot8 = new org.jfree.chart.plot.XYPlot(xYDataset4, valueAxis5, valueAxis6, xYItemRenderer7);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        xYPlot8.drawBackgroundImage(graphics2D9, rectangle2D10);
        java.awt.Stroke stroke12 = xYPlot8.getRangeCrosshairStroke();
        org.jfree.chart.axis.ValueAxis valueAxis14 = xYPlot8.getRangeAxis(10);
        xYPlot8.setDomainCrosshairValue(0.0d, false);
        java.awt.Font font18 = xYPlot8.getNoDataMessageFont();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = xYPlot8.getOrientation();
        numberAxis0.setPlot((org.jfree.chart.plot.Plot) xYPlot8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(valueAxis14);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(plotOrientation19);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.lang.String str1 = plotOrientation0.toString();
        org.jfree.data.xy.XYDataset xYDataset2 = null;
        org.jfree.chart.axis.ValueAxis valueAxis3 = null;
        org.jfree.chart.axis.ValueAxis valueAxis4 = null;
        org.jfree.chart.renderer.xy.XYItemRenderer xYItemRenderer5 = null;
        org.jfree.chart.plot.XYPlot xYPlot6 = new org.jfree.chart.plot.XYPlot(xYDataset2, valueAxis3, valueAxis4, xYItemRenderer5);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = xYPlot6.getRangeAxisEdge((int) (byte) 10);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        xYPlot6.setFixedRangeAxisSpace(axisSpace9);
        java.awt.Paint paint11 = xYPlot6.getDomainCrosshairPaint();
        int int12 = xYPlot6.getRangeAxisCount();
        boolean boolean13 = plotOrientation0.equals((java.lang.Object) xYPlot6);
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot(categoryDataset14, categoryAxis15, valueAxis16, categoryItemRenderer17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot18.zoomRangeAxes(0.0d, plotRenderingInfo20, point2D21, false);
        org.jfree.chart.plot.Marker marker25 = null;
        org.jfree.chart.util.Layer layer26 = null;
        boolean boolean28 = categoryPlot18.removeDomainMarker((int) (byte) 0, marker25, layer26, false);
        boolean boolean29 = categoryPlot18.isDomainZoomable();
        boolean boolean30 = xYPlot6.equals((java.lang.Object) categoryPlot18);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot18.setFixedDomainAxisSpace(axisSpace31, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis35.addCategoryLabelToolTip((java.lang.Comparable) 15, "TextAnchor.BOTTOM_CENTER");
        java.lang.String str40 = categoryAxis35.getCategoryLabelToolTip((java.lang.Comparable) ' ');
        categoryPlot18.setDomainAxis(categoryAxis35);
        categoryPlot18.clearAnnotations();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str1.equals("PlotOrientation.HORIZONTAL"));
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNull(str40);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        java.lang.Object obj1 = numberAxis0.clone();
        boolean boolean2 = numberAxis0.isAutoRange();
        boolean boolean3 = numberAxis0.isVisible();
        java.awt.Paint paint4 = numberAxis0.getTickLabelPaint();
        java.awt.Paint paint5 = numberAxis0.getTickMarkPaint();
        numberAxis0.setAutoTickUnitSelection(true, true);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }
}

