import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        numberAxis1.setTickMarksVisible(false);
        boolean boolean5 = numberAxis1.isAutoRange();
        numberAxis1.setRangeWithMargins((double) 0.0f, (double) 1L);
        java.text.NumberFormat numberFormat9 = numberAxis1.getNumberFormatOverride();
        java.awt.Font font10 = numberAxis1.getTickLabelFont();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(numberFormat9);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, true);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener5 = null;
        defaultStatisticalCategoryDataset1.addChangeListener(datasetChangeListener5);
        java.lang.Number number9 = defaultStatisticalCategoryDataset1.getMeanValue((java.lang.Comparable) 15, (java.lang.Comparable) 1.0f);
        java.util.List list10 = defaultStatisticalCategoryDataset1.getRowKeys();
        projectInfo0.setContributors(list10);
        try {
            java.util.Collection collection12 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list10);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertEquals((double) number2, Double.NaN, 0);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertNull(number9);
        org.junit.Assert.assertNotNull(list10);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        java.awt.Paint paint28 = legendItem27.getLinePaint();
        java.lang.Comparable comparable29 = legendItem27.getSeriesKey();
        java.lang.String str30 = legendItem27.getToolTipText();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(comparable29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str30.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color30);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double45 = numberAxis44.getLabelAngle();
        numberAxis44.setFixedDimension(0.0d);
        org.jfree.data.Range range48 = numberAxis44.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent49 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis44);
        java.awt.Shape shape50 = numberAxis44.getRightArrow();
        legendGraphic42.setLine(shape50);
        legendGraphic42.setWidth(0.0d);
        java.awt.Paint paint54 = legendGraphic42.getOutlinePaint();
        legendGraphic42.setLineVisible(true);
        java.awt.Shape shape64 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        java.awt.Color color66 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color68 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.axis.NumberAxis numberAxis70 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double71 = numberAxis70.getLabelAngle();
        numberAxis70.setFixedDimension(0.0d);
        org.jfree.data.Range range74 = numberAxis70.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent75 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis70);
        java.util.EventListener eventListener76 = null;
        boolean boolean77 = numberAxis70.hasListener(eventListener76);
        java.awt.Stroke stroke78 = numberAxis70.getTickMarkStroke();
        java.awt.Shape shape82 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer83 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint85 = barRenderer83.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint87 = barRenderer83.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke89 = null;
        barRenderer83.setSeriesOutlineStroke(0, stroke89, true);
        java.awt.Stroke stroke94 = barRenderer83.getItemOutlineStroke((int) (byte) -1, 0);
        java.awt.Color color95 = java.awt.Color.CYAN;
        int int96 = color95.getRed();
        org.jfree.chart.LegendItem legendItem97 = new org.jfree.chart.LegendItem("{0}", "", "EXPAND", "hi!", false, shape64, true, (java.awt.Paint) color66, true, (java.awt.Paint) color68, stroke78, false, shape82, stroke94, (java.awt.Paint) color95);
        java.awt.Color color98 = color68.brighter();
        legendGraphic42.setLinePaint((java.awt.Paint) color68);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNull(paint54);
        org.junit.Assert.assertNotNull(shape64);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(color68);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(range74);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(stroke78);
        org.junit.Assert.assertNotNull(shape82);
        org.junit.Assert.assertNotNull(paint85);
        org.junit.Assert.assertNull(paint87);
        org.junit.Assert.assertNotNull(stroke94);
        org.junit.Assert.assertNotNull(color95);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
        org.junit.Assert.assertNotNull(color98);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.RANGE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint10 = barRenderer8.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer8.setSeriesURLGenerator(10, categoryURLGenerator12, true);
        boolean boolean15 = barRenderer8.getAutoPopulateSeriesStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace19 = color18.getColorSpace();
        categoryPlot17.setOutlinePaint((java.awt.Paint) color18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot17.setDomainAxis(categoryAxis21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", (org.jfree.chart.plot.Plot) categoryPlot17);
        boolean boolean24 = barRenderer8.hasListener((java.util.EventListener) jFreeChart23);
        float float25 = jFreeChart23.getBackgroundImageAlpha();
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart23);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo28);
        java.awt.geom.Rectangle2D rectangle2D30 = plotRenderingInfo29.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D31 = plotRenderingInfo29.getDataArea();
        java.awt.geom.Point2D point2D32 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        try {
            jFreeChart23.draw(graphics2D27, rectangle2D31, point2D32, chartRenderingInfo33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(colorSpace19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
        org.junit.Assert.assertNull(rectangle2D30);
        org.junit.Assert.assertNotNull(rectangle2D31);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace11 = color10.getColorSpace();
        categoryPlot9.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot9.setDomainAxis(categoryAxis13);
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", (org.jfree.chart.plot.Plot) categoryPlot9);
        boolean boolean16 = barRenderer0.hasListener((java.util.EventListener) jFreeChart15);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        try {
            java.awt.image.BufferedImage bufferedImage22 = jFreeChart15.createBufferedImage((int) (byte) 10, (int) (short) 0, (double) (-1.0f), (double) 1L, chartRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (10) and height (0) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(colorSpace11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.text.TextFragment textFragment1 = new org.jfree.chart.text.TextFragment("RectangleEdge.LEFT");
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        numberAxis1.setTickMarksVisible(false);
        boolean boolean5 = numberAxis1.isAutoRange();
        org.jfree.chart.event.AxisChangeListener axisChangeListener6 = null;
        numberAxis1.removeChangeListener(axisChangeListener6);
        java.awt.Font font8 = numberAxis1.getTickLabelFont();
        org.jfree.data.RangeType rangeType9 = org.jfree.data.RangeType.NEGATIVE;
        numberAxis1.setRangeType(rangeType9);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(rangeType9);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
        boolean boolean3 = numberTickUnit0.equals((java.lang.Object) categoryItemRendererState2);
        double double4 = categoryItemRendererState2.getBarWidth();
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        boolean boolean3 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge2);
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) 0L);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType5 = categoryLabelPosition4.getWidthType();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertNotNull(categoryLabelWidthType5);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        java.awt.Paint paint28 = legendItem27.getLinePaint();
        java.lang.Comparable comparable29 = legendItem27.getSeriesKey();
        java.lang.String str30 = legendItem27.getURLText();
        java.text.AttributedString attributedString31 = legendItem27.getAttributedLabel();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(comparable29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str30.equals("TextAnchor.BOTTOM_CENTER"));
        org.junit.Assert.assertNull(attributedString31);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double4 = numberAxis3.getLabelAngle();
        numberAxis3.setFixedDimension(0.0d);
        org.jfree.data.Range range7 = numberAxis3.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double10 = numberAxis9.getLabelAngle();
        numberAxis9.setFixedDimension(0.0d);
        org.jfree.data.Range range13 = numberAxis9.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double16 = numberAxis15.getLabelAngle();
        numberAxis15.setFixedDimension(0.0d);
        org.jfree.data.Range range19 = numberAxis15.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(range13, range19);
        java.lang.String str21 = range13.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint22 = new org.jfree.chart.block.RectangleConstraint(range7, range13);
        double double23 = range7.getLength();
        numberAxis1.setRange(range7);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "Range[0.0,1.0]" + "'", str21.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getDomainMarkers((-129), layer9);
        org.junit.Assert.assertNull(collection10);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = plotRenderingInfo1.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo1.getPlotArea();
        org.jfree.chart.renderer.RendererState rendererState4 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo1);
        org.junit.Assert.assertNull(rectangle2D2);
        org.junit.Assert.assertNull(rectangle2D3);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double8 = numberAxis7.getLabelAngle();
        numberAxis7.setFixedDimension(0.0d);
        org.jfree.data.Range range11 = numberAxis7.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range5, range11);
        double double13 = rectangleConstraint12.getHeight();
        java.lang.String str14 = rectangleConstraint12.toString();
        double double15 = rectangleConstraint12.getHeight();
        org.jfree.chart.text.TextBlock textBlock17 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke20 = barRenderer19.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        barRenderer19.notifyListeners(rendererChangeEvent21);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition23 = barRenderer19.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor24 = itemLabelPosition23.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick26 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock17, textBlockAnchor18, textAnchor24, 0.0d);
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.util.Size2D size2D28 = textBlock17.calculateDimensions(graphics2D27);
        size2D28.width = 2;
        size2D28.setHeight((double) 10L);
        org.jfree.chart.util.Size2D size2D33 = rectangleConstraint12.calculateConstrainedSize(size2D28);
        double double34 = size2D33.getHeight();
        double double35 = size2D33.width;
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str14.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(itemLabelPosition23);
        org.junit.Assert.assertNotNull(textAnchor24);
        org.junit.Assert.assertNotNull(size2D28);
        org.junit.Assert.assertNotNull(size2D33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke2 = barRenderer1.getBaseStroke();
        java.awt.Font font3 = barRenderer1.getBaseItemLabelFont();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean10 = color8.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color8);
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("{0}", font3, (java.awt.Paint) color8, (float) ' ');
        java.awt.Font font14 = textFragment13.getFont();
        java.lang.String str15 = textFragment13.getText();
        float float16 = textFragment13.getBaselineOffset();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{0}" + "'", str15.equals("{0}"));
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 32.0f + "'", float16 == 32.0f);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo0 = new org.jfree.chart.ui.BasicProjectInfo();
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        categoryPlot0.setDomainAxis(categoryAxis4);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        categoryPlot0.markerChanged(markerChangeEvent6);
        org.jfree.chart.axis.AxisSpace axisSpace8 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNull(axisSpace8);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer1.setSeriesURLGenerator(10, categoryURLGenerator5, true);
        boolean boolean8 = barRenderer1.getAutoPopulateSeriesStroke();
        java.awt.Paint paint10 = barRenderer1.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke12 = barRenderer11.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer11.notifyListeners(rendererChangeEvent13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer11.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape16 = barRenderer11.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity17 = new org.jfree.chart.entity.LegendItemEntity(shape16);
        barRenderer1.setBaseShape(shape16, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity22 = new org.jfree.chart.entity.TickLabelEntity(shape16, "java.awt.Color[r=128,g=128,b=0]", "");
        boolean boolean23 = categoryLabelPositions0.equals((java.lang.Object) "java.awt.Color[r=128,g=128,b=0]");
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint26 = barRenderer24.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator28 = null;
        barRenderer24.setSeriesURLGenerator(10, categoryURLGenerator28, true);
        boolean boolean31 = barRenderer24.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType33 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer24, jFreeChart32, chartChangeEventType33);
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint37 = barRenderer35.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator39 = null;
        barRenderer35.setSeriesURLGenerator(10, categoryURLGenerator39, true);
        boolean boolean42 = barRenderer35.getAutoPopulateSeriesStroke();
        java.awt.Paint paint44 = barRenderer35.lookupSeriesFillPaint(10);
        barRenderer24.setBaseFillPaint(paint44);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = null;
        barRenderer24.setBaseItemLabelGenerator(categoryItemLabelGenerator46, true);
        boolean boolean50 = barRenderer24.isSeriesVisible(15);
        boolean boolean51 = categoryLabelPositions0.equals((java.lang.Object) 15);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition53 = categoryLabelPositions0.getLabelPosition(rectangleEdge52);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType54 = categoryLabelPosition53.getWidthType();
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(categoryLabelPosition53);
        org.junit.Assert.assertNotNull(categoryLabelWidthType54);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        categoryPlot0.drawBackgroundImage(graphics2D3, rectangle2D7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint11 = barRenderer9.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        barRenderer9.setSeriesURLGenerator(10, categoryURLGenerator13, true);
        boolean boolean16 = barRenderer9.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer9.getPositiveItemLabelPositionFallback();
        java.awt.Shape shape19 = barRenderer9.lookupSeriesShape(10);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer9);
        double double21 = barRenderer9.getItemMargin();
        barRenderer9.setSeriesItemLabelsVisible((int) (byte) 1, (java.lang.Boolean) false, true);
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.2d + "'", double21 == 0.2d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("SortOrder.ASCENDING");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        java.awt.Font font6 = barRenderer4.getBaseItemLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("{0}", font6, (java.awt.Paint) color11, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("ThreadContext", font6);
        java.awt.Font font18 = labelBlock17.getFont();
        java.awt.Font font19 = labelBlock17.getFont();
        labelBlock1.setFont(font19);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        float float3 = numberAxis1.getTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = categoryPlot0.getDomainAxis();
        boolean boolean4 = categoryPlot0.isSubplot();
        org.junit.Assert.assertNull(categoryAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setTickMarkInsideLength((float) 15);
        double double13 = numberAxis1.getLabelAngle();
        numberAxis1.setAutoTickUnitSelection(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        barRenderer3.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock1, textBlockAnchor2, textAnchor8, 0.0d);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock1.calculateDimensions(graphics2D11);
        size2D12.width = 2;
        size2D12.setHeight((double) 10L);
        double double17 = size2D12.width;
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.0d + "'", double17 == 2.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        int int28 = legendItem27.getSeriesIndex();
        java.awt.Paint paint29 = legendItem27.getFillPaint();
        boolean boolean30 = legendItem27.isLineVisible();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer2.getBaseStroke();
        java.awt.Font font4 = barRenderer2.getBaseItemLabelFont();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("{0}", font4, (java.awt.Paint) color9, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("ThreadContext", font4);
        labelBlock15.setPadding((double) 'a', (double) '4', (double) 10, (-15361.0d));
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0, jFreeChart8, chartChangeEventType9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint13 = barRenderer11.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        barRenderer11.setSeriesURLGenerator(10, categoryURLGenerator15, true);
        boolean boolean18 = barRenderer11.getAutoPopulateSeriesStroke();
        java.awt.Paint paint20 = barRenderer11.lookupSeriesFillPaint(10);
        barRenderer0.setBaseFillPaint(paint20);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator22, true);
        boolean boolean26 = barRenderer0.isSeriesVisible(15);
        java.awt.Paint paint27 = barRenderer0.getBaseFillPaint();
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        java.awt.Color color38 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color40 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double43 = numberAxis42.getLabelAngle();
        numberAxis42.setFixedDimension(0.0d);
        org.jfree.data.Range range46 = numberAxis42.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent47 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis42);
        java.util.EventListener eventListener48 = null;
        boolean boolean49 = numberAxis42.hasListener(eventListener48);
        java.awt.Stroke stroke50 = numberAxis42.getTickMarkStroke();
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer55 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint57 = barRenderer55.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint59 = barRenderer55.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke61 = null;
        barRenderer55.setSeriesOutlineStroke(0, stroke61, true);
        java.awt.Stroke stroke66 = barRenderer55.getItemOutlineStroke((int) (byte) -1, 0);
        java.awt.Color color67 = java.awt.Color.CYAN;
        int int68 = color67.getRed();
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("{0}", "", "EXPAND", "hi!", false, shape36, true, (java.awt.Paint) color38, true, (java.awt.Paint) color40, stroke50, false, shape54, stroke66, (java.awt.Paint) color67);
        barRenderer0.setSeriesPaint(0, (java.awt.Paint) color67);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNull(paint59);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Paint paint4 = barRenderer0.getItemOutlinePaint(3, (int) (byte) 10);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator1 = barRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertNull(categoryURLGenerator1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        java.awt.Color color1 = java.awt.Color.getColor("LGPL");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        java.awt.Font font5 = barRenderer3.getBaseItemLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}", font5, (java.awt.Paint) color10, (float) ' ');
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        categoryPlot18.setOutlinePaint((java.awt.Paint) color19);
        java.awt.Paint paint22 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot18.rendererChanged(rendererChangeEvent23);
        categoryPlot18.setRangeCrosshairValue((double) 3, true);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font16, (org.jfree.chart.plot.Plot) categoryPlot18, false);
        jFreeChart29.setAntiAlias(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions32 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint35 = barRenderer33.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator37 = null;
        barRenderer33.setSeriesURLGenerator(10, categoryURLGenerator37, true);
        boolean boolean40 = barRenderer33.getAutoPopulateSeriesStroke();
        java.awt.Paint paint42 = barRenderer33.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke44 = barRenderer43.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent45 = null;
        barRenderer43.notifyListeners(rendererChangeEvent45);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition47 = barRenderer43.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape48 = barRenderer43.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity49 = new org.jfree.chart.entity.LegendItemEntity(shape48);
        barRenderer33.setBaseShape(shape48, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity54 = new org.jfree.chart.entity.TickLabelEntity(shape48, "java.awt.Color[r=128,g=128,b=0]", "");
        boolean boolean55 = categoryLabelPositions32.equals((java.lang.Object) "java.awt.Color[r=128,g=128,b=0]");
        org.jfree.chart.renderer.category.BarRenderer barRenderer56 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint58 = barRenderer56.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator60 = null;
        barRenderer56.setSeriesURLGenerator(10, categoryURLGenerator60, true);
        boolean boolean63 = barRenderer56.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart64 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType65 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent66 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer56, jFreeChart64, chartChangeEventType65);
        org.jfree.chart.renderer.category.BarRenderer barRenderer67 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint69 = barRenderer67.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator71 = null;
        barRenderer67.setSeriesURLGenerator(10, categoryURLGenerator71, true);
        boolean boolean74 = barRenderer67.getAutoPopulateSeriesStroke();
        java.awt.Paint paint76 = barRenderer67.lookupSeriesFillPaint(10);
        barRenderer56.setBaseFillPaint(paint76);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator78 = null;
        barRenderer56.setBaseItemLabelGenerator(categoryItemLabelGenerator78, true);
        boolean boolean82 = barRenderer56.isSeriesVisible(15);
        boolean boolean83 = categoryLabelPositions32.equals((java.lang.Object) 15);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition84 = new org.jfree.chart.axis.CategoryLabelPosition();
        float float85 = categoryLabelPosition84.getWidthRatio();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor86 = categoryLabelPosition84.getCategoryAnchor();
        float float87 = categoryLabelPosition84.getWidthRatio();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions88 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions32, categoryLabelPosition84);
        try {
            jFreeChart29.setTextAntiAlias((java.lang.Object) categoryLabelPositions32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: org.jfree.chart.axis.CategoryLabelPositions@1e7ff5c2 incompatible with Text-specific antialiasing enable key");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(categoryLabelPositions32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNotNull(itemLabelPosition47);
        org.junit.Assert.assertNotNull(shape48);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType65);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(paint76);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + true + "'", boolean82 == true);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + float85 + "' != '" + 0.95f + "'", float85 == 0.95f);
        org.junit.Assert.assertNotNull(rectangleAnchor86);
        org.junit.Assert.assertTrue("'" + float87 + "' != '" + 0.95f + "'", float87 == 0.95f);
        org.junit.Assert.assertNotNull(categoryLabelPositions88);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        java.awt.Paint paint28 = legendItem27.getLinePaint();
        java.awt.Shape shape29 = legendItem27.getShape();
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape29);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(shape29);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        java.awt.Font font6 = barRenderer4.getBaseItemLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("{0}", font6, (java.awt.Paint) color11, (float) ' ');
        numberAxis1.setLabelFont(font6);
        numberAxis1.setLowerBound(1.0E-8d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener20 = null;
        numberAxis1.removeChangeListener(axisChangeListener20);
        numberAxis1.setRangeWithMargins(0.0d, (double) 1);
        numberAxis1.resizeRange((double) 1L, Double.NaN);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        categoryPlot1.setOutlinePaint((java.awt.Paint) color2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot1.setDomainAxis(categoryAxis5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent8 = null;
        try {
            categoryPlot1.notifyListeners(plotChangeEvent8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        numberAxis1.setTickMarksVisible(false);
        boolean boolean5 = numberAxis1.isAutoRange();
        org.jfree.chart.event.AxisChangeListener axisChangeListener6 = null;
        numberAxis1.removeChangeListener(axisChangeListener6);
        java.awt.Font font8 = numberAxis1.getTickLabelFont();
        boolean boolean9 = numberAxis1.isPositiveArrowVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape5 = barRenderer0.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.chart.block.BlockBorder blockBorder7 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean8 = legendItemEntity6.equals((java.lang.Object) blockBorder7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isTickLabelsVisible();
        numberAxis10.setAutoRange(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = numberAxis10.getTickUnit();
        legendItemEntity6.setSeriesKey((java.lang.Comparable) numberTickUnit14);
        java.lang.String str16 = legendItemEntity6.getShapeCoords();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(blockBorder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "-3,-3,3,3" + "'", str16.equals("-3,-3,3,3"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        java.lang.Object obj0 = null;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'object' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        categoryPlot0.configureDomainAxes();
        int int8 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets();
        categoryPlot0.setInsets(rectangleInsets9);
        double double12 = rectangleInsets9.calculateLeftInset((double) (short) 1);
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        double double3 = barRenderer0.getMaximumBarWidth();
        barRenderer0.setSeriesItemLabelsVisible((int) (short) 0, true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = barRenderer0.getItemLabelGenerator((int) (byte) 0, (int) '4');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Color color7 = java.awt.Color.CYAN;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color7, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image11 = null;
        categoryPlot10.setBackgroundImage(image11);
        categoryPlot10.clearDomainAxes();
        org.jfree.chart.plot.Plot plot14 = categoryPlot10.getRootPlot();
        barRenderer0.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(plot14);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        java.awt.Font font5 = barRenderer3.getBaseItemLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}", font5, (java.awt.Paint) color10, (float) ' ');
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        categoryPlot18.setOutlinePaint((java.awt.Paint) color19);
        java.awt.Paint paint22 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot18.rendererChanged(rendererChangeEvent23);
        categoryPlot18.setRangeCrosshairValue((double) 3, true);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font16, (org.jfree.chart.plot.Plot) categoryPlot18, false);
        org.jfree.chart.event.ChartChangeListener chartChangeListener30 = null;
        try {
            jFreeChart29.addChangeListener(chartChangeListener30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("VerticalAlignment.CENTER");
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        java.awt.Color color1 = java.awt.Color.getColor("HorizontalAlignment.CENTER");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        boolean boolean7 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot0.getAxisOffset();
        boolean boolean9 = categoryPlot0.isOutlineVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, (double) (byte) 0);
        java.util.EventListener eventListener5 = null;
        boolean boolean6 = defaultStatisticalCategoryDataset1.hasListener(eventListener5);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, (java.lang.Comparable) 100.0f);
        org.jfree.data.general.PieDataset pieDataset10 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, (int) ' ');
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 0.2d, (org.jfree.data.KeyedValues) pieDataset10);
        org.junit.Assert.assertEquals((double) number2, Double.NaN, 0);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertNotNull(pieDataset10);
        org.junit.Assert.assertNotNull(categoryDataset11);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.LegendItem legendItem12 = barRenderer0.getLegendItem((int) ' ', 1);
        java.lang.Boolean boolean14 = barRenderer0.getSeriesItemLabelsVisible((int) (byte) 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItem12);
        org.junit.Assert.assertNull(boolean14);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double5 = numberAxis4.getLabelAngle();
        numberAxis4.setFixedDimension(0.0d);
        org.jfree.data.Range range8 = numberAxis4.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis4);
        java.util.EventListener eventListener10 = null;
        boolean boolean11 = numberAxis4.hasListener(eventListener10);
        java.awt.Stroke stroke12 = numberAxis4.getTickMarkStroke();
        org.jfree.data.Range range13 = numberAxis4.getRange();
        boolean boolean16 = range13.intersects((double) 2, (double) '#');
        numberAxis1.setRangeWithMargins(range13, false, true);
        boolean boolean20 = numberAxis1.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image23 = null;
        categoryPlot22.setBackgroundImage(image23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        java.awt.geom.Rectangle2D rectangle2D28 = plotRenderingInfo27.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D29 = plotRenderingInfo27.getDataArea();
        categoryPlot22.drawBackgroundImage(graphics2D25, rectangle2D29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge31);
        double double33 = numberAxis1.valueToJava2D((double) 0.5f, rectangle2D29, rectangleEdge31);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand34 = null;
        numberAxis1.setMarkerBand(markerAxisBand34);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        java.awt.Font font5 = barRenderer3.getBaseItemLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}", font5, (java.awt.Paint) color10, (float) ' ');
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        categoryPlot18.setOutlinePaint((java.awt.Paint) color19);
        java.awt.Paint paint22 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot18.rendererChanged(rendererChangeEvent23);
        categoryPlot18.setRangeCrosshairValue((double) 3, true);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font16, (org.jfree.chart.plot.Plot) categoryPlot18, false);
        jFreeChart29.setTextAntiAlias(false);
        boolean boolean32 = jFreeChart29.getAntiAlias();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        categoryPlot0.setDomainAxis(categoryAxis4);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        categoryPlot0.markerChanged(markerChangeEvent6);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint10 = barRenderer8.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint13 = barRenderer11.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint15 = barRenderer11.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke17 = null;
        barRenderer11.setSeriesOutlineStroke(0, stroke17, true);
        java.awt.Stroke stroke22 = barRenderer11.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer8.setBaseStroke(stroke22);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke27 = barRenderer26.getBaseStroke();
        java.awt.Font font28 = barRenderer26.getBaseItemLabelFont();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean35 = color33.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder36 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color33);
        org.jfree.chart.text.TextFragment textFragment38 = new org.jfree.chart.text.TextFragment("{0}", font28, (java.awt.Paint) color33, (float) ' ');
        java.awt.image.ColorModel colorModel39 = null;
        java.awt.Rectangle rectangle40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        java.awt.geom.AffineTransform affineTransform42 = null;
        java.awt.RenderingHints renderingHints43 = null;
        java.awt.PaintContext paintContext44 = color33.createContext(colorModel39, rectangle40, rectangle2D41, affineTransform42, renderingHints43);
        barRenderer8.setSeriesPaint(0, (java.awt.Paint) color33);
        barRenderer8.setBaseSeriesVisible(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer48 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition50 = barRenderer48.getSeriesNegativeItemLabelPosition((int) (short) -1);
        barRenderer8.setPositiveItemLabelPositionFallback(itemLabelPosition50);
        int int52 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer8);
        java.awt.Paint paint53 = barRenderer8.getBasePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(paintContext44);
        org.junit.Assert.assertNotNull(itemLabelPosition50);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(paint53);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        double double2 = categoryAxis1.getCategoryMargin();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) ' ');
        categoryAxis1.setCategoryMargin(15.0d);
        java.lang.Object obj7 = categoryAxis1.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(obj7);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = barRenderer0.getBaseURLGenerator();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNull(categoryURLGenerator5);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        java.lang.Object obj1 = tickUnits0.clone();
        try {
            org.jfree.chart.axis.TickUnit tickUnit3 = tickUnits0.getCeilingTickUnit((double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createUpRotationLabelPositions(0.05d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        java.awt.Font font6 = barRenderer4.getBaseItemLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("{0}", font6, (java.awt.Paint) color11, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("ThreadContext", font6);
        java.awt.Paint paint18 = labelBlock17.getPaint();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition19 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean20 = labelBlock17.equals((java.lang.Object) categoryLabelPosition19);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions1, categoryLabelPosition19);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(categoryLabelPositions21);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setRight((double) '#');
        axisSpace0.setLeft((double) 10L);
        axisSpace0.setBottom((double) (-129));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        java.awt.Font font5 = barRenderer3.getBaseItemLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}", font5, (java.awt.Paint) color10, (float) ' ');
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        categoryPlot18.setOutlinePaint((java.awt.Paint) color19);
        java.awt.Paint paint22 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot18.rendererChanged(rendererChangeEvent23);
        categoryPlot18.setRangeCrosshairValue((double) 3, true);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font16, (org.jfree.chart.plot.Plot) categoryPlot18, false);
        int int30 = jFreeChart29.getBackgroundImageAlignment();
        jFreeChart29.setBorderVisible(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener33 = null;
        jFreeChart29.removeProgressListener(chartProgressListener33);
        java.awt.Paint paint35 = jFreeChart29.getBorderPaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        categoryPlot0.configureDomainAxes();
        boolean boolean8 = categoryPlot0.isSubplot();
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color16 = java.awt.Color.CYAN;
        java.awt.Color color17 = java.awt.Color.CYAN;
        java.awt.Color color18 = java.awt.Color.red;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color10, color14, color15, color16, color17, color18 };
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color20 };
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke23 = null;
        java.awt.Stroke[] strokeArray24 = new java.awt.Stroke[] { stroke23 };
        java.awt.Shape shape25 = null;
        java.awt.Shape[] shapeArray26 = new java.awt.Shape[] { shape25 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray21, strokeArray22, strokeArray24, shapeArray26);
        java.awt.Paint paint28 = defaultDrawingSupplier27.getNextPaint();
        barRenderer0.setSeriesOutlinePaint(0, paint28, false);
        int int31 = barRenderer0.getPassCount();
        boolean boolean34 = barRenderer0.getItemVisible(2, (int) (byte) 0);
        int int35 = barRenderer0.getRowCount();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator36 = null;
        barRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator36);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(shapeArray26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        categoryPlot1.setOutlinePaint((java.awt.Paint) color2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot1.setDomainAxis(categoryAxis5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", (org.jfree.chart.plot.Plot) categoryPlot1);
        jFreeChart7.fireChartChanged();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double12 = numberAxis11.getLabelAngle();
        numberAxis11.setFixedDimension(0.0d);
        org.jfree.data.Range range15 = numberAxis11.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis11);
        numberAxis11.setUpperBound((double) '4');
        numberAxis11.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.axis.AxisState axisState23 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = null;
        java.util.List list26 = numberAxis11.refreshTicks(graphics2D21, axisState23, rectangle2D24, rectangleEdge25);
        boolean boolean27 = numberAxis11.isVerticalTickLabels();
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean31 = numberAxis30.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double34 = numberAxis33.getLabelAngle();
        numberAxis33.setFixedDimension(0.0d);
        org.jfree.data.Range range37 = numberAxis33.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent38 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis33);
        java.util.EventListener eventListener39 = null;
        boolean boolean40 = numberAxis33.hasListener(eventListener39);
        java.awt.Stroke stroke41 = numberAxis33.getTickMarkStroke();
        org.jfree.data.Range range42 = numberAxis33.getRange();
        boolean boolean45 = range42.intersects((double) 2, (double) '#');
        numberAxis30.setRangeWithMargins(range42, false, true);
        boolean boolean49 = numberAxis30.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image52 = null;
        categoryPlot51.setBackgroundImage(image52);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo55);
        java.awt.geom.Rectangle2D rectangle2D57 = plotRenderingInfo56.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D58 = plotRenderingInfo56.getDataArea();
        categoryPlot51.drawBackgroundImage(graphics2D54, rectangle2D58);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge60);
        double double62 = numberAxis30.valueToJava2D((double) 0.5f, rectangle2D58, rectangleEdge60);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = null;
        double double64 = numberAxis11.valueToJava2D(0.0d, rectangle2D58, rectangleEdge63);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo65 = null;
        try {
            jFreeChart7.draw(graphics2D9, rectangle2D58, chartRenderingInfo65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(list26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape5 = barRenderer0.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.chart.block.BlockBorder blockBorder7 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean8 = legendItemEntity6.equals((java.lang.Object) blockBorder7);
        java.awt.Shape shape9 = legendItemEntity6.getArea();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator10 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator11 = null;
        java.lang.String str12 = legendItemEntity6.getImageMapAreaTag(toolTipTagFragmentGenerator10, uRLTagFragmentGenerator11);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(blockBorder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean8 = color6.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder9 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color6);
        java.awt.Color color10 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color11 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color12 = java.awt.Color.CYAN;
        java.awt.Color color13 = java.awt.Color.CYAN;
        java.awt.Color color14 = java.awt.Color.red;
        java.awt.Paint[] paintArray15 = new java.awt.Paint[] { color6, color10, color11, color12, color13, color14 };
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint[] paintArray17 = new java.awt.Paint[] { color16 };
        java.awt.Stroke[] strokeArray18 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke19 = null;
        java.awt.Stroke[] strokeArray20 = new java.awt.Stroke[] { stroke19 };
        java.awt.Shape shape21 = null;
        java.awt.Shape[] shapeArray22 = new java.awt.Shape[] { shape21 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier23 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray15, paintArray17, strokeArray18, strokeArray20, shapeArray22);
        keyedObjects0.addObject((java.lang.Comparable) "", (java.lang.Object) paintArray15);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(paintArray17);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(strokeArray20);
        org.junit.Assert.assertNotNull(shapeArray22);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=255,g=255,b=0]");
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0, jFreeChart8, chartChangeEventType9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean13 = numberAxis12.isTickLabelsVisible();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double16 = numberAxis15.getLabelAngle();
        numberAxis15.setFixedDimension(0.0d);
        org.jfree.data.Range range19 = numberAxis15.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double22 = numberAxis21.getLabelAngle();
        numberAxis21.setFixedDimension(0.0d);
        org.jfree.data.Range range25 = numberAxis21.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(range19, range25);
        numberAxis12.setRangeWithMargins(range19);
        boolean boolean28 = chartChangeEventType9.equals((java.lang.Object) numberAxis12);
        java.awt.Paint paint29 = numberAxis12.getAxisLinePaint();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double32 = numberAxis31.getLabelAngle();
        numberAxis31.setFixedDimension(0.0d);
        org.jfree.data.Range range35 = numberAxis31.getRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = numberAxis31.getTickLabelInsets();
        numberAxis12.setTickLabelInsets(rectangleInsets36);
        double double39 = rectangleInsets36.calculateLeftInset(0.0d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 4.0d + "'", double39 == 4.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1L));
        org.jfree.data.general.PieDataset pieDataset6 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, 0);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset6, (java.lang.Comparable) 0.2d, (double) (short) 1);
        org.jfree.data.general.PieDataset pieDataset13 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset6, (java.lang.Comparable) "RectangleConstraintType.RANGE", 0.0d, (int) 'a');
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNotNull(pieDataset6);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNotNull(pieDataset13);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setRight((double) '#');
        axisSpace0.setRight((double) (short) -1);
        axisSpace0.setRight((double) 1.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo7);
        java.awt.geom.Rectangle2D rectangle2D9 = plotRenderingInfo8.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D10 = plotRenderingInfo8.getDataArea();
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean13 = numberAxis12.isTickLabelsVisible();
        numberAxis12.setAutoRange(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis12.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean20 = numberAxis19.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double23 = numberAxis22.getLabelAngle();
        numberAxis22.setFixedDimension(0.0d);
        org.jfree.data.Range range26 = numberAxis22.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis22);
        java.util.EventListener eventListener28 = null;
        boolean boolean29 = numberAxis22.hasListener(eventListener28);
        java.awt.Stroke stroke30 = numberAxis22.getTickMarkStroke();
        org.jfree.data.Range range31 = numberAxis22.getRange();
        boolean boolean34 = range31.intersects((double) 2, (double) '#');
        numberAxis19.setRangeWithMargins(range31, false, true);
        boolean boolean38 = numberAxis19.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image41 = null;
        categoryPlot40.setBackgroundImage(image41);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo44);
        java.awt.geom.Rectangle2D rectangle2D46 = plotRenderingInfo45.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D47 = plotRenderingInfo45.getDataArea();
        categoryPlot40.drawBackgroundImage(graphics2D43, rectangle2D47);
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge49);
        double double51 = numberAxis19.valueToJava2D((double) 0.5f, rectangle2D47, rectangleEdge49);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str53 = rectangleEdge52.toString();
        double double54 = numberAxis12.lengthToJava2D((double) 2, rectangle2D47, rectangleEdge52);
        java.awt.geom.Rectangle2D rectangle2D55 = axisSpace0.expand(rectangle2D10, rectangle2D47);
        axisSpace0.setRight(0.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge59 = null;
        try {
            axisSpace0.add((double) 0.5f, rectangleEdge59);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'edge' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(rectangle2D9);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "RectangleEdge.LEFT" + "'", str53.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D55);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        java.awt.Paint paint6 = barRenderer0.getItemOutlinePaint(0, 15);
        barRenderer0.setBaseCreateEntities(false, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator10 = barRenderer0.getBaseToolTipGenerator();
        barRenderer0.setMaximumBarWidth((double) 1);
        java.awt.Color color13 = java.awt.Color.YELLOW;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color13);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNull(categoryToolTipGenerator10);
        org.junit.Assert.assertNotNull(color13);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        numberAxis1.setTickMarksVisible(false);
        boolean boolean5 = numberAxis1.isAutoRange();
        org.jfree.chart.event.AxisChangeListener axisChangeListener6 = null;
        numberAxis1.removeChangeListener(axisChangeListener6);
        numberAxis1.setAutoTickUnitSelection(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape5 = barRenderer0.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        legendItemEntity6.setToolTipText("PlotOrientation.VERTICAL");
        java.lang.String str9 = legendItemEntity6.getShapeCoords();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "-3,-3,3,3" + "'", str9.equals("-3,-3,3,3"));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType6 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor5, categoryLabelWidthType6, (float) 0L);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor9 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        boolean boolean10 = rectangleAnchor4.equals((java.lang.Object) textBlockAnchor9);
        java.lang.String str11 = rectangleAnchor4.toString();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke14 = barRenderer13.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        barRenderer13.notifyListeners(rendererChangeEvent15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer13.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor18 = itemLabelPosition17.getTextAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType20 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition22 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor12, textAnchor18, (double) 0.95f, categoryLabelWidthType20, (float) ' ');
        try {
            java.awt.geom.Rectangle2D rectangle2D23 = org.jfree.chart.text.TextUtilities.drawAlignedString("EXPAND", graphics2D1, (float) 10L, 32.0f, textAnchor18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(categoryLabelWidthType6);
        org.junit.Assert.assertNotNull(textBlockAnchor9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str11.equals("RectangleAnchor.BOTTOM"));
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(textAnchor18);
        org.junit.Assert.assertNotNull(categoryLabelWidthType20);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1L));
        java.lang.Number number7 = defaultStatisticalCategoryDataset0.getStdDevValue((java.lang.Comparable) (-15423), (java.lang.Comparable) "PlotOrientation.VERTICAL");
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertNull(number7);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) "{0}");
        java.lang.String str4 = textAnchor1.toString();
        boolean boolean5 = keyedObjects0.equals((java.lang.Object) str4);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean9 = numberAxis8.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke12 = barRenderer11.getBaseStroke();
        java.awt.Font font13 = barRenderer11.getBaseItemLabelFont();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean20 = color18.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color18);
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("{0}", font13, (java.awt.Paint) color18, (float) ' ');
        numberAxis8.setLabelFont(font13);
        numberAxis8.setLabelToolTip("");
        org.jfree.data.Range range27 = numberAxis8.getRange();
        keyedObjects0.setObject((java.lang.Comparable) "RectangleEdge.LEFT", (java.lang.Object) range27);
        java.lang.Object obj30 = keyedObjects0.getObject((java.lang.Comparable) "Range[0.0,1.0]");
        int int31 = keyedObjects0.getItemCount();
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str4.equals("TextAnchor.BOTTOM_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNull(obj30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (double) (byte) 0);
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = defaultStatisticalCategoryDataset0.hasListener(eventListener4);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 100.0f);
        int int9 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) 0);
        double double11 = defaultStatisticalCategoryDataset0.getRangeUpperBound(true);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertEquals((double) double11, Double.NaN, 0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Paint paint5 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke7 = barRenderer6.getBaseStroke();
        java.awt.Font font8 = barRenderer6.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator11 = barRenderer6.getItemLabelGenerator((int) (byte) 0, (int) '4');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer6.getBaseNegativeItemLabelPosition();
        barRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition12);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNull(categoryItemLabelGenerator11);
        org.junit.Assert.assertNotNull(itemLabelPosition12);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape5 = barRenderer0.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.chart.block.BlockBorder blockBorder7 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean8 = legendItemEntity6.equals((java.lang.Object) blockBorder7);
        legendItemEntity6.setToolTipText("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(blockBorder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean6 = color4.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color4);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color10 = java.awt.Color.CYAN;
        java.awt.Color color11 = java.awt.Color.CYAN;
        java.awt.Color color12 = java.awt.Color.red;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color4, color8, color9, color10, color11, color12 };
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint[] paintArray15 = new java.awt.Paint[] { color14 };
        java.awt.Stroke[] strokeArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke17 = null;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke17 };
        java.awt.Shape shape19 = null;
        java.awt.Shape[] shapeArray20 = new java.awt.Shape[] { shape19 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray13, paintArray15, strokeArray16, strokeArray18, shapeArray20);
        java.awt.Paint paint22 = defaultDrawingSupplier21.getNextPaint();
        java.awt.Stroke stroke23 = defaultDrawingSupplier21.getNextStroke();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset7 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7);
        java.util.EventListener eventListener9 = null;
        boolean boolean10 = defaultStatisticalCategoryDataset7.hasListener(eventListener9);
        int int11 = defaultStatisticalCategoryDataset7.getRowCount();
        categoryPlot0.setDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset7);
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertEquals((double) number8, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint((int) '4');
        java.awt.Color color4 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        try {
            paintList0.setPaint((-1), (java.awt.Paint) color4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color30);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double45 = numberAxis44.getLabelAngle();
        numberAxis44.setFixedDimension(0.0d);
        org.jfree.data.Range range48 = numberAxis44.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent49 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis44);
        java.awt.Shape shape50 = numberAxis44.getRightArrow();
        legendGraphic42.setLine(shape50);
        legendGraphic42.setWidth(0.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer54 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint56 = barRenderer54.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer57 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint59 = barRenderer57.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint61 = barRenderer57.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke63 = null;
        barRenderer57.setSeriesOutlineStroke(0, stroke63, true);
        java.awt.Stroke stroke68 = barRenderer57.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer54.setBaseStroke(stroke68);
        legendGraphic42.setOutlineStroke(stroke68);
        java.awt.Stroke stroke71 = legendGraphic42.getLineStroke();
        java.awt.Shape shape72 = null;
        legendGraphic42.setLine(shape72);
        boolean boolean74 = legendGraphic42.isLineVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNull(paint61);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNull(stroke71);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot0.setDomainAxis(1, categoryAxis9, false);
        java.util.List list12 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        java.awt.Color color4 = java.awt.Color.pink;
        org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder((double) 0.0f, (double) 32.0f, (double) (-15423), 0.0d, (java.awt.Paint) color4);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) "{0}");
        java.lang.String str4 = textAnchor1.toString();
        boolean boolean5 = keyedObjects0.equals((java.lang.Object) str4);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean9 = numberAxis8.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke12 = barRenderer11.getBaseStroke();
        java.awt.Font font13 = barRenderer11.getBaseItemLabelFont();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean20 = color18.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color18);
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("{0}", font13, (java.awt.Paint) color18, (float) ' ');
        numberAxis8.setLabelFont(font13);
        numberAxis8.setLabelToolTip("");
        org.jfree.data.Range range27 = numberAxis8.getRange();
        keyedObjects0.setObject((java.lang.Comparable) "RectangleEdge.LEFT", (java.lang.Object) range27);
        org.jfree.chart.text.TextBlock textBlock30 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor31 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke33 = barRenderer32.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        barRenderer32.notifyListeners(rendererChangeEvent34);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = barRenderer32.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor37 = itemLabelPosition36.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick39 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock30, textBlockAnchor31, textAnchor37, 0.0d);
        org.jfree.chart.text.TextAnchor textAnchor40 = categoryTick39.getTextAnchor();
        boolean boolean41 = keyedObjects0.equals((java.lang.Object) textAnchor40);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str4.equals("TextAnchor.BOTTOM_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(textBlockAnchor31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
        org.junit.Assert.assertNotNull(textAnchor37);
        org.junit.Assert.assertNotNull(textAnchor40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        java.awt.Font font6 = barRenderer4.getBaseItemLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("{0}", font6, (java.awt.Paint) color11, (float) ' ');
        numberAxis1.setLabelFont(font6);
        numberAxis1.setLabelToolTip("");
        org.jfree.data.Range range20 = numberAxis1.getRange();
        java.awt.Shape shape21 = numberAxis1.getDownArrow();
        numberAxis1.setFixedDimension(0.0d);
        numberAxis1.zoomRange(0.05d, (double) 0.5f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = categoryPlot0.getDomainGridlinePosition();
        int int8 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot0.getRangeAxis(8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        categoryPlot0.setOutlinePaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke8 = barRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.lang.Boolean boolean11 = barRenderer0.getSeriesCreateEntities(100);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNull(boolean11);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        int int28 = legendItem27.getSeriesIndex();
        java.awt.Paint paint29 = legendItem27.getFillPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint32 = barRenderer30.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint34 = barRenderer30.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke36 = null;
        barRenderer30.setSeriesOutlineStroke(0, stroke36, true);
        java.awt.Stroke stroke41 = barRenderer30.getItemOutlineStroke((int) (byte) -1, 0);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = null;
        try {
            org.jfree.chart.block.LineBorder lineBorder43 = new org.jfree.chart.block.LineBorder(paint29, stroke41, rectangleInsets42);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Paint paint5 = barRenderer0.getSeriesFillPaint((int) (short) 0);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getItemLabelPadding();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo8 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo8);
        java.awt.geom.Rectangle2D rectangle2D10 = plotRenderingInfo9.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo9.getDataArea();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition12 = new org.jfree.chart.axis.CategoryLabelPosition();
        float float13 = categoryLabelPosition12.getWidthRatio();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = categoryLabelPosition12.getCategoryAnchor();
        java.awt.geom.Point2D point2D15 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D11, rectangleAnchor14);
        legendTitle6.setLegendItemGraphicAnchor(rectangleAnchor14);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNull(rectangle2D10);
        org.junit.Assert.assertNotNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.95f + "'", float13 == 0.95f);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(point2D15);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer2.getBaseStroke();
        java.awt.Font font4 = barRenderer2.getBaseItemLabelFont();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("{0}", font4, (java.awt.Paint) color9, (float) ' ');
        java.awt.Font font15 = textFragment14.getFont();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge17);
        textTitle16.setPosition(rectangleEdge19);
        java.lang.String str21 = textTitle16.getURLText();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean24 = numberAxis23.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double27 = numberAxis26.getLabelAngle();
        numberAxis26.setFixedDimension(0.0d);
        org.jfree.data.Range range30 = numberAxis26.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent31 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis26);
        java.util.EventListener eventListener32 = null;
        boolean boolean33 = numberAxis26.hasListener(eventListener32);
        java.awt.Stroke stroke34 = numberAxis26.getTickMarkStroke();
        org.jfree.data.Range range35 = numberAxis26.getRange();
        boolean boolean38 = range35.intersects((double) 2, (double) '#');
        numberAxis23.setRangeWithMargins(range35, false, true);
        boolean boolean42 = numberAxis23.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image45 = null;
        categoryPlot44.setBackgroundImage(image45);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo48);
        java.awt.geom.Rectangle2D rectangle2D50 = plotRenderingInfo49.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D51 = plotRenderingInfo49.getDataArea();
        categoryPlot44.drawBackgroundImage(graphics2D47, rectangle2D51);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge53);
        double double55 = numberAxis23.valueToJava2D((double) 0.5f, rectangle2D51, rectangleEdge53);
        textTitle16.setBounds(rectangle2D51);
        org.jfree.chart.util.RectangleInsets rectangleInsets57 = textTitle16.getPadding();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets57);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis1.refreshTicks(graphics2D11, axisState13, rectangle2D14, rectangleEdge15);
        org.jfree.chart.util.UnitType unitType17 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean18 = numberAxis1.equals((java.lang.Object) unitType17);
        numberAxis1.setInverted(true);
        java.text.NumberFormat numberFormat21 = null;
        numberAxis1.setNumberFormatOverride(numberFormat21);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        java.lang.Number[] numberArray5 = new java.lang.Number[] { 2.0f };
        java.lang.Number[] numberArray7 = new java.lang.Number[] { 2.0f };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 2.0f };
        java.lang.Number[][] numberArray10 = new java.lang.Number[][] { numberArray5, numberArray7, numberArray9 };
        org.jfree.data.category.CategoryDataset categoryDataset11 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("TextAnchor.BOTTOM_CENTER", "Range[0.0,1.0]", numberArray10);
        org.jfree.data.category.CategoryDataset categoryDataset12 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("EXPAND", "LegendItemEntity: seriesKey=null, dataset=null", numberArray10);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray10);
        org.junit.Assert.assertNotNull(categoryDataset11);
        org.junit.Assert.assertNotNull(categoryDataset12);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 10.0f, (java.lang.Number) (short) 0);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, true);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (int) '#');
        boolean boolean9 = meanAndStandardDeviation2.equals((java.lang.Object) pieDataset8);
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        numberAxis1.setTickMarksVisible(false);
        boolean boolean5 = numberAxis1.isAutoRange();
        java.awt.Paint paint6 = numberAxis1.getTickLabelPaint();
        java.awt.Font font7 = numberAxis1.getTickLabelFont();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(font7);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        org.jfree.chart.plot.ValueMarker valueMarker8 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke14 = barRenderer13.getBaseStroke();
        java.awt.Font font15 = barRenderer13.getBaseItemLabelFont();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean22 = color20.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder23 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color20);
        org.jfree.chart.text.TextFragment textFragment25 = new org.jfree.chart.text.TextFragment("{0}", font15, (java.awt.Paint) color20, (float) ' ');
        numberAxis10.setLabelFont(font15);
        valueMarker8.setLabelFont(font15);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image29 = null;
        categoryPlot28.setBackgroundImage(image29);
        categoryPlot28.clearDomainAxes();
        org.jfree.chart.plot.Plot plot32 = categoryPlot28.getRootPlot();
        valueMarker8.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) plot32);
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        java.awt.geom.Rectangle2D rectangle2D38 = plotRenderingInfo37.getPlotArea();
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot34.zoomDomainAxes(0.05d, plotRenderingInfo37, point2D39);
        org.jfree.chart.renderer.category.BarRenderer barRenderer41 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint43 = null;
        barRenderer41.setSeriesFillPaint((int) '#', paint43, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = null;
        barRenderer41.setSeriesURLGenerator(0, categoryURLGenerator47, true);
        int int50 = categoryPlot34.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer41);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder51 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str52 = datasetRenderingOrder51.toString();
        categoryPlot34.setDatasetRenderingOrder(datasetRenderingOrder51);
        valueMarker8.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot34);
        org.jfree.chart.util.Layer layer55 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker8, layer55);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(plot32);
        org.junit.Assert.assertNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1) + "'", int50 == (-1));
        org.junit.Assert.assertNotNull(datasetRenderingOrder51);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str52.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("Size2D[width=15.0, height=0.0]");
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("SortOrder.ASCENDING");
        labelBlock1.setPadding((double) (byte) 0, (double) 1, (double) 100.0f, 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = null;
        barRenderer7.setSeriesFillPaint((int) '#', paint9, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        barRenderer7.setSeriesURLGenerator(0, categoryURLGenerator13, true);
        int int16 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = new org.jfree.chart.labels.ItemLabelPosition();
        barRenderer7.setPositiveItemLabelPositionFallback(itemLabelPosition17);
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Paint paint5 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.Marker marker9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        barRenderer0.drawRangeMarker(graphics2D6, categoryPlot7, valueAxis8, marker9, rectangle2D10);
        barRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer2.getBaseStroke();
        java.awt.Font font4 = barRenderer2.getBaseItemLabelFont();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("{0}", font4, (java.awt.Paint) color9, (float) ' ');
        java.awt.Font font15 = textFragment14.getFont();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge17);
        textTitle16.setPosition(rectangleEdge19);
        java.lang.String str21 = textTitle16.getURLText();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean24 = numberAxis23.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double27 = numberAxis26.getLabelAngle();
        numberAxis26.setFixedDimension(0.0d);
        org.jfree.data.Range range30 = numberAxis26.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent31 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis26);
        java.util.EventListener eventListener32 = null;
        boolean boolean33 = numberAxis26.hasListener(eventListener32);
        java.awt.Stroke stroke34 = numberAxis26.getTickMarkStroke();
        org.jfree.data.Range range35 = numberAxis26.getRange();
        boolean boolean38 = range35.intersects((double) 2, (double) '#');
        numberAxis23.setRangeWithMargins(range35, false, true);
        boolean boolean42 = numberAxis23.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image45 = null;
        categoryPlot44.setBackgroundImage(image45);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo48);
        java.awt.geom.Rectangle2D rectangle2D50 = plotRenderingInfo49.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D51 = plotRenderingInfo49.getDataArea();
        categoryPlot44.drawBackgroundImage(graphics2D47, rectangle2D51);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge53);
        double double55 = numberAxis23.valueToJava2D((double) 0.5f, rectangle2D51, rectangleEdge53);
        textTitle16.setBounds(rectangle2D51);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment57 = textTitle16.getTextAlignment();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment57);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0, jFreeChart8, chartChangeEventType9);
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 10, (java.lang.Boolean) true, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer0.getPositiveItemLabelPosition((int) (short) 100, 10);
        org.jfree.chart.text.TextAnchor textAnchor18 = itemLabelPosition17.getRotationAnchor();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(textAnchor18);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double8 = numberAxis7.getLabelAngle();
        numberAxis7.setFixedDimension(0.0d);
        org.jfree.data.Range range11 = numberAxis7.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range5, range11);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = rectangleConstraint12.toFixedWidth((double) (-8355840));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(rectangleConstraint14);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        barRenderer3.setSeriesURLGenerator(10, categoryURLGenerator7, true);
        boolean boolean10 = barRenderer3.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType12 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent13 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer3, jFreeChart11, chartChangeEventType12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean16 = numberAxis15.isTickLabelsVisible();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double19 = numberAxis18.getLabelAngle();
        numberAxis18.setFixedDimension(0.0d);
        org.jfree.data.Range range22 = numberAxis18.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double25 = numberAxis24.getLabelAngle();
        numberAxis24.setFixedDimension(0.0d);
        org.jfree.data.Range range28 = numberAxis24.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range22, range28);
        numberAxis15.setRangeWithMargins(range22);
        boolean boolean31 = chartChangeEventType12.equals((java.lang.Object) numberAxis15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint34 = barRenderer32.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator36 = null;
        barRenderer32.setSeriesURLGenerator(10, categoryURLGenerator36, true);
        boolean boolean39 = barRenderer32.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart40 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType41 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent42 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer32, jFreeChart40, chartChangeEventType41);
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint45 = barRenderer43.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator47 = null;
        barRenderer43.setSeriesURLGenerator(10, categoryURLGenerator47, true);
        boolean boolean50 = barRenderer43.getAutoPopulateSeriesStroke();
        java.awt.Paint paint52 = barRenderer43.lookupSeriesFillPaint(10);
        barRenderer32.setBaseFillPaint(paint52);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator54 = null;
        barRenderer32.setBaseItemLabelGenerator(categoryItemLabelGenerator54, true);
        boolean boolean58 = barRenderer32.isSeriesVisible(15);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator59 = barRenderer32.getLegendItemToolTipGenerator();
        org.jfree.chart.plot.CategoryPlot categoryPlot60 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, categoryAxis2, (org.jfree.chart.axis.ValueAxis) numberAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer32);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType41);
        org.junit.Assert.assertNotNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(paint52);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator59);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        numberAxis1.setTickMarksVisible(false);
        boolean boolean5 = numberAxis1.isAutoRange();
        java.awt.Paint paint6 = numberAxis1.getTickLabelPaint();
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setAutoRangeIncludesZero(true);
        boolean boolean11 = numberAxis1.isVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        categoryPlot1.setOutlinePaint((java.awt.Paint) color2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot1.setDomainAxis(categoryAxis5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", (org.jfree.chart.plot.Plot) categoryPlot1);
        jFreeChart7.fireChartChanged();
        try {
            org.jfree.chart.title.Title title10 = jFreeChart7.getSubtitle((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.LegendItem legendItem12 = barRenderer0.getLegendItem((int) ' ', 1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint20 = barRenderer18.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = null;
        barRenderer18.setSeriesURLGenerator(10, categoryURLGenerator22, true);
        boolean boolean25 = barRenderer18.getAutoPopulateSeriesStroke();
        java.awt.Paint paint27 = barRenderer18.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke29 = barRenderer28.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent30 = null;
        barRenderer28.notifyListeners(rendererChangeEvent30);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = barRenderer28.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape33 = barRenderer28.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity34 = new org.jfree.chart.entity.LegendItemEntity(shape33);
        barRenderer18.setBaseShape(shape33, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity39 = new org.jfree.chart.entity.TickLabelEntity(shape33, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color40 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem41 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape33, (java.awt.Paint) color40);
        barRenderer0.setSeriesPaint((int) (byte) 10, (java.awt.Paint) color40);
        org.jfree.chart.LegendItemCollection legendItemCollection43 = barRenderer0.getLegendItems();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItem12);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(legendItemCollection43);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        java.awt.Stroke stroke0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.axis.AxisLocation axisLocation1 = axisLocation0.getOpposite();
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(axisLocation1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape((int) (short) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke7 = barRenderer6.getBaseStroke();
        java.awt.Font font8 = barRenderer6.getBaseItemLabelFont();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean15 = color13.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color13);
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("{0}", font8, (java.awt.Paint) color13, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("ThreadContext", font8);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str21 = rectangleInsets20.toString();
        labelBlock19.setMargin(rectangleInsets20);
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean25 = numberAxis24.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double28 = numberAxis27.getLabelAngle();
        numberAxis27.setFixedDimension(0.0d);
        org.jfree.data.Range range31 = numberAxis27.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent32 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis27);
        java.util.EventListener eventListener33 = null;
        boolean boolean34 = numberAxis27.hasListener(eventListener33);
        java.awt.Stroke stroke35 = numberAxis27.getTickMarkStroke();
        org.jfree.data.Range range36 = numberAxis27.getRange();
        boolean boolean39 = range36.intersects((double) 2, (double) '#');
        numberAxis24.setRangeWithMargins(range36, false, true);
        boolean boolean43 = numberAxis24.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image46 = null;
        categoryPlot45.setBackgroundImage(image46);
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo49);
        java.awt.geom.Rectangle2D rectangle2D51 = plotRenderingInfo50.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D52 = plotRenderingInfo50.getDataArea();
        categoryPlot45.drawBackgroundImage(graphics2D48, rectangle2D52);
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge54);
        double double56 = numberAxis24.valueToJava2D((double) 0.5f, rectangle2D52, rectangleEdge54);
        java.awt.geom.Rectangle2D rectangle2D59 = rectangleInsets20.createOutsetRectangle(rectangle2D52, true, true);
        try {
            shapeList0.setShape((-8355840), (java.awt.Shape) rectangle2D52);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str21.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(range36);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D59);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        keyedObjects2D0.setObject((java.lang.Object) 0.2d, (java.lang.Comparable) numberTickUnit2, (java.lang.Comparable) 10);
        keyedObjects2D0.addObject((java.lang.Object) 2.0d, (java.lang.Comparable) 1, (java.lang.Comparable) 100);
        try {
            keyedObjects2D0.removeColumn((java.lang.Comparable) "hi!");
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit2);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation((int) (short) -1);
        boolean boolean10 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.chart.axis.ValueAxis valueAxis12 = categoryPlot0.getRangeAxisForDataset(0);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(valueAxis12);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) 2, 0.0f, Double.NaN, (float) (byte) 1, (float) ' ');
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = null;
        barRenderer0.setSeriesFillPaint((int) '#', paint2, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        barRenderer0.setSeriesURLGenerator(0, categoryURLGenerator6, true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor9 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor10 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean12 = textAnchor10.equals((java.lang.Object) "{0}");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor9, textAnchor10);
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition13);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = null;
        barRenderer0.setSeriesURLGenerator(0, categoryURLGenerator16);
        org.junit.Assert.assertNotNull(itemLabelAnchor9);
        org.junit.Assert.assertNotNull(textAnchor10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        java.awt.Graphics2D graphics2D0 = null;
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape2, (double) 10.0f, (float) (-8355840), (float) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("");
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (double) (byte) 0);
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = defaultStatisticalCategoryDataset0.hasListener(eventListener4);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 100.0f);
        java.lang.Number number8 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.util.List list9 = defaultStatisticalCategoryDataset0.getColumnKeys();
        try {
            java.util.Collection collection10 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list9);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.0d + "'", number8.equals(0.0d));
        org.junit.Assert.assertNotNull(list9);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        double double2 = categoryAxis1.getCategoryMargin();
        double double3 = categoryAxis1.getCategoryMargin();
        categoryAxis1.setLowerMargin((double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (int) '#');
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertEquals((double) number6, Double.NaN, 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double8 = numberAxis7.getLabelAngle();
        numberAxis7.setFixedDimension(0.0d);
        org.jfree.data.Range range11 = numberAxis7.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double14 = numberAxis13.getLabelAngle();
        numberAxis13.setFixedDimension(0.0d);
        org.jfree.data.Range range17 = numberAxis13.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(range11, range17);
        java.lang.String str19 = range11.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(range5, range11);
        double double21 = range5.getLength();
        org.jfree.data.Range range24 = org.jfree.data.Range.shift(range5, (double) 10.0f, true);
        try {
            org.jfree.data.Range range27 = org.jfree.data.Range.expand(range24, 3.0d, (double) (-8355840));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (7.0) <= upper (-8355829.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Range[0.0,1.0]" + "'", str19.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0, jFreeChart8, chartChangeEventType9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint13 = barRenderer11.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        barRenderer11.setSeriesURLGenerator(10, categoryURLGenerator15, true);
        boolean boolean18 = barRenderer11.getAutoPopulateSeriesStroke();
        java.awt.Paint paint20 = barRenderer11.lookupSeriesFillPaint(10);
        barRenderer0.setBaseFillPaint(paint20);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator22, true);
        barRenderer0.setBaseCreateEntities(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = barRenderer0.getPositiveItemLabelPosition((int) (short) 0, 100);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = barRenderer0.getBaseToolTipGenerator();
        barRenderer0.setSeriesVisibleInLegend((int) 'a', (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNull(categoryToolTipGenerator30);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        boolean boolean3 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge2);
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge2);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertNotNull(rectangleEdge1);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        java.awt.Font font6 = barRenderer4.getBaseItemLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("{0}", font6, (java.awt.Paint) color11, (float) ' ');
        numberAxis1.setLabelFont(font6);
        numberAxis1.setLabelToolTip("");
        numberAxis1.setFixedDimension(10.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        keyedObjects2D0.setObject((java.lang.Object) 0.2d, (java.lang.Comparable) numberTickUnit2, (java.lang.Comparable) 10);
        keyedObjects2D0.addObject((java.lang.Object) 2.0d, (java.lang.Comparable) 1, (java.lang.Comparable) 100);
        keyedObjects2D0.removeObject((java.lang.Comparable) "PlotOrientation.VERTICAL", (java.lang.Comparable) "hi!");
        java.lang.Comparable comparable12 = null;
        keyedObjects2D0.removeObject(comparable12, (java.lang.Comparable) "EXPAND");
        try {
            java.lang.Comparable comparable16 = keyedObjects2D0.getRowKey((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit2);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        categoryPlot1.setOutlinePaint((java.awt.Paint) color2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot1.setDomainAxis(categoryAxis5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", (org.jfree.chart.plot.Plot) categoryPlot1);
        boolean boolean8 = jFreeChart7.getAntiAlias();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.text.TextBlock textBlock1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick5 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 2, textBlock1, textBlockAnchor2, textAnchor3, 0.0d);
        java.lang.String str6 = categoryTick5.toString();
        java.lang.Comparable comparable7 = categoryTick5.getCategory();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "" + "'", str6.equals(""));
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 2 + "'", comparable7.equals(2));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint7 = barRenderer3.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke9 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke9, true);
        java.awt.Stroke stroke14 = barRenderer3.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer0.setBaseStroke(stroke14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke19 = barRenderer18.getBaseStroke();
        java.awt.Font font20 = barRenderer18.getBaseItemLabelFont();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean27 = color25.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder28 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color25);
        org.jfree.chart.text.TextFragment textFragment30 = new org.jfree.chart.text.TextFragment("{0}", font20, (java.awt.Paint) color25, (float) ' ');
        java.awt.image.ColorModel colorModel31 = null;
        java.awt.Rectangle rectangle32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        java.awt.geom.AffineTransform affineTransform34 = null;
        java.awt.RenderingHints renderingHints35 = null;
        java.awt.PaintContext paintContext36 = color25.createContext(colorModel31, rectangle32, rectangle2D33, affineTransform34, renderingHints35);
        barRenderer0.setSeriesPaint(0, (java.awt.Paint) color25);
        barRenderer0.setBaseSeriesVisible(false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer40 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition42 = barRenderer40.getSeriesNegativeItemLabelPosition((int) (short) -1);
        barRenderer0.setPositiveItemLabelPositionFallback(itemLabelPosition42);
        java.lang.Boolean boolean45 = barRenderer0.getSeriesVisibleInLegend((int) ' ');
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(font20);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paintContext36);
        org.junit.Assert.assertNotNull(itemLabelPosition42);
        org.junit.Assert.assertNull(boolean45);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        double double2 = categoryAxis1.getCategoryMargin();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) ' ');
        double double5 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = barRenderer0.getItemLabelGenerator((int) (short) 10, (int) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer0.getPositiveItemLabelPosition((int) (short) -1, 2);
        barRenderer0.setBaseCreateEntities(false, true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double14 = numberAxis13.getLabelAngle();
        numberAxis13.setFixedDimension(0.0d);
        org.jfree.data.Range range17 = numberAxis13.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis13);
        java.util.EventListener eventListener19 = null;
        boolean boolean20 = numberAxis13.hasListener(eventListener19);
        java.awt.Stroke stroke21 = numberAxis13.getTickMarkStroke();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint28 = barRenderer26.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint30 = barRenderer26.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke32 = null;
        barRenderer26.setSeriesOutlineStroke(0, stroke32, true);
        java.awt.Stroke stroke37 = barRenderer26.getItemOutlineStroke((int) (byte) -1, 0);
        java.awt.Color color38 = java.awt.Color.CYAN;
        int int39 = color38.getRed();
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("{0}", "", "EXPAND", "hi!", false, shape7, true, (java.awt.Paint) color9, true, (java.awt.Paint) color11, stroke21, false, shape25, stroke37, (java.awt.Paint) color38);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo41 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo42 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo41);
        java.awt.geom.Rectangle2D rectangle2D43 = plotRenderingInfo42.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D44 = plotRenderingInfo42.getDataArea();
        boolean boolean45 = org.jfree.chart.util.ShapeUtilities.equal(shape7, (java.awt.Shape) rectangle2D44);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor46 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor47 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType48 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition50 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor46, textBlockAnchor47, categoryLabelWidthType48, (float) 0L);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor51 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        boolean boolean52 = rectangleAnchor46.equals((java.lang.Object) textBlockAnchor51);
        java.awt.geom.Point2D point2D53 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D44, rectangleAnchor46);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNull(rectangle2D43);
        org.junit.Assert.assertNotNull(rectangle2D44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(rectangleAnchor46);
        org.junit.Assert.assertNotNull(textBlockAnchor47);
        org.junit.Assert.assertNotNull(categoryLabelWidthType48);
        org.junit.Assert.assertNotNull(textBlockAnchor51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(point2D53);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint5 = valueMarker4.getPaint();
        org.jfree.chart.util.Layer layer6 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker4, layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = null;
        categoryPlot0.setDomainAxis(0, categoryAxis9, true);
        categoryPlot0.clearDomainMarkers((-15423));
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace6 = color5.getColorSpace();
        categoryPlot4.setOutlinePaint((java.awt.Paint) color5);
        java.awt.Paint paint8 = categoryPlot4.getOutlinePaint();
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape3, paint8);
        valueMarker1.setPaint(paint8);
        java.lang.String str11 = valueMarker1.getLabel();
        java.lang.Object obj12 = valueMarker1.clone();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis1.refreshTicks(graphics2D11, axisState13, rectangle2D14, rectangleEdge15);
        axisState13.cursorRight((double) 15.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape5 = barRenderer0.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.chart.block.BlockBorder blockBorder7 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean8 = legendItemEntity6.equals((java.lang.Object) blockBorder7);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDownTriangle(0.0f);
        boolean boolean11 = legendItemEntity6.equals((java.lang.Object) 0.0f);
        java.lang.Object obj12 = legendItemEntity6.clone();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset13 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number14 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset13);
        org.jfree.data.Range range16 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset13, true);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener17 = null;
        defaultStatisticalCategoryDataset13.addChangeListener(datasetChangeListener17);
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset13);
        org.jfree.data.general.PieDataset pieDataset21 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset13, (java.lang.Comparable) 0.95f);
        legendItemEntity6.setDataset((org.jfree.data.general.Dataset) pieDataset21);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(blockBorder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(obj12);
        org.junit.Assert.assertEquals((double) number14, Double.NaN, 0);
        org.junit.Assert.assertNull(range16);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.0d + "'", number19.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset21);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge6);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener4 = null;
        defaultStatisticalCategoryDataset0.addChangeListener(datasetChangeListener4);
        java.lang.Number number8 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 15, (java.lang.Comparable) 1.0f);
        double double10 = defaultStatisticalCategoryDataset0.getRangeLowerBound(false);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertEquals((double) double10, Double.NaN, 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint7 = barRenderer3.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke9 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke9, true);
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean14 = color12.equals((java.lang.Object) 0.0d);
        barRenderer3.setBaseItemLabelPaint((java.awt.Paint) color12);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = barRenderer3.getLegendItemToolTipGenerator();
        barRenderer3.setAutoPopulateSeriesOutlinePaint(false);
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        java.awt.Color color29 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color31 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double34 = numberAxis33.getLabelAngle();
        numberAxis33.setFixedDimension(0.0d);
        org.jfree.data.Range range37 = numberAxis33.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent38 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis33);
        java.util.EventListener eventListener39 = null;
        boolean boolean40 = numberAxis33.hasListener(eventListener39);
        java.awt.Stroke stroke41 = numberAxis33.getTickMarkStroke();
        java.awt.Shape shape45 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer46 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint48 = barRenderer46.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint50 = barRenderer46.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke52 = null;
        barRenderer46.setSeriesOutlineStroke(0, stroke52, true);
        java.awt.Stroke stroke57 = barRenderer46.getItemOutlineStroke((int) (byte) -1, 0);
        java.awt.Color color58 = java.awt.Color.CYAN;
        int int59 = color58.getRed();
        org.jfree.chart.LegendItem legendItem60 = new org.jfree.chart.LegendItem("{0}", "", "EXPAND", "hi!", false, shape27, true, (java.awt.Paint) color29, true, (java.awt.Paint) color31, stroke41, false, shape45, stroke57, (java.awt.Paint) color58);
        barRenderer3.setSeriesOutlineStroke(2, stroke57, true);
        barRenderer0.setBaseOutlineStroke(stroke57);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator65 = null;
        barRenderer0.setSeriesURLGenerator((int) (short) 1, categoryURLGenerator65);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(shape45);
        org.junit.Assert.assertNotNull(paint48);
        org.junit.Assert.assertNull(paint50);
        org.junit.Assert.assertNotNull(stroke57);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean6 = color4.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color4);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo10.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D12 = plotRenderingInfo10.getDataArea();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition13 = new org.jfree.chart.axis.CategoryLabelPosition();
        float float14 = categoryLabelPosition13.getWidthRatio();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor15 = categoryLabelPosition13.getCategoryAnchor();
        java.awt.geom.Point2D point2D16 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D12, rectangleAnchor15);
        try {
            blockBorder7.draw(graphics2D8, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNull(rectangle2D11);
        org.junit.Assert.assertNotNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.95f + "'", float14 == 0.95f);
        org.junit.Assert.assertNotNull(rectangleAnchor15);
        org.junit.Assert.assertNotNull(point2D16);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer1.setSeriesURLGenerator(10, categoryURLGenerator5, true);
        boolean boolean8 = barRenderer1.getAutoPopulateSeriesStroke();
        java.awt.Paint paint10 = barRenderer1.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke12 = barRenderer11.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer11.notifyListeners(rendererChangeEvent13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer11.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape16 = barRenderer11.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity17 = new org.jfree.chart.entity.LegendItemEntity(shape16);
        barRenderer1.setBaseShape(shape16, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity22 = new org.jfree.chart.entity.TickLabelEntity(shape16, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke25 = barRenderer24.getBaseStroke();
        java.awt.Font font26 = barRenderer24.getBaseItemLabelFont();
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean33 = color31.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color31);
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("{0}", font26, (java.awt.Paint) color31, (float) ' ');
        java.awt.image.ColorModel colorModel37 = null;
        java.awt.Rectangle rectangle38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        java.awt.geom.AffineTransform affineTransform40 = null;
        java.awt.RenderingHints renderingHints41 = null;
        java.awt.PaintContext paintContext42 = color31.createContext(colorModel37, rectangle38, rectangle2D39, affineTransform40, renderingHints41);
        org.jfree.chart.title.LegendGraphic legendGraphic43 = new org.jfree.chart.title.LegendGraphic(shape16, (java.awt.Paint) color31);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double46 = numberAxis45.getLabelAngle();
        numberAxis45.setFixedDimension(0.0d);
        org.jfree.data.Range range49 = numberAxis45.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent50 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis45);
        java.awt.Shape shape51 = numberAxis45.getRightArrow();
        legendGraphic43.setLine(shape51);
        legendGraphic43.setWidth(0.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer55 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint57 = barRenderer55.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer58 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint60 = barRenderer58.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint62 = barRenderer58.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke64 = null;
        barRenderer58.setSeriesOutlineStroke(0, stroke64, true);
        java.awt.Stroke stroke69 = barRenderer58.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer55.setBaseStroke(stroke69);
        legendGraphic43.setOutlineStroke(stroke69);
        java.awt.Stroke stroke72 = legendGraphic43.getLineStroke();
        java.awt.Shape shape73 = null;
        legendGraphic43.setLine(shape73);
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean77 = numberAxis76.isTickLabelsVisible();
        java.awt.Paint paint78 = numberAxis76.getAxisLinePaint();
        numberAxis76.setLabelToolTip("ChartChangeEventType.DATASET_UPDATED");
        centerArrangement0.add((org.jfree.chart.block.Block) legendGraphic43, (java.lang.Object) numberAxis76);
        org.jfree.chart.block.BlockContainer blockContainer82 = null;
        java.awt.Graphics2D graphics2D83 = null;
        org.jfree.chart.axis.NumberAxis numberAxis85 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double86 = numberAxis85.getLabelAngle();
        numberAxis85.setFixedDimension(0.0d);
        org.jfree.data.Range range89 = numberAxis85.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis91 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double92 = numberAxis91.getLabelAngle();
        numberAxis91.setFixedDimension(0.0d);
        org.jfree.data.Range range95 = numberAxis91.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint96 = new org.jfree.chart.block.RectangleConstraint(range89, range95);
        double double97 = rectangleConstraint96.getWidth();
        try {
            org.jfree.chart.util.Size2D size2D98 = centerArrangement0.arrange(blockContainer82, graphics2D83, rectangleConstraint96);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paintContext42);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNull(paint62);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNull(stroke72);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(range89);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertNotNull(range95);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color4 = java.awt.Color.magenta;
        float[] floatArray5 = null;
        float[] floatArray6 = color4.getComponents(floatArray5);
        float[] floatArray7 = color3.getRGBColorComponents(floatArray6);
        float[] floatArray8 = java.awt.Color.RGBtoHSB(1, 8, 0, floatArray6);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        barRenderer3.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock1, textBlockAnchor2, textAnchor8, 0.0d);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock1.calculateDimensions(graphics2D11);
        size2D12.width = 15.0f;
        java.lang.String str15 = size2D12.toString();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint19 = barRenderer17.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint21 = barRenderer17.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke23 = null;
        barRenderer17.setSeriesOutlineStroke(0, stroke23, true);
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean28 = color26.equals((java.lang.Object) 0.0d);
        barRenderer17.setBaseItemLabelPaint((java.awt.Paint) color26);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator30 = barRenderer17.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke34 = barRenderer33.getBaseStroke();
        java.awt.Font font35 = barRenderer33.getBaseItemLabelFont();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean42 = color40.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder43 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color40);
        org.jfree.chart.text.TextFragment textFragment45 = new org.jfree.chart.text.TextFragment("{0}", font35, (java.awt.Paint) color40, (float) ' ');
        java.awt.Font font46 = textFragment45.getFont();
        barRenderer17.setSeriesItemLabelFont(0, font46);
        java.awt.Color color48 = java.awt.Color.green;
        org.jfree.chart.text.TextLine textLine49 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_CENTER", font46, (java.awt.Paint) color48);
        boolean boolean50 = size2D12.equals((java.lang.Object) color48);
        java.lang.Object obj51 = size2D12.clone();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Size2D[width=15.0, height=0.0]" + "'", str15.equals("Size2D[width=15.0, height=0.0]"));
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator30);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertNotNull(color48);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(obj51);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = plotRenderingInfo1.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo1.getPlotArea();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        plotRenderingInfo1.addSubplotInfo(plotRenderingInfo5);
        org.junit.Assert.assertNull(rectangle2D2);
        org.junit.Assert.assertNull(rectangle2D3);
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) axisLocation1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = axisLocation1.getOpposite();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation1, plotOrientation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(axisLocation3);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Paint paint5 = barRenderer0.getSeriesFillPaint((int) (short) 0);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = legendTitle6.getItemLabelPadding();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = legendTitle6.getMargin();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        keyedObjects2D0.setObject((java.lang.Object) 0.2d, (java.lang.Comparable) numberTickUnit2, (java.lang.Comparable) 10);
        keyedObjects2D0.addObject((java.lang.Object) 2.0d, (java.lang.Comparable) 1, (java.lang.Comparable) 100);
        keyedObjects2D0.removeObject((java.lang.Comparable) "PlotOrientation.VERTICAL", (java.lang.Comparable) "hi!");
        java.lang.Comparable comparable12 = null;
        keyedObjects2D0.removeObject(comparable12, (java.lang.Comparable) "EXPAND");
        java.lang.Object obj17 = keyedObjects2D0.getObject((java.lang.Comparable) '#', (java.lang.Comparable) "LegendItemEntity: seriesKey=null, dataset=null");
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertNull(obj17);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer2 = null;
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = null;
        try {
            org.jfree.chart.util.Size2D size2D5 = borderArrangement0.arrange(blockContainer2, graphics2D3, rectangleConstraint4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double[][] doubleArray2 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset3 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("LegendItemEntity: seriesKey=null, dataset=null", "java.awt.Color[r=255,g=255,b=0]", doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        categoryPlot0.drawBackgroundImage(graphics2D3, rectangle2D7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis10, true);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot0.getDomainMarkers((int) (short) 1, layer14);
        java.awt.Font font16 = categoryPlot0.getNoDataMessageFont();
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(font16);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape5 = barRenderer0.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.data.general.Dataset dataset7 = legendItemEntity6.getDataset();
        java.lang.Comparable comparable8 = legendItemEntity6.getSeriesKey();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertNull(comparable8);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.awt.Stroke stroke2 = strokeList0.getStroke((int) (short) 1);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color30);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double45 = numberAxis44.getLabelAngle();
        numberAxis44.setFixedDimension(0.0d);
        org.jfree.data.Range range48 = numberAxis44.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent49 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis44);
        java.awt.Shape shape50 = numberAxis44.getRightArrow();
        legendGraphic42.setLine(shape50);
        legendGraphic42.setWidth(0.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer54 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint56 = barRenderer54.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer57 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint59 = barRenderer57.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint61 = barRenderer57.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke63 = null;
        barRenderer57.setSeriesOutlineStroke(0, stroke63, true);
        java.awt.Stroke stroke68 = barRenderer57.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer54.setBaseStroke(stroke68);
        legendGraphic42.setOutlineStroke(stroke68);
        java.awt.Stroke stroke71 = legendGraphic42.getLineStroke();
        java.awt.Shape shape72 = null;
        legendGraphic42.setLine(shape72);
        legendGraphic42.setShapeOutlineVisible(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNull(paint61);
        org.junit.Assert.assertNotNull(stroke68);
        org.junit.Assert.assertNull(stroke71);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        java.awt.Shape shape11 = numberAxis1.getRightArrow();
        org.jfree.chart.event.AxisChangeListener axisChangeListener12 = null;
        numberAxis1.addChangeListener(axisChangeListener12);
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean16 = numberAxis15.isTickLabelsVisible();
        numberAxis15.setAutoRange(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = numberAxis15.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean23 = numberAxis22.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double26 = numberAxis25.getLabelAngle();
        numberAxis25.setFixedDimension(0.0d);
        org.jfree.data.Range range29 = numberAxis25.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent30 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis25);
        java.util.EventListener eventListener31 = null;
        boolean boolean32 = numberAxis25.hasListener(eventListener31);
        java.awt.Stroke stroke33 = numberAxis25.getTickMarkStroke();
        org.jfree.data.Range range34 = numberAxis25.getRange();
        boolean boolean37 = range34.intersects((double) 2, (double) '#');
        numberAxis22.setRangeWithMargins(range34, false, true);
        boolean boolean41 = numberAxis22.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image44 = null;
        categoryPlot43.setBackgroundImage(image44);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo47 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo47);
        java.awt.geom.Rectangle2D rectangle2D49 = plotRenderingInfo48.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D50 = plotRenderingInfo48.getDataArea();
        categoryPlot43.drawBackgroundImage(graphics2D46, rectangle2D50);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge52);
        double double54 = numberAxis22.valueToJava2D((double) 0.5f, rectangle2D50, rectangleEdge52);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str56 = rectangleEdge55.toString();
        double double57 = numberAxis15.lengthToJava2D((double) 2, rectangle2D50, rectangleEdge55);
        numberAxis1.setLeftArrow((java.awt.Shape) rectangle2D50);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(numberTickUnit19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNull(rectangle2D49);
        org.junit.Assert.assertNotNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "RectangleEdge.LEFT" + "'", str56.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.data.Range range2 = new org.jfree.data.Range(0.0d, (double) 100L);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("Size2D[width=15.0, height=0.0]", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke6 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke6, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        boolean boolean13 = barRenderer0.getIncludeBaseInRange();
        java.awt.Stroke stroke14 = null;
        try {
            barRenderer0.setBaseStroke(stroke14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        java.lang.String str22 = tickLabelEntity21.getURLText();
        tickLabelEntity21.setURLText("ThreadContext");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator25 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator26 = null;
        try {
            java.lang.String str27 = tickLabelEntity21.getImageMapAreaTag(toolTipTagFragmentGenerator25, uRLTagFragmentGenerator26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "" + "'", str22.equals(""));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        numberAxis1.setTickMarksVisible(false);
        boolean boolean5 = numberAxis1.isAutoRange();
        numberAxis1.setRangeWithMargins((double) 0.0f, (double) 1L);
        java.text.NumberFormat numberFormat9 = numberAxis1.getNumberFormatOverride();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        numberAxis1.setLeftArrow(shape11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(numberFormat9);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickLabelsVisible();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis1.valueToJava2D((double) 10.0f, rectangle2D4, rectangleEdge5);
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        java.awt.Shape shape9 = numberAxis1.getLeftArrow();
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity12 = new org.jfree.chart.entity.TickLabelEntity(shape9, "RectangleEdge.LEFT", "RectangleEdge.LEFT");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        java.lang.String str1 = tickType0.toString();
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "MINOR" + "'", str1.equals("MINOR"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        barRenderer3.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock1, textBlockAnchor2, textAnchor8, 0.0d);
        java.lang.Object obj11 = categoryTick10.clone();
        double double12 = categoryTick10.getAngle();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        org.jfree.chart.axis.ValueAxis valueAxis5 = categoryPlot0.getRangeAxisForDataset(15);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) (-1));
        try {
            categoryPlot0.setDomainAxis((int) (short) -1, categoryAxis8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNull(valueAxis5);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getInfo();
//        java.lang.String str2 = projectInfo0.getName();
//        projectInfo0.setLicenceName("java.awt.Color[r=128,g=128,b=0]");
//        java.lang.String str5 = projectInfo0.getLicenceText();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str1.equals("http://www.jfree.org/jfreechart/index.html"));
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "JFreeChart" + "'", str2.equals("JFreeChart"));
//        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str5.equals("http://www.jfree.org/jfreechart/index.html"));
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        float[] floatArray2 = new float[] { (short) 10 };
        try {
            float[] floatArray3 = color0.getRGBColorComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(100);
        java.lang.Object obj3 = objectList1.get((int) ' ');
        java.lang.Object obj5 = objectList1.get((int) (byte) 100);
        org.junit.Assert.assertNull(obj3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape5 = barRenderer0.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.data.general.Dataset dataset7 = legendItemEntity6.getDataset();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        double double9 = numberTickUnit8.getSize();
        legendItemEntity6.setSeriesKey((java.lang.Comparable) numberTickUnit8);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertNotNull(numberTickUnit8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Paint paint5 = barRenderer0.getSeriesFillPaint((int) (short) 0);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.awt.Color color7 = java.awt.Color.BLUE;
        legendTitle6.setItemPaint((java.awt.Paint) color7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke13 = barRenderer12.getBaseStroke();
        java.awt.Font font14 = barRenderer12.getBaseItemLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean21 = color19.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color19);
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("{0}", font14, (java.awt.Paint) color19, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock25 = new org.jfree.chart.block.LabelBlock("ThreadContext", font14);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str27 = rectangleInsets26.toString();
        labelBlock25.setMargin(rectangleInsets26);
        org.jfree.chart.axis.NumberAxis numberAxis30 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean31 = numberAxis30.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double34 = numberAxis33.getLabelAngle();
        numberAxis33.setFixedDimension(0.0d);
        org.jfree.data.Range range37 = numberAxis33.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent38 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis33);
        java.util.EventListener eventListener39 = null;
        boolean boolean40 = numberAxis33.hasListener(eventListener39);
        java.awt.Stroke stroke41 = numberAxis33.getTickMarkStroke();
        org.jfree.data.Range range42 = numberAxis33.getRange();
        boolean boolean45 = range42.intersects((double) 2, (double) '#');
        numberAxis30.setRangeWithMargins(range42, false, true);
        boolean boolean49 = numberAxis30.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image52 = null;
        categoryPlot51.setBackgroundImage(image52);
        java.awt.Graphics2D graphics2D54 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo55 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo55);
        java.awt.geom.Rectangle2D rectangle2D57 = plotRenderingInfo56.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D58 = plotRenderingInfo56.getDataArea();
        categoryPlot51.drawBackgroundImage(graphics2D54, rectangle2D58);
        org.jfree.chart.util.RectangleEdge rectangleEdge60 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge60);
        double double62 = numberAxis30.valueToJava2D((double) 0.5f, rectangle2D58, rectangleEdge60);
        java.awt.geom.Rectangle2D rectangle2D65 = rectangleInsets26.createOutsetRectangle(rectangle2D58, true, true);
        java.awt.Color color66 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel67 = null;
        java.awt.Rectangle rectangle68 = null;
        java.awt.geom.Rectangle2D rectangle2D69 = null;
        java.awt.geom.AffineTransform affineTransform70 = null;
        java.awt.RenderingHints renderingHints71 = null;
        java.awt.PaintContext paintContext72 = color66.createContext(colorModel67, rectangle68, rectangle2D69, affineTransform70, renderingHints71);
        try {
            java.lang.Object obj73 = legendTitle6.draw(graphics2D9, rectangle2D58, (java.lang.Object) color66);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str27.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNotNull(range42);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNull(rectangle2D57);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertNotNull(rectangleEdge60);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D65);
        org.junit.Assert.assertNotNull(color66);
        org.junit.Assert.assertNotNull(paintContext72);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0, jFreeChart8, chartChangeEventType9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint13 = barRenderer11.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        barRenderer11.setSeriesURLGenerator(10, categoryURLGenerator15, true);
        boolean boolean18 = barRenderer11.getAutoPopulateSeriesStroke();
        java.awt.Paint paint20 = barRenderer11.lookupSeriesFillPaint(10);
        barRenderer0.setBaseFillPaint(paint20);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator22, true);
        barRenderer0.setBaseCreateEntities(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = barRenderer0.getPositiveItemLabelPosition((int) (short) 0, 100);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator30 = barRenderer0.getBaseToolTipGenerator();
        double double31 = barRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNull(categoryToolTipGenerator30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0d + "'", double31 == 1.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (double) (byte) 0);
        java.util.List list4 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(list4);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        barRenderer3.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock1, textBlockAnchor2, textAnchor8, 0.0d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textBlock1.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textBlock1.setLineAlignment(horizontalAlignment12);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor14 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor15 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType16 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor14, textBlockAnchor15, categoryLabelWidthType16, (float) 0L);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor19 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        boolean boolean20 = rectangleAnchor14.equals((java.lang.Object) textBlockAnchor19);
        boolean boolean21 = horizontalAlignment12.equals((java.lang.Object) textBlockAnchor19);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(rectangleAnchor14);
        org.junit.Assert.assertNotNull(textBlockAnchor15);
        org.junit.Assert.assertNotNull(categoryLabelWidthType16);
        org.junit.Assert.assertNotNull(textBlockAnchor19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition0 = new org.jfree.chart.axis.CategoryLabelPosition();
        float float1 = categoryLabelPosition0.getWidthRatio();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor2 = categoryLabelPosition0.getCategoryAnchor();
        float float3 = categoryLabelPosition0.getWidthRatio();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType4 = categoryLabelPosition0.getWidthType();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.95f + "'", float1 == 0.95f);
        org.junit.Assert.assertNotNull(rectangleAnchor2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.95f + "'", float3 == 0.95f);
        org.junit.Assert.assertNotNull(categoryLabelWidthType4);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        barRenderer3.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock1, textBlockAnchor2, textAnchor8, 0.0d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment11 = textBlock1.getLineAlignment();
        java.util.List list12 = textBlock1.getLines();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(horizontalAlignment11);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("hi!", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setRight((double) '#');
        axisSpace0.setLeft((double) 10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = axisSpace0.reserved(rectangle2D5, rectangleEdge6);
        axisSpace0.setRight((double) '4');
        axisSpace0.setLeft((double) 10.0f);
        org.junit.Assert.assertNull(rectangle2D7);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.extendWidth((double) 0.95f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.949999988079071d + "'", double2 == 8.949999988079071d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str4 = projectInfo3.getLicenceName();
        java.awt.Image image5 = projectInfo3.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo6 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list7 = projectInfo6.getContributors();
        projectInfo3.addLibrary((org.jfree.chart.ui.Library) projectInfo6);
        org.jfree.chart.ui.ProjectInfo projectInfo9 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str10 = projectInfo9.getLicenceName();
        java.awt.Image image11 = projectInfo9.getLogo();
        projectInfo3.setLogo(image11);
        org.jfree.chart.ui.ProjectInfo projectInfo16 = new org.jfree.chart.ui.ProjectInfo("TextAnchor.BOTTOM_CENTER", "RectangleAnchor.BOTTOM", "RectangleConstraintType.RANGE", image11, "TextBlockAnchor.TOP_LEFT", "VerticalAlignment.CENTER", "hi!");
        org.jfree.chart.ui.ProjectInfo projectInfo17 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str18 = projectInfo17.getLicenceName();
        java.awt.Image image19 = projectInfo17.getLogo();
        org.jfree.chart.ui.ProjectInfo projectInfo20 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list21 = projectInfo20.getContributors();
        projectInfo17.addLibrary((org.jfree.chart.ui.Library) projectInfo20);
        org.jfree.chart.ui.ProjectInfo projectInfo23 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str24 = projectInfo23.getLicenceName();
        java.awt.Image image25 = projectInfo23.getLogo();
        projectInfo17.setLogo(image25);
        projectInfo16.setLogo(image25);
        org.junit.Assert.assertNotNull(projectInfo3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java.awt.Color[r=128,g=128,b=0]" + "'", str4.equals("java.awt.Color[r=128,g=128,b=0]"));
        org.junit.Assert.assertNotNull(image5);
        org.junit.Assert.assertNotNull(projectInfo6);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(projectInfo9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "java.awt.Color[r=128,g=128,b=0]" + "'", str10.equals("java.awt.Color[r=128,g=128,b=0]"));
        org.junit.Assert.assertNotNull(image11);
        org.junit.Assert.assertNotNull(projectInfo17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "java.awt.Color[r=128,g=128,b=0]" + "'", str18.equals("java.awt.Color[r=128,g=128,b=0]"));
        org.junit.Assert.assertNotNull(image19);
        org.junit.Assert.assertNotNull(projectInfo20);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(projectInfo23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "java.awt.Color[r=128,g=128,b=0]" + "'", str24.equals("java.awt.Color[r=128,g=128,b=0]"));
        org.junit.Assert.assertNotNull(image25);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        java.awt.Font font5 = barRenderer3.getBaseItemLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}", font5, (java.awt.Paint) color10, (float) ' ');
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        categoryPlot18.setOutlinePaint((java.awt.Paint) color19);
        java.awt.Paint paint22 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot18.rendererChanged(rendererChangeEvent23);
        categoryPlot18.setRangeCrosshairValue((double) 3, true);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font16, (org.jfree.chart.plot.Plot) categoryPlot18, false);
        int int30 = jFreeChart29.getBackgroundImageAlignment();
        jFreeChart29.setBorderVisible(false);
        org.jfree.chart.event.ChartProgressListener chartProgressListener33 = null;
        jFreeChart29.removeProgressListener(chartProgressListener33);
        java.awt.RenderingHints renderingHints35 = null;
        try {
            jFreeChart29.setRenderingHints(renderingHints35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: RenderingHints given are null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        categoryPlot0.configureDomainAxes();
        int int8 = categoryPlot0.getRangeAxisCount();
        java.util.List list9 = categoryPlot0.getCategories();
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(list9);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getLabelAngle();
        numberAxis2.setFixedDimension(0.0d);
        org.jfree.data.Range range6 = numberAxis2.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent7 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis2);
        numberAxis2.setUpperBound((double) '4');
        numberAxis2.setAxisLineVisible(false);
        java.awt.Shape shape12 = numberAxis2.getRightArrow();
        org.jfree.chart.event.AxisChangeListener axisChangeListener13 = null;
        numberAxis2.addChangeListener(axisChangeListener13);
        java.awt.Font font15 = numberAxis2.getLabelFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint22 = barRenderer20.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        barRenderer20.setSeriesURLGenerator(10, categoryURLGenerator24, true);
        boolean boolean27 = barRenderer20.getAutoPopulateSeriesStroke();
        java.awt.Paint paint29 = barRenderer20.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke31 = barRenderer30.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        barRenderer30.notifyListeners(rendererChangeEvent32);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = barRenderer30.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape35 = barRenderer30.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity36 = new org.jfree.chart.entity.LegendItemEntity(shape35);
        barRenderer20.setBaseShape(shape35, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity41 = new org.jfree.chart.entity.TickLabelEntity(shape35, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color42 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem43 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape35, (java.awt.Paint) color42);
        java.awt.Paint paint44 = legendItem43.getLinePaint();
        java.lang.Comparable comparable45 = legendItem43.getSeriesKey();
        java.awt.Paint paint46 = legendItem43.getOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment48 = new org.jfree.chart.text.TextFragment("Range[0.0,1.0]", font15, paint46, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertNotNull(shape12);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertNull(comparable45);
        org.junit.Assert.assertNotNull(paint46);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (double) (byte) 0);
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = defaultStatisticalCategoryDataset0.hasListener(eventListener4);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 100.0f);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (int) ' ');
        try {
            java.lang.Comparable comparable11 = defaultStatisticalCategoryDataset0.getColumnKey((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertNotNull(pieDataset9);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) (-8355840));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean2 = legendItemCollection0.equals((java.lang.Object) axisLocation1);
        org.jfree.chart.axis.AxisLocation axisLocation3 = axisLocation1.getOpposite();
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation3, plotOrientation4);
        java.lang.String str6 = plotOrientation4.toString();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(axisLocation3);
        org.junit.Assert.assertNotNull(plotOrientation4);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "PlotOrientation.VERTICAL" + "'", str6.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean5 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke8 = barRenderer7.getBaseStroke();
        java.awt.Font font9 = barRenderer7.getBaseItemLabelFont();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean16 = color14.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color14);
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("{0}", font9, (java.awt.Paint) color14, (float) ' ');
        numberAxis4.setLabelFont(font9);
        valueMarker2.setLabelFont(font9);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset22 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable23 = null;
        int int24 = defaultStatisticalCategoryDataset22.getColumnIndex(comparable23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot25.setDomainAxis(categoryAxis26);
        defaultStatisticalCategoryDataset22.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot25);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("RangeType.FULL", font9, (org.jfree.chart.plot.Plot) categoryPlot25, true);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo35 = null;
        java.awt.image.BufferedImage bufferedImage36 = jFreeChart30.createBufferedImage((int) (short) 10, 8, 100.0d, (double) 10L, chartRenderingInfo35);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(bufferedImage36);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "");
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        java.awt.Font font6 = barRenderer4.getBaseItemLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("{0}", font6, (java.awt.Paint) color11, (float) ' ');
        numberAxis1.setLabelFont(font6);
        numberAxis1.setLowerBound(1.0E-8d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener20 = null;
        numberAxis1.removeChangeListener(axisChangeListener20);
        double double22 = numberAxis1.getLabelAngle();
        boolean boolean23 = numberAxis1.isInverted();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        org.jfree.data.category.CategoryDataset categoryDataset8 = categoryPlot0.getDataset(100);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryDataset8);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint5 = barRenderer1.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke7 = null;
        barRenderer1.setSeriesOutlineStroke(0, stroke7, true);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        barRenderer1.setBaseItemLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = barRenderer1.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke18 = barRenderer17.getBaseStroke();
        java.awt.Font font19 = barRenderer17.getBaseItemLabelFont();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean26 = color24.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color24);
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("{0}", font19, (java.awt.Paint) color24, (float) ' ');
        java.awt.Font font30 = textFragment29.getFont();
        barRenderer1.setSeriesItemLabelFont(0, font30);
        java.awt.Color color32 = java.awt.Color.green;
        org.jfree.chart.text.TextLine textLine33 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_CENTER", font30, (java.awt.Paint) color32);
        org.jfree.chart.text.TextFragment textFragment34 = textLine33.getLastTextFragment();
        java.awt.Font font35 = textFragment34.getFont();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.text.TextAnchor textAnchor37 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        try {
            float float38 = textFragment34.calculateBaselineOffset(graphics2D36, textAnchor37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(textFragment34);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(textAnchor37);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean5 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke8 = barRenderer7.getBaseStroke();
        java.awt.Font font9 = barRenderer7.getBaseItemLabelFont();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean16 = color14.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color14);
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("{0}", font9, (java.awt.Paint) color14, (float) ' ');
        numberAxis4.setLabelFont(font9);
        valueMarker2.setLabelFont(font9);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset22 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable23 = null;
        int int24 = defaultStatisticalCategoryDataset22.getColumnIndex(comparable23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot25.setDomainAxis(categoryAxis26);
        defaultStatisticalCategoryDataset22.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot25);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("RangeType.FULL", font9, (org.jfree.chart.plot.Plot) categoryPlot25, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color33 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace34 = color33.getColorSpace();
        categoryPlot32.setOutlinePaint((java.awt.Paint) color33);
        org.jfree.chart.axis.AxisLocation axisLocation37 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot32.setRangeAxisLocation((int) (byte) 100, axisLocation37, false);
        categoryPlot25.setDomainAxisLocation((int) '#', axisLocation37, true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(colorSpace34);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        categoryPlot2.setOutlinePaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = categoryPlot2.getOutlinePaint();
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape1, paint6);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer8 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendGraphic7.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer8);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double13 = numberAxis12.getLabelAngle();
        numberAxis12.setFixedDimension(0.0d);
        org.jfree.data.Range range16 = numberAxis12.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double19 = numberAxis18.getLabelAngle();
        numberAxis18.setFixedDimension(0.0d);
        org.jfree.data.Range range22 = numberAxis18.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(range16, range22);
        java.lang.String str24 = range16.toString();
        double double26 = range16.constrain((double) (-1.0f));
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean29 = numberAxis28.isTickMarksVisible();
        numberAxis28.setTickMarksVisible(false);
        boolean boolean32 = numberAxis28.isAutoRange();
        java.awt.Paint paint33 = numberAxis28.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double36 = numberAxis35.getLabelAngle();
        numberAxis35.setFixedDimension(0.0d);
        org.jfree.data.Range range39 = numberAxis35.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent40 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis35);
        java.util.EventListener eventListener41 = null;
        boolean boolean42 = numberAxis35.hasListener(eventListener41);
        java.awt.Stroke stroke43 = numberAxis35.getTickMarkStroke();
        org.jfree.data.Range range44 = numberAxis35.getRange();
        boolean boolean47 = range44.intersects((double) 2, (double) '#');
        numberAxis28.setRange(range44, true, false);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double53 = numberAxis52.getLabelAngle();
        numberAxis52.setFixedDimension(0.0d);
        org.jfree.data.Range range56 = numberAxis52.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis58 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double59 = numberAxis58.getLabelAngle();
        numberAxis58.setFixedDimension(0.0d);
        org.jfree.data.Range range62 = numberAxis58.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis64 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double65 = numberAxis64.getLabelAngle();
        numberAxis64.setFixedDimension(0.0d);
        org.jfree.data.Range range68 = numberAxis64.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint69 = new org.jfree.chart.block.RectangleConstraint(range62, range68);
        java.lang.String str70 = range62.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint71 = new org.jfree.chart.block.RectangleConstraint(range56, range62);
        double double72 = range56.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint73 = new org.jfree.chart.block.RectangleConstraint(range44, range56);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint74 = new org.jfree.chart.block.RectangleConstraint(range16, range56);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType75 = rectangleConstraint74.getWidthConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D76 = legendGraphic7.arrange(graphics2D10, rectangleConstraint74);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "Range[0.0,1.0]" + "'", str24.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(range56);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(range62);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(range68);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "Range[0.0,1.0]" + "'", str70.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0d + "'", double72 == 1.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType75);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (short) -1, (double) (byte) -1, 3, (java.lang.Comparable) "RangeType.FULL");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Paint paint5 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.Marker marker9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        barRenderer0.drawRangeMarker(graphics2D6, categoryPlot7, valueAxis8, marker9, rectangle2D10);
        boolean boolean12 = barRenderer0.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.util.Layer layer0 = org.jfree.chart.util.Layer.BACKGROUND;
        org.junit.Assert.assertNotNull(layer0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = categoryPlot0.getDomainAxis();
        try {
            categoryPlot0.mapDatasetToRangeAxis((-8355840), 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryAxis3);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis1.getTickLabelInsets();
        numberAxis1.setLabelAngle((double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        java.awt.Font font6 = barRenderer4.getBaseItemLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("{0}", font6, (java.awt.Paint) color11, (float) ' ');
        numberAxis1.setLabelFont(font6);
        numberAxis1.setLowerBound(1.0E-8d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener20 = null;
        numberAxis1.removeChangeListener(axisChangeListener20);
        org.jfree.chart.axis.TickUnits tickUnits22 = new org.jfree.chart.axis.TickUnits();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit23 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState25 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo24);
        boolean boolean26 = numberTickUnit23.equals((java.lang.Object) categoryItemRendererState25);
        tickUnits22.add((org.jfree.chart.axis.TickUnit) numberTickUnit23);
        int int28 = tickUnits22.size();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset29 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean34 = numberAxis33.isTickLabelsVisible();
        numberAxis33.setAutoRange(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit37 = numberAxis33.getTickUnit();
        java.lang.Comparable comparable38 = null;
        defaultStatisticalCategoryDataset29.add(Double.NaN, 0.0d, (java.lang.Comparable) numberTickUnit37, comparable38);
        tickUnits22.add((org.jfree.chart.axis.TickUnit) numberTickUnit37);
        numberAxis1.setTickUnit(numberTickUnit37);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(numberTickUnit23);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 1 + "'", int28 == 1);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
        org.junit.Assert.assertNotNull(numberTickUnit37);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState2 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo1);
        boolean boolean3 = numberTickUnit0.equals((java.lang.Object) categoryItemRendererState2);
        org.jfree.chart.entity.EntityCollection entityCollection4 = categoryItemRendererState2.getEntityCollection();
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNull(entityCollection4);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double8 = numberAxis7.getLabelAngle();
        numberAxis7.setFixedDimension(0.0d);
        org.jfree.data.Range range11 = numberAxis7.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double14 = numberAxis13.getLabelAngle();
        numberAxis13.setFixedDimension(0.0d);
        org.jfree.data.Range range17 = numberAxis13.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(range11, range17);
        java.lang.String str19 = range11.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(range5, range11);
        double double21 = range5.getLength();
        org.jfree.data.Range range24 = org.jfree.data.Range.shift(range5, (double) 10.0f, true);
        org.jfree.data.Range range27 = org.jfree.data.Range.shift(range5, 0.0d, false);
        org.jfree.data.Range range29 = org.jfree.data.Range.expandToInclude(range27, 0.5d);
        boolean boolean32 = range29.intersects(Double.NaN, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Range[0.0,1.0]" + "'", str19.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean6 = numberAxis5.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke9 = barRenderer8.getBaseStroke();
        java.awt.Font font10 = barRenderer8.getBaseItemLabelFont();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean17 = color15.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder18 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color15);
        org.jfree.chart.text.TextFragment textFragment20 = new org.jfree.chart.text.TextFragment("{0}", font10, (java.awt.Paint) color15, (float) ' ');
        numberAxis5.setLabelFont(font10);
        numberAxis5.setLabelToolTip("");
        org.jfree.data.Range range24 = numberAxis5.getRange();
        java.awt.Shape shape25 = numberAxis5.getDownArrow();
        java.awt.Shape shape27 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color29 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace30 = color29.getColorSpace();
        categoryPlot28.setOutlinePaint((java.awt.Paint) color29);
        java.awt.Paint paint32 = categoryPlot28.getOutlinePaint();
        org.jfree.chart.title.LegendGraphic legendGraphic33 = new org.jfree.chart.title.LegendGraphic(shape27, paint32);
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("PlotOrientation.VERTICAL", "Size2D[width=15.0, height=0.0]", "", "hi!", shape25, paint32);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(colorSpace30);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        boolean boolean7 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot0.getAxisOffset();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryPlot0.setNoDataMessageFont(font9);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        java.util.EventListener eventListener7 = null;
        boolean boolean8 = numberAxis1.hasListener(eventListener7);
        numberAxis1.setRangeWithMargins(1.0d, Double.NaN);
        numberAxis1.setAutoRangeIncludesZero(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand14 = numberAxis1.getMarkerBand();
        double double15 = numberAxis1.getFixedDimension();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(markerAxisBand14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        java.awt.Shape shape0 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3);
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, true);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener7 = null;
        defaultStatisticalCategoryDataset3.addChangeListener(datasetChangeListener7);
        java.lang.Number number11 = defaultStatisticalCategoryDataset3.getMeanValue((java.lang.Comparable) 15, (java.lang.Comparable) 1.0f);
        java.util.List list12 = defaultStatisticalCategoryDataset3.getRowKeys();
        java.lang.Number number13 = null;
        defaultStatisticalCategoryDataset3.add(number13, (java.lang.Number) 10, (java.lang.Comparable) "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", (java.lang.Comparable) 0.5f);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = new org.jfree.chart.axis.NumberTickUnit(3.0d);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double23 = numberAxis22.getLabelAngle();
        numberAxis22.setFixedDimension(0.0d);
        org.jfree.data.Range range26 = numberAxis22.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis22);
        numberAxis22.setUpperBound((double) '4');
        numberAxis22.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.axis.AxisState axisState34 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = null;
        java.util.List list37 = numberAxis22.refreshTicks(graphics2D32, axisState34, rectangle2D35, rectangleEdge36);
        boolean boolean38 = numberAxis22.isVerticalTickLabels();
        double double39 = numberAxis22.getLowerBound();
        boolean boolean40 = numberTickUnit20.equals((java.lang.Object) double39);
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity41 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "http://www.jfree.org/jfreechart/index.html", "java.awt.Color[r=128,g=128,b=0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) '#', (java.lang.Comparable) numberTickUnit20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertNull(range6);
        org.junit.Assert.assertNull(number11);
        org.junit.Assert.assertNotNull(list12);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertNotNull(list37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.block.LineBorder lineBorder0 = new org.jfree.chart.block.LineBorder();
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke6 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke6, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        boolean boolean13 = barRenderer0.getIncludeBaseInRange();
        barRenderer0.setBaseSeriesVisibleInLegend(true);
        java.awt.Paint paint16 = barRenderer0.getBaseOutlinePaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke22 = barRenderer21.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        barRenderer21.notifyListeners(rendererChangeEvent23);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = barRenderer21.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape26 = barRenderer21.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity27 = new org.jfree.chart.entity.LegendItemEntity(shape26);
        org.jfree.chart.block.BlockBorder blockBorder28 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean29 = legendItemEntity27.equals((java.lang.Object) blockBorder28);
        java.awt.Shape shape30 = legendItemEntity27.getArea();
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke32 = barRenderer31.getBaseStroke();
        java.awt.Font font33 = barRenderer31.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator36 = barRenderer31.getItemLabelGenerator((int) (byte) 0, (int) '4');
        java.awt.Stroke stroke37 = barRenderer31.getBaseStroke();
        java.awt.Color color38 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.lang.String str39 = color38.toString();
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("EXPAND", "", "SortOrder.ASCENDING", "RectangleConstraintType.RANGE", shape30, stroke37, (java.awt.Paint) color38);
        barRenderer0.setBaseFillPaint((java.awt.Paint) color38);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(blockBorder28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertNull(categoryItemLabelGenerator36);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "java.awt.Color[r=128,g=255,b=255]" + "'", str39.equals("java.awt.Color[r=128,g=255,b=255]"));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke2 = barRenderer1.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        barRenderer1.notifyListeners(rendererChangeEvent3);
        boolean boolean5 = barRenderer1.getAutoPopulateSeriesOutlinePaint();
        org.jfree.data.KeyedObject keyedObject6 = new org.jfree.data.KeyedObject((java.lang.Comparable) 98.0d, (java.lang.Object) barRenderer1);
        java.awt.Shape shape8 = barRenderer1.getSeriesShape(10);
        double double9 = barRenderer1.getMaximumBarWidth();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        int int1 = tickUnits0.size();
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double4 = numberAxis3.getLabelAngle();
        numberAxis3.setFixedDimension(0.0d);
        org.jfree.data.Range range7 = numberAxis3.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent8 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis3);
        numberAxis3.setUpperBound((double) '4');
        numberAxis3.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.axis.AxisState axisState15 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = null;
        java.util.List list18 = numberAxis3.refreshTicks(graphics2D13, axisState15, rectangle2D16, rectangleEdge17);
        boolean boolean19 = numberAxis3.isVerticalTickLabels();
        double double20 = numberAxis3.getLowerBound();
        boolean boolean21 = tickUnits0.equals((java.lang.Object) double20);
        java.lang.Object obj22 = tickUnits0.clone();
        java.lang.Object obj23 = tickUnits0.clone();
        try {
            org.jfree.chart.axis.TickUnit tickUnit25 = tickUnits0.getCeilingTickUnit((double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(range7);
        org.junit.Assert.assertNotNull(list18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(obj23);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean4 = numberAxis3.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke7 = barRenderer6.getBaseStroke();
        java.awt.Font font8 = barRenderer6.getBaseItemLabelFont();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean15 = color13.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color13);
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("{0}", font8, (java.awt.Paint) color13, (float) ' ');
        numberAxis3.setLabelFont(font8);
        valueMarker1.setLabelFont(font8);
        java.awt.Paint paint21 = valueMarker1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.Plot plot4 = categoryPlot0.getRootPlot();
        int int5 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double6 = numberAxis5.getLabelAngle();
        numberAxis5.setFixedDimension(0.0d);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        numberAxis5.setAxisLinePaint((java.awt.Paint) color9);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) (byte) 100, 0.0d, (double) 100L, (double) 0, (java.awt.Paint) color9);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = blockBorder13.getInsets();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        categoryPlot0.drawBackgroundImage(graphics2D3, rectangle2D7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis10, true);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot0.getDomainMarkers((int) (short) 1, layer14);
        java.awt.Paint paint16 = categoryPlot0.getRangeGridlinePaint();
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getLabelAngle();
        numberAxis2.setFixedDimension(0.0d);
        org.jfree.data.Range range6 = numberAxis2.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double9 = numberAxis8.getLabelAngle();
        numberAxis8.setFixedDimension(0.0d);
        org.jfree.data.Range range12 = numberAxis8.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range6, range12);
        double double14 = rectangleConstraint13.getHeight();
        boolean boolean15 = rectangleEdge0.equals((java.lang.Object) double14);
        org.junit.Assert.assertNotNull(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.util.SortOrder sortOrder3 = categoryPlot0.getRowRenderingOrder();
        org.junit.Assert.assertNotNull(sortOrder3);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) 8, 0.2d);
        org.jfree.chart.util.Size2D size2D5 = new org.jfree.chart.util.Size2D((double) (-1), (double) (-129));
        org.jfree.chart.util.Size2D size2D6 = rectangleConstraint2.calculateConstrainedSize(size2D5);
        org.junit.Assert.assertNotNull(size2D6);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getSeriesItemLabelGenerator((int) (short) 1);
        java.awt.Stroke stroke6 = barRenderer0.lookupSeriesOutlineStroke(1);
        barRenderer0.setBaseCreateEntities(false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape5 = barRenderer0.getBaseShape();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent6 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        categoryPlot1.setOutlinePaint((java.awt.Paint) color2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot1.setDomainAxis(categoryAxis5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.title.LegendTitle legendTitle9 = jFreeChart7.getLegend((-15423));
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNull(legendTitle9);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean4 = numberAxis3.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke7 = barRenderer6.getBaseStroke();
        java.awt.Font font8 = barRenderer6.getBaseItemLabelFont();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean15 = color13.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color13);
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("{0}", font8, (java.awt.Paint) color13, (float) ' ');
        numberAxis3.setLabelFont(font8);
        numberAxis3.setLowerBound(1.0E-8d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener22 = null;
        numberAxis3.removeChangeListener(axisChangeListener22);
        double double24 = numberAxis3.getLabelAngle();
        boolean boolean25 = categoryAxis1.equals((java.lang.Object) double24);
        categoryAxis1.setMaximumCategoryLabelWidthRatio(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker30 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace35 = color34.getColorSpace();
        categoryPlot33.setOutlinePaint((java.awt.Paint) color34);
        java.awt.Paint paint37 = categoryPlot33.getOutlinePaint();
        org.jfree.chart.title.LegendGraphic legendGraphic38 = new org.jfree.chart.title.LegendGraphic(shape32, paint37);
        valueMarker30.setPaint(paint37);
        java.awt.Paint paint40 = valueMarker30.getOutlinePaint();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 0.0f, paint40);
        float float42 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(colorSpace35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + float42 + "' != '" + 0.0f + "'", float42 == 0.0f);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = new org.jfree.chart.axis.CategoryLabelPositions();
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = barRenderer0.getItemLabelGenerator((int) (short) 10, (int) '#');
        java.awt.Color color16 = java.awt.Color.getHSBColor((float) '4', (float) 2, (float) (short) 0);
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color16);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = null;
        barRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator18);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator20, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double8 = numberAxis7.getLabelAngle();
        numberAxis7.setFixedDimension(0.0d);
        org.jfree.data.Range range11 = numberAxis7.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double14 = numberAxis13.getLabelAngle();
        numberAxis13.setFixedDimension(0.0d);
        org.jfree.data.Range range17 = numberAxis13.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(range11, range17);
        java.lang.String str19 = range11.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(range5, range11);
        double double21 = range5.getLength();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double24 = numberAxis23.getLabelAngle();
        numberAxis23.setFixedDimension(0.0d);
        org.jfree.data.Range range27 = numberAxis23.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent28 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis23);
        java.util.EventListener eventListener29 = null;
        boolean boolean30 = numberAxis23.hasListener(eventListener29);
        java.awt.Stroke stroke31 = numberAxis23.getTickMarkStroke();
        org.jfree.data.Range range32 = numberAxis23.getRange();
        org.jfree.data.Range range33 = org.jfree.data.Range.combine(range5, range32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Range[0.0,1.0]" + "'", str19.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range33);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color30);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double45 = numberAxis44.getLabelAngle();
        numberAxis44.setFixedDimension(0.0d);
        org.jfree.data.Range range48 = numberAxis44.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent49 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis44);
        java.awt.Shape shape50 = numberAxis44.getRightArrow();
        legendGraphic42.setLine(shape50);
        legendGraphic42.setWidth(0.0d);
        java.awt.Color color54 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean56 = color54.equals((java.lang.Object) 0.0d);
        legendGraphic42.setFillPaint((java.awt.Paint) color54);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = legendGraphic42.getPadding();
        double double60 = rectangleInsets58.trimWidth(0.0d);
        double double61 = rectangleInsets58.getLeft();
        double double63 = rectangleInsets58.calculateLeftInset((double) 3);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + (-4.0d) + "'", double60 == (-4.0d));
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 2.0d + "'", double61 == 2.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 2.0d + "'", double63 == 2.0d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        try {
            java.lang.Object obj1 = org.jfree.chart.util.ObjectUtilities.clone((java.lang.Object) color0);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint10 = barRenderer8.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer8.setSeriesURLGenerator(10, categoryURLGenerator12, true);
        boolean boolean15 = barRenderer8.getAutoPopulateSeriesStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color18 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace19 = color18.getColorSpace();
        categoryPlot17.setOutlinePaint((java.awt.Paint) color18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        categoryPlot17.setDomainAxis(categoryAxis21);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", (org.jfree.chart.plot.Plot) categoryPlot17);
        boolean boolean24 = barRenderer8.hasListener((java.util.EventListener) jFreeChart23);
        float float25 = jFreeChart23.getBackgroundImageAlpha();
        categoryPlot0.addChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart23);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(colorSpace19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 0.5f + "'", float25 == 0.5f);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint7 = barRenderer3.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke9 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke9, true);
        java.awt.Stroke stroke14 = barRenderer3.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer0.setBaseStroke(stroke14);
        boolean boolean16 = barRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Font font18 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        barRenderer0.setSeriesItemLabelFont((int) (short) 10, font18, true);
        boolean boolean21 = barRenderer0.isDrawBarOutline();
        double double22 = barRenderer0.getUpperClip();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis1.refreshTicks(graphics2D11, axisState13, rectangle2D14, rectangleEdge15);
        org.jfree.chart.util.UnitType unitType17 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean18 = numberAxis1.equals((java.lang.Object) unitType17);
        boolean boolean19 = numberAxis1.isTickMarksVisible();
        numberAxis1.setVerticalTickLabels(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis1.refreshTicks(graphics2D11, axisState13, rectangle2D14, rectangleEdge15);
        boolean boolean17 = numberAxis1.isVerticalTickLabels();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo21.getPlotArea();
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot18.zoomDomainAxes(0.05d, plotRenderingInfo21, point2D23);
        categoryPlot18.configureDomainAxes();
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        org.jfree.chart.LegendItemCollection legendItemCollection27 = categoryPlot18.getFixedLegendItems();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = categoryPlot18.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(rectangle2D22);
        org.junit.Assert.assertNull(legendItemCollection27);
        org.junit.Assert.assertNotNull(datasetRenderingOrder28);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        int int28 = legendItem27.getDatasetIndex();
        legendItem27.setDatasetIndex(15);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        boolean boolean7 = categoryPlot0.isOutlineVisible();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean14 = numberAxis13.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke17 = barRenderer16.getBaseStroke();
        java.awt.Font font18 = barRenderer16.getBaseItemLabelFont();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean25 = color23.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder26 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color23);
        org.jfree.chart.text.TextFragment textFragment28 = new org.jfree.chart.text.TextFragment("{0}", font18, (java.awt.Paint) color23, (float) ' ');
        numberAxis13.setLabelFont(font18);
        numberAxis13.setLowerBound(1.0E-8d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener32 = null;
        numberAxis13.removeChangeListener(axisChangeListener32);
        double double34 = numberAxis13.getLabelAngle();
        boolean boolean35 = categoryAxis11.equals((java.lang.Object) double34);
        double double36 = categoryAxis11.getLowerMargin();
        int int37 = categoryPlot0.getDomainAxisIndex(categoryAxis11);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.05d + "'", double36 == 0.05d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace10 = color9.getColorSpace();
        categoryPlot8.setOutlinePaint((java.awt.Paint) color9);
        java.awt.Paint paint12 = categoryPlot8.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        categoryPlot8.rendererChanged(rendererChangeEvent13);
        boolean boolean15 = categoryPlot8.isOutlineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = categoryPlot8.getAxisOffset();
        boolean boolean17 = barRenderer0.hasListener((java.util.EventListener) categoryPlot8);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = null;
        try {
            barRenderer0.setSeriesItemLabelGenerator((-129), categoryItemLabelGenerator19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = categoryPlot0.getDomainGridlinePosition();
        int int8 = categoryPlot0.getRangeAxisCount();
        categoryPlot0.clearDomainMarkers((int) '4');
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        java.lang.String str12 = plotOrientation11.toString();
        categoryPlot0.setOrientation(plotOrientation11);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "PlotOrientation.VERTICAL" + "'", str12.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean4 = numberAxis3.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke7 = barRenderer6.getBaseStroke();
        java.awt.Font font8 = barRenderer6.getBaseItemLabelFont();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean15 = color13.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color13);
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("{0}", font8, (java.awt.Paint) color13, (float) ' ');
        numberAxis3.setLabelFont(font8);
        valueMarker1.setLabelFont(font8);
        java.awt.Paint paint21 = valueMarker1.getOutlinePaint();
        java.awt.Paint paint22 = valueMarker1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("-3,-3,3,3");
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) 0L);
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        boolean boolean6 = rectangleAnchor0.equals((java.lang.Object) textBlockAnchor5);
        java.lang.String str7 = rectangleAnchor0.toString();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor8 = org.jfree.chart.text.TextBlockAnchor.CENTER_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke10 = barRenderer9.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        barRenderer9.notifyListeners(rendererChangeEvent11);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer9.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor14 = itemLabelPosition13.getTextAnchor();
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType16 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor8, textAnchor14, (double) 0.95f, categoryLabelWidthType16, (float) ' ');
        java.lang.String str19 = categoryLabelWidthType16.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str7.equals("RectangleAnchor.BOTTOM"));
        org.junit.Assert.assertNotNull(textBlockAnchor8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNotNull(textAnchor14);
        org.junit.Assert.assertNotNull(categoryLabelWidthType16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "CategoryLabelWidthType.RANGE" + "'", str19.equals("CategoryLabelWidthType.RANGE"));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) '#');
        axisState1.cursorLeft((double) 15);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (byte) 10);
        axisState1.cursorRight((double) 1);
        axisState1.setMax((double) (-1.0f));
        axisState1.cursorLeft((double) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image10 = null;
        categoryPlot9.setBackgroundImage(image10);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot9.zoomRangeAxes(0.0d, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot9.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot9.getDomainAxisEdge((int) (short) -1);
        axisState1.moveCursor(10.0d, rectangleEdge20);
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean26 = numberAxis25.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke29 = barRenderer28.getBaseStroke();
        java.awt.Font font30 = barRenderer28.getBaseItemLabelFont();
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean37 = color35.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder38 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color35);
        org.jfree.chart.text.TextFragment textFragment40 = new org.jfree.chart.text.TextFragment("{0}", font30, (java.awt.Paint) color35, (float) ' ');
        numberAxis25.setLabelFont(font30);
        numberAxis25.setLowerBound(1.0E-8d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener44 = null;
        numberAxis25.removeChangeListener(axisChangeListener44);
        double double46 = numberAxis25.getLabelAngle();
        boolean boolean47 = categoryAxis23.equals((java.lang.Object) double46);
        categoryAxis23.setMaximumCategoryLabelWidthRatio(0.0f);
        boolean boolean50 = rectangleEdge20.equals((java.lang.Object) 0.0f);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (short) 100, (double) ' ', (int) (short) 10, (java.lang.Comparable) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        numberAxis1.setTickMarksVisible(false);
        boolean boolean5 = numberAxis1.isAutoRange();
        numberAxis1.setRangeWithMargins((double) 0.0f, (double) 1L);
        java.text.NumberFormat numberFormat9 = numberAxis1.getNumberFormatOverride();
        java.awt.Shape shape10 = numberAxis1.getLeftArrow();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(numberFormat9);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("ThreadContext");
        labelBlock1.setPadding((-15361.0d), 0.0d, (double) '4', 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint5 = valueMarker4.getPaint();
        org.jfree.chart.util.Layer layer6 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker4, layer6);
        valueMarker4.setLabel("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        try {
            java.awt.image.BufferedImage bufferedImage10 = jFreeChart7.createBufferedImage(1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (1) and height (-1) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(rectangle2D4);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        boolean boolean2 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        boolean boolean7 = categoryPlot0.isOutlineVisible();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo12.getPlotArea();
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot9.zoomDomainAxes(0.05d, plotRenderingInfo12, point2D14);
        categoryPlot9.configureDomainAxes();
        int int17 = categoryPlot9.getRangeAxisCount();
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot9.setRowRenderingOrder(sortOrder18);
        categoryPlot0.setRowRenderingOrder(sortOrder18);
        boolean boolean21 = categoryPlot0.isSubplot();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 100, 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot0.getRangeMarkers(8, layer12);
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNull(collection13);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean7 = numberAxis6.isTickLabelsVisible();
        categoryPlot0.setRangeAxis(3, (org.jfree.chart.axis.ValueAxis) numberAxis6);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke13 = barRenderer12.getBaseStroke();
        java.awt.Font font14 = barRenderer12.getBaseItemLabelFont();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean21 = color19.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder22 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color19);
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("{0}", font14, (java.awt.Paint) color19, (float) ' ');
        java.awt.Font font25 = textFragment24.getFont();
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        categoryPlot27.setOutlinePaint((java.awt.Paint) color28);
        java.awt.Paint paint31 = categoryPlot27.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent32 = null;
        categoryPlot27.rendererChanged(rendererChangeEvent32);
        categoryPlot27.setRangeCrosshairValue((double) 3, true);
        org.jfree.chart.JFreeChart jFreeChart38 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font25, (org.jfree.chart.plot.Plot) categoryPlot27, false);
        jFreeChart38.setAntiAlias(true);
        categoryPlot0.removeChangeListener((org.jfree.chart.event.PlotChangeListener) jFreeChart38);
        org.jfree.chart.event.ChartProgressListener chartProgressListener42 = null;
        jFreeChart38.removeProgressListener(chartProgressListener42);
        org.junit.Assert.assertNull(categoryAxis3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertNotNull(paint31);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint5 = valueMarker4.getPaint();
        org.jfree.chart.util.Layer layer6 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker4, layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean15 = numberAxis14.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke18 = barRenderer17.getBaseStroke();
        java.awt.Font font19 = barRenderer17.getBaseItemLabelFont();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean26 = color24.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color24);
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("{0}", font19, (java.awt.Paint) color24, (float) ' ');
        numberAxis14.setLabelFont(font19);
        numberAxis14.setLowerBound(1.0E-8d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener33 = null;
        numberAxis14.removeChangeListener(axisChangeListener33);
        double double35 = numberAxis14.getLabelAngle();
        boolean boolean36 = categoryAxis12.equals((java.lang.Object) double35);
        categoryAxis12.setMaximumCategoryLabelWidthRatio(0.0f);
        org.jfree.chart.axis.CategoryAxis categoryAxis40 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        double double41 = categoryAxis40.getCategoryMargin();
        categoryAxis40.removeCategoryLabelToolTip((java.lang.Comparable) ' ');
        categoryAxis40.setCategoryMargin(15.0d);
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray46 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis8, categoryAxis10, categoryAxis12, categoryAxis40 };
        categoryPlot0.setDomainAxes(categoryAxisArray46);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.2d + "'", double41 == 0.2d);
        org.junit.Assert.assertNotNull(categoryAxisArray46);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        boolean boolean7 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double10 = numberAxis9.getLabelAngle();
        numberAxis9.setFixedDimension(0.0d);
        org.jfree.data.Range range13 = numberAxis9.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis9);
        categoryPlot0.axisChanged(axisChangeEvent14);
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier18 = categoryPlot0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(drawingSupplier18);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D5 = plotRenderingInfo3.getDataArea();
        try {
            shapeList0.setShape((-1), (java.awt.Shape) rectangle2D5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertNotNull(rectangle2D5);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint(2.0d, (double) (byte) -1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        numberAxis1.setTickMarksVisible(false);
        boolean boolean5 = numberAxis1.isAutoRange();
        org.jfree.chart.event.AxisChangeListener axisChangeListener6 = null;
        numberAxis1.removeChangeListener(axisChangeListener6);
        double double8 = numberAxis1.getAutoRangeMinimumSize();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0E-8d + "'", double8 == 1.0E-8d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 100, 0.0d, (double) 1L, (double) '4');
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (double) (byte) 0);
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = defaultStatisticalCategoryDataset0.hasListener(eventListener4);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 100.0f);
        org.jfree.data.general.PieDataset pieDataset9 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (int) ' ');
        org.jfree.data.Range range11 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertNotNull(pieDataset9);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("MINOR", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getInfo();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType2 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        boolean boolean6 = gradientPaintTransformType2.equals((java.lang.Object) numberAxis4);
        boolean boolean7 = projectInfo0.equals((java.lang.Object) numberAxis4);
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "http://www.jfree.org/jfreechart/index.html" + "'", str1.equals("http://www.jfree.org/jfreechart/index.html"));
        org.junit.Assert.assertNotNull(gradientPaintTransformType2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = barRenderer0.getItemLabelGenerator((int) (byte) 0, (int) '4');
        java.awt.Stroke stroke6 = barRenderer0.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = barRenderer0.getLegendItems();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo10);
        java.awt.geom.Rectangle2D rectangle2D12 = plotRenderingInfo11.getPlotArea();
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot8.zoomDomainAxes(0.05d, plotRenderingInfo11, point2D13);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint17 = null;
        barRenderer15.setSeriesFillPaint((int) '#', paint17, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = null;
        barRenderer15.setSeriesURLGenerator(0, categoryURLGenerator21, true);
        int int24 = categoryPlot8.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15);
        boolean boolean25 = legendItemCollection7.equals((java.lang.Object) categoryPlot8);
        java.awt.Image image26 = categoryPlot8.getBackgroundImage();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNull(rectangle2D12);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(image26);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setTickMarkInsideLength((float) 15);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image14 = null;
        categoryPlot13.setBackgroundImage(image14);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo17 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo17);
        java.awt.geom.Rectangle2D rectangle2D19 = plotRenderingInfo18.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D20 = plotRenderingInfo18.getDataArea();
        categoryPlot13.drawBackgroundImage(graphics2D16, rectangle2D20);
        numberAxis1.setDownArrow((java.awt.Shape) rectangle2D20);
        numberAxis1.setTickLabelsVisible(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNull(rectangle2D19);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint5 = valueMarker4.getPaint();
        org.jfree.chart.util.Layer layer6 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker4, layer6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getDomainAxisLocation();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.Color color2 = java.awt.Color.orange;
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) (-1L), (java.awt.Paint) color2);
        org.jfree.chart.axis.AxisSpace axisSpace6 = new org.jfree.chart.axis.AxisSpace();
        axisSpace6.setRight((double) '#');
        axisSpace6.setRight((double) (short) -1);
        axisSpace6.setRight((double) 1.0f);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo14.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D16 = plotRenderingInfo14.getDataArea();
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean19 = numberAxis18.isTickLabelsVisible();
        numberAxis18.setAutoRange(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit22 = numberAxis18.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean26 = numberAxis25.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double29 = numberAxis28.getLabelAngle();
        numberAxis28.setFixedDimension(0.0d);
        org.jfree.data.Range range32 = numberAxis28.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent33 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis28);
        java.util.EventListener eventListener34 = null;
        boolean boolean35 = numberAxis28.hasListener(eventListener34);
        java.awt.Stroke stroke36 = numberAxis28.getTickMarkStroke();
        org.jfree.data.Range range37 = numberAxis28.getRange();
        boolean boolean40 = range37.intersects((double) 2, (double) '#');
        numberAxis25.setRangeWithMargins(range37, false, true);
        boolean boolean44 = numberAxis25.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image47 = null;
        categoryPlot46.setBackgroundImage(image47);
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo50 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo50);
        java.awt.geom.Rectangle2D rectangle2D52 = plotRenderingInfo51.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D53 = plotRenderingInfo51.getDataArea();
        categoryPlot46.drawBackgroundImage(graphics2D49, rectangle2D53);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge56 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge55);
        double double57 = numberAxis25.valueToJava2D((double) 0.5f, rectangle2D53, rectangleEdge55);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str59 = rectangleEdge58.toString();
        double double60 = numberAxis18.lengthToJava2D((double) 2, rectangle2D53, rectangleEdge58);
        java.awt.geom.Rectangle2D rectangle2D61 = axisSpace6.expand(rectangle2D16, rectangle2D53);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge62);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge62);
        double double65 = categoryAxis0.getCategoryEnd((int) '#', (int) (short) 100, rectangle2D16, rectangleEdge64);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNull(rectangle2D15);
        org.junit.Assert.assertNotNull(rectangle2D16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(numberTickUnit22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNull(rectangle2D52);
        org.junit.Assert.assertNotNull(rectangle2D53);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertNotNull(rectangleEdge56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "RectangleEdge.LEFT" + "'", str59.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        boolean boolean7 = categoryPlot0.isOutlineVisible();
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo11 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo11);
        java.awt.geom.Rectangle2D rectangle2D13 = plotRenderingInfo12.getPlotArea();
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot9.zoomDomainAxes(0.05d, plotRenderingInfo12, point2D14);
        categoryPlot9.configureDomainAxes();
        int int17 = categoryPlot9.getRangeAxisCount();
        org.jfree.chart.util.SortOrder sortOrder18 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot9.setRowRenderingOrder(sortOrder18);
        categoryPlot0.setRowRenderingOrder(sortOrder18);
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = categoryPlot0.getDomainAxis();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(rectangle2D13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertNotNull(sortOrder18);
        org.junit.Assert.assertNull(categoryAxis21);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        java.awt.Paint paint28 = legendItem27.getLinePaint();
        java.lang.Comparable comparable29 = legendItem27.getSeriesKey();
        java.awt.Paint paint30 = legendItem27.getOutlinePaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke33 = barRenderer32.getBaseStroke();
        java.awt.Font font34 = barRenderer32.getBaseItemLabelFont();
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean41 = color39.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder42 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color39);
        org.jfree.chart.text.TextFragment textFragment44 = new org.jfree.chart.text.TextFragment("{0}", font34, (java.awt.Paint) color39, (float) ' ');
        boolean boolean45 = legendItem27.equals((java.lang.Object) textFragment44);
        java.lang.Comparable comparable46 = legendItem27.getSeriesKey();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(comparable29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNull(comparable46);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        categoryPlot0.configureDomainAxes();
        int int8 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets();
        categoryPlot0.setInsets(rectangleInsets9);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean14 = numberAxis13.isTickLabelsVisible();
        numberAxis13.setAutoRange(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit17 = numberAxis13.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean21 = numberAxis20.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double24 = numberAxis23.getLabelAngle();
        numberAxis23.setFixedDimension(0.0d);
        org.jfree.data.Range range27 = numberAxis23.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent28 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis23);
        java.util.EventListener eventListener29 = null;
        boolean boolean30 = numberAxis23.hasListener(eventListener29);
        java.awt.Stroke stroke31 = numberAxis23.getTickMarkStroke();
        org.jfree.data.Range range32 = numberAxis23.getRange();
        boolean boolean35 = range32.intersects((double) 2, (double) '#');
        numberAxis20.setRangeWithMargins(range32, false, true);
        boolean boolean39 = numberAxis20.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image42 = null;
        categoryPlot41.setBackgroundImage(image42);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo45);
        java.awt.geom.Rectangle2D rectangle2D47 = plotRenderingInfo46.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D48 = plotRenderingInfo46.getDataArea();
        categoryPlot41.drawBackgroundImage(graphics2D44, rectangle2D48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge50);
        double double52 = numberAxis20.valueToJava2D((double) 0.5f, rectangle2D48, rectangleEdge50);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str54 = rectangleEdge53.toString();
        double double55 = numberAxis13.lengthToJava2D((double) 2, rectangle2D48, rectangleEdge53);
        try {
            categoryPlot0.drawOutline(graphics2D11, rectangle2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(numberTickUnit17);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "RectangleEdge.LEFT" + "'", str54.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0, jFreeChart8, chartChangeEventType9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint13 = barRenderer11.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        barRenderer11.setSeriesURLGenerator(10, categoryURLGenerator15, true);
        boolean boolean18 = barRenderer11.getAutoPopulateSeriesStroke();
        java.awt.Paint paint20 = barRenderer11.lookupSeriesFillPaint(10);
        barRenderer0.setBaseFillPaint(paint20);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator22, true);
        boolean boolean26 = barRenderer0.isSeriesVisible(15);
        java.awt.Paint paint27 = barRenderer0.getBaseFillPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer30 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke31 = barRenderer30.getBaseStroke();
        java.awt.Font font32 = barRenderer30.getBaseItemLabelFont();
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean39 = color37.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder40 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color37);
        org.jfree.chart.text.TextFragment textFragment42 = new org.jfree.chart.text.TextFragment("{0}", font32, (java.awt.Paint) color37, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock43 = new org.jfree.chart.block.LabelBlock("ThreadContext", font32);
        java.awt.Font font44 = labelBlock43.getFont();
        barRenderer0.setBaseItemLabelFont(font44);
        barRenderer0.setIncludeBaseInRange(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(paint27);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(font32);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(font44);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        categoryPlot0.drawBackgroundImage(graphics2D3, rectangle2D7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis10, true);
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = barRenderer0.getItemLabelGenerator((int) (byte) 0, (int) '4');
        java.awt.Stroke stroke6 = barRenderer0.getBaseStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = barRenderer7.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer7.setBaseURLGenerator(categoryURLGenerator10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace14 = color13.getColorSpace();
        categoryPlot12.setOutlinePaint((java.awt.Paint) color13);
        java.awt.Paint paint16 = categoryPlot12.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        categoryPlot12.rendererChanged(rendererChangeEvent17);
        boolean boolean19 = categoryPlot12.isOutlineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double22 = numberAxis21.getLabelAngle();
        numberAxis21.setFixedDimension(0.0d);
        org.jfree.data.Range range25 = numberAxis21.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent26 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis21);
        categoryPlot12.axisChanged(axisChangeEvent26);
        barRenderer7.setPlot(categoryPlot12);
        barRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot12);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(colorSpace14);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(range25);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        categoryPlot2.setOutlinePaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = categoryPlot2.getOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("", font1, paint6, (float) 15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke10 = barRenderer9.getBaseStroke();
        java.awt.Font font11 = barRenderer9.getBaseItemLabelFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint16 = barRenderer12.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke18 = null;
        barRenderer12.setSeriesOutlineStroke(0, stroke18, true);
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean23 = color21.equals((java.lang.Object) 0.0d);
        barRenderer12.setBaseItemLabelPaint((java.awt.Paint) color21);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator25 = barRenderer12.getLegendItemToolTipGenerator();
        barRenderer12.setAutoPopulateSeriesOutlinePaint(false);
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        java.awt.Color color38 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color40 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double43 = numberAxis42.getLabelAngle();
        numberAxis42.setFixedDimension(0.0d);
        org.jfree.data.Range range46 = numberAxis42.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent47 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis42);
        java.util.EventListener eventListener48 = null;
        boolean boolean49 = numberAxis42.hasListener(eventListener48);
        java.awt.Stroke stroke50 = numberAxis42.getTickMarkStroke();
        java.awt.Shape shape54 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer55 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint57 = barRenderer55.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint59 = barRenderer55.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke61 = null;
        barRenderer55.setSeriesOutlineStroke(0, stroke61, true);
        java.awt.Stroke stroke66 = barRenderer55.getItemOutlineStroke((int) (byte) -1, 0);
        java.awt.Color color67 = java.awt.Color.CYAN;
        int int68 = color67.getRed();
        org.jfree.chart.LegendItem legendItem69 = new org.jfree.chart.LegendItem("{0}", "", "EXPAND", "hi!", false, shape36, true, (java.awt.Paint) color38, true, (java.awt.Paint) color40, stroke50, false, shape54, stroke66, (java.awt.Paint) color67);
        barRenderer12.setSeriesOutlineStroke(2, stroke66, true);
        barRenderer9.setBaseOutlineStroke(stroke66);
        org.jfree.chart.util.RectangleInsets rectangleInsets77 = new org.jfree.chart.util.RectangleInsets((double) 0, (double) 10, (double) 100L, (double) '4');
        org.jfree.chart.block.LineBorder lineBorder78 = new org.jfree.chart.block.LineBorder(paint6, stroke66, rectangleInsets77);
        java.awt.Stroke stroke79 = lineBorder78.getStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets80 = lineBorder78.getInsets();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator25);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNull(paint59);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(color67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(rectangleInsets80);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        java.awt.Font font5 = barRenderer3.getBaseItemLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}", font5, (java.awt.Paint) color10, (float) ' ');
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        categoryPlot18.setOutlinePaint((java.awt.Paint) color19);
        java.awt.Paint paint22 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot18.rendererChanged(rendererChangeEvent23);
        categoryPlot18.setRangeCrosshairValue((double) 3, true);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font16, (org.jfree.chart.plot.Plot) categoryPlot18, false);
        jFreeChart29.setAntiAlias(true);
        boolean boolean32 = jFreeChart29.isNotify();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_LEFT;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor2 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor3 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean5 = textAnchor3.equals((java.lang.Object) "{0}");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor2, textAnchor3);
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType8 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint11 = barRenderer9.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        barRenderer9.setSeriesURLGenerator(10, categoryURLGenerator13, true);
        boolean boolean16 = barRenderer9.getAutoPopulateSeriesStroke();
        java.awt.Paint paint18 = barRenderer9.lookupSeriesFillPaint(10);
        boolean boolean19 = categoryLabelWidthType8.equals((java.lang.Object) 10);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition21 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor3, 0.0d, categoryLabelWidthType8, 32.0f);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor2);
        org.junit.Assert.assertNotNull(textAnchor3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(categoryLabelWidthType8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge6);
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge6);
        int int9 = numberTickUnit5.compareTo((java.lang.Object) rectangleEdge6);
        try {
            double double10 = categoryAxis1.getCategoryStart((int) (short) 100, 0, rectangle2D4, rectangleEdge6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (byte) 10);
        axisState1.cursorRight((double) 1);
        axisState1.setMax((double) (-1.0f));
        double double6 = axisState1.getMax();
        axisState1.cursorUp((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-1.0d) + "'", double6 == (-1.0d));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1L));
        boolean boolean5 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color30);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double45 = numberAxis44.getLabelAngle();
        numberAxis44.setFixedDimension(0.0d);
        org.jfree.data.Range range48 = numberAxis44.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent49 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis44);
        java.awt.Shape shape50 = numberAxis44.getRightArrow();
        legendGraphic42.setLine(shape50);
        legendGraphic42.setWidth(0.0d);
        java.awt.Color color54 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean56 = color54.equals((java.lang.Object) 0.0d);
        legendGraphic42.setFillPaint((java.awt.Paint) color54);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = legendGraphic42.getPadding();
        boolean boolean59 = legendGraphic42.isShapeVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.block.RectangleConstraint rectangleConstraint0 = org.jfree.chart.block.RectangleConstraint.NONE;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = rectangleConstraint0.toFixedHeight((double) 10L);
        org.junit.Assert.assertNotNull(rectangleConstraint0);
        org.junit.Assert.assertNotNull(rectangleConstraint2);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        categoryPlot0.configureDomainAxes();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double10 = numberAxis9.getLabelAngle();
        numberAxis9.setFixedDimension(0.0d);
        org.jfree.data.Range range13 = numberAxis9.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis9);
        numberAxis9.setUpperBound((double) '4');
        numberAxis9.setAxisLineVisible(false);
        numberAxis9.setTickMarkInsideLength((float) 15);
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis9);
        boolean boolean22 = categoryPlot0.isRangeZoomable();
        categoryPlot0.setBackgroundAlpha((float) '#');
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer2.getBaseStroke();
        java.awt.Font font4 = barRenderer2.getBaseItemLabelFont();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("{0}", font4, (java.awt.Paint) color9, (float) ' ');
        java.awt.Font font15 = textFragment14.getFont();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge17);
        textTitle16.setPosition(rectangleEdge19);
        java.lang.String str21 = textTitle16.getURLText();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean24 = numberAxis23.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double27 = numberAxis26.getLabelAngle();
        numberAxis26.setFixedDimension(0.0d);
        org.jfree.data.Range range30 = numberAxis26.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent31 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis26);
        java.util.EventListener eventListener32 = null;
        boolean boolean33 = numberAxis26.hasListener(eventListener32);
        java.awt.Stroke stroke34 = numberAxis26.getTickMarkStroke();
        org.jfree.data.Range range35 = numberAxis26.getRange();
        boolean boolean38 = range35.intersects((double) 2, (double) '#');
        numberAxis23.setRangeWithMargins(range35, false, true);
        boolean boolean42 = numberAxis23.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image45 = null;
        categoryPlot44.setBackgroundImage(image45);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo48);
        java.awt.geom.Rectangle2D rectangle2D50 = plotRenderingInfo49.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D51 = plotRenderingInfo49.getDataArea();
        categoryPlot44.drawBackgroundImage(graphics2D47, rectangle2D51);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge53);
        double double55 = numberAxis23.valueToJava2D((double) 0.5f, rectangle2D51, rectangleEdge53);
        textTitle16.setBounds(rectangle2D51);
        org.jfree.chart.util.VerticalAlignment verticalAlignment57 = textTitle16.getVerticalAlignment();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment57);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        barRenderer3.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock1, textBlockAnchor2, textAnchor8, 0.0d);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock1.calculateDimensions(graphics2D11);
        size2D12.setWidth(3.0d);
        double double15 = size2D12.getHeight();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Paint paint6 = barRenderer0.lookupSeriesFillPaint((int) (byte) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint10 = barRenderer8.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer8.setSeriesURLGenerator(10, categoryURLGenerator12, true);
        boolean boolean15 = barRenderer8.getAutoPopulateSeriesStroke();
        java.awt.Paint paint17 = barRenderer8.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke19 = barRenderer18.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        barRenderer18.notifyListeners(rendererChangeEvent20);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer18.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape23 = barRenderer18.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity24 = new org.jfree.chart.entity.LegendItemEntity(shape23);
        barRenderer8.setBaseShape(shape23, true);
        barRenderer0.setSeriesShape(0, shape23, false);
        java.awt.Paint paint30 = null;
        barRenderer0.setSeriesOutlinePaint((int) (byte) 10, paint30, false);
        barRenderer0.setItemMargin(8.949999988079071d);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = null;
        barRenderer0.setSeriesFillPaint((int) '#', paint2, false);
        java.awt.Paint paint6 = barRenderer0.getSeriesFillPaint((int) (short) 100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener4 = null;
        defaultStatisticalCategoryDataset0.addChangeListener(datasetChangeListener4);
        java.lang.Number number8 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 15, (java.lang.Comparable) 1.0f);
        java.util.List list9 = defaultStatisticalCategoryDataset0.getRowKeys();
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_CYAN;
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke13 = barRenderer12.getBaseStroke();
        java.awt.Color color14 = java.awt.Color.cyan;
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint17 = barRenderer15.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint20 = barRenderer18.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint22 = barRenderer18.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke24 = null;
        barRenderer18.setSeriesOutlineStroke(0, stroke24, true);
        java.awt.Stroke stroke29 = barRenderer18.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer15.setBaseStroke(stroke29);
        org.jfree.chart.plot.ValueMarker valueMarker32 = new org.jfree.chart.plot.ValueMarker((double) 1L, (java.awt.Paint) color11, stroke13, (java.awt.Paint) color14, stroke29, 0.5f);
        org.jfree.chart.axis.NumberAxis numberAxis34 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double35 = numberAxis34.getLabelAngle();
        numberAxis34.setFixedDimension(0.0d);
        org.jfree.data.Range range38 = numberAxis34.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent39 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis34);
        numberAxis34.setUpperBound((double) '4');
        numberAxis34.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.axis.AxisState axisState46 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = null;
        java.util.List list49 = numberAxis34.refreshTicks(graphics2D44, axisState46, rectangle2D47, rectangleEdge48);
        boolean boolean50 = numberAxis34.isVerticalTickLabels();
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo53 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo54 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo53);
        java.awt.geom.Rectangle2D rectangle2D55 = plotRenderingInfo54.getPlotArea();
        java.awt.geom.Point2D point2D56 = null;
        categoryPlot51.zoomDomainAxes(0.05d, plotRenderingInfo54, point2D56);
        categoryPlot51.configureDomainAxes();
        numberAxis34.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot51);
        boolean boolean60 = color11.equals((java.lang.Object) categoryPlot51);
        boolean boolean61 = defaultStatisticalCategoryDataset0.hasListener((java.util.EventListener) categoryPlot51);
        int int62 = defaultStatisticalCategoryDataset0.getRowCount();
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertNotNull(list49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNull(rectangle2D55);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        java.awt.Font font1 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        java.awt.Paint paint2 = null;
        try {
            org.jfree.chart.text.TextLine textLine3 = new org.jfree.chart.text.TextLine("SortOrder.ASCENDING", font1, paint2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        java.awt.Font font0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        categoryPlot1.setOutlinePaint((java.awt.Paint) color2);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        categoryPlot1.setDomainAxis(categoryAxis5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart("PlotOrientation.VERTICAL", (org.jfree.chart.plot.Plot) categoryPlot1);
        jFreeChart7.setTextAntiAlias(true);
        jFreeChart7.setNotify(false);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace6 = color5.getColorSpace();
        categoryPlot4.setOutlinePaint((java.awt.Paint) color5);
        java.awt.Paint paint8 = categoryPlot4.getOutlinePaint();
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape3, paint8);
        valueMarker1.setPaint(paint8);
        java.awt.Stroke stroke11 = valueMarker1.getStroke();
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType12 = valueMarker1.getLabelOffsetType();
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(lengthAdjustmentType12);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Stroke stroke4 = categoryPlot0.getDomainGridlineStroke();
        boolean boolean5 = categoryPlot0.isRangeCrosshairVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint8 = barRenderer6.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = null;
        barRenderer6.setSeriesURLGenerator(10, categoryURLGenerator10, true);
        boolean boolean13 = barRenderer6.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke14 = barRenderer6.getBaseStroke();
        categoryPlot0.setOutlineStroke(stroke14);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean5 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke8 = barRenderer7.getBaseStroke();
        java.awt.Font font9 = barRenderer7.getBaseItemLabelFont();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean16 = color14.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color14);
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("{0}", font9, (java.awt.Paint) color14, (float) ' ');
        numberAxis4.setLabelFont(font9);
        valueMarker2.setLabelFont(font9);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset22 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable23 = null;
        int int24 = defaultStatisticalCategoryDataset22.getColumnIndex(comparable23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot25.setDomainAxis(categoryAxis26);
        defaultStatisticalCategoryDataset22.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot25);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("RangeType.FULL", font9, (org.jfree.chart.plot.Plot) categoryPlot25, true);
        java.util.List list31 = jFreeChart30.getSubtitles();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(list31);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double6 = numberAxis5.getLabelAngle();
        numberAxis5.setFixedDimension(0.0d);
        org.jfree.data.Range range9 = numberAxis5.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent10 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis5);
        numberAxis5.setUpperBound((double) '4');
        numberAxis5.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.axis.AxisState axisState17 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = null;
        java.util.List list20 = numberAxis5.refreshTicks(graphics2D15, axisState17, rectangle2D18, rectangleEdge19);
        org.jfree.chart.util.UnitType unitType21 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean22 = numberAxis5.equals((java.lang.Object) unitType21);
        boolean boolean23 = numberAxis5.getAutoRangeStickyZero();
        java.lang.Class<?> wildcardClass24 = numberAxis5.getClass();
        java.net.URL uRL25 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ChartChangeEventType.DATASET_UPDATED", (java.lang.Class) wildcardClass24);
        java.io.InputStream inputStream26 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("Range[0.0,1.0]", (java.lang.Class) wildcardClass24);
        java.net.URL uRL27 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("ChartChangeEventType.DATASET_UPDATED", (java.lang.Class) wildcardClass24);
        java.net.URL uRL28 = org.jfree.chart.util.ObjectUtilities.getResource("ChartChangeEventType.DATASET_UPDATED", (java.lang.Class) wildcardClass24);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertNotNull(list20);
        org.junit.Assert.assertNotNull(unitType21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNull(uRL25);
        org.junit.Assert.assertNull(inputStream26);
        org.junit.Assert.assertNull(uRL27);
        org.junit.Assert.assertNull(uRL28);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1L));
        int int5 = defaultStatisticalCategoryDataset0.getColumnCount();
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("java.awt.Color[r=128,g=255,b=255]", "", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "Range[0.0,1.0]");
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        categoryPlot2.setOutlinePaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = categoryPlot2.getOutlinePaint();
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape1, paint6);
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer8 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendGraphic7.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer8);
        boolean boolean11 = standardGradientPaintTransformer8.equals((java.lang.Object) "Range[0.0,1.0]");
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        categoryPlot0.setDomainAxis(categoryAxis1);
        org.jfree.chart.plot.ValueMarker valueMarker4 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint5 = valueMarker4.getPaint();
        org.jfree.chart.util.Layer layer6 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker4, layer6);
        categoryPlot0.setRangeGridlinesVisible(false);
        boolean boolean10 = categoryPlot0.isRangeCrosshairVisible();
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer1.setSeriesURLGenerator(10, categoryURLGenerator5, true);
        boolean boolean8 = barRenderer1.getAutoPopulateSeriesStroke();
        java.awt.Paint paint10 = barRenderer1.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke12 = barRenderer11.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer11.notifyListeners(rendererChangeEvent13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer11.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape16 = barRenderer11.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity17 = new org.jfree.chart.entity.LegendItemEntity(shape16);
        barRenderer1.setBaseShape(shape16, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity22 = new org.jfree.chart.entity.TickLabelEntity(shape16, "java.awt.Color[r=128,g=128,b=0]", "");
        boolean boolean23 = categoryLabelPositions0.equals((java.lang.Object) "java.awt.Color[r=128,g=128,b=0]");
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint26 = barRenderer24.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator28 = null;
        barRenderer24.setSeriesURLGenerator(10, categoryURLGenerator28, true);
        boolean boolean31 = barRenderer24.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart32 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType33 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent34 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer24, jFreeChart32, chartChangeEventType33);
        org.jfree.chart.renderer.category.BarRenderer barRenderer35 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint37 = barRenderer35.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator39 = null;
        barRenderer35.setSeriesURLGenerator(10, categoryURLGenerator39, true);
        boolean boolean42 = barRenderer35.getAutoPopulateSeriesStroke();
        java.awt.Paint paint44 = barRenderer35.lookupSeriesFillPaint(10);
        barRenderer24.setBaseFillPaint(paint44);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator46 = null;
        barRenderer24.setBaseItemLabelGenerator(categoryItemLabelGenerator46, true);
        boolean boolean50 = barRenderer24.isSeriesVisible(15);
        boolean boolean51 = categoryLabelPositions0.equals((java.lang.Object) 15);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition53 = categoryLabelPositions0.getLabelPosition(rectangleEdge52);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset54 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number55 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset54);
        org.jfree.data.Range range57 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset54, true);
        org.jfree.data.general.PieDataset pieDataset59 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset54, (int) '#');
        org.jfree.data.general.PieDataset pieDataset62 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset59, (java.lang.Comparable) 2.0d, (double) 100);
        boolean boolean63 = categoryLabelPositions0.equals((java.lang.Object) pieDataset59);
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType33);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paint44);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertNotNull(categoryLabelPosition53);
        org.junit.Assert.assertEquals((double) number55, Double.NaN, 0);
        org.junit.Assert.assertNull(range57);
        org.junit.Assert.assertNotNull(pieDataset59);
        org.junit.Assert.assertNotNull(pieDataset62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("JFreeChart");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name JFreeChart, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape5 = barRenderer0.getBaseShape();
        java.awt.Color color7 = java.awt.Color.CYAN;
        int int8 = color7.getRed();
        java.awt.Color color9 = color7.darker();
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 1, (java.awt.Paint) color9);
        boolean boolean11 = barRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        boolean boolean11 = barRenderer0.isSeriesVisibleInLegend((int) (short) 1);
        barRenderer0.setBaseCreateEntities(true);
        java.awt.Shape shape15 = null;
        barRenderer0.setSeriesShape((int) (byte) 1, shape15, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color30);
        java.awt.Paint paint43 = null;
        legendGraphic42.setFillPaint(paint43);
        java.awt.Paint paint45 = legendGraphic42.getOutlinePaint();
        boolean boolean46 = legendGraphic42.isShapeVisible();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor47 = legendGraphic42.getShapeLocation();
        legendGraphic42.setShapeVisible(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertNull(paint45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(rectangleAnchor47);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("ChartChangeEventType.DATASET_UPDATED");
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis1.refreshTicks(graphics2D11, axisState13, rectangle2D14, rectangleEdge15);
        boolean boolean17 = numberAxis1.isVerticalTickLabels();
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean21 = numberAxis20.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double24 = numberAxis23.getLabelAngle();
        numberAxis23.setFixedDimension(0.0d);
        org.jfree.data.Range range27 = numberAxis23.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent28 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis23);
        java.util.EventListener eventListener29 = null;
        boolean boolean30 = numberAxis23.hasListener(eventListener29);
        java.awt.Stroke stroke31 = numberAxis23.getTickMarkStroke();
        org.jfree.data.Range range32 = numberAxis23.getRange();
        boolean boolean35 = range32.intersects((double) 2, (double) '#');
        numberAxis20.setRangeWithMargins(range32, false, true);
        boolean boolean39 = numberAxis20.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image42 = null;
        categoryPlot41.setBackgroundImage(image42);
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo45 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo46 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo45);
        java.awt.geom.Rectangle2D rectangle2D47 = plotRenderingInfo46.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D48 = plotRenderingInfo46.getDataArea();
        categoryPlot41.drawBackgroundImage(graphics2D44, rectangle2D48);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge50);
        double double52 = numberAxis20.valueToJava2D((double) 0.5f, rectangle2D48, rectangleEdge50);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = null;
        double double54 = numberAxis1.valueToJava2D(0.0d, rectangle2D48, rectangleEdge53);
        org.jfree.data.Range range55 = numberAxis1.getRange();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(rectangle2D47);
        org.junit.Assert.assertNotNull(rectangle2D48);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(rectangleEdge51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(range55);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("EXPAND", "DatasetRenderingOrder.FORWARD", "VerticalAlignment.CENTER", "DatasetRenderingOrder.FORWARD");
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint7 = barRenderer5.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer5.setSeriesURLGenerator(10, categoryURLGenerator9, true);
        boolean boolean12 = barRenderer5.getAutoPopulateSeriesStroke();
        java.awt.Paint paint14 = barRenderer5.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke16 = barRenderer15.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent17 = null;
        barRenderer15.notifyListeners(rendererChangeEvent17);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = barRenderer15.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape20 = barRenderer15.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity21 = new org.jfree.chart.entity.LegendItemEntity(shape20);
        barRenderer5.setBaseShape(shape20, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity26 = new org.jfree.chart.entity.TickLabelEntity(shape20, "java.awt.Color[r=128,g=128,b=0]", "");
        boolean boolean27 = basicProjectInfo4.equals((java.lang.Object) shape20);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        java.lang.String str1 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.BOTTOM" + "'", str1.equals("VerticalAlignment.BOTTOM"));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (double) (byte) 0);
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = defaultStatisticalCategoryDataset0.hasListener(eventListener4);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 100.0f);
        int int9 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) 0);
        int int10 = defaultStatisticalCategoryDataset0.getRowCount();
        int int11 = defaultStatisticalCategoryDataset0.getRowCount();
        org.jfree.data.Range range13 = defaultStatisticalCategoryDataset0.getRangeBounds(true);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNull(range13);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke6 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke6, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        boolean boolean13 = barRenderer0.getIncludeBaseInRange();
        java.awt.Color color15 = java.awt.Color.LIGHT_GRAY;
        barRenderer0.setSeriesOutlinePaint(100, (java.awt.Paint) color15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint24 = barRenderer22.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator26 = null;
        barRenderer22.setSeriesURLGenerator(10, categoryURLGenerator26, true);
        boolean boolean29 = barRenderer22.getAutoPopulateSeriesStroke();
        java.awt.Paint paint31 = barRenderer22.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke33 = barRenderer32.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        barRenderer32.notifyListeners(rendererChangeEvent34);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = barRenderer32.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape37 = barRenderer32.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity38 = new org.jfree.chart.entity.LegendItemEntity(shape37);
        barRenderer22.setBaseShape(shape37, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity43 = new org.jfree.chart.entity.TickLabelEntity(shape37, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color44 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape37, (java.awt.Paint) color44);
        int int46 = legendItem45.getSeriesIndex();
        java.awt.Shape shape47 = legendItem45.getLine();
        barRenderer0.setSeriesShape(1, shape47, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(shape47);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        numberAxis1.setTickMarksVisible(false);
        boolean boolean5 = numberAxis1.isAutoRange();
        java.awt.Paint paint6 = numberAxis1.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double9 = numberAxis8.getLabelAngle();
        numberAxis8.setFixedDimension(0.0d);
        org.jfree.data.Range range12 = numberAxis8.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis8);
        java.util.EventListener eventListener14 = null;
        boolean boolean15 = numberAxis8.hasListener(eventListener14);
        java.awt.Stroke stroke16 = numberAxis8.getTickMarkStroke();
        org.jfree.data.Range range17 = numberAxis8.getRange();
        boolean boolean20 = range17.intersects((double) 2, (double) '#');
        numberAxis1.setRange(range17, true, false);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean26 = numberAxis25.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double29 = numberAxis28.getLabelAngle();
        numberAxis28.setFixedDimension(0.0d);
        org.jfree.data.Range range32 = numberAxis28.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent33 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis28);
        java.util.EventListener eventListener34 = null;
        boolean boolean35 = numberAxis28.hasListener(eventListener34);
        java.awt.Stroke stroke36 = numberAxis28.getTickMarkStroke();
        org.jfree.data.Range range37 = numberAxis28.getRange();
        boolean boolean40 = range37.intersects((double) 2, (double) '#');
        numberAxis25.setRangeWithMargins(range37, false, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint(range17, range37);
        org.jfree.chart.axis.TickUnits tickUnits45 = new org.jfree.chart.axis.TickUnits();
        java.lang.Object obj46 = tickUnits45.clone();
        boolean boolean47 = range37.equals(obj46);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape((int) (short) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        barRenderer3.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape8 = barRenderer3.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.chart.block.BlockBorder blockBorder10 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean11 = legendItemEntity9.equals((java.lang.Object) blockBorder10);
        java.lang.String str12 = legendItemEntity9.toString();
        java.awt.Shape shape13 = legendItemEntity9.getArea();
        boolean boolean14 = shapeList0.equals((java.lang.Object) legendItemEntity9);
        org.junit.Assert.assertNull(shape2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(blockBorder10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str12.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        numberAxis1.setTickMarkInsideLength((float) 100L);
        org.jfree.chart.axis.TickUnits tickUnits5 = new org.jfree.chart.axis.TickUnits();
        int int6 = tickUnits5.size();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = barRenderer7.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint11 = barRenderer7.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke13 = null;
        barRenderer7.setSeriesOutlineStroke(0, stroke13, true);
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean18 = color16.equals((java.lang.Object) 0.0d);
        barRenderer7.setBaseItemLabelPaint((java.awt.Paint) color16);
        java.awt.Color color21 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel22 = null;
        java.awt.Rectangle rectangle23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        java.awt.geom.AffineTransform affineTransform25 = null;
        java.awt.RenderingHints renderingHints26 = null;
        java.awt.PaintContext paintContext27 = color21.createContext(colorModel22, rectangle23, rectangle2D24, affineTransform25, renderingHints26);
        barRenderer7.setSeriesOutlinePaint((int) (byte) 1, (java.awt.Paint) color21);
        boolean boolean29 = tickUnits5.equals((java.lang.Object) (byte) 1);
        numberAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(paintContext27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = barRenderer0.getItemLabelGenerator((int) (byte) 0, (int) '4');
        java.awt.Shape shape8 = org.jfree.chart.util.ShapeUtilities.createUpTriangle((float) (-15423));
        barRenderer0.setSeriesShape(2, shape8);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Paint paint6 = barRenderer0.lookupSeriesFillPaint((int) (byte) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint10 = barRenderer8.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer8.setSeriesURLGenerator(10, categoryURLGenerator12, true);
        boolean boolean15 = barRenderer8.getAutoPopulateSeriesStroke();
        java.awt.Paint paint17 = barRenderer8.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke19 = barRenderer18.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        barRenderer18.notifyListeners(rendererChangeEvent20);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer18.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape23 = barRenderer18.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity24 = new org.jfree.chart.entity.LegendItemEntity(shape23);
        barRenderer8.setBaseShape(shape23, true);
        barRenderer0.setSeriesShape(0, shape23, false);
        java.awt.Paint paint30 = null;
        barRenderer0.setSeriesOutlinePaint((int) (byte) 10, paint30, false);
        java.awt.Shape shape33 = barRenderer0.getBaseShape();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        java.lang.Number number0 = org.jfree.chart.plot.Plot.ZERO;
        org.junit.Assert.assertTrue("'" + number0 + "' != '" + 0 + "'", number0.equals(0));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        boolean boolean7 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.util.Layer layer9 = null;
        java.util.Collection collection10 = categoryPlot0.getDomainMarkers((-8355840), layer9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint16 = barRenderer12.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Paint paint17 = barRenderer12.getBaseItemLabelPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint20 = barRenderer18.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint23 = barRenderer21.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint25 = barRenderer21.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke27 = null;
        barRenderer21.setSeriesOutlineStroke(0, stroke27, true);
        java.awt.Stroke stroke32 = barRenderer21.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer18.setBaseStroke(stroke32);
        barRenderer12.setBaseOutlineStroke(stroke32);
        categoryPlot0.setRenderer((int) (byte) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(collection10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(stroke32);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        java.awt.Font font5 = barRenderer3.getBaseItemLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}", font5, (java.awt.Paint) color10, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("ThreadContext", font5);
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double19 = numberAxis18.getLabelAngle();
        numberAxis18.setFixedDimension(0.0d);
        org.jfree.data.Range range22 = numberAxis18.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent23 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis18);
        numberAxis18.setUpperBound((double) '4');
        numberAxis18.setAxisLineVisible(false);
        numberAxis18.setTickMarkInsideLength((float) 15);
        double double30 = numberAxis18.getLabelAngle();
        java.awt.Shape shape32 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace35 = color34.getColorSpace();
        categoryPlot33.setOutlinePaint((java.awt.Paint) color34);
        java.awt.Paint paint37 = categoryPlot33.getOutlinePaint();
        org.jfree.chart.title.LegendGraphic legendGraphic38 = new org.jfree.chart.title.LegendGraphic(shape32, paint37);
        numberAxis18.setRightArrow(shape32);
        java.awt.Font font40 = numberAxis18.getLabelFont();
        labelBlock16.setFont(font40);
        org.jfree.chart.title.TextTitle textTitle42 = new org.jfree.chart.title.TextTitle("RectangleEdge.LEFT", font40);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(shape32);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(colorSpace35);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(font40);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (-4.0d), (double) ' ');
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint7 = barRenderer5.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint10 = barRenderer8.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint12 = barRenderer8.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke14 = null;
        barRenderer8.setSeriesOutlineStroke(0, stroke14, true);
        java.awt.Stroke stroke19 = barRenderer8.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer5.setBaseStroke(stroke19);
        boolean boolean21 = barRenderer5.getAutoPopulateSeriesPaint();
        boolean boolean22 = columnArrangement4.equals((java.lang.Object) boolean21);
        org.jfree.chart.block.BlockContainer blockContainer23 = null;
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint25 = null;
        try {
            org.jfree.chart.util.Size2D size2D26 = columnArrangement4.arrange(blockContainer23, graphics2D24, rectangleConstraint25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.LegendItem legendItem12 = barRenderer0.getLegendItem((int) ' ', 1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition();
        double double14 = itemLabelPosition13.getAngle();
        org.jfree.chart.text.TextAnchor textAnchor15 = itemLabelPosition13.getRotationAnchor();
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition13, true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(legendItem12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(textAnchor15);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.Plot plot4 = categoryPlot0.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint7 = valueMarker6.getPaint();
        java.awt.Stroke stroke8 = valueMarker6.getStroke();
        org.jfree.chart.util.Layer layer9 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker6, layer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double13 = numberAxis12.getLabelAngle();
        numberAxis12.setFixedDimension(0.0d);
        org.jfree.data.Range range16 = numberAxis12.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis12);
        numberAxis12.setUpperBound((double) '4');
        numberAxis12.setAxisLineVisible(false);
        numberAxis12.setTickMarkInsideLength((float) 15);
        double double24 = numberAxis12.getLabelAngle();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        categoryPlot27.setOutlinePaint((java.awt.Paint) color28);
        java.awt.Paint paint31 = categoryPlot27.getOutlinePaint();
        org.jfree.chart.title.LegendGraphic legendGraphic32 = new org.jfree.chart.title.LegendGraphic(shape26, paint31);
        numberAxis12.setRightArrow(shape26);
        java.awt.Font font34 = numberAxis12.getLabelFont();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo38);
        java.awt.geom.Rectangle2D rectangle2D40 = plotRenderingInfo39.getPlotArea();
        java.awt.geom.Point2D point2D41 = null;
        categoryPlot36.zoomDomainAxes(0.05d, plotRenderingInfo39, point2D41);
        categoryPlot36.configureDomainAxes();
        int int44 = categoryPlot36.getRangeAxisCount();
        org.jfree.chart.util.SortOrder sortOrder45 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot36.setRowRenderingOrder(sortOrder45);
        categoryPlot0.setColumnRenderingOrder(sortOrder45);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = categoryPlot0.getRenderer();
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertNull(categoryItemRenderer48);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) "{0}");
        java.lang.String str4 = textAnchor1.toString();
        boolean boolean5 = keyedObjects0.equals((java.lang.Object) str4);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean9 = numberAxis8.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke12 = barRenderer11.getBaseStroke();
        java.awt.Font font13 = barRenderer11.getBaseItemLabelFont();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean20 = color18.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color18);
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("{0}", font13, (java.awt.Paint) color18, (float) ' ');
        numberAxis8.setLabelFont(font13);
        numberAxis8.setLabelToolTip("");
        org.jfree.data.Range range27 = numberAxis8.getRange();
        keyedObjects0.setObject((java.lang.Comparable) "RectangleEdge.LEFT", (java.lang.Object) range27);
        java.lang.Object obj30 = keyedObjects0.getObject((java.lang.Comparable) "Range[0.0,1.0]");
        keyedObjects0.setObject((java.lang.Comparable) "CategoryLabelWidthType.RANGE", (java.lang.Object) (-15423));
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str4.equals("TextAnchor.BOTTOM_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNull(obj30);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        java.awt.Shape shape0 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset3 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (int) '#');
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) (short) 100);
        java.lang.Number number10 = defaultStatisticalCategoryDataset3.getStdDevValue((java.lang.Comparable) 3, (java.lang.Comparable) 1L);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean13 = numberAxis12.isTickLabelsVisible();
        numberAxis12.setAutoRange(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit16 = numberAxis12.getTickUnit();
        java.lang.String str17 = numberTickUnit16.toString();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit19 = new org.jfree.chart.axis.NumberTickUnit(3.0d);
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity20 = new org.jfree.chart.entity.CategoryItemEntity(shape0, "VerticalAlignment.CENTER", "SortOrder.ASCENDING", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset3, (java.lang.Comparable) str17, (java.lang.Comparable) numberTickUnit19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertNull(number10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(numberTickUnit16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "[size=1]" + "'", str17.equals("[size=1]"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        keyedObjects2D0.setObject((java.lang.Object) 0.2d, (java.lang.Comparable) numberTickUnit2, (java.lang.Comparable) 10);
        keyedObjects2D0.addObject((java.lang.Object) 2.0d, (java.lang.Comparable) 1, (java.lang.Comparable) 100);
        org.jfree.chart.axis.AxisState axisState10 = new org.jfree.chart.axis.AxisState(10.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        axisState10.moveCursor(1.0d, rectangleEdge12);
        double double14 = axisState10.getMax();
        keyedObjects2D0.addObject((java.lang.Object) axisState10, (java.lang.Comparable) 'a', (java.lang.Comparable) (-1));
        java.lang.Object obj20 = keyedObjects2D0.getObject((java.lang.Comparable) "HorizontalAlignment.CENTER", (java.lang.Comparable) 100.0f);
        int int22 = keyedObjects2D0.getRowIndex((java.lang.Comparable) '4');
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNull(obj20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        java.awt.Font font6 = barRenderer4.getBaseItemLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("{0}", font6, (java.awt.Paint) color11, (float) ' ');
        numberAxis1.setLabelFont(font6);
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setFixedAutoRange(100.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.plot.ValueMarker valueMarker2 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean5 = numberAxis4.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke8 = barRenderer7.getBaseStroke();
        java.awt.Font font9 = barRenderer7.getBaseItemLabelFont();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean16 = color14.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder17 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color14);
        org.jfree.chart.text.TextFragment textFragment19 = new org.jfree.chart.text.TextFragment("{0}", font9, (java.awt.Paint) color14, (float) ' ');
        numberAxis4.setLabelFont(font9);
        valueMarker2.setLabelFont(font9);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset22 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Comparable comparable23 = null;
        int int24 = defaultStatisticalCategoryDataset22.getColumnIndex(comparable23);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        categoryPlot25.setDomainAxis(categoryAxis26);
        defaultStatisticalCategoryDataset22.addChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot25);
        org.jfree.chart.JFreeChart jFreeChart30 = new org.jfree.chart.JFreeChart("RangeType.FULL", font9, (org.jfree.chart.plot.Plot) categoryPlot25, true);
        jFreeChart30.clearSubtitles();
        org.jfree.chart.plot.Plot plot32 = jFreeChart30.getPlot();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke35 = barRenderer34.getBaseStroke();
        java.awt.Font font36 = barRenderer34.getBaseItemLabelFont();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator37 = barRenderer34.getLegendItemURLGenerator();
        java.awt.Paint paint39 = barRenderer34.getSeriesFillPaint((int) (short) 0);
        org.jfree.chart.title.LegendTitle legendTitle40 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer34);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = legendTitle40.getLegendItemGraphicPadding();
        java.awt.geom.Rectangle2D rectangle2D42 = legendTitle40.getBounds();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo43 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo43);
        java.awt.geom.Rectangle2D rectangle2D45 = plotRenderingInfo44.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D46 = plotRenderingInfo44.getDataArea();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition47 = new org.jfree.chart.axis.CategoryLabelPosition();
        float float48 = categoryLabelPosition47.getWidthRatio();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = categoryLabelPosition47.getCategoryAnchor();
        java.awt.geom.Point2D point2D50 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D46, rectangleAnchor49);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo51 = null;
        try {
            jFreeChart30.draw(graphics2D33, rectangle2D42, point2D50, chartRenderingInfo51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(plot32);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator37);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertNull(rectangle2D45);
        org.junit.Assert.assertNotNull(rectangle2D46);
        org.junit.Assert.assertTrue("'" + float48 + "' != '" + 0.95f + "'", float48 == 0.95f);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(point2D50);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 100, 0);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor10 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertNotNull(categoryAnchor10);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        barRenderer3.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock1, textBlockAnchor2, textAnchor8, 0.0d);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock1.calculateDimensions(graphics2D11);
        java.lang.String str13 = size2D12.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str13.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Paint paint5 = barRenderer0.getSeriesFillPaint((int) (short) 0);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean14 = color12.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder15 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color12);
        java.awt.Color color16 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color18 = java.awt.Color.CYAN;
        java.awt.Color color19 = java.awt.Color.CYAN;
        java.awt.Color color20 = java.awt.Color.red;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color12, color16, color17, color18, color19, color20 };
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint[] paintArray23 = new java.awt.Paint[] { color22 };
        java.awt.Stroke[] strokeArray24 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke25 = null;
        java.awt.Stroke[] strokeArray26 = new java.awt.Stroke[] { stroke25 };
        java.awt.Shape shape27 = null;
        java.awt.Shape[] shapeArray28 = new java.awt.Shape[] { shape27 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray21, paintArray23, strokeArray24, strokeArray26, shapeArray28);
        boolean boolean30 = datasetRenderingOrder7.equals((java.lang.Object) defaultDrawingSupplier29);
        java.awt.Paint paint31 = defaultDrawingSupplier29.getNextPaint();
        java.awt.Paint paint32 = defaultDrawingSupplier29.getNextPaint();
        barRenderer0.setBaseFillPaint(paint32);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(paintArray23);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(strokeArray26);
        org.junit.Assert.assertNotNull(shapeArray28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(paint32);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.block.CenterArrangement centerArrangement0 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer1.setSeriesURLGenerator(10, categoryURLGenerator5, true);
        boolean boolean8 = barRenderer1.getAutoPopulateSeriesStroke();
        java.awt.Paint paint10 = barRenderer1.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke12 = barRenderer11.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer11.notifyListeners(rendererChangeEvent13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer11.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape16 = barRenderer11.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity17 = new org.jfree.chart.entity.LegendItemEntity(shape16);
        barRenderer1.setBaseShape(shape16, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity22 = new org.jfree.chart.entity.TickLabelEntity(shape16, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer24 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke25 = barRenderer24.getBaseStroke();
        java.awt.Font font26 = barRenderer24.getBaseItemLabelFont();
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean33 = color31.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder34 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color31);
        org.jfree.chart.text.TextFragment textFragment36 = new org.jfree.chart.text.TextFragment("{0}", font26, (java.awt.Paint) color31, (float) ' ');
        java.awt.image.ColorModel colorModel37 = null;
        java.awt.Rectangle rectangle38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        java.awt.geom.AffineTransform affineTransform40 = null;
        java.awt.RenderingHints renderingHints41 = null;
        java.awt.PaintContext paintContext42 = color31.createContext(colorModel37, rectangle38, rectangle2D39, affineTransform40, renderingHints41);
        org.jfree.chart.title.LegendGraphic legendGraphic43 = new org.jfree.chart.title.LegendGraphic(shape16, (java.awt.Paint) color31);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double46 = numberAxis45.getLabelAngle();
        numberAxis45.setFixedDimension(0.0d);
        org.jfree.data.Range range49 = numberAxis45.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent50 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis45);
        java.awt.Shape shape51 = numberAxis45.getRightArrow();
        legendGraphic43.setLine(shape51);
        legendGraphic43.setWidth(0.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer55 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint57 = barRenderer55.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer58 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint60 = barRenderer58.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint62 = barRenderer58.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke64 = null;
        barRenderer58.setSeriesOutlineStroke(0, stroke64, true);
        java.awt.Stroke stroke69 = barRenderer58.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer55.setBaseStroke(stroke69);
        legendGraphic43.setOutlineStroke(stroke69);
        java.awt.Stroke stroke72 = legendGraphic43.getLineStroke();
        java.awt.Shape shape73 = null;
        legendGraphic43.setLine(shape73);
        org.jfree.chart.axis.NumberAxis numberAxis76 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean77 = numberAxis76.isTickLabelsVisible();
        java.awt.Paint paint78 = numberAxis76.getAxisLinePaint();
        numberAxis76.setLabelToolTip("ChartChangeEventType.DATASET_UPDATED");
        centerArrangement0.add((org.jfree.chart.block.Block) legendGraphic43, (java.lang.Object) numberAxis76);
        centerArrangement0.clear();
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(paintContext42);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(paint57);
        org.junit.Assert.assertNotNull(paint60);
        org.junit.Assert.assertNull(paint62);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNull(stroke72);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(paint78);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("-3,-3,3,3", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.Plot plot4 = categoryPlot0.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint7 = valueMarker6.getPaint();
        java.awt.Stroke stroke8 = valueMarker6.getStroke();
        org.jfree.chart.util.Layer layer9 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker6, layer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double13 = numberAxis12.getLabelAngle();
        numberAxis12.setFixedDimension(0.0d);
        org.jfree.data.Range range16 = numberAxis12.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis12);
        numberAxis12.setUpperBound((double) '4');
        numberAxis12.setAxisLineVisible(false);
        numberAxis12.setTickMarkInsideLength((float) 15);
        double double24 = numberAxis12.getLabelAngle();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        categoryPlot27.setOutlinePaint((java.awt.Paint) color28);
        java.awt.Paint paint31 = categoryPlot27.getOutlinePaint();
        org.jfree.chart.title.LegendGraphic legendGraphic32 = new org.jfree.chart.title.LegendGraphic(shape26, paint31);
        numberAxis12.setRightArrow(shape26);
        java.awt.Font font34 = numberAxis12.getLabelFont();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo38);
        java.awt.geom.Rectangle2D rectangle2D40 = plotRenderingInfo39.getPlotArea();
        java.awt.geom.Point2D point2D41 = null;
        categoryPlot36.zoomDomainAxes(0.05d, plotRenderingInfo39, point2D41);
        categoryPlot36.configureDomainAxes();
        int int44 = categoryPlot36.getRangeAxisCount();
        org.jfree.chart.util.SortOrder sortOrder45 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot36.setRowRenderingOrder(sortOrder45);
        categoryPlot0.setColumnRenderingOrder(sortOrder45);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.plot.ValueMarker valueMarker50 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.NumberAxis numberAxis52 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean53 = numberAxis52.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer55 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke56 = barRenderer55.getBaseStroke();
        java.awt.Font font57 = barRenderer55.getBaseItemLabelFont();
        java.awt.Color color62 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean64 = color62.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder65 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color62);
        org.jfree.chart.text.TextFragment textFragment67 = new org.jfree.chart.text.TextFragment("{0}", font57, (java.awt.Paint) color62, (float) ' ');
        numberAxis52.setLabelFont(font57);
        valueMarker50.setLabelFont(font57);
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image71 = null;
        categoryPlot70.setBackgroundImage(image71);
        categoryPlot70.clearDomainAxes();
        org.jfree.chart.plot.Plot plot74 = categoryPlot70.getRootPlot();
        valueMarker50.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) plot74);
        org.jfree.chart.plot.ValueMarker valueMarker77 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint78 = valueMarker77.getPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer79 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint81 = barRenderer79.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint83 = barRenderer79.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke85 = null;
        barRenderer79.setSeriesOutlineStroke(0, stroke85, true);
        java.awt.Stroke stroke90 = barRenderer79.getItemOutlineStroke((int) (byte) -1, 0);
        valueMarker77.setOutlineStroke(stroke90);
        valueMarker50.setStroke(stroke90);
        categoryPlot0.setRangeCrosshairStroke(stroke90);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertNotNull(color62);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(plot74);
        org.junit.Assert.assertNotNull(paint78);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNull(paint83);
        org.junit.Assert.assertNotNull(stroke90);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        numberAxis1.setTickMarksVisible(false);
        boolean boolean5 = numberAxis1.isAutoRange();
        numberAxis1.centerRange((double) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        java.awt.Font font5 = barRenderer3.getBaseItemLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}", font5, (java.awt.Paint) color10, (float) ' ');
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        categoryPlot18.setOutlinePaint((java.awt.Paint) color19);
        java.awt.Paint paint22 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot18.rendererChanged(rendererChangeEvent23);
        categoryPlot18.setRangeCrosshairValue((double) 3, true);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font16, (org.jfree.chart.plot.Plot) categoryPlot18, false);
        int int30 = jFreeChart29.getBackgroundImageAlignment();
        jFreeChart29.setBorderVisible(false);
        jFreeChart29.removeLegend();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.title.LegendTitle legendTitle8 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) categoryPlot0);
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = legendTitle8.getLegendItemGraphicEdge();
        java.lang.Object obj10 = null;
        boolean boolean11 = rectangleEdge9.equals(obj10);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.clearRangeAxes();
        org.jfree.chart.block.CenterArrangement centerArrangement14 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint17 = barRenderer15.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        barRenderer15.setSeriesURLGenerator(10, categoryURLGenerator19, true);
        boolean boolean22 = barRenderer15.getAutoPopulateSeriesStroke();
        java.awt.Paint paint24 = barRenderer15.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke26 = barRenderer25.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        barRenderer25.notifyListeners(rendererChangeEvent27);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = barRenderer25.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape30 = barRenderer25.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity31 = new org.jfree.chart.entity.LegendItemEntity(shape30);
        barRenderer15.setBaseShape(shape30, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity36 = new org.jfree.chart.entity.TickLabelEntity(shape30, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke39 = barRenderer38.getBaseStroke();
        java.awt.Font font40 = barRenderer38.getBaseItemLabelFont();
        java.awt.Color color45 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean47 = color45.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder48 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color45);
        org.jfree.chart.text.TextFragment textFragment50 = new org.jfree.chart.text.TextFragment("{0}", font40, (java.awt.Paint) color45, (float) ' ');
        java.awt.image.ColorModel colorModel51 = null;
        java.awt.Rectangle rectangle52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.awt.geom.AffineTransform affineTransform54 = null;
        java.awt.RenderingHints renderingHints55 = null;
        java.awt.PaintContext paintContext56 = color45.createContext(colorModel51, rectangle52, rectangle2D53, affineTransform54, renderingHints55);
        org.jfree.chart.title.LegendGraphic legendGraphic57 = new org.jfree.chart.title.LegendGraphic(shape30, (java.awt.Paint) color45);
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double60 = numberAxis59.getLabelAngle();
        numberAxis59.setFixedDimension(0.0d);
        org.jfree.data.Range range63 = numberAxis59.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent64 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis59);
        java.awt.Shape shape65 = numberAxis59.getRightArrow();
        legendGraphic57.setLine(shape65);
        legendGraphic57.setWidth(0.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer69 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint71 = barRenderer69.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer72 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint74 = barRenderer72.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint76 = barRenderer72.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke78 = null;
        barRenderer72.setSeriesOutlineStroke(0, stroke78, true);
        java.awt.Stroke stroke83 = barRenderer72.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer69.setBaseStroke(stroke83);
        legendGraphic57.setOutlineStroke(stroke83);
        java.awt.Stroke stroke86 = legendGraphic57.getLineStroke();
        java.awt.Shape shape87 = null;
        legendGraphic57.setLine(shape87);
        org.jfree.chart.axis.NumberAxis numberAxis90 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean91 = numberAxis90.isTickLabelsVisible();
        java.awt.Paint paint92 = numberAxis90.getAxisLinePaint();
        numberAxis90.setLabelToolTip("ChartChangeEventType.DATASET_UPDATED");
        centerArrangement14.add((org.jfree.chart.block.Block) legendGraphic57, (java.lang.Object) numberAxis90);
        categoryPlot12.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis90);
        boolean boolean97 = rectangleEdge9.equals((java.lang.Object) categoryPlot12);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNotNull(font40);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(paintContext56);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertNotNull(shape65);
        org.junit.Assert.assertNotNull(paint71);
        org.junit.Assert.assertNotNull(paint74);
        org.junit.Assert.assertNull(paint76);
        org.junit.Assert.assertNotNull(stroke83);
        org.junit.Assert.assertNull(stroke86);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + true + "'", boolean91 == true);
        org.junit.Assert.assertNotNull(paint92);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("EXPAND");
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image3 = null;
        categoryPlot2.setBackgroundImage(image3);
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = categoryPlot2.getDomainAxis();
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot2);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke8 = barRenderer7.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent9 = null;
        barRenderer7.notifyListeners(rendererChangeEvent9);
        java.awt.Paint paint13 = barRenderer7.getItemOutlinePaint(0, 15);
        int int14 = categoryPlot2.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer7.getNegativeItemLabelPosition((int) (short) 10, (int) (byte) 10);
        org.junit.Assert.assertNull(categoryAxis5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(itemLabelPosition17);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Paint paint5 = barRenderer0.getSeriesFillPaint((int) (short) 0);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.awt.Color color7 = java.awt.Color.BLUE;
        legendTitle6.setItemPaint((java.awt.Paint) color7);
        java.lang.String str9 = legendTitle6.getID();
        java.awt.Paint paint10 = legendTitle6.getItemPaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        double double2 = categoryAxis1.getCategoryMargin();
        double double3 = categoryAxis1.getCategoryMargin();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double5 = rectangleInsets4.getTop();
        categoryAxis1.setLabelInsets(rectangleInsets4);
        java.lang.Comparable comparable7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace10 = color9.getColorSpace();
        categoryPlot8.setOutlinePaint((java.awt.Paint) color9);
        java.awt.Paint paint12 = categoryPlot8.getOutlinePaint();
        try {
            categoryAxis1.setTickLabelPaint(comparable7, paint12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.2d + "'", double3 == 0.2d);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(colorSpace10);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        barRenderer2.setSeriesURLGenerator(10, categoryURLGenerator6, true);
        boolean boolean9 = barRenderer2.getAutoPopulateSeriesStroke();
        java.awt.Paint paint11 = barRenderer2.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke13 = barRenderer12.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        barRenderer12.notifyListeners(rendererChangeEvent14);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer12.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape17 = barRenderer12.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity(shape17);
        barRenderer2.setBaseShape(shape17, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity23 = new org.jfree.chart.entity.TickLabelEntity(shape17, "java.awt.Color[r=128,g=128,b=0]", "");
        java.lang.String str24 = tickLabelEntity23.getURLText();
        boolean boolean25 = valueMarker1.equals((java.lang.Object) tickLabelEntity23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke27 = barRenderer26.getBaseStroke();
        java.awt.Font font28 = barRenderer26.getBaseItemLabelFont();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = barRenderer26.getLegendItemURLGenerator();
        java.awt.Paint paint31 = barRenderer26.getSeriesFillPaint((int) (short) 0);
        org.jfree.chart.title.LegendTitle legendTitle32 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer26);
        java.awt.Color color33 = java.awt.Color.BLUE;
        legendTitle32.setItemPaint((java.awt.Paint) color33);
        java.lang.String str35 = legendTitle32.getID();
        boolean boolean36 = valueMarker1.equals((java.lang.Object) str35);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNull(str35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean4 = numberAxis3.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke7 = barRenderer6.getBaseStroke();
        java.awt.Font font8 = barRenderer6.getBaseItemLabelFont();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean15 = color13.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color13);
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("{0}", font8, (java.awt.Paint) color13, (float) ' ');
        numberAxis3.setLabelFont(font8);
        valueMarker1.setLabelFont(font8);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image22 = null;
        categoryPlot21.setBackgroundImage(image22);
        categoryPlot21.clearDomainAxes();
        org.jfree.chart.plot.Plot plot25 = categoryPlot21.getRootPlot();
        valueMarker1.removeChangeListener((org.jfree.chart.event.MarkerChangeListener) plot25);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo29);
        java.awt.geom.Rectangle2D rectangle2D31 = plotRenderingInfo30.getPlotArea();
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot27.zoomDomainAxes(0.05d, plotRenderingInfo30, point2D32);
        org.jfree.chart.renderer.category.BarRenderer barRenderer34 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint36 = null;
        barRenderer34.setSeriesFillPaint((int) '#', paint36, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator40 = null;
        barRenderer34.setSeriesURLGenerator(0, categoryURLGenerator40, true);
        int int43 = categoryPlot27.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer34);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder44 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str45 = datasetRenderingOrder44.toString();
        categoryPlot27.setDatasetRenderingOrder(datasetRenderingOrder44);
        valueMarker1.addChangeListener((org.jfree.chart.event.MarkerChangeListener) categoryPlot27);
        java.awt.Paint paint48 = valueMarker1.getOutlinePaint();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(plot25);
        org.junit.Assert.assertNull(rectangle2D31);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-1) + "'", int43 == (-1));
        org.junit.Assert.assertNotNull(datasetRenderingOrder44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str45.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        numberAxis1.setTickMarksVisible(false);
        boolean boolean5 = numberAxis1.isAutoRange();
        java.awt.Paint paint6 = numberAxis1.getTickLabelPaint();
        numberAxis1.setVerticalTickLabels(false);
        numberAxis1.setAutoRangeIncludesZero(true);
        boolean boolean11 = numberAxis1.isTickMarksVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis1.refreshTicks(graphics2D11, axisState13, rectangle2D14, rectangleEdge15);
        org.jfree.chart.util.UnitType unitType17 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean18 = numberAxis1.equals((java.lang.Object) unitType17);
        boolean boolean19 = numberAxis1.getAutoRangeStickyZero();
        java.lang.Class<?> wildcardClass20 = numberAxis1.getClass();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double23 = numberAxis22.getLabelAngle();
        numberAxis22.setFixedDimension(0.0d);
        org.jfree.data.Range range26 = numberAxis22.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent27 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis22);
        java.util.EventListener eventListener28 = null;
        boolean boolean29 = numberAxis22.hasListener(eventListener28);
        java.awt.Stroke stroke30 = numberAxis22.getTickMarkStroke();
        org.jfree.data.Range range31 = numberAxis22.getRange();
        boolean boolean34 = range31.intersects((double) 2, (double) '#');
        numberAxis1.setDefaultAutoRange(range31);
        java.awt.Paint paint36 = numberAxis1.getAxisLinePaint();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(range26);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        boolean boolean7 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double10 = numberAxis9.getLabelAngle();
        numberAxis9.setFixedDimension(0.0d);
        org.jfree.data.Range range13 = numberAxis9.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis9);
        categoryPlot0.axisChanged(axisChangeEvent14);
        java.lang.Object obj16 = axisChangeEvent14.getSource();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        java.awt.Color color0 = java.awt.Color.black;
        int int1 = color0.getGreen();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint7 = barRenderer3.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke9 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke9, true);
        java.awt.Stroke stroke14 = barRenderer3.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer0.setBaseStroke(stroke14);
        boolean boolean16 = barRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Font font18 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        barRenderer0.setSeriesItemLabelFont((int) (short) 10, font18, true);
        boolean boolean21 = barRenderer0.isDrawBarOutline();
        java.awt.Paint paint23 = barRenderer0.getSeriesOutlinePaint((-1));
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double8 = numberAxis7.getLabelAngle();
        numberAxis7.setFixedDimension(0.0d);
        org.jfree.data.Range range11 = numberAxis7.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range5, range11);
        org.jfree.data.Range range13 = rectangleConstraint12.getWidthRange();
        double double15 = range13.constrain(0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) 0L);
        org.jfree.chart.text.TextAnchor textAnchor5 = categoryLabelPosition4.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor6 = categoryLabelPosition4.getRotationAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = categoryLabelPosition4.getLabelAnchor();
        java.lang.Object obj8 = null;
        boolean boolean9 = textBlockAnchor7.equals(obj8);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint12 = barRenderer10.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint14 = barRenderer10.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Paint paint16 = barRenderer10.getSeriesOutlinePaint((int) (byte) 100);
        barRenderer10.setAutoPopulateSeriesStroke(false);
        boolean boolean19 = textBlockAnchor7.equals((java.lang.Object) false);
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertNotNull(textAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNull(paint16);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator4 = null;
        barRenderer0.setSeriesToolTipGenerator((int) 'a', categoryToolTipGenerator4);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color30);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double45 = numberAxis44.getLabelAngle();
        numberAxis44.setFixedDimension(0.0d);
        org.jfree.data.Range range48 = numberAxis44.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent49 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis44);
        java.awt.Shape shape50 = numberAxis44.getRightArrow();
        legendGraphic42.setLine(shape50);
        legendGraphic42.setWidth(0.0d);
        java.awt.Color color54 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean56 = color54.equals((java.lang.Object) 0.0d);
        legendGraphic42.setFillPaint((java.awt.Paint) color54);
        org.jfree.chart.util.RectangleInsets rectangleInsets58 = legendGraphic42.getPadding();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition59 = new org.jfree.chart.axis.CategoryLabelPosition();
        float float60 = categoryLabelPosition59.getWidthRatio();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor61 = categoryLabelPosition59.getCategoryAnchor();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor62 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType63 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition65 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor61, textBlockAnchor62, categoryLabelWidthType63, (float) (short) 100);
        legendGraphic42.setShapeAnchor(rectangleAnchor61);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(rectangleInsets58);
        org.junit.Assert.assertTrue("'" + float60 + "' != '" + 0.95f + "'", float60 == 0.95f);
        org.junit.Assert.assertNotNull(rectangleAnchor61);
        org.junit.Assert.assertNotNull(textBlockAnchor62);
        org.junit.Assert.assertNotNull(categoryLabelWidthType63);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        boolean boolean7 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot0.getAxisOffset();
        double double10 = rectangleInsets8.calculateBottomOutset((double) (byte) 1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.configureDomainAxes();
        java.lang.String str2 = categoryPlot0.getNoDataMessage();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) (byte) 1);
        boolean boolean4 = rectangleInsets0.equals((java.lang.Object) 10L);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets0.getUnitType();
        java.lang.String str6 = unitType5.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "UnitType.ABSOLUTE" + "'", str6.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean3 = numberAxis2.isTickLabelsVisible();
        boolean boolean4 = gradientPaintTransformType0.equals((java.lang.Object) numberAxis2);
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double7 = numberAxis6.getLabelAngle();
        numberAxis6.setFixedDimension(0.0d);
        org.jfree.data.Range range10 = numberAxis6.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis6);
        java.util.EventListener eventListener12 = null;
        boolean boolean13 = numberAxis6.hasListener(eventListener12);
        java.awt.Stroke stroke14 = numberAxis6.getTickMarkStroke();
        numberAxis2.setTickMarkStroke(stroke14);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke14);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke6 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke6, true);
        java.awt.Stroke stroke11 = barRenderer0.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Paint paint5 = barRenderer0.getSeriesFillPaint((int) (short) 0);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        java.awt.Color color7 = java.awt.Color.BLUE;
        legendTitle6.setItemPaint((java.awt.Paint) color7);
        java.lang.String str9 = legendTitle6.getID();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor10 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        legendTitle6.setLegendItemGraphicAnchor(rectangleAnchor10);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNull(str9);
        org.junit.Assert.assertNotNull(rectangleAnchor10);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape5 = barRenderer0.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.chart.block.BlockBorder blockBorder7 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean8 = legendItemEntity6.equals((java.lang.Object) blockBorder7);
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean11 = numberAxis10.isTickLabelsVisible();
        numberAxis10.setAutoRange(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = numberAxis10.getTickUnit();
        legendItemEntity6.setSeriesKey((java.lang.Comparable) numberTickUnit14);
        java.lang.Comparable comparable16 = legendItemEntity6.getSeriesKey();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(blockBorder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertNotNull(comparable16);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0, jFreeChart8, chartChangeEventType9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint13 = barRenderer11.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        barRenderer11.setSeriesURLGenerator(10, categoryURLGenerator15, true);
        boolean boolean18 = barRenderer11.getAutoPopulateSeriesStroke();
        java.awt.Paint paint20 = barRenderer11.lookupSeriesFillPaint(10);
        barRenderer0.setBaseFillPaint(paint20);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color30, true);
        java.lang.Object obj44 = barRenderer0.clone();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertNotNull(obj44);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint7 = barRenderer3.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke9 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke9, true);
        java.awt.Stroke stroke14 = barRenderer3.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer0.setBaseStroke(stroke14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke18 = barRenderer17.getBaseStroke();
        barRenderer0.setSeriesOutlineStroke((int) (short) 10, stroke18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = barRenderer0.getURLGenerator((int) 'a', (int) (short) 10);
        java.awt.Paint paint24 = barRenderer0.lookupSeriesFillPaint((-1));
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertNotNull(paint24);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double8 = numberAxis7.getLabelAngle();
        numberAxis7.setFixedDimension(0.0d);
        org.jfree.data.Range range11 = numberAxis7.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double14 = numberAxis13.getLabelAngle();
        numberAxis13.setFixedDimension(0.0d);
        org.jfree.data.Range range17 = numberAxis13.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(range11, range17);
        java.lang.String str19 = range11.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(range5, range11);
        double double21 = range5.getLength();
        org.jfree.data.Range range24 = org.jfree.data.Range.shift(range5, (double) 10.0f, true);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(range5, (-1.0d));
        org.jfree.data.Range range27 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint28 = rectangleConstraint26.toRangeHeight(range27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Range[0.0,1.0]" + "'", str19.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(range24);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        java.lang.String str2 = projectInfo0.getLicenceName();
        projectInfo0.addOptionalLibrary("-3,-3,3,3");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=128,g=128,b=0]" + "'", str2.equals("java.awt.Color[r=128,g=128,b=0]"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (double) (byte) 0);
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = defaultStatisticalCategoryDataset0.hasListener(eventListener4);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 100.0f);
        int int9 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) 0);
        int int10 = defaultStatisticalCategoryDataset0.getRowCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo13);
        java.awt.geom.Rectangle2D rectangle2D15 = plotRenderingInfo14.getPlotArea();
        java.awt.geom.Point2D point2D16 = null;
        categoryPlot11.zoomDomainAxes(0.05d, plotRenderingInfo14, point2D16);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint20 = null;
        barRenderer18.setSeriesFillPaint((int) '#', paint20, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        barRenderer18.setSeriesURLGenerator(0, categoryURLGenerator24, true);
        int int27 = categoryPlot11.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer18);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder28 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str29 = datasetRenderingOrder28.toString();
        categoryPlot11.setDatasetRenderingOrder(datasetRenderingOrder28);
        defaultStatisticalCategoryDataset0.removeChangeListener((org.jfree.data.general.DatasetChangeListener) categoryPlot11);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(pieDataset7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNull(rectangle2D15);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(datasetRenderingOrder28);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str29.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.axis.TickType tickType0 = org.jfree.chart.axis.TickType.MINOR;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        categoryPlot1.setOutlinePaint((java.awt.Paint) color2);
        java.awt.Paint paint5 = categoryPlot1.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        categoryPlot1.rendererChanged(rendererChangeEvent6);
        boolean boolean8 = categoryPlot1.isOutlineVisible();
        boolean boolean9 = tickType0.equals((java.lang.Object) boolean8);
        org.junit.Assert.assertNotNull(tickType0);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        boolean boolean2 = plotOrientation0.equals((java.lang.Object) categoryLabelPositions1);
        java.lang.String str3 = plotOrientation0.toString();
        org.junit.Assert.assertNotNull(plotOrientation0);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "PlotOrientation.VERTICAL" + "'", str3.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.block.CenterArrangement centerArrangement1 = new org.jfree.chart.block.CenterArrangement();
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        barRenderer2.setSeriesURLGenerator(10, categoryURLGenerator6, true);
        boolean boolean9 = barRenderer2.getAutoPopulateSeriesStroke();
        java.awt.Paint paint11 = barRenderer2.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke13 = barRenderer12.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        barRenderer12.notifyListeners(rendererChangeEvent14);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer12.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape17 = barRenderer12.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity(shape17);
        barRenderer2.setBaseShape(shape17, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity23 = new org.jfree.chart.entity.TickLabelEntity(shape17, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke26 = barRenderer25.getBaseStroke();
        java.awt.Font font27 = barRenderer25.getBaseItemLabelFont();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean34 = color32.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder35 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color32);
        org.jfree.chart.text.TextFragment textFragment37 = new org.jfree.chart.text.TextFragment("{0}", font27, (java.awt.Paint) color32, (float) ' ');
        java.awt.image.ColorModel colorModel38 = null;
        java.awt.Rectangle rectangle39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        java.awt.geom.AffineTransform affineTransform41 = null;
        java.awt.RenderingHints renderingHints42 = null;
        java.awt.PaintContext paintContext43 = color32.createContext(colorModel38, rectangle39, rectangle2D40, affineTransform41, renderingHints42);
        org.jfree.chart.title.LegendGraphic legendGraphic44 = new org.jfree.chart.title.LegendGraphic(shape17, (java.awt.Paint) color32);
        org.jfree.chart.axis.NumberAxis numberAxis46 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double47 = numberAxis46.getLabelAngle();
        numberAxis46.setFixedDimension(0.0d);
        org.jfree.data.Range range50 = numberAxis46.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent51 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis46);
        java.awt.Shape shape52 = numberAxis46.getRightArrow();
        legendGraphic44.setLine(shape52);
        legendGraphic44.setWidth(0.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer56 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint58 = barRenderer56.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer59 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint61 = barRenderer59.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint63 = barRenderer59.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke65 = null;
        barRenderer59.setSeriesOutlineStroke(0, stroke65, true);
        java.awt.Stroke stroke70 = barRenderer59.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer56.setBaseStroke(stroke70);
        legendGraphic44.setOutlineStroke(stroke70);
        java.awt.Stroke stroke73 = legendGraphic44.getLineStroke();
        java.awt.Shape shape74 = null;
        legendGraphic44.setLine(shape74);
        org.jfree.chart.axis.NumberAxis numberAxis77 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean78 = numberAxis77.isTickLabelsVisible();
        java.awt.Paint paint79 = numberAxis77.getAxisLinePaint();
        numberAxis77.setLabelToolTip("ChartChangeEventType.DATASET_UPDATED");
        centerArrangement1.add((org.jfree.chart.block.Block) legendGraphic44, (java.lang.Object) numberAxis77);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit84 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.util.RectangleEdge rectangleEdge85 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge86 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge85);
        org.jfree.chart.util.RectangleEdge rectangleEdge87 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge85);
        int int88 = numberTickUnit84.compareTo((java.lang.Object) rectangleEdge85);
        keyedObjects2D0.addObject((java.lang.Object) numberAxis77, (java.lang.Comparable) 4.0d, (java.lang.Comparable) int88);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paintContext43);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(range50);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(paint61);
        org.junit.Assert.assertNull(paint63);
        org.junit.Assert.assertNotNull(stroke70);
        org.junit.Assert.assertNull(stroke73);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + true + "'", boolean78 == true);
        org.junit.Assert.assertNotNull(paint79);
        org.junit.Assert.assertNotNull(numberTickUnit84);
        org.junit.Assert.assertNotNull(rectangleEdge85);
        org.junit.Assert.assertNotNull(rectangleEdge86);
        org.junit.Assert.assertNotNull(rectangleEdge87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + (-1) + "'", int88 == (-1));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        java.awt.Paint paint6 = barRenderer0.getItemOutlinePaint(0, 15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator16 = null;
        barRenderer12.setSeriesURLGenerator(10, categoryURLGenerator16, true);
        boolean boolean19 = barRenderer12.getAutoPopulateSeriesStroke();
        java.awt.Paint paint21 = barRenderer12.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke23 = barRenderer22.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent24 = null;
        barRenderer22.notifyListeners(rendererChangeEvent24);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = barRenderer22.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape27 = barRenderer22.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity28 = new org.jfree.chart.entity.LegendItemEntity(shape27);
        barRenderer12.setBaseShape(shape27, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity33 = new org.jfree.chart.entity.TickLabelEntity(shape27, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color34 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape27, (java.awt.Paint) color34);
        java.awt.Paint paint36 = legendItem35.getLinePaint();
        java.lang.Comparable comparable37 = legendItem35.getSeriesKey();
        java.awt.Stroke stroke38 = legendItem35.getLineStroke();
        barRenderer0.setSeriesOutlineStroke(0, stroke38);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(itemLabelPosition26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(comparable37);
        org.junit.Assert.assertNotNull(stroke38);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean6 = color4.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color4);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color10 = java.awt.Color.CYAN;
        java.awt.Color color11 = java.awt.Color.CYAN;
        java.awt.Color color12 = java.awt.Color.red;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color4, color8, color9, color10, color11, color12 };
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint[] paintArray15 = new java.awt.Paint[] { color14 };
        java.awt.Stroke[] strokeArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke17 = null;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke17 };
        java.awt.Shape shape19 = null;
        java.awt.Shape[] shapeArray20 = new java.awt.Shape[] { shape19 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray13, paintArray15, strokeArray16, strokeArray18, shapeArray20);
        java.awt.Paint paint22 = defaultDrawingSupplier21.getNextOutlinePaint();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis1.refreshTicks(graphics2D11, axisState13, rectangle2D14, rectangleEdge15);
        boolean boolean17 = numberAxis1.isVerticalTickLabels();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        java.awt.geom.Rectangle2D rectangle2D22 = plotRenderingInfo21.getPlotArea();
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot18.zoomDomainAxes(0.05d, plotRenderingInfo21, point2D23);
        categoryPlot18.configureDomainAxes();
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot18);
        org.jfree.chart.LegendItemCollection legendItemCollection27 = categoryPlot18.getFixedLegendItems();
        categoryPlot18.setNoDataMessage("RectangleAnchor.BOTTOM");
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray30 = null;
        try {
            categoryPlot18.setRenderers(categoryItemRendererArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNull(rectangle2D22);
        org.junit.Assert.assertNull(legendItemCollection27);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        barRenderer2.setSeriesURLGenerator(10, categoryURLGenerator6, true);
        boolean boolean9 = barRenderer2.getAutoPopulateSeriesStroke();
        java.awt.Paint paint11 = barRenderer2.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke13 = barRenderer12.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        barRenderer12.notifyListeners(rendererChangeEvent14);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer12.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape17 = barRenderer12.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity(shape17);
        barRenderer2.setBaseShape(shape17, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity23 = new org.jfree.chart.entity.TickLabelEntity(shape17, "java.awt.Color[r=128,g=128,b=0]", "");
        java.lang.String str24 = tickLabelEntity23.getURLText();
        boolean boolean25 = valueMarker1.equals((java.lang.Object) tickLabelEntity23);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent26 = null;
        valueMarker1.notifyListeners(markerChangeEvent26);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "" + "'", str24.equals(""));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean6 = color4.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder7 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color4);
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color10 = java.awt.Color.CYAN;
        java.awt.Color color11 = java.awt.Color.CYAN;
        java.awt.Color color12 = java.awt.Color.red;
        java.awt.Paint[] paintArray13 = new java.awt.Paint[] { color4, color8, color9, color10, color11, color12 };
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint[] paintArray15 = new java.awt.Paint[] { color14 };
        java.awt.Stroke[] strokeArray16 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke17 = null;
        java.awt.Stroke[] strokeArray18 = new java.awt.Stroke[] { stroke17 };
        java.awt.Shape shape19 = null;
        java.awt.Shape[] shapeArray20 = new java.awt.Shape[] { shape19 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray13, paintArray15, strokeArray16, strokeArray18, shapeArray20);
        java.awt.Paint paint22 = defaultDrawingSupplier21.getNextPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint25 = barRenderer23.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint27 = barRenderer23.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke29 = null;
        barRenderer23.setSeriesOutlineStroke(0, stroke29, true);
        java.awt.Stroke stroke34 = barRenderer23.getItemOutlineStroke((int) (byte) -1, 0);
        boolean boolean35 = defaultDrawingSupplier21.equals((java.lang.Object) barRenderer23);
        boolean boolean37 = defaultDrawingSupplier21.equals((java.lang.Object) (byte) 0);
        java.lang.Object obj38 = defaultDrawingSupplier21.clone();
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(paintArray13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintArray15);
        org.junit.Assert.assertNotNull(strokeArray16);
        org.junit.Assert.assertNotNull(strokeArray18);
        org.junit.Assert.assertNotNull(shapeArray20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(obj38);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        barRenderer3.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock1, textBlockAnchor2, textAnchor8, 0.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke12 = barRenderer11.getBaseStroke();
        java.awt.Font font13 = barRenderer11.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator16 = barRenderer11.getItemLabelGenerator((int) (byte) 0, (int) '4');
        java.awt.Stroke stroke17 = barRenderer11.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection18 = barRenderer11.getLegendItems();
        java.lang.Object obj19 = legendItemCollection18.clone();
        boolean boolean20 = textAnchor8.equals((java.lang.Object) legendItemCollection18);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNull(categoryItemLabelGenerator16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(legendItemCollection18);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.plot.Plot plot4 = categoryPlot0.getRootPlot();
        org.jfree.chart.plot.ValueMarker valueMarker6 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Paint paint7 = valueMarker6.getPaint();
        java.awt.Stroke stroke8 = valueMarker6.getStroke();
        org.jfree.chart.util.Layer layer9 = null;
        categoryPlot0.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker6, layer9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double13 = numberAxis12.getLabelAngle();
        numberAxis12.setFixedDimension(0.0d);
        org.jfree.data.Range range16 = numberAxis12.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent17 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis12);
        numberAxis12.setUpperBound((double) '4');
        numberAxis12.setAxisLineVisible(false);
        numberAxis12.setTickMarkInsideLength((float) 15);
        double double24 = numberAxis12.getLabelAngle();
        java.awt.Shape shape26 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color28 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace29 = color28.getColorSpace();
        categoryPlot27.setOutlinePaint((java.awt.Paint) color28);
        java.awt.Paint paint31 = categoryPlot27.getOutlinePaint();
        org.jfree.chart.title.LegendGraphic legendGraphic32 = new org.jfree.chart.title.LegendGraphic(shape26, paint31);
        numberAxis12.setRightArrow(shape26);
        java.awt.Font font34 = numberAxis12.getLabelFont();
        categoryPlot0.setRangeAxis((org.jfree.chart.axis.ValueAxis) numberAxis12);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo38 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo38);
        java.awt.geom.Rectangle2D rectangle2D40 = plotRenderingInfo39.getPlotArea();
        java.awt.geom.Point2D point2D41 = null;
        categoryPlot36.zoomDomainAxes(0.05d, plotRenderingInfo39, point2D41);
        categoryPlot36.configureDomainAxes();
        int int44 = categoryPlot36.getRangeAxisCount();
        org.jfree.chart.util.SortOrder sortOrder45 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot36.setRowRenderingOrder(sortOrder45);
        categoryPlot0.setColumnRenderingOrder(sortOrder45);
        categoryPlot0.configureRangeAxes();
        org.jfree.chart.axis.NumberAxis numberAxis50 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double51 = numberAxis50.getLabelAngle();
        numberAxis50.setFixedDimension(0.0d);
        org.jfree.data.Range range54 = numberAxis50.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent55 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis50);
        org.jfree.chart.axis.Axis axis56 = axisChangeEvent55.getAxis();
        org.jfree.chart.JFreeChart jFreeChart57 = axisChangeEvent55.getChart();
        categoryPlot0.axisChanged(axisChangeEvent55);
        org.junit.Assert.assertNotNull(plot4);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(range16);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(colorSpace29);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertNull(rectangle2D40);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(sortOrder45);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(range54);
        org.junit.Assert.assertNotNull(axis56);
        org.junit.Assert.assertNull(jFreeChart57);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        java.awt.Font font5 = barRenderer3.getBaseItemLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}", font5, (java.awt.Paint) color10, (float) ' ');
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        categoryPlot18.setOutlinePaint((java.awt.Paint) color19);
        java.awt.Paint paint22 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot18.rendererChanged(rendererChangeEvent23);
        categoryPlot18.setRangeCrosshairValue((double) 3, true);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font16, (org.jfree.chart.plot.Plot) categoryPlot18, false);
        java.awt.Paint paint30 = jFreeChart29.getBackgroundPaint();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        int int28 = legendItem27.getSeriesIndex();
        java.awt.Shape shape29 = legendItem27.getLine();
        java.lang.String str30 = legendItem27.getURLText();
        java.lang.String str31 = legendItem27.getDescription();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str30.equals("TextAnchor.BOTTOM_CENTER"));
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str31.equals("TextAnchor.BOTTOM_CENTER"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setRight((double) '#');
        axisSpace0.setRight((double) (short) -1);
        double double5 = axisSpace0.getRight();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double9 = numberAxis8.getLabelAngle();
        numberAxis8.setFixedDimension(0.0d);
        org.jfree.data.Range range12 = numberAxis8.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis8);
        numberAxis8.setUpperBound((double) '4');
        numberAxis8.setAxisLineVisible(false);
        numberAxis8.setTickMarkInsideLength((float) 15);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image21 = null;
        categoryPlot20.setBackgroundImage(image21);
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        java.awt.geom.Rectangle2D rectangle2D26 = plotRenderingInfo25.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D27 = plotRenderingInfo25.getDataArea();
        categoryPlot20.drawBackgroundImage(graphics2D23, rectangle2D27);
        numberAxis8.setDownArrow((java.awt.Shape) rectangle2D27);
        try {
            java.awt.geom.Rectangle2D rectangle2D30 = axisSpace0.expand(rectangle2D6, rectangle2D27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.0d) + "'", double5 == (-1.0d));
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertNull(rectangle2D26);
        org.junit.Assert.assertNotNull(rectangle2D27);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color30);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double45 = numberAxis44.getLabelAngle();
        numberAxis44.setFixedDimension(0.0d);
        org.jfree.data.Range range48 = numberAxis44.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent49 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis44);
        java.awt.Shape shape50 = numberAxis44.getRightArrow();
        legendGraphic42.setLine(shape50);
        legendGraphic42.setHeight((double) 2.0f);
        double double54 = legendGraphic42.getContentXOffset();
        java.awt.Shape shape55 = legendGraphic42.getLine();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.0d + "'", double54 == 2.0d);
        org.junit.Assert.assertNotNull(shape55);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = barRenderer0.getItemLabelGenerator((int) (byte) 0, (int) '4');
        java.awt.Stroke stroke6 = barRenderer0.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = barRenderer0.getLegendItems();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double10 = numberAxis9.getLabelAngle();
        numberAxis9.setFixedDimension(0.0d);
        org.jfree.data.Range range13 = numberAxis9.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis9);
        numberAxis9.setUpperBound((double) '4');
        numberAxis9.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.axis.AxisState axisState21 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = null;
        java.util.List list24 = numberAxis9.refreshTicks(graphics2D19, axisState21, rectangle2D22, rectangleEdge23);
        boolean boolean25 = numberAxis9.isVerticalTickLabels();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo28 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo28);
        java.awt.geom.Rectangle2D rectangle2D30 = plotRenderingInfo29.getPlotArea();
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot26.zoomDomainAxes(0.05d, plotRenderingInfo29, point2D31);
        categoryPlot26.configureDomainAxes();
        numberAxis9.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot26);
        org.jfree.chart.LegendItemCollection legendItemCollection35 = categoryPlot26.getFixedLegendItems();
        categoryPlot26.setNoDataMessage("RectangleAnchor.BOTTOM");
        boolean boolean38 = legendItemCollection7.equals((java.lang.Object) categoryPlot26);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertNotNull(list24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNull(rectangle2D30);
        org.junit.Assert.assertNull(legendItemCollection35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 10.0f, (java.lang.Number) (short) 0);
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double5 = numberAxis4.getLabelAngle();
        numberAxis4.setFixedDimension(0.0d);
        org.jfree.data.Range range8 = numberAxis4.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double11 = numberAxis10.getLabelAngle();
        numberAxis10.setFixedDimension(0.0d);
        org.jfree.data.Range range14 = numberAxis10.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double17 = numberAxis16.getLabelAngle();
        numberAxis16.setFixedDimension(0.0d);
        org.jfree.data.Range range20 = numberAxis16.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range14, range20);
        java.lang.String str22 = range14.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint23 = new org.jfree.chart.block.RectangleConstraint(range8, range14);
        double double24 = range8.getLength();
        org.jfree.data.Range range27 = org.jfree.data.Range.shift(range8, (double) 10.0f, true);
        org.jfree.data.Range range30 = org.jfree.data.Range.shift(range8, 0.0d, false);
        org.jfree.data.Range range32 = org.jfree.data.Range.expandToInclude(range30, 0.5d);
        org.jfree.data.Range range34 = org.jfree.data.Range.shift(range32, (double) 1L);
        boolean boolean35 = meanAndStandardDeviation2.equals((java.lang.Object) range34);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "Range[0.0,1.0]" + "'", str22.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertNotNull(range34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.lang.String str1 = projectInfo0.getLicenceName();
        java.awt.Image image2 = projectInfo0.getLogo();
        java.awt.Image image3 = projectInfo0.getLogo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=128,g=128,b=0]" + "'", str1.equals("java.awt.Color[r=128,g=128,b=0]"));
        org.junit.Assert.assertNotNull(image2);
        org.junit.Assert.assertNotNull(image3);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        barRenderer4.notifyListeners(rendererChangeEvent6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer4.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape9 = barRenderer4.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity10 = new org.jfree.chart.entity.LegendItemEntity(shape9);
        org.jfree.chart.block.BlockBorder blockBorder11 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean12 = legendItemEntity10.equals((java.lang.Object) blockBorder11);
        java.awt.Shape shape13 = legendItemEntity10.getArea();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        java.awt.Font font16 = barRenderer14.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = barRenderer14.getItemLabelGenerator((int) (byte) 0, (int) '4');
        java.awt.Stroke stroke20 = barRenderer14.getBaseStroke();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        java.lang.String str22 = color21.toString();
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("EXPAND", "", "SortOrder.ASCENDING", "RectangleConstraintType.RANGE", shape13, stroke20, (java.awt.Paint) color21);
        java.lang.Comparable comparable24 = legendItem23.getSeriesKey();
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(blockBorder11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNull(categoryItemLabelGenerator19);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "java.awt.Color[r=128,g=255,b=255]" + "'", str22.equals("java.awt.Color[r=128,g=255,b=255]"));
        org.junit.Assert.assertNull(comparable24);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickLabelsVisible();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis1.valueToJava2D((double) 10.0f, rectangle2D4, rectangleEdge5);
        java.text.NumberFormat numberFormat7 = null;
        numberAxis1.setNumberFormatOverride(numberFormat7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = null;
        try {
            numberAxis1.setLabelInsets(rectangleInsets9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape5 = barRenderer0.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.data.general.Dataset dataset7 = legendItemEntity6.getDataset();
        java.lang.String str8 = legendItemEntity6.toString();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(dataset7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str8.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        java.awt.Font font5 = barRenderer3.getBaseItemLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}", font5, (java.awt.Paint) color10, (float) ' ');
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font16);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean20 = numberAxis19.isTickMarksVisible();
        numberAxis19.setTickMarksVisible(false);
        boolean boolean23 = numberAxis19.isAutoRange();
        org.jfree.chart.event.AxisChangeListener axisChangeListener24 = null;
        numberAxis19.removeChangeListener(axisChangeListener24);
        java.awt.Font font26 = numberAxis19.getTickLabelFont();
        textTitle17.setFont(font26);
        org.jfree.chart.renderer.category.BarRenderer barRenderer28 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint30 = barRenderer28.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint32 = barRenderer28.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke34 = null;
        barRenderer28.setSeriesOutlineStroke(0, stroke34, true);
        java.awt.Stroke stroke39 = barRenderer28.getItemOutlineStroke((int) (byte) -1, 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator40 = barRenderer28.getBaseItemLabelGenerator();
        java.awt.Color color41 = java.awt.Color.gray;
        barRenderer28.setBasePaint((java.awt.Paint) color41);
        java.awt.Graphics2D graphics2D45 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer46 = new org.jfree.chart.text.G2TextMeasurer(graphics2D45);
        try {
            org.jfree.chart.text.TextBlock textBlock47 = org.jfree.chart.text.TextUtilities.createTextBlock("VerticalAlignment.BOTTOM", font26, (java.awt.Paint) color41, (float) (short) 100, 0, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(font26);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNull(paint32);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(categoryItemLabelGenerator40);
        org.junit.Assert.assertNotNull(color41);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        keyedObjects2D0.setObject((java.lang.Object) 0.2d, (java.lang.Comparable) numberTickUnit2, (java.lang.Comparable) 10);
        keyedObjects2D0.addObject((java.lang.Object) 2.0d, (java.lang.Comparable) 1, (java.lang.Comparable) 100);
        org.jfree.chart.axis.AxisState axisState10 = new org.jfree.chart.axis.AxisState(10.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        axisState10.moveCursor(1.0d, rectangleEdge12);
        double double14 = axisState10.getMax();
        keyedObjects2D0.addObject((java.lang.Object) axisState10, (java.lang.Comparable) 'a', (java.lang.Comparable) (-1));
        java.lang.Object obj18 = keyedObjects2D0.clone();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset19 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean24 = numberAxis23.isTickLabelsVisible();
        numberAxis23.setAutoRange(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit27 = numberAxis23.getTickUnit();
        java.lang.Comparable comparable28 = null;
        defaultStatisticalCategoryDataset19.add(Double.NaN, 0.0d, (java.lang.Comparable) numberTickUnit27, comparable28);
        int int30 = keyedObjects2D0.getRowIndex((java.lang.Comparable) 0.0d);
        try {
            java.lang.Comparable comparable32 = keyedObjects2D0.getRowKey((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 3");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(obj18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(numberTickUnit27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        java.awt.Font font5 = barRenderer3.getBaseItemLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}", font5, (java.awt.Paint) color10, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("ThreadContext", font5);
        java.awt.Font font17 = labelBlock16.getFont();
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint24 = barRenderer22.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator26 = null;
        barRenderer22.setSeriesURLGenerator(10, categoryURLGenerator26, true);
        boolean boolean29 = barRenderer22.getAutoPopulateSeriesStroke();
        java.awt.Paint paint31 = barRenderer22.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke33 = barRenderer32.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent34 = null;
        barRenderer32.notifyListeners(rendererChangeEvent34);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = barRenderer32.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape37 = barRenderer32.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity38 = new org.jfree.chart.entity.LegendItemEntity(shape37);
        barRenderer22.setBaseShape(shape37, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity43 = new org.jfree.chart.entity.TickLabelEntity(shape37, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color44 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem45 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape37, (java.awt.Paint) color44);
        java.awt.Paint paint46 = legendItem45.getLinePaint();
        java.lang.Comparable comparable47 = legendItem45.getSeriesKey();
        java.awt.Paint paint48 = legendItem45.getOutlinePaint();
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer51 = new org.jfree.chart.text.G2TextMeasurer(graphics2D50);
        try {
            org.jfree.chart.text.TextBlock textBlock52 = org.jfree.chart.text.TextUtilities.createTextBlock("RectangleEdge.LEFT", font17, paint48, (float) 10L, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(paint31);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
        org.junit.Assert.assertNotNull(shape37);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNull(comparable47);
        org.junit.Assert.assertNotNull(paint48);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0, jFreeChart8, chartChangeEventType9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint13 = barRenderer11.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        barRenderer11.setSeriesURLGenerator(10, categoryURLGenerator15, true);
        boolean boolean18 = barRenderer11.getAutoPopulateSeriesStroke();
        java.awt.Paint paint20 = barRenderer11.lookupSeriesFillPaint(10);
        barRenderer0.setBaseFillPaint(paint20);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator22, true);
        barRenderer0.setBaseCreateEntities(true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = barRenderer0.getPositiveItemLabelPosition((int) (short) 0, 100);
        barRenderer0.setSeriesVisible(100, (java.lang.Boolean) true, true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        barRenderer3.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock1, textBlockAnchor2, textAnchor8, 0.0d);
        org.jfree.chart.text.TextBlock textBlock11 = categoryTick10.getLabel();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textBlock11.getLineAlignment();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer2.getBaseStroke();
        java.awt.Font font4 = barRenderer2.getBaseItemLabelFont();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("{0}", font4, (java.awt.Paint) color9, (float) ' ');
        java.awt.Font font15 = textFragment14.getFont();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font15);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) 0.95f, (double) '4', (double) (byte) 1, (double) 0.0f);
        textTitle16.setFrame((org.jfree.chart.block.BlockFrame) blockBorder21);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font15);
    }
}

