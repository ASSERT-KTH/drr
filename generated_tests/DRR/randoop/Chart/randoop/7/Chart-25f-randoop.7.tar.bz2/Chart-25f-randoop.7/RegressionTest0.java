import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        try {
            java.awt.Color color1 = java.awt.Color.decode("");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: Zero length string");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_TICK_UNIT_SELECTION;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        java.awt.Color color0 = java.awt.Color.GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.util.Collection collection0 = null;
        try {
            java.util.Collection collection1 = org.jfree.chart.util.ObjectUtilities.deepClone(collection0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'collection' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = new org.jfree.chart.axis.NumberTickUnit((double) 0L, numberFormat1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_AUTO_RANGE_STICKY_ZERO;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.LegendItemEntity legendItemEntity1 = new org.jfree.chart.entity.LegendItemEntity(shape0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) 100L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'categoryAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor1);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (-1.0d), (float) (-1), (float) (byte) 100);
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("{0}", graphics2D1, (float) '#', (float) (byte) 0, (double) 1.0f, 100.0f, (-1.0f));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = null;
        double double2 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D0, rectangleEdge1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("hi!", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        numberAxis1.setAutoRangeIncludesZero(true);
        java.awt.Shape shape5 = null;
        try {
            numberAxis1.setUpArrow(shape5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrow' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        try {
            org.jfree.chart.axis.AxisState axisState11 = numberAxis1.draw(graphics2D5, (double) '#', rectangle2D7, rectangle2D8, rectangleEdge9, plotRenderingInfo10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test033");
//        java.lang.Class class1 = null;
//        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("{0}", class1);
//        org.junit.Assert.assertNull(uRL2);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke2 = barRenderer1.getBaseStroke();
        java.awt.Font font3 = barRenderer1.getBaseItemLabelFont();
        java.awt.Color color4 = java.awt.Color.RED;
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer8 = new org.jfree.chart.text.G2TextMeasurer(graphics2D7);
        try {
            org.jfree.chart.text.TextBlock textBlock9 = org.jfree.chart.text.TextUtilities.createTextBlock("{0}", font3, (java.awt.Paint) color4, (float) (byte) 10, 0, (org.jfree.chart.text.TextMeasurer) g2TextMeasurer8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test035");
//        java.lang.Class class1 = null;
//        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("", class1);
//        org.junit.Assert.assertNotNull(inputStream2);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.setFixedDimension(0.0d);
        java.awt.Stroke stroke4 = null;
        try {
            numberAxis1.setTickMarkStroke(stroke4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.TOP;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("{0}");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name {0}, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.isUseDrawRotatedStringWorkaround();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        boolean boolean11 = barRenderer0.isSeriesVisibleInLegend((int) (short) 1);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            barRenderer0.drawOutline(graphics2D12, categoryPlot13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) (byte) 1);
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge1 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge0);
        org.junit.Assert.assertNull(rectangleEdge1);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color16 = java.awt.Color.CYAN;
        java.awt.Color color17 = java.awt.Color.CYAN;
        java.awt.Color color18 = java.awt.Color.red;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color10, color14, color15, color16, color17, color18 };
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color20 };
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke23 = null;
        java.awt.Stroke[] strokeArray24 = new java.awt.Stroke[] { stroke23 };
        java.awt.Shape shape25 = null;
        java.awt.Shape[] shapeArray26 = new java.awt.Shape[] { shape25 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray21, strokeArray22, strokeArray24, shapeArray26);
        java.awt.Paint paint28 = defaultDrawingSupplier27.getNextPaint();
        barRenderer0.setSeriesOutlinePaint(0, paint28, false);
        java.lang.Boolean boolean32 = barRenderer0.getSeriesItemLabelsVisible(0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(shapeArray26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(boolean32);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceTopPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.util.UnitType unitType0 = null;
        try {
            org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) 10.0f, (double) 0.0f, (double) 0.0f, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'unitType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.lang.ClassLoader classLoader0 = null;
        try {
            java.util.ResourceBundle.clearCache(classLoader0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(10.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = null;
        axisState1.moveCursor(1.0d, rectangleEdge3);
        double double5 = axisState1.getCursor();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.extendHeight((double) (-1.0f));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        try {
            java.lang.Object obj2 = jFreeChartResources0.getObject("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key hi!");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke6 = barRenderer5.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        barRenderer5.notifyListeners(rendererChangeEvent7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = barRenderer5.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape10 = barRenderer5.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity(shape10);
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean19 = color17.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder20 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color17);
        java.lang.String str21 = color17.toString();
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint25 = barRenderer23.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = null;
        barRenderer23.setSeriesURLGenerator(10, categoryURLGenerator27, true);
        boolean boolean30 = barRenderer23.getAutoPopulateSeriesStroke();
        java.awt.Paint paint32 = barRenderer23.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint35 = barRenderer33.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer36 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint38 = barRenderer36.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint40 = barRenderer36.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke42 = null;
        barRenderer36.setSeriesOutlineStroke(0, stroke42, true);
        java.awt.Stroke stroke47 = barRenderer36.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer33.setBaseStroke(stroke47);
        org.jfree.chart.renderer.category.BarRenderer barRenderer50 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke51 = barRenderer50.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent52 = null;
        barRenderer50.notifyListeners(rendererChangeEvent52);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition54 = barRenderer50.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape55 = barRenderer50.getBaseShape();
        java.awt.Stroke stroke56 = null;
        java.awt.Color color57 = java.awt.Color.red;
        try {
            org.jfree.chart.LegendItem legendItem58 = new org.jfree.chart.LegendItem(attributedString0, "TextAnchor.BOTTOM_CENTER", "TextAnchor.BOTTOM_CENTER", "", true, shape10, false, (java.awt.Paint) color17, true, paint32, stroke47, false, shape55, stroke56, (java.awt.Paint) color57);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=128,g=128,b=0]" + "'", str21.equals("java.awt.Color[r=128,g=128,b=0]"));
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNotNull(paint35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNull(paint40);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNotNull(itemLabelPosition54);
        org.junit.Assert.assertNotNull(shape55);
        org.junit.Assert.assertNotNull(color57);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent6 = null;
        barRenderer4.notifyListeners(rendererChangeEvent6);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer4.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape9 = barRenderer4.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity10 = new org.jfree.chart.entity.LegendItemEntity(shape9);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        try {
            org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem(attributedString0, "", "", "", shape9, (java.awt.Paint) color11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("{0}", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = null;
        barRenderer0.setSeriesFillPaint((int) '#', paint2, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        barRenderer0.setSeriesToolTipGenerator(8, categoryToolTipGenerator6, false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        org.jfree.data.general.DatasetGroup datasetGroup0 = new org.jfree.data.general.DatasetGroup();
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        int int3 = java.awt.Color.HSBtoRGB((float) 10, (float) 'a', 10.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-15423) + "'", int3 == (-15423));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getSeriesItemLabelGenerator((int) (short) 1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = null;
        try {
            barRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        java.util.ResourceBundle.Control control3 = null;
        try {
            java.util.ResourceBundle resourceBundle4 = java.util.ResourceBundle.getBundle("{0}", locale1, classLoader2, control3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Color color2 = java.awt.Color.gray;
        try {
            barRenderer0.setSeriesItemLabelPaint((-15423), (java.awt.Paint) color2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        double double2 = categoryItemRendererState1.getSeriesRunningTotal();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = null;
        try {
            axisSpace0.ensureAtLeast((double) 1.0f, rectangleEdge2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalStateException; message: AxisSpace.ensureAtLeast(): unrecognised AxisLocation.");
        } catch (java.lang.IllegalStateException e) {
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Object obj3 = keyedObjects2D0.getObject(0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.block.BlockBorder blockBorder0 = new org.jfree.chart.block.BlockBorder();
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType4 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        try {
            org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition6 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, textAnchor2, (double) (short) 100, categoryLabelWidthType4, (float) 0L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType4);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("{0}", "Range[0.0,1.0]", "Range[0.0,1.0]", "{0}", "TextAnchor.BOTTOM_CENTER");
        java.lang.String str6 = basicProjectInfo5.getLicenceName();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str6.equals("TextAnchor.BOTTOM_CENTER"));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        barRenderer0.setDrawBarOutline(true);
        double double7 = barRenderer0.getUpperClip();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        java.lang.String str1 = horizontalAlignment0.toString();
        org.junit.Assert.assertNotNull(horizontalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "HorizontalAlignment.CENTER" + "'", str1.equals("HorizontalAlignment.CENTER"));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickLabelsVisible();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = null;
        double double6 = numberAxis1.valueToJava2D((double) 10.0f, rectangle2D4, rectangleEdge5);
        numberAxis1.setTickMarkInsideLength(0.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor4 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor5 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType6 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor4, textBlockAnchor5, categoryLabelWidthType6, (float) 0L);
        org.jfree.chart.text.TextAnchor textAnchor9 = categoryLabelPosition8.getRotationAnchor();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("{0}", graphics2D1, (-1.0f), (float) 100, textAnchor9, (double) (byte) 100, (float) (byte) -1, (float) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor4);
        org.junit.Assert.assertNotNull(textBlockAnchor5);
        org.junit.Assert.assertNotNull(categoryLabelWidthType6);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        java.lang.String str1 = lengthAdjustmentType0.toString();
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "EXPAND" + "'", str1.equals("EXPAND"));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        double double2 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str1.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setAutoTickUnitSelection(false, true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) (byte) 1);
        boolean boolean4 = rectangleInsets0.equals((java.lang.Object) 10L);
        double double6 = rectangleInsets0.calculateLeftOutset(2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.ui.Library library4 = new org.jfree.chart.ui.Library("", "java.awt.Color[r=128,g=128,b=0]", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "");
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) -1, (int) (byte) 10, 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1L));
        defaultStatisticalCategoryDataset0.add((java.lang.Number) (-1L), (java.lang.Number) (short) 0, (java.lang.Comparable) 100.0d, (java.lang.Comparable) "{0}");
        java.util.EventListener eventListener10 = null;
        boolean boolean11 = defaultStatisticalCategoryDataset0.hasListener(eventListener10);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.LegendItemSource legendItemSource0 = null;
        org.jfree.chart.block.Arrangement arrangement1 = null;
        org.jfree.chart.block.BorderArrangement borderArrangement2 = new org.jfree.chart.block.BorderArrangement();
        try {
            org.jfree.chart.title.LegendTitle legendTitle3 = new org.jfree.chart.title.LegendTitle(legendItemSource0, arrangement1, (org.jfree.chart.block.Arrangement) borderArrangement2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'arrangement' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        java.awt.Shape shape0 = null;
        java.awt.Shape shape4 = org.jfree.chart.util.ShapeUtilities.rotateShape(shape0, (double) 0.0f, 0.0f, (float) '4');
        org.junit.Assert.assertNull(shape4);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color16 = java.awt.Color.CYAN;
        java.awt.Color color17 = java.awt.Color.CYAN;
        java.awt.Color color18 = java.awt.Color.red;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color10, color14, color15, color16, color17, color18 };
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color20 };
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke23 = null;
        java.awt.Stroke[] strokeArray24 = new java.awt.Stroke[] { stroke23 };
        java.awt.Shape shape25 = null;
        java.awt.Shape[] shapeArray26 = new java.awt.Shape[] { shape25 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray21, strokeArray22, strokeArray24, shapeArray26);
        java.awt.Paint paint28 = defaultDrawingSupplier27.getNextPaint();
        barRenderer0.setSeriesOutlinePaint(0, paint28, false);
        int int31 = barRenderer0.getPassCount();
        int int32 = barRenderer0.getRowCount();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(shapeArray26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("HorizontalAlignment.CENTER", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint5 = barRenderer1.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke7 = null;
        barRenderer1.setSeriesOutlineStroke(0, stroke7, true);
        java.awt.Stroke stroke12 = barRenderer1.getItemOutlineStroke((int) (byte) -1, 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = barRenderer1.getBaseItemLabelGenerator();
        java.awt.Color color14 = java.awt.Color.gray;
        barRenderer1.setBasePaint((java.awt.Paint) color14);
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double18 = numberAxis17.getLabelAngle();
        numberAxis17.setFixedDimension(0.0d);
        org.jfree.data.Range range21 = numberAxis17.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent22 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis17);
        java.util.EventListener eventListener23 = null;
        boolean boolean24 = numberAxis17.hasListener(eventListener23);
        java.awt.Stroke stroke25 = numberAxis17.getTickMarkStroke();
        java.awt.Paint paint26 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint29 = barRenderer27.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator31 = null;
        barRenderer27.setSeriesURLGenerator(10, categoryURLGenerator31, true);
        java.awt.Stroke stroke36 = barRenderer27.getItemOutlineStroke(1, (int) (byte) 1);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker(0.0d, (java.awt.Paint) color14, stroke25, paint26, stroke36, (float) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(stroke36);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        keyedObjects2D0.setObject((java.lang.Object) 0.2d, (java.lang.Comparable) numberTickUnit2, (java.lang.Comparable) 10);
        keyedObjects2D0.addObject((java.lang.Object) 2.0d, (java.lang.Comparable) 1, (java.lang.Comparable) 100);
        int int9 = keyedObjects2D0.getRowCount();
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        barRenderer3.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBaseNegativeItemLabelPosition();
        barRenderer0.setSeriesNegativeItemLabelPosition((int) '#', itemLabelPosition7);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        double double2 = barRenderer0.getLowerClip();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        int int28 = legendItem27.getSeriesIndex();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer29 = null;
        try {
            legendItem27.setFillPaintTransformer(gradientPaintTransformer29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color30);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double45 = numberAxis44.getLabelAngle();
        numberAxis44.setFixedDimension(0.0d);
        org.jfree.data.Range range48 = numberAxis44.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent49 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis44);
        java.awt.Shape shape50 = numberAxis44.getRightArrow();
        legendGraphic42.setLine(shape50);
        java.awt.Graphics2D graphics2D52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        java.lang.Object obj54 = null;
        try {
            java.lang.Object obj55 = legendGraphic42.draw(graphics2D52, rectangle2D53, obj54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(shape50);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.CENTER;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.LengthConstraintType lengthConstraintType2 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double6 = numberAxis5.getLabelAngle();
        numberAxis5.setFixedDimension(0.0d);
        org.jfree.data.Range range9 = numberAxis5.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double12 = numberAxis11.getLabelAngle();
        numberAxis11.setFixedDimension(0.0d);
        org.jfree.data.Range range15 = numberAxis11.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(range9, range15);
        org.jfree.data.Range range17 = rectangleConstraint16.getWidthRange();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType18 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint19 = new org.jfree.chart.block.RectangleConstraint((double) 0, range1, lengthConstraintType2, 0.0d, range17, lengthConstraintType18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertNotNull(range17);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        try {
            java.awt.Color color1 = java.awt.Color.decode("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double6 = numberAxis5.getLabelAngle();
        numberAxis5.setFixedDimension(0.0d);
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 0);
        numberAxis5.setUpArrow(shape10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint14 = barRenderer12.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint17 = barRenderer15.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint19 = barRenderer15.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke21 = null;
        barRenderer15.setSeriesOutlineStroke(0, stroke21, true);
        java.awt.Stroke stroke26 = barRenderer15.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer12.setBaseStroke(stroke26);
        org.jfree.chart.renderer.category.BarRenderer barRenderer29 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke30 = barRenderer29.getBaseStroke();
        barRenderer12.setSeriesOutlineStroke((int) (short) 10, stroke30);
        java.awt.Paint paint32 = null;
        try {
            org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem(attributedString0, "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", shape10, stroke30, paint32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        double double6 = defaultStatisticalCategoryDataset0.getRangeUpperBound(false);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = barRenderer0.getItemLabelGenerator((int) (byte) 0, (int) '4');
        java.awt.Stroke stroke6 = barRenderer0.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = barRenderer0.getLegendItems();
        try {
            org.jfree.chart.LegendItem legendItem9 = legendItemCollection7.get(10);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 10, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = org.jfree.chart.util.HorizontalAlignment.LEFT;
        org.junit.Assert.assertNotNull(horizontalAlignment0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        java.awt.Font font6 = barRenderer4.getBaseItemLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("{0}", font6, (java.awt.Paint) color11, (float) ' ');
        numberAxis1.setLabelFont(font6);
        numberAxis1.setLabelToolTip("");
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge23 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge22);
        try {
            double double25 = numberAxis1.valueToJava2D(3.0d, rectangle2D21, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(rectangleEdge23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint7 = barRenderer3.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke9 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke9, true);
        java.awt.Stroke stroke14 = barRenderer3.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer0.setBaseStroke(stroke14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke18 = barRenderer17.getBaseStroke();
        barRenderer0.setSeriesOutlineStroke((int) (short) 10, stroke18);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo24 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo25 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo24);
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState26 = barRenderer0.initialise(graphics2D20, rectangle2D21, categoryPlot22, (int) (byte) 100, plotRenderingInfo25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double7 = numberAxis6.getLabelAngle();
        numberAxis6.setFixedDimension(0.0d);
        org.jfree.data.Range range10 = numberAxis6.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent11 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis6);
        numberAxis6.setUpperBound((double) '4');
        numberAxis6.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.axis.AxisState axisState18 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        java.util.List list21 = numberAxis6.refreshTicks(graphics2D16, axisState18, rectangle2D19, rectangleEdge20);
        org.jfree.chart.util.UnitType unitType22 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean23 = numberAxis6.equals((java.lang.Object) unitType22);
        numberAxis6.setInverted(true);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            barRenderer0.drawRangeGridline(graphics2D3, categoryPlot4, (org.jfree.chart.axis.ValueAxis) numberAxis6, rectangle2D26, (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNotNull(unitType22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
        org.junit.Assert.assertNull(classLoader0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke6 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke6, true);
        java.awt.Stroke stroke11 = barRenderer0.getItemOutlineStroke((int) (byte) -1, 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = barRenderer0.getBaseItemLabelGenerator();
        double double13 = barRenderer0.getUpperClip();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 0, (double) 10, (double) 100L, (double) '4');
        double double6 = rectangleInsets4.extendWidth((double) (-15423));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-15361.0d) + "'", double6 == (-15361.0d));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) "{0}");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        java.lang.String str5 = textAnchor1.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str5.equals("TextAnchor.BOTTOM_CENTER"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("", "");
        java.lang.String str3 = contributor2.getEmail();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("TextAnchor.BOTTOM_CENTER");
        try {
            java.lang.String str4 = jFreeChartResources0.getString("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint5 = barRenderer1.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke7 = null;
        barRenderer1.setSeriesOutlineStroke(0, stroke7, true);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        barRenderer1.setBaseItemLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = barRenderer1.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke18 = barRenderer17.getBaseStroke();
        java.awt.Font font19 = barRenderer17.getBaseItemLabelFont();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean26 = color24.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color24);
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("{0}", font19, (java.awt.Paint) color24, (float) ' ');
        java.awt.Font font30 = textFragment29.getFont();
        barRenderer1.setSeriesItemLabelFont(0, font30);
        java.awt.Color color32 = java.awt.Color.green;
        org.jfree.chart.text.TextLine textLine33 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_CENTER", font30, (java.awt.Paint) color32);
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor37 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor38 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType39 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition41 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor37, textBlockAnchor38, categoryLabelWidthType39, (float) 0L);
        org.jfree.chart.text.TextAnchor textAnchor42 = categoryLabelPosition41.getRotationAnchor();
        org.jfree.chart.text.TextAnchor textAnchor43 = categoryLabelPosition41.getRotationAnchor();
        try {
            textLine33.draw(graphics2D34, (float) 8, 0.0f, textAnchor43, (float) 10L, 1.0f, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(rectangleAnchor37);
        org.junit.Assert.assertNotNull(textBlockAnchor38);
        org.junit.Assert.assertNotNull(categoryLabelWidthType39);
        org.junit.Assert.assertNotNull(textAnchor42);
        org.junit.Assert.assertNotNull(textAnchor43);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke2 = barRenderer1.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        barRenderer1.notifyListeners(rendererChangeEvent3);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = barRenderer1.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape6 = barRenderer1.getBaseShape();
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape6, (double) (byte) 10, (float) 10, (float) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(itemLabelPosition5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.lang.Object obj1 = barRenderer0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        java.awt.Shape shape7 = numberAxis1.getRightArrow();
        boolean boolean8 = numberAxis1.isVerticalTickLabels();
        java.lang.String str9 = numberAxis1.getLabel();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "hi!" + "'", str9.equals("hi!"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0, jFreeChart8, chartChangeEventType9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint13 = barRenderer11.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        barRenderer11.setSeriesURLGenerator(10, categoryURLGenerator15, true);
        boolean boolean18 = barRenderer11.getAutoPopulateSeriesStroke();
        java.awt.Paint paint20 = barRenderer11.lookupSeriesFillPaint(10);
        barRenderer0.setBaseFillPaint(paint20);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = barRenderer0.getToolTipGenerator((int) '4', (int) '4');
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNull(categoryToolTipGenerator24);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        barRenderer2.setSeriesURLGenerator(10, categoryURLGenerator6, true);
        boolean boolean9 = barRenderer2.getAutoPopulateSeriesStroke();
        java.awt.Paint paint11 = barRenderer2.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke13 = barRenderer12.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent14 = null;
        barRenderer12.notifyListeners(rendererChangeEvent14);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer12.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape17 = barRenderer12.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity18 = new org.jfree.chart.entity.LegendItemEntity(shape17);
        barRenderer2.setBaseShape(shape17, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity23 = new org.jfree.chart.entity.TickLabelEntity(shape17, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Shape shape24 = tickLabelEntity23.getArea();
        boolean boolean25 = org.jfree.chart.util.ShapeUtilities.equal(shape1, shape24);
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.data.Range range0 = org.jfree.chart.axis.ValueAxis.DEFAULT_RANGE;
        org.junit.Assert.assertNotNull(range0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(10.0d, (double) 10.0f, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (double) (byte) 0);
        java.util.EventListener eventListener4 = null;
        boolean boolean5 = defaultStatisticalCategoryDataset0.hasListener(eventListener4);
        org.jfree.data.general.PieDataset pieDataset7 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 100.0f);
        try {
            java.lang.Comparable comparable9 = defaultStatisticalCategoryDataset0.getRowKey(100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(pieDataset7);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        java.awt.Font font6 = barRenderer4.getBaseItemLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("{0}", font6, (java.awt.Paint) color11, (float) ' ');
        numberAxis1.setLabelFont(font6);
        numberAxis1.setLabelToolTip("");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit20 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        numberAxis1.setTickUnit(numberTickUnit20, false, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(numberTickUnit20);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        categoryPlot0.setDomainAxis(categoryAxis1);
        java.util.List list3 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(list3);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]", class1);
        org.junit.Assert.assertNull(obj2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        keyedObjects2D0.setObject((java.lang.Object) 0.2d, (java.lang.Comparable) numberTickUnit2, (java.lang.Comparable) 10);
        keyedObjects2D0.addObject((java.lang.Object) 2.0d, (java.lang.Comparable) 1, (java.lang.Comparable) 100);
        org.jfree.chart.axis.AxisState axisState10 = new org.jfree.chart.axis.AxisState(10.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        axisState10.moveCursor(1.0d, rectangleEdge12);
        double double14 = axisState10.getMax();
        keyedObjects2D0.addObject((java.lang.Object) axisState10, (java.lang.Comparable) 'a', (java.lang.Comparable) (-1));
        try {
            keyedObjects2D0.removeColumn(1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        try {
            numberAxis1.setRange(100.0d, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        keyedObjects2D0.setObject((java.lang.Object) 0.2d, (java.lang.Comparable) numberTickUnit2, (java.lang.Comparable) 10);
        keyedObjects2D0.addObject((java.lang.Object) 2.0d, (java.lang.Comparable) 1, (java.lang.Comparable) 100);
        org.jfree.chart.axis.AxisState axisState10 = new org.jfree.chart.axis.AxisState(10.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        axisState10.moveCursor(1.0d, rectangleEdge12);
        double double14 = axisState10.getMax();
        keyedObjects2D0.addObject((java.lang.Object) axisState10, (java.lang.Comparable) 'a', (java.lang.Comparable) (-1));
        int int18 = keyedObjects2D0.getColumnCount();
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Shape shape10 = barRenderer0.lookupSeriesShape(10);
        boolean boolean11 = barRenderer0.getBaseSeriesVisibleInLegend();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint5 = barRenderer1.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Paint paint6 = barRenderer1.getBaseItemLabelPaint();
        java.awt.Paint paint7 = barRenderer1.getBaseFillPaint();
        java.awt.Stroke stroke8 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        java.awt.Paint paint9 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint12 = barRenderer10.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = null;
        barRenderer10.setSeriesURLGenerator(10, categoryURLGenerator14, true);
        boolean boolean17 = barRenderer10.getAutoPopulateSeriesStroke();
        java.awt.Paint paint19 = barRenderer10.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke21 = barRenderer20.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        barRenderer20.notifyListeners(rendererChangeEvent22);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = barRenderer20.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape25 = barRenderer20.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity26 = new org.jfree.chart.entity.LegendItemEntity(shape25);
        barRenderer10.setBaseShape(shape25, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity31 = new org.jfree.chart.entity.TickLabelEntity(shape25, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke34 = barRenderer33.getBaseStroke();
        java.awt.Font font35 = barRenderer33.getBaseItemLabelFont();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean42 = color40.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder43 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color40);
        org.jfree.chart.text.TextFragment textFragment45 = new org.jfree.chart.text.TextFragment("{0}", font35, (java.awt.Paint) color40, (float) ' ');
        java.awt.image.ColorModel colorModel46 = null;
        java.awt.Rectangle rectangle47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.geom.AffineTransform affineTransform49 = null;
        java.awt.RenderingHints renderingHints50 = null;
        java.awt.PaintContext paintContext51 = color40.createContext(colorModel46, rectangle47, rectangle2D48, affineTransform49, renderingHints50);
        org.jfree.chart.title.LegendGraphic legendGraphic52 = new org.jfree.chart.title.LegendGraphic(shape25, (java.awt.Paint) color40);
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double55 = numberAxis54.getLabelAngle();
        numberAxis54.setFixedDimension(0.0d);
        org.jfree.data.Range range58 = numberAxis54.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent59 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis54);
        java.awt.Shape shape60 = numberAxis54.getRightArrow();
        legendGraphic52.setLine(shape60);
        legendGraphic52.setWidth(0.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer64 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint66 = barRenderer64.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer67 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint69 = barRenderer67.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint71 = barRenderer67.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke73 = null;
        barRenderer67.setSeriesOutlineStroke(0, stroke73, true);
        java.awt.Stroke stroke78 = barRenderer67.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer64.setBaseStroke(stroke78);
        legendGraphic52.setOutlineStroke(stroke78);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker82 = new org.jfree.chart.plot.ValueMarker(0.0d, paint7, stroke8, paint9, stroke78, (float) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paintContext51);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(paint66);
        org.junit.Assert.assertNotNull(paint69);
        org.junit.Assert.assertNull(paint71);
        org.junit.Assert.assertNotNull(stroke78);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker5 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0, jFreeChart8, chartChangeEventType9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint13 = barRenderer11.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        barRenderer11.setSeriesURLGenerator(10, categoryURLGenerator15, true);
        boolean boolean18 = barRenderer11.getAutoPopulateSeriesStroke();
        java.awt.Paint paint20 = barRenderer11.lookupSeriesFillPaint(10);
        barRenderer0.setBaseFillPaint(paint20);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator22, true);
        barRenderer0.setBaseSeriesVisible(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        try {
            barRenderer0.setSeriesVisible((int) (byte) -1, (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str1 = sortOrder0.toString();
        org.junit.Assert.assertNotNull(sortOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "SortOrder.ASCENDING" + "'", str1.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        try {
            java.awt.geom.Point2D point2D2 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D0, rectangleAnchor1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        java.lang.String str1 = rangeType0.toString();
        org.junit.Assert.assertNotNull(rangeType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RangeType.FULL" + "'", str1.equals("RangeType.FULL"));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double14 = numberAxis13.getLabelAngle();
        numberAxis13.setFixedDimension(0.0d);
        org.jfree.data.Range range17 = numberAxis13.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis13);
        java.util.EventListener eventListener19 = null;
        boolean boolean20 = numberAxis13.hasListener(eventListener19);
        java.awt.Stroke stroke21 = numberAxis13.getTickMarkStroke();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint28 = barRenderer26.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint30 = barRenderer26.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke32 = null;
        barRenderer26.setSeriesOutlineStroke(0, stroke32, true);
        java.awt.Stroke stroke37 = barRenderer26.getItemOutlineStroke((int) (byte) -1, 0);
        java.awt.Color color38 = java.awt.Color.CYAN;
        int int39 = color38.getRed();
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("{0}", "", "EXPAND", "hi!", false, shape7, true, (java.awt.Paint) color9, true, (java.awt.Paint) color11, stroke21, false, shape25, stroke37, (java.awt.Paint) color38);
        float[] floatArray41 = new float[] {};
        try {
            float[] floatArray42 = color9.getColorComponents(floatArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(floatArray41);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double5 = numberAxis4.getLabelAngle();
        numberAxis4.setFixedDimension(0.0d);
        org.jfree.data.Range range8 = numberAxis4.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis4);
        java.util.EventListener eventListener10 = null;
        boolean boolean11 = numberAxis4.hasListener(eventListener10);
        java.awt.Stroke stroke12 = numberAxis4.getTickMarkStroke();
        org.jfree.data.Range range13 = numberAxis4.getRange();
        boolean boolean16 = range13.intersects((double) 2, (double) '#');
        numberAxis1.setRangeWithMargins(range13, false, true);
        java.lang.String str20 = range13.toString();
        double double21 = range13.getLength();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Range[0.0,1.0]" + "'", str20.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo10.getPlotArea();
        boolean boolean12 = categoryPlot0.render(graphics2D3, rectangle2D7, 0, plotRenderingInfo10);
        java.awt.Paint paint13 = null;
        try {
            categoryPlot0.setRangeGridlinePaint(paint13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo10.getPlotArea();
        boolean boolean12 = categoryPlot0.render(graphics2D3, rectangle2D7, 0, plotRenderingInfo10);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = barRenderer0.getPlot();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNull(categoryPlot5);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer2.getBaseStroke();
        java.awt.Font font4 = barRenderer2.getBaseItemLabelFont();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("{0}", font4, (java.awt.Paint) color9, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("ThreadContext", font4);
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image18 = null;
        categoryPlot17.setBackgroundImage(image18);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo21);
        java.awt.geom.Rectangle2D rectangle2D23 = plotRenderingInfo22.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D24 = plotRenderingInfo22.getDataArea();
        categoryPlot17.drawBackgroundImage(graphics2D20, rectangle2D24);
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean28 = numberAxis27.isTickMarksVisible();
        numberAxis27.setTickMarksVisible(false);
        boolean boolean31 = numberAxis27.isAutoRange();
        try {
            java.lang.Object obj32 = labelBlock15.draw(graphics2D16, rectangle2D24, (java.lang.Object) boolean31);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(rectangle2D23);
        org.junit.Assert.assertNotNull(rectangle2D24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) "{0}");
        java.lang.String str4 = textAnchor1.toString();
        boolean boolean5 = keyedObjects0.equals((java.lang.Object) str4);
        try {
            keyedObjects0.removeValue(2);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 2, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str4.equals("TextAnchor.BOTTOM_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.ui.Licences licences0 = new org.jfree.chart.ui.Licences();
        java.lang.String str1 = licences0.getLGPL();
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo10.getPlotArea();
        boolean boolean12 = categoryPlot0.render(graphics2D3, rectangle2D7, 0, plotRenderingInfo10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint15 = barRenderer13.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = null;
        barRenderer13.setSeriesURLGenerator(10, categoryURLGenerator17, true);
        boolean boolean20 = barRenderer13.getAutoPopulateSeriesStroke();
        java.awt.Paint paint22 = barRenderer13.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent25 = null;
        barRenderer23.notifyListeners(rendererChangeEvent25);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = barRenderer23.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape28 = barRenderer23.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity29 = new org.jfree.chart.entity.LegendItemEntity(shape28);
        barRenderer13.setBaseShape(shape28, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity34 = new org.jfree.chart.entity.TickLabelEntity(shape28, "java.awt.Color[r=128,g=128,b=0]", "");
        boolean boolean35 = plotRenderingInfo10.equals((java.lang.Object) "java.awt.Color[r=128,g=128,b=0]");
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
        org.junit.Assert.assertNotNull(shape28);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke28 = barRenderer27.getBaseStroke();
        java.awt.Font font29 = barRenderer27.getBaseItemLabelFont();
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean36 = color34.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder37 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color34);
        org.jfree.chart.text.TextFragment textFragment39 = new org.jfree.chart.text.TextFragment("{0}", font29, (java.awt.Paint) color34, (float) ' ');
        java.awt.image.ColorModel colorModel40 = null;
        java.awt.Rectangle rectangle41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        java.awt.geom.AffineTransform affineTransform43 = null;
        java.awt.RenderingHints renderingHints44 = null;
        java.awt.PaintContext paintContext45 = color34.createContext(colorModel40, rectangle41, rectangle2D42, affineTransform43, renderingHints44);
        org.jfree.chart.title.LegendGraphic legendGraphic46 = new org.jfree.chart.title.LegendGraphic(shape19, (java.awt.Paint) color34);
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double49 = numberAxis48.getLabelAngle();
        numberAxis48.setFixedDimension(0.0d);
        org.jfree.data.Range range52 = numberAxis48.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent53 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis48);
        java.awt.Shape shape54 = numberAxis48.getRightArrow();
        legendGraphic46.setLine(shape54);
        java.awt.Paint paint56 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_PAINT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer57 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint59 = barRenderer57.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer60 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint62 = barRenderer60.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint64 = barRenderer60.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke66 = null;
        barRenderer60.setSeriesOutlineStroke(0, stroke66, true);
        java.awt.Stroke stroke71 = barRenderer60.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer57.setBaseStroke(stroke71);
        org.jfree.chart.renderer.category.BarRenderer barRenderer74 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke75 = barRenderer74.getBaseStroke();
        barRenderer57.setSeriesOutlineStroke((int) (short) 10, stroke75);
        java.awt.Color color77 = java.awt.Color.GREEN;
        try {
            org.jfree.chart.LegendItem legendItem78 = new org.jfree.chart.LegendItem(attributedString0, "ThreadContext", "", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", shape54, paint56, stroke75, (java.awt.Paint) color77);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(paintContext45);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertNotNull(shape54);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNull(paint64);
        org.junit.Assert.assertNotNull(stroke71);
        org.junit.Assert.assertNotNull(stroke75);
        org.junit.Assert.assertNotNull(color77);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        java.text.AttributedString attributedString28 = legendItem27.getAttributedLabel();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNull(attributedString28);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_OUTSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 2.0f + "'", float0 == 2.0f);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        java.awt.Color color9 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color11 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double14 = numberAxis13.getLabelAngle();
        numberAxis13.setFixedDimension(0.0d);
        org.jfree.data.Range range17 = numberAxis13.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent18 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis13);
        java.util.EventListener eventListener19 = null;
        boolean boolean20 = numberAxis13.hasListener(eventListener19);
        java.awt.Stroke stroke21 = numberAxis13.getTickMarkStroke();
        java.awt.Shape shape25 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint28 = barRenderer26.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint30 = barRenderer26.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke32 = null;
        barRenderer26.setSeriesOutlineStroke(0, stroke32, true);
        java.awt.Stroke stroke37 = barRenderer26.getItemOutlineStroke((int) (byte) -1, 0);
        java.awt.Color color38 = java.awt.Color.CYAN;
        int int39 = color38.getRed();
        org.jfree.chart.LegendItem legendItem40 = new org.jfree.chart.LegendItem("{0}", "", "EXPAND", "hi!", false, shape7, true, (java.awt.Paint) color9, true, (java.awt.Paint) color11, stroke21, false, shape25, stroke37, (java.awt.Paint) color38);
        java.awt.Color color41 = color11.brighter();
        java.lang.String str42 = color11.toString();
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(color41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "java.awt.Color[r=255,g=255,b=64]" + "'", str42.equals("java.awt.Color[r=255,g=255,b=64]"));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0, jFreeChart8, chartChangeEventType9);
        org.jfree.chart.JFreeChart jFreeChart11 = chartChangeEvent10.getChart();
        java.lang.Object obj12 = chartChangeEvent10.getSource();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNull(jFreeChart11);
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.axis.NumberAxis numberAxis2 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double3 = numberAxis2.getLabelAngle();
        numberAxis2.setFixedDimension(0.0d);
        org.jfree.data.Range range6 = numberAxis2.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double9 = numberAxis8.getLabelAngle();
        numberAxis8.setFixedDimension(0.0d);
        org.jfree.data.Range range12 = numberAxis8.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint13 = new org.jfree.chart.block.RectangleConstraint(range6, range12);
        double double14 = range12.getLength();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType15 = null;
        org.jfree.chart.axis.NumberAxis numberAxis18 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double19 = numberAxis18.getLabelAngle();
        numberAxis18.setFixedDimension(0.0d);
        org.jfree.data.Range range22 = numberAxis18.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double25 = numberAxis24.getLabelAngle();
        numberAxis24.setFixedDimension(0.0d);
        org.jfree.data.Range range28 = numberAxis24.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint29 = new org.jfree.chart.block.RectangleConstraint(range22, range28);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType30 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint31 = new org.jfree.chart.block.RectangleConstraint(10.0d, range12, lengthConstraintType15, 2.0d, range28, lengthConstraintType30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'widthType' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(range22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(range28);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint5 = barRenderer1.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke7 = null;
        barRenderer1.setSeriesOutlineStroke(0, stroke7, true);
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        barRenderer1.setBaseItemLabelPaint((java.awt.Paint) color10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator14 = barRenderer1.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke18 = barRenderer17.getBaseStroke();
        java.awt.Font font19 = barRenderer17.getBaseItemLabelFont();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean26 = color24.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder27 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color24);
        org.jfree.chart.text.TextFragment textFragment29 = new org.jfree.chart.text.TextFragment("{0}", font19, (java.awt.Paint) color24, (float) ' ');
        java.awt.Font font30 = textFragment29.getFont();
        barRenderer1.setSeriesItemLabelFont(0, font30);
        java.awt.Color color32 = java.awt.Color.green;
        org.jfree.chart.text.TextLine textLine33 = new org.jfree.chart.text.TextLine("TextAnchor.BOTTOM_CENTER", font30, (java.awt.Paint) color32);
        java.awt.Graphics2D graphics2D34 = null;
        try {
            org.jfree.chart.util.Size2D size2D35 = textLine33.calculateDimensions(graphics2D34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(font30);
        org.junit.Assert.assertNotNull(color32);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.awt.Color color0 = java.awt.Color.blue;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        double double3 = barRenderer0.getMaximumBarWidth();
        barRenderer0.setBaseSeriesVisible(true, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        java.awt.Paint paint28 = legendItem27.getLinePaint();
        java.lang.Comparable comparable29 = legendItem27.getSeriesKey();
        int int30 = legendItem27.getDatasetIndex();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(comparable29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        categoryPlot0.clearDomainAxes();
        boolean boolean4 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = barRenderer0.getPositiveItemLabelPositionFallback();
        java.awt.Shape shape10 = barRenderer0.lookupSeriesShape(10);
        org.jfree.chart.LegendItem legendItem13 = barRenderer0.getLegendItem(8, (int) (short) 0);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(itemLabelPosition8);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNull(legendItem13);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        try {
            java.util.Collection collection2 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list1);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = barRenderer0.getItemLabelGenerator((int) (byte) 0, (int) '4');
        java.awt.Stroke stroke6 = barRenderer0.getBaseStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection7 = barRenderer0.getLegendItems();
        java.lang.Object obj8 = legendItemCollection7.clone();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem10 = null;
        legendItemCollection9.add(legendItem10);
        legendItemCollection7.addAll(legendItemCollection9);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(legendItemCollection7);
        org.junit.Assert.assertNotNull(obj8);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        java.awt.Paint paint15 = barRenderer10.getSeriesItemLabelPaint(0);
        java.awt.Paint paint16 = barRenderer10.getBaseItemLabelPaint();
        barRenderer0.setBaseOutlinePaint(paint16, true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color30);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double45 = numberAxis44.getLabelAngle();
        numberAxis44.setFixedDimension(0.0d);
        org.jfree.data.Range range48 = numberAxis44.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent49 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis44);
        java.awt.Shape shape50 = numberAxis44.getRightArrow();
        legendGraphic42.setLine(shape50);
        legendGraphic42.setWidth(0.0d);
        java.awt.Color color54 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean56 = color54.equals((java.lang.Object) 0.0d);
        legendGraphic42.setFillPaint((java.awt.Paint) color54);
        java.awt.Paint paint58 = legendGraphic42.getFillPaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(paint58);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        categoryPlot0.drawBackgroundImage(graphics2D3, rectangle2D7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis10, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot0.getRenderer((int) (byte) -1);
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNull(categoryItemRenderer14);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis1.refreshTicks(graphics2D11, axisState13, rectangle2D14, rectangleEdge15);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand17 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNull(markerAxisBand17);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.RendererState rendererState1 = new org.jfree.chart.renderer.RendererState(plotRenderingInfo0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        java.awt.Font font6 = barRenderer4.getBaseItemLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("{0}", font6, (java.awt.Paint) color11, (float) ' ');
        numberAxis1.setLabelFont(font6);
        numberAxis1.setLabelToolTip("");
        numberAxis1.setVerticalTickLabels(true);
        double double22 = numberAxis1.getUpperBound();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("TextAnchor.BOTTOM_CENTER", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.block.BlockResult blockResult0 = new org.jfree.chart.block.BlockResult();
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint7 = barRenderer3.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke9 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke9, true);
        java.awt.Stroke stroke14 = barRenderer3.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer0.setBaseStroke(stroke14);
        boolean boolean16 = barRenderer0.getAutoPopulateSeriesPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = barRenderer17.getSeriesNegativeItemLabelPosition((int) (short) -1);
        barRenderer0.setNegativeItemLabelPositionFallback(itemLabelPosition19);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition19);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("hi!");
        java.lang.Object obj2 = datasetGroup1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = barRenderer0.getSeriesNegativeItemLabelPosition((int) (short) -1);
        boolean boolean3 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        double double4 = barRenderer0.getItemLabelAnchorOffset();
        org.junit.Assert.assertNotNull(itemLabelPosition2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2.0d + "'", double4 == 2.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor1 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType2 = org.jfree.chart.axis.CategoryLabelWidthType.RANGE;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition4 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor0, textBlockAnchor1, categoryLabelWidthType2, (float) 0L);
        java.lang.String str5 = rectangleAnchor0.toString();
        org.junit.Assert.assertNotNull(rectangleAnchor0);
        org.junit.Assert.assertNotNull(textBlockAnchor1);
        org.junit.Assert.assertNotNull(categoryLabelWidthType2);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleAnchor.BOTTOM" + "'", str5.equals("RectangleAnchor.BOTTOM"));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint11 = barRenderer9.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint13 = barRenderer9.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke15 = null;
        barRenderer9.setSeriesOutlineStroke(0, stroke15, true);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean20 = color18.equals((java.lang.Object) 0.0d);
        barRenderer9.setBaseItemLabelPaint((java.awt.Paint) color18);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator22 = barRenderer9.getLegendItemToolTipGenerator();
        barRenderer9.setAutoPopulateSeriesOutlinePaint(false);
        java.awt.Shape shape33 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        java.awt.Color color35 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color37 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double40 = numberAxis39.getLabelAngle();
        numberAxis39.setFixedDimension(0.0d);
        org.jfree.data.Range range43 = numberAxis39.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent44 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis39);
        java.util.EventListener eventListener45 = null;
        boolean boolean46 = numberAxis39.hasListener(eventListener45);
        java.awt.Stroke stroke47 = numberAxis39.getTickMarkStroke();
        java.awt.Shape shape51 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer52 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint54 = barRenderer52.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint56 = barRenderer52.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke58 = null;
        barRenderer52.setSeriesOutlineStroke(0, stroke58, true);
        java.awt.Stroke stroke63 = barRenderer52.getItemOutlineStroke((int) (byte) -1, 0);
        java.awt.Color color64 = java.awt.Color.CYAN;
        int int65 = color64.getRed();
        org.jfree.chart.LegendItem legendItem66 = new org.jfree.chart.LegendItem("{0}", "", "EXPAND", "hi!", false, shape33, true, (java.awt.Paint) color35, true, (java.awt.Paint) color37, stroke47, false, shape51, stroke63, (java.awt.Paint) color64);
        barRenderer9.setSeriesOutlineStroke(2, stroke63, true);
        numberAxis1.setAxisLineStroke(stroke63);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator22);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(stroke47);
        org.junit.Assert.assertNotNull(shape51);
        org.junit.Assert.assertNotNull(paint54);
        org.junit.Assert.assertNull(paint56);
        org.junit.Assert.assertNotNull(stroke63);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        numberAxis4.setAutoRange(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = numberAxis4.getTickUnit();
        java.lang.Comparable comparable9 = null;
        defaultStatisticalCategoryDataset0.add(Double.NaN, 0.0d, (java.lang.Comparable) numberTickUnit8, comparable9);
        java.lang.Number number13 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) (-1.0f), (java.lang.Comparable) false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(numberTickUnit8);
        org.junit.Assert.assertNull(number13);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) "{0}");
        java.lang.String str4 = textAnchor1.toString();
        boolean boolean5 = keyedObjects0.equals((java.lang.Object) str4);
        try {
            keyedObjects0.removeValue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str4.equals("TextAnchor.BOTTOM_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double8 = numberAxis7.getLabelAngle();
        numberAxis7.setFixedDimension(0.0d);
        org.jfree.data.Range range11 = numberAxis7.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range5, range11);
        java.lang.String str13 = range5.toString();
        double double15 = range5.constrain((double) (-1.0f));
        double double16 = range5.getLowerBound();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Range[0.0,1.0]" + "'", str13.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        boolean boolean0 = org.jfree.chart.text.TextUtilities.getUseFontMetricsGetStringBounds();
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke6 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke6, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        boolean boolean13 = barRenderer0.getIncludeBaseInRange();
        barRenderer0.setBaseSeriesVisibleInLegend(true);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation16 = null;
        boolean boolean17 = barRenderer0.removeAnnotation(categoryAnnotation16);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) "{0}");
        java.lang.String str4 = textAnchor1.toString();
        boolean boolean5 = keyedObjects0.equals((java.lang.Object) str4);
        java.lang.Object obj7 = keyedObjects0.getObject((java.lang.Comparable) (-1.0d));
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str4.equals("TextAnchor.BOTTOM_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState8 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo5);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.awt.Paint paint1 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint4 = barRenderer2.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator6 = null;
        barRenderer2.setSeriesURLGenerator(10, categoryURLGenerator6, true);
        java.awt.Stroke stroke11 = barRenderer2.getItemOutlineStroke(1, (int) (byte) 1);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker12 = new org.jfree.chart.plot.ValueMarker((double) 10L, paint1, stroke11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("", "java.awt.Color[r=255,g=255,b=64]", "EXPAND", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]");
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        keyedObjects2D0.setObject((java.lang.Object) 0.2d, (java.lang.Comparable) numberTickUnit2, (java.lang.Comparable) 10);
        int int5 = keyedObjects2D0.getColumnCount();
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition1 = new org.jfree.chart.axis.CategoryLabelPosition();
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions2 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color30);
        java.awt.Paint paint43 = null;
        legendGraphic42.setFillPaint(paint43);
        java.awt.Paint paint45 = legendGraphic42.getOutlinePaint();
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.axis.NumberAxis numberAxis48 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double49 = numberAxis48.getLabelAngle();
        numberAxis48.setFixedDimension(0.0d);
        org.jfree.data.Range range52 = numberAxis48.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis54 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double55 = numberAxis54.getLabelAngle();
        numberAxis54.setFixedDimension(0.0d);
        org.jfree.data.Range range58 = numberAxis54.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint59 = new org.jfree.chart.block.RectangleConstraint(range52, range58);
        double double60 = rectangleConstraint59.getHeight();
        try {
            org.jfree.chart.util.Size2D size2D61 = legendGraphic42.arrange(graphics2D46, rectangleConstraint59);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertNull(paint45);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(range52);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(range58);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation3 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean7 = color5.equals((java.lang.Object) 0.0d);
        numberAxis1.setAxisLinePaint((java.awt.Paint) color5);
        java.awt.Paint paint9 = numberAxis1.getAxisLinePaint();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 0);
        numberAxis1.setUpArrow(shape11);
        org.jfree.chart.axis.NumberAxis numberAxis14 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean15 = numberAxis14.isTickMarksVisible();
        numberAxis14.setTickMarksVisible(false);
        boolean boolean18 = numberAxis1.equals((java.lang.Object) numberAxis14);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("{0}", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis1.refreshTicks(graphics2D11, axisState13, rectangle2D14, rectangleEdge15);
        java.lang.Object obj17 = null;
        boolean boolean18 = numberAxis1.equals(obj17);
        try {
            numberAxis1.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        java.lang.ClassLoader classLoader0 = null;
        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getSeriesItemLabelGenerator((int) (short) 1);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator5);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0, jFreeChart8, chartChangeEventType9);
        org.jfree.chart.axis.NumberAxis numberAxis12 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean13 = numberAxis12.isTickLabelsVisible();
        org.jfree.chart.axis.NumberAxis numberAxis15 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double16 = numberAxis15.getLabelAngle();
        numberAxis15.setFixedDimension(0.0d);
        org.jfree.data.Range range19 = numberAxis15.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double22 = numberAxis21.getLabelAngle();
        numberAxis21.setFixedDimension(0.0d);
        org.jfree.data.Range range25 = numberAxis21.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint26 = new org.jfree.chart.block.RectangleConstraint(range19, range25);
        numberAxis12.setRangeWithMargins(range19);
        boolean boolean28 = chartChangeEventType9.equals((java.lang.Object) numberAxis12);
        java.lang.Object obj29 = null;
        boolean boolean30 = chartChangeEventType9.equals(obj29);
        java.lang.String str31 = chartChangeEventType9.toString();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "ChartChangeEventType.DATASET_UPDATED" + "'", str31.equals("ChartChangeEventType.DATASET_UPDATED"));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color30);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double45 = numberAxis44.getLabelAngle();
        numberAxis44.setFixedDimension(0.0d);
        org.jfree.data.Range range48 = numberAxis44.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent49 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis44);
        java.awt.Shape shape50 = numberAxis44.getRightArrow();
        legendGraphic42.setLine(shape50);
        legendGraphic42.setWidth(0.0d);
        org.jfree.chart.renderer.category.BarRenderer barRenderer54 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint56 = barRenderer54.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer57 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint59 = barRenderer57.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint61 = barRenderer57.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke63 = null;
        barRenderer57.setSeriesOutlineStroke(0, stroke63, true);
        java.awt.Stroke stroke68 = barRenderer57.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer54.setBaseStroke(stroke68);
        legendGraphic42.setOutlineStroke(stroke68);
        legendGraphic42.setShapeFilled(false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNull(paint61);
        org.junit.Assert.assertNotNull(stroke68);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (byte) 10);
        axisState1.cursorRight((double) (short) 10);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) (short) -1);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        double double6 = numberAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.05d + "'", double6 == 0.05d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        numberAxis1.zoomRange((double) (short) 0, 10.0d);
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        numberAxis1.setTickLabelPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        categoryPlot0.configureDomainAxes();
        int int8 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = new org.jfree.chart.util.RectangleInsets();
        categoryPlot0.setInsets(rectangleInsets9);
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(axisSpace11);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer2.getBaseStroke();
        java.awt.Font font4 = barRenderer2.getBaseItemLabelFont();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("{0}", font4, (java.awt.Paint) color9, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("ThreadContext", font4);
        java.awt.Paint paint16 = labelBlock15.getPaint();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image19 = null;
        categoryPlot18.setBackgroundImage(image19);
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo22 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo22);
        java.awt.geom.Rectangle2D rectangle2D24 = plotRenderingInfo23.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D25 = plotRenderingInfo23.getDataArea();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo27 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo27);
        java.awt.geom.Rectangle2D rectangle2D29 = plotRenderingInfo28.getPlotArea();
        boolean boolean30 = categoryPlot18.render(graphics2D21, rectangle2D25, 0, plotRenderingInfo28);
        try {
            labelBlock15.draw(graphics2D17, rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNull(rectangle2D24);
        org.junit.Assert.assertNotNull(rectangle2D25);
        org.junit.Assert.assertNull(rectangle2D29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Stroke stroke2 = null;
        try {
            valueMarker1.setStroke(stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = categoryPlot0.getDomainGridlinePosition();
        int int8 = categoryPlot0.getRangeAxisCount();
        categoryPlot0.clearDomainMarkers((int) '4');
        java.util.List list11 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(list11);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Paint paint5 = barRenderer0.getBaseItemLabelPaint();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint8 = barRenderer6.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint11 = barRenderer9.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint13 = barRenderer9.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke15 = null;
        barRenderer9.setSeriesOutlineStroke(0, stroke15, true);
        java.awt.Stroke stroke20 = barRenderer9.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer6.setBaseStroke(stroke20);
        barRenderer0.setBaseOutlineStroke(stroke20);
        double double23 = barRenderer0.getLowerClip();
        barRenderer0.setMaximumBarWidth((double) 10);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean5 = numberAxis4.isTickLabelsVisible();
        numberAxis4.setAutoRange(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit8 = numberAxis4.getTickUnit();
        java.lang.Comparable comparable9 = null;
        defaultStatisticalCategoryDataset0.add(Double.NaN, 0.0d, (java.lang.Comparable) numberTickUnit8, comparable9);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(numberTickUnit8);
        org.junit.Assert.assertNull(range12);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Paint paint6 = barRenderer0.lookupSeriesFillPaint((int) (byte) 100);
        org.jfree.chart.renderer.category.BarRenderer barRenderer8 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint10 = barRenderer8.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer8.setSeriesURLGenerator(10, categoryURLGenerator12, true);
        boolean boolean15 = barRenderer8.getAutoPopulateSeriesStroke();
        java.awt.Paint paint17 = barRenderer8.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke19 = barRenderer18.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        barRenderer18.notifyListeners(rendererChangeEvent20);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer18.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape23 = barRenderer18.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity24 = new org.jfree.chart.entity.LegendItemEntity(shape23);
        barRenderer8.setBaseShape(shape23, true);
        barRenderer0.setSeriesShape(0, shape23, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator29 = null;
        barRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator29);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset1 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number2 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1);
        org.jfree.data.Range range4 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, (double) (byte) 0);
        java.util.EventListener eventListener5 = null;
        boolean boolean6 = defaultStatisticalCategoryDataset1.hasListener(eventListener5);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset1, (java.lang.Comparable) 100.0f);
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) '4', (org.jfree.data.KeyedValues) pieDataset8);
        org.junit.Assert.assertEquals((double) number2, Double.NaN, 0);
        org.junit.Assert.assertNull(range4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertNotNull(categoryDataset9);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation((int) (short) -1);
        boolean boolean10 = categoryPlot0.isRangeGridlinesVisible();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(datasetGroup11);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.awt.Font font1 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer2.getBaseStroke();
        java.awt.Font font4 = barRenderer2.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer2.getItemLabelGenerator((int) (byte) 0, (int) '4');
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean10 = numberAxis9.isTickMarksVisible();
        numberAxis9.setTickMarksVisible(false);
        boolean boolean13 = numberAxis9.isAutoRange();
        java.awt.Paint paint14 = numberAxis9.getTickLabelPaint();
        barRenderer2.setBasePaint(paint14);
        try {
            org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("ThreadContext", font1, paint14, 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint14);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 0);
        numberAxis1.setUpArrow(shape6);
        org.jfree.chart.entity.ChartEntity chartEntity8 = new org.jfree.chart.entity.ChartEntity(shape6);
        java.lang.Object obj9 = chartEntity8.clone();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(obj9);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        categoryPlot0.configureDomainAxes();
        int int8 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.util.SortOrder sortOrder9 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder9);
        java.awt.Color color14 = java.awt.Color.getHSBColor((float) 100L, (float) (byte) 0, 0.0f);
        categoryPlot0.setDomainGridlinePaint((java.awt.Paint) color14);
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.ui.Contributor contributor2 = new org.jfree.chart.ui.Contributor("PlotOrientation.VERTICAL", "ThreadContext");
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double8 = numberAxis7.getLabelAngle();
        numberAxis7.setFixedDimension(0.0d);
        org.jfree.data.Range range11 = numberAxis7.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range5, range11);
        java.lang.String str13 = rectangleConstraint12.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str13.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (int) '#');
        double double6 = org.jfree.data.general.DatasetUtilities.calculatePieDatasetTotal(pieDataset5);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        categoryPlot0.configureDomainAxes();
        int int8 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.util.SortOrder sortOrder9 = org.jfree.chart.util.SortOrder.DESCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint13 = barRenderer11.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray14 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] { barRenderer11 };
        categoryPlot0.setRenderers(categoryItemRendererArray14);
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(categoryItemRendererArray14);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        categoryPlot0.configureDomainAxes();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9, true);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener13 = null;
        defaultStatisticalCategoryDataset9.addChangeListener(datasetChangeListener13);
        java.lang.Number number17 = defaultStatisticalCategoryDataset9.getMeanValue((java.lang.Comparable) 15, (java.lang.Comparable) 1.0f);
        int int18 = defaultStatisticalCategoryDataset9.getColumnCount();
        categoryPlot0.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder20 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertEquals((double) number10, Double.NaN, 0);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(datasetRenderingOrder20);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double5 = numberAxis4.getLabelAngle();
        numberAxis4.setFixedDimension(0.0d);
        org.jfree.data.Range range8 = numberAxis4.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double11 = numberAxis10.getLabelAngle();
        numberAxis10.setFixedDimension(0.0d);
        org.jfree.data.Range range14 = numberAxis10.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(range8, range14);
        numberAxis1.setRangeWithMargins(range8);
        double double17 = range8.getLength();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        barRenderer3.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock1, textBlockAnchor2, textAnchor8, 0.0d);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock1.calculateDimensions(graphics2D11);
        size2D12.setHeight((double) 15);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(size2D12);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        java.awt.Font font6 = barRenderer4.getBaseItemLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("{0}", font6, (java.awt.Paint) color11, (float) ' ');
        numberAxis1.setLabelFont(font6);
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setUpperMargin(0.2d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Shape shape3 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace6 = color5.getColorSpace();
        categoryPlot4.setOutlinePaint((java.awt.Paint) color5);
        java.awt.Paint paint8 = categoryPlot4.getOutlinePaint();
        org.jfree.chart.title.LegendGraphic legendGraphic9 = new org.jfree.chart.title.LegendGraphic(shape3, paint8);
        valueMarker1.setPaint(paint8);
        java.awt.Paint paint11 = valueMarker1.getOutlinePaint();
        org.jfree.chart.text.TextAnchor textAnchor12 = null;
        try {
            valueMarker1.setLabelTextAnchor(textAnchor12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape3);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(colorSpace6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(paint11);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        java.awt.Font font6 = barRenderer4.getBaseItemLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("{0}", font6, (java.awt.Paint) color11, (float) ' ');
        numberAxis1.setLabelFont(font6);
        numberAxis1.setLabelToolTip("");
        org.jfree.data.Range range20 = numberAxis1.getRange();
        numberAxis1.setAxisLineVisible(false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range20);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        java.awt.Font font0 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        boolean boolean2 = jFreeChartResources0.containsKey("TextAnchor.BOTTOM_CENTER");
        java.util.Set<java.lang.String> strSet3 = jFreeChartResources0.keySet();
        try {
            java.lang.Object obj5 = jFreeChartResources0.getObject("");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find resource for bundle org.jfree.chart.resources.JFreeChartResources, key ");
        } catch (java.util.MissingResourceException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(strSet3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        java.awt.Font font6 = barRenderer4.getBaseItemLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("{0}", font6, (java.awt.Paint) color11, (float) ' ');
        numberAxis1.setLabelFont(font6);
        numberAxis1.setLowerBound(1.0E-8d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener20 = null;
        numberAxis1.removeChangeListener(axisChangeListener20);
        numberAxis1.setRangeWithMargins(0.0d, (double) 1);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image28 = null;
        categoryPlot27.setBackgroundImage(image28);
        java.awt.Graphics2D graphics2D30 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo31 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo31);
        java.awt.geom.Rectangle2D rectangle2D33 = plotRenderingInfo32.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D34 = plotRenderingInfo32.getDataArea();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo36 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo36);
        java.awt.geom.Rectangle2D rectangle2D38 = plotRenderingInfo37.getPlotArea();
        boolean boolean39 = categoryPlot27.render(graphics2D30, rectangle2D34, 0, plotRenderingInfo37);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image41 = null;
        categoryPlot40.setBackgroundImage(image41);
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo44 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo44);
        java.awt.geom.Rectangle2D rectangle2D46 = plotRenderingInfo45.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D47 = plotRenderingInfo45.getDataArea();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo50 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo49);
        java.awt.geom.Rectangle2D rectangle2D51 = plotRenderingInfo50.getPlotArea();
        boolean boolean52 = categoryPlot40.render(graphics2D43, rectangle2D47, 0, plotRenderingInfo50);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge53);
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge53);
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo58);
        java.awt.geom.Rectangle2D rectangle2D60 = plotRenderingInfo59.getPlotArea();
        java.awt.geom.Point2D point2D61 = null;
        categoryPlot56.zoomDomainAxes(0.05d, plotRenderingInfo59, point2D61);
        try {
            org.jfree.chart.axis.AxisState axisState63 = numberAxis1.draw(graphics2D25, (double) (byte) 1, rectangle2D34, rectangle2D47, rectangleEdge55, plotRenderingInfo59);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(rectangle2D33);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNull(rectangle2D38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNull(rectangle2D46);
        org.junit.Assert.assertNotNull(rectangle2D47);
        org.junit.Assert.assertNull(rectangle2D51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertNull(rectangle2D60);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopInset(0.0d);
        double double3 = rectangleInsets0.getLeft();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.0d + "'", double3 == 4.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.BOTTOM;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        java.awt.Font font5 = barRenderer3.getBaseItemLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}", font5, (java.awt.Paint) color10, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("ThreadContext", font5);
        java.awt.Paint paint17 = labelBlock16.getPaint();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition18 = new org.jfree.chart.axis.CategoryLabelPosition();
        boolean boolean19 = labelBlock16.equals((java.lang.Object) categoryLabelPosition18);
        boolean boolean20 = verticalAlignment0.equals((java.lang.Object) labelBlock16);
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Paint paint6 = barRenderer0.getSeriesOutlinePaint((int) (byte) 100);
        double double7 = barRenderer0.getMinimumBarLength();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Locale locale1 = jFreeChartResources0.getLocale();
        boolean boolean3 = jFreeChartResources0.containsKey("PlotOrientation.VERTICAL");
        org.junit.Assert.assertNull(locale1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.title.Title.DEFAULT_PADDING;
        double double1 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        numberAxis1.setAutoRangeIncludesZero(true);
        double double5 = numberAxis1.getUpperMargin();
        java.text.NumberFormat numberFormat6 = numberAxis1.getNumberFormatOverride();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
        org.junit.Assert.assertNull(numberFormat6);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double5 = numberAxis4.getLabelAngle();
        numberAxis4.setFixedDimension(0.0d);
        org.jfree.data.Range range8 = numberAxis4.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent9 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis4);
        java.util.EventListener eventListener10 = null;
        boolean boolean11 = numberAxis4.hasListener(eventListener10);
        java.awt.Stroke stroke12 = numberAxis4.getTickMarkStroke();
        org.jfree.data.Range range13 = numberAxis4.getRange();
        boolean boolean16 = range13.intersects((double) 2, (double) '#');
        numberAxis1.setRangeWithMargins(range13, false, true);
        boolean boolean20 = numberAxis1.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image23 = null;
        categoryPlot22.setBackgroundImage(image23);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo26);
        java.awt.geom.Rectangle2D rectangle2D28 = plotRenderingInfo27.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D29 = plotRenderingInfo27.getDataArea();
        categoryPlot22.drawBackgroundImage(graphics2D25, rectangle2D29);
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge31);
        double double33 = numberAxis1.valueToJava2D((double) 0.5f, rectangle2D29, rectangleEdge31);
        boolean boolean34 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(range13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(rectangle2D28);
        org.junit.Assert.assertNotNull(rectangle2D29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultStatisticalCategoryDataset0.getGroup();
        java.lang.Object obj6 = datasetGroup5.clone();
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Paint paint5 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint6 = barRenderer0.getBaseFillPaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator8, true);
        barRenderer0.setBaseSeriesVisibleInLegend(false, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double8 = numberAxis7.getLabelAngle();
        numberAxis7.setFixedDimension(0.0d);
        org.jfree.data.Range range11 = numberAxis7.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range5, range11);
        java.lang.String str13 = range5.toString();
        double double15 = range5.constrain((double) (-1.0f));
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean18 = numberAxis17.isTickMarksVisible();
        numberAxis17.setTickMarksVisible(false);
        boolean boolean21 = numberAxis17.isAutoRange();
        java.awt.Paint paint22 = numberAxis17.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double25 = numberAxis24.getLabelAngle();
        numberAxis24.setFixedDimension(0.0d);
        org.jfree.data.Range range28 = numberAxis24.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent29 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis24);
        java.util.EventListener eventListener30 = null;
        boolean boolean31 = numberAxis24.hasListener(eventListener30);
        java.awt.Stroke stroke32 = numberAxis24.getTickMarkStroke();
        org.jfree.data.Range range33 = numberAxis24.getRange();
        boolean boolean36 = range33.intersects((double) 2, (double) '#');
        numberAxis17.setRange(range33, true, false);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double42 = numberAxis41.getLabelAngle();
        numberAxis41.setFixedDimension(0.0d);
        org.jfree.data.Range range45 = numberAxis41.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double48 = numberAxis47.getLabelAngle();
        numberAxis47.setFixedDimension(0.0d);
        org.jfree.data.Range range51 = numberAxis47.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double54 = numberAxis53.getLabelAngle();
        numberAxis53.setFixedDimension(0.0d);
        org.jfree.data.Range range57 = numberAxis53.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = new org.jfree.chart.block.RectangleConstraint(range51, range57);
        java.lang.String str59 = range51.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint60 = new org.jfree.chart.block.RectangleConstraint(range45, range51);
        double double61 = range45.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint62 = new org.jfree.chart.block.RectangleConstraint(range33, range45);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint63 = new org.jfree.chart.block.RectangleConstraint(range5, range45);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType64 = rectangleConstraint63.getWidthConstraintType();
        java.lang.String str65 = lengthConstraintType64.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Range[0.0,1.0]" + "'", str13.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Range[0.0,1.0]" + "'", str59.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.0d + "'", double61 == 1.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType64);
        org.junit.Assert.assertTrue("'" + str65 + "' != '" + "RectangleConstraintType.RANGE" + "'", str65.equals("RectangleConstraintType.RANGE"));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint3 = barRenderer1.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        barRenderer1.setSeriesURLGenerator(10, categoryURLGenerator5, true);
        boolean boolean8 = barRenderer1.getAutoPopulateSeriesStroke();
        java.awt.Paint paint10 = barRenderer1.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke12 = barRenderer11.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent13 = null;
        barRenderer11.notifyListeners(rendererChangeEvent13);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer11.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape16 = barRenderer11.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity17 = new org.jfree.chart.entity.LegendItemEntity(shape16);
        barRenderer1.setBaseShape(shape16, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity22 = new org.jfree.chart.entity.TickLabelEntity(shape16, "java.awt.Color[r=128,g=128,b=0]", "");
        try {
            org.jfree.chart.util.ShapeUtilities.drawRotatedShape(graphics2D0, shape16, (double) 100.0f, (float) (byte) 10, (float) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Paint paint6 = barRenderer0.getSeriesOutlinePaint((int) (byte) 100);
        int int7 = barRenderer0.getRowCount();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        int int28 = legendItem27.getSeriesIndex();
        org.jfree.data.general.Dataset dataset29 = legendItem27.getDataset();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNull(dataset29);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("RectangleConstraintType.RANGE");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name RectangleConstraintType.RANGE, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("ThreadContext", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = barRenderer0.getItemLabelGenerator((int) (byte) 0, (int) '4');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Color color7 = java.awt.Color.CYAN;
        barRenderer0.setBaseOutlinePaint((java.awt.Paint) color7, false);
        try {
            barRenderer0.setSeriesVisibleInLegend((int) (byte) -1, (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        java.awt.Paint paint0 = org.jfree.chart.title.TextTitle.DEFAULT_TEXT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("hi!");
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        keyedObjects2D0.setObject((java.lang.Object) 0.2d, (java.lang.Comparable) numberTickUnit2, (java.lang.Comparable) 10);
        keyedObjects2D0.addObject((java.lang.Object) 2.0d, (java.lang.Comparable) 1, (java.lang.Comparable) 100);
        org.jfree.chart.axis.AxisState axisState10 = new org.jfree.chart.axis.AxisState(10.0d);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = null;
        axisState10.moveCursor(1.0d, rectangleEdge12);
        double double14 = axisState10.getMax();
        keyedObjects2D0.addObject((java.lang.Object) axisState10, (java.lang.Comparable) 'a', (java.lang.Comparable) (-1));
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset18 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number19 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18);
        org.jfree.data.Range range21 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18, true);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener22 = null;
        defaultStatisticalCategoryDataset18.addChangeListener(datasetChangeListener22);
        java.lang.Number number26 = defaultStatisticalCategoryDataset18.getMeanValue((java.lang.Comparable) 15, (java.lang.Comparable) 1.0f);
        java.util.List list27 = defaultStatisticalCategoryDataset18.getRowKeys();
        axisState10.setTicks(list27);
        org.junit.Assert.assertNotNull(numberTickUnit2);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertEquals((double) number19, Double.NaN, 0);
        org.junit.Assert.assertNull(range21);
        org.junit.Assert.assertNull(number26);
        org.junit.Assert.assertNotNull(list27);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        barRenderer3.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock1, textBlockAnchor2, textAnchor8, 0.0d);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock1.calculateDimensions(graphics2D11);
        size2D12.width = 15.0f;
        java.lang.String str15 = size2D12.toString();
        double double16 = size2D12.getWidth();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "Size2D[width=15.0, height=0.0]" + "'", str15.equals("Size2D[width=15.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 15.0d + "'", double16 == 15.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) (-1L));
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = null;
        barRenderer7.setSeriesFillPaint((int) '#', paint9, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        barRenderer7.setSeriesURLGenerator(0, categoryURLGenerator13, true);
        int int16 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint20 = barRenderer18.lookupSeriesFillPaint((int) (byte) -1);
        barRenderer7.setSeriesFillPaint((int) '#', paint20);
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0, jFreeChart8, chartChangeEventType9);
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 10, (java.lang.Boolean) true, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer0.getPositiveItemLabelPosition((int) (short) 100, 10);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double20 = numberAxis19.getLabelAngle();
        numberAxis19.setFixedDimension(0.0d);
        org.jfree.data.Range range23 = numberAxis19.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double26 = numberAxis25.getLabelAngle();
        numberAxis25.setFixedDimension(0.0d);
        org.jfree.data.Range range29 = numberAxis25.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint30 = new org.jfree.chart.block.RectangleConstraint(range23, range29);
        java.lang.String str31 = range23.toString();
        double double33 = range23.constrain((double) (-1.0f));
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean36 = numberAxis35.isTickMarksVisible();
        numberAxis35.setTickMarksVisible(false);
        boolean boolean39 = numberAxis35.isAutoRange();
        java.awt.Paint paint40 = numberAxis35.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis42 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double43 = numberAxis42.getLabelAngle();
        numberAxis42.setFixedDimension(0.0d);
        org.jfree.data.Range range46 = numberAxis42.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent47 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis42);
        java.util.EventListener eventListener48 = null;
        boolean boolean49 = numberAxis42.hasListener(eventListener48);
        java.awt.Stroke stroke50 = numberAxis42.getTickMarkStroke();
        org.jfree.data.Range range51 = numberAxis42.getRange();
        boolean boolean54 = range51.intersects((double) 2, (double) '#');
        numberAxis35.setRange(range51, true, false);
        org.jfree.chart.axis.NumberAxis numberAxis59 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double60 = numberAxis59.getLabelAngle();
        numberAxis59.setFixedDimension(0.0d);
        org.jfree.data.Range range63 = numberAxis59.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis65 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double66 = numberAxis65.getLabelAngle();
        numberAxis65.setFixedDimension(0.0d);
        org.jfree.data.Range range69 = numberAxis65.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis71 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double72 = numberAxis71.getLabelAngle();
        numberAxis71.setFixedDimension(0.0d);
        org.jfree.data.Range range75 = numberAxis71.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint76 = new org.jfree.chart.block.RectangleConstraint(range69, range75);
        java.lang.String str77 = range69.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint78 = new org.jfree.chart.block.RectangleConstraint(range63, range69);
        double double79 = range63.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint80 = new org.jfree.chart.block.RectangleConstraint(range51, range63);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint81 = new org.jfree.chart.block.RectangleConstraint(range23, range63);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType82 = rectangleConstraint81.getWidthConstraintType();
        boolean boolean83 = itemLabelPosition17.equals((java.lang.Object) lengthConstraintType82);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(range23);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "Range[0.0,1.0]" + "'", str31.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertNotNull(paint40);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(range46);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(range63);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(range69);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(range75);
        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "Range[0.0,1.0]" + "'", str77.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.0d + "'", double79 == 1.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double5 = numberAxis4.getLabelAngle();
        numberAxis4.setFixedDimension(0.0d);
        org.jfree.data.Range range8 = numberAxis4.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double11 = numberAxis10.getLabelAngle();
        numberAxis10.setFixedDimension(0.0d);
        org.jfree.data.Range range14 = numberAxis10.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(range8, range14);
        numberAxis1.setRangeWithMargins(range8);
        numberAxis1.setAutoTickUnitSelection(true, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke2 = barRenderer1.getBaseStroke();
        java.awt.Font font3 = barRenderer1.getBaseItemLabelFont();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean10 = color8.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color8);
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("{0}", font3, (java.awt.Paint) color8, (float) ' ');
        java.awt.Paint paint14 = textFragment13.getPaint();
        java.lang.String str15 = textFragment13.getText();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{0}" + "'", str15.equals("{0}"));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        java.awt.Font font6 = barRenderer4.getBaseItemLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("{0}", font6, (java.awt.Paint) color11, (float) ' ');
        numberAxis1.setLabelFont(font6);
        numberAxis1.setLabelToolTip("");
        org.jfree.data.Range range20 = numberAxis1.getRange();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image22 = null;
        categoryPlot21.setBackgroundImage(image22);
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo25 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo25);
        java.awt.geom.Rectangle2D rectangle2D27 = plotRenderingInfo26.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D28 = plotRenderingInfo26.getDataArea();
        categoryPlot21.drawBackgroundImage(graphics2D24, rectangle2D28);
        boolean boolean30 = range20.equals((java.lang.Object) graphics2D24);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNull(rectangle2D27);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation((int) (short) -1);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot0.zoomRangeAxes(1.0E-8d, (double) 10, plotRenderingInfo12, point2D13);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        java.awt.Paint paint28 = legendItem27.getLinePaint();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer29 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem27.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer29);
        java.awt.Shape shape31 = legendItem27.getLine();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(shape31);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("LegendItemEntity: seriesKey=null, dataset=null", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        numberAxis1.setTickMarksVisible(false);
        boolean boolean5 = numberAxis1.isAutoRange();
        java.awt.Paint paint6 = numberAxis1.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double9 = numberAxis8.getLabelAngle();
        numberAxis8.setFixedDimension(0.0d);
        org.jfree.data.Range range12 = numberAxis8.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent13 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis8);
        java.util.EventListener eventListener14 = null;
        boolean boolean15 = numberAxis8.hasListener(eventListener14);
        java.awt.Stroke stroke16 = numberAxis8.getTickMarkStroke();
        org.jfree.data.Range range17 = numberAxis8.getRange();
        boolean boolean20 = range17.intersects((double) 2, (double) '#');
        numberAxis1.setRange(range17, true, false);
        org.jfree.chart.axis.NumberAxis numberAxis25 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double26 = numberAxis25.getLabelAngle();
        numberAxis25.setFixedDimension(0.0d);
        org.jfree.data.Range range29 = numberAxis25.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double32 = numberAxis31.getLabelAngle();
        numberAxis31.setFixedDimension(0.0d);
        org.jfree.data.Range range35 = numberAxis31.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis37 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double38 = numberAxis37.getLabelAngle();
        numberAxis37.setFixedDimension(0.0d);
        org.jfree.data.Range range41 = numberAxis37.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint42 = new org.jfree.chart.block.RectangleConstraint(range35, range41);
        java.lang.String str43 = range35.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint44 = new org.jfree.chart.block.RectangleConstraint(range29, range35);
        double double45 = range29.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint46 = new org.jfree.chart.block.RectangleConstraint(range17, range29);
        double double47 = rectangleConstraint46.getHeight();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(range12);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(range41);
        org.junit.Assert.assertTrue("'" + str43 + "' != '" + "Range[0.0,1.0]" + "'", str43.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.0d + "'", double45 == 1.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke6 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke6, true);
        java.awt.Stroke stroke11 = barRenderer0.getItemOutlineStroke((int) (byte) -1, 0);
        boolean boolean12 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        java.awt.Paint paint28 = legendItem27.getLinePaint();
        java.lang.Comparable comparable29 = legendItem27.getSeriesKey();
        java.awt.Paint paint30 = legendItem27.getOutlinePaint();
        java.lang.String str31 = legendItem27.getToolTipText();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNull(comparable29);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str31.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        java.awt.Shape shape7 = numberAxis1.getRightArrow();
        boolean boolean8 = numberAxis1.isVerticalTickLabels();
        numberAxis1.setInverted(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = barRenderer0.getPositiveItemLabelPosition((int) '4', 3);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition6);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) (-15361.0d), (java.lang.Number) 1.0E-8d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("{0}");
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        java.awt.Font font5 = barRenderer3.getBaseItemLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}", font5, (java.awt.Paint) color10, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("ThreadContext", font5);
        java.awt.Font font17 = labelBlock16.getFont();
        java.awt.Paint paint18 = null;
        try {
            org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("", font17, paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        java.awt.Stroke stroke20 = barRenderer0.getSeriesStroke((int) (short) -1);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent21 = null;
        barRenderer0.notifyListeners(rendererChangeEvent21);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(stroke20);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        java.util.EventListener eventListener7 = null;
        boolean boolean8 = numberAxis1.hasListener(eventListener7);
        numberAxis1.setRangeWithMargins(1.0d, Double.NaN);
        numberAxis1.setAutoRangeIncludesZero(false);
        try {
            numberAxis1.setAutoRangeMinimumSize(0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color30);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double45 = numberAxis44.getLabelAngle();
        numberAxis44.setFixedDimension(0.0d);
        org.jfree.data.Range range48 = numberAxis44.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent49 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis44);
        java.awt.Shape shape50 = numberAxis44.getRightArrow();
        legendGraphic42.setLine(shape50);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor52 = legendGraphic42.getShapeAnchor();
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer55 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke56 = barRenderer55.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent57 = null;
        barRenderer55.notifyListeners(rendererChangeEvent57);
        boolean boolean59 = barRenderer55.getAutoPopulateSeriesOutlinePaint();
        org.jfree.data.KeyedObject keyedObject60 = new org.jfree.data.KeyedObject((java.lang.Comparable) 98.0d, (java.lang.Object) barRenderer55);
        org.jfree.chart.axis.NumberAxis numberAxis62 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double63 = numberAxis62.getLabelAngle();
        numberAxis62.setFixedDimension(0.0d);
        org.jfree.data.Range range66 = numberAxis62.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis68 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double69 = numberAxis68.getLabelAngle();
        numberAxis68.setFixedDimension(0.0d);
        org.jfree.data.Range range72 = numberAxis68.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint73 = new org.jfree.chart.block.RectangleConstraint(range66, range72);
        boolean boolean74 = keyedObject60.equals((java.lang.Object) rectangleConstraint73);
        try {
            org.jfree.chart.util.Size2D size2D75 = legendGraphic42.arrange(graphics2D53, rectangleConstraint73);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(rectangleAnchor52);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(range66);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(range72);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.util.VerticalAlignment.CENTER;
        java.lang.String str1 = verticalAlignment0.toString();
        java.lang.String str2 = verticalAlignment0.toString();
        org.junit.Assert.assertNotNull(verticalAlignment0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "VerticalAlignment.CENTER" + "'", str1.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "VerticalAlignment.CENTER" + "'", str2.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        org.jfree.chart.renderer.category.BarRenderer barRenderer7 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint9 = null;
        barRenderer7.setSeriesFillPaint((int) '#', paint9, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        barRenderer7.setSeriesURLGenerator(0, categoryURLGenerator13, true);
        int int16 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer7);
        boolean boolean17 = barRenderer7.getAutoPopulateSeriesStroke();
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1) + "'", int16 == (-1));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        barRenderer3.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock1, textBlockAnchor2, textAnchor8, 0.0d);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock1.calculateDimensions(graphics2D11);
        size2D12.width = 2;
        size2D12.setHeight((double) 10L);
        size2D12.setWidth((double) 1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(size2D12);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        categoryPlot2.setOutlinePaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = categoryPlot2.getOutlinePaint();
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape1, paint6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double11 = numberAxis10.getLabelAngle();
        numberAxis10.setFixedDimension(0.0d);
        org.jfree.data.Range range14 = numberAxis10.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double17 = numberAxis16.getLabelAngle();
        numberAxis16.setFixedDimension(0.0d);
        org.jfree.data.Range range20 = numberAxis16.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint21 = new org.jfree.chart.block.RectangleConstraint(range14, range20);
        double double22 = rectangleConstraint21.getHeight();
        java.lang.String str23 = rectangleConstraint21.toString();
        double double24 = rectangleConstraint21.getHeight();
        try {
            org.jfree.chart.util.Size2D size2D25 = legendGraphic7.arrange(graphics2D8, rectangleConstraint21);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str23.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke6 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke6, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        java.awt.Color color14 = java.awt.Color.CYAN;
        java.awt.image.ColorModel colorModel15 = null;
        java.awt.Rectangle rectangle16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        java.awt.geom.AffineTransform affineTransform18 = null;
        java.awt.RenderingHints renderingHints19 = null;
        java.awt.PaintContext paintContext20 = color14.createContext(colorModel15, rectangle16, rectangle2D17, affineTransform18, renderingHints19);
        barRenderer0.setSeriesOutlinePaint((int) (byte) 1, (java.awt.Paint) color14);
        int int22 = color14.getTransparency();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(paintContext20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 1 + "'", int22 == 1);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        boolean boolean11 = barRenderer0.isSeriesVisibleInLegend((int) (short) 1);
        barRenderer0.setBaseCreateEntities(true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier14 = barRenderer0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNull(drawingSupplier14);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        boolean boolean7 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double10 = numberAxis9.getLabelAngle();
        numberAxis9.setFixedDimension(0.0d);
        org.jfree.data.Range range13 = numberAxis9.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis9);
        categoryPlot0.axisChanged(axisChangeEvent14);
        categoryPlot0.clearDomainMarkers((int) (short) 10);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        java.awt.Paint paint28 = legendItem27.getLinePaint();
        java.awt.Shape shape29 = legendItem27.getShape();
        java.lang.String str30 = legendItem27.getLabel();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "java.awt.Color[r=128,g=128,b=0]" + "'", str30.equals("java.awt.Color[r=128,g=128,b=0]"));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke2 = barRenderer1.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        barRenderer1.notifyListeners(rendererChangeEvent3);
        boolean boolean5 = barRenderer1.getAutoPopulateSeriesOutlinePaint();
        org.jfree.data.KeyedObject keyedObject6 = new org.jfree.data.KeyedObject((java.lang.Comparable) 98.0d, (java.lang.Object) barRenderer1);
        java.lang.Comparable comparable7 = keyedObject6.getKey();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + 98.0d + "'", comparable7.equals(98.0d));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke2 = barRenderer1.getBaseStroke();
        java.awt.Font font3 = barRenderer1.getBaseItemLabelFont();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean10 = color8.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color8);
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("{0}", font3, (java.awt.Paint) color8, (float) ' ');
        java.awt.Graphics2D graphics2D14 = null;
        try {
            org.jfree.chart.util.Size2D size2D15 = textFragment13.calculateDimensions(graphics2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        borderArrangement0.clear();
        org.jfree.chart.block.BlockContainer blockContainer2 = null;
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double6 = numberAxis5.getLabelAngle();
        numberAxis5.setFixedDimension(0.0d);
        org.jfree.data.Range range9 = numberAxis5.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double12 = numberAxis11.getLabelAngle();
        numberAxis11.setFixedDimension(0.0d);
        org.jfree.data.Range range15 = numberAxis11.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint16 = new org.jfree.chart.block.RectangleConstraint(range9, range15);
        java.lang.String str17 = range9.toString();
        double double19 = range9.constrain((double) (-1.0f));
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean22 = numberAxis21.isTickMarksVisible();
        numberAxis21.setTickMarksVisible(false);
        boolean boolean25 = numberAxis21.isAutoRange();
        java.awt.Paint paint26 = numberAxis21.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis28 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double29 = numberAxis28.getLabelAngle();
        numberAxis28.setFixedDimension(0.0d);
        org.jfree.data.Range range32 = numberAxis28.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent33 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis28);
        java.util.EventListener eventListener34 = null;
        boolean boolean35 = numberAxis28.hasListener(eventListener34);
        java.awt.Stroke stroke36 = numberAxis28.getTickMarkStroke();
        org.jfree.data.Range range37 = numberAxis28.getRange();
        boolean boolean40 = range37.intersects((double) 2, (double) '#');
        numberAxis21.setRange(range37, true, false);
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double46 = numberAxis45.getLabelAngle();
        numberAxis45.setFixedDimension(0.0d);
        org.jfree.data.Range range49 = numberAxis45.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double52 = numberAxis51.getLabelAngle();
        numberAxis51.setFixedDimension(0.0d);
        org.jfree.data.Range range55 = numberAxis51.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis57 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double58 = numberAxis57.getLabelAngle();
        numberAxis57.setFixedDimension(0.0d);
        org.jfree.data.Range range61 = numberAxis57.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint62 = new org.jfree.chart.block.RectangleConstraint(range55, range61);
        java.lang.String str63 = range55.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint64 = new org.jfree.chart.block.RectangleConstraint(range49, range55);
        double double65 = range49.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint66 = new org.jfree.chart.block.RectangleConstraint(range37, range49);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint67 = new org.jfree.chart.block.RectangleConstraint(range9, range49);
        org.jfree.chart.block.LengthConstraintType lengthConstraintType68 = rectangleConstraint67.getWidthConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D69 = borderArrangement0.arrange(blockContainer2, graphics2D3, rectangleConstraint67);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(range9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Range[0.0,1.0]" + "'", str17.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(range32);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(range49);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(range55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(range61);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "Range[0.0,1.0]" + "'", str63.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.0d + "'", double65 == 1.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType68);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint7 = barRenderer3.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke9 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke9, true);
        java.awt.Stroke stroke14 = barRenderer3.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer0.setBaseStroke(stroke14);
        boolean boolean16 = barRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Font font18 = org.jfree.chart.text.TextFragment.DEFAULT_FONT;
        barRenderer0.setSeriesItemLabelFont((int) (short) 10, font18, true);
        java.awt.Paint paint21 = barRenderer0.getBasePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(paint21);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.resources.JFreeChartResources jFreeChartResources0 = new org.jfree.chart.resources.JFreeChartResources();
        java.util.Set<java.lang.String> strSet1 = jFreeChartResources0.keySet();
        org.junit.Assert.assertNotNull(strSet1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        java.lang.Comparable comparable2 = null;
        try {
            java.awt.Paint paint3 = categoryAxis1.getTickLabelPaint(comparable2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'category' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 0.95f, (double) (byte) 0, 0.2d, (double) 0);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo7.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D9 = plotRenderingInfo7.getDataArea();
        try {
            blockBorder4.draw(graphics2D5, rectangle2D9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(rectangle2D8);
        org.junit.Assert.assertNotNull(rectangle2D9);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Paint paint5 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint6 = barRenderer0.getBaseFillPaint();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        try {
            barRenderer0.setLegendItemLabelGenerator(categorySeriesLabelGenerator7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'generator' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        java.lang.Number number4 = defaultStatisticalCategoryDataset0.getValue((java.lang.Comparable) 0, (java.lang.Comparable) (-1L));
        int int6 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) (short) 100);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(number4);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.awt.Color color0 = java.awt.Color.DARK_GRAY;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.axis.AxisState axisState0 = new org.jfree.chart.axis.AxisState();
        axisState0.setMax(0.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = barRenderer0.getItemLabelGenerator((int) (byte) 0, (int) '4');
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        try {
            barRenderer0.setSeriesToolTipGenerator((-1), categoryToolTipGenerator7, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint7 = barRenderer3.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke9 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke9, true);
        java.awt.Stroke stroke14 = barRenderer3.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer0.setBaseStroke(stroke14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke18 = barRenderer17.getBaseStroke();
        barRenderer0.setSeriesOutlineStroke((int) (short) 10, stroke18);
        double double20 = barRenderer0.getItemLabelAnchorOffset();
        double double21 = barRenderer0.getItemLabelAnchorOffset();
        java.awt.Stroke stroke23 = barRenderer0.getSeriesStroke(100);
        int int24 = barRenderer0.getRowCount();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertNull(stroke23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        boolean boolean7 = categoryPlot0.isOutlineVisible();
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double10 = numberAxis9.getLabelAngle();
        numberAxis9.setFixedDimension(0.0d);
        org.jfree.data.Range range13 = numberAxis9.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent14 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis9);
        categoryPlot0.axisChanged(axisChangeEvent14);
        org.jfree.chart.JFreeChart jFreeChart16 = null;
        axisChangeEvent14.setChart(jFreeChart16);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(range13);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = org.jfree.chart.axis.CategoryAnchor.END;
        categoryPlot0.setDomainGridlinePosition(categoryAnchor7);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor7);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        boolean boolean5 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.util.List list7 = categoryPlot0.getCategoriesForAxis(categoryAxis6);
        org.jfree.chart.axis.ValueAxis[] valueAxisArray8 = new org.jfree.chart.axis.ValueAxis[] {};
        categoryPlot0.setRangeAxes(valueAxisArray8);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(list7);
        org.junit.Assert.assertNotNull(valueAxisArray8);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) "{0}");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.jfree.chart.text.TextBlock textBlock6 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 2, textBlock6, textBlockAnchor7, textAnchor8, 0.0d);
        org.jfree.chart.text.TextAnchor textAnchor11 = null;
        try {
            org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor8, textAnchor11, (-15361.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rotationAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        categoryPlot0.setAnchorValue((double) 8, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = categoryPlot0.getDomainAxisForDataset(1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNull(categoryAxis11);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        categoryPlot2.setOutlinePaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = categoryPlot2.getOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment8 = new org.jfree.chart.text.TextFragment("", font1, paint6, (float) 15);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextBlock textBlock11 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor12 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer13 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke14 = barRenderer13.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        barRenderer13.notifyListeners(rendererChangeEvent15);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer13.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor18 = itemLabelPosition17.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick20 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock11, textBlockAnchor12, textAnchor18, 0.0d);
        try {
            float float21 = textFragment8.calculateBaselineOffset(graphics2D9, textAnchor18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(textBlockAnchor12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(textAnchor18);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.block.LengthConstraintType lengthConstraintType0 = org.jfree.chart.block.LengthConstraintType.NONE;
        org.junit.Assert.assertNotNull(lengthConstraintType0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color30);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double45 = numberAxis44.getLabelAngle();
        numberAxis44.setFixedDimension(0.0d);
        org.jfree.data.Range range48 = numberAxis44.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent49 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis44);
        java.awt.Shape shape50 = numberAxis44.getRightArrow();
        legendGraphic42.setLine(shape50);
        legendGraphic42.setShapeFilled(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(shape50);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        java.awt.Font font6 = barRenderer4.getBaseItemLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("{0}", font6, (java.awt.Paint) color11, (float) ' ');
        numberAxis1.setLabelFont(font6);
        numberAxis1.setLowerBound(1.0E-8d);
        double double20 = numberAxis1.getFixedAutoRange();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((java.lang.Number) 10.0f, (java.lang.Number) (short) 0);
        org.jfree.chart.LegendItemCollection legendItemCollection3 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItem legendItem4 = null;
        legendItemCollection3.add(legendItem4);
        boolean boolean6 = meanAndStandardDeviation2.equals((java.lang.Object) legendItem4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        java.awt.Paint paint0 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer2.getBaseStroke();
        java.awt.Font font4 = barRenderer2.getBaseItemLabelFont();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("{0}", font4, (java.awt.Paint) color9, (float) ' ');
        java.awt.Font font15 = textFragment14.getFont();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font15);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = textTitle16.getHorizontalAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment18 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textTitle16.setHorizontalAlignment(horizontalAlignment18);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(horizontalAlignment17);
        org.junit.Assert.assertNotNull(horizontalAlignment18);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint7 = barRenderer3.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke9 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke9, true);
        java.awt.Stroke stroke14 = barRenderer3.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer0.setBaseStroke(stroke14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke18 = barRenderer17.getBaseStroke();
        barRenderer0.setSeriesOutlineStroke((int) (short) 10, stroke18);
        double double20 = barRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.renderer.category.BarRenderer barRenderer22 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke23 = barRenderer22.getBaseStroke();
        java.awt.Font font24 = barRenderer22.getBaseItemLabelFont();
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean31 = color29.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder32 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color29);
        org.jfree.chart.text.TextFragment textFragment34 = new org.jfree.chart.text.TextFragment("{0}", font24, (java.awt.Paint) color29, (float) ' ');
        barRenderer0.setBaseFillPaint((java.awt.Paint) color29, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) (byte) 1);
        boolean boolean4 = rectangleInsets0.equals((java.lang.Object) 10L);
        double double6 = rectangleInsets0.calculateRightInset(0.05d);
        double double8 = rectangleInsets0.calculateTopInset((double) 1L);
        double double9 = rectangleInsets0.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.0d + "'", double8 == 2.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        java.util.EventListener eventListener7 = null;
        boolean boolean8 = numberAxis1.hasListener(eventListener7);
        numberAxis1.setAutoRangeStickyZero(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("EXPAND", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        barRenderer0.setBaseSeriesVisible(false, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getSeriesItemLabelGenerator((int) (short) 1);
        java.awt.Stroke stroke6 = barRenderer0.lookupSeriesOutlineStroke(1);
        java.awt.Paint paint7 = barRenderer0.getBaseItemLabelPaint();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesPaint((int) (short) 1);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(paint9);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.awt.Font font0 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((-1.0f));
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = categoryPlot0.getDomainGridlinePosition();
        int int8 = categoryPlot0.getRangeAxisCount();
        categoryPlot0.clearDomainMarkers((int) '4');
        boolean boolean11 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        org.jfree.data.general.DatasetGroup datasetGroup3 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertNull(datasetGroup3);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0, jFreeChart8, chartChangeEventType9);
        barRenderer0.setSeriesVisibleInLegend((int) (byte) 10, (java.lang.Boolean) true, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint18 = barRenderer16.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator20 = null;
        barRenderer16.setSeriesURLGenerator(10, categoryURLGenerator20, true);
        boolean boolean23 = barRenderer16.getAutoPopulateSeriesStroke();
        java.awt.Stroke stroke24 = barRenderer16.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition25 = barRenderer16.getBaseNegativeItemLabelPosition();
        barRenderer0.setSeriesNegativeItemLabelPosition((int) '#', itemLabelPosition25);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(itemLabelPosition25);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        categoryPlot0.drawBackgroundImage(graphics2D3, rectangle2D7);
        org.jfree.chart.renderer.category.BarRenderer barRenderer9 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint11 = barRenderer9.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        barRenderer9.setSeriesURLGenerator(10, categoryURLGenerator13, true);
        boolean boolean16 = barRenderer9.getAutoPopulateSeriesStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition17 = barRenderer9.getPositiveItemLabelPositionFallback();
        java.awt.Shape shape19 = barRenderer9.lookupSeriesShape(10);
        categoryPlot0.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer9);
        double double21 = barRenderer9.getItemMargin();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = barRenderer9.getURLGenerator((int) (short) -1, 10);
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(itemLabelPosition17);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.2d + "'", double21 == 0.2d);
        org.junit.Assert.assertNull(categoryURLGenerator24);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) "{0}");
        java.lang.String str4 = textAnchor1.toString();
        boolean boolean5 = keyedObjects0.equals((java.lang.Object) str4);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) (-1.0d));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str4.equals("TextAnchor.BOTTOM_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        org.jfree.chart.LegendItemCollection legendItemCollection5 = barRenderer0.getLegendItems();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(legendItemCollection5);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis1.refreshTicks(graphics2D11, axisState13, rectangle2D14, rectangleEdge15);
        org.jfree.chart.util.UnitType unitType17 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean18 = numberAxis1.equals((java.lang.Object) unitType17);
        java.lang.String str19 = unitType17.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "UnitType.ABSOLUTE" + "'", str19.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        java.awt.Paint paint28 = legendItem27.getLinePaint();
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer29 = new org.jfree.chart.util.StandardGradientPaintTransformer();
        legendItem27.setFillPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer29);
        java.lang.Object obj31 = standardGradientPaintTransformer29.clone();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(obj31);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis1.refreshTicks(graphics2D11, axisState13, rectangle2D14, rectangleEdge15);
        org.jfree.chart.util.UnitType unitType17 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean18 = numberAxis1.equals((java.lang.Object) unitType17);
        java.lang.Object obj19 = numberAxis1.clone();
        org.jfree.chart.axis.TickUnits tickUnits20 = new org.jfree.chart.axis.TickUnits();
        numberAxis1.setStandardTickUnits((org.jfree.chart.axis.TickUnitSource) tickUnits20);
        org.jfree.data.KeyedObjects2D keyedObjects2D22 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit24 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        keyedObjects2D22.setObject((java.lang.Object) 0.2d, (java.lang.Comparable) numberTickUnit24, (java.lang.Comparable) 10);
        try {
            org.jfree.chart.axis.TickUnit tickUnit27 = tickUnits20.getCeilingTickUnit((org.jfree.chart.axis.TickUnit) numberTickUnit24);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNotNull(numberTickUnit24);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.UP_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener4 = null;
        defaultStatisticalCategoryDataset0.addChangeListener(datasetChangeListener4);
        java.lang.Number number8 = defaultStatisticalCategoryDataset0.getMeanValue((java.lang.Comparable) 15, (java.lang.Comparable) 1.0f);
        int int9 = defaultStatisticalCategoryDataset0.getColumnCount();
        try {
            java.lang.Number number12 = defaultStatisticalCategoryDataset0.getStdDevValue((int) '#', (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNull(number8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        java.awt.Shape shape18 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        java.awt.Color color20 = java.awt.Color.LIGHT_GRAY;
        java.awt.Color color22 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double25 = numberAxis24.getLabelAngle();
        numberAxis24.setFixedDimension(0.0d);
        org.jfree.data.Range range28 = numberAxis24.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent29 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis24);
        java.util.EventListener eventListener30 = null;
        boolean boolean31 = numberAxis24.hasListener(eventListener30);
        java.awt.Stroke stroke32 = numberAxis24.getTickMarkStroke();
        java.awt.Shape shape36 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 8, (float) (byte) 10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer37 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint39 = barRenderer37.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint41 = barRenderer37.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke43 = null;
        barRenderer37.setSeriesOutlineStroke(0, stroke43, true);
        java.awt.Stroke stroke48 = barRenderer37.getItemOutlineStroke((int) (byte) -1, 0);
        java.awt.Color color49 = java.awt.Color.CYAN;
        int int50 = color49.getRed();
        org.jfree.chart.LegendItem legendItem51 = new org.jfree.chart.LegendItem("{0}", "", "EXPAND", "hi!", false, shape18, true, (java.awt.Paint) color20, true, (java.awt.Paint) color22, stroke32, false, shape36, stroke48, (java.awt.Paint) color49);
        try {
            barRenderer0.setSeriesStroke((-15423), stroke48, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(shape36);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setTickMarkInsideLength((float) 15);
        float float13 = numberAxis1.getTickMarkInsideLength();
        double double14 = numberAxis1.getLabelAngle();
        numberAxis1.setAutoRangeIncludesZero(false);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 15.0f + "'", float13 == 15.0f);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        barRenderer3.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock1, textBlockAnchor2, textAnchor8, 0.0d);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock1.calculateDimensions(graphics2D11);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        java.lang.String str17 = textBlockAnchor16.toString();
        textBlock1.draw(graphics2D13, 0.95f, 2.0f, textBlockAnchor16);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor22 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        textBlock1.draw(graphics2D19, 0.5f, (float) (short) -1, textBlockAnchor22);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "TextBlockAnchor.TOP_LEFT" + "'", str17.equals("TextBlockAnchor.TOP_LEFT"));
        org.junit.Assert.assertNotNull(textBlockAnchor22);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke6 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke6, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        boolean boolean13 = barRenderer0.getIncludeBaseInRange();
        barRenderer0.setBaseSeriesVisibleInLegend(true);
        java.awt.Paint paint16 = barRenderer0.getBaseOutlinePaint();
        java.awt.Paint paint18 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_PAINT;
        barRenderer0.setSeriesItemLabelPaint((int) (byte) 1, paint18, true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.lang.Object obj2 = valueMarker1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        categoryPlot0.configureDomainAxes();
        java.awt.Paint paint8 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        categoryPlot0.setDomainAxisLocation((int) (byte) 0, axisLocation10, false);
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        categoryPlot0.setInsets(rectangleInsets2, true);
        org.junit.Assert.assertNotNull(rectangleInsets2);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        org.jfree.chart.axis.NumberAxis numberAxis29 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double30 = numberAxis29.getLabelAngle();
        numberAxis29.setFixedDimension(0.0d);
        org.jfree.data.Range range33 = numberAxis29.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent34 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis29);
        java.util.EventListener eventListener35 = null;
        boolean boolean36 = numberAxis29.hasListener(eventListener35);
        java.awt.Stroke stroke37 = numberAxis29.getTickMarkStroke();
        org.jfree.data.Range range38 = numberAxis29.getRange();
        numberAxis29.zoomRange(0.0d, (double) 3);
        boolean boolean42 = legendItem27.equals((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNotNull(range38);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createDiamond((float) (byte) 0);
        numberAxis1.setUpArrow(shape6);
        java.lang.String str8 = numberAxis1.getLabelURL();
        java.awt.Font font10 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace13 = color12.getColorSpace();
        categoryPlot11.setOutlinePaint((java.awt.Paint) color12);
        java.awt.Paint paint15 = categoryPlot11.getOutlinePaint();
        org.jfree.chart.text.TextFragment textFragment17 = new org.jfree.chart.text.TextFragment("", font10, paint15, (float) 15);
        numberAxis1.setTickLabelFont(font10);
        numberAxis1.setNegativeArrowVisible(true);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(paint15);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = org.jfree.chart.util.LengthAdjustmentType.EXPAND;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(lengthAdjustmentType2);
        org.junit.Assert.assertNotNull(lengthAdjustmentType3);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setRight((double) '#');
        axisSpace0.setLeft((double) 10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = axisSpace0.reserved(rectangle2D5, rectangleEdge6);
        axisSpace0.setRight((double) (short) -1);
        double double10 = axisSpace0.getTop();
        org.junit.Assert.assertNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint7 = barRenderer3.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke9 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke9, true);
        java.awt.Stroke stroke14 = barRenderer3.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer0.setBaseStroke(stroke14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke18 = barRenderer17.getBaseStroke();
        barRenderer0.setSeriesOutlineStroke((int) (short) 10, stroke18);
        double double20 = barRenderer0.getItemLabelAnchorOffset();
        boolean boolean21 = barRenderer0.getAutoPopulateSeriesShape();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.0d + "'", double20 == 2.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (int) '#');
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createConsolidatedPieDataset(pieDataset5, (java.lang.Comparable) 2.0d, (double) 100);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) pieDataset5);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertNotNull(pieDataset8);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("HorizontalAlignment.CENTER");
        org.jfree.chart.axis.NumberAxis numberAxis3 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean4 = numberAxis3.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke7 = barRenderer6.getBaseStroke();
        java.awt.Font font8 = barRenderer6.getBaseItemLabelFont();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean15 = color13.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder16 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color13);
        org.jfree.chart.text.TextFragment textFragment18 = new org.jfree.chart.text.TextFragment("{0}", font8, (java.awt.Paint) color13, (float) ' ');
        numberAxis3.setLabelFont(font8);
        numberAxis3.setLowerBound(1.0E-8d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener22 = null;
        numberAxis3.removeChangeListener(axisChangeListener22);
        double double24 = numberAxis3.getLabelAngle();
        boolean boolean25 = datasetGroup1.equals((java.lang.Object) numberAxis3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(font8);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener4 = null;
        defaultStatisticalCategoryDataset0.addChangeListener(datasetChangeListener4);
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumStackedRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.general.PieDataset pieDataset8 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (java.lang.Comparable) 0.95f);
        int int10 = defaultStatisticalCategoryDataset0.getColumnIndex((java.lang.Comparable) 1);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.0d + "'", number6.equals(0.0d));
        org.junit.Assert.assertNotNull(pieDataset8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        java.awt.Stroke stroke9 = barRenderer0.getItemOutlineStroke(1, (int) (byte) 1);
        java.awt.Paint paint10 = barRenderer0.getBasePaint();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo9 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo9);
        java.awt.geom.Rectangle2D rectangle2D11 = plotRenderingInfo10.getPlotArea();
        boolean boolean12 = categoryPlot0.render(graphics2D3, rectangle2D7, 0, plotRenderingInfo10);
        org.jfree.chart.plot.CategoryMarker categoryMarker14 = null;
        org.jfree.chart.util.Layer layer15 = null;
        try {
            categoryPlot0.addDomainMarker((int) (short) -1, categoryMarker14, layer15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNull(rectangle2D11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        java.awt.Stroke stroke9 = barRenderer0.getItemOutlineStroke(1, (int) (byte) 1);
        barRenderer0.setSeriesCreateEntities(0, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(stroke9);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer2.getBaseStroke();
        java.awt.Font font4 = barRenderer2.getBaseItemLabelFont();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("{0}", font4, (java.awt.Paint) color9, (float) ' ');
        java.awt.Font font15 = textFragment14.getFont();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge17);
        textTitle16.setPosition(rectangleEdge19);
        java.lang.String str21 = textTitle16.getURLText();
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean24 = numberAxis23.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis26 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double27 = numberAxis26.getLabelAngle();
        numberAxis26.setFixedDimension(0.0d);
        org.jfree.data.Range range30 = numberAxis26.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent31 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis26);
        java.util.EventListener eventListener32 = null;
        boolean boolean33 = numberAxis26.hasListener(eventListener32);
        java.awt.Stroke stroke34 = numberAxis26.getTickMarkStroke();
        org.jfree.data.Range range35 = numberAxis26.getRange();
        boolean boolean38 = range35.intersects((double) 2, (double) '#');
        numberAxis23.setRangeWithMargins(range35, false, true);
        boolean boolean42 = numberAxis23.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image45 = null;
        categoryPlot44.setBackgroundImage(image45);
        java.awt.Graphics2D graphics2D47 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo48 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo49 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo48);
        java.awt.geom.Rectangle2D rectangle2D50 = plotRenderingInfo49.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D51 = plotRenderingInfo49.getDataArea();
        categoryPlot44.drawBackgroundImage(graphics2D47, rectangle2D51);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge54 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge53);
        double double55 = numberAxis23.valueToJava2D((double) 0.5f, rectangle2D51, rectangleEdge53);
        textTitle16.setBounds(rectangle2D51);
        java.lang.String str57 = textTitle16.getToolTipText();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(range30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNull(rectangle2D50);
        org.junit.Assert.assertNotNull(rectangle2D51);
        org.junit.Assert.assertNotNull(rectangleEdge53);
        org.junit.Assert.assertNotNull(rectangleEdge54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNull(str57);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis1.refreshTicks(graphics2D11, axisState13, rectangle2D14, rectangleEdge15);
        org.jfree.chart.util.UnitType unitType17 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean18 = numberAxis1.equals((java.lang.Object) unitType17);
        boolean boolean19 = numberAxis1.getAutoRangeStickyZero();
        org.jfree.chart.axis.NumberAxis numberAxis21 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double22 = numberAxis21.getLabelAngle();
        numberAxis21.setFixedDimension(0.0d);
        org.jfree.data.Range range25 = numberAxis21.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double28 = numberAxis27.getLabelAngle();
        numberAxis27.setFixedDimension(0.0d);
        org.jfree.data.Range range31 = numberAxis27.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint32 = new org.jfree.chart.block.RectangleConstraint(range25, range31);
        numberAxis1.setRangeWithMargins(range25);
        double double34 = range25.getLength();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(range25);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(range31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.0d + "'", double34 == 1.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        org.jfree.chart.axis.Axis axis7 = axisChangeEvent6.getAxis();
        org.jfree.chart.JFreeChart jFreeChart8 = axisChangeEvent6.getChart();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = axisChangeEvent6.getType();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(axis7);
        org.junit.Assert.assertNull(jFreeChart8);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        categoryPlot0.configureDomainAxes();
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertNull(rectangle2D4);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultStatisticalCategoryDataset0.getGroup();
        org.jfree.data.Range range6 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertNull(range6);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit2 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        keyedObjects2D0.setObject((java.lang.Object) 0.2d, (java.lang.Comparable) numberTickUnit2, (java.lang.Comparable) 10);
        keyedObjects2D0.addObject((java.lang.Object) 2.0d, (java.lang.Comparable) 1, (java.lang.Comparable) 100);
        keyedObjects2D0.removeObject((java.lang.Comparable) "PlotOrientation.VERTICAL", (java.lang.Comparable) "hi!");
        keyedObjects2D0.removeObject((java.lang.Comparable) "EXPAND", (java.lang.Comparable) 10.0f);
        org.junit.Assert.assertNotNull(numberTickUnit2);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.axis.CategoryLabelWidthType categoryLabelWidthType0 = org.jfree.chart.axis.CategoryLabelWidthType.CATEGORY;
        org.junit.Assert.assertNotNull(categoryLabelWidthType0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = null;
        try {
            barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition19, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace1 = color0.getColorSpace();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace3 = color2.getColorSpace();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        java.awt.Color color5 = java.awt.Color.magenta;
        float[] floatArray6 = null;
        float[] floatArray7 = color5.getComponents(floatArray6);
        float[] floatArray8 = color4.getRGBColorComponents(floatArray7);
        float[] floatArray9 = color0.getColorComponents(colorSpace3, floatArray7);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(colorSpace1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(colorSpace3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor7 = categoryPlot0.getDomainGridlinePosition();
        int int8 = categoryPlot0.getRangeAxisCount();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot0.getRangeAxis(8);
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertNotNull(categoryAnchor7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNull(valueAxis10);
        org.junit.Assert.assertNull(datasetGroup11);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        java.awt.Font font0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        barRenderer0.setDrawBarOutline(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace9 = color8.getColorSpace();
        categoryPlot7.setOutlinePaint((java.awt.Paint) color8);
        java.awt.Paint paint11 = categoryPlot7.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        categoryPlot7.rendererChanged(rendererChangeEvent12);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = categoryPlot7.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image17 = null;
        categoryPlot16.setBackgroundImage(image17);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo20 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo20);
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot16.zoomRangeAxes(0.0d, plotRenderingInfo21, point2D22);
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot7.zoomRangeAxes((double) (byte) 1, plotRenderingInfo21, point2D24);
        boolean boolean26 = barRenderer0.equals((java.lang.Object) categoryPlot7);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(colorSpace9);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(categoryAnchor14);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        categoryPlot0.setDomainAxis(categoryAxis1);
        java.awt.Image image3 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo7.getPlotArea();
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes(10.0d, (double) 10.0f, plotRenderingInfo7, point2D9);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(rectangle2D8);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateLeftOutset((double) (byte) 1);
        boolean boolean4 = rectangleInsets0.equals((java.lang.Object) 10L);
        double double6 = rectangleInsets0.calculateRightInset(0.05d);
        double double8 = rectangleInsets0.calculateLeftInset((double) 'a');
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets0.createInsetRectangle(rectangle2D9, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        categoryPlot0.mapDatasetToRangeAxis((int) (byte) 100, 0);
        categoryPlot0.setBackgroundImageAlpha((float) 0);
        org.junit.Assert.assertNull(rectangle2D4);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        java.util.List list1 = projectInfo0.getContributors();
        projectInfo0.setLicenceText("http://www.jfree.org/jfreechart/index.html");
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color16 = java.awt.Color.CYAN;
        java.awt.Color color17 = java.awt.Color.CYAN;
        java.awt.Color color18 = java.awt.Color.red;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color10, color14, color15, color16, color17, color18 };
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color20 };
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke23 = null;
        java.awt.Stroke[] strokeArray24 = new java.awt.Stroke[] { stroke23 };
        java.awt.Shape shape25 = null;
        java.awt.Shape[] shapeArray26 = new java.awt.Shape[] { shape25 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray21, strokeArray22, strokeArray24, shapeArray26);
        java.awt.Paint paint28 = defaultDrawingSupplier27.getNextPaint();
        barRenderer0.setSeriesOutlinePaint(0, paint28, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer31 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint33 = barRenderer31.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint35 = barRenderer31.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Paint paint37 = barRenderer31.lookupSeriesFillPaint((int) (byte) 100);
        barRenderer0.setBaseFillPaint(paint37, true);
        java.awt.Paint paint40 = null;
        try {
            barRenderer0.setBaseOutlinePaint(paint40, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(shapeArray26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) (byte) 10);
        axisState1.cursorLeft((double) 0.0f);
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str6 = rectangleEdge5.toString();
        axisState1.moveCursor((double) (-15423), rectangleEdge5);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleEdge.LEFT" + "'", str6.equals("RectangleEdge.LEFT"));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setRight((double) '#');
        axisSpace0.setLeft((double) 10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = axisSpace0.reserved(rectangle2D5, rectangleEdge6);
        axisSpace0.setLeft((double) (-8355840));
        axisSpace0.setLeft((double) (short) 10);
        org.junit.Assert.assertNull(rectangle2D7);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis1.refreshTicks(graphics2D11, axisState13, rectangle2D14, rectangleEdge15);
        org.jfree.chart.util.UnitType unitType17 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean18 = numberAxis1.equals((java.lang.Object) unitType17);
        boolean boolean19 = numberAxis1.getAutoRangeStickyZero();
        try {
            numberAxis1.setRange((double) (byte) 100, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (100.0) <= upper (10.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke6 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke6, true);
        java.awt.Stroke stroke11 = barRenderer0.getItemOutlineStroke((int) (byte) -1, 0);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = barRenderer0.getBaseItemLabelGenerator();
        barRenderer0.setSeriesVisible((int) (short) 100, (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.TickUnits tickUnits0 = new org.jfree.chart.axis.TickUnits();
        try {
            org.jfree.chart.axis.TickUnit tickUnit2 = tickUnits0.get((int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        boolean boolean3 = textAnchor1.equals((java.lang.Object) "{0}");
        java.lang.String str4 = textAnchor1.toString();
        boolean boolean5 = keyedObjects0.equals((java.lang.Object) str4);
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean9 = numberAxis8.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke12 = barRenderer11.getBaseStroke();
        java.awt.Font font13 = barRenderer11.getBaseItemLabelFont();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean20 = color18.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color18);
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("{0}", font13, (java.awt.Paint) color18, (float) ' ');
        numberAxis8.setLabelFont(font13);
        numberAxis8.setLabelToolTip("");
        org.jfree.data.Range range27 = numberAxis8.getRange();
        keyedObjects0.setObject((java.lang.Comparable) "RectangleEdge.LEFT", (java.lang.Object) range27);
        double double30 = range27.constrain((double) 0.5f);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "TextAnchor.BOTTOM_CENTER" + "'", str4.equals("TextAnchor.BOTTOM_CENTER"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(range27);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.5d + "'", double30 == 0.5d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape5 = barRenderer0.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.chart.block.BlockBorder blockBorder7 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean8 = legendItemEntity6.equals((java.lang.Object) blockBorder7);
        java.awt.Shape shape9 = legendItemEntity6.getArea();
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createDownTriangle((float) 10);
        java.awt.Shape shape12 = org.jfree.chart.util.ShapeUtilities.clone(shape11);
        legendItemEntity6.setArea(shape12);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(blockBorder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(shape12);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setTickMarkInsideLength((float) 15);
        double double13 = numberAxis1.getLabelAngle();
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace18 = color17.getColorSpace();
        categoryPlot16.setOutlinePaint((java.awt.Paint) color17);
        java.awt.Paint paint20 = categoryPlot16.getOutlinePaint();
        org.jfree.chart.title.LegendGraphic legendGraphic21 = new org.jfree.chart.title.LegendGraphic(shape15, paint20);
        numberAxis1.setRightArrow(shape15);
        boolean boolean23 = numberAxis1.isAxisLineVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(colorSpace18);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0, jFreeChart8, chartChangeEventType9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint13 = barRenderer11.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        barRenderer11.setSeriesURLGenerator(10, categoryURLGenerator15, true);
        boolean boolean18 = barRenderer11.getAutoPopulateSeriesStroke();
        java.awt.Paint paint20 = barRenderer11.lookupSeriesFillPaint(10);
        barRenderer0.setBaseFillPaint(paint20);
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        barRenderer0.setSeriesFillPaint((int) (byte) 100, (java.awt.Paint) color23, false);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke5 = barRenderer4.getBaseStroke();
        java.awt.Font font6 = barRenderer4.getBaseItemLabelFont();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("{0}", font6, (java.awt.Paint) color11, (float) ' ');
        numberAxis1.setLabelFont(font6);
        numberAxis1.setLabelToolTip("");
        org.jfree.data.Range range20 = numberAxis1.getRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = numberAxis1.getLabelInsets();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertNotNull(rectangleInsets21);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape5 = barRenderer0.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        org.jfree.chart.block.BlockBorder blockBorder7 = org.jfree.chart.block.BlockBorder.NONE;
        boolean boolean8 = legendItemEntity6.equals((java.lang.Object) blockBorder7);
        java.lang.Object obj9 = null;
        boolean boolean10 = blockBorder7.equals(obj9);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(blockBorder7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = barRenderer0.getSeriesItemLabelGenerator((int) (short) 1);
        barRenderer0.setAutoPopulateSeriesOutlinePaint(true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator4);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color30);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double45 = numberAxis44.getLabelAngle();
        numberAxis44.setFixedDimension(0.0d);
        org.jfree.data.Range range48 = numberAxis44.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent49 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis44);
        java.awt.Shape shape50 = numberAxis44.getRightArrow();
        legendGraphic42.setLine(shape50);
        legendGraphic42.setWidth(0.0d);
        java.lang.String str54 = legendGraphic42.getID();
        boolean boolean55 = legendGraphic42.isShapeOutlineVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        java.lang.Number number4 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.general.DatasetGroup datasetGroup5 = defaultStatisticalCategoryDataset0.getGroup();
        java.lang.Number number6 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
        org.junit.Assert.assertNotNull(datasetGroup5);
        org.junit.Assert.assertEquals((double) number6, Double.NaN, 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer2.getBaseStroke();
        java.awt.Font font4 = barRenderer2.getBaseItemLabelFont();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("{0}", font4, (java.awt.Paint) color9, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("ThreadContext", font4);
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        java.lang.String str17 = rectangleInsets16.toString();
        labelBlock15.setMargin(rectangleInsets16);
        double double19 = rectangleInsets16.getTop();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleInsets16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]" + "'", str17.equals("RectangleInsets[t=2.0,l=4.0,b=2.0,r=4.0]"));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 2.0d + "'", double19 == 2.0d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint4 = barRenderer0.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke6 = null;
        barRenderer0.setSeriesOutlineStroke(0, stroke6, true);
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        barRenderer0.setBaseItemLabelPaint((java.awt.Paint) color9);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator13 = barRenderer0.getLegendItemToolTipGenerator();
        barRenderer0.setItemMargin((double) (-1.0f));
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator13);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("RectangleAnchor.BOTTOM");
        numberAxis1.setUpperMargin((double) 1L);
        boolean boolean4 = numberAxis1.getAutoRangeStickyZero();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        org.jfree.chart.axis.Axis axis7 = axisChangeEvent6.getAxis();
        org.jfree.chart.JFreeChart jFreeChart8 = axisChangeEvent6.getChart();
        org.jfree.chart.axis.Axis axis9 = axisChangeEvent6.getAxis();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(axis7);
        org.junit.Assert.assertNull(jFreeChart8);
        org.junit.Assert.assertNotNull(axis9);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        java.awt.Paint paint5 = barRenderer0.getSeriesItemLabelPaint(0);
        java.awt.Paint paint6 = barRenderer0.getBaseItemLabelPaint();
        barRenderer0.setBaseSeriesVisible(true, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        java.awt.Font font12 = barRenderer10.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = barRenderer10.getItemLabelGenerator((int) (byte) 0, (int) '4');
        java.awt.Stroke stroke16 = barRenderer10.getBaseStroke();
        barRenderer0.setBaseStroke(stroke16, true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNull(categoryItemLabelGenerator15);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color30);
        org.jfree.chart.axis.NumberAxis numberAxis44 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double45 = numberAxis44.getLabelAngle();
        numberAxis44.setFixedDimension(0.0d);
        org.jfree.data.Range range48 = numberAxis44.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent49 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis44);
        java.awt.Shape shape50 = numberAxis44.getRightArrow();
        legendGraphic42.setLine(shape50);
        legendGraphic42.setWidth(0.0d);
        java.awt.Color color54 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean56 = color54.equals((java.lang.Object) 0.0d);
        legendGraphic42.setFillPaint((java.awt.Paint) color54);
        org.jfree.chart.renderer.category.BarRenderer barRenderer58 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke59 = barRenderer58.getBaseStroke();
        boolean boolean61 = barRenderer58.isSeriesVisibleInLegend(0);
        java.awt.Stroke stroke63 = barRenderer58.getSeriesOutlineStroke((int) (short) 1);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer64 = barRenderer58.getGradientPaintTransformer();
        legendGraphic42.setFillPaintTransformer(gradientPaintTransformer64);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(range48);
        org.junit.Assert.assertNotNull(shape50);
        org.junit.Assert.assertNotNull(color54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(stroke59);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNull(stroke63);
        org.junit.Assert.assertNotNull(gradientPaintTransformer64);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        java.lang.String str2 = numberAxis1.getLabelToolTip();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer2.getBaseStroke();
        java.awt.Font font4 = barRenderer2.getBaseItemLabelFont();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("{0}", font4, (java.awt.Paint) color9, (float) ' ');
        java.awt.Font font15 = textFragment14.getFont();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge17);
        textTitle16.setPosition(rectangleEdge19);
        java.lang.String str21 = textTitle16.getURLText();
        java.lang.String str22 = textTitle16.getID();
        boolean boolean23 = textTitle16.getNotify();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNull(str22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        java.awt.Color color14 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color15 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.Color color16 = java.awt.Color.CYAN;
        java.awt.Color color17 = java.awt.Color.CYAN;
        java.awt.Color color18 = java.awt.Color.red;
        java.awt.Paint[] paintArray19 = new java.awt.Paint[] { color10, color14, color15, color16, color17, color18 };
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        java.awt.Paint[] paintArray21 = new java.awt.Paint[] { color20 };
        java.awt.Stroke[] strokeArray22 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        java.awt.Stroke stroke23 = null;
        java.awt.Stroke[] strokeArray24 = new java.awt.Stroke[] { stroke23 };
        java.awt.Shape shape25 = null;
        java.awt.Shape[] shapeArray26 = new java.awt.Shape[] { shape25 };
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier(paintArray19, paintArray21, strokeArray22, strokeArray24, shapeArray26);
        java.awt.Paint paint28 = defaultDrawingSupplier27.getNextPaint();
        barRenderer0.setSeriesOutlinePaint(0, paint28, false);
        int int31 = barRenderer0.getPassCount();
        barRenderer0.setBaseItemLabelsVisible(false);
        barRenderer0.removeAnnotations();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(paintArray19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(paintArray21);
        org.junit.Assert.assertNotNull(strokeArray22);
        org.junit.Assert.assertNotNull(strokeArray24);
        org.junit.Assert.assertNotNull(shapeArray26);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1 + "'", int31 == 1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Paint paint5 = barRenderer0.getSeriesFillPaint((int) (short) 0);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = legendTitle6.getLegendItemGraphicLocation();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        java.awt.Font font5 = barRenderer3.getBaseItemLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}", font5, (java.awt.Paint) color10, (float) ' ');
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        categoryPlot18.setOutlinePaint((java.awt.Paint) color19);
        java.awt.Paint paint22 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot18.rendererChanged(rendererChangeEvent23);
        categoryPlot18.setRangeCrosshairValue((double) 3, true);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font16, (org.jfree.chart.plot.Plot) categoryPlot18, false);
        int int30 = jFreeChart29.getBackgroundImageAlignment();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo34 = null;
        try {
            java.awt.image.BufferedImage bufferedImage35 = jFreeChart29.createBufferedImage((int) (byte) 10, (int) (short) 100, (int) (byte) -1, chartRenderingInfo34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 15 + "'", int30 == 15);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double8 = numberAxis7.getLabelAngle();
        numberAxis7.setFixedDimension(0.0d);
        org.jfree.data.Range range11 = numberAxis7.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double14 = numberAxis13.getLabelAngle();
        numberAxis13.setFixedDimension(0.0d);
        org.jfree.data.Range range17 = numberAxis13.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint18 = new org.jfree.chart.block.RectangleConstraint(range11, range17);
        java.lang.String str19 = range11.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint20 = new org.jfree.chart.block.RectangleConstraint(range5, range11);
        org.jfree.data.Range range21 = rectangleConstraint20.getHeightRange();
        java.lang.String str22 = rectangleConstraint20.toString();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(range17);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "Range[0.0,1.0]" + "'", str19.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(range21);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]" + "'", str22.equals("RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]"));
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        numberAxis1.setTickMarkInsideLength((float) 15);
        double double13 = numberAxis1.getLabelAngle();
        boolean boolean14 = numberAxis1.isVisible();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = barRenderer0.getLegendItemURLGenerator();
        java.awt.Paint paint5 = barRenderer0.getSeriesFillPaint((int) (short) 0);
        org.jfree.chart.title.LegendTitle legendTitle6 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) barRenderer0);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = null;
        try {
            legendTitle6.setLegendItemGraphicAnchor(rectangleAnchor7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'anchor' point.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator3);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (int) '#');
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.junit.Assert.assertNotNull(pieDataset2);
        org.junit.Assert.assertNull(range3);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = null;
        categoryPlot0.setDomainAxis(categoryAxis1);
        java.awt.Image image3 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo6 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo6);
        java.awt.geom.Rectangle2D rectangle2D8 = plotRenderingInfo7.getPlotArea();
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomRangeAxes(10.0d, (double) 10.0f, plotRenderingInfo7, point2D9);
        org.jfree.chart.LegendItemCollection legendItemCollection11 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        boolean boolean13 = legendItemCollection11.equals((java.lang.Object) axisLocation12);
        org.jfree.chart.axis.AxisLocation axisLocation14 = axisLocation12.getOpposite();
        org.jfree.chart.plot.PlotOrientation plotOrientation15 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation14, plotOrientation15);
        categoryPlot0.setOrientation(plotOrientation15);
        org.junit.Assert.assertNull(image3);
        org.junit.Assert.assertNull(rectangle2D8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(plotOrientation15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint7 = barRenderer3.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke9 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke9, true);
        java.awt.Stroke stroke14 = barRenderer3.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer0.setBaseStroke(stroke14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke18 = barRenderer17.getBaseStroke();
        barRenderer0.setSeriesOutlineStroke((int) (short) 10, stroke18);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator22 = barRenderer0.getURLGenerator((int) 'a', (int) (short) 10);
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color25 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace26 = color25.getColorSpace();
        categoryPlot24.setOutlinePaint((java.awt.Paint) color25);
        java.awt.Stroke stroke28 = categoryPlot24.getDomainGridlineStroke();
        barRenderer0.setSeriesOutlineStroke(1, stroke28, true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(categoryURLGenerator22);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(colorSpace26);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape5 = barRenderer0.getBaseShape();
        barRenderer0.setMaximumBarWidth((double) 100L);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator8 = barRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator8);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double8 = numberAxis7.getLabelAngle();
        numberAxis7.setFixedDimension(0.0d);
        org.jfree.data.Range range11 = numberAxis7.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint12 = new org.jfree.chart.block.RectangleConstraint(range5, range11);
        java.lang.String str13 = range5.toString();
        double double15 = range5.constrain((double) (-1.0f));
        org.jfree.chart.axis.NumberAxis numberAxis17 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean18 = numberAxis17.isTickMarksVisible();
        numberAxis17.setTickMarksVisible(false);
        boolean boolean21 = numberAxis17.isAutoRange();
        java.awt.Paint paint22 = numberAxis17.getTickLabelPaint();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double25 = numberAxis24.getLabelAngle();
        numberAxis24.setFixedDimension(0.0d);
        org.jfree.data.Range range28 = numberAxis24.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent29 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis24);
        java.util.EventListener eventListener30 = null;
        boolean boolean31 = numberAxis24.hasListener(eventListener30);
        java.awt.Stroke stroke32 = numberAxis24.getTickMarkStroke();
        org.jfree.data.Range range33 = numberAxis24.getRange();
        boolean boolean36 = range33.intersects((double) 2, (double) '#');
        numberAxis17.setRange(range33, true, false);
        org.jfree.chart.axis.NumberAxis numberAxis41 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double42 = numberAxis41.getLabelAngle();
        numberAxis41.setFixedDimension(0.0d);
        org.jfree.data.Range range45 = numberAxis41.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis47 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double48 = numberAxis47.getLabelAngle();
        numberAxis47.setFixedDimension(0.0d);
        org.jfree.data.Range range51 = numberAxis47.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis53 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double54 = numberAxis53.getLabelAngle();
        numberAxis53.setFixedDimension(0.0d);
        org.jfree.data.Range range57 = numberAxis53.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint58 = new org.jfree.chart.block.RectangleConstraint(range51, range57);
        java.lang.String str59 = range51.toString();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint60 = new org.jfree.chart.block.RectangleConstraint(range45, range51);
        double double61 = range45.getLength();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint62 = new org.jfree.chart.block.RectangleConstraint(range33, range45);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint63 = new org.jfree.chart.block.RectangleConstraint(range5, range45);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint65 = rectangleConstraint63.toFixedHeight(3.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(range11);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "Range[0.0,1.0]" + "'", str13.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(range28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(range45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(range51);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(range57);
        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "Range[0.0,1.0]" + "'", str59.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.0d + "'", double61 == 1.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint65);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        java.util.EventListener eventListener7 = null;
        boolean boolean8 = numberAxis1.hasListener(eventListener7);
        java.awt.Stroke stroke9 = numberAxis1.getTickMarkStroke();
        org.jfree.data.Range range10 = numberAxis1.getRange();
        boolean boolean12 = range10.contains(2.0d);
        org.jfree.chart.block.RectangleConstraint rectangleConstraint14 = new org.jfree.chart.block.RectangleConstraint(range10, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(range10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis1.refreshTicks(graphics2D11, axisState13, rectangle2D14, rectangleEdge15);
        org.jfree.chart.util.UnitType unitType17 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean18 = numberAxis1.equals((java.lang.Object) unitType17);
        boolean boolean19 = numberAxis1.isTickMarksVisible();
        java.lang.String str20 = numberAxis1.getLabelURL();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNull(str20);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace4 = color3.getColorSpace();
        categoryPlot2.setOutlinePaint((java.awt.Paint) color3);
        java.awt.Paint paint6 = categoryPlot2.getOutlinePaint();
        org.jfree.chart.title.LegendGraphic legendGraphic7 = new org.jfree.chart.title.LegendGraphic(shape1, paint6);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke12 = barRenderer11.getBaseStroke();
        java.awt.Font font13 = barRenderer11.getBaseItemLabelFont();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean20 = color18.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder21 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color18);
        org.jfree.chart.text.TextFragment textFragment23 = new org.jfree.chart.text.TextFragment("{0}", font13, (java.awt.Paint) color18, (float) ' ');
        java.awt.Font font24 = textFragment23.getFont();
        org.jfree.chart.title.TextTitle textTitle25 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font24);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge26);
        org.jfree.chart.util.RectangleEdge rectangleEdge28 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge26);
        textTitle25.setPosition(rectangleEdge28);
        java.lang.String str30 = textTitle25.getURLText();
        org.jfree.chart.axis.NumberAxis numberAxis32 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean33 = numberAxis32.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double36 = numberAxis35.getLabelAngle();
        numberAxis35.setFixedDimension(0.0d);
        org.jfree.data.Range range39 = numberAxis35.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent40 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis35);
        java.util.EventListener eventListener41 = null;
        boolean boolean42 = numberAxis35.hasListener(eventListener41);
        java.awt.Stroke stroke43 = numberAxis35.getTickMarkStroke();
        org.jfree.data.Range range44 = numberAxis35.getRange();
        boolean boolean47 = range44.intersects((double) 2, (double) '#');
        numberAxis32.setRangeWithMargins(range44, false, true);
        boolean boolean51 = numberAxis32.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image54 = null;
        categoryPlot53.setBackgroundImage(image54);
        java.awt.Graphics2D graphics2D56 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo57 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo57);
        java.awt.geom.Rectangle2D rectangle2D59 = plotRenderingInfo58.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D60 = plotRenderingInfo58.getDataArea();
        categoryPlot53.drawBackgroundImage(graphics2D56, rectangle2D60);
        org.jfree.chart.util.RectangleEdge rectangleEdge62 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge62);
        double double64 = numberAxis32.valueToJava2D((double) 0.5f, rectangle2D60, rectangleEdge62);
        textTitle25.setBounds(rectangle2D60);
        try {
            legendGraphic7.draw(graphics2D8, rectangle2D60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(colorSpace4);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(font24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(rectangleEdge28);
        org.junit.Assert.assertNull(str30);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(range39);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(range44);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNull(rectangle2D59);
        org.junit.Assert.assertNotNull(rectangle2D60);
        org.junit.Assert.assertNotNull(rectangleEdge62);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        java.awt.Paint paint4 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent5);
        boolean boolean7 = categoryPlot0.isOutlineVisible();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getInsets();
        double double11 = rectangleInsets9.calculateRightInset((double) 100L);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 8.0d + "'", double11 == 8.0d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        java.awt.Stroke stroke20 = barRenderer0.getSeriesStroke((int) (short) -1);
        boolean boolean21 = barRenderer0.getBaseItemLabelsVisible();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(stroke20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("TextBlockAnchor.TOP_LEFT", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.renderer.category.BarRenderer barRenderer4 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint6 = barRenderer4.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer4.setSeriesURLGenerator(10, categoryURLGenerator8, true);
        boolean boolean11 = barRenderer4.getAutoPopulateSeriesStroke();
        java.awt.Paint paint13 = barRenderer4.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent16 = null;
        barRenderer14.notifyListeners(rendererChangeEvent16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer14.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape19 = barRenderer14.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity20 = new org.jfree.chart.entity.LegendItemEntity(shape19);
        barRenderer4.setBaseShape(shape19, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity25 = new org.jfree.chart.entity.TickLabelEntity(shape19, "java.awt.Color[r=128,g=128,b=0]", "");
        java.awt.Color color26 = java.awt.Color.pink;
        org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("java.awt.Color[r=128,g=128,b=0]", "TextAnchor.BOTTOM_CENTER", "RectangleConstraint[RectangleConstraintType.RANGE: width=0.0, height=0.0]", "TextAnchor.BOTTOM_CENTER", shape19, (java.awt.Paint) color26);
        int int28 = legendItem27.getSeriesIndex();
        java.awt.Shape shape29 = legendItem27.getLine();
        java.awt.Paint paint30 = legendItem27.getOutlinePaint();
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint5 = barRenderer3.lookupSeriesFillPaint((int) (byte) -1);
        java.awt.Paint paint7 = barRenderer3.getSeriesItemLabelPaint((int) (short) 1);
        java.awt.Stroke stroke9 = null;
        barRenderer3.setSeriesOutlineStroke(0, stroke9, true);
        java.awt.Stroke stroke14 = barRenderer3.getItemOutlineStroke((int) (byte) -1, 0);
        barRenderer0.setBaseStroke(stroke14);
        boolean boolean16 = barRenderer0.getAutoPopulateSeriesPaint();
        java.awt.Color color18 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        try {
            barRenderer0.setSeriesFillPaint((-1), (java.awt.Paint) color18, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        org.jfree.data.general.PieDataset pieDataset5 = org.jfree.data.general.DatasetUtilities.createPieDatasetForColumn((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, (int) '#');
        int int7 = defaultStatisticalCategoryDataset0.getRowIndex((java.lang.Comparable) (-8355840));
        org.junit.Assert.assertEquals((double) number1, Double.NaN, 0);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertNotNull(pieDataset5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        barRenderer3.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock1, textBlockAnchor2, textAnchor8, 0.0d);
        org.jfree.chart.text.TextBlock textBlock11 = categoryTick10.getLabel();
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke15 = barRenderer14.getBaseStroke();
        java.awt.Font font16 = barRenderer14.getBaseItemLabelFont();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean23 = color21.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder24 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color21);
        org.jfree.chart.text.TextFragment textFragment26 = new org.jfree.chart.text.TextFragment("{0}", font16, (java.awt.Paint) color21, (float) ' ');
        java.awt.Font font27 = textFragment26.getFont();
        org.jfree.chart.title.TextTitle textTitle28 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font27);
        boolean boolean29 = textBlock11.equals((java.lang.Object) font27);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(textBlock11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType9 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer0, jFreeChart8, chartChangeEventType9);
        org.jfree.chart.renderer.category.BarRenderer barRenderer11 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint13 = barRenderer11.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        barRenderer11.setSeriesURLGenerator(10, categoryURLGenerator15, true);
        boolean boolean18 = barRenderer11.getAutoPopulateSeriesStroke();
        java.awt.Paint paint20 = barRenderer11.lookupSeriesFillPaint(10);
        barRenderer0.setBaseFillPaint(paint20);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = null;
        barRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator22, true);
        java.awt.Stroke stroke25 = barRenderer0.getBaseStroke();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint20);
        org.junit.Assert.assertNotNull(stroke25);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 0.95f, (double) '4', (double) (byte) 1, (double) 0.0f);
        java.awt.Paint paint5 = blockBorder4.getPaint();
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setRight((double) '#');
        axisSpace0.setLeft((double) 10L);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = axisSpace0.reserved(rectangle2D5, rectangleEdge6);
        axisSpace0.setLeft((double) (-8355840));
        java.lang.Object obj10 = axisSpace0.clone();
        org.junit.Assert.assertNull(rectangle2D7);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.util.RectangleInsets rectangleInsets6 = numberAxis1.getTickLabelInsets();
        double double8 = rectangleInsets6.calculateLeftOutset((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(rectangleInsets6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Rectangle2D rectangle2D6 = plotRenderingInfo5.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D7 = plotRenderingInfo5.getDataArea();
        categoryPlot0.drawBackgroundImage(graphics2D3, rectangle2D7);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = null;
        categoryPlot0.setDomainAxis((int) ' ', categoryAxis10, true);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot0.getDomainMarkers((int) (short) 1, layer14);
        categoryPlot0.setAnchorValue(3.0d);
        org.junit.Assert.assertNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertNull(collection15);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double2 = numberAxis1.getLabelAngle();
        numberAxis1.setFixedDimension(0.0d);
        org.jfree.data.Range range5 = numberAxis1.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        numberAxis1.setUpperBound((double) '4');
        numberAxis1.setAxisLineVisible(false);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.axis.AxisState axisState13 = new org.jfree.chart.axis.AxisState(10.0d);
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = null;
        java.util.List list16 = numberAxis1.refreshTicks(graphics2D11, axisState13, rectangle2D14, rectangleEdge15);
        org.jfree.chart.util.UnitType unitType17 = org.jfree.chart.util.UnitType.ABSOLUTE;
        boolean boolean18 = numberAxis1.equals((java.lang.Object) unitType17);
        numberAxis1.setInverted(true);
        numberAxis1.setLowerMargin((-1.0d));
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean25 = numberAxis24.isTickLabelsVisible();
        numberAxis24.setAutoRange(true);
        java.text.NumberFormat numberFormat28 = null;
        numberAxis24.setNumberFormatOverride(numberFormat28);
        boolean boolean30 = numberAxis1.equals((java.lang.Object) numberAxis24);
        numberAxis24.configure();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertNotNull(range5);
        org.junit.Assert.assertNotNull(list16);
        org.junit.Assert.assertNotNull(unitType17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.awt.Color color0 = java.awt.Color.white;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.chart.renderer.category.BarRenderer barRenderer1 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke2 = barRenderer1.getBaseStroke();
        java.awt.Font font3 = barRenderer1.getBaseItemLabelFont();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean10 = color8.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder11 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color8);
        org.jfree.chart.text.TextFragment textFragment13 = new org.jfree.chart.text.TextFragment("{0}", font3, (java.awt.Paint) color8, (float) ' ');
        java.awt.Font font14 = textFragment13.getFont();
        float float15 = textFragment13.getBaselineOffset();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 32.0f + "'", float15 == 32.0f);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        categoryItemRendererState1.setBarWidth(0.2d);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = categoryItemRendererState1.getInfo();
        org.junit.Assert.assertNull(plotRenderingInfo4);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image1 = null;
        categoryPlot0.setBackgroundImage(image1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo4 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo5 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo4);
        java.awt.geom.Point2D point2D6 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo5, point2D6);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot0.getRangeAxisLocation((int) (short) -1);
        java.awt.Paint paint10 = categoryPlot0.getRangeGridlinePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        org.jfree.chart.util.Layer layer12 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker11, layer12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertNotNull(paint10);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        categoryPlot0.configureDomainAxes();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset9 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.lang.Number number10 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9);
        org.jfree.data.Range range12 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9, true);
        org.jfree.data.general.DatasetChangeListener datasetChangeListener13 = null;
        defaultStatisticalCategoryDataset9.addChangeListener(datasetChangeListener13);
        java.lang.Number number17 = defaultStatisticalCategoryDataset9.getMeanValue((java.lang.Comparable) 15, (java.lang.Comparable) 1.0f);
        int int18 = defaultStatisticalCategoryDataset9.getColumnCount();
        categoryPlot0.setDataset(0, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset9);
        org.jfree.chart.axis.CategoryAxis categoryAxis22 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean25 = numberAxis24.isTickMarksVisible();
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke28 = barRenderer27.getBaseStroke();
        java.awt.Font font29 = barRenderer27.getBaseItemLabelFont();
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean36 = color34.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder37 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color34);
        org.jfree.chart.text.TextFragment textFragment39 = new org.jfree.chart.text.TextFragment("{0}", font29, (java.awt.Paint) color34, (float) ' ');
        numberAxis24.setLabelFont(font29);
        numberAxis24.setLowerBound(1.0E-8d);
        org.jfree.chart.event.AxisChangeListener axisChangeListener43 = null;
        numberAxis24.removeChangeListener(axisChangeListener43);
        double double45 = numberAxis24.getLabelAngle();
        boolean boolean46 = categoryAxis22.equals((java.lang.Object) double45);
        categoryAxis22.setMaximumCategoryLabelWidthRatio(0.0f);
        org.jfree.chart.plot.ValueMarker valueMarker51 = new org.jfree.chart.plot.ValueMarker((double) (byte) 0);
        java.awt.Shape shape53 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color55 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace56 = color55.getColorSpace();
        categoryPlot54.setOutlinePaint((java.awt.Paint) color55);
        java.awt.Paint paint58 = categoryPlot54.getOutlinePaint();
        org.jfree.chart.title.LegendGraphic legendGraphic59 = new org.jfree.chart.title.LegendGraphic(shape53, paint58);
        valueMarker51.setPaint(paint58);
        java.awt.Paint paint61 = valueMarker51.getOutlinePaint();
        categoryAxis22.setTickLabelPaint((java.lang.Comparable) 0.0f, paint61);
        try {
            categoryPlot0.setDomainAxis((int) (short) -1, categoryAxis22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(rectangle2D4);
        org.junit.Assert.assertEquals((double) number10, Double.NaN, 0);
        org.junit.Assert.assertNull(range12);
        org.junit.Assert.assertNull(number17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(font29);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(shape53);
        org.junit.Assert.assertNotNull(color55);
        org.junit.Assert.assertNotNull(colorSpace56);
        org.junit.Assert.assertNotNull(paint58);
        org.junit.Assert.assertNotNull(paint61);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions((double) 100.0f);
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        java.awt.Font font5 = barRenderer3.getBaseItemLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}", font5, (java.awt.Paint) color10, (float) ' ');
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        categoryPlot18.setOutlinePaint((java.awt.Paint) color19);
        java.awt.Paint paint22 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot18.rendererChanged(rendererChangeEvent23);
        categoryPlot18.setRangeCrosshairValue((double) 3, true);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font16, (org.jfree.chart.plot.Plot) categoryPlot18, false);
        jFreeChart29.setAntiAlias(true);
        jFreeChart29.setTitle("RectangleEdge.LEFT");
        java.awt.Stroke stroke34 = jFreeChart29.getBorderStroke();
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(stroke34);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.axis.AxisSpace axisSpace0 = new org.jfree.chart.axis.AxisSpace();
        axisSpace0.setRight((double) '#');
        axisSpace0.setLeft((double) 10L);
        java.lang.Object obj5 = axisSpace0.clone();
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent2 = null;
        barRenderer0.notifyListeners(rendererChangeEvent2);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = barRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape5 = barRenderer0.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity6 = new org.jfree.chart.entity.LegendItemEntity(shape5);
        legendItemEntity6.setToolTipText("PlotOrientation.VERTICAL");
        java.lang.String str9 = legendItemEntity6.toString();
        org.jfree.data.general.Dataset dataset10 = legendItemEntity6.getDataset();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(itemLabelPosition4);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str9.equals("LegendItemEntity: seriesKey=null, dataset=null"));
        org.junit.Assert.assertNull(dataset10);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setSeriesItemLabelsVisible((int) (byte) 1, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer5 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint7 = barRenderer5.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = null;
        barRenderer5.setSeriesURLGenerator(10, categoryURLGenerator9, true);
        boolean boolean12 = barRenderer5.getAutoPopulateSeriesStroke();
        org.jfree.chart.JFreeChart jFreeChart13 = null;
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType14 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent15 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) barRenderer5, jFreeChart13, chartChangeEventType14);
        barRenderer5.setSeriesVisibleInLegend((int) (byte) 10, (java.lang.Boolean) true, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition22 = barRenderer5.getPositiveItemLabelPosition((int) (short) 100, 10);
        barRenderer0.setSeriesPositiveItemLabelPosition((int) (byte) 0, itemLabelPosition22, true);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(chartChangeEventType14);
        org.junit.Assert.assertNotNull(itemLabelPosition22);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickLabelsVisible();
        java.awt.Paint paint3 = numberAxis1.getAxisLinePaint();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        numberAxis1.setAxisLinePaint((java.awt.Paint) color4);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        int int3 = java.awt.Color.HSBtoRGB((float) 15, (float) (byte) -1, (float) (-15423));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-129) + "'", int3 == (-129));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo0 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo1 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo0);
        java.awt.geom.Rectangle2D rectangle2D2 = plotRenderingInfo1.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D3 = plotRenderingInfo1.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo1.getPlotArea();
        org.junit.Assert.assertNull(rectangle2D2);
        org.junit.Assert.assertNull(rectangle2D3);
        org.junit.Assert.assertNull(rectangle2D4);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        numberAxis1.configure();
        numberAxis1.zoomRange((double) (short) 0, 10.0d);
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean8 = numberAxis7.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double11 = numberAxis10.getLabelAngle();
        numberAxis10.setFixedDimension(0.0d);
        org.jfree.data.Range range14 = numberAxis10.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent15 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis10);
        java.util.EventListener eventListener16 = null;
        boolean boolean17 = numberAxis10.hasListener(eventListener16);
        java.awt.Stroke stroke18 = numberAxis10.getTickMarkStroke();
        org.jfree.data.Range range19 = numberAxis10.getRange();
        boolean boolean22 = range19.intersects((double) 2, (double) '#');
        numberAxis7.setRangeWithMargins(range19, false, true);
        java.lang.String str26 = range19.toString();
        numberAxis1.setRangeWithMargins(range19, true, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color31 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace32 = color31.getColorSpace();
        categoryPlot30.setOutlinePaint((java.awt.Paint) color31);
        java.awt.Paint paint34 = categoryPlot30.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent35 = null;
        categoryPlot30.rendererChanged(rendererChangeEvent35);
        boolean boolean37 = categoryPlot30.isOutlineVisible();
        org.jfree.chart.util.Layer layer39 = null;
        java.util.Collection collection40 = categoryPlot30.getDomainMarkers((-8355840), layer39);
        numberAxis1.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot30);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(range19);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "Range[0.0,1.0]" + "'", str26.equals("Range[0.0,1.0]"));
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNotNull(colorSpace32);
        org.junit.Assert.assertNotNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(collection40);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = barRenderer0.getItemLabelGenerator((int) (short) 10, (int) '#');
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = barRenderer0.getPositiveItemLabelPosition((int) (short) -1, 2);
        java.awt.Shape shape16 = barRenderer0.getBaseShape();
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator12);
        org.junit.Assert.assertNotNull(itemLabelPosition15);
        org.junit.Assert.assertNotNull(shape16);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = barRenderer0.getItemLabelGenerator((int) (byte) 0, (int) '4');
        java.awt.Stroke stroke6 = barRenderer0.getBaseStroke();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator8 = null;
        barRenderer0.setSeriesToolTipGenerator(1, categoryToolTipGenerator8);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        java.awt.Font font5 = barRenderer3.getBaseItemLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}", font5, (java.awt.Paint) color10, (float) ' ');
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("ThreadContext", font5);
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        labelBlock16.setFont(font17);
        org.jfree.chart.text.TextLine textLine19 = new org.jfree.chart.text.TextLine("LGPL", font17);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font17);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        java.awt.Font font5 = barRenderer3.getBaseItemLabelFont();
        java.awt.Color color10 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean12 = color10.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder13 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color10);
        org.jfree.chart.text.TextFragment textFragment15 = new org.jfree.chart.text.TextFragment("{0}", font5, (java.awt.Paint) color10, (float) ' ');
        java.awt.Font font16 = textFragment15.getFont();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font16);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color19 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace20 = color19.getColorSpace();
        categoryPlot18.setOutlinePaint((java.awt.Paint) color19);
        java.awt.Paint paint22 = categoryPlot18.getOutlinePaint();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        categoryPlot18.rendererChanged(rendererChangeEvent23);
        categoryPlot18.setRangeCrosshairValue((double) 3, true);
        org.jfree.chart.JFreeChart jFreeChart29 = new org.jfree.chart.JFreeChart("VerticalAlignment.CENTER", font16, (org.jfree.chart.plot.Plot) categoryPlot18, false);
        jFreeChart29.setAntiAlias(true);
        jFreeChart29.setTitle("LGPL");
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(colorSpace20);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        org.jfree.chart.axis.AxisLocation axisLocation5 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        categoryPlot0.setRangeAxisLocation((int) (byte) 100, axisLocation5, false);
        categoryPlot0.setNoDataMessage("EXPAND");
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(axisLocation5);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo2 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo3 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo2);
        java.awt.geom.Rectangle2D rectangle2D4 = plotRenderingInfo3.getPlotArea();
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomDomainAxes(0.05d, plotRenderingInfo3, point2D5);
        org.jfree.chart.JFreeChart jFreeChart7 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        jFreeChart7.setTextAntiAlias(true);
        org.junit.Assert.assertNull(rectangle2D4);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.Range.shift(range0, (double) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace2 = color1.getColorSpace();
        categoryPlot0.setOutlinePaint((java.awt.Paint) color1);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        categoryPlot0.setDomainAxis(categoryAxis4);
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent6 = null;
        categoryPlot0.markerChanged(markerChangeEvent6);
        java.util.List list8 = categoryPlot0.getAnnotations();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(colorSpace2);
        org.junit.Assert.assertNotNull(list8);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickLabelsVisible();
        org.jfree.chart.axis.NumberAxis numberAxis4 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double5 = numberAxis4.getLabelAngle();
        numberAxis4.setFixedDimension(0.0d);
        org.jfree.data.Range range8 = numberAxis4.getRange();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double11 = numberAxis10.getLabelAngle();
        numberAxis10.setFixedDimension(0.0d);
        org.jfree.data.Range range14 = numberAxis10.getRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint15 = new org.jfree.chart.block.RectangleConstraint(range8, range14);
        numberAxis1.setRangeWithMargins(range8);
        double double17 = range8.getLowerBound();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(range8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(range14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_GREEN;
        java.awt.color.ColorSpace colorSpace7 = color6.getColorSpace();
        categoryPlot5.setOutlinePaint((java.awt.Paint) color6);
        java.awt.Stroke stroke9 = categoryPlot5.getDomainGridlineStroke();
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint12 = barRenderer10.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = null;
        barRenderer10.setSeriesURLGenerator(10, categoryURLGenerator14, true);
        boolean boolean17 = barRenderer10.getAutoPopulateSeriesStroke();
        java.awt.Paint paint19 = barRenderer10.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke21 = barRenderer20.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent22 = null;
        barRenderer20.notifyListeners(rendererChangeEvent22);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = barRenderer20.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape25 = barRenderer20.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity26 = new org.jfree.chart.entity.LegendItemEntity(shape25);
        barRenderer10.setBaseShape(shape25, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity31 = new org.jfree.chart.entity.TickLabelEntity(shape25, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer33 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke34 = barRenderer33.getBaseStroke();
        java.awt.Font font35 = barRenderer33.getBaseItemLabelFont();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean42 = color40.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder43 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color40);
        org.jfree.chart.text.TextFragment textFragment45 = new org.jfree.chart.text.TextFragment("{0}", font35, (java.awt.Paint) color40, (float) ' ');
        java.awt.image.ColorModel colorModel46 = null;
        java.awt.Rectangle rectangle47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        java.awt.geom.AffineTransform affineTransform49 = null;
        java.awt.RenderingHints renderingHints50 = null;
        java.awt.PaintContext paintContext51 = color40.createContext(colorModel46, rectangle47, rectangle2D48, affineTransform49, renderingHints50);
        org.jfree.chart.title.LegendGraphic legendGraphic52 = new org.jfree.chart.title.LegendGraphic(shape25, (java.awt.Paint) color40);
        try {
            org.jfree.chart.LegendItem legendItem53 = new org.jfree.chart.LegendItem(attributedString0, "ChartChangeEventType.DATASET_UPDATED", "SortOrder.ASCENDING", "SortOrder.ASCENDING", shape4, stroke9, (java.awt.Paint) color40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(colorSpace7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(font35);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(paintContext51);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.text.TextBlock textBlock1 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke4 = barRenderer3.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent5 = null;
        barRenderer3.notifyListeners(rendererChangeEvent5);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer3.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick10 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock1, textBlockAnchor2, textAnchor8, 0.0d);
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.util.Size2D size2D12 = textBlock1.calculateDimensions(graphics2D11);
        org.jfree.chart.text.TextLine textLine13 = textBlock1.getLastLine();
        org.junit.Assert.assertNotNull(textBlockAnchor2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertNotNull(size2D12);
        org.junit.Assert.assertNull(textLine13);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        java.awt.Font font2 = barRenderer0.getBaseItemLabelFont();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator5 = barRenderer0.getItemLabelGenerator((int) (byte) 0, (int) '4');
        org.jfree.chart.axis.NumberAxis numberAxis7 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean8 = numberAxis7.isTickMarksVisible();
        numberAxis7.setTickMarksVisible(false);
        boolean boolean11 = numberAxis7.isAutoRange();
        java.awt.Paint paint12 = numberAxis7.getTickLabelPaint();
        barRenderer0.setBasePaint(paint12);
        barRenderer0.setDrawBarOutline(false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = null;
        barRenderer0.setLegendItemToolTipGenerator(categorySeriesLabelGenerator16);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNull(categoryItemLabelGenerator5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Paint paint2 = barRenderer0.lookupSeriesFillPaint((int) (byte) -1);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator4 = null;
        barRenderer0.setSeriesURLGenerator(10, categoryURLGenerator4, true);
        boolean boolean7 = barRenderer0.getAutoPopulateSeriesStroke();
        java.awt.Paint paint9 = barRenderer0.lookupSeriesFillPaint(10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer10 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke11 = barRenderer10.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent12 = null;
        barRenderer10.notifyListeners(rendererChangeEvent12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer10.getBaseNegativeItemLabelPosition();
        java.awt.Shape shape15 = barRenderer10.getBaseShape();
        org.jfree.chart.entity.LegendItemEntity legendItemEntity16 = new org.jfree.chart.entity.LegendItemEntity(shape15);
        barRenderer0.setBaseShape(shape15, true);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity(shape15, "java.awt.Color[r=128,g=128,b=0]", "");
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke24 = barRenderer23.getBaseStroke();
        java.awt.Font font25 = barRenderer23.getBaseItemLabelFont();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean32 = color30.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder33 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color30);
        org.jfree.chart.text.TextFragment textFragment35 = new org.jfree.chart.text.TextFragment("{0}", font25, (java.awt.Paint) color30, (float) ' ');
        java.awt.image.ColorModel colorModel36 = null;
        java.awt.Rectangle rectangle37 = null;
        java.awt.geom.Rectangle2D rectangle2D38 = null;
        java.awt.geom.AffineTransform affineTransform39 = null;
        java.awt.RenderingHints renderingHints40 = null;
        java.awt.PaintContext paintContext41 = color30.createContext(colorModel36, rectangle37, rectangle2D38, affineTransform39, renderingHints40);
        org.jfree.chart.title.LegendGraphic legendGraphic42 = new org.jfree.chart.title.LegendGraphic(shape15, (java.awt.Paint) color30);
        java.awt.Paint paint43 = null;
        legendGraphic42.setFillPaint(paint43);
        java.awt.Paint paint45 = legendGraphic42.getOutlinePaint();
        legendGraphic42.setShapeVisible(true);
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paintContext41);
        org.junit.Assert.assertNull(paint45);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("TextAnchor.BOTTOM_CENTER");
        double double2 = categoryAxis1.getCategoryMargin();
        categoryAxis1.removeCategoryLabelToolTip((java.lang.Comparable) ' ');
        java.lang.Object obj5 = categoryAxis1.clone();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean13 = color11.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder14 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color11);
        int int15 = color11.getRGB();
        categoryAxis1.setTickLabelPaint((java.lang.Comparable) 100.0f, (java.awt.Paint) color11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2d + "'", double2 == 0.2d);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-8355840) + "'", int15 == (-8355840));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.renderer.category.BarRenderer barRenderer2 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke3 = barRenderer2.getBaseStroke();
        java.awt.Font font4 = barRenderer2.getBaseItemLabelFont();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        boolean boolean11 = color9.equals((java.lang.Object) 0.0d);
        org.jfree.chart.block.BlockBorder blockBorder12 = new org.jfree.chart.block.BlockBorder((double) 1, (double) 0, (double) 1, (double) 0, (java.awt.Paint) color9);
        org.jfree.chart.text.TextFragment textFragment14 = new org.jfree.chart.text.TextFragment("{0}", font4, (java.awt.Paint) color9, (float) ' ');
        java.awt.Font font15 = textFragment14.getFont();
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle("java.awt.Color[r=128,g=128,b=0]", font15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge17);
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge17);
        textTitle16.setPosition(rectangleEdge19);
        java.lang.String str21 = textTitle16.getURLText();
        org.jfree.chart.text.TextBlock textBlock23 = new org.jfree.chart.text.TextBlock();
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor24 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke26 = barRenderer25.getBaseStroke();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent27 = null;
        barRenderer25.notifyListeners(rendererChangeEvent27);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = barRenderer25.getBaseNegativeItemLabelPosition();
        org.jfree.chart.text.TextAnchor textAnchor30 = itemLabelPosition29.getTextAnchor();
        org.jfree.chart.axis.CategoryTick categoryTick32 = new org.jfree.chart.axis.CategoryTick((java.lang.Comparable) 0L, textBlock23, textBlockAnchor24, textAnchor30, 0.0d);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment33 = textBlock23.getLineAlignment();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment34 = org.jfree.chart.title.Title.DEFAULT_HORIZONTAL_ALIGNMENT;
        textBlock23.setLineAlignment(horizontalAlignment34);
        textTitle16.setHorizontalAlignment(horizontalAlignment34);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNull(str21);
        org.junit.Assert.assertNotNull(textBlockAnchor24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(itemLabelPosition29);
        org.junit.Assert.assertNotNull(textAnchor30);
        org.junit.Assert.assertNotNull(horizontalAlignment33);
        org.junit.Assert.assertNotNull(horizontalAlignment34);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean2 = numberAxis1.isTickLabelsVisible();
        numberAxis1.setAutoRange(true);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit5 = numberAxis1.getTickUnit();
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("hi!");
        boolean boolean9 = numberAxis8.isTickMarksVisible();
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("hi!");
        double double12 = numberAxis11.getLabelAngle();
        numberAxis11.setFixedDimension(0.0d);
        org.jfree.data.Range range15 = numberAxis11.getRange();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent16 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis11);
        java.util.EventListener eventListener17 = null;
        boolean boolean18 = numberAxis11.hasListener(eventListener17);
        java.awt.Stroke stroke19 = numberAxis11.getTickMarkStroke();
        org.jfree.data.Range range20 = numberAxis11.getRange();
        boolean boolean23 = range20.intersects((double) 2, (double) '#');
        numberAxis8.setRangeWithMargins(range20, false, true);
        boolean boolean27 = numberAxis8.isInverted();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Image image30 = null;
        categoryPlot29.setBackgroundImage(image30);
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo33 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = new org.jfree.chart.plot.PlotRenderingInfo(chartRenderingInfo33);
        java.awt.geom.Rectangle2D rectangle2D35 = plotRenderingInfo34.getPlotArea();
        java.awt.geom.Rectangle2D rectangle2D36 = plotRenderingInfo34.getDataArea();
        categoryPlot29.drawBackgroundImage(graphics2D32, rectangle2D36);
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = org.jfree.chart.util.RectangleEdge.LEFT;
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = org.jfree.chart.util.RectangleEdge.opposite(rectangleEdge38);
        double double40 = numberAxis8.valueToJava2D((double) 0.5f, rectangle2D36, rectangleEdge38);
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = org.jfree.chart.util.RectangleEdge.LEFT;
        java.lang.String str42 = rectangleEdge41.toString();
        double double43 = numberAxis1.lengthToJava2D((double) 2, rectangle2D36, rectangleEdge41);
        java.awt.Paint paint44 = numberAxis1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(numberTickUnit5);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(range15);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(range20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(rectangle2D35);
        org.junit.Assert.assertNotNull(rectangle2D36);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "RectangleEdge.LEFT" + "'", str42.equals("RectangleEdge.LEFT"));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(paint44);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        java.awt.Stroke stroke1 = barRenderer0.getBaseStroke();
        boolean boolean3 = barRenderer0.isSeriesItemLabelsVisible((int) '4');
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        boolean boolean2 = textAnchor0.equals((java.lang.Object) color1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }
}

