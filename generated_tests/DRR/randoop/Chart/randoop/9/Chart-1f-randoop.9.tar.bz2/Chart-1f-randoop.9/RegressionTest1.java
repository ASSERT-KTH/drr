import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getMinorTickMarkInsideLength();
        categoryAxis0.setLabelURL("");
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        int int1 = legendItemCollection0.getItemCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        boolean boolean12 = lineAndShapeRenderer0.getBaseShapesVisible();
        boolean boolean14 = lineAndShapeRenderer0.isSeriesVisible(0);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape2 = legendItem1.getLine();
        java.lang.Comparable comparable3 = null;
        legendItem1.setSeriesKey(comparable3);
        legendItem1.setDatasetIndex(100);
        org.junit.Assert.assertNotNull(shape2);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setVisible(true);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
//        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//        java.awt.Graphics2D graphics2D3 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
//        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
//        org.jfree.chart.plot.Marker marker9 = null;
//        java.awt.geom.Rectangle2D rectangle2D10 = null;
//        lineAndShapeRenderer2.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis8, marker9, rectangle2D10);
//        org.jfree.chart.util.Layer layer12 = null;
//        java.util.Collection collection13 = categoryPlot4.getDomainMarkers(layer12);
//        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
//        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
//        boolean boolean17 = barRenderer14.isSeriesVisible((int) (short) -1);
//        barRenderer14.setAutoPopulateSeriesStroke(true);
//        boolean boolean20 = barRenderer14.getDataBoundsIncludesVisibleSeriesOnly();
//        boolean boolean21 = barRenderer14.getShadowsVisible();
//        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//        java.awt.Stroke stroke25 = defaultDrawingSupplier24.getNextOutlineStroke();
//        categoryPlot23.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier24, true);
//        java.awt.Paint paint28 = defaultDrawingSupplier24.getNextPaint();
//        java.awt.Shape shape29 = defaultDrawingSupplier24.getNextShape();
//        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
//        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        categoryPlot30.setNoDataMessagePaint((java.awt.Paint) color31);
//        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryPlot30.getInsets();
//        org.jfree.chart.axis.AxisSpace axisSpace34 = categoryPlot30.getFixedDomainAxisSpace();
//        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//        java.awt.Graphics2D graphics2D36 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot37.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
//        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
//        org.jfree.chart.plot.Marker marker42 = null;
//        java.awt.geom.Rectangle2D rectangle2D43 = null;
//        lineAndShapeRenderer35.drawRangeMarker(graphics2D36, categoryPlot37, valueAxis41, marker42, rectangle2D43);
//        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier45 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//        java.awt.Stroke stroke46 = defaultDrawingSupplier45.getNextOutlineStroke();
//        categoryPlot37.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier45);
//        categoryPlot30.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier45);
//        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisSpace axisSpace50 = categoryPlot49.getFixedRangeAxisSpace();
//        boolean boolean51 = defaultDrawingSupplier45.equals((java.lang.Object) categoryPlot49);
//        categoryPlot49.clearRangeAxes();
//        org.jfree.chart.entity.PlotEntity plotEntity55 = new org.jfree.chart.entity.PlotEntity(shape29, (org.jfree.chart.plot.Plot) categoryPlot49, "ChartChangeEventType.GENERAL", "GradientPaintTransformType.CENTER_VERTICAL");
//        barRenderer14.setSeriesShape(10, shape29, true);
//        try {
//            shapeList0.setShape((-1), shape29);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNull(collection13);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//        org.junit.Assert.assertNotNull(stroke25);
//        org.junit.Assert.assertNotNull(paint28);
//        org.junit.Assert.assertNotNull(shape29);
//        org.junit.Assert.assertNotNull(color31);
//        org.junit.Assert.assertNotNull(rectangleInsets33);
//        org.junit.Assert.assertNull(axisSpace34);
//        org.junit.Assert.assertNotNull(stroke46);
//        org.junit.Assert.assertNull(axisSpace50);
//        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
//    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_BLUE;
        lineAndShapeRenderer0.setBaseItemLabelPaint((java.awt.Paint) color3, false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier42 = null;
        categoryPlot29.setDrawingSupplier(drawingSupplier42);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = categoryPlot29.getRenderer((int) (short) 0);
        org.jfree.data.general.DatasetGroup datasetGroup46 = categoryPlot29.getDatasetGroup();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(categoryItemRenderer45);
        org.junit.Assert.assertNull(datasetGroup46);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint4 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '#');
        boolean boolean5 = lineAndShapeRenderer0.getBaseShapesFilled();
        java.awt.Shape shape7 = lineAndShapeRenderer0.lookupLegendShape((int) (short) 100);
        boolean boolean8 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Font font10 = lineAndShapeRenderer0.lookupLegendTextFont((int) (short) 1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNull(font10);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) true);
        java.awt.Stroke stroke3 = renderAttributes0.getDefaultOutlineStroke();
        java.awt.Shape shape6 = renderAttributes0.getItemShape(10, (int) 'a');
        java.awt.Shape shape8 = renderAttributes0.getSeriesShape((int) (short) 0);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(shape6);
        org.junit.Assert.assertNull(shape8);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        barRenderer12.setDrawBarOutline(false);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = legendItem18.getFillPaintTransformer();
        barRenderer12.setGradientPaintTransformer(gradientPaintTransformer19);
        java.awt.Paint paint22 = barRenderer12.lookupSeriesPaint((int) (byte) 100);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator24 = null;
        try {
            barRenderer12.setSeriesToolTipGenerator((-32640), categoryToolTipGenerator24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer19);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE11" + "'", str1.equals("ItemLabelAnchor.INSIDE11"));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedRangeAxisSpace();
        boolean boolean2 = categoryPlot0.isRangePannable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 8, plotRenderingInfo4, point2D5, false);
        org.jfree.chart.util.SortOrder sortOrder8 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder8);
        java.awt.Stroke stroke10 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke14 = defaultDrawingSupplier13.getNextOutlineStroke();
        categoryPlot12.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier13, true);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot12.getDomainAxisLocation(1);
        java.lang.String str19 = axisLocation18.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation18, plotOrientation20);
        categoryPlot0.setRangeAxisLocation((int) 'a', axisLocation18, true);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str19.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setLabelAngle(100.0d);
        categoryPlot0.setDomainAxis((int) (short) 100, categoryAxis5, true);
        java.awt.Image image10 = categoryPlot0.getBackgroundImage();
        boolean boolean11 = categoryPlot0.isRangeCrosshairVisible();
        boolean boolean12 = categoryPlot0.isOutlineVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("hi!");
        java.lang.String str2 = datasetGroup1.getID();
        java.lang.String str3 = datasetGroup1.getID();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "hi!" + "'", str3.equals("hi!"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        double double5 = rectangleInsets3.extendHeight((double) (byte) 1);
        double double7 = rectangleInsets3.calculateTopOutset((double) 'a');
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 9.0d + "'", double5 == 9.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        java.awt.Color color4 = java.awt.Color.ORANGE;
        java.awt.Color color5 = color4.brighter();
        java.awt.Color color6 = color5.brighter();
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot0.getAxisOffset();
        java.lang.String str9 = rectangleInsets8.toString();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]" + "'", str9.equals("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]"));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer12.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = barRenderer12.getDrawingSupplier();
        barRenderer12.setDrawBarOutline(true);
        barRenderer12.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(drawingSupplier15);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.lang.Boolean boolean6 = lineAndShapeRenderer3.getSeriesShapesFilled(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        lineAndShapeRenderer8.drawRangeMarker(graphics2D9, categoryPlot10, valueAxis14, marker15, rectangle2D16);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot10.getDomainMarkers(layer18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer20);
        boolean boolean23 = barRenderer20.isSeriesVisible((int) (short) -1);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape27 = legendItem26.getLine();
        barRenderer20.setSeriesShape(0, shape27, false);
        lineAndShapeRenderer3.setSeriesShape((int) (byte) 1, shape27);
        boolean boolean33 = lineAndShapeRenderer3.getItemShapeVisible((int) (byte) 10, 1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke11 = lineAndShapeRenderer7.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem14 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape15 = legendItem14.getLine();
        java.awt.Font font16 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem14.setLabelFont(font16);
        lineAndShapeRenderer7.setSeriesItemLabelFont((int) ' ', font16);
        lineAndShapeRenderer7.setBaseShapesFilled(true);
        boolean boolean21 = legendItem1.equals((java.lang.Object) lineAndShapeRenderer7);
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        java.awt.Color color3 = java.awt.Color.getHSBColor((float) 8, 0.0f, (float) ' ');
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape5, "AxisLocation.TOP_OR_RIGHT", "hi!");
        java.awt.Shape shape10 = chartEntity9.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot12.setNoDataMessagePaint((java.awt.Paint) color13);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator18 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color13, (float) ' ', (int) (byte) 0, (double) (-1));
        double double19 = defaultShadowGenerator18.getAngle();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        lineAndShapeRenderer20.drawRangeMarker(graphics2D21, categoryPlot22, valueAxis26, marker27, rectangle2D28);
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = categoryPlot22.getDomainMarkers(layer30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot22.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo34, point2D35);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        categoryPlot22.setFixedDomainAxisSpace(axisSpace37);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean43 = lineAndShapeRenderer40.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer40.setPlot(categoryPlot44);
        categoryPlot22.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer40);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot49.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.plot.Marker marker54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        lineAndShapeRenderer47.drawRangeMarker(graphics2D48, categoryPlot49, valueAxis53, marker54, rectangle2D55);
        org.jfree.chart.axis.AxisLocation axisLocation58 = null;
        categoryPlot49.setRangeAxisLocation((int) (short) 100, axisLocation58, false);
        lineAndShapeRenderer40.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot49);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = categoryPlot49.getRangeAxisEdge(100);
        categoryPlot49.setDomainCrosshairVisible(false);
        boolean boolean66 = categoryPlot49.isRangeGridlinesVisible();
        boolean boolean67 = defaultShadowGenerator18.equals((java.lang.Object) categoryPlot49);
        org.jfree.chart.entity.PlotEntity plotEntity68 = new org.jfree.chart.entity.PlotEntity(shape10, (org.jfree.chart.plot.Plot) categoryPlot49);
        java.lang.String str69 = plotEntity68.getShapeCoords();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + str69 + "' != '" + "0,0,0,0" + "'", str69.equals("0,0,0,0"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.lang.Object obj1 = shapeList0.clone();
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 0, false);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) (-1), (double) 10.0f, plotRenderingInfo10, point2D11);
        categoryPlot0.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo16 = null;
        java.awt.geom.Point2D point2D17 = null;
        categoryPlot0.zoomRangeAxes((-16.0d), plotRenderingInfo16, point2D17, true);
        boolean boolean20 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        categoryPlot29.setRangeCrosshairVisible(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean47 = lineAndShapeRenderer44.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer44.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color50 = java.awt.Color.darkGray;
        lineAndShapeRenderer44.setBaseOutlinePaint((java.awt.Paint) color50, false);
        categoryPlot29.setOutlinePaint((java.awt.Paint) color50);
        java.awt.Paint paint54 = null;
        try {
            categoryPlot29.setRangeZeroBaselinePaint(paint54);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(color50);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("hi!");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("hi!");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
        java.lang.String str5 = unknownKeyException1.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.UnknownKeyException: hi!" + "'", str5.equals("org.jfree.data.UnknownKeyException: hi!"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        lineAndShapeRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        java.awt.Shape shape6 = lineAndShapeRenderer0.getBaseShape();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        lineAndShapeRenderer8.drawRangeMarker(graphics2D9, categoryPlot10, valueAxis14, marker15, rectangle2D16);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot10.getDomainMarkers(layer18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer20);
        boolean boolean23 = barRenderer20.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = barRenderer20.getBaseNegativeItemLabelPosition();
        barRenderer20.setShadowYOffset((double) (-1L));
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer20.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color28);
        lineAndShapeRenderer0.setSeriesPaint(255, (java.awt.Paint) color28);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        barRenderer12.setDrawBarOutline(false);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = legendItem18.getFillPaintTransformer();
        barRenderer12.setGradientPaintTransformer(gradientPaintTransformer19);
        java.awt.Paint paint21 = barRenderer12.getBasePaint();
        boolean boolean22 = barRenderer12.getIncludeBaseInRange();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer19);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = null;
        try {
            org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean2 = legendItem1.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int7 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean8 = legendItem1.equals((java.lang.Object) categoryPlot3);
        categoryPlot3.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        barRenderer12.setItemMargin(0.2d);
        org.jfree.chart.renderer.category.BarPainter barPainter16 = null;
        try {
            barRenderer12.setBarPainter(barPainter16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'painter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke14 = defaultDrawingSupplier13.getNextOutlineStroke();
        categoryPlot12.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier13, true);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot12.getDomainAxisLocation(1);
        org.jfree.chart.axis.AxisLocation axisLocation19 = axisLocation18.getOpposite();
        boolean boolean20 = lineAndShapeRenderer0.equals((java.lang.Object) axisLocation19);
        boolean boolean21 = lineAndShapeRenderer0.getUseOutlinePaint();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot24.setNoDataMessagePaint((java.awt.Paint) color25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryPlot24.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray29 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis28 };
        categoryPlot24.setDomainAxes(categoryAxisArray29);
        java.awt.Stroke stroke31 = categoryPlot24.getDomainCrosshairStroke();
        categoryPlot23.setDomainGridlineStroke(stroke31);
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        try {
            lineAndShapeRenderer0.drawBackground(graphics2D22, categoryPlot23, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(categoryAxisArray29);
        org.junit.Assert.assertNotNull(stroke31);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color2);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color2, (float) ' ', (int) (byte) 0, (double) (-1));
        int int8 = defaultShadowGenerator7.calculateOffsetX();
        int int9 = defaultShadowGenerator7.getShadowSize();
        int int10 = defaultShadowGenerator7.getDistance();
        java.awt.Color color11 = defaultShadowGenerator7.getShadowColor();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-35) + "'", int8 == (-35));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer0.setPlot(categoryPlot4);
        categoryPlot4.setBackgroundImageAlignment((int) (short) 0);
        java.util.List list8 = categoryPlot4.getAnnotations();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot4.getFixedLegendItems();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot4);
        org.jfree.chart.event.AnnotationChangeEvent annotationChangeEvent11 = null;
        categoryPlot4.annotationChanged(annotationChangeEvent11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(legendItemCollection9);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        boolean boolean12 = lineAndShapeRenderer7.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        java.awt.Stroke stroke22 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot14.setDomainGridlineStroke(stroke22);
        lineAndShapeRenderer7.setSeriesOutlineStroke((int) ' ', stroke22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        int int28 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4194304));
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.setValue(0.0d, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) "TextAnchor.CENTER");
        try {
            defaultCategoryDataset0.setSelected((int) ' ', 0, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 32, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator3, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        java.awt.Paint paint7 = lineAndShapeRenderer0.getBaseOutlinePaint();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.awt.Color color0 = java.awt.Color.orange;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        java.awt.Paint paint7 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot0.getRangeMarkers(layer8);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(collection9);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke11 = defaultDrawingSupplier10.getNextOutlineStroke();
        categoryPlot2.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot2.setRangeAxis(0, valueAxis14);
        categoryPlot2.setAnchorValue((double) (-32640));
        org.jfree.chart.plot.CategoryMarker categoryMarker18 = null;
        org.jfree.chart.util.Layer layer19 = null;
        try {
            categoryPlot2.addDomainMarker(categoryMarker18, layer19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        boolean boolean4 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 10);
        double double3 = rectangleInsets0.getRight();
        double double5 = rectangleInsets0.calculateBottomOutset(255.0d);
        double double7 = rectangleInsets0.calculateTopInset((double) 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.0d + "'", double3 == 8.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isDomainCrosshairVisible();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_LIGHT_BLUE;
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color2);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        lineAndShapeRenderer0.setUseSeriesOffset(false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot2.setRangeAxisLocation((int) (short) 100, axisLocation11, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextOutlineStroke();
        categoryPlot15.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16, true);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot15.getDomainAxisLocation(1);
        categoryPlot2.setDomainAxisLocation(0, axisLocation21);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot2.getRangeAxisForDataset(10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = categoryPlot2.getDrawingSupplier();
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean29 = legendItem28.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color31 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot30.setNoDataMessagePaint((java.awt.Paint) color31);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int34 = categoryPlot30.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer33);
        boolean boolean35 = legendItem28.equals((java.lang.Object) categoryPlot30);
        org.jfree.chart.axis.AxisLocation axisLocation37 = categoryPlot30.getRangeAxisLocation(8);
        try {
            categoryPlot2.setDomainAxisLocation((-4194304), axisLocation37, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(drawingSupplier25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(axisLocation37);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        double double16 = barRenderer12.getShadowYOffset();
        java.awt.Color color18 = java.awt.Color.ORANGE;
        java.awt.Color color19 = color18.brighter();
        barRenderer12.setSeriesOutlinePaint((int) '4', (java.awt.Paint) color19, true);
        org.jfree.chart.renderer.category.BarPainter barPainter22 = barRenderer12.getBarPainter();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(barPainter22);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        lineAndShapeRenderer0.setSeriesShapesFilled(0, (java.lang.Boolean) false);
        lineAndShapeRenderer0.setBaseSeriesVisibleInLegend(false);
        lineAndShapeRenderer0.setSeriesLinesVisible(0, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint2 = lineAndShapeRenderer0.getSeriesPaint((int) (byte) 0);
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getSeriesStroke(1);
        double double5 = lineAndShapeRenderer0.getItemMargin();
        lineAndShapeRenderer0.setSeriesShapesFilled(0, false);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        legendItem1.setSeriesKey((java.lang.Comparable) 10L);
        java.awt.Paint paint5 = legendItem1.getLabelPaint();
        boolean boolean6 = legendItem1.isShapeFilled();
        legendItem1.setShapeVisible(false);
        legendItem1.setLineVisible(false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer12.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer12.getToolTipGenerator(0, (int) (byte) 10, true);
        java.awt.Paint paint22 = barRenderer12.getItemOutlinePaint(192, 15, false);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertNotNull(paint22);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("0,0,0,0", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape2 = legendItem1.getLine();
        java.lang.String str3 = legendItem1.getDescription();
        legendItem1.setDatasetIndex((int) (short) -1);
        boolean boolean6 = legendItem1.isLineVisible();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.jfree.data.category.AbstractCategoryDataset abstractCategoryDataset0 = new org.jfree.data.category.AbstractCategoryDataset();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot1.getInsets();
        boolean boolean5 = categoryPlot1.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo7 = null;
        java.awt.geom.Point2D point2D8 = null;
        categoryPlot1.zoomDomainAxes((double) (short) 100, plotRenderingInfo7, point2D8, true);
        categoryPlot1.clearRangeMarkers();
        boolean boolean12 = abstractCategoryDataset0.hasListener((java.util.EventListener) categoryPlot1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        lineAndShapeRenderer5.drawRangeMarker(graphics2D6, categoryPlot7, valueAxis11, marker12, rectangle2D13);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke16 = defaultDrawingSupplier15.getNextOutlineStroke();
        categoryPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot19.getFixedRangeAxisSpace();
        boolean boolean21 = defaultDrawingSupplier15.equals((java.lang.Object) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot19.getRendererForDataset(categoryDataset22);
        categoryPlot19.clearRangeAxes();
        categoryPlot19.clearRangeMarkers();
        java.awt.Paint paint26 = null;
        try {
            categoryPlot19.setDomainCrosshairPaint(paint26);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(categoryItemRenderer23);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer12.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer12.getToolTipGenerator(0, (int) (byte) 10, true);
        java.awt.Shape shape19 = barRenderer12.getBaseShape();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertNotNull(shape19);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint4 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '#');
        java.awt.Stroke stroke8 = lineAndShapeRenderer0.getItemStroke(1, (int) (short) 1, false);
        lineAndShapeRenderer0.setItemLabelAnchorOffset((double) 255);
        java.lang.Object obj11 = lineAndShapeRenderer0.clone();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset14 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        float float16 = categoryAxis15.getTickMarkOutsideLength();
        categoryAxis15.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets19 = categoryAxis15.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke23 = lineAndShapeRenderer21.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint25 = lineAndShapeRenderer21.lookupLegendTextPaint((int) '#');
        boolean boolean26 = lineAndShapeRenderer21.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot29.setNoDataMessagePaint((java.awt.Paint) color30);
        org.jfree.chart.util.RectangleInsets rectangleInsets32 = categoryPlot29.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis33 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray34 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis33 };
        categoryPlot29.setDomainAxes(categoryAxisArray34);
        java.awt.Stroke stroke36 = categoryPlot29.getDomainCrosshairStroke();
        categoryPlot28.setDomainGridlineStroke(stroke36);
        lineAndShapeRenderer21.setSeriesOutlineStroke((int) ' ', stroke36, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset14, categoryAxis15, valueAxis20, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer21);
        org.jfree.chart.axis.CategoryAxis categoryAxis41 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis41.setUpperMargin((double) (short) 0);
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot45.setNoDataMessagePaint((java.awt.Paint) color46);
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = categoryPlot45.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace49 = null;
        categoryPlot45.setFixedDomainAxisSpace(axisSpace49);
        org.jfree.chart.util.RectangleEdge rectangleEdge51 = categoryPlot45.getDomainAxisEdge();
        try {
            double double52 = lineAndShapeRenderer0.getItemMiddle((java.lang.Comparable) 0.5f, (java.lang.Comparable) 10L, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset14, categoryAxis41, rectangle2D44, rectangleEdge51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: -1");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 2.0f + "'", float16 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets19);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(rectangleInsets32);
        org.junit.Assert.assertNotNull(categoryAxisArray34);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertNotNull(rectangleEdge51);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color6 = java.awt.Color.darkGray;
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color6, false);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getTickLabelInsets();
        float float13 = categoryAxis11.getTickMarkInsideLength();
        java.awt.Paint paint14 = categoryAxis11.getLabelPaint();
        categoryAxis11.setFixedDimension((double) 0);
        boolean boolean17 = categoryAxis11.isTickMarksVisible();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) (short) -1);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.util.Layer layer21 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        try {
            lineAndShapeRenderer0.drawAnnotations(graphics2D9, rectangle2D10, categoryAxis11, valueAxis20, layer21, plotRenderingInfo22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer0.setPlot(categoryPlot4);
        categoryPlot4.setBackgroundImageAlignment((int) (short) 0);
        java.util.List list8 = categoryPlot4.getAnnotations();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot4.getFixedLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot4.setDataset((int) ' ', categoryDataset11);
        java.awt.Paint paint13 = categoryPlot4.getRangeMinorGridlinePaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot4.getRangeAxisEdge(0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(rectangleEdge15);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        boolean boolean12 = lineAndShapeRenderer7.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        java.awt.Stroke stroke22 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot14.setDomainGridlineStroke(stroke22);
        lineAndShapeRenderer7.setSeriesOutlineStroke((int) ' ', stroke22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        int int28 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4194304));
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.setValue(0.0d, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) "TextAnchor.CENTER");
        java.lang.Object obj34 = defaultCategoryDataset0.clone();
        defaultCategoryDataset0.clear();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(obj34);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        org.jfree.chart.LegendItem legendItem3 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer4 = legendItem3.getFillPaintTransformer();
        org.jfree.data.general.Dataset dataset5 = legendItem3.getDataset();
        java.awt.Stroke stroke6 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        legendItem3.setOutlineStroke(stroke6);
        legendItem1.setOutlineStroke(stroke6);
        org.junit.Assert.assertNotNull(gradientPaintTransformer4);
        org.junit.Assert.assertNull(dataset5);
        org.junit.Assert.assertNotNull(stroke6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        categoryPlot29.setRangeCrosshairVisible(false);
        boolean boolean44 = categoryPlot29.canSelectByPoint();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedRangeAxisSpace();
        boolean boolean2 = categoryPlot0.isRangePannable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 8, plotRenderingInfo4, point2D5, false);
        org.jfree.chart.util.SortOrder sortOrder8 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder8);
        java.awt.Stroke stroke10 = categoryPlot0.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke14 = defaultDrawingSupplier13.getNextOutlineStroke();
        categoryPlot12.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier13, true);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot12.getDomainAxisLocation(1);
        java.lang.String str19 = axisLocation18.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation18, plotOrientation20);
        categoryPlot0.setRangeAxisLocation((int) 'a', axisLocation18, true);
        boolean boolean24 = categoryPlot0.isRangeCrosshairVisible();
        float float25 = categoryPlot0.getForegroundAlpha();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str19.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 1.0f + "'", float25 == 1.0f);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(35);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot29.getRangeAxisEdge(100);
        categoryPlot29.setCrosshairDatasetIndex(100, true);
        org.jfree.chart.axis.AxisLocation axisLocation47 = categoryPlot29.getRangeAxisLocation();
        org.jfree.chart.plot.CategoryMarker categoryMarker48 = null;
        try {
            categoryPlot29.addDomainMarker(categoryMarker48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(axisLocation47);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        lineAndShapeRenderer5.drawRangeMarker(graphics2D6, categoryPlot7, valueAxis11, marker12, rectangle2D13);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke16 = defaultDrawingSupplier15.getNextOutlineStroke();
        categoryPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot19.getFixedRangeAxisSpace();
        boolean boolean21 = defaultDrawingSupplier15.equals((java.lang.Object) categoryPlot19);
        categoryPlot19.clearRangeAxes();
        categoryPlot19.setRangeMinorGridlinesVisible(false);
        java.awt.Paint paint25 = categoryPlot19.getRangeMinorGridlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.plot.Marker marker43 = null;
        org.jfree.chart.util.Layer layer44 = null;
        boolean boolean46 = categoryPlot29.removeDomainMarker((int) (short) 100, marker43, layer44, false);
        java.awt.Stroke stroke47 = categoryPlot29.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        boolean boolean12 = lineAndShapeRenderer7.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        java.awt.Stroke stroke22 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot14.setDomainGridlineStroke(stroke22);
        lineAndShapeRenderer7.setSeriesOutlineStroke((int) ' ', stroke22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        int int28 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4194304));
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.setValue(0.0d, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) "TextAnchor.CENTER");
        try {
            defaultCategoryDataset0.removeColumn((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getMinorTickMarkInsideLength();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int9 = categoryPlot5.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot5.setDataset(categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot5.getDomainAxis((int) (short) 100);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        boolean boolean15 = categoryPlot5.canSelectByRegion();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = categoryPlot5.getOrientation();
        java.lang.String str17 = plotOrientation16.toString();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "PlotOrientation.VERTICAL" + "'", str17.equals("PlotOrientation.VERTICAL"));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color2);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color2, (float) ' ', (int) (byte) 0, (double) (-1));
        int int8 = defaultShadowGenerator7.calculateOffsetX();
        int int9 = defaultShadowGenerator7.getShadowSize();
        int int10 = defaultShadowGenerator7.getDistance();
        java.awt.image.BufferedImage bufferedImage11 = null;
        try {
            java.awt.image.BufferedImage bufferedImage12 = defaultShadowGenerator7.createDropShadow(bufferedImage11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-35) + "'", int8 == (-35));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj1 = standardCategorySeriesLabelGenerator0.clone();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke5 = defaultDrawingSupplier4.getNextOutlineStroke();
        categoryPlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4, true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot3.getDomainAxisLocation(1);
        categoryPlot3.setForegroundAlpha((float) (short) 100);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot3, "hi!");
        boolean boolean14 = standardCategorySeriesLabelGenerator0.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(axisLocation9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        barRenderer0.setMaximumBarWidth((double) 0.0f);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator12 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj13 = standardCategorySeriesLabelGenerator12.clone();
        barRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator12);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        categoryPlot2.setBackgroundAlpha((float) 8);
        java.awt.Paint paint21 = null;
        try {
            categoryPlot2.setNoDataMessagePaint(paint21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        categoryPlot0.setDataset(categoryDataset5);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot0.getRenderer();
        org.jfree.chart.axis.ValueAxis valueAxis10 = categoryPlot0.getRangeAxis();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNull(valueAxis10);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getBaseCreateEntities();
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape7 = legendItem6.getLine();
        lineAndShapeRenderer0.setBaseLegendShape(shape7);
        java.awt.Paint paint9 = null;
        try {
            lineAndShapeRenderer0.setBaseFillPaint(paint9, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape7);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        barRenderer12.setDrawBarOutline(false);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = legendItem18.getFillPaintTransformer();
        barRenderer12.setGradientPaintTransformer(gradientPaintTransformer19);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = barRenderer12.getBaseURLGenerator();
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer22 = barRenderer12.getGradientPaintTransformer();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer19);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertNotNull(gradientPaintTransformer22);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot0.setRangeAxis(valueAxis5);
        categoryPlot0.setRangeCrosshairValue((double) '#');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        float float11 = categoryAxis10.getTickMarkOutsideLength();
        categoryAxis10.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis10.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke18 = lineAndShapeRenderer16.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint20 = lineAndShapeRenderer16.lookupLegendTextPaint((int) '#');
        boolean boolean21 = lineAndShapeRenderer16.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot24.setNoDataMessagePaint((java.awt.Paint) color25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryPlot24.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray29 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis28 };
        categoryPlot24.setDomainAxes(categoryAxisArray29);
        java.awt.Stroke stroke31 = categoryPlot24.getDomainCrosshairStroke();
        categoryPlot23.setDomainGridlineStroke(stroke31);
        lineAndShapeRenderer16.setSeriesOutlineStroke((int) ' ', stroke31, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, categoryAxis10, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer16);
        int int37 = defaultCategoryDataset9.getRowIndex((java.lang.Comparable) (-4194304));
        defaultCategoryDataset9.clear();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = categoryPlot0.getRendererForDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        categoryPlot0.zoomRangeAxes(0.0d, plotRenderingInfo41, point2D42);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(categoryAxisArray29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNull(categoryItemRenderer39);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean2 = lineAndShapeRenderer0.isSeriesVisible((int) (byte) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator5 = lineAndShapeRenderer3.getSeriesToolTipGenerator(1);
        java.lang.Boolean boolean7 = lineAndShapeRenderer3.getSeriesLinesVisible((int) (byte) 0);
        java.awt.Color color9 = java.awt.Color.GRAY;
        lineAndShapeRenderer3.setSeriesItemLabelPaint(10, (java.awt.Paint) color9);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator11 = lineAndShapeRenderer3.getLegendItemLabelGenerator();
        lineAndShapeRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator11);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = lineAndShapeRenderer0.getSeriesItemLabelGenerator(0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator5);
        org.junit.Assert.assertNull(boolean7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator11);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot17.setNoDataMessagePaint((java.awt.Paint) color18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryPlot17.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace21 = categoryPlot17.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot24.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.plot.Marker marker29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        lineAndShapeRenderer22.drawRangeMarker(graphics2D23, categoryPlot24, valueAxis28, marker29, rectangle2D30);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier32 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke33 = defaultDrawingSupplier32.getNextOutlineStroke();
        categoryPlot24.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier32);
        categoryPlot17.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier32);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace37 = categoryPlot36.getFixedRangeAxisSpace();
        boolean boolean38 = defaultDrawingSupplier32.equals((java.lang.Object) categoryPlot36);
        java.awt.Stroke stroke39 = categoryPlot36.getDomainCrosshairStroke();
        categoryPlot2.setOutlineStroke(stroke39);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNull(axisSpace21);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(axisSpace37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(stroke39);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.lang.Boolean boolean6 = lineAndShapeRenderer3.getSeriesShapesFilled(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        lineAndShapeRenderer8.drawRangeMarker(graphics2D9, categoryPlot10, valueAxis14, marker15, rectangle2D16);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot10.getDomainMarkers(layer18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer20);
        boolean boolean23 = barRenderer20.isSeriesVisible((int) (short) -1);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape27 = legendItem26.getLine();
        barRenderer20.setSeriesShape(0, shape27, false);
        lineAndShapeRenderer3.setSeriesShape((int) (byte) 1, shape27);
        java.awt.Graphics2D graphics2D31 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot34.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis38 = null;
        org.jfree.chart.plot.Marker marker39 = null;
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        lineAndShapeRenderer32.drawRangeMarker(graphics2D33, categoryPlot34, valueAxis38, marker39, rectangle2D40);
        java.awt.Color color42 = java.awt.Color.WHITE;
        categoryPlot34.setOutlinePaint((java.awt.Paint) color42);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        categoryPlot34.panRangeAxes(0.0d, plotRenderingInfo45, point2D46);
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color49 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot48.setNoDataMessagePaint((java.awt.Paint) color49);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int52 = categoryPlot48.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer51);
        org.jfree.chart.axis.AxisSpace axisSpace53 = null;
        categoryPlot48.setFixedRangeAxisSpace(axisSpace53);
        java.awt.Stroke stroke55 = categoryPlot48.getRangeCrosshairStroke();
        categoryPlot34.setDomainGridlineStroke(stroke55);
        categoryPlot34.setDomainGridlinesVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis59 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = categoryAxis59.getTickLabelInsets();
        float float61 = categoryAxis59.getMinorTickMarkInsideLength();
        org.jfree.chart.plot.CategoryMarker categoryMarker62 = null;
        java.awt.geom.Rectangle2D rectangle2D63 = null;
        try {
            lineAndShapeRenderer3.drawDomainMarker(graphics2D31, categoryPlot34, categoryAxis59, categoryMarker62, rectangle2D63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1) + "'", int52 == (-1));
        org.junit.Assert.assertNotNull(stroke55);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertTrue("'" + float61 + "' != '" + 0.0f + "'", float61 == 0.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        categoryPlot0.clearDomainAxes();
        boolean boolean5 = categoryPlot0.isRangeCrosshairVisible();
        java.awt.Paint paint6 = null;
        try {
            categoryPlot0.setNoDataMessagePaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        boolean boolean12 = lineAndShapeRenderer7.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        java.awt.Stroke stroke22 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot14.setDomainGridlineStroke(stroke22);
        lineAndShapeRenderer7.setSeriesOutlineStroke((int) ' ', stroke22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        int int28 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4194304));
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.setValue(0.0d, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) "TextAnchor.CENTER");
        int int34 = defaultCategoryDataset0.getColumnCount();
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) 1L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (1) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextOutlineStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1, true);
        java.awt.Paint paint5 = defaultDrawingSupplier1.getNextPaint();
        java.awt.Shape shape6 = defaultDrawingSupplier1.getNextShape();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot7.setNoDataMessagePaint((java.awt.Paint) color8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryPlot7.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot7.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.Marker marker19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        lineAndShapeRenderer12.drawRangeMarker(graphics2D13, categoryPlot14, valueAxis18, marker19, rectangle2D20);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke23 = defaultDrawingSupplier22.getNextOutlineStroke();
        categoryPlot14.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        categoryPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot26.getFixedRangeAxisSpace();
        boolean boolean28 = defaultDrawingSupplier22.equals((java.lang.Object) categoryPlot26);
        categoryPlot26.clearRangeAxes();
        org.jfree.chart.entity.PlotEntity plotEntity32 = new org.jfree.chart.entity.PlotEntity(shape6, (org.jfree.chart.plot.Plot) categoryPlot26, "ChartChangeEventType.GENERAL", "GradientPaintTransformType.CENTER_VERTICAL");
        categoryPlot26.setDomainCrosshairRowKey((java.lang.Comparable) 1.0d);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNull(axisSpace27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryPlot0.getAxisOffset();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        int int9 = categoryPlot0.indexOf(categoryDataset8);
        int int10 = categoryPlot0.getDatasetCount();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot0.getDomainAxisEdge();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(rectangleEdge11);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        boolean boolean0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultShadowsVisible();
//        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        categoryPlot2.mapDatasetToRangeAxis(8, (int) '4');
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot2.getDomainAxisLocation();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(axisLocation15);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        lineAndShapeRenderer1.drawRangeMarker(graphics2D2, categoryPlot3, valueAxis7, marker8, rectangle2D9);
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot3.setRangeAxisLocation((int) (short) 100, axisLocation12, false);
        java.awt.Color color15 = java.awt.Color.ORANGE;
        java.awt.Color color16 = color15.brighter();
        categoryPlot3.setRangeMinorGridlinePaint((java.awt.Paint) color16);
        categoryPlot0.setRangeZeroBaselinePaint((java.awt.Paint) color16);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        java.awt.Color color0 = java.awt.Color.white;
        int int1 = color0.getBlue();
        java.awt.Color color2 = java.awt.Color.ORANGE;
        java.awt.Color color3 = color2.brighter();
        float[] floatArray8 = new float[] { (-10289251), (-1.0f), 2.0f, 0.0f };
        float[] floatArray9 = color3.getComponents(floatArray8);
        float[] floatArray10 = color0.getColorComponents(floatArray9);
        java.lang.String str11 = color0.toString();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "java.awt.Color[r=255,g=255,b=255]" + "'", str11.equals("java.awt.Color[r=255,g=255,b=255]"));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setSeriesFillPaint((int) 'a', (java.awt.Paint) color11, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer14.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean18 = lineAndShapeRenderer14.getDrawOutlines();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = lineAndShapeRenderer19.getSeriesToolTipGenerator(1);
        java.lang.Boolean boolean23 = lineAndShapeRenderer19.getSeriesLinesVisible((int) (byte) 0);
        java.awt.Color color25 = java.awt.Color.GRAY;
        lineAndShapeRenderer19.setSeriesItemLabelPaint(10, (java.awt.Paint) color25);
        lineAndShapeRenderer14.setBaseLegendTextPaint((java.awt.Paint) color25);
        barRenderer0.setShadowPaint((java.awt.Paint) color25);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition29 = barRenderer0.getNegativeItemLabelPositionFallback();
        barRenderer0.setBaseCreateEntities(true, false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
        org.junit.Assert.assertNull(boolean23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNull(itemLabelPosition29);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        java.lang.Boolean boolean12 = lineAndShapeRenderer0.getSeriesVisible((int) (short) 100);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNull(boolean12);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        java.awt.Paint paint3 = categoryAxis0.getLabelPaint();
        categoryAxis0.setFixedDimension((double) 0);
        boolean boolean6 = categoryAxis0.isTickMarksVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot7.setNoDataMessagePaint((java.awt.Paint) color8);
        categoryPlot7.setCrosshairDatasetIndex((int) (byte) 0, false);
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot7.zoomRangeAxes((double) (-1), (double) 10.0f, plotRenderingInfo17, point2D18);
        categoryPlot7.setDomainGridlinesVisible(false);
        categoryPlot7.clearAnnotations();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int25 = color24.getTransparency();
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color24);
        java.awt.Stroke stroke27 = categoryAxis0.getTickMarkStroke();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot28.setNoDataMessagePaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryPlot28.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis32 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray33 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis32 };
        categoryPlot28.setDomainAxes(categoryAxisArray33);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot28);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(categoryAxisArray33);
    }

//    @Test
//    public void test093() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test093");
//        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//        java.awt.Graphics2D graphics2D1 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
//        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
//        org.jfree.chart.plot.Marker marker7 = null;
//        java.awt.geom.Rectangle2D rectangle2D8 = null;
//        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
//        org.jfree.chart.util.Layer layer10 = null;
//        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
//        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
//        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
//        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer12.getPositiveItemLabelPositionFallback();
//        org.jfree.chart.plot.DrawingSupplier drawingSupplier15 = barRenderer12.getDrawingSupplier();
//        boolean boolean16 = barRenderer12.getShadowsVisible();
//        org.junit.Assert.assertNull(collection11);
//        org.junit.Assert.assertNull(itemLabelPosition14);
//        org.junit.Assert.assertNotNull(drawingSupplier15);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot2.setRangeAxisLocation((int) (short) 100, axisLocation11, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextOutlineStroke();
        categoryPlot15.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16, true);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot15.getDomainAxisLocation(1);
        categoryPlot2.setDomainAxisLocation(0, axisLocation21);
        float float23 = categoryPlot2.getForegroundAlpha();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean26 = legendItem25.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot27.setNoDataMessagePaint((java.awt.Paint) color28);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int31 = categoryPlot27.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer30);
        boolean boolean32 = legendItem25.equals((java.lang.Object) categoryPlot27);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot27.getRangeAxisLocation(8);
        categoryPlot2.setDomainAxisLocation(axisLocation34);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertTrue("'" + float23 + "' != '" + 1.0f + "'", float23 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1) + "'", int31 == (-1));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        boolean boolean5 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemLabelPaint((int) (byte) 10, (int) (byte) -1, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        lineAndShapeRenderer9.drawRangeMarker(graphics2D10, categoryPlot11, valueAxis15, marker16, rectangle2D17);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot11.getDomainMarkers(layer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot11.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo23, point2D24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot11.setFixedDomainAxisSpace(axisSpace26);
        categoryPlot11.setBackgroundAlpha((float) 8);
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace31 = categoryPlot30.getFixedRangeAxisSpace();
        boolean boolean32 = categoryPlot30.isRangePannable();
        java.awt.Paint paint33 = categoryPlot30.getRangeMinorGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset34 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer35 = categoryPlot30.getRendererForDataset(categoryDataset34);
        org.jfree.chart.util.SortOrder sortOrder36 = categoryPlot30.getRowRenderingOrder();
        categoryPlot11.setRowRenderingOrder(sortOrder36);
        boolean boolean38 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot11);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNull(axisSpace31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNull(categoryItemRenderer35);
        org.junit.Assert.assertNotNull(sortOrder36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean2 = legendItem1.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int7 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean8 = legendItem1.equals((java.lang.Object) categoryPlot3);
        boolean boolean9 = categoryPlot3.isRangeZeroBaselineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot3.getRendererForDataset(categoryDataset10);
        categoryPlot3.setDomainCrosshairColumnKey((java.lang.Comparable) false);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        categoryPlot3.setDomainGridlinePosition(categoryAnchor14);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryItemRenderer11);
        org.junit.Assert.assertNotNull(categoryAnchor14);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis0.getTickLabelInsets();
        double double3 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.05d + "'", double3 == 0.05d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean7 = lineAndShapeRenderer4.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = lineAndShapeRenderer4.getPositiveItemLabelPosition((int) (short) 1, (int) (byte) 1, true);
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition11, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        lineAndShapeRenderer15.drawRangeMarker(graphics2D16, categoryPlot17, valueAxis21, marker22, rectangle2D23);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot17.getDomainMarkers(layer25);
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot17.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer27);
        boolean boolean30 = barRenderer27.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = barRenderer27.getBaseNegativeItemLabelPosition();
        barRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 10, itemLabelPosition31);
        boolean boolean36 = barRenderer0.getItemCreateEntity((int) (short) 10, (-4194304), true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) ' ');
        int int2 = objectList1.size();
        java.awt.Stroke stroke3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_STROKE;
        boolean boolean4 = objectList1.equals((java.lang.Object) stroke3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        java.awt.Stroke stroke15 = lineAndShapeRenderer7.getItemStroke(1, (int) (short) 1, false);
        legendItem1.setOutlineStroke(stroke15);
        java.lang.String str17 = legendItem1.getToolTipText();
        int int18 = legendItem1.getDatasetIndex();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(str17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean2 = legendItem1.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int7 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean8 = legendItem1.equals((java.lang.Object) categoryPlot3);
        java.lang.Comparable comparable9 = legendItem1.getSeriesKey();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(comparable9);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        barRenderer12.setDrawBarOutline(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = barRenderer12.getGradientPaintTransformer();
        barRenderer12.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        barRenderer12.notifyListeners(rendererChangeEvent20);
        java.awt.Color color23 = java.awt.Color.ORANGE;
        java.awt.Color color24 = color23.brighter();
        java.awt.Color color25 = color24.brighter();
        barRenderer12.setSeriesFillPaint((int) (short) 100, (java.awt.Paint) color24);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = null;
        barRenderer12.setBaseToolTipGenerator(categoryToolTipGenerator27, true);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer17);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace5);
        boolean boolean7 = categoryPlot0.isDomainGridlinesVisible();
        boolean boolean8 = categoryPlot0.isRangePannable();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            boolean boolean10 = categoryPlot0.removeAnnotation(categoryAnnotation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        boolean boolean4 = itemLabelAnchor0.equals((java.lang.Object) color3);
        float[] floatArray10 = new float[] { 0L, (byte) 100, 32.0f, (-1L), 'a' };
        float[] floatArray11 = color3.getRGBComponents(floatArray10);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 100.0d);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType10 = chartChangeEvent9.getType();
        java.lang.Object obj11 = null;
        boolean boolean12 = chartChangeEventType10.equals(obj11);
        plotChangeEvent7.setType(chartChangeEventType10);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(chartChangeEventType10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.JFreeChart jFreeChart8 = plotChangeEvent7.getChart();
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNull(jFreeChart8);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color2);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color2, (float) ' ', (int) (byte) 0, (double) (-1));
        int int8 = defaultShadowGenerator7.calculateOffsetX();
        float float9 = defaultShadowGenerator7.getShadowOpacity();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-35) + "'", int8 == (-35));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 32.0f + "'", float9 == 32.0f);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        lineAndShapeRenderer0.setSeriesShapesFilled(0, (java.lang.Boolean) false);
        lineAndShapeRenderer0.setUseFillPaint(false);
        boolean boolean20 = lineAndShapeRenderer0.getItemCreateEntity((int) '4', (int) (byte) 100, true);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape5, "AxisLocation.TOP_OR_RIGHT", "hi!");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean14 = lineAndShapeRenderer10.getDrawOutlines();
        java.awt.Paint paint18 = lineAndShapeRenderer10.getItemLabelPaint((int) (byte) 10, (int) (byte) -1, false);
        boolean boolean19 = chartEntity9.equals((java.lang.Object) lineAndShapeRenderer10);
        java.awt.Shape shape20 = null;
        try {
            chartEntity9.setArea(shape20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_LIGHT_YELLOW;
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer12.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        barRenderer12.setSeriesURLGenerator(10, categoryURLGenerator19, false);
        double double22 = barRenderer12.getBase();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        barRenderer12.notifyListeners(rendererChangeEvent23);
        barRenderer12.setSeriesItemLabelsVisible(4, true);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        barRenderer0.setMaximumBarWidth((double) 0.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer0.getPositiveItemLabelPositionFallback();
        barRenderer0.setShadowYOffset(9.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNull(itemLabelPosition14);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot0.removeDomainMarker((int) (short) 10, marker9, layer10);
        java.util.List list12 = categoryPlot0.getCategories();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(list12);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        java.awt.Color color1 = java.awt.Color.getColor("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        java.awt.Paint paint3 = categoryAxis0.getLabelPaint();
        org.jfree.chart.plot.Plot plot4 = categoryAxis0.getPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot5.getInsets();
        double double10 = rectangleInsets8.calculateTopOutset((double) 1.0f);
        double double12 = rectangleInsets8.calculateLeftInset(100.0d);
        categoryAxis0.setTickLabelInsets(rectangleInsets8);
        categoryAxis0.setCategoryMargin((double) (short) -1);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot24.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.plot.Marker marker29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        lineAndShapeRenderer22.drawRangeMarker(graphics2D23, categoryPlot24, valueAxis28, marker29, rectangle2D30);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = categoryPlot24.getDomainMarkers(layer32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        categoryPlot24.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo36, point2D37);
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        categoryPlot24.setFixedDomainAxisSpace(axisSpace39);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean45 = lineAndShapeRenderer42.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer42.setPlot(categoryPlot46);
        categoryPlot24.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer42);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer49 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot51.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.plot.Marker marker56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        lineAndShapeRenderer49.drawRangeMarker(graphics2D50, categoryPlot51, valueAxis55, marker56, rectangle2D57);
        org.jfree.chart.axis.AxisLocation axisLocation60 = null;
        categoryPlot51.setRangeAxisLocation((int) (short) 100, axisLocation60, false);
        lineAndShapeRenderer42.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot51);
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = categoryPlot51.getRangeAxisEdge(100);
        try {
            double double66 = categoryAxis0.getCategorySeriesMiddle((-4194304), 0, (int) (short) 10, 0, (-8.0d), rectangle2D21, rectangleEdge65);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.0d + "'", double12 == 8.0d);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(rectangleEdge65);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double1 = rectangleInsets0.getTop();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.jfree.data.SelectableValue selectableValue2 = new org.jfree.data.SelectableValue((java.lang.Number) (-35), true);
        selectableValue2.setSelected(false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        lineAndShapeRenderer2.setAutoPopulateSeriesStroke(true);
        lineAndShapeRenderer2.setDefaultEntityRadius((int) ' ');
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.lang.Object obj5 = categoryPlot0.clone();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getRangeMarkers(layer6);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        int int10 = categoryPlot0.indexOf(categoryDataset9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = categoryPlot0.getDomainGridlinePosition();
        java.awt.Paint paint12 = categoryPlot0.getOutlinePaint();
        float float13 = categoryPlot0.getBackgroundImageAlpha();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.5f + "'", float13 == 0.5f);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke7 = defaultDrawingSupplier6.getNextOutlineStroke();
        categoryPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier6, true);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot5.getDomainAxisLocation(1);
        java.lang.String str12 = axisLocation11.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation11, plotOrientation13);
        org.jfree.chart.axis.AxisState axisState15 = null;
        categoryAxis0.drawTickMarks(graphics2D2, 0.05d, rectangle2D4, rectangleEdge14, axisState15);
        int int17 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Paint paint18 = categoryAxis0.getTickLabelPaint();
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D23 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot24.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.plot.Marker marker29 = null;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        lineAndShapeRenderer22.drawRangeMarker(graphics2D23, categoryPlot24, valueAxis28, marker29, rectangle2D30);
        org.jfree.chart.util.Layer layer32 = null;
        java.util.Collection collection33 = categoryPlot24.getDomainMarkers(layer32);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo36 = null;
        java.awt.geom.Point2D point2D37 = null;
        categoryPlot24.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo36, point2D37);
        org.jfree.chart.axis.AxisSpace axisSpace39 = null;
        categoryPlot24.setFixedDomainAxisSpace(axisSpace39);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean45 = lineAndShapeRenderer42.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer42.setPlot(categoryPlot46);
        categoryPlot24.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer42);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer49 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D50 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot51.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis55 = null;
        org.jfree.chart.plot.Marker marker56 = null;
        java.awt.geom.Rectangle2D rectangle2D57 = null;
        lineAndShapeRenderer49.drawRangeMarker(graphics2D50, categoryPlot51, valueAxis55, marker56, rectangle2D57);
        org.jfree.chart.axis.AxisLocation axisLocation60 = null;
        categoryPlot51.setRangeAxisLocation((int) (short) 100, axisLocation60, false);
        lineAndShapeRenderer42.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot51);
        org.jfree.chart.util.RectangleEdge rectangleEdge65 = categoryPlot51.getRangeAxisEdge(100);
        org.jfree.chart.axis.AxisState axisState66 = null;
        categoryAxis0.drawTickMarks(graphics2D19, (double) 32.0f, rectangle2D21, rectangleEdge65, axisState66);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str12.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertNull(collection33);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(rectangleEdge65);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint4 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '#');
        java.awt.Stroke stroke8 = lineAndShapeRenderer0.getItemStroke(1, (int) (short) 1, false);
        lineAndShapeRenderer0.setItemLabelAnchorOffset((double) 255);
        java.awt.Stroke stroke11 = lineAndShapeRenderer0.getBaseStroke();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier0 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke1 = defaultDrawingSupplier0.getNextOutlineStroke();
        java.awt.Stroke stroke2 = defaultDrawingSupplier0.getNextStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        int int4 = categoryPlot0.getDatasetCount();
        categoryPlot0.setCrosshairDatasetIndex((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace4);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer8 = categoryPlot0.getRenderer((-32640));
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(categoryItemRenderer8);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getBaseCreateEntities();
        boolean boolean5 = lineAndShapeRenderer0.getUseFillPaint();
        org.jfree.chart.LegendItem legendItem8 = lineAndShapeRenderer0.getLegendItem((int) (short) 10, 192);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(legendItem8);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.awt.Color color0 = java.awt.Color.BLACK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        categoryPlot29.setRangeCrosshairVisible(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean47 = lineAndShapeRenderer44.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer44.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color50 = java.awt.Color.darkGray;
        lineAndShapeRenderer44.setBaseOutlinePaint((java.awt.Paint) color50, false);
        categoryPlot29.setOutlinePaint((java.awt.Paint) color50);
        org.jfree.chart.axis.AxisSpace axisSpace54 = categoryPlot29.getFixedRangeAxisSpace();
        categoryPlot29.setNoDataMessage("UnitType.ABSOLUTE");
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNull(axisSpace54);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier20 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke21 = defaultDrawingSupplier20.getNextOutlineStroke();
        categoryPlot19.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier20, true);
        java.awt.Paint paint24 = defaultDrawingSupplier20.getNextPaint();
        java.awt.Shape shape25 = defaultDrawingSupplier20.getNextShape();
        java.awt.Stroke stroke26 = defaultDrawingSupplier20.getNextOutlineStroke();
        categoryPlot2.setDomainGridlineStroke(stroke26);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(stroke26);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        java.awt.Stroke stroke43 = lineAndShapeRenderer20.lookupSeriesStroke(0);
        java.awt.Color color44 = org.jfree.chart.ChartColor.DARK_CYAN;
        lineAndShapeRenderer20.setBaseOutlinePaint((java.awt.Paint) color44, true);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color44);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextOutlineStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        lineAndShapeRenderer5.drawRangeMarker(graphics2D6, categoryPlot7, valueAxis11, marker12, rectangle2D13);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot7.getDomainMarkers(layer15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot7.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.Marker marker26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        lineAndShapeRenderer19.drawRangeMarker(graphics2D20, categoryPlot21, valueAxis25, marker26, rectangle2D27);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot21.getDomainMarkers(layer29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo33, point2D34);
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace36);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean42 = lineAndShapeRenderer39.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer39.setPlot(categoryPlot43);
        categoryPlot21.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer39);
        barRenderer17.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot21);
        java.util.List list47 = categoryPlot21.getCategories();
        boolean boolean48 = categoryPlot21.isDomainCrosshairVisible();
        java.awt.Paint paint49 = categoryPlot21.getRangeMinorGridlinePaint();
        boolean boolean50 = defaultDrawingSupplier1.equals((java.lang.Object) categoryPlot21);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent51 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot21);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNull(list47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.lang.Boolean boolean6 = lineAndShapeRenderer3.getSeriesShapesFilled(100);
        lineAndShapeRenderer3.setUseOutlinePaint(false);
        lineAndShapeRenderer3.setItemMargin(0.0d);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(boolean6);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint4 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '#');
        boolean boolean5 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Stroke stroke6 = lineAndShapeRenderer0.getBaseOutlineStroke();
        boolean boolean7 = lineAndShapeRenderer0.getBaseLinesVisible();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        barRenderer0.setMaximumBarWidth((double) 0.0f);
        java.awt.Paint paint12 = barRenderer0.getShadowPaint();
        double double13 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer0.setSeriesItemLabelGenerator(35, categoryItemLabelGenerator15);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset17 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        float float19 = categoryAxis18.getTickMarkOutsideLength();
        categoryAxis18.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryAxis18.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke26 = lineAndShapeRenderer24.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint28 = lineAndShapeRenderer24.lookupLegendTextPaint((int) '#');
        boolean boolean29 = lineAndShapeRenderer24.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color33 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot32.setNoDataMessagePaint((java.awt.Paint) color33);
        org.jfree.chart.util.RectangleInsets rectangleInsets35 = categoryPlot32.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis36 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray37 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis36 };
        categoryPlot32.setDomainAxes(categoryAxisArray37);
        java.awt.Stroke stroke39 = categoryPlot32.getDomainCrosshairStroke();
        categoryPlot31.setDomainGridlineStroke(stroke39);
        lineAndShapeRenderer24.setSeriesOutlineStroke((int) ' ', stroke39, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset17, categoryAxis18, valueAxis23, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer24);
        int int45 = defaultCategoryDataset17.getRowIndex((java.lang.Comparable) (-4194304));
        java.lang.Object obj46 = defaultCategoryDataset17.clone();
        org.jfree.data.Range range47 = barRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset17);
        java.awt.Color color48 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        barRenderer0.setShadowPaint((java.awt.Paint) color48);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(paint28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(color33);
        org.junit.Assert.assertNotNull(rectangleInsets35);
        org.junit.Assert.assertNotNull(categoryAxisArray37);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + (-1) + "'", int45 == (-1));
        org.junit.Assert.assertNotNull(obj46);
        org.junit.Assert.assertNull(range47);
        org.junit.Assert.assertNotNull(color48);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint4 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '#');
        boolean boolean5 = lineAndShapeRenderer0.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot8.setNoDataMessagePaint((java.awt.Paint) color9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot8.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray13 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis12 };
        categoryPlot8.setDomainAxes(categoryAxisArray13);
        java.awt.Stroke stroke15 = categoryPlot8.getDomainCrosshairStroke();
        categoryPlot7.setDomainGridlineStroke(stroke15);
        lineAndShapeRenderer0.setSeriesOutlineStroke((int) ' ', stroke15, true);
        java.lang.Boolean boolean20 = lineAndShapeRenderer0.getSeriesShapesVisible((int) 'a');
        boolean boolean21 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryAxisArray13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(boolean20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle(100.0d);
        java.awt.Font font4 = categoryAxis0.getTickLabelFont((java.lang.Comparable) 100L);
        org.junit.Assert.assertNotNull(font4);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot29.getRangeAxisEdge(100);
        categoryPlot29.setDomainCrosshairVisible(false);
        boolean boolean46 = categoryPlot29.isRangeGridlinesVisible();
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = null;
        try {
            categoryPlot29.addDomainMarker(categoryMarker47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getMinorTickMarkInsideLength();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color3);
        categoryAxis0.setTickMarkInsideLength((float) (-10289251));
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        lineAndShapeRenderer14.drawRangeMarker(graphics2D15, categoryPlot16, valueAxis20, marker21, rectangle2D22);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot16.getDomainMarkers(layer24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot16.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo28, point2D29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot16.setFixedDomainAxisSpace(axisSpace31);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean37 = lineAndShapeRenderer34.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer34.setPlot(categoryPlot38);
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        barRenderer12.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        java.util.List list42 = categoryPlot16.getCategories();
        boolean boolean43 = categoryPlot16.isDomainCrosshairVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        categoryPlot44.setDomainAxis(10, categoryAxis46, true);
        categoryPlot44.setDomainCrosshairRowKey((java.lang.Comparable) (-1L));
        categoryPlot16.setParent((org.jfree.chart.plot.Plot) categoryPlot44);
        org.jfree.chart.util.RectangleEdge rectangleEdge53 = categoryPlot16.getDomainAxisEdge((int) (byte) -1);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(list42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleEdge53);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot0.setRangeAxis(valueAxis5);
        categoryPlot0.clearSelection();
        java.awt.Image image8 = categoryPlot0.getBackgroundImage();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getTickLabelInsets();
        float float11 = categoryAxis9.getTickMarkInsideLength();
        categoryAxis9.setLabel("");
        categoryAxis9.setLabel("{0}");
        java.awt.Stroke stroke16 = categoryAxis9.getAxisLineStroke();
        java.awt.Stroke stroke17 = categoryAxis9.getTickMarkStroke();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("");
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke22 = defaultDrawingSupplier21.getNextOutlineStroke();
        categoryPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21, true);
        java.awt.Paint paint25 = defaultDrawingSupplier21.getNextPaint();
        java.awt.Shape shape26 = defaultDrawingSupplier21.getNextShape();
        java.awt.Stroke stroke27 = defaultDrawingSupplier21.getNextOutlineStroke();
        legendItem19.setOutlineStroke(stroke27);
        categoryAxis9.setAxisLineStroke(stroke27);
        categoryPlot0.setDomainCrosshairStroke(stroke27);
        org.junit.Assert.assertNull(image8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(shape26);
        org.junit.Assert.assertNotNull(stroke27);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot0.setRangeAxis(valueAxis5);
        categoryPlot0.setRangeCrosshairValue((double) '#');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset9 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        float float11 = categoryAxis10.getTickMarkOutsideLength();
        categoryAxis10.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis10.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke18 = lineAndShapeRenderer16.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint20 = lineAndShapeRenderer16.lookupLegendTextPaint((int) '#');
        boolean boolean21 = lineAndShapeRenderer16.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color25 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot24.setNoDataMessagePaint((java.awt.Paint) color25);
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryPlot24.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis28 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray29 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis28 };
        categoryPlot24.setDomainAxes(categoryAxisArray29);
        java.awt.Stroke stroke31 = categoryPlot24.getDomainCrosshairStroke();
        categoryPlot23.setDomainGridlineStroke(stroke31);
        lineAndShapeRenderer16.setSeriesOutlineStroke((int) ' ', stroke31, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9, categoryAxis10, valueAxis15, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer16);
        int int37 = defaultCategoryDataset9.getRowIndex((java.lang.Comparable) (-4194304));
        defaultCategoryDataset9.clear();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = categoryPlot0.getRendererForDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset9);
        java.util.List list40 = categoryPlot0.getCategories();
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 2.0f + "'", float11 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(paint20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(categoryAxisArray29);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertNull(categoryItemRenderer39);
        org.junit.Assert.assertNull(list40);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot29.getRangeAxisEdge(100);
        categoryPlot29.setDomainCrosshairVisible(false);
        boolean boolean46 = categoryPlot29.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        categoryPlot29.panDomainAxes((double) (-32640), plotRenderingInfo48, point2D49);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        categoryPlot29.panDomainAxes((double) (-1.0f), plotRenderingInfo52, point2D53);
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color56 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot55.setNoDataMessagePaint((java.awt.Paint) color56);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer58 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean61 = lineAndShapeRenderer58.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation62 = null;
        boolean boolean63 = lineAndShapeRenderer58.removeAnnotation(categoryAnnotation62);
        boolean boolean64 = categoryPlot55.equals((java.lang.Object) boolean63);
        categoryPlot29.setParent((org.jfree.chart.plot.Plot) categoryPlot55);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot0.setRangeAxis(valueAxis5);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot0.getAxisOffset();
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color6 = java.awt.Color.darkGray;
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color6, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = lineAndShapeRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        lineAndShapeRenderer14.drawRangeMarker(graphics2D15, categoryPlot16, valueAxis20, marker21, rectangle2D22);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot16.getDomainMarkers(layer24);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer26);
        boolean boolean29 = barRenderer26.isSeriesVisible((int) (short) -1);
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape33 = legendItem32.getLine();
        barRenderer26.setSeriesShape(0, shape33, false);
        legendItem13.setShape(shape33);
        lineAndShapeRenderer0.setSeriesShape(15, shape33, false);
        lineAndShapeRenderer0.setItemMargin(0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(shape33);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 32.0f);
        double double4 = rectangleInsets0.trimWidth(4.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.0d + "'", double4 == 4.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.data.general.Dataset dataset3 = legendItem1.getDataset();
        java.awt.Stroke stroke4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        legendItem1.setOutlineStroke(stroke4);
        java.lang.String str6 = legendItem1.getURLText();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNull(dataset3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(str6);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        java.awt.Color color10 = java.awt.Color.WHITE;
        categoryPlot2.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot2.panRangeAxes(0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color17 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot16.setNoDataMessagePaint((java.awt.Paint) color17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int20 = categoryPlot16.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer19);
        org.jfree.chart.axis.AxisSpace axisSpace21 = null;
        categoryPlot16.setFixedRangeAxisSpace(axisSpace21);
        java.awt.Stroke stroke23 = categoryPlot16.getRangeCrosshairStroke();
        categoryPlot2.setDomainGridlineStroke(stroke23);
        categoryPlot2.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = categoryPlot2.getOrientation();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(plotOrientation27);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setLabel("");
        categoryAxis0.setLabelURL("");
        float float7 = categoryAxis0.getTickMarkOutsideLength();
        categoryAxis0.setVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = shapeList0.getShape(0);
        org.junit.Assert.assertNull(shape2);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        java.awt.Paint paint3 = categoryAxis0.getLabelPaint();
        categoryAxis0.setFixedDimension((double) 0);
        boolean boolean6 = categoryAxis0.isTickMarksVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot7.setNoDataMessagePaint((java.awt.Paint) color8);
        categoryPlot7.setCrosshairDatasetIndex((int) (byte) 0, false);
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot7.zoomRangeAxes((double) (-1), (double) 10.0f, plotRenderingInfo17, point2D18);
        categoryPlot7.setDomainGridlinesVisible(false);
        categoryPlot7.clearAnnotations();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int25 = color24.getTransparency();
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color24);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor27 = org.jfree.chart.axis.CategoryAnchor.MIDDLE;
        java.awt.geom.Rectangle2D rectangle2D30 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot33.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.plot.Marker marker38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        lineAndShapeRenderer31.drawRangeMarker(graphics2D32, categoryPlot33, valueAxis37, marker38, rectangle2D39);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = categoryPlot33.getDomainMarkers(layer41);
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot33.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer43);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer45 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot47.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis51 = null;
        org.jfree.chart.plot.Marker marker52 = null;
        java.awt.geom.Rectangle2D rectangle2D53 = null;
        lineAndShapeRenderer45.drawRangeMarker(graphics2D46, categoryPlot47, valueAxis51, marker52, rectangle2D53);
        org.jfree.chart.util.Layer layer55 = null;
        java.util.Collection collection56 = categoryPlot47.getDomainMarkers(layer55);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo59 = null;
        java.awt.geom.Point2D point2D60 = null;
        categoryPlot47.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo59, point2D60);
        org.jfree.chart.axis.AxisSpace axisSpace62 = null;
        categoryPlot47.setFixedDomainAxisSpace(axisSpace62);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer65 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean68 = lineAndShapeRenderer65.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot69 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer65.setPlot(categoryPlot69);
        categoryPlot47.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer65);
        barRenderer43.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot47);
        java.util.List list73 = categoryPlot47.getCategories();
        org.jfree.chart.util.RectangleEdge rectangleEdge75 = categoryPlot47.getRangeAxisEdge((int) (byte) -1);
        try {
            double double76 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor27, 100, (-4194304), rectangle2D30, rectangleEdge75);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 100");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1 + "'", int25 == 1);
        org.junit.Assert.assertNotNull(categoryAnchor27);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertNull(collection56);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNull(list73);
        org.junit.Assert.assertNotNull(rectangleEdge75);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double4 = rectangleInsets2.calculateBottomOutset((double) 0.5f);
        org.jfree.chart.util.UnitType unitType5 = rectangleInsets2.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType5, (double) 255, 0.0d, (double) 10.0f, 0.0d);
        double double12 = rectangleInsets10.calculateTopOutset((double) 'a');
        categoryAxis0.setLabelInsets(rectangleInsets10, true);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 3.0d + "'", double4 == 3.0d);
        org.junit.Assert.assertNotNull(unitType5);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 255.0d + "'", double12 == 255.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemLabelPaint((int) (byte) 10, (int) (byte) -1, false);
        int int9 = lineAndShapeRenderer0.getPassCount();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        java.awt.Font font12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        lineAndShapeRenderer0.setBaseItemLabelFont(font12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(font12);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getTickMarkOutsideLength();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.Marker marker9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        lineAndShapeRenderer2.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis8, marker9, rectangle2D10);
        org.jfree.chart.axis.AxisLocation axisLocation13 = null;
        categoryPlot4.setRangeAxisLocation((int) (short) 100, axisLocation13, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke19 = defaultDrawingSupplier18.getNextOutlineStroke();
        categoryPlot17.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier18, true);
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot17.getDomainAxisLocation(1);
        categoryPlot4.setDomainAxisLocation(0, axisLocation23);
        org.jfree.chart.axis.ValueAxis valueAxis26 = categoryPlot4.getRangeAxisForDataset(10);
        categoryAxis0.removeChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot4);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0f + "'", float1 == 2.0f);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertNull(valueAxis26);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextOutlineStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1, true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation(1);
        categoryPlot0.setForegroundAlpha((float) (short) 100);
        org.jfree.chart.axis.AxisSpace axisSpace9 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace9);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        objectList0.clear();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        lineAndShapeRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis10, marker11, rectangle2D12);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot6.getDomainMarkers(layer14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer16.getPositiveItemLabelPositionFallback();
        org.jfree.chart.plot.DrawingSupplier drawingSupplier19 = barRenderer16.getDrawingSupplier();
        barRenderer16.setDrawBarOutline(true);
        double double22 = barRenderer16.getItemLabelAnchorOffset();
        objectList0.set((int) (byte) 1, (java.lang.Object) double22);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(drawingSupplier19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 2.0d + "'", double22 == 2.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(false, false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer12.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        barRenderer12.setSeriesURLGenerator(10, categoryURLGenerator19, false);
        double double22 = barRenderer12.getBase();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent23 = null;
        barRenderer12.notifyListeners(rendererChangeEvent23);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot28.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.plot.Marker marker33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        lineAndShapeRenderer26.drawRangeMarker(graphics2D27, categoryPlot28, valueAxis32, marker33, rectangle2D34);
        org.jfree.chart.util.Layer layer36 = null;
        java.util.Collection collection37 = categoryPlot28.getDomainMarkers(layer36);
        org.jfree.chart.renderer.category.BarRenderer barRenderer38 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot28.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer38);
        boolean boolean41 = barRenderer38.isSeriesVisible((int) (short) -1);
        org.jfree.chart.LegendItem legendItem44 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape45 = legendItem44.getLine();
        barRenderer38.setSeriesShape(0, shape45, false);
        try {
            barRenderer12.setSeriesShape((-1), shape45);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNull(collection37);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(shape45);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        try {
            keyedObjects2D0.removeColumn((-32640));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -32640");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedRangeAxisSpace();
        boolean boolean2 = categoryPlot0.isRangePannable();
        java.awt.Paint paint3 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.plot.Marker marker4 = null;
        org.jfree.chart.util.Layer layer5 = null;
        try {
            boolean boolean6 = categoryPlot0.removeRangeMarker(marker4, layer5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape2 = legendItem1.getLine();
        java.awt.Paint paint3 = legendItem1.getLinePaint();
        java.awt.Paint paint4 = legendItem1.getFillPaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint4 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '#');
        java.awt.Stroke stroke8 = lineAndShapeRenderer0.getItemStroke(1, (int) (short) 1, false);
        lineAndShapeRenderer0.setItemLabelAnchorOffset((double) 255);
        lineAndShapeRenderer0.setDrawOutlines(false);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace15 = categoryPlot14.getFixedRangeAxisSpace();
        boolean boolean16 = categoryPlot14.isRangePannable();
        java.awt.Paint paint17 = categoryPlot14.getRangeMinorGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer19 = categoryPlot14.getRendererForDataset(categoryDataset18);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot14.zoomDomainAxes((double) (short) 1, (double) (short) 1, plotRenderingInfo22, point2D23);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryAxis25.getTickLabelInsets();
        float float27 = categoryAxis25.getMinorTickMarkInsideLength();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis25.setAxisLinePaint((java.awt.Paint) color28);
        int int30 = categoryAxis25.getMaximumCategoryLabelLines();
        org.jfree.chart.plot.CategoryMarker categoryMarker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        try {
            lineAndShapeRenderer0.drawDomainMarker(graphics2D13, categoryPlot14, categoryAxis25, categoryMarker31, rectangle2D32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(axisSpace15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(paint17);
        org.junit.Assert.assertNull(categoryItemRenderer19);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertTrue("'" + float27 + "' != '" + 0.0f + "'", float27 == 0.0f);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1 + "'", int30 == 1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        boolean boolean2 = datasetRenderingOrder0.equals((java.lang.Object) 100.0f);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean6 = lineAndShapeRenderer3.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer3.setPlot(categoryPlot7);
        categoryPlot7.setBackgroundImageAlignment((int) (short) 0);
        int int11 = categoryPlot7.getRendererCount();
        boolean boolean12 = datasetRenderingOrder0.equals((java.lang.Object) categoryPlot7);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean1 = renderAttributes0.getDefaultCreateEntity();
        java.awt.Stroke stroke2 = renderAttributes0.getDefaultOutlineStroke();
        org.junit.Assert.assertNull(boolean1);
        org.junit.Assert.assertNull(stroke2);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        lineAndShapeRenderer3.drawRangeMarker(graphics2D4, categoryPlot5, valueAxis9, marker10, rectangle2D11);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot5.getDomainMarkers(layer13);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        lineAndShapeRenderer17.drawRangeMarker(graphics2D18, categoryPlot19, valueAxis23, marker24, rectangle2D25);
        org.jfree.chart.util.Layer layer27 = null;
        java.util.Collection collection28 = categoryPlot19.getDomainMarkers(layer27);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo31 = null;
        java.awt.geom.Point2D point2D32 = null;
        categoryPlot19.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo31, point2D32);
        org.jfree.chart.axis.AxisSpace axisSpace34 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace34);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean40 = lineAndShapeRenderer37.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer37.setPlot(categoryPlot41);
        categoryPlot19.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer37);
        barRenderer15.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot19);
        java.util.List list45 = categoryPlot19.getCategories();
        boolean boolean46 = categoryPlot19.isDomainCrosshairVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis49 = null;
        categoryPlot47.setDomainAxis(10, categoryAxis49, true);
        categoryPlot47.setDomainCrosshairRowKey((java.lang.Comparable) (-1L));
        categoryPlot19.setParent((org.jfree.chart.plot.Plot) categoryPlot47);
        org.jfree.chart.entity.PlotEntity plotEntity56 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot19, "TextAnchor.CENTER");
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNull(collection28);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNull(list45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = lineAndShapeRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator6);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        try {
            java.awt.Color color1 = java.awt.Color.decode("RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        java.awt.Color color4 = java.awt.Color.pink;
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color4, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator7 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator7);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        legendItem1.setSeriesKey((java.lang.Comparable) 10L);
        java.awt.Paint paint5 = legendItem1.getLabelPaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis6.getTickLabelInsets();
        float float8 = categoryAxis6.getTickMarkInsideLength();
        categoryAxis6.setLabel("");
        categoryAxis6.setLabel("{0}");
        java.awt.Stroke stroke13 = categoryAxis6.getAxisLineStroke();
        java.awt.Stroke stroke14 = categoryAxis6.getTickMarkStroke();
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("");
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke19 = defaultDrawingSupplier18.getNextOutlineStroke();
        categoryPlot17.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier18, true);
        java.awt.Paint paint22 = defaultDrawingSupplier18.getNextPaint();
        java.awt.Shape shape23 = defaultDrawingSupplier18.getNextShape();
        java.awt.Stroke stroke24 = defaultDrawingSupplier18.getNextOutlineStroke();
        legendItem16.setOutlineStroke(stroke24);
        categoryAxis6.setAxisLineStroke(stroke24);
        legendItem1.setOutlineStroke(stroke24);
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        double double11 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        try {
            lineAndShapeRenderer0.setSeriesCreateEntities((-1), (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        float float7 = categoryPlot0.getForegroundAlpha();
        java.lang.Comparable comparable8 = null;
        categoryPlot0.setDomainCrosshairColumnKey(comparable8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double12 = rectangleInsets10.calculateBottomOutset((double) 0.5f);
        categoryPlot0.setInsets(rectangleInsets10, true);
        double double16 = rectangleInsets10.trimHeight((double) 32.0f);
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D18 = rectangleInsets10.createOutsetRectangle(rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 26.0d + "'", double16 == 26.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setLabel("");
        categoryAxis0.setAxisLineVisible(true);
        float float7 = categoryAxis0.getMinorTickMarkInsideLength();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        float float9 = categoryAxis8.getTickMarkOutsideLength();
        categoryAxis8.setCategoryMargin((double) 8);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryAxis12.getTickLabelInsets();
        float float14 = categoryAxis12.getTickMarkInsideLength();
        categoryAxis12.setLabel("");
        categoryAxis12.setLabel("{0}");
        java.awt.Font font19 = categoryAxis12.getTickLabelFont();
        categoryAxis8.setLabelFont(font19);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions21 = categoryAxis8.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions21);
        java.awt.Font font23 = categoryAxis0.getTickLabelFont();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.0f + "'", float7 == 0.0f);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 2.0f + "'", float9 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + float14 + "' != '" + 0.0f + "'", float14 == 0.0f);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertNotNull(categoryLabelPositions21);
        org.junit.Assert.assertNotNull(font23);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        boolean boolean12 = lineAndShapeRenderer7.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        java.awt.Stroke stroke22 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot14.setDomainGridlineStroke(stroke22);
        lineAndShapeRenderer7.setSeriesOutlineStroke((int) ' ', stroke22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        int int28 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4194304));
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.setValue(0.0d, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) "TextAnchor.CENTER");
        java.lang.Comparable comparable34 = null;
        try {
            defaultCategoryDataset0.removeValue(comparable34, (java.lang.Comparable) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer12.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        barRenderer12.setSeriesURLGenerator(10, categoryURLGenerator19, false);
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator22 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        barRenderer12.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator22);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator24 = null;
        barRenderer12.setBaseURLGenerator(categoryURLGenerator24, false);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) 0.05d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        barRenderer12.setDrawBarOutline(false);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = legendItem18.getFillPaintTransformer();
        barRenderer12.setGradientPaintTransformer(gradientPaintTransformer19);
        double double21 = barRenderer12.getMinimumBarLength();
        double double22 = barRenderer12.getItemMargin();
        int int23 = barRenderer12.getRowCount();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.2d + "'", double22 == 0.2d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextOutlineStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1, true);
        java.lang.Object obj5 = categoryPlot0.clone();
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color7 = java.awt.Color.WHITE;
        boolean boolean8 = plotOrientation6.equals((java.lang.Object) color7);
        categoryPlot0.setOrientation(plotOrientation6);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot10.setNoDataMessagePaint((java.awt.Paint) color11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot10.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray15 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis14 };
        categoryPlot10.setDomainAxes(categoryAxisArray15);
        org.jfree.chart.util.RectangleInsets rectangleInsets17 = categoryPlot10.getAxisOffset();
        org.jfree.data.category.CategoryDataset categoryDataset18 = null;
        int int19 = categoryPlot10.indexOf(categoryDataset18);
        int int20 = categoryPlot10.getDatasetCount();
        boolean boolean21 = plotOrientation6.equals((java.lang.Object) int20);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNotNull(categoryAxisArray15);
        org.junit.Assert.assertNotNull(rectangleInsets17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int1 = keyedObjects2D0.getRowCount();
        try {
            keyedObjects2D0.removeColumn(15);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 15, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace4);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge();
        java.lang.Comparable comparable7 = categoryPlot0.getDomainCrosshairColumnKey();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(comparable7);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint4 = renderAttributes1.getItemPaint(10, (int) (short) 0);
        java.awt.Paint paint5 = renderAttributes1.getDefaultFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot8.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.plot.Marker marker13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        lineAndShapeRenderer6.drawRangeMarker(graphics2D7, categoryPlot8, valueAxis12, marker13, rectangle2D14);
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot8.setRangeAxisLocation((int) (short) 100, axisLocation17, false);
        java.awt.Color color20 = java.awt.Color.ORANGE;
        java.awt.Color color21 = color20.brighter();
        categoryPlot8.setRangeMinorGridlinePaint((java.awt.Paint) color21);
        renderAttributes1.setDefaultLabelPaint((java.awt.Paint) color21);
        java.awt.Paint paint26 = renderAttributes1.getItemPaint(10, (int) (short) 1);
        java.awt.Color color27 = org.jfree.chart.ChartColor.DARK_GREEN;
        renderAttributes1.setDefaultLabelPaint((java.awt.Paint) color27);
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color27);
        java.lang.Object obj30 = categoryPlot0.clone();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean35 = lineAndShapeRenderer32.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer32.setPlot(categoryPlot36);
        categoryPlot36.setBackgroundImageAlignment((int) (short) 0);
        java.util.List list40 = categoryPlot36.getAnnotations();
        try {
            categoryPlot0.mapDatasetToRangeAxes((int) (short) 0, list40);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Empty list not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(obj30);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(list40);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint2 = lineAndShapeRenderer0.getSeriesPaint((int) (byte) 0);
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getSeriesStroke(1);
        double double5 = lineAndShapeRenderer0.getItemMargin();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition7, false);
        boolean boolean13 = lineAndShapeRenderer0.isItemLabelVisible(255, (int) (short) -1, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke17 = lineAndShapeRenderer15.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint19 = lineAndShapeRenderer15.lookupLegendTextPaint((int) '#');
        boolean boolean20 = lineAndShapeRenderer15.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot23.setNoDataMessagePaint((java.awt.Paint) color24);
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = categoryPlot23.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray28 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis27 };
        categoryPlot23.setDomainAxes(categoryAxisArray28);
        java.awt.Stroke stroke30 = categoryPlot23.getDomainCrosshairStroke();
        categoryPlot22.setDomainGridlineStroke(stroke30);
        lineAndShapeRenderer15.setSeriesOutlineStroke((int) ' ', stroke30, true);
        try {
            lineAndShapeRenderer0.setSeriesStroke((-32640), stroke30, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(rectangleInsets26);
        org.junit.Assert.assertNotNull(categoryAxisArray28);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        lineAndShapeRenderer14.drawRangeMarker(graphics2D15, categoryPlot16, valueAxis20, marker21, rectangle2D22);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot16.getDomainMarkers(layer24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot16.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo28, point2D29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot16.setFixedDomainAxisSpace(axisSpace31);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean37 = lineAndShapeRenderer34.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer34.setPlot(categoryPlot38);
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        barRenderer12.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        java.util.List list42 = categoryPlot16.getCategories();
        java.awt.Stroke stroke43 = categoryPlot16.getRangeMinorGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot16.getDomainAxisEdge((int) (byte) 100);
        try {
            categoryPlot16.zoom((double) 8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(list42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        java.awt.Stroke stroke10 = categoryPlot2.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo12 = null;
        java.awt.geom.Point2D point2D13 = null;
        categoryPlot2.zoomRangeAxes(8.0d, plotRenderingInfo12, point2D13, false);
        int int16 = categoryPlot2.getBackgroundImageAlignment();
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 15 + "'", int16 == 15);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double5 = rectangleInsets3.calculateTopInset((double) 10);
        java.lang.String str6 = rectangleInsets3.toString();
        double double8 = rectangleInsets3.trimWidth(0.0d);
        categoryAxis0.setLabelInsets(rectangleInsets3, true);
        double double11 = categoryAxis0.getLabelAngle();
        boolean boolean12 = categoryAxis0.isTickLabelsVisible();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str6.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-16.0d) + "'", double8 == (-16.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setLabel("");
        categoryAxis0.setLabel("{0}");
        java.awt.Stroke stroke7 = categoryAxis0.getAxisLineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double10 = rectangleInsets8.calculateTopInset((double) 10);
        double double12 = rectangleInsets8.calculateRightInset((double) (short) -1);
        double double14 = rectangleInsets8.calculateTopOutset((double) 8);
        categoryAxis0.setLabelInsets(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.0d + "'", double12 == 8.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 4.0d + "'", double14 == 4.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getBaseCreateEntities();
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape7 = legendItem6.getLine();
        lineAndShapeRenderer0.setBaseLegendShape(shape7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = lineAndShapeRenderer0.getBasePositiveItemLabelPosition();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(itemLabelPosition9);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setLabel("");
        categoryAxis0.setLabelURL("");
        java.awt.Font font8 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        categoryAxis0.setTickLabelFont((java.lang.Comparable) 10, font8);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        boolean boolean4 = categoryPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) (short) 100, plotRenderingInfo6, point2D7, true);
        categoryPlot0.clearRangeMarkers();
        categoryPlot0.mapDatasetToDomainAxis(10, (int) (byte) 1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke3 = defaultDrawingSupplier2.getNextOutlineStroke();
        categoryPlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier2, true);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot1.getDomainAxisLocation(1);
        categoryPlot1.setForegroundAlpha((float) (short) 100);
        org.jfree.chart.entity.PlotEntity plotEntity11 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "hi!");
        java.lang.Object obj12 = null;
        boolean boolean13 = plotEntity11.equals(obj12);
        java.lang.String str14 = plotEntity11.toString();
        java.awt.Shape shape15 = null;
        try {
            plotEntity11.setArea(shape15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "PlotEntity: tooltip = hi!" + "'", str14.equals("PlotEntity: tooltip = hi!"));
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.clear();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        float float3 = categoryAxis2.getTickMarkOutsideLength();
        categoryAxis2.setCategoryMargin((double) 8);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot6.setNoDataMessagePaint((java.awt.Paint) color7);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int10 = categoryPlot6.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color13 = java.awt.Color.WHITE;
        boolean boolean14 = plotOrientation12.equals((java.lang.Object) color13);
        int int15 = color13.getBlue();
        lineAndShapeRenderer9.setSeriesFillPaint(1, (java.awt.Paint) color13);
        categoryAxis2.setTickMarkPaint((java.awt.Paint) color13);
        java.awt.Stroke stroke18 = categoryAxis2.getTickMarkStroke();
        keyedObjects2D0.addObject((java.lang.Object) stroke18, (java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (java.lang.Comparable) 32.0f);
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) (-1.0d));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (-1.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setLabelAngle(100.0d);
        categoryPlot0.setDomainAxis((int) (short) 100, categoryAxis5, true);
        categoryAxis5.configure();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color2);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color2, (float) ' ', (int) (byte) 0, (double) (-1));
        java.awt.Color color8 = defaultShadowGenerator7.getShadowColor();
        float float9 = defaultShadowGenerator7.getShadowOpacity();
        java.awt.image.BufferedImage bufferedImage10 = null;
        try {
            java.awt.image.BufferedImage bufferedImage11 = defaultShadowGenerator7.createDropShadow(bufferedImage10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 32.0f + "'", float9 == 32.0f);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        java.awt.Color color4 = java.awt.Color.pink;
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color4, false);
        java.awt.Paint paint8 = lineAndShapeRenderer0.lookupLegendTextPaint((int) 'a');
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNull(paint8);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot0.setRangeAxis(valueAxis5);
        categoryPlot0.setRangeCrosshairValue((double) '#');
        int int9 = categoryPlot0.getDomainAxisCount();
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 11 + "'", int9 == 11);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        lineAndShapeRenderer14.drawRangeMarker(graphics2D15, categoryPlot16, valueAxis20, marker21, rectangle2D22);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot16.getDomainMarkers(layer24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot16.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo28, point2D29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot16.setFixedDomainAxisSpace(axisSpace31);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean37 = lineAndShapeRenderer34.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer34.setPlot(categoryPlot38);
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        barRenderer12.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        java.util.List list42 = categoryPlot16.getCategories();
        boolean boolean43 = categoryPlot16.isDomainCrosshairVisible();
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = categoryAxis44.getTickLabelInsets();
        float float46 = categoryAxis44.getTickMarkInsideLength();
        java.awt.Paint paint47 = categoryAxis44.getLabelPaint();
        org.jfree.chart.plot.Plot plot48 = categoryAxis44.getPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color50 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot49.setNoDataMessagePaint((java.awt.Paint) color50);
        org.jfree.chart.util.RectangleInsets rectangleInsets52 = categoryPlot49.getInsets();
        double double54 = rectangleInsets52.calculateTopOutset((double) 1.0f);
        double double56 = rectangleInsets52.calculateLeftInset(100.0d);
        categoryAxis44.setTickLabelInsets(rectangleInsets52);
        categoryAxis44.setCategoryMargin((double) (short) -1);
        categoryPlot16.setDomainAxis(categoryAxis44);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(list42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 0.0f + "'", float46 == 0.0f);
        org.junit.Assert.assertNotNull(paint47);
        org.junit.Assert.assertNull(plot48);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNotNull(rectangleInsets52);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 4.0d + "'", double54 == 4.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 8.0d + "'", double56 == 8.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.lang.Object obj5 = categoryPlot0.clone();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getRangeMarkers(layer6);
        java.awt.Stroke stroke8 = categoryPlot0.getOutlineStroke();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = categoryAxis9.getTickLabelInsets();
        float float11 = categoryAxis9.getTickMarkInsideLength();
        categoryAxis9.setLabel("");
        categoryAxis9.setAxisLineVisible(true);
        float float16 = categoryAxis9.getMinorTickMarkInsideLength();
        org.jfree.chart.plot.Plot plot17 = categoryAxis9.getPlot();
        java.awt.Stroke stroke18 = categoryAxis9.getTickMarkStroke();
        categoryPlot0.setRangeGridlineStroke(stroke18);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.0f + "'", float16 == 0.0f);
        org.junit.Assert.assertNull(plot17);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle(100.0d);
        double double3 = categoryAxis0.getLabelAngle();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        categoryPlot0.clearRangeAxes();
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean11 = categoryPlot0.removeDomainMarker((int) (short) 10, marker9, layer10);
        int int12 = categoryPlot0.getWeight();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        try {
            categoryPlot0.drawBackground(graphics2D13, rectangle2D14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        barRenderer12.setAutoPopulateSeriesStroke(true);
        boolean boolean18 = barRenderer12.getDataBoundsIncludesVisibleSeriesOnly();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator20 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ChartEntity: tooltip = AxisLocation.TOP_OR_RIGHT");
        barRenderer12.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator20);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setLabelAngle(100.0d);
        categoryPlot0.setDomainAxis((int) (short) 100, categoryAxis5, true);
        java.awt.Image image10 = categoryPlot0.getBackgroundImage();
        categoryPlot0.setNotify(false);
        categoryPlot0.setRangeCrosshairValue((-16.0d), true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(image10);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color2);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color2, (float) ' ', (int) (byte) 0, (double) (-1));
        java.awt.Color color8 = defaultShadowGenerator7.getShadowColor();
        java.awt.Color color9 = defaultShadowGenerator7.getShadowColor();
        float float10 = defaultShadowGenerator7.getShadowOpacity();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 32.0f + "'", float10 == 32.0f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) (short) 10);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color2);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color2, (float) ' ', (int) (byte) 0, (double) (-1));
        int int8 = defaultShadowGenerator7.calculateOffsetX();
        int int9 = defaultShadowGenerator7.getShadowSize();
        float float10 = defaultShadowGenerator7.getShadowOpacity();
        float float11 = defaultShadowGenerator7.getShadowOpacity();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-35) + "'", int8 == (-35));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 32.0f + "'", float10 == 32.0f);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 32.0f + "'", float11 == 32.0f);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean1 = lineAndShapeRenderer0.getBaseSeriesVisible();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        legendItem1.setSeriesKey((java.lang.Comparable) 10L);
        org.jfree.data.general.Dataset dataset5 = legendItem1.getDataset();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNull(dataset5);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        float float3 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setLabel("");
        categoryAxis1.setLabel("{0}");
        java.awt.Stroke stroke8 = categoryAxis1.getAxisLineStroke();
        boolean boolean9 = color0.equals((java.lang.Object) categoryAxis1);
        int int10 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 192 + "'", int10 == 192);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 100.0d);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent3 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 100.0d);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent3.getType();
        chartChangeEvent1.setType(chartChangeEventType4);
        java.lang.String str6 = chartChangeEventType4.toString();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        int int11 = categoryPlot7.getDatasetCount();
        float float12 = categoryPlot7.getForegroundAlpha();
        boolean boolean13 = chartChangeEventType4.equals((java.lang.Object) categoryPlot7);
        org.junit.Assert.assertNotNull(chartChangeEventType4);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ChartChangeEventType.GENERAL" + "'", str6.equals("ChartChangeEventType.GENERAL"));
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        double double5 = rectangleInsets3.calculateTopOutset((double) 1.0f);
        double double7 = rectangleInsets3.calculateTopOutset((double) 100.0f);
        double double9 = rectangleInsets3.calculateRightOutset(0.05d);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 8.0d + "'", double9 == 8.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 100.0d);
        java.lang.Object obj2 = chartChangeEvent1.getSource();
        java.lang.Object obj3 = chartChangeEvent1.getSource();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType4 = chartChangeEvent1.getType();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 100.0d + "'", obj2.equals(100.0d));
        org.junit.Assert.assertTrue("'" + obj3 + "' != '" + 100.0d + "'", obj3.equals(100.0d));
        org.junit.Assert.assertNotNull(chartChangeEventType4);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = barRenderer0.getPositiveItemLabelPosition(0, (int) (byte) 10, false);
        org.jfree.chart.text.TextAnchor textAnchor12 = itemLabelPosition11.getRotationAnchor();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color6 = java.awt.Color.darkGray;
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color6, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.Marker marker20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        lineAndShapeRenderer13.drawRangeMarker(graphics2D14, categoryPlot15, valueAxis19, marker20, rectangle2D21);
        org.jfree.chart.util.Layer layer23 = null;
        java.util.Collection collection24 = categoryPlot15.getDomainMarkers(layer23);
        org.jfree.chart.renderer.category.BarRenderer barRenderer25 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot15.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer25);
        boolean boolean28 = barRenderer25.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator29 = barRenderer25.getLegendItemLabelGenerator();
        barRenderer25.setDrawBarOutline(true);
        int int32 = barRenderer25.getColumnCount();
        java.awt.Paint paint36 = barRenderer25.getItemLabelPaint((int) (short) 0, (int) (short) -1, true);
        lineAndShapeRenderer0.setLegendTextPaint(15, paint36);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(collection24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(paint36);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        barRenderer12.setBaseSeriesVisible(true, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean20 = barRenderer19.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint22 = barRenderer19.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = barRenderer19.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = null;
        barRenderer19.setBaseURLGenerator(categoryURLGenerator27);
        barRenderer19.setMaximumBarWidth((double) 0.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = barRenderer19.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        barRenderer12.setNegativeItemLabelPositionFallback(itemLabelPosition32);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNull(categoryItemLabelGenerator26);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean2 = legendItem1.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int7 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean8 = legendItem1.equals((java.lang.Object) categoryPlot3);
        categoryPlot3.mapDatasetToDomainAxis(1, (-32640));
        categoryPlot3.setOutlineVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot3.getInsets();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        lineAndShapeRenderer15.drawRangeMarker(graphics2D16, categoryPlot17, valueAxis21, marker22, rectangle2D23);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot17.getDomainMarkers(layer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot17.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo29, point2D30);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot17.setFixedDomainAxisSpace(axisSpace32);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean38 = lineAndShapeRenderer35.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer35.setPlot(categoryPlot39);
        categoryPlot17.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer35);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot44.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.plot.Marker marker49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        lineAndShapeRenderer42.drawRangeMarker(graphics2D43, categoryPlot44, valueAxis48, marker49, rectangle2D50);
        org.jfree.chart.axis.AxisLocation axisLocation53 = null;
        categoryPlot44.setRangeAxisLocation((int) (short) 100, axisLocation53, false);
        lineAndShapeRenderer35.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot44);
        org.jfree.chart.util.RectangleEdge rectangleEdge58 = categoryPlot44.getRangeAxisEdge(100);
        categoryPlot44.setCrosshairDatasetIndex(100, true);
        org.jfree.chart.axis.AxisLocation axisLocation62 = categoryPlot44.getRangeAxisLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets63 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double65 = rectangleInsets63.calculateTopInset((double) 10);
        double double67 = rectangleInsets63.calculateLeftInset((double) (byte) 100);
        categoryPlot44.setInsets(rectangleInsets63);
        categoryPlot3.setInsets(rectangleInsets63, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(rectangleEdge58);
        org.junit.Assert.assertNotNull(axisLocation62);
        org.junit.Assert.assertNotNull(rectangleInsets63);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 4.0d + "'", double65 == 4.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 8.0d + "'", double67 == 8.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer12.getPositiveItemLabelPositionFallback();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator18 = barRenderer12.getToolTipGenerator(0, (int) (byte) 10, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition19 = barRenderer12.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertNull(categoryToolTipGenerator18);
        org.junit.Assert.assertNull(itemLabelPosition19);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        double double5 = rectangleInsets3.extendHeight((double) (byte) 1);
        double double6 = rectangleInsets3.getTop();
        double double8 = rectangleInsets3.calculateTopOutset((double) (short) 1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 9.0d + "'", double5 == 9.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.0d + "'", double8 == 4.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke7 = defaultDrawingSupplier6.getNextOutlineStroke();
        categoryPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier6, true);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot5.getDomainAxisLocation(1);
        java.lang.String str12 = axisLocation11.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation11, plotOrientation13);
        org.jfree.chart.axis.AxisState axisState15 = null;
        categoryAxis0.drawTickMarks(graphics2D2, 0.05d, rectangle2D4, rectangleEdge14, axisState15);
        int int17 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke18 = categoryAxis0.getTickMarkStroke();
        java.awt.Paint paint20 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) 2.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str12.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 8);
        double double4 = rectangleInsets0.extendHeight((double) (-10289251));
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0289245E7d) + "'", double4 == (-1.0289245E7d));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        java.lang.Boolean boolean5 = barRenderer0.getSeriesVisibleInLegend(100);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = barRenderer0.getSeriesPositiveItemLabelPosition((int) (short) 100);
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getRotationAnchor();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean6 = lineAndShapeRenderer3.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer3.setPlot(categoryPlot7);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator9 = null;
        lineAndShapeRenderer3.setBaseItemLabelGenerator(categoryItemLabelGenerator9, false);
        lineAndShapeRenderer3.setDataBoundsIncludesVisibleSeriesOnly(false);
        java.awt.Paint paint15 = lineAndShapeRenderer3.lookupSeriesOutlinePaint((int) (byte) 10);
        java.awt.Font font19 = lineAndShapeRenderer3.getItemLabelFont((int) (short) -1, (int) (short) 100, false);
        legendItem1.setLabelFont(font19);
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(font19);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = barRenderer12.getLegendItemLabelGenerator();
        barRenderer12.setDrawBarOutline(true);
        int int19 = barRenderer12.getColumnCount();
        java.awt.Paint paint23 = barRenderer12.getItemLabelPaint((int) (short) 0, (int) (short) -1, true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = barRenderer12.getURLGenerator((-4194304), 100, false);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNull(categoryURLGenerator27);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = lineAndShapeRenderer0.getSeriesToolTipGenerator(1);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesLinesVisible((int) (byte) 0);
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.junit.Assert.assertNull(categoryToolTipGenerator2);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint6 = lineAndShapeRenderer0.lookupSeriesOutlinePaint(10);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getBaseCreateEntities();
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape7 = legendItem6.getLine();
        lineAndShapeRenderer0.setBaseLegendShape(shape7);
        java.awt.Font font9 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer0.setBaseItemLabelFont(font9);
        java.awt.Stroke stroke14 = lineAndShapeRenderer0.getItemOutlineStroke(0, 100, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke14);
    }

//    @Test
//    public void test226() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test226");
//        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//        java.awt.Graphics2D graphics2D1 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
//        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
//        org.jfree.chart.plot.Marker marker7 = null;
//        java.awt.geom.Rectangle2D rectangle2D8 = null;
//        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
//        org.jfree.chart.util.Layer layer10 = null;
//        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
//        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
//        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
//        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
//        barRenderer12.setAutoPopulateSeriesStroke(true);
//        boolean boolean18 = barRenderer12.getDataBoundsIncludesVisibleSeriesOnly();
//        boolean boolean19 = barRenderer12.getShadowsVisible();
//        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//        java.awt.Stroke stroke23 = defaultDrawingSupplier22.getNextOutlineStroke();
//        categoryPlot21.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22, true);
//        java.awt.Paint paint26 = defaultDrawingSupplier22.getNextPaint();
//        java.awt.Shape shape27 = defaultDrawingSupplier22.getNextShape();
//        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
//        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        categoryPlot28.setNoDataMessagePaint((java.awt.Paint) color29);
//        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryPlot28.getInsets();
//        org.jfree.chart.axis.AxisSpace axisSpace32 = categoryPlot28.getFixedDomainAxisSpace();
//        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//        java.awt.Graphics2D graphics2D34 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot35.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
//        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
//        org.jfree.chart.plot.Marker marker40 = null;
//        java.awt.geom.Rectangle2D rectangle2D41 = null;
//        lineAndShapeRenderer33.drawRangeMarker(graphics2D34, categoryPlot35, valueAxis39, marker40, rectangle2D41);
//        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier43 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//        java.awt.Stroke stroke44 = defaultDrawingSupplier43.getNextOutlineStroke();
//        categoryPlot35.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier43);
//        categoryPlot28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier43);
//        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisSpace axisSpace48 = categoryPlot47.getFixedRangeAxisSpace();
//        boolean boolean49 = defaultDrawingSupplier43.equals((java.lang.Object) categoryPlot47);
//        categoryPlot47.clearRangeAxes();
//        org.jfree.chart.entity.PlotEntity plotEntity53 = new org.jfree.chart.entity.PlotEntity(shape27, (org.jfree.chart.plot.Plot) categoryPlot47, "ChartChangeEventType.GENERAL", "GradientPaintTransformType.CENTER_VERTICAL");
//        barRenderer12.setSeriesShape(10, shape27, true);
//        java.awt.Paint paint56 = barRenderer12.getBaseLegendTextPaint();
//        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator57 = null;
//        barRenderer12.setBaseItemLabelGenerator(categoryItemLabelGenerator57);
//        org.junit.Assert.assertNull(collection11);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(stroke23);
//        org.junit.Assert.assertNotNull(paint26);
//        org.junit.Assert.assertNotNull(shape27);
//        org.junit.Assert.assertNotNull(color29);
//        org.junit.Assert.assertNotNull(rectangleInsets31);
//        org.junit.Assert.assertNull(axisSpace32);
//        org.junit.Assert.assertNotNull(stroke44);
//        org.junit.Assert.assertNull(axisSpace48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNull(paint56);
//    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint4 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '#');
        java.awt.Stroke stroke8 = lineAndShapeRenderer0.getItemStroke(1, (int) (short) 1, false);
        lineAndShapeRenderer0.setItemLabelAnchorOffset((double) 255);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = lineAndShapeRenderer0.getPositiveItemLabelPosition((-10289251), (int) (short) 10, false);
        lineAndShapeRenderer0.setSeriesShapesVisible((int) (byte) 1, false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(itemLabelPosition14);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean1 = renderAttributes0.getDefaultCreateEntity();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) false);
        java.awt.Shape shape4 = renderAttributes0.getDefaultShape();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color6 = java.awt.Color.WHITE;
        boolean boolean7 = plotOrientation5.equals((java.lang.Object) color6);
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color6);
        java.awt.Shape shape10 = renderAttributes0.getSeriesShape(255);
        java.awt.Font font11 = renderAttributes0.getDefaultLabelFont();
        org.junit.Assert.assertNull(boolean1);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNull(font11);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) 0.5f);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) 255, 0.0d, (double) 10.0f, 0.0d);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent9 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertNotNull(unitType3);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        barRenderer0.setMaximumBarWidth((double) 0.0f);
        java.awt.Paint paint12 = barRenderer0.getShadowPaint();
        double double13 = barRenderer0.getMinimumBarLength();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer0.setSeriesItemLabelGenerator(35, categoryItemLabelGenerator15);
        barRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        try {
            keyedObjects2D0.removeColumn((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 35, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        boolean boolean12 = lineAndShapeRenderer7.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        java.awt.Stroke stroke22 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot14.setDomainGridlineStroke(stroke22);
        lineAndShapeRenderer7.setSeriesOutlineStroke((int) ' ', stroke22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        categoryPlot26.mapDatasetToDomainAxis((int) (byte) 100, 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) true);
        java.awt.Stroke stroke4 = renderAttributes0.getSeriesStroke((-1));
        java.awt.Paint paint7 = renderAttributes0.getItemOutlinePaint(1, (int) (byte) 1);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertNull(paint7);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.util.ObjectList objectList5 = new org.jfree.chart.util.ObjectList((int) 'a');
        objectList5.clear();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot8.setNoDataMessagePaint((java.awt.Paint) color9);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int12 = categoryPlot8.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer11);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color15 = java.awt.Color.WHITE;
        boolean boolean16 = plotOrientation14.equals((java.lang.Object) color15);
        int int17 = color15.getBlue();
        lineAndShapeRenderer11.setSeriesFillPaint(1, (java.awt.Paint) color15);
        org.jfree.chart.plot.PlotOrientation plotOrientation20 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color21 = java.awt.Color.WHITE;
        boolean boolean22 = plotOrientation20.equals((java.lang.Object) color21);
        int int23 = color21.getBlue();
        lineAndShapeRenderer11.setSeriesOutlinePaint(0, (java.awt.Paint) color21, false);
        objectList5.set((int) 'a', (java.lang.Object) lineAndShapeRenderer11);
        java.awt.Shape shape30 = lineAndShapeRenderer11.getItemShape((int) (short) 0, (-4194304), false);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot31.setNoDataMessagePaint((java.awt.Paint) color32);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int35 = categoryPlot31.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        org.jfree.chart.plot.PlotOrientation plotOrientation37 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color38 = java.awt.Color.WHITE;
        boolean boolean39 = plotOrientation37.equals((java.lang.Object) color38);
        int int40 = color38.getBlue();
        lineAndShapeRenderer34.setSeriesFillPaint(1, (java.awt.Paint) color38);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer43 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot45.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis49 = null;
        org.jfree.chart.plot.Marker marker50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        lineAndShapeRenderer43.drawRangeMarker(graphics2D44, categoryPlot45, valueAxis49, marker50, rectangle2D51);
        org.jfree.chart.util.Layer layer53 = null;
        java.util.Collection collection54 = categoryPlot45.getDomainMarkers(layer53);
        org.jfree.chart.renderer.category.BarRenderer barRenderer55 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot45.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer55);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition57 = barRenderer55.getPositiveItemLabelPositionFallback();
        java.awt.Color color59 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        barRenderer55.setSeriesPaint((int) (short) 1, (java.awt.Paint) color59, false);
        lineAndShapeRenderer34.setSeriesFillPaint((int) (short) 1, (java.awt.Paint) color59, true);
        org.jfree.chart.LegendItem legendItem65 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer66 = legendItem65.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem68 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape69 = legendItem68.getLine();
        legendItem65.setShape(shape69);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer71 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke73 = lineAndShapeRenderer71.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint75 = lineAndShapeRenderer71.lookupLegendTextPaint((int) '#');
        java.awt.Stroke stroke79 = lineAndShapeRenderer71.getItemStroke(1, (int) (short) 1, false);
        legendItem65.setOutlineStroke(stroke79);
        java.awt.Color color81 = java.awt.Color.RED;
        try {
            org.jfree.chart.LegendItem legendItem82 = new org.jfree.chart.LegendItem(attributedString0, "", "AxisLocation.TOP_OR_RIGHT", "0,0,0,0", shape30, (java.awt.Paint) color59, stroke79, (java.awt.Paint) color81);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 255 + "'", int17 == 255);
        org.junit.Assert.assertNotNull(plotOrientation20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 255 + "'", int23 == 255);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 255 + "'", int40 == 255);
        org.junit.Assert.assertNull(collection54);
        org.junit.Assert.assertNull(itemLabelPosition57);
        org.junit.Assert.assertNotNull(color59);
        org.junit.Assert.assertNotNull(gradientPaintTransformer66);
        org.junit.Assert.assertNotNull(shape69);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNull(paint75);
        org.junit.Assert.assertNotNull(stroke79);
        org.junit.Assert.assertNotNull(color81);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot29.getRangeAxisEdge(100);
        categoryPlot29.setCrosshairDatasetIndex(100, true);
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) "UnitType.ABSOLUTE", false);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        java.awt.Font font0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot29.getRangeAxisEdge(100);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        try {
            int int45 = categoryPlot29.getRangeAxisIndex(valueAxis44);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setLabelAngle(100.0d);
        categoryPlot0.setDomainAxis((int) (short) 100, categoryAxis5, true);
        java.lang.String str10 = categoryAxis5.getLabelToolTip();
        java.lang.String str11 = categoryAxis5.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis5.getLabelInsets();
        categoryAxis5.setUpperMargin((double) 10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        java.awt.Color color4 = java.awt.Color.ORANGE;
        java.awt.Color color5 = color4.brighter();
        java.awt.Color color6 = color5.brighter();
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color6);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        categoryPlot0.setRangeCrosshairValue((double) 4);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot0.getDomainMarkers((-32640), layer13);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(collection14);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.lang.Object obj5 = categoryPlot0.clone();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getRangeMarkers(layer6);
        categoryPlot0.setRangePannable(true);
        categoryPlot0.setNoDataMessage("");
        boolean boolean12 = categoryPlot0.isNotify();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getMinorTickMarkInsideLength();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color3);
        categoryAxis0.setTickMarkInsideLength((float) (-10289251));
        boolean boolean7 = categoryAxis0.isMinorTickMarksVisible();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean14 = categoryPlot2.getDrawSharedDomainAxis();
        categoryPlot2.setBackgroundImageAlignment((-1));
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot2.getRangeAxisLocation();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(axisLocation17);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) (byte) 1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.ABSOLUTE;
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = new org.jfree.chart.util.RectangleInsets(unitType0, (double) (short) -1, 0.0d, (-1.0d), (double) (short) 1);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = new org.jfree.chart.util.RectangleInsets(unitType0, 8.0d, 0.05d, 2.0d, (double) (-1L));
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        java.lang.Object obj1 = keyedObjects2D0.clone();
        try {
            keyedObjects2D0.removeRow((java.lang.Comparable) 8);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (8) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        lineAndShapeRenderer11.drawRangeMarker(graphics2D12, categoryPlot13, valueAxis17, marker18, rectangle2D19);
        java.awt.Color color21 = java.awt.Color.WHITE;
        categoryPlot13.setOutlinePaint((java.awt.Paint) color21);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo24 = null;
        java.awt.geom.Point2D point2D25 = null;
        categoryPlot13.panRangeAxes(0.0d, plotRenderingInfo24, point2D25);
        org.jfree.chart.plot.PlotOrientation plotOrientation27 = categoryPlot13.getOrientation();
        java.awt.Stroke stroke28 = categoryPlot13.getOutlineStroke();
        lineAndShapeRenderer0.setBaseStroke(stroke28);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertNotNull(plotOrientation27);
        org.junit.Assert.assertNotNull(stroke28);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        boolean boolean4 = categoryPlot0.isDomainCrosshairVisible();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent5 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.Stroke stroke7 = categoryPlot0.getDomainCrosshairStroke();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) "RectangleInsets[t=4.0,l=4.0,b=4.0,r=4.0]", true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.plot.Marker marker43 = null;
        org.jfree.chart.util.Layer layer44 = null;
        boolean boolean46 = categoryPlot29.removeDomainMarker((int) (short) 100, marker43, layer44, false);
        org.jfree.chart.plot.Marker marker47 = null;
        org.jfree.chart.util.Layer layer48 = null;
        boolean boolean49 = categoryPlot29.removeDomainMarker(marker47, layer48);
        java.awt.Graphics2D graphics2D50 = null;
        java.awt.geom.Rectangle2D rectangle2D51 = null;
        categoryPlot29.drawBackgroundImage(graphics2D50, rectangle2D51);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean2 = legendItem1.isLineVisible();
        java.awt.Paint paint3 = legendItem1.getLabelPaint();
        boolean boolean4 = legendItem1.isLineVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.axis.AxisSpace axisSpace14 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace14, false);
        java.awt.Paint paint17 = null;
        categoryPlot2.setBackgroundPaint(paint17);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        lineAndShapeRenderer3.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Paint paint8 = lineAndShapeRenderer3.getSeriesOutlinePaint((int) (byte) 0);
        boolean boolean9 = lineAndShapeRenderer3.getBaseSeriesVisible();
        int int10 = lineAndShapeRenderer3.getColumnCount();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getDomainAxisLocation((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke10 = defaultDrawingSupplier9.getNextOutlineStroke();
        categoryPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9, true);
        java.awt.Paint paint13 = defaultDrawingSupplier9.getNextPaint();
        java.awt.Shape shape14 = defaultDrawingSupplier9.getNextShape();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9, false);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace17, false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(shape14);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean1 = renderAttributes0.getDefaultCreateEntity();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) false);
        java.awt.Paint paint5 = renderAttributes0.getSeriesOutlinePaint((int) '#');
        org.jfree.chart.util.ObjectList objectList7 = new org.jfree.chart.util.ObjectList((int) 'a');
        objectList7.clear();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot10.setNoDataMessagePaint((java.awt.Paint) color11);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int14 = categoryPlot10.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer13);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color17 = java.awt.Color.WHITE;
        boolean boolean18 = plotOrientation16.equals((java.lang.Object) color17);
        int int19 = color17.getBlue();
        lineAndShapeRenderer13.setSeriesFillPaint(1, (java.awt.Paint) color17);
        org.jfree.chart.plot.PlotOrientation plotOrientation22 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color23 = java.awt.Color.WHITE;
        boolean boolean24 = plotOrientation22.equals((java.lang.Object) color23);
        int int25 = color23.getBlue();
        lineAndShapeRenderer13.setSeriesOutlinePaint(0, (java.awt.Paint) color23, false);
        objectList7.set((int) 'a', (java.lang.Object) lineAndShapeRenderer13);
        java.awt.Shape shape32 = lineAndShapeRenderer13.getItemShape((int) (short) 0, (-4194304), false);
        renderAttributes0.setDefaultShape(shape32);
        org.junit.Assert.assertNull(boolean1);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + (-1) + "'", int14 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
        org.junit.Assert.assertNotNull(plotOrientation22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 255 + "'", int25 == 255);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        lineAndShapeRenderer0.setSeriesShapesFilled(0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem21 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer22 = legendItem21.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape25 = legendItem24.getLine();
        legendItem21.setShape(shape25);
        org.jfree.chart.entity.ChartEntity chartEntity29 = new org.jfree.chart.entity.ChartEntity(shape25, "AxisLocation.TOP_OR_RIGHT", "hi!");
        java.awt.Shape shape30 = chartEntity29.getArea();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier31 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke32 = defaultDrawingSupplier31.getNextOutlineStroke();
        java.awt.Paint paint33 = null;
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "ItemLabelAnchor.INSIDE9", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", shape30, stroke32, paint33);
        lineAndShapeRenderer0.setSeriesOutlineStroke((int) (byte) 10, stroke32);
        java.awt.Paint paint36 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_PAINT;
        lineAndShapeRenderer0.setBaseLegendTextPaint(paint36);
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.data.Range range39 = lineAndShapeRenderer0.findRangeBounds(categoryDataset38);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(gradientPaintTransformer22);
        org.junit.Assert.assertNotNull(shape25);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertNull(range39);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.lang.Object obj5 = categoryPlot0.clone();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getRangeMarkers(layer6);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        int int10 = categoryPlot0.indexOf(categoryDataset9);
        double double11 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double2 = rectangleInsets0.calculateTopInset((double) 10);
        java.lang.String str3 = rectangleInsets0.toString();
        double double5 = rectangleInsets0.trimWidth(0.0d);
        double double7 = rectangleInsets0.extendWidth(26.0d);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str3.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-16.0d) + "'", double5 == (-16.0d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 42.0d + "'", double7 == 42.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        barRenderer12.setDrawBarOutline(false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator20 = barRenderer12.getItemLabelGenerator((int) (short) 1, (int) (short) 0, false);
        boolean boolean23 = barRenderer12.getItemVisible(2, (int) ' ');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator27 = barRenderer12.getURLGenerator(100, (int) (byte) 100, false);
        barRenderer12.setAutoPopulateSeriesOutlinePaint(true);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNull(categoryItemLabelGenerator20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(categoryURLGenerator27);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        java.util.List list2 = keyedObjects0.getKeys();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(list2);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection0.addAll(legendItemCollection1);
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        float float4 = categoryAxis3.getTickMarkOutsideLength();
        categoryAxis3.setCategoryMargin((double) 8);
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot7.setNoDataMessagePaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int11 = categoryPlot7.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer10);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color14 = java.awt.Color.WHITE;
        boolean boolean15 = plotOrientation13.equals((java.lang.Object) color14);
        int int16 = color14.getBlue();
        lineAndShapeRenderer10.setSeriesFillPaint(1, (java.awt.Paint) color14);
        categoryAxis3.setTickMarkPaint((java.awt.Paint) color14);
        categoryAxis3.setVisible(false);
        boolean boolean21 = legendItemCollection1.equals((java.lang.Object) false);
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("");
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier25 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke26 = defaultDrawingSupplier25.getNextOutlineStroke();
        categoryPlot24.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier25, true);
        java.awt.Paint paint29 = defaultDrawingSupplier25.getNextPaint();
        java.awt.Shape shape30 = defaultDrawingSupplier25.getNextShape();
        java.awt.Stroke stroke31 = defaultDrawingSupplier25.getNextOutlineStroke();
        legendItem23.setOutlineStroke(stroke31);
        java.lang.String str33 = legendItem23.getToolTipText();
        legendItemCollection1.add(legendItem23);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(paint29);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(stroke31);
        org.junit.Assert.assertNull(str33);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.jfree.chart.LegendItem legendItem2 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer3 = legendItem2.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape6 = legendItem5.getLine();
        legendItem2.setShape(shape6);
        org.jfree.chart.entity.ChartEntity chartEntity10 = new org.jfree.chart.entity.ChartEntity(shape6, "AxisLocation.TOP_OR_RIGHT", "hi!");
        java.awt.Shape shape11 = chartEntity10.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot13.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator19 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color14, (float) ' ', (int) (byte) 0, (double) (-1));
        double double20 = defaultShadowGenerator19.getAngle();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot23.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.chart.plot.Marker marker28 = null;
        java.awt.geom.Rectangle2D rectangle2D29 = null;
        lineAndShapeRenderer21.drawRangeMarker(graphics2D22, categoryPlot23, valueAxis27, marker28, rectangle2D29);
        org.jfree.chart.util.Layer layer31 = null;
        java.util.Collection collection32 = categoryPlot23.getDomainMarkers(layer31);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        java.awt.geom.Point2D point2D36 = null;
        categoryPlot23.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo35, point2D36);
        org.jfree.chart.axis.AxisSpace axisSpace38 = null;
        categoryPlot23.setFixedDomainAxisSpace(axisSpace38);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean44 = lineAndShapeRenderer41.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer41.setPlot(categoryPlot45);
        categoryPlot23.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer41);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer48 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D49 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot50.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis54 = null;
        org.jfree.chart.plot.Marker marker55 = null;
        java.awt.geom.Rectangle2D rectangle2D56 = null;
        lineAndShapeRenderer48.drawRangeMarker(graphics2D49, categoryPlot50, valueAxis54, marker55, rectangle2D56);
        org.jfree.chart.axis.AxisLocation axisLocation59 = null;
        categoryPlot50.setRangeAxisLocation((int) (short) 100, axisLocation59, false);
        lineAndShapeRenderer41.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot50);
        org.jfree.chart.util.RectangleEdge rectangleEdge64 = categoryPlot50.getRangeAxisEdge(100);
        categoryPlot50.setDomainCrosshairVisible(false);
        boolean boolean67 = categoryPlot50.isRangeGridlinesVisible();
        boolean boolean68 = defaultShadowGenerator19.equals((java.lang.Object) categoryPlot50);
        org.jfree.chart.entity.PlotEntity plotEntity69 = new org.jfree.chart.entity.PlotEntity(shape11, (org.jfree.chart.plot.Plot) categoryPlot50);
        boolean boolean70 = rectangleInsets0.equals((java.lang.Object) shape11);
        java.awt.geom.Rectangle2D rectangle2D71 = null;
        try {
            rectangleInsets0.trim(rectangle2D71);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertNotNull(gradientPaintTransformer3);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-1.0d) + "'", double20 == (-1.0d));
        org.junit.Assert.assertNull(collection32);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(rectangleEdge64);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + true + "'", boolean67 == true);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer12.getBaseNegativeItemLabelPosition();
        barRenderer12.setShadowYOffset((double) (-1L));
        barRenderer12.setItemLabelAnchorOffset((double) (-1L));
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        boolean boolean22 = barRenderer12.removeAnnotation(categoryAnnotation21);
        barRenderer12.removeAnnotations();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextOutlineStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        lineAndShapeRenderer5.drawRangeMarker(graphics2D6, categoryPlot7, valueAxis11, marker12, rectangle2D13);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot7.getDomainMarkers(layer15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot7.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.Marker marker26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        lineAndShapeRenderer19.drawRangeMarker(graphics2D20, categoryPlot21, valueAxis25, marker26, rectangle2D27);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot21.getDomainMarkers(layer29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo33, point2D34);
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace36);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean42 = lineAndShapeRenderer39.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer39.setPlot(categoryPlot43);
        categoryPlot21.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer39);
        barRenderer17.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot21);
        java.util.List list47 = categoryPlot21.getCategories();
        boolean boolean48 = categoryPlot21.isDomainCrosshairVisible();
        java.awt.Paint paint49 = categoryPlot21.getRangeMinorGridlinePaint();
        boolean boolean50 = defaultDrawingSupplier1.equals((java.lang.Object) categoryPlot21);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor51 = categoryPlot21.getDomainGridlinePosition();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNull(list47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertNotNull(categoryAnchor51);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setUpperMargin((double) (short) 0);
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean8 = renderAttributes7.getDefaultCreateEntity();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        float float10 = categoryAxis9.getTickMarkOutsideLength();
        categoryAxis9.setCategoryMargin((double) 8);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot13.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int17 = categoryPlot13.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer16);
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color20 = java.awt.Color.WHITE;
        boolean boolean21 = plotOrientation19.equals((java.lang.Object) color20);
        int int22 = color20.getBlue();
        lineAndShapeRenderer16.setSeriesFillPaint(1, (java.awt.Paint) color20);
        categoryAxis9.setTickMarkPaint((java.awt.Paint) color20);
        java.awt.Stroke stroke25 = categoryAxis9.getTickMarkStroke();
        renderAttributes7.setDefaultOutlineStroke(stroke25);
        categoryAxis4.setTickMarkStroke(stroke25);
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke25, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D32 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot33.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis37 = null;
        org.jfree.chart.plot.Marker marker38 = null;
        java.awt.geom.Rectangle2D rectangle2D39 = null;
        lineAndShapeRenderer31.drawRangeMarker(graphics2D32, categoryPlot33, valueAxis37, marker38, rectangle2D39);
        org.jfree.chart.util.Layer layer41 = null;
        java.util.Collection collection42 = categoryPlot33.getDomainMarkers(layer41);
        org.jfree.chart.renderer.category.BarRenderer barRenderer43 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot33.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer43);
        boolean boolean46 = barRenderer43.isSeriesVisible((int) (short) -1);
        barRenderer43.setAutoPopulateSeriesStroke(true);
        boolean boolean49 = barRenderer43.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Shape shape51 = barRenderer43.getSeriesShape((int) (short) -1);
        org.jfree.chart.LegendItem legendItem53 = new org.jfree.chart.LegendItem("");
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier55 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke56 = defaultDrawingSupplier55.getNextOutlineStroke();
        categoryPlot54.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier55, true);
        java.awt.Paint paint59 = defaultDrawingSupplier55.getNextPaint();
        java.awt.Shape shape60 = defaultDrawingSupplier55.getNextShape();
        java.awt.Stroke stroke61 = defaultDrawingSupplier55.getNextOutlineStroke();
        legendItem53.setOutlineStroke(stroke61);
        barRenderer43.setBaseStroke(stroke61);
        try {
            lineAndShapeRenderer0.setSeriesOutlineStroke((-32640), stroke61);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNull(collection42);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNull(shape51);
        org.junit.Assert.assertNotNull(stroke56);
        org.junit.Assert.assertNotNull(paint59);
        org.junit.Assert.assertNotNull(shape60);
        org.junit.Assert.assertNotNull(stroke61);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        categoryPlot0.clearRangeAxes();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedRangeAxisSpace();
        boolean boolean2 = categoryPlot0.isRangePannable();
        java.awt.Paint paint3 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRendererForDataset(categoryDataset4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        try {
            categoryPlot0.handleClick((int) ' ', 35, plotRenderingInfo9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(axisSpace6);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setLabelAngle(100.0d);
        categoryPlot0.setDomainAxis((int) (short) 100, categoryAxis5, true);
        java.awt.Stroke stroke10 = categoryPlot0.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getRowIndex((java.lang.Comparable) (-8.0d));
        try {
            keyedObjects2D0.removeObject((java.lang.Comparable) '#', (java.lang.Comparable) 4.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (#) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        categoryPlot2.setBackgroundAlpha((float) 8);
        boolean boolean21 = categoryPlot2.isNotify();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean25 = lineAndShapeRenderer22.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer22.setPlot(categoryPlot26);
        categoryPlot26.setBackgroundImageAlignment((int) (short) 0);
        java.util.List list30 = categoryPlot26.getAnnotations();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot26.getFixedLegendItems();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot26);
        categoryPlot2.notifyListeners(plotChangeEvent32);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType34 = plotChangeEvent32.getType();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNull(legendItemCollection31);
        org.junit.Assert.assertNotNull(chartChangeEventType34);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke3 = defaultDrawingSupplier2.getNextOutlineStroke();
        categoryPlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier2, true);
        java.awt.Paint paint6 = defaultDrawingSupplier2.getNextPaint();
        boolean boolean7 = datasetRenderingOrder0.equals((java.lang.Object) paint6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke10 = defaultDrawingSupplier9.getNextOutlineStroke();
        categoryPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9, true);
        java.awt.Paint paint13 = defaultDrawingSupplier9.getNextPaint();
        java.awt.Shape shape14 = defaultDrawingSupplier9.getNextShape();
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = legendItem16.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape20 = legendItem19.getLine();
        legendItem16.setShape(shape20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke24 = lineAndShapeRenderer22.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint26 = lineAndShapeRenderer22.lookupLegendTextPaint((int) '#');
        java.awt.Stroke stroke30 = lineAndShapeRenderer22.getItemStroke(1, (int) (short) 1, false);
        legendItem16.setOutlineStroke(stroke30);
        java.lang.String str32 = legendItem16.getToolTipText();
        boolean boolean33 = defaultDrawingSupplier9.equals((java.lang.Object) legendItem16);
        boolean boolean34 = datasetRenderingOrder0.equals((java.lang.Object) defaultDrawingSupplier9);
        java.awt.Shape shape35 = defaultDrawingSupplier9.getNextShape();
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color37 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot36.setNoDataMessagePaint((java.awt.Paint) color37);
        org.jfree.chart.util.RectangleInsets rectangleInsets39 = categoryPlot36.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace40 = categoryPlot36.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot43.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis47 = null;
        org.jfree.chart.plot.Marker marker48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        lineAndShapeRenderer41.drawRangeMarker(graphics2D42, categoryPlot43, valueAxis47, marker48, rectangle2D49);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier51 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke52 = defaultDrawingSupplier51.getNextOutlineStroke();
        categoryPlot43.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier51);
        categoryPlot36.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier51);
        org.jfree.chart.plot.CategoryPlot categoryPlot55 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace56 = categoryPlot55.getFixedRangeAxisSpace();
        boolean boolean57 = defaultDrawingSupplier51.equals((java.lang.Object) categoryPlot55);
        org.jfree.data.category.CategoryDataset categoryDataset58 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer59 = categoryPlot55.getRendererForDataset(categoryDataset58);
        org.jfree.chart.entity.PlotEntity plotEntity62 = new org.jfree.chart.entity.PlotEntity(shape35, (org.jfree.chart.plot.Plot) categoryPlot55, "UnitType.ABSOLUTE", "PlotEntity: tooltip = hi!");
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(rectangleInsets39);
        org.junit.Assert.assertNull(axisSpace40);
        org.junit.Assert.assertNotNull(stroke52);
        org.junit.Assert.assertNull(axisSpace56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNull(categoryItemRenderer59);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        boolean boolean5 = categoryPlot0.isRangeMinorGridlinesVisible();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("poly");
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        double double5 = rectangleInsets3.extendHeight((double) (byte) 1);
        double double7 = rectangleInsets3.calculateTopOutset(0.2d);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 9.0d + "'", double5 == 9.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.0d + "'", double7 == 4.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot2.setRangeAxisLocation((int) (short) 100, axisLocation11, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextOutlineStroke();
        categoryPlot15.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16, true);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot15.getDomainAxisLocation(1);
        categoryPlot2.setDomainAxisLocation(0, axisLocation21);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot2.getRangeAxisForDataset(10);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier25 = categoryPlot2.getDrawingSupplier();
        categoryPlot2.setDomainGridlinesVisible(false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis24);
        org.junit.Assert.assertNotNull(drawingSupplier25);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        barRenderer12.setAutoPopulateSeriesStroke(true);
        java.awt.Color color19 = java.awt.Color.pink;
        barRenderer12.setLegendTextPaint((int) (byte) 1, (java.awt.Paint) color19);
        java.awt.Shape shape21 = barRenderer12.getBaseLegendShape();
        java.awt.Font font23 = barRenderer12.getSeriesItemLabelFont(4);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(font23);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 0, false);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) (-1), (double) 10.0f, plotRenderingInfo10, point2D11);
        categoryPlot0.setDomainGridlinesVisible(false);
        categoryPlot0.clearAnnotations();
        categoryPlot0.setNotify(true);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 0, false);
        float float6 = categoryPlot0.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.Marker marker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        lineAndShapeRenderer7.drawRangeMarker(graphics2D8, categoryPlot9, valueAxis13, marker14, rectangle2D15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot9.getDomainMarkers(layer17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19);
        boolean boolean22 = barRenderer19.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = barRenderer19.getLegendItemLabelGenerator();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        lineAndShapeRenderer24.drawRangeMarker(graphics2D25, categoryPlot26, valueAxis30, marker31, rectangle2D32);
        boolean boolean34 = barRenderer19.hasListener((java.util.EventListener) categoryPlot26);
        int int35 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace37 = categoryPlot36.getFixedRangeAxisSpace();
        boolean boolean38 = categoryPlot36.isRangePannable();
        java.awt.Paint paint39 = categoryPlot36.getRangeMinorGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = categoryPlot36.getRendererForDataset(categoryDataset40);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo44 = null;
        java.awt.geom.Point2D point2D45 = null;
        categoryPlot36.zoomDomainAxes((double) (short) 1, (double) (short) 1, plotRenderingInfo44, point2D45);
        boolean boolean47 = barRenderer19.equals((java.lang.Object) point2D45);
        boolean boolean51 = barRenderer19.isItemLabelVisible(10, 10, false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.5f + "'", float6 == 0.5f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator23);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertNull(axisSpace37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNull(categoryItemRenderer41);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke3 = defaultDrawingSupplier2.getNextOutlineStroke();
        categoryPlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier2, true);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot1.getDomainAxisLocation(1);
        categoryPlot1.setForegroundAlpha((float) (short) 100);
        org.jfree.chart.entity.PlotEntity plotEntity11 = new org.jfree.chart.entity.PlotEntity(shape0, (org.jfree.chart.plot.Plot) categoryPlot1, "hi!");
        org.jfree.chart.axis.AxisSpace axisSpace12 = categoryPlot1.getFixedRangeAxisSpace();
        java.awt.Stroke stroke13 = categoryPlot1.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(shape0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNull(axisSpace12);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.lang.Boolean boolean6 = lineAndShapeRenderer3.getSeriesShapesFilled(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        lineAndShapeRenderer8.drawRangeMarker(graphics2D9, categoryPlot10, valueAxis14, marker15, rectangle2D16);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot10.getDomainMarkers(layer18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer20);
        boolean boolean23 = barRenderer20.isSeriesVisible((int) (short) -1);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape27 = legendItem26.getLine();
        barRenderer20.setSeriesShape(0, shape27, false);
        lineAndShapeRenderer3.setSeriesShape((int) (byte) 1, shape27);
        double double31 = lineAndShapeRenderer3.getItemLabelAnchorOffset();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator32 = null;
        lineAndShapeRenderer3.setBaseURLGenerator(categoryURLGenerator32, false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.0d + "'", double31 == 2.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        float float3 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setLabel("");
        categoryAxis1.setLabel("{0}");
        java.awt.Stroke stroke8 = categoryAxis1.getAxisLineStroke();
        boolean boolean9 = color0.equals((java.lang.Object) categoryAxis1);
        categoryAxis1.setCategoryLabelPositionOffset(35);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke5 = defaultDrawingSupplier4.getNextOutlineStroke();
        categoryPlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4, true);
        java.awt.Paint paint8 = defaultDrawingSupplier4.getNextPaint();
        java.awt.Shape shape9 = defaultDrawingSupplier4.getNextShape();
        java.awt.Stroke stroke10 = defaultDrawingSupplier4.getNextOutlineStroke();
        legendItem1.setOutlineStroke(stroke10);
        java.awt.Paint paint12 = legendItem1.getFillPaint();
        java.lang.Object obj13 = legendItem1.clone();
        legendItem1.setToolTipText("poly");
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(obj13);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        barRenderer12.setDrawBarOutline(false);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = legendItem18.getFillPaintTransformer();
        barRenderer12.setGradientPaintTransformer(gradientPaintTransformer19);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator21 = barRenderer12.getBaseURLGenerator();
        boolean boolean23 = barRenderer12.isSeriesItemLabelsVisible((int) (byte) 0);
        int int24 = barRenderer12.getColumnCount();
        java.awt.Paint paint28 = barRenderer12.getItemOutlinePaint((int) (short) 0, (int) (short) 1, true);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer19);
        org.junit.Assert.assertNull(categoryURLGenerator21);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(paint28);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke7 = defaultDrawingSupplier6.getNextOutlineStroke();
        categoryPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier6, true);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot5.getDomainAxisLocation(1);
        java.lang.String str12 = axisLocation11.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation11, plotOrientation13);
        org.jfree.chart.axis.AxisState axisState15 = null;
        categoryAxis0.drawTickMarks(graphics2D2, 0.05d, rectangle2D4, rectangleEdge14, axisState15);
        int int17 = categoryAxis0.getCategoryLabelPositionOffset();
        double double18 = categoryAxis0.getFixedDimension();
        float float19 = categoryAxis0.getTickMarkOutsideLength();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str12.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + float19 + "' != '" + 2.0f + "'", float19 == 2.0f);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedRangeAxisSpace();
        boolean boolean2 = categoryPlot0.isRangePannable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 8, plotRenderingInfo4, point2D5, false);
        org.jfree.chart.util.SortOrder sortOrder8 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder8);
        org.jfree.chart.LegendItem legendItem11 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean12 = legendItem11.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot13.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int17 = categoryPlot13.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer16);
        boolean boolean18 = legendItem11.equals((java.lang.Object) categoryPlot13);
        categoryPlot13.mapDatasetToDomainAxis(1, (-32640));
        categoryPlot13.setOutlineVisible(false);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryPlot13.getInsets();
        categoryPlot0.setInsets(rectangleInsets24, false);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(rectangleInsets24);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer12.getBaseNegativeItemLabelPosition();
        barRenderer12.setShadowYOffset((double) (-1L));
        barRenderer12.setItemLabelAnchorOffset((double) (-1L));
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.plot.Marker marker30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        lineAndShapeRenderer23.drawRangeMarker(graphics2D24, categoryPlot25, valueAxis29, marker30, rectangle2D31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot25.setRangeAxisLocation((int) (short) 100, axisLocation34, false);
        java.awt.Color color37 = java.awt.Color.ORANGE;
        java.awt.Color color38 = color37.brighter();
        categoryPlot25.setRangeMinorGridlinePaint((java.awt.Paint) color38);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        categoryPlot25.zoomDomainAxes(0.0d, plotRenderingInfo41, point2D42);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset44 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = new org.jfree.chart.axis.CategoryAxis();
        float float46 = categoryAxis45.getTickMarkOutsideLength();
        categoryAxis45.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets49 = categoryAxis45.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis50 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer51 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke53 = lineAndShapeRenderer51.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint55 = lineAndShapeRenderer51.lookupLegendTextPaint((int) '#');
        boolean boolean56 = lineAndShapeRenderer51.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot58 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color60 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot59.setNoDataMessagePaint((java.awt.Paint) color60);
        org.jfree.chart.util.RectangleInsets rectangleInsets62 = categoryPlot59.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis63 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray64 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis63 };
        categoryPlot59.setDomainAxes(categoryAxisArray64);
        java.awt.Stroke stroke66 = categoryPlot59.getDomainCrosshairStroke();
        categoryPlot58.setDomainGridlineStroke(stroke66);
        lineAndShapeRenderer51.setSeriesOutlineStroke((int) ' ', stroke66, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot70 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset44, categoryAxis45, valueAxis50, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer51);
        int int72 = defaultCategoryDataset44.getRowIndex((java.lang.Comparable) (-4194304));
        defaultCategoryDataset44.clear();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo74 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState75 = barRenderer12.initialise(graphics2D21, rectangle2D22, categoryPlot25, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset44, plotRenderingInfo74);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 2.0f + "'", float46 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets49);
        org.junit.Assert.assertNotNull(stroke53);
        org.junit.Assert.assertNull(paint55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(color60);
        org.junit.Assert.assertNotNull(rectangleInsets62);
        org.junit.Assert.assertNotNull(categoryAxisArray64);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-1) + "'", int72 == (-1));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint3 = renderAttributes0.getItemPaint(10, (int) (short) 0);
        java.awt.Paint paint4 = renderAttributes0.getDefaultFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        lineAndShapeRenderer5.drawRangeMarker(graphics2D6, categoryPlot7, valueAxis11, marker12, rectangle2D13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot7.setRangeAxisLocation((int) (short) 100, axisLocation16, false);
        java.awt.Color color19 = java.awt.Color.ORANGE;
        java.awt.Color color20 = color19.brighter();
        categoryPlot7.setRangeMinorGridlinePaint((java.awt.Paint) color20);
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color20);
        java.awt.Paint paint25 = renderAttributes0.getItemPaint(10, (int) (short) 1);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_GREEN;
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color26);
        try {
            java.lang.Boolean boolean30 = renderAttributes0.getCreateEntity((int) (short) 0, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.lang.Boolean boolean6 = lineAndShapeRenderer3.getSeriesShapesFilled(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        lineAndShapeRenderer8.drawRangeMarker(graphics2D9, categoryPlot10, valueAxis14, marker15, rectangle2D16);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot10.getDomainMarkers(layer18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer20);
        boolean boolean23 = barRenderer20.isSeriesVisible((int) (short) -1);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape27 = legendItem26.getLine();
        barRenderer20.setSeriesShape(0, shape27, false);
        lineAndShapeRenderer3.setSeriesShape((int) (byte) 1, shape27);
        boolean boolean31 = lineAndShapeRenderer3.getUseFillPaint();
        java.awt.Shape shape32 = lineAndShapeRenderer3.getBaseShape();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(shape32);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean2 = legendItem1.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int7 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean8 = legendItem1.equals((java.lang.Object) categoryPlot3);
        legendItem1.setLineVisible(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer11 = legendItem1.getFillPaintTransformer();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer11);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedRangeAxisSpace();
        boolean boolean2 = categoryPlot0.isRangePannable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 8, plotRenderingInfo4, point2D5, false);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        boolean boolean12 = categoryPlot0.removeDomainMarker(35, marker9, layer10, false);
        java.awt.Paint paint13 = categoryPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getMinorTickMarkInsideLength();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int9 = categoryPlot5.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer8);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot5.setDataset(categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot5.getDomainAxis((int) (short) 100);
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot5);
        boolean boolean15 = categoryPlot5.canSelectByRegion();
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = categoryPlot5.getOrientation();
        boolean boolean17 = categoryPlot5.isSubplot();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getBaseCreateEntities();
        boolean boolean5 = lineAndShapeRenderer0.getUseFillPaint();
        java.awt.Stroke stroke7 = lineAndShapeRenderer0.getSeriesStroke((int) '#');
        boolean boolean8 = lineAndShapeRenderer0.getAutoPopulateSeriesPaint();
        boolean boolean10 = lineAndShapeRenderer0.isSeriesItemLabelsVisible((-35));
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        categoryPlot0.setDataset(categoryDataset5);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        java.util.List list9 = categoryPlot0.getAnnotations();
        org.jfree.chart.axis.AxisSpace axisSpace10 = categoryPlot0.getFixedRangeAxisSpace();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(list9);
        org.junit.Assert.assertNull(axisSpace10);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        lineAndShapeRenderer3.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Paint paint8 = lineAndShapeRenderer3.getSeriesOutlinePaint((int) (byte) 0);
        boolean boolean9 = lineAndShapeRenderer3.getBaseSeriesVisible();
        java.lang.Object obj10 = lineAndShapeRenderer3.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        barRenderer12.setAutoPopulateSeriesStroke(true);
        boolean boolean18 = barRenderer12.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer12.setShadowPaint((java.awt.Paint) color19);
        barRenderer12.setMaximumBarWidth((double) 2.0f);
        barRenderer12.setShadowYOffset((double) '#');
        barRenderer12.setItemMargin((double) 0L);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        keyedObjects0.insertValue(0, (java.lang.Comparable) (-1), (java.lang.Object) 0);
        java.util.List list6 = keyedObjects0.getKeys();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(list6);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        boolean boolean13 = lineAndShapeRenderer0.isSeriesVisibleInLegend((-32640));
        java.awt.Paint paint17 = lineAndShapeRenderer0.getItemLabelPaint((-4194304), 255, false);
        lineAndShapeRenderer0.clearSeriesPaints(true);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(paint17);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean2 = legendItem1.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int7 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean8 = legendItem1.equals((java.lang.Object) categoryPlot3);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot3.getRangeAxisLocation(8);
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke13 = defaultDrawingSupplier12.getNextOutlineStroke();
        categoryPlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier12, true);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot11.getDomainAxisLocation(1);
        java.lang.String str18 = axisLocation17.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation17, plotOrientation19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace22 = categoryPlot21.getFixedRangeAxisSpace();
        boolean boolean23 = categoryPlot21.isRangePannable();
        java.awt.Paint paint24 = categoryPlot21.getRangeMinorGridlinePaint();
        boolean boolean25 = plotOrientation19.equals((java.lang.Object) categoryPlot21);
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.plot.Plot.resolveRangeAxisLocation(axisLocation10, plotOrientation19);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str18.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setLabel("");
        categoryAxis0.setLabel("{0}");
        java.awt.Stroke stroke7 = categoryAxis0.getAxisLineStroke();
        java.awt.Stroke stroke8 = categoryAxis0.getTickMarkStroke();
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("");
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke13 = defaultDrawingSupplier12.getNextOutlineStroke();
        categoryPlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier12, true);
        java.awt.Paint paint16 = defaultDrawingSupplier12.getNextPaint();
        java.awt.Shape shape17 = defaultDrawingSupplier12.getNextShape();
        java.awt.Stroke stroke18 = defaultDrawingSupplier12.getNextOutlineStroke();
        legendItem10.setOutlineStroke(stroke18);
        categoryAxis0.setAxisLineStroke(stroke18);
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.util.Layer layer37 = null;
        java.util.Collection collection38 = categoryPlot29.getDomainMarkers(layer37);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
        java.awt.geom.Point2D point2D42 = null;
        categoryPlot29.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo41, point2D42);
        org.jfree.chart.axis.AxisSpace axisSpace44 = null;
        categoryPlot29.setFixedDomainAxisSpace(axisSpace44);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean50 = lineAndShapeRenderer47.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot51 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer47.setPlot(categoryPlot51);
        categoryPlot29.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer47);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer54 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D55 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot56.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis60 = null;
        org.jfree.chart.plot.Marker marker61 = null;
        java.awt.geom.Rectangle2D rectangle2D62 = null;
        lineAndShapeRenderer54.drawRangeMarker(graphics2D55, categoryPlot56, valueAxis60, marker61, rectangle2D62);
        org.jfree.chart.axis.AxisLocation axisLocation65 = null;
        categoryPlot56.setRangeAxisLocation((int) (short) 100, axisLocation65, false);
        lineAndShapeRenderer47.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot56);
        org.jfree.chart.util.RectangleEdge rectangleEdge70 = categoryPlot56.getRangeAxisEdge(100);
        try {
            double double71 = categoryAxis0.getCategorySeriesMiddle((int) (byte) 10, (int) (byte) 1, 0, 4, (-8.0d), rectangle2D26, rectangleEdge70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(collection38);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertNotNull(rectangleEdge70);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        boolean boolean4 = categoryPlot0.isDomainCrosshairVisible();
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent5 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent5);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.RenderingSource renderingSource10 = null;
        categoryPlot0.select(0.0d, (double) 100.0f, rectangle2D9, renderingSource10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        java.awt.Color color4 = java.awt.Color.ORANGE;
        java.awt.Color color5 = color4.brighter();
        java.awt.Color color6 = color5.brighter();
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color6);
        java.awt.Font font8 = categoryPlot0.getNoDataMessageFont();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(font8);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getBaseCreateEntities();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer0.getPositiveItemLabelPosition(11, (int) ' ', true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        lineAndShapeRenderer5.drawRangeMarker(graphics2D6, categoryPlot7, valueAxis11, marker12, rectangle2D13);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot7.getDomainMarkers(layer15);
        org.jfree.chart.renderer.category.BarRenderer barRenderer17 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot7.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer17);
        boolean boolean20 = barRenderer17.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = barRenderer17.getBaseNegativeItemLabelPosition();
        boolean boolean22 = barRenderer17.getBaseSeriesVisible();
        java.awt.Paint paint26 = barRenderer17.getItemPaint(0, 15, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke29 = lineAndShapeRenderer27.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint31 = lineAndShapeRenderer27.lookupLegendTextPaint((int) '#');
        boolean boolean32 = lineAndShapeRenderer27.getBaseSeriesVisible();
        java.awt.Stroke stroke33 = lineAndShapeRenderer27.getBaseOutlineStroke();
        java.awt.Paint paint34 = null;
        try {
            org.jfree.chart.LegendItem legendItem35 = new org.jfree.chart.LegendItem(attributedString0, "java.awt.Color[r=255,g=255,b=255]", "{0}", "ChartChangeEventType.GENERAL", shape4, paint26, stroke33, paint34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(stroke29);
        org.junit.Assert.assertNull(paint31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(stroke33);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint2 = lineAndShapeRenderer0.getSeriesPaint((int) (byte) 0);
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getSeriesStroke(1);
        double double5 = lineAndShapeRenderer0.getItemMargin();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition7, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = lineAndShapeRenderer0.getURLGenerator(0, 35, false);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(categoryURLGenerator13);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setUpperMargin((double) (short) 0);
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean8 = renderAttributes7.getDefaultCreateEntity();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        float float10 = categoryAxis9.getTickMarkOutsideLength();
        categoryAxis9.setCategoryMargin((double) 8);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot13.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int17 = categoryPlot13.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer16);
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color20 = java.awt.Color.WHITE;
        boolean boolean21 = plotOrientation19.equals((java.lang.Object) color20);
        int int22 = color20.getBlue();
        lineAndShapeRenderer16.setSeriesFillPaint(1, (java.awt.Paint) color20);
        categoryAxis9.setTickMarkPaint((java.awt.Paint) color20);
        java.awt.Stroke stroke25 = categoryAxis9.getTickMarkStroke();
        renderAttributes7.setDefaultOutlineStroke(stroke25);
        categoryAxis4.setTickMarkStroke(stroke25);
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke25, true);
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer33 = legendItem32.getFillPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke36 = defaultDrawingSupplier35.getNextOutlineStroke();
        categoryPlot34.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35, true);
        java.awt.Paint paint39 = defaultDrawingSupplier35.getNextPaint();
        java.awt.Shape shape40 = defaultDrawingSupplier35.getNextShape();
        java.awt.Stroke stroke41 = defaultDrawingSupplier35.getNextOutlineStroke();
        legendItem32.setOutlineStroke(stroke41);
        lineAndShapeRenderer0.setSeriesStroke((int) '4', stroke41, true);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(gradientPaintTransformer33);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(shape40);
        org.junit.Assert.assertNotNull(stroke41);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        barRenderer12.setDrawBarOutline(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = barRenderer12.getGradientPaintTransformer();
        barRenderer12.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke23 = defaultDrawingSupplier22.getNextOutlineStroke();
        categoryPlot21.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22, true);
        java.awt.Paint paint26 = defaultDrawingSupplier22.getNextPaint();
        java.awt.Shape shape27 = defaultDrawingSupplier22.getNextShape();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot28.setNoDataMessagePaint((java.awt.Paint) color29);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryPlot28.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace32 = categoryPlot28.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D34 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot35.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
        org.jfree.chart.plot.Marker marker40 = null;
        java.awt.geom.Rectangle2D rectangle2D41 = null;
        lineAndShapeRenderer33.drawRangeMarker(graphics2D34, categoryPlot35, valueAxis39, marker40, rectangle2D41);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier43 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke44 = defaultDrawingSupplier43.getNextOutlineStroke();
        categoryPlot35.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier43);
        categoryPlot28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier43);
        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace48 = categoryPlot47.getFixedRangeAxisSpace();
        boolean boolean49 = defaultDrawingSupplier43.equals((java.lang.Object) categoryPlot47);
        categoryPlot47.clearRangeAxes();
        org.jfree.chart.entity.PlotEntity plotEntity53 = new org.jfree.chart.entity.PlotEntity(shape27, (org.jfree.chart.plot.Plot) categoryPlot47, "ChartChangeEventType.GENERAL", "GradientPaintTransformType.CENTER_VERTICAL");
        try {
            barRenderer12.setSeriesShape((-32640), shape27, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer17);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNull(axisSpace32);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertNull(axisSpace48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean1 = renderAttributes0.getDefaultCreateEntity();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) false);
        java.awt.Shape shape4 = renderAttributes0.getDefaultShape();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color6 = java.awt.Color.WHITE;
        boolean boolean7 = plotOrientation5.equals((java.lang.Object) color6);
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color6);
        java.awt.Paint paint10 = renderAttributes0.getSeriesPaint((int) 'a');
        java.awt.Paint paint11 = renderAttributes0.getDefaultPaint();
        org.junit.Assert.assertNull(boolean1);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(paint11);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        boolean boolean12 = lineAndShapeRenderer7.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        java.awt.Stroke stroke22 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot14.setDomainGridlineStroke(stroke22);
        lineAndShapeRenderer7.setSeriesOutlineStroke((int) ' ', stroke22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        int int28 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4194304));
        defaultCategoryDataset0.clear();
        try {
            defaultCategoryDataset0.removeColumn((java.lang.Comparable) 4.0d);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Column key (4.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultCreateEntity();
        java.awt.Paint paint3 = renderAttributes1.getDefaultLabelPaint();
        java.awt.Paint paint6 = renderAttributes1.getItemOutlinePaint((-1), (-1));
        renderAttributes1.setDefaultLabelVisible((java.lang.Boolean) false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer9.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke14 = lineAndShapeRenderer9.lookupSeriesOutlineStroke(0);
        renderAttributes1.setDefaultOutlineStroke(stroke14);
        keyedObjects2D0.setObject((java.lang.Object) renderAttributes1, (java.lang.Comparable) (-16.0d), (java.lang.Comparable) 100);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        float float20 = categoryAxis19.getTickMarkOutsideLength();
        categoryAxis19.setCategoryMargin((double) 8);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot23.setNoDataMessagePaint((java.awt.Paint) color24);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int27 = categoryPlot23.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer26);
        org.jfree.chart.plot.PlotOrientation plotOrientation29 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color30 = java.awt.Color.WHITE;
        boolean boolean31 = plotOrientation29.equals((java.lang.Object) color30);
        int int32 = color30.getBlue();
        lineAndShapeRenderer26.setSeriesFillPaint(1, (java.awt.Paint) color30);
        categoryAxis19.setTickMarkPaint((java.awt.Paint) color30);
        java.awt.Stroke stroke35 = categoryAxis19.getTickMarkStroke();
        categoryAxis19.setCategoryLabelPositionOffset((int) (short) 1);
        java.awt.Paint paint38 = categoryAxis19.getLabelPaint();
        renderAttributes1.setDefaultFillPaint(paint38);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 2.0f + "'", float20 == 2.0f);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 255 + "'", int32 == 255);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        java.awt.Color color10 = java.awt.Color.WHITE;
        categoryPlot2.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot2.panRangeAxes(0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = categoryPlot2.getOrientation();
        java.awt.Stroke stroke17 = categoryPlot2.getOutlineStroke();
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        try {
            categoryPlot2.addDomainMarker((int) (byte) 100, categoryMarker19, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setLabel("");
        categoryAxis0.setLabel("{0}");
        java.awt.Font font7 = categoryAxis0.getTickLabelFont();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        lineAndShapeRenderer9.drawRangeMarker(graphics2D10, categoryPlot11, valueAxis15, marker16, rectangle2D17);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot11.getDomainMarkers(layer19);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot11.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer21);
        org.jfree.chart.renderer.category.BarPainter barPainter23 = barRenderer21.getBarPainter();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator24 = null;
        barRenderer21.setBaseItemLabelGenerator(categoryItemLabelGenerator24, false);
        java.awt.Color color28 = java.awt.Color.BLUE;
        barRenderer21.setSeriesItemLabelPaint((int) (short) 100, (java.awt.Paint) color28, true);
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) "org.jfree.data.UnknownKeyException: hi!", (java.awt.Paint) color28);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(barPainter23);
        org.junit.Assert.assertNotNull(color28);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        java.awt.Paint paint3 = categoryAxis0.getLabelPaint();
        org.jfree.chart.plot.Plot plot4 = categoryAxis0.getPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot5.getInsets();
        double double10 = rectangleInsets8.calculateTopOutset((double) 1.0f);
        double double12 = rectangleInsets8.calculateLeftInset(100.0d);
        categoryAxis0.setTickLabelInsets(rectangleInsets8);
        double double15 = rectangleInsets8.calculateLeftInset(1.0d);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.0d + "'", double12 == 8.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot2.getDomainMarkers(layer19);
        java.awt.Stroke stroke21 = categoryPlot2.getRangeGridlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot2.getFixedLegendItems();
        java.awt.Paint paint23 = categoryPlot2.getOutlinePaint();
        categoryPlot2.clearRangeMarkers();
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color26 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot25.setNoDataMessagePaint((java.awt.Paint) color26);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryPlot25.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace29 = categoryPlot25.getFixedDomainAxisSpace();
        java.awt.Paint paint30 = categoryPlot25.getRangeMinorGridlinePaint();
        categoryPlot2.setOutlinePaint(paint30);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(color26);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNull(axisSpace29);
        org.junit.Assert.assertNotNull(paint30);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedRangeAxisSpace();
        boolean boolean2 = categoryPlot0.isRangePannable();
        java.awt.Paint paint3 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRendererForDataset(categoryDataset4);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        java.awt.geom.Point2D point2D9 = null;
        categoryPlot0.zoomDomainAxes((double) (short) 1, (double) (short) 1, plotRenderingInfo8, point2D9);
        categoryPlot0.setBackgroundAlpha((float) 255);
        categoryPlot0.setBackgroundImageAlpha((float) (byte) 1);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryItemRenderer5);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer12.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        barRenderer12.setBaseFillPaint((java.awt.Paint) color18);
        boolean boolean20 = barRenderer12.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition21 = barRenderer12.getPositiveItemLabelPositionFallback();
        boolean boolean22 = barRenderer12.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Shape shape26 = barRenderer12.getItemShape(192, (int) (byte) 1, false);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(itemLabelPosition21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(shape26);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        float float3 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setLabel("");
        categoryAxis1.setLabel("{0}");
        java.awt.Stroke stroke8 = categoryAxis1.getAxisLineStroke();
        boolean boolean9 = color0.equals((java.lang.Object) categoryAxis1);
        java.awt.Paint paint10 = categoryAxis1.getAxisLinePaint();
        categoryAxis1.setTickMarksVisible(true);
        boolean boolean13 = categoryAxis1.isVisible();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) '4', (int) (short) 1, (-4194304));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Blue");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setSeriesFillPaint((int) 'a', (java.awt.Paint) color11, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer14.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean18 = lineAndShapeRenderer14.getDrawOutlines();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = lineAndShapeRenderer19.getSeriesToolTipGenerator(1);
        java.lang.Boolean boolean23 = lineAndShapeRenderer19.getSeriesLinesVisible((int) (byte) 0);
        java.awt.Color color25 = java.awt.Color.GRAY;
        lineAndShapeRenderer19.setSeriesItemLabelPaint(10, (java.awt.Paint) color25);
        lineAndShapeRenderer14.setBaseLegendTextPaint((java.awt.Paint) color25);
        barRenderer0.setShadowPaint((java.awt.Paint) color25);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator29 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator29);
        java.awt.Font font31 = null;
        try {
            barRenderer0.setBaseItemLabelFont(font31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
        org.junit.Assert.assertNull(boolean23);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.awt.Color color2 = java.awt.Color.getColor("hi!", (int) '#');
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 0, false);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) (-1), (double) 10.0f, plotRenderingInfo10, point2D11);
        categoryPlot0.setCrosshairDatasetIndex((int) (short) -1);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        objectList0.clear();
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendItem5.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape9 = legendItem8.getLine();
        legendItem5.setShape(shape9);
        java.awt.Stroke stroke11 = null;
        legendItem5.setOutlineStroke(stroke11);
        legendItem5.setLineVisible(true);
        try {
            objectList0.set((-4194304), (java.lang.Object) true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(shape9);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke7 = defaultDrawingSupplier6.getNextOutlineStroke();
        categoryPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier6, true);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot5.getDomainAxisLocation(1);
        java.lang.String str12 = axisLocation11.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation11, plotOrientation13);
        org.jfree.chart.axis.AxisState axisState15 = null;
        categoryAxis0.drawTickMarks(graphics2D2, 0.05d, rectangle2D4, rectangleEdge14, axisState15);
        int int17 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Stroke stroke18 = categoryAxis0.getTickMarkStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        lineAndShapeRenderer20.drawRangeMarker(graphics2D21, categoryPlot22, valueAxis26, marker27, rectangle2D28);
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = categoryPlot22.getDomainMarkers(layer30);
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot22.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer32);
        org.jfree.chart.renderer.category.BarPainter barPainter34 = barRenderer32.getBarPainter();
        barRenderer32.setDrawBarOutline(false);
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer39 = legendItem38.getFillPaintTransformer();
        barRenderer32.setGradientPaintTransformer(gradientPaintTransformer39);
        double double41 = barRenderer32.getMinimumBarLength();
        java.awt.Paint paint42 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        barRenderer32.setShadowPaint(paint42);
        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets45 = categoryAxis44.getTickLabelInsets();
        float float46 = categoryAxis44.getTickMarkInsideLength();
        categoryAxis44.setLabel("");
        categoryAxis44.setLabel("{0}");
        java.awt.Font font51 = categoryAxis44.getTickLabelFont();
        barRenderer32.setBaseItemLabelFont(font51);
        categoryAxis0.setTickLabelFont((java.lang.Comparable) "DatasetRenderingOrder.FORWARD", font51);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str12.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 4 + "'", int17 == 4);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertNotNull(barPainter34);
        org.junit.Assert.assertNotNull(gradientPaintTransformer39);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(paint42);
        org.junit.Assert.assertNotNull(rectangleInsets45);
        org.junit.Assert.assertTrue("'" + float46 + "' != '" + 0.0f + "'", float46 == 0.0f);
        org.junit.Assert.assertNotNull(font51);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        java.awt.Stroke stroke5 = lineAndShapeRenderer0.getSeriesStroke(0);
        java.lang.Boolean boolean7 = lineAndShapeRenderer0.getSeriesCreateEntities((int) '#');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNull(boolean7);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator3 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator3, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = lineAndShapeRenderer0.getBaseNegativeItemLabelPosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke10 = defaultDrawingSupplier9.getNextOutlineStroke();
        categoryPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9, true);
        java.awt.Paint paint13 = defaultDrawingSupplier9.getNextPaint();
        java.awt.Shape shape14 = defaultDrawingSupplier9.getNextShape();
        java.awt.Stroke stroke15 = defaultDrawingSupplier9.getNextOutlineStroke();
        lineAndShapeRenderer0.setSeriesOutlineStroke((int) 'a', stroke15, false);
        java.awt.Paint paint18 = lineAndShapeRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertNotNull(itemLabelPosition6);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean1 = renderAttributes0.getDefaultCreateEntity();
        java.awt.Paint paint2 = renderAttributes0.getDefaultLabelPaint();
        java.awt.Paint paint5 = renderAttributes0.getItemOutlinePaint((-1), (-1));
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.Marker marker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        lineAndShapeRenderer7.drawRangeMarker(graphics2D8, categoryPlot9, valueAxis13, marker14, rectangle2D15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot9.getDomainMarkers(layer17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19);
        boolean boolean22 = barRenderer19.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = barRenderer19.getLegendItemLabelGenerator();
        barRenderer19.setDrawBarOutline(true);
        java.awt.Paint paint26 = barRenderer19.getBaseFillPaint();
        renderAttributes0.setSeriesPaint(192, paint26);
        org.junit.Assert.assertNull(boolean1);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator23);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        lineAndShapeRenderer3.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Paint paint8 = lineAndShapeRenderer3.getSeriesOutlinePaint((int) (byte) 0);
        boolean boolean9 = lineAndShapeRenderer3.getBaseSeriesVisible();
        java.awt.Font font10 = null;
        lineAndShapeRenderer3.setBaseLegendTextFont(font10);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        barRenderer0.setMaximumBarWidth((double) 0.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot16.getFixedRangeAxisSpace();
        boolean boolean18 = categoryPlot16.isRangePannable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot16.zoomRangeAxes((double) 8, plotRenderingInfo20, point2D21, false);
        org.jfree.chart.util.SortOrder sortOrder24 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot16.setRowRenderingOrder(sortOrder24);
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryAxis26.getTickLabelInsets();
        float float28 = categoryAxis26.getTickMarkInsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets29 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double31 = rectangleInsets29.calculateTopInset((double) 10);
        java.lang.String str32 = rectangleInsets29.toString();
        double double34 = rectangleInsets29.trimWidth(0.0d);
        categoryAxis26.setLabelInsets(rectangleInsets29, true);
        double double37 = categoryAxis26.getLabelAngle();
        java.lang.String str39 = categoryAxis26.getCategoryLabelToolTip((java.lang.Comparable) (short) 100);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState45 = null;
        try {
            java.awt.Shape shape46 = barRenderer0.createHotSpotShape(graphics2D14, rectangle2D15, categoryPlot16, categoryAxis26, valueAxis40, categoryDataset41, (int) (byte) 1, 0, false, categoryItemRendererState45);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(sortOrder24);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 0.0f + "'", float28 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 4.0d + "'", double31 == 4.0d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str32.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + (-16.0d) + "'", double34 == (-16.0d));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNull(str39);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = barRenderer12.getLegendItemLabelGenerator();
        barRenderer12.setSeriesVisibleInLegend((int) (byte) 100, (java.lang.Boolean) false, false);
        org.jfree.chart.renderer.category.BarRenderer barRenderer21 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean22 = barRenderer21.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint24 = barRenderer21.getSeriesFillPaint(1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean28 = lineAndShapeRenderer25.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition32 = lineAndShapeRenderer25.getPositiveItemLabelPosition((int) (short) 1, (int) (byte) 1, true);
        barRenderer21.setBasePositiveItemLabelPosition(itemLabelPosition32, false);
        barRenderer12.setPositiveItemLabelPositionFallback(itemLabelPosition32);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition32);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemLabelPaint((int) (byte) 10, (int) (byte) -1, false);
        java.awt.Font font9 = lineAndShapeRenderer0.getBaseLegendTextFont();
        java.awt.Stroke stroke11 = lineAndShapeRenderer0.getSeriesStroke(0);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNull(font9);
        org.junit.Assert.assertNull(stroke11);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("hi!");
        java.lang.String str2 = datasetGroup1.getID();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean6 = lineAndShapeRenderer3.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer3.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color9 = java.awt.Color.darkGray;
        lineAndShapeRenderer3.setBaseOutlinePaint((java.awt.Paint) color9, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator12 = null;
        lineAndShapeRenderer3.setBaseToolTipGenerator(categoryToolTipGenerator12, true);
        boolean boolean15 = datasetGroup1.equals((java.lang.Object) true);
        java.lang.Object obj16 = datasetGroup1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        float float7 = categoryPlot0.getForegroundAlpha();
        java.lang.Comparable comparable8 = null;
        categoryPlot0.setDomainCrosshairColumnKey(comparable8);
        org.jfree.chart.util.RectangleInsets rectangleInsets10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double12 = rectangleInsets10.calculateBottomOutset((double) 0.5f);
        categoryPlot0.setInsets(rectangleInsets10, true);
        java.awt.Graphics2D graphics2D15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        org.jfree.chart.plot.CategoryCrosshairState categoryCrosshairState19 = null;
        boolean boolean20 = categoryPlot0.render(graphics2D15, rectangle2D16, (int) 'a', plotRenderingInfo18, categoryCrosshairState19);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertNotNull(rectangleInsets10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.0d + "'", double12 == 3.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        categoryPlot2.setBackgroundAlpha((float) 8);
        boolean boolean21 = categoryPlot2.isNotify();
        org.jfree.chart.LegendItem legendItem24 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean25 = legendItem24.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color27 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot26.setNoDataMessagePaint((java.awt.Paint) color27);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int30 = categoryPlot26.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer29);
        boolean boolean31 = legendItem24.equals((java.lang.Object) categoryPlot26);
        org.jfree.chart.axis.AxisLocation axisLocation33 = categoryPlot26.getRangeAxisLocation(8);
        try {
            categoryPlot2.setRangeAxisLocation((-35), axisLocation33, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(axisLocation33);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer12.getBaseNegativeItemLabelPosition();
        barRenderer12.setShadowYOffset((double) (-1L));
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke21 = lineAndShapeRenderer19.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint23 = lineAndShapeRenderer19.lookupLegendTextPaint((int) '#');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor24 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor24, textAnchor25);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor27 = itemLabelPosition26.getItemLabelAnchor();
        lineAndShapeRenderer19.setBasePositiveItemLabelPosition(itemLabelPosition26);
        barRenderer12.setBaseNegativeItemLabelPosition(itemLabelPosition26, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot31.setNoDataMessagePaint((java.awt.Paint) color32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryPlot31.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray36 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis35 };
        categoryPlot31.setDomainAxes(categoryAxisArray36);
        categoryPlot31.clearRangeAxes();
        barRenderer12.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot31);
        categoryPlot31.setOutlineVisible(true);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(itemLabelAnchor24);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(itemLabelAnchor27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(categoryAxisArray36);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseOutlineStroke();
        lineAndShapeRenderer2.setUseFillPaint(false);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint4 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '#');
        boolean boolean5 = lineAndShapeRenderer0.getBaseShapesFilled();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator6 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator6);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint4 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '#');
        boolean boolean5 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Stroke stroke6 = lineAndShapeRenderer0.getBaseOutlineStroke();
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (short) 100, false);
        lineAndShapeRenderer0.setBaseShapesFilled(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder13 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke16 = defaultDrawingSupplier15.getNextOutlineStroke();
        categoryPlot14.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15, true);
        java.awt.Paint paint19 = defaultDrawingSupplier15.getNextPaint();
        boolean boolean20 = datasetRenderingOrder13.equals((java.lang.Object) paint19);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke23 = defaultDrawingSupplier22.getNextOutlineStroke();
        categoryPlot21.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22, true);
        java.awt.Paint paint26 = defaultDrawingSupplier22.getNextPaint();
        java.awt.Shape shape27 = defaultDrawingSupplier22.getNextShape();
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer30 = legendItem29.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape33 = legendItem32.getLine();
        legendItem29.setShape(shape33);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke37 = lineAndShapeRenderer35.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint39 = lineAndShapeRenderer35.lookupLegendTextPaint((int) '#');
        java.awt.Stroke stroke43 = lineAndShapeRenderer35.getItemStroke(1, (int) (short) 1, false);
        legendItem29.setOutlineStroke(stroke43);
        java.lang.String str45 = legendItem29.getToolTipText();
        boolean boolean46 = defaultDrawingSupplier22.equals((java.lang.Object) legendItem29);
        boolean boolean47 = datasetRenderingOrder13.equals((java.lang.Object) defaultDrawingSupplier22);
        java.awt.Shape shape48 = defaultDrawingSupplier22.getNextShape();
        try {
            lineAndShapeRenderer0.setSeriesShape((int) (byte) -1, shape48);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder13);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(gradientPaintTransformer30);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNull(str45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(shape48);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean1 = renderAttributes0.getDefaultCreateEntity();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) false);
        java.awt.Shape shape4 = renderAttributes0.getDefaultShape();
        java.lang.Boolean boolean5 = renderAttributes0.getDefaultCreateEntity();
        org.junit.Assert.assertNull(boolean1);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNull(boolean5);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder7);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke12 = defaultDrawingSupplier11.getNextOutlineStroke();
        categoryPlot10.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier11, true);
        org.jfree.chart.axis.AxisLocation axisLocation16 = categoryPlot10.getDomainAxisLocation(1);
        org.jfree.chart.axis.AxisLocation axisLocation17 = axisLocation16.getOpposite();
        categoryPlot0.setRangeAxisLocation(0, axisLocation17, true);
        org.jfree.chart.plot.Plot plot20 = categoryPlot0.getParent();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation21 = null;
        try {
            boolean boolean23 = categoryPlot0.removeAnnotation(categoryAnnotation21, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(axisLocation16);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertNull(plot20);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        barRenderer0.setMaximumBarWidth((double) 0.0f);
        java.awt.Paint paint12 = barRenderer0.getShadowPaint();
        double double13 = barRenderer0.getMinimumBarLength();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        java.awt.Stroke stroke22 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot15.setDomainCrosshairRowKey((java.lang.Comparable) 'a', false);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        barRenderer0.drawRangeMarker(graphics2D14, categoryPlot15, valueAxis26, marker27, rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(stroke22);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        lineAndShapeRenderer14.drawRangeMarker(graphics2D15, categoryPlot16, valueAxis20, marker21, rectangle2D22);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot16.getDomainMarkers(layer24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot16.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo28, point2D29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot16.setFixedDomainAxisSpace(axisSpace31);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean37 = lineAndShapeRenderer34.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer34.setPlot(categoryPlot38);
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        barRenderer12.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer42 = barRenderer12.getGradientPaintTransformer();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformer42);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot0.setRangeAxis(valueAxis5);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.plot.Marker marker9 = null;
        boolean boolean10 = categoryPlot0.removeDomainMarker(marker9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer12.getBaseNegativeItemLabelPosition();
        boolean boolean17 = barRenderer12.getBaseSeriesVisible();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator19 = barRenderer12.getSeriesItemLabelGenerator((int) '4');
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNull(categoryItemLabelGenerator19);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double5 = rectangleInsets3.calculateTopInset((double) 10);
        java.lang.String str6 = rectangleInsets3.toString();
        double double8 = rectangleInsets3.trimWidth(0.0d);
        categoryAxis0.setLabelInsets(rectangleInsets3, true);
        float float11 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        categoryAxis0.setLabelAngle(26.0d);
        double double14 = categoryAxis0.getLabelAngle();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str6.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-16.0d) + "'", double8 == (-16.0d));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 26.0d + "'", double14 == 26.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        boolean boolean12 = lineAndShapeRenderer7.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        java.awt.Stroke stroke22 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot14.setDomainGridlineStroke(stroke22);
        lineAndShapeRenderer7.setSeriesOutlineStroke((int) ' ', stroke22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        int int28 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4194304));
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.setValue(0.0d, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) "TextAnchor.CENTER");
        int int34 = defaultCategoryDataset0.getColumnCount();
        int int35 = defaultCategoryDataset0.getRowCount();
        java.lang.Comparable comparable36 = null;
        try {
            int int37 = defaultCategoryDataset0.getColumnIndex(comparable36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'key' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        try {
            org.jfree.chart.ChartColor chartColor3 = new org.jfree.chart.ChartColor((int) (short) -1, (int) (short) 10, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Color parameter outside of expected range: Red");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        java.awt.Color color4 = java.awt.Color.ORANGE;
        java.awt.Color color5 = color4.brighter();
        java.awt.Color color6 = color5.brighter();
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot0.getAxisOffset();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier11 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke12 = defaultDrawingSupplier11.getNextOutlineStroke();
        categoryPlot10.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier11, true);
        java.awt.Paint paint15 = defaultDrawingSupplier11.getNextPaint();
        boolean boolean16 = datasetRenderingOrder9.equals((java.lang.Object) paint15);
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke19 = defaultDrawingSupplier18.getNextOutlineStroke();
        categoryPlot17.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier18, true);
        java.awt.Paint paint22 = defaultDrawingSupplier18.getNextPaint();
        java.awt.Shape shape23 = defaultDrawingSupplier18.getNextShape();
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer26 = legendItem25.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape29 = legendItem28.getLine();
        legendItem25.setShape(shape29);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke33 = lineAndShapeRenderer31.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint35 = lineAndShapeRenderer31.lookupLegendTextPaint((int) '#');
        java.awt.Stroke stroke39 = lineAndShapeRenderer31.getItemStroke(1, (int) (short) 1, false);
        legendItem25.setOutlineStroke(stroke39);
        java.lang.String str41 = legendItem25.getToolTipText();
        boolean boolean42 = defaultDrawingSupplier18.equals((java.lang.Object) legendItem25);
        boolean boolean43 = datasetRenderingOrder9.equals((java.lang.Object) defaultDrawingSupplier18);
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder9);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(gradientPaintTransformer26);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(stroke33);
        org.junit.Assert.assertNull(paint35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(str41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        lineAndShapeRenderer0.setSeriesShapesFilled(0, (java.lang.Boolean) false);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.util.ObjectList objectList18 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj19 = objectList18.clone();
        objectList18.clear();
        org.jfree.data.KeyedObjects2D keyedObjects2D21 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.renderer.RenderAttributes renderAttributes22 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean23 = renderAttributes22.getDefaultCreateEntity();
        java.awt.Paint paint24 = renderAttributes22.getDefaultLabelPaint();
        java.awt.Paint paint27 = renderAttributes22.getItemOutlinePaint((-1), (-1));
        renderAttributes22.setDefaultLabelVisible((java.lang.Boolean) false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer30.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke35 = lineAndShapeRenderer30.lookupSeriesOutlineStroke(0);
        renderAttributes22.setDefaultOutlineStroke(stroke35);
        keyedObjects2D21.setObject((java.lang.Object) renderAttributes22, (java.lang.Comparable) (-16.0d), (java.lang.Comparable) 100);
        boolean boolean40 = objectList18.equals((java.lang.Object) renderAttributes22);
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color43 = color42.brighter();
        renderAttributes22.setSeriesFillPaint((int) (byte) 10, (java.awt.Paint) color42);
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) ' ', (java.awt.Paint) color42);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNull(boolean23);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNull(paint27);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator10 = lineAndShapeRenderer0.getLegendItemLabelGenerator();
        double double11 = lineAndShapeRenderer0.getItemLabelAnchorOffset();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator13 = null;
        lineAndShapeRenderer0.setSeriesURLGenerator(1, categoryURLGenerator13, true);
        java.lang.Object obj16 = lineAndShapeRenderer0.clone();
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.0d + "'", double11 == 2.0d);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) true);
        java.awt.Paint paint4 = renderAttributes0.getSeriesFillPaint(1);
        java.awt.Shape shape5 = renderAttributes0.getDefaultShape();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.Marker marker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        lineAndShapeRenderer7.drawRangeMarker(graphics2D8, categoryPlot9, valueAxis13, marker14, rectangle2D15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot9.getDomainMarkers(layer17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19);
        org.jfree.chart.renderer.category.BarPainter barPainter21 = barRenderer19.getBarPainter();
        barRenderer19.setDrawBarOutline(false);
        org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer26 = legendItem25.getFillPaintTransformer();
        barRenderer19.setGradientPaintTransformer(gradientPaintTransformer26);
        double double28 = barRenderer19.getMinimumBarLength();
        java.awt.Paint paint29 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        barRenderer19.setShadowPaint(paint29);
        renderAttributes0.setSeriesPaint(35, paint29);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNotNull(barPainter21);
        org.junit.Assert.assertNotNull(gradientPaintTransformer26);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(paint29);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedRangeAxisSpace();
        boolean boolean2 = categoryPlot0.isRangePannable();
        java.awt.Paint paint3 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRendererForDataset(categoryDataset4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Stroke stroke7 = categoryPlot0.getDomainCrosshairStroke();
        int int8 = categoryPlot0.getRangeAxisCount();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator4 = null;
        lineAndShapeRenderer2.setSeriesItemLabelGenerator((int) (byte) 0, categoryItemLabelGenerator4, false);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation4 = null;
        boolean boolean5 = lineAndShapeRenderer0.removeAnnotation(categoryAnnotation4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer6.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean10 = lineAndShapeRenderer6.getDrawOutlines();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = lineAndShapeRenderer11.getSeriesToolTipGenerator(1);
        java.lang.Boolean boolean15 = lineAndShapeRenderer11.getSeriesLinesVisible((int) (byte) 0);
        java.awt.Color color17 = java.awt.Color.GRAY;
        lineAndShapeRenderer11.setSeriesItemLabelPaint(10, (java.awt.Paint) color17);
        lineAndShapeRenderer6.setBaseLegendTextPaint((java.awt.Paint) color17);
        lineAndShapeRenderer0.setBasePaint((java.awt.Paint) color17, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
        org.junit.Assert.assertNull(boolean15);
        org.junit.Assert.assertNotNull(color17);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        java.awt.Stroke stroke5 = lineAndShapeRenderer0.getSeriesStroke(0);
        lineAndShapeRenderer0.setSeriesLinesVisible((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.renderer.RenderAttributes renderAttributes11 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint14 = renderAttributes11.getItemPaint(10, (int) (short) 0);
        java.awt.Paint paint15 = renderAttributes11.getDefaultFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot18.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis22 = null;
        org.jfree.chart.plot.Marker marker23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        lineAndShapeRenderer16.drawRangeMarker(graphics2D17, categoryPlot18, valueAxis22, marker23, rectangle2D24);
        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
        categoryPlot18.setRangeAxisLocation((int) (short) 100, axisLocation27, false);
        java.awt.Color color30 = java.awt.Color.ORANGE;
        java.awt.Color color31 = color30.brighter();
        categoryPlot18.setRangeMinorGridlinePaint((java.awt.Paint) color31);
        renderAttributes11.setDefaultLabelPaint((java.awt.Paint) color31);
        java.awt.Paint paint36 = renderAttributes11.getItemPaint(10, (int) (short) 1);
        java.awt.Color color37 = org.jfree.chart.ChartColor.DARK_GREEN;
        renderAttributes11.setDefaultLabelPaint((java.awt.Paint) color37);
        categoryPlot10.setRangeGridlinePaint((java.awt.Paint) color37);
        lineAndShapeRenderer0.setSeriesItemLabelPaint(100, (java.awt.Paint) color37, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNull(paint14);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(color31);
        org.junit.Assert.assertNull(paint36);
        org.junit.Assert.assertNotNull(color37);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        float float3 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setLabel("");
        categoryAxis1.setLabel("{0}");
        java.awt.Stroke stroke8 = categoryAxis1.getAxisLineStroke();
        boolean boolean9 = color0.equals((java.lang.Object) categoryAxis1);
        java.awt.Paint paint10 = categoryAxis1.getAxisLinePaint();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getTickLabelInsets();
        float float13 = categoryAxis11.getTickMarkInsideLength();
        categoryAxis11.setLabel("");
        categoryAxis11.setLabel("{0}");
        java.awt.Font font18 = categoryAxis11.getTickLabelFont();
        categoryAxis1.setTickLabelFont(font18);
        double double20 = categoryAxis1.getUpperMargin();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.05d + "'", double20 == 0.05d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        boolean boolean2 = legendItem1.isShapeOutlineVisible();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.jfree.chart.renderer.category.BarRenderer barRenderer3 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean4 = barRenderer3.getAutoPopulateSeriesOutlinePaint();
        boolean boolean5 = itemLabelAnchor0.equals((java.lang.Object) barRenderer3);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = null;
        categoryPlot9.setDomainAxis(10, categoryAxis11, true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot9.setRangeAxis(valueAxis14);
        categoryPlot9.setRangeCrosshairValue((double) '#');
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset18 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        float float20 = categoryAxis19.getTickMarkOutsideLength();
        categoryAxis19.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets23 = categoryAxis19.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke27 = lineAndShapeRenderer25.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint29 = lineAndShapeRenderer25.lookupLegendTextPaint((int) '#');
        boolean boolean30 = lineAndShapeRenderer25.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color34 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot33.setNoDataMessagePaint((java.awt.Paint) color34);
        org.jfree.chart.util.RectangleInsets rectangleInsets36 = categoryPlot33.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray38 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis37 };
        categoryPlot33.setDomainAxes(categoryAxisArray38);
        java.awt.Stroke stroke40 = categoryPlot33.getDomainCrosshairStroke();
        categoryPlot32.setDomainGridlineStroke(stroke40);
        lineAndShapeRenderer25.setSeriesOutlineStroke((int) ' ', stroke40, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset18, categoryAxis19, valueAxis24, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer25);
        int int46 = defaultCategoryDataset18.getRowIndex((java.lang.Comparable) (-4194304));
        defaultCategoryDataset18.clear();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer48 = categoryPlot9.getRendererForDataset((org.jfree.data.category.CategoryDataset) defaultCategoryDataset18);
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity51 = new org.jfree.chart.entity.CategoryItemEntity(shape5, "", "PlotEntity: tooltip = hi!", (org.jfree.data.category.CategoryDataset) defaultCategoryDataset18, (java.lang.Comparable) 2, (java.lang.Comparable) 10.0d);
        java.lang.String str52 = categoryItemEntity51.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 2.0f + "'", float20 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets23);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNull(paint29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertNotNull(rectangleInsets36);
        org.junit.Assert.assertNotNull(categoryAxisArray38);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1) + "'", int46 == (-1));
        org.junit.Assert.assertNull(categoryItemRenderer48);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot2.setRangeAxisLocation((int) (short) 100, axisLocation11, false);
        java.awt.Color color14 = java.awt.Color.ORANGE;
        java.awt.Color color15 = color14.brighter();
        categoryPlot2.setRangeMinorGridlinePaint((java.awt.Paint) color15);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot2.zoomDomainAxes(0.0d, plotRenderingInfo18, point2D19);
        org.jfree.chart.event.PlotChangeListener plotChangeListener21 = null;
        categoryPlot2.removeChangeListener(plotChangeListener21);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        objectList0.clear();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        lineAndShapeRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis10, marker11, rectangle2D12);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot6.getDomainMarkers(layer14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition18 = barRenderer16.getPositiveItemLabelPositionFallback();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        barRenderer16.setSeriesPaint((int) (short) 1, (java.awt.Paint) color20, false);
        barRenderer16.setSeriesItemLabelsVisible(15, (java.lang.Boolean) false, false);
        objectList0.set((int) ' ', (java.lang.Object) barRenderer16);
        org.jfree.chart.text.TextAnchor textAnchor29 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        objectList0.set(0, (java.lang.Object) textAnchor29);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(itemLabelPosition18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(textAnchor29);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean2 = renderAttributes1.getDefaultCreateEntity();
        java.awt.Paint paint3 = renderAttributes1.getDefaultLabelPaint();
        java.awt.Paint paint6 = renderAttributes1.getItemOutlinePaint((-1), (-1));
        renderAttributes1.setDefaultLabelVisible((java.lang.Boolean) false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer9.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke14 = lineAndShapeRenderer9.lookupSeriesOutlineStroke(0);
        renderAttributes1.setDefaultOutlineStroke(stroke14);
        keyedObjects2D0.setObject((java.lang.Object) renderAttributes1, (java.lang.Comparable) (-16.0d), (java.lang.Comparable) 100);
        java.awt.Paint paint19 = renderAttributes1.getDefaultOutlinePaint();
        java.awt.Paint paint22 = renderAttributes1.getItemOutlinePaint((-32640), 0);
        org.junit.Assert.assertNull(boolean2);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNull(paint19);
        org.junit.Assert.assertNull(paint22);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getTickMarkOutsideLength();
        categoryAxis0.setCategoryMargin((double) 8);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot4.setNoDataMessagePaint((java.awt.Paint) color5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int8 = categoryPlot4.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color11 = java.awt.Color.WHITE;
        boolean boolean12 = plotOrientation10.equals((java.lang.Object) color11);
        int int13 = color11.getBlue();
        lineAndShapeRenderer7.setSeriesFillPaint(1, (java.awt.Paint) color11);
        categoryAxis0.setTickMarkPaint((java.awt.Paint) color11);
        categoryAxis0.setLabelToolTip("DatasetRenderingOrder.FORWARD");
        java.awt.Paint paint18 = categoryAxis0.getAxisLinePaint();
        double double19 = categoryAxis0.getLabelAngle();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0f + "'", float1 == 2.0f);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        boolean boolean13 = lineAndShapeRenderer0.isSeriesVisibleInLegend((-32640));
        java.awt.Color color15 = java.awt.Color.white;
        int int16 = color15.getBlue();
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) (short) 1, (java.awt.Paint) color15);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation18 = null;
        try {
            lineAndShapeRenderer0.addAnnotation(categoryAnnotation18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        categoryPlot2.setBackgroundAlpha((float) 8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean24 = lineAndShapeRenderer21.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer21.setPlot(categoryPlot25);
        categoryPlot25.setBackgroundImageAlignment((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot25.zoomDomainAxes((double) 0.0f, plotRenderingInfo30, point2D31, true);
        categoryPlot2.setParent((org.jfree.chart.plot.Plot) categoryPlot25);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier35 = categoryPlot25.getDrawingSupplier();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(drawingSupplier35);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color6 = java.awt.Color.darkGray;
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color6, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, true);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer14 = legendItem13.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape17 = legendItem16.getLine();
        legendItem13.setShape(shape17);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape17, "AxisLocation.TOP_OR_RIGHT", "hi!");
        java.awt.Shape shape22 = chartEntity21.getArea();
        lineAndShapeRenderer0.setBaseLegendShape(shape22);
        org.jfree.chart.entity.ChartEntity chartEntity25 = new org.jfree.chart.entity.ChartEntity(shape22, "AxisLocation.TOP_OR_RIGHT");
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(gradientPaintTransformer14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape22);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getMinorTickMarkInsideLength();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color3);
        categoryAxis0.setTickMarkInsideLength((float) (-10289251));
        float float7 = categoryAxis0.getTickMarkOutsideLength();
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Color color10 = color9.brighter();
        java.awt.Color color11 = color10.brighter();
        categoryAxis0.setTickLabelPaint((java.lang.Comparable) 102.0d, (java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.lang.Boolean boolean6 = lineAndShapeRenderer0.getSeriesVisibleInLegend((int) '#');
        boolean boolean7 = lineAndShapeRenderer0.getUseSeriesOffset();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer0.setPlot(categoryPlot4);
        categoryPlot4.setRangePannable(true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        boolean boolean12 = lineAndShapeRenderer7.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        java.awt.Stroke stroke22 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot14.setDomainGridlineStroke(stroke22);
        lineAndShapeRenderer7.setSeriesOutlineStroke((int) ' ', stroke22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        int int28 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4194304));
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.setValue(0.0d, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) "TextAnchor.CENTER");
        java.lang.Object obj34 = defaultCategoryDataset0.clone();
        java.lang.Object obj35 = null;
        boolean boolean36 = defaultCategoryDataset0.equals(obj35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(obj34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        java.awt.Color color0 = java.awt.Color.CYAN;
        java.awt.Color color1 = color0.darker();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        lineAndShapeRenderer0.setSeriesShapesFilled(0, (java.lang.Boolean) false);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator17);
        java.awt.Paint paint19 = lineAndShapeRenderer0.getBaseLegendTextPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(paint19);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        java.awt.Stroke stroke10 = categoryPlot2.getRangeZeroBaselineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection11 = categoryPlot2.getLegendItems();
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(legendItemCollection11);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        float float7 = categoryPlot0.getForegroundAlpha();
        categoryPlot0.setBackgroundAlpha((float) 2);
        int int10 = categoryPlot0.getBackgroundImageAlignment();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder11 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder11);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot0.zoomRangeAxes((double) 100, plotRenderingInfo14, point2D15, false);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 1.0f + "'", float7 == 1.0f);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 15 + "'", int10 == 15);
        org.junit.Assert.assertNotNull(datasetRenderingOrder11);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color2);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color2, (float) ' ', (int) (byte) 0, (double) (-1));
        double double8 = defaultShadowGenerator7.getAngle();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot11.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis15 = null;
        org.jfree.chart.plot.Marker marker16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        lineAndShapeRenderer9.drawRangeMarker(graphics2D10, categoryPlot11, valueAxis15, marker16, rectangle2D17);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot11.getDomainMarkers(layer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot11.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo23, point2D24);
        org.jfree.chart.axis.AxisSpace axisSpace26 = null;
        categoryPlot11.setFixedDomainAxisSpace(axisSpace26);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer29 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean32 = lineAndShapeRenderer29.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer29.setPlot(categoryPlot33);
        categoryPlot11.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer29);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer36 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D37 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot38.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis42 = null;
        org.jfree.chart.plot.Marker marker43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        lineAndShapeRenderer36.drawRangeMarker(graphics2D37, categoryPlot38, valueAxis42, marker43, rectangle2D44);
        org.jfree.chart.axis.AxisLocation axisLocation47 = null;
        categoryPlot38.setRangeAxisLocation((int) (short) 100, axisLocation47, false);
        lineAndShapeRenderer29.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot38);
        org.jfree.chart.util.RectangleEdge rectangleEdge52 = categoryPlot38.getRangeAxisEdge(100);
        categoryPlot38.setDomainCrosshairVisible(false);
        boolean boolean55 = categoryPlot38.isRangeGridlinesVisible();
        boolean boolean56 = defaultShadowGenerator7.equals((java.lang.Object) categoryPlot38);
        int int57 = defaultShadowGenerator7.getShadowSize();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.0d) + "'", double8 == (-1.0d));
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(rectangleEdge52);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 35 + "'", int57 == 35);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedRangeAxisSpace();
        boolean boolean2 = categoryPlot0.isRangePannable();
        java.awt.Paint paint3 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRendererForDataset(categoryDataset4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Paint paint7 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        org.jfree.chart.axis.AxisLocation axisLocation7 = categoryPlot0.getDomainAxisLocation((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke10 = defaultDrawingSupplier9.getNextOutlineStroke();
        categoryPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9, true);
        java.awt.Paint paint13 = defaultDrawingSupplier9.getNextPaint();
        java.awt.Shape shape14 = defaultDrawingSupplier9.getNextShape();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9, false);
        java.lang.Object obj17 = defaultDrawingSupplier9.clone();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
        org.junit.Assert.assertNotNull(axisLocation7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setLabel("");
        categoryAxis0.setLabel("{0}");
        java.awt.Stroke stroke7 = categoryAxis0.getAxisLineStroke();
        double double8 = categoryAxis0.getLabelAngle();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (short) -1, "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        java.lang.String str12 = categoryAxis0.getLabelURL();
        categoryAxis0.setAxisLineVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNull(str12);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot29.getRangeAxisEdge(100);
        categoryPlot29.setDomainCrosshairVisible(false);
        boolean boolean46 = categoryPlot29.isRangeGridlinesVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo48 = null;
        java.awt.geom.Point2D point2D49 = null;
        categoryPlot29.panDomainAxes((double) (-32640), plotRenderingInfo48, point2D49);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        categoryPlot29.panDomainAxes((double) (-1.0f), plotRenderingInfo52, point2D53);
        boolean boolean55 = categoryPlot29.isRangePannable();
        boolean boolean56 = categoryPlot29.isDomainZoomable();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        java.awt.Paint paint3 = categoryAxis0.getLabelPaint();
        categoryAxis0.setFixedDimension((double) 0);
        boolean boolean6 = categoryAxis0.isTickMarksVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot7.setNoDataMessagePaint((java.awt.Paint) color8);
        categoryPlot7.setCrosshairDatasetIndex((int) (byte) 0, false);
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot7.zoomRangeAxes((double) (-1), (double) 10.0f, plotRenderingInfo17, point2D18);
        categoryPlot7.setDomainGridlinesVisible(false);
        categoryPlot7.clearAnnotations();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        java.awt.Image image24 = null;
        categoryPlot7.setBackgroundImage(image24);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        barRenderer0.setShadowXOffset(0.0d);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        double double16 = barRenderer12.getShadowYOffset();
        java.awt.Color color18 = java.awt.Color.ORANGE;
        java.awt.Color color19 = color18.brighter();
        barRenderer12.setSeriesOutlinePaint((int) '4', (java.awt.Paint) color19, true);
        barRenderer12.setSeriesVisible(8, (java.lang.Boolean) true, false);
        org.jfree.chart.LegendItemCollection legendItemCollection26 = barRenderer12.getLegendItems();
        java.awt.Paint paint28 = null;
        barRenderer12.setSeriesPaint(2, paint28, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition34 = barRenderer12.getNegativeItemLabelPosition(35, (int) '#', true);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(legendItemCollection26);
        org.junit.Assert.assertNotNull(itemLabelPosition34);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color2);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color2, (float) ' ', (int) (byte) 0, (double) (-1));
        java.awt.Color color8 = defaultShadowGenerator7.getShadowColor();
        java.awt.Color color9 = defaultShadowGenerator7.getShadowColor();
        java.awt.Color color10 = java.awt.Color.ORANGE;
        java.awt.Color color11 = color10.brighter();
        java.awt.Color color12 = color11.brighter();
        java.awt.color.ColorSpace colorSpace13 = color11.getColorSpace();
        java.awt.Color color14 = java.awt.Color.red;
        java.awt.Color color15 = java.awt.Color.ORANGE;
        java.awt.Color color16 = color15.brighter();
        float[] floatArray21 = new float[] { (-10289251), (-1.0f), 2.0f, 0.0f };
        float[] floatArray22 = color16.getComponents(floatArray21);
        float[] floatArray23 = color14.getRGBComponents(floatArray21);
        float[] floatArray24 = color9.getColorComponents(colorSpace13, floatArray23);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(colorSpace13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendItem5.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape9 = legendItem8.getLine();
        legendItem5.setShape(shape9);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape9, "AxisLocation.TOP_OR_RIGHT", "hi!");
        java.awt.Shape shape14 = chartEntity13.getArea();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke16 = defaultDrawingSupplier15.getNextOutlineStroke();
        java.awt.Paint paint17 = null;
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "ItemLabelAnchor.INSIDE9", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", shape14, stroke16, paint17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.Marker marker26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        lineAndShapeRenderer19.drawRangeMarker(graphics2D20, categoryPlot21, valueAxis25, marker26, rectangle2D27);
        org.jfree.chart.util.Layer layer29 = null;
        java.util.Collection collection30 = categoryPlot21.getDomainMarkers(layer29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot21.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo33, point2D34);
        org.jfree.chart.axis.AxisSpace axisSpace36 = null;
        categoryPlot21.setFixedDomainAxisSpace(axisSpace36);
        categoryPlot21.setBackgroundAlpha((float) 8);
        boolean boolean40 = categoryPlot21.isNotify();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer41 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean44 = lineAndShapeRenderer41.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer41.setPlot(categoryPlot45);
        categoryPlot45.setBackgroundImageAlignment((int) (short) 0);
        java.util.List list49 = categoryPlot45.getAnnotations();
        org.jfree.chart.LegendItemCollection legendItemCollection50 = categoryPlot45.getFixedLegendItems();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent51 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot45);
        categoryPlot21.notifyListeners(plotChangeEvent51);
        org.jfree.chart.util.Layer layer53 = null;
        java.util.Collection collection54 = categoryPlot21.getRangeMarkers(layer53);
        org.jfree.chart.entity.PlotEntity plotEntity57 = new org.jfree.chart.entity.PlotEntity(shape14, (org.jfree.chart.plot.Plot) categoryPlot21, "0,0,0,0", "hi!");
        java.lang.String str58 = plotEntity57.getToolTipText();
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(collection30);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertNotNull(list49);
        org.junit.Assert.assertNull(legendItemCollection50);
        org.junit.Assert.assertNull(collection54);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "0,0,0,0" + "'", str58.equals("0,0,0,0"));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        try {
            java.awt.Color color1 = java.awt.Color.decode("PlotOrientation.VERTICAL");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"PlotOrientation.VERTICAL\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint2 = lineAndShapeRenderer0.getSeriesPaint((int) (byte) 0);
        java.awt.Font font3 = org.jfree.chart.plot.CategoryPlot.DEFAULT_VALUE_LABEL_FONT;
        lineAndShapeRenderer0.setBaseItemLabelFont(font3, true);
        java.awt.Paint paint7 = lineAndShapeRenderer0.lookupSeriesFillPaint((-10289251));
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextOutlineStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1, true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation(1);
        boolean boolean7 = categoryPlot0.isRangePannable();
        boolean boolean8 = categoryPlot0.isDomainPannable();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        try {
            categoryPlot0.setDomainAxisLocation(axisLocation9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke3 = defaultDrawingSupplier2.getNextOutlineStroke();
        categoryPlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier2, true);
        java.awt.Paint paint6 = defaultDrawingSupplier2.getNextPaint();
        boolean boolean7 = datasetRenderingOrder0.equals((java.lang.Object) paint6);
        java.lang.String str8 = datasetRenderingOrder0.toString();
        java.awt.Color color9 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis10.getTickLabelInsets();
        float float12 = categoryAxis10.getTickMarkInsideLength();
        categoryAxis10.setLabel("");
        categoryAxis10.setLabel("{0}");
        java.awt.Stroke stroke17 = categoryAxis10.getAxisLineStroke();
        boolean boolean18 = color9.equals((java.lang.Object) categoryAxis10);
        java.awt.Paint paint19 = categoryAxis10.getAxisLinePaint();
        categoryAxis10.setTickMarksVisible(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions22 = categoryAxis10.getCategoryLabelPositions();
        boolean boolean23 = datasetRenderingOrder0.equals((java.lang.Object) categoryLabelPositions22);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str8.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 0.0f + "'", float12 == 0.0f);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(categoryLabelPositions22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        keyedObjects2D0.clear();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = new org.jfree.chart.axis.CategoryAxis();
        float float3 = categoryAxis2.getTickMarkOutsideLength();
        categoryAxis2.setCategoryMargin((double) 8);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color7 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot6.setNoDataMessagePaint((java.awt.Paint) color7);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int10 = categoryPlot6.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color13 = java.awt.Color.WHITE;
        boolean boolean14 = plotOrientation12.equals((java.lang.Object) color13);
        int int15 = color13.getBlue();
        lineAndShapeRenderer9.setSeriesFillPaint(1, (java.awt.Paint) color13);
        categoryAxis2.setTickMarkPaint((java.awt.Paint) color13);
        java.awt.Stroke stroke18 = categoryAxis2.getTickMarkStroke();
        keyedObjects2D0.addObject((java.lang.Object) stroke18, (java.lang.Comparable) "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", (java.lang.Comparable) 32.0f);
        try {
            java.lang.Object obj24 = keyedObjects2D0.getObject((java.lang.Comparable) '4', (java.lang.Comparable) (-4194304));
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (4) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 2.0f + "'", float3 == 2.0f);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getMinorTickMarkInsideLength();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color3);
        categoryAxis0.setTickMarkInsideLength((float) (-10289251));
        float float7 = categoryAxis0.getTickMarkOutsideLength();
        float float8 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 2.0f + "'", float7 == 2.0f);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double5 = rectangleInsets3.calculateTopInset((double) 10);
        java.lang.String str6 = rectangleInsets3.toString();
        double double8 = rectangleInsets3.trimWidth(0.0d);
        categoryAxis0.setLabelInsets(rectangleInsets3, true);
        double double11 = categoryAxis0.getLabelAngle();
        java.lang.String str13 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) (short) 100);
        categoryAxis0.setVisible(false);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str6.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-16.0d) + "'", double8 == (-16.0d));
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNull(str13);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        categoryPlot2.setBackgroundAlpha((float) 8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean24 = lineAndShapeRenderer21.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer21.setPlot(categoryPlot25);
        categoryPlot25.setBackgroundImageAlignment((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot25.zoomDomainAxes((double) 0.0f, plotRenderingInfo30, point2D31, true);
        categoryPlot2.setParent((org.jfree.chart.plot.Plot) categoryPlot25);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace36 = categoryPlot35.getFixedRangeAxisSpace();
        boolean boolean37 = categoryPlot35.isRangePannable();
        java.awt.Paint paint38 = categoryPlot35.getRangeMinorGridlinePaint();
        categoryPlot25.setRangeGridlinePaint(paint38);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNull(axisSpace36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(paint38);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        barRenderer12.setDrawBarOutline(false);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = legendItem18.getFillPaintTransformer();
        barRenderer12.setGradientPaintTransformer(gradientPaintTransformer19);
        double double21 = barRenderer12.getMinimumBarLength();
        java.awt.Paint paint22 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        barRenderer12.setShadowPaint(paint22);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets25 = categoryAxis24.getTickLabelInsets();
        float float26 = categoryAxis24.getTickMarkInsideLength();
        categoryAxis24.setLabel("");
        categoryAxis24.setLabel("{0}");
        java.awt.Font font31 = categoryAxis24.getTickLabelFont();
        barRenderer12.setBaseItemLabelFont(font31);
        double double33 = barRenderer12.getBase();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(paint22);
        org.junit.Assert.assertNotNull(rectangleInsets25);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 0.0f + "'", float26 == 0.0f);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot4.setNoDataMessagePaint((java.awt.Paint) color5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int8 = categoryPlot4.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        lineAndShapeRenderer7.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Paint paint12 = lineAndShapeRenderer7.getSeriesOutlinePaint((int) (byte) 0);
        boolean boolean13 = lineAndShapeRenderer7.getBaseSeriesVisible();
        java.awt.Shape shape15 = lineAndShapeRenderer7.lookupLegendShape((-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace17 = categoryPlot16.getFixedRangeAxisSpace();
        boolean boolean18 = categoryPlot16.isRangePannable();
        java.awt.Paint paint19 = categoryPlot16.getRangeMinorGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset20 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer21 = categoryPlot16.getRendererForDataset(categoryDataset20);
        org.jfree.chart.axis.AxisSpace axisSpace22 = categoryPlot16.getFixedDomainAxisSpace();
        java.awt.Stroke stroke23 = categoryPlot16.getDomainCrosshairStroke();
        java.awt.Paint paint24 = null;
        try {
            org.jfree.chart.LegendItem legendItem25 = new org.jfree.chart.LegendItem(attributedString0, "{0}", "ItemLabelAnchor.INSIDE11", "DatasetRenderingOrder.FORWARD", shape15, stroke23, paint24);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNull(axisSpace17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNull(categoryItemRenderer21);
        org.junit.Assert.assertNull(axisSpace22);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean1 = renderAttributes0.getDefaultCreateEntity();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) false);
        java.awt.Shape shape4 = renderAttributes0.getDefaultShape();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color6 = java.awt.Color.WHITE;
        boolean boolean7 = plotOrientation5.equals((java.lang.Object) color6);
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color6);
        java.awt.Shape shape10 = renderAttributes0.getSeriesShape(255);
        java.awt.Stroke stroke11 = renderAttributes0.getDefaultStroke();
        java.awt.Shape shape12 = renderAttributes0.getDefaultShape();
        org.junit.Assert.assertNull(boolean1);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNull(shape12);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        java.awt.Stroke stroke5 = lineAndShapeRenderer0.getSeriesStroke(0);
        lineAndShapeRenderer0.setSeriesLinesVisible((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        lineAndShapeRenderer0.setSeriesItemLabelGenerator(10, categoryItemLabelGenerator10, true);
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        categoryPlot15.clearRangeAxes();
        org.jfree.chart.plot.Marker marker24 = null;
        org.jfree.chart.util.Layer layer25 = null;
        boolean boolean26 = categoryPlot15.removeDomainMarker((int) (short) 10, marker24, layer25);
        int int27 = categoryPlot15.getWeight();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset28 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        float float30 = categoryAxis29.getTickMarkOutsideLength();
        categoryAxis29.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke37 = lineAndShapeRenderer35.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint39 = lineAndShapeRenderer35.lookupLegendTextPaint((int) '#');
        boolean boolean40 = lineAndShapeRenderer35.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot43.setNoDataMessagePaint((java.awt.Paint) color44);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = categoryPlot43.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray48 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis47 };
        categoryPlot43.setDomainAxes(categoryAxisArray48);
        java.awt.Stroke stroke50 = categoryPlot43.getDomainCrosshairStroke();
        categoryPlot42.setDomainGridlineStroke(stroke50);
        lineAndShapeRenderer35.setSeriesOutlineStroke((int) ' ', stroke50, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset28, categoryAxis29, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer35);
        int int56 = defaultCategoryDataset28.getRowIndex((java.lang.Comparable) (-4194304));
        java.lang.Object obj57 = defaultCategoryDataset28.clone();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo58 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState59 = lineAndShapeRenderer0.initialise(graphics2D13, rectangle2D14, categoryPlot15, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset28, plotRenderingInfo58);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 2.0f + "'", float30 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(categoryAxisArray48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertNotNull(obj57);
        org.junit.Assert.assertNotNull(categoryItemRendererState59);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setLabelAngle(100.0d);
        categoryPlot0.setDomainAxis((int) (short) 100, categoryAxis5, true);
        java.lang.String str10 = categoryAxis5.getLabelToolTip();
        java.lang.String str11 = categoryAxis5.getLabelToolTip();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis5.getLabelInsets();
        double double14 = rectangleInsets12.calculateBottomInset((double) 1L);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 3.0d + "'", double14 == 3.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
        java.lang.Object obj1 = standardCategorySeriesLabelGenerator0.clone();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset2 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        float float4 = categoryAxis3.getTickMarkOutsideLength();
        categoryAxis3.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis3.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer9 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke11 = lineAndShapeRenderer9.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint13 = lineAndShapeRenderer9.lookupLegendTextPaint((int) '#');
        boolean boolean14 = lineAndShapeRenderer9.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot17.setNoDataMessagePaint((java.awt.Paint) color18);
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = categoryPlot17.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis21 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray22 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis21 };
        categoryPlot17.setDomainAxes(categoryAxisArray22);
        java.awt.Stroke stroke24 = categoryPlot17.getDomainCrosshairStroke();
        categoryPlot16.setDomainGridlineStroke(stroke24);
        lineAndShapeRenderer9.setSeriesOutlineStroke((int) ' ', stroke24, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2, categoryAxis3, valueAxis8, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer9);
        int int30 = defaultCategoryDataset2.getRowIndex((java.lang.Comparable) (-4194304));
        defaultCategoryDataset2.clear();
        defaultCategoryDataset2.setValue(0.0d, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) "TextAnchor.CENTER");
        java.lang.Object obj36 = defaultCategoryDataset2.clone();
        java.lang.String str38 = standardCategorySeriesLabelGenerator0.generateLabel((org.jfree.data.category.CategoryDataset) defaultCategoryDataset2, 0);
        defaultCategoryDataset2.addValue((java.lang.Number) 100.0d, (java.lang.Comparable) "AxisLocation.TOP_OR_RIGHT", (java.lang.Comparable) "poly");
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 2.0f + "'", float4 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(categoryAxisArray22);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertNotNull(obj36);
        org.junit.Assert.assertTrue("'" + str38 + "' != '" + "UnitType.ABSOLUTE" + "'", str38.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        java.awt.Color color0 = java.awt.Color.lightGray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemLabelPaint((int) (byte) 10, (int) (byte) -1, false);
        int int9 = lineAndShapeRenderer0.getPassCount();
        lineAndShapeRenderer0.clearSeriesStrokes(true);
        boolean boolean13 = lineAndShapeRenderer0.isSeriesVisible(100);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getTickMarkOutsideLength();
        categoryAxis0.setCategoryMargin((double) 8);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot4.setNoDataMessagePaint((java.awt.Paint) color5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int8 = categoryPlot4.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color11 = java.awt.Color.WHITE;
        boolean boolean12 = plotOrientation10.equals((java.lang.Object) color11);
        int int13 = color11.getBlue();
        lineAndShapeRenderer7.setSeriesFillPaint(1, (java.awt.Paint) color11);
        categoryAxis0.setTickMarkPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke16 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.setCategoryLabelPositionOffset((int) (short) 1);
        org.jfree.chart.plot.Plot plot19 = categoryAxis0.getPlot();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) 255);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0f + "'", float1 == 2.0f);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(plot19);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean2 = legendItem1.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int7 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean8 = legendItem1.equals((java.lang.Object) categoryPlot3);
        boolean boolean9 = categoryPlot3.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot3.zoomRangeAxes(4.0d, plotRenderingInfo11, point2D12, false);
        categoryPlot3.configureDomainAxes();
        org.jfree.chart.util.RectangleInsets rectangleInsets16 = null;
        try {
            categoryPlot3.setInsets(rectangleInsets16, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer12.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        barRenderer12.setSeriesURLGenerator(10, categoryURLGenerator19, false);
        int int22 = barRenderer12.getRowCount();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        categoryPlot29.setRangeCrosshairVisible(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean47 = lineAndShapeRenderer44.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer44.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color50 = java.awt.Color.darkGray;
        lineAndShapeRenderer44.setBaseOutlinePaint((java.awt.Paint) color50, false);
        categoryPlot29.setOutlinePaint((java.awt.Paint) color50);
        org.jfree.chart.axis.ValueAxis valueAxis55 = categoryPlot29.getRangeAxis((int) (short) 10);
        int int56 = categoryPlot29.getBackgroundImageAlignment();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertNull(valueAxis55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 15 + "'", int56 == 15);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setLabel("");
        categoryAxis0.setLabel("{0}");
        java.awt.Stroke stroke7 = categoryAxis0.getAxisLineStroke();
        double double8 = categoryAxis0.getLabelAngle();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (short) -1, "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]");
        categoryAxis0.setCategoryMargin((double) 10L);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot2.getDomainMarkers(layer19);
        java.awt.Stroke stroke21 = categoryPlot2.getRangeGridlineStroke();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot2.getFixedLegendItems();
        java.awt.Paint paint23 = categoryPlot2.getOutlinePaint();
        java.awt.Stroke stroke24 = categoryPlot2.getDomainGridlineStroke();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(legendItemCollection22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(stroke24);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextOutlineStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1, true);
        java.awt.Paint paint5 = defaultDrawingSupplier1.getNextPaint();
        java.awt.Shape shape6 = defaultDrawingSupplier1.getNextShape();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.Marker marker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        lineAndShapeRenderer7.drawRangeMarker(graphics2D8, categoryPlot9, valueAxis13, marker14, rectangle2D15);
        java.awt.Stroke stroke17 = categoryPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot9.zoomRangeAxes(8.0d, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.entity.PlotEntity plotEntity25 = new org.jfree.chart.entity.PlotEntity(shape6, (org.jfree.chart.plot.Plot) categoryPlot9, "", "PlotOrientation.HORIZONTAL");
        java.awt.Paint paint26 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_PAINT;
        boolean boolean27 = plotEntity25.equals((java.lang.Object) paint26);
        java.lang.Object obj28 = null;
        boolean boolean29 = plotEntity25.equals(obj28);
        java.lang.String str30 = plotEntity25.getToolTipText();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(paint26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "" + "'", str30.equals(""));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape2 = legendItem1.getLine();
        java.lang.String str3 = legendItem1.getDescription();
        java.awt.Color color4 = java.awt.Color.white;
        legendItem1.setOutlinePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.BarRenderer barRenderer6 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean7 = barRenderer6.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint9 = barRenderer6.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator13 = barRenderer6.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = null;
        barRenderer6.setBaseURLGenerator(categoryURLGenerator14);
        barRenderer6.setMaximumBarWidth((double) 0.0f);
        java.awt.Paint paint18 = barRenderer6.getShadowPaint();
        double double19 = barRenderer6.getMinimumBarLength();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator21 = null;
        barRenderer6.setSeriesItemLabelGenerator(35, categoryItemLabelGenerator21);
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset23 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        float float25 = categoryAxis24.getTickMarkOutsideLength();
        categoryAxis24.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets28 = categoryAxis24.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer30 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke32 = lineAndShapeRenderer30.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint34 = lineAndShapeRenderer30.lookupLegendTextPaint((int) '#');
        boolean boolean35 = lineAndShapeRenderer30.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color39 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot38.setNoDataMessagePaint((java.awt.Paint) color39);
        org.jfree.chart.util.RectangleInsets rectangleInsets41 = categoryPlot38.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis42 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray43 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis42 };
        categoryPlot38.setDomainAxes(categoryAxisArray43);
        java.awt.Stroke stroke45 = categoryPlot38.getDomainCrosshairStroke();
        categoryPlot37.setDomainGridlineStroke(stroke45);
        lineAndShapeRenderer30.setSeriesOutlineStroke((int) ' ', stroke45, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23, categoryAxis24, valueAxis29, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer30);
        int int51 = defaultCategoryDataset23.getRowIndex((java.lang.Comparable) (-4194304));
        java.lang.Object obj52 = defaultCategoryDataset23.clone();
        org.jfree.data.Range range53 = barRenderer6.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultCategoryDataset23);
        org.jfree.data.general.DatasetGroup datasetGroup55 = new org.jfree.data.general.DatasetGroup("hi!");
        java.lang.Object obj56 = datasetGroup55.clone();
        defaultCategoryDataset23.setGroup(datasetGroup55);
        boolean boolean58 = color4.equals((java.lang.Object) datasetGroup55);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertNull(categoryItemLabelGenerator13);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets28);
        org.junit.Assert.assertNotNull(stroke32);
        org.junit.Assert.assertNull(paint34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(rectangleInsets41);
        org.junit.Assert.assertNotNull(categoryAxisArray43);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
        org.junit.Assert.assertNotNull(obj52);
        org.junit.Assert.assertNull(range53);
        org.junit.Assert.assertNotNull(obj56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace4 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace4);
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge();
        boolean boolean7 = categoryPlot0.isOutlineVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint4 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '#');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor6);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor8 = itemLabelPosition7.getItemLabelAnchor();
        lineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition7);
        java.awt.Stroke stroke10 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LINE_STROKE;
        lineAndShapeRenderer0.setBaseStroke(stroke10);
        boolean boolean12 = lineAndShapeRenderer0.getUseSeriesOffset();
        java.lang.Boolean boolean14 = lineAndShapeRenderer0.getSeriesLinesVisible((int) (short) 100);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(itemLabelAnchor8);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNull(boolean14);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        barRenderer0.setMaximumBarWidth((double) 0.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition12 = barRenderer0.getPositiveItemLabelPositionFallback();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNull(itemLabelPosition12);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer12.getBaseNegativeItemLabelPosition();
        barRenderer12.setShadowYOffset((double) (-1L));
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer12.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color20);
        int int22 = color20.getRGB();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-8388480) + "'", int22 == (-8388480));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean2 = legendItem1.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int7 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean8 = legendItem1.equals((java.lang.Object) categoryPlot3);
        java.awt.Color color9 = java.awt.Color.magenta;
        categoryPlot3.setRangeCrosshairPaint((java.awt.Paint) color9);
        float float11 = categoryPlot3.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 1.0f + "'", float11 == 1.0f);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        java.lang.Object obj2 = keyedObjects0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer0.setPlot(categoryPlot4);
        categoryPlot4.setBackgroundImageAlignment((int) (short) 0);
        java.util.List list8 = categoryPlot4.getAnnotations();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryPlot4.getInsets();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNotNull(rectangleInsets9);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        java.awt.Paint paint3 = categoryAxis0.getLabelPaint();
        categoryAxis0.setFixedDimension((double) 0);
        boolean boolean6 = categoryAxis0.isTickMarksVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot7.setNoDataMessagePaint((java.awt.Paint) color8);
        categoryPlot7.setCrosshairDatasetIndex((int) (byte) 0, false);
        categoryPlot7.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot7.zoomRangeAxes((double) (-1), (double) 10.0f, plotRenderingInfo17, point2D18);
        categoryPlot7.setDomainGridlinesVisible(false);
        categoryPlot7.clearAnnotations();
        categoryAxis0.addChangeListener((org.jfree.chart.event.AxisChangeListener) categoryPlot7);
        categoryPlot7.setDomainCrosshairColumnKey((java.lang.Comparable) 8);
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color28 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot27.setNoDataMessagePaint((java.awt.Paint) color28);
        categoryPlot27.setCrosshairDatasetIndex((int) (byte) 0, false);
        categoryPlot27.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        categoryPlot27.zoomRangeAxes((double) (-1), (double) 10.0f, plotRenderingInfo37, point2D38);
        categoryPlot27.setDomainGridlinesVisible(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot43.setNoDataMessagePaint((java.awt.Paint) color44);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator49 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color44, (float) ' ', (int) (byte) 0, (double) (-1));
        java.awt.Color color50 = defaultShadowGenerator49.getShadowColor();
        float float51 = defaultShadowGenerator49.getShadowOpacity();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer52 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D53 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot54.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis58 = null;
        org.jfree.chart.plot.Marker marker59 = null;
        java.awt.geom.Rectangle2D rectangle2D60 = null;
        lineAndShapeRenderer52.drawRangeMarker(graphics2D53, categoryPlot54, valueAxis58, marker59, rectangle2D60);
        org.jfree.chart.axis.AxisLocation axisLocation63 = null;
        categoryPlot54.setRangeAxisLocation((int) (short) 100, axisLocation63, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier68 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke69 = defaultDrawingSupplier68.getNextOutlineStroke();
        categoryPlot67.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier68, true);
        org.jfree.chart.axis.AxisLocation axisLocation73 = categoryPlot67.getDomainAxisLocation(1);
        categoryPlot54.setDomainAxisLocation(0, axisLocation73);
        org.jfree.chart.axis.AxisLocation axisLocation75 = axisLocation73.getOpposite();
        boolean boolean76 = defaultShadowGenerator49.equals((java.lang.Object) axisLocation75);
        boolean boolean77 = categoryPlot27.equals((java.lang.Object) axisLocation75);
        categoryPlot7.setDomainAxisLocation((int) (byte) 1, axisLocation75);
        java.lang.String str79 = axisLocation75.toString();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(color50);
        org.junit.Assert.assertTrue("'" + float51 + "' != '" + 32.0f + "'", float51 == 32.0f);
        org.junit.Assert.assertNotNull(stroke69);
        org.junit.Assert.assertNotNull(axisLocation73);
        org.junit.Assert.assertNotNull(axisLocation75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "AxisLocation.BOTTOM_OR_LEFT" + "'", str79.equals("AxisLocation.BOTTOM_OR_LEFT"));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color2);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color2, (float) ' ', (int) (byte) 0, (double) (-1));
        java.awt.Color color8 = defaultShadowGenerator7.getShadowColor();
        java.awt.Color color9 = defaultShadowGenerator7.getShadowColor();
        int int10 = defaultShadowGenerator7.getDistance();
        int int11 = defaultShadowGenerator7.getDistance();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean1 = renderAttributes0.getDefaultCreateEntity();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) false);
        java.awt.Shape shape4 = renderAttributes0.getDefaultShape();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color6 = java.awt.Color.WHITE;
        boolean boolean7 = plotOrientation5.equals((java.lang.Object) color6);
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color6);
        java.awt.Shape shape10 = renderAttributes0.getSeriesShape(255);
        java.awt.Stroke stroke11 = renderAttributes0.getDefaultStroke();
        java.awt.Stroke stroke13 = renderAttributes0.getSeriesStroke((int) (byte) -1);
        java.lang.Boolean boolean14 = renderAttributes0.getDefaultLabelVisible();
        org.junit.Assert.assertNull(boolean1);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(shape10);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14.equals(false));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot29.getRangeAxisEdge(100);
        categoryPlot29.setCrosshairDatasetIndex(100, true);
        org.jfree.chart.axis.AxisLocation axisLocation47 = categoryPlot29.getRangeAxisLocation();
        org.jfree.data.category.CategoryDataset categoryDataset48 = categoryPlot29.getDataset();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNull(categoryDataset48);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color6 = java.awt.Color.darkGray;
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color6, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, true);
        lineAndShapeRenderer0.setDrawOutlines(false);
        int int14 = lineAndShapeRenderer0.getDefaultEntityRadius();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer12.getBaseNegativeItemLabelPosition();
        barRenderer12.setShadowYOffset((double) (-1L));
        java.awt.Shape shape20 = barRenderer12.lookupSeriesShape((int) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity23 = new org.jfree.chart.entity.ChartEntity(shape20, "ItemLabelAnchor.INSIDE11", "UnitType.ABSOLUTE");
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(shape20);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        lineAndShapeRenderer14.drawRangeMarker(graphics2D15, categoryPlot16, valueAxis20, marker21, rectangle2D22);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot16.getDomainMarkers(layer24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot16.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo28, point2D29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot16.setFixedDomainAxisSpace(axisSpace31);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean37 = lineAndShapeRenderer34.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer34.setPlot(categoryPlot38);
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        barRenderer12.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        java.util.List list42 = categoryPlot16.getCategories();
        java.awt.Stroke stroke43 = categoryPlot16.getRangeMinorGridlineStroke();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot16.getDomainAxisEdge((int) (byte) 100);
        org.jfree.chart.plot.Marker marker47 = null;
        org.jfree.chart.util.Layer layer48 = null;
        try {
            categoryPlot16.addRangeMarker(10, marker47, layer48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(list42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(rectangleEdge45);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double5 = rectangleInsets3.calculateTopInset((double) 10);
        java.lang.String str6 = rectangleInsets3.toString();
        double double8 = rectangleInsets3.trimWidth(0.0d);
        categoryAxis0.setLabelInsets(rectangleInsets3, true);
        float float11 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        categoryAxis0.setLabelAngle(26.0d);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryAxis0.getLabelInsets();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]" + "'", str6.equals("RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]"));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-16.0d) + "'", double8 == (-16.0d));
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 0.0f + "'", float11 == 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = null;
        lineAndShapeRenderer20.setBaseToolTipGenerator(categoryToolTipGenerator27);
        boolean boolean29 = lineAndShapeRenderer20.getBaseLinesVisible();
        double double30 = lineAndShapeRenderer20.getItemLabelAnchorOffset();
        lineAndShapeRenderer20.setSeriesVisible(8, (java.lang.Boolean) true, true);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.0d + "'", double30 == 2.0d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.lang.Object obj5 = categoryPlot0.clone();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getRangeMarkers(layer6);
        categoryPlot0.setRangePannable(true);
        int int10 = categoryPlot0.getRendererCount();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        lineAndShapeRenderer11.drawRangeMarker(graphics2D12, categoryPlot13, valueAxis17, marker18, rectangle2D19);
        org.jfree.chart.axis.AxisLocation axisLocation22 = null;
        categoryPlot13.setRangeAxisLocation((int) (short) 100, axisLocation22, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier27 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke28 = defaultDrawingSupplier27.getNextOutlineStroke();
        categoryPlot26.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier27, true);
        org.jfree.chart.axis.AxisLocation axisLocation32 = categoryPlot26.getDomainAxisLocation(1);
        categoryPlot13.setDomainAxisLocation(0, axisLocation32);
        org.jfree.chart.axis.AxisLocation axisLocation34 = axisLocation32.getOpposite();
        categoryPlot0.setRangeAxisLocation(axisLocation32);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNotNull(axisLocation32);
        org.junit.Assert.assertNotNull(axisLocation34);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        boolean boolean2 = textAnchor0.equals((java.lang.Object) 9.0d);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        lineAndShapeRenderer14.drawRangeMarker(graphics2D15, categoryPlot16, valueAxis20, marker21, rectangle2D22);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot16.getDomainMarkers(layer24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot16.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo28, point2D29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot16.setFixedDomainAxisSpace(axisSpace31);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean37 = lineAndShapeRenderer34.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer34.setPlot(categoryPlot38);
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        barRenderer12.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        java.awt.Shape shape43 = barRenderer12.lookupSeriesShape(2);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(shape43);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setLabelAngle(100.0d);
        categoryPlot0.setDomainAxis((int) (short) 100, categoryAxis5, true);
        java.awt.Color color10 = java.awt.Color.DARK_GRAY;
        java.awt.Color color11 = color10.brighter();
        categoryAxis5.setLabelPaint((java.awt.Paint) color11);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(color11);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke14 = defaultDrawingSupplier13.getNextOutlineStroke();
        categoryPlot12.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier13, true);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot12.getDomainAxisLocation(1);
        org.jfree.chart.axis.AxisLocation axisLocation19 = axisLocation18.getOpposite();
        boolean boolean20 = lineAndShapeRenderer0.equals((java.lang.Object) axisLocation19);
        boolean boolean21 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = lineAndShapeRenderer0.getLegendItems();
        int int23 = legendItemCollection22.getItemCount();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 0, false);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) (-1), (double) 10.0f, plotRenderingInfo10, point2D11);
        categoryPlot0.setDomainGridlinesVisible(false);
        categoryPlot0.clearAnnotations();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        barRenderer0.setMaximumBarWidth((double) 0.0f);
        java.awt.Paint paint12 = barRenderer0.getShadowPaint();
        double double13 = barRenderer0.getMinimumBarLength();
        barRenderer0.setShadowYOffset((double) '#');
        barRenderer0.setBaseItemLabelsVisible(true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

//    @Test
//    public void test432() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test432");
//        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//        java.awt.Graphics2D graphics2D1 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
//        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
//        org.jfree.chart.plot.Marker marker7 = null;
//        java.awt.geom.Rectangle2D rectangle2D8 = null;
//        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
//        org.jfree.chart.util.Layer layer10 = null;
//        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
//        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
//        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
//        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
//        barRenderer12.setAutoPopulateSeriesStroke(true);
//        boolean boolean18 = barRenderer12.getDataBoundsIncludesVisibleSeriesOnly();
//        boolean boolean19 = barRenderer12.getShadowsVisible();
//        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier22 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//        java.awt.Stroke stroke23 = defaultDrawingSupplier22.getNextOutlineStroke();
//        categoryPlot21.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier22, true);
//        java.awt.Paint paint26 = defaultDrawingSupplier22.getNextPaint();
//        java.awt.Shape shape27 = defaultDrawingSupplier22.getNextShape();
//        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
//        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
//        categoryPlot28.setNoDataMessagePaint((java.awt.Paint) color29);
//        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryPlot28.getInsets();
//        org.jfree.chart.axis.AxisSpace axisSpace32 = categoryPlot28.getFixedDomainAxisSpace();
//        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
//        java.awt.Graphics2D graphics2D34 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
//        categoryPlot35.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
//        org.jfree.chart.axis.ValueAxis valueAxis39 = null;
//        org.jfree.chart.plot.Marker marker40 = null;
//        java.awt.geom.Rectangle2D rectangle2D41 = null;
//        lineAndShapeRenderer33.drawRangeMarker(graphics2D34, categoryPlot35, valueAxis39, marker40, rectangle2D41);
//        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier43 = new org.jfree.chart.plot.DefaultDrawingSupplier();
//        java.awt.Stroke stroke44 = defaultDrawingSupplier43.getNextOutlineStroke();
//        categoryPlot35.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier43);
//        categoryPlot28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier43);
//        org.jfree.chart.plot.CategoryPlot categoryPlot47 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisSpace axisSpace48 = categoryPlot47.getFixedRangeAxisSpace();
//        boolean boolean49 = defaultDrawingSupplier43.equals((java.lang.Object) categoryPlot47);
//        categoryPlot47.clearRangeAxes();
//        org.jfree.chart.entity.PlotEntity plotEntity53 = new org.jfree.chart.entity.PlotEntity(shape27, (org.jfree.chart.plot.Plot) categoryPlot47, "ChartChangeEventType.GENERAL", "GradientPaintTransformType.CENTER_VERTICAL");
//        barRenderer12.setSeriesShape(10, shape27, true);
//        java.awt.Stroke stroke57 = barRenderer12.lookupSeriesOutlineStroke((int) 'a');
//        org.junit.Assert.assertNull(collection11);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
//        org.junit.Assert.assertNotNull(stroke23);
//        org.junit.Assert.assertNotNull(paint26);
//        org.junit.Assert.assertNotNull(shape27);
//        org.junit.Assert.assertNotNull(color29);
//        org.junit.Assert.assertNotNull(rectangleInsets31);
//        org.junit.Assert.assertNull(axisSpace32);
//        org.junit.Assert.assertNotNull(stroke44);
//        org.junit.Assert.assertNull(axisSpace48);
//        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
//        org.junit.Assert.assertNotNull(stroke57);
//    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        java.awt.Color color0 = java.awt.Color.BLUE;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        java.awt.Color color7 = java.awt.Color.gray;
        java.awt.Color color8 = java.awt.Color.ORANGE;
        java.awt.Color color9 = color8.brighter();
        float[] floatArray14 = new float[] { (-10289251), (-1.0f), 2.0f, 0.0f };
        float[] floatArray15 = color9.getComponents(floatArray14);
        float[] floatArray16 = color7.getColorComponents(floatArray15);
        float[] floatArray17 = color0.getComponents(floatArray16);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        lineAndShapeRenderer0.setSeriesShapesFilled(0, (java.lang.Boolean) false);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator17);
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color19);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition43 = null;
        lineAndShapeRenderer20.setSeriesPositiveItemLabelPosition((int) '#', itemLabelPosition43, true);
        try {
            org.jfree.chart.LegendItem legendItem48 = lineAndShapeRenderer20.getLegendItem(2, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer5);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent7 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.Plot plot8 = plotChangeEvent7.getPlot();
        org.jfree.chart.JFreeChart jFreeChart9 = null;
        plotChangeEvent7.setChart(jFreeChart9);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(plot8);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot0.setRangeAxis(valueAxis5);
        categoryPlot0.setRangeCrosshairValue((double) '#');
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        lineAndShapeRenderer11.drawRangeMarker(graphics2D12, categoryPlot13, valueAxis17, marker18, rectangle2D19);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot13.getDomainMarkers(layer21);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot13.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer23);
        boolean boolean26 = barRenderer23.isSeriesVisible((int) (short) -1);
        barRenderer23.setAutoPopulateSeriesStroke(true);
        boolean boolean29 = barRenderer23.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer23.setShadowPaint((java.awt.Paint) color30);
        barRenderer23.setMaximumBarWidth((double) 2.0f);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = null;
        barRenderer23.setBaseToolTipGenerator(categoryToolTipGenerator34, true);
        org.jfree.chart.LegendItem legendItem38 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape39 = legendItem38.getLine();
        java.awt.Font font40 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem38.setLabelFont(font40);
        barRenderer23.setBaseItemLabelFont(font40);
        categoryPlot0.setRenderer(2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer23);
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(font40);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets2 = categoryAxis1.getTickLabelInsets();
        float float3 = categoryAxis1.getTickMarkInsideLength();
        categoryAxis1.setLabel("");
        categoryAxis1.setLabel("{0}");
        java.awt.Stroke stroke8 = categoryAxis1.getAxisLineStroke();
        boolean boolean9 = color0.equals((java.lang.Object) categoryAxis1);
        java.awt.Paint paint10 = categoryAxis1.getAxisLinePaint();
        categoryAxis1.setTickMarksVisible(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions13 = categoryAxis1.getCategoryLabelPositions();
        java.lang.String str14 = categoryAxis1.getLabelToolTip();
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean20 = legendItem19.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot21.setNoDataMessagePaint((java.awt.Paint) color22);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int25 = categoryPlot21.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer24);
        boolean boolean26 = legendItem19.equals((java.lang.Object) categoryPlot21);
        boolean boolean27 = categoryPlot21.isRangeZeroBaselineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot21.getRendererForDataset(categoryDataset28);
        categoryPlot21.setDomainCrosshairColumnKey((java.lang.Comparable) false);
        categoryPlot21.setAnchorValue(8.0d, false);
        org.jfree.chart.util.RectangleEdge rectangleEdge35 = categoryPlot21.getDomainAxisEdge();
        try {
            double double36 = categoryAxis1.getCategoryMiddle(10, 0, rectangle2D17, rectangleEdge35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid category index: 10");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(rectangleInsets2);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.0f + "'", float3 == 0.0f);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(categoryLabelPositions13);
        org.junit.Assert.assertNull(str14);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertNotNull(rectangleEdge35);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis4.setUpperMargin((double) (short) 0);
        org.jfree.chart.renderer.RenderAttributes renderAttributes7 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean8 = renderAttributes7.getDefaultCreateEntity();
        org.jfree.chart.axis.CategoryAxis categoryAxis9 = new org.jfree.chart.axis.CategoryAxis();
        float float10 = categoryAxis9.getTickMarkOutsideLength();
        categoryAxis9.setCategoryMargin((double) 8);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color14 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot13.setNoDataMessagePaint((java.awt.Paint) color14);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int17 = categoryPlot13.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer16);
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color20 = java.awt.Color.WHITE;
        boolean boolean21 = plotOrientation19.equals((java.lang.Object) color20);
        int int22 = color20.getBlue();
        lineAndShapeRenderer16.setSeriesFillPaint(1, (java.awt.Paint) color20);
        categoryAxis9.setTickMarkPaint((java.awt.Paint) color20);
        java.awt.Stroke stroke25 = categoryAxis9.getTickMarkStroke();
        renderAttributes7.setDefaultOutlineStroke(stroke25);
        categoryAxis4.setTickMarkStroke(stroke25);
        lineAndShapeRenderer0.setBaseOutlineStroke(stroke25, true);
        int int30 = lineAndShapeRenderer0.getColumnCount();
        lineAndShapeRenderer0.setBaseShapesVisible(false);
        org.junit.Assert.assertNull(boolean8);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 2.0f + "'", float10 == 2.0f);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1) + "'", int17 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double1 = rectangleInsets0.getLeft();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createAdjustedRectangle(rectangle2D2, lengthAdjustmentType3, lengthAdjustmentType4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) (-32640), (double) 'a', (double) 0, (double) (byte) 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer0.getPositiveItemLabelPosition((int) (short) 1, (int) (byte) 1, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = lineAndShapeRenderer0.getDrawingSupplier();
        try {
            lineAndShapeRenderer0.setSeriesCreateEntities((-35), (java.lang.Boolean) false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(drawingSupplier8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 0, false);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Paint paint8 = categoryPlot0.getNoDataMessagePaint();
        categoryPlot0.setBackgroundAlpha(100.0f);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        java.awt.Paint paint3 = categoryAxis0.getLabelPaint();
        org.jfree.chart.plot.Plot plot4 = categoryAxis0.getPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot5.getInsets();
        double double10 = rectangleInsets8.calculateTopOutset((double) 1.0f);
        double double12 = rectangleInsets8.calculateLeftInset(100.0d);
        categoryAxis0.setTickLabelInsets(rectangleInsets8);
        categoryAxis0.setCategoryMargin((double) (short) -1);
        java.lang.String str17 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) '#');
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.0d + "'", double12 == 8.0d);
        org.junit.Assert.assertNull(str17);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color7 = java.awt.Color.WHITE;
        boolean boolean8 = plotOrientation6.equals((java.lang.Object) color7);
        int int9 = color7.getBlue();
        lineAndShapeRenderer3.setSeriesFillPaint(1, (java.awt.Paint) color7);
        boolean boolean11 = lineAndShapeRenderer3.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator12 = null;
        lineAndShapeRenderer3.setBaseItemLabelGenerator(categoryItemLabelGenerator12);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 0, false);
        float float6 = categoryPlot0.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.Marker marker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        lineAndShapeRenderer7.drawRangeMarker(graphics2D8, categoryPlot9, valueAxis13, marker14, rectangle2D15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot9.getDomainMarkers(layer17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19);
        boolean boolean22 = barRenderer19.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = barRenderer19.getLegendItemLabelGenerator();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        lineAndShapeRenderer24.drawRangeMarker(graphics2D25, categoryPlot26, valueAxis30, marker31, rectangle2D32);
        boolean boolean34 = barRenderer19.hasListener((java.util.EventListener) categoryPlot26);
        int int35 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19);
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 0.0f);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.5f + "'", float6 == 0.5f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator23);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        int int2 = keyedObjects2D0.getRowIndex((java.lang.Comparable) (-8.0d));
        java.lang.Object obj3 = keyedObjects2D0.clone();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator1 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator1);
        java.lang.Boolean boolean4 = lineAndShapeRenderer0.getSeriesCreateEntities((int) (byte) 0);
        org.junit.Assert.assertNull(boolean4);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle(100.0d);
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) (-32640), "DatasetRenderingOrder.FORWARD");
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) 100.0f);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getBaseCreateEntities();
        boolean boolean5 = lineAndShapeRenderer0.getUseFillPaint();
        java.awt.Paint paint7 = lineAndShapeRenderer0.getSeriesPaint((int) (byte) 10);
        java.awt.Font font11 = lineAndShapeRenderer0.getItemLabelFont((-32640), (-35), true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(paint7);
        org.junit.Assert.assertNotNull(font11);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape5, "AxisLocation.TOP_OR_RIGHT", "hi!");
        java.awt.Shape shape10 = chartEntity9.getArea();
        java.lang.String str11 = chartEntity9.getShapeType();
        java.lang.String str12 = chartEntity9.toString();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator13 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator14 = null;
        try {
            java.lang.String str15 = chartEntity9.getImageMapAreaTag(toolTipTagFragmentGenerator13, uRLTagFragmentGenerator14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "poly" + "'", str11.equals("poly"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "ChartEntity: tooltip = AxisLocation.TOP_OR_RIGHT" + "'", str12.equals("ChartEntity: tooltip = AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer3.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean7 = lineAndShapeRenderer3.getDrawOutlines();
        java.awt.Paint paint11 = lineAndShapeRenderer3.getItemLabelPaint((int) (byte) 10, (int) (byte) -1, false);
        int int12 = lineAndShapeRenderer3.getPassCount();
        java.lang.Boolean boolean14 = lineAndShapeRenderer3.getSeriesShapesFilled((-35));
        keyedObjects0.setObject((java.lang.Comparable) "{0}", (java.lang.Object) boolean14);
        java.util.List list16 = keyedObjects0.getKeys();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNull(boolean14);
        org.junit.Assert.assertNotNull(list16);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        lineAndShapeRenderer0.setSeriesShapesFilled(0, false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.lang.Object obj5 = categoryPlot0.clone();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getRangeMarkers(layer6);
        categoryPlot0.configureRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset9 = null;
        int int10 = categoryPlot0.indexOf(categoryDataset9);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor11 = categoryPlot0.getDomainGridlinePosition();
        java.awt.Paint paint12 = categoryPlot0.getOutlinePaint();
        org.jfree.chart.plot.CategoryMarker categoryMarker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker13, layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor11);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer12.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        java.awt.Color color19 = java.awt.Color.BLUE;
        barRenderer12.setSeriesItemLabelPaint((int) (short) 100, (java.awt.Paint) color19, true);
        java.awt.Font font23 = barRenderer12.getSeriesItemLabelFont(11);
        barRenderer12.setShadowVisible(false);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNull(font23);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        java.awt.Color color0 = java.awt.Color.blue;
        java.lang.Class<?> wildcardClass1 = color0.getClass();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke7 = defaultDrawingSupplier6.getNextOutlineStroke();
        categoryPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier6, true);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot5.getDomainAxisLocation(1);
        java.lang.String str12 = axisLocation11.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation11, plotOrientation13);
        org.jfree.chart.axis.AxisState axisState15 = null;
        categoryAxis0.drawTickMarks(graphics2D2, 0.05d, rectangle2D4, rectangleEdge14, axisState15);
        float float17 = categoryAxis0.getMinorTickMarkOutsideLength();
        java.lang.String str18 = categoryAxis0.getLabelToolTip();
        categoryAxis0.setLabelAngle((double) 1);
        float float21 = categoryAxis0.getMinorTickMarkOutsideLength();
        float float22 = categoryAxis0.getTickMarkInsideLength();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str12.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertTrue("'" + float17 + "' != '" + 2.0f + "'", float17 == 2.0f);
        org.junit.Assert.assertNull(str18);
        org.junit.Assert.assertTrue("'" + float21 + "' != '" + 2.0f + "'", float21 == 2.0f);
        org.junit.Assert.assertTrue("'" + float22 + "' != '" + 0.0f + "'", float22 == 0.0f);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        boolean boolean12 = lineAndShapeRenderer7.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        java.awt.Stroke stroke22 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot14.setDomainGridlineStroke(stroke22);
        lineAndShapeRenderer7.setSeriesOutlineStroke((int) ' ', stroke22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        int int28 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4194304));
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.setValue(0.0d, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) "TextAnchor.CENTER");
        java.lang.Object obj34 = null;
        boolean boolean35 = defaultCategoryDataset0.equals(obj34);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
    }
}

