import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.general.Dataset dataset1 = null;
        org.jfree.chart.event.DatasetChangeInfo datasetChangeInfo2 = null;
        try {
            org.jfree.data.event.DatasetChangeEvent datasetChangeEvent3 = new org.jfree.data.event.DatasetChangeEvent((java.lang.Object) 1.0d, dataset1, datasetChangeInfo2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'info' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = null;
        try {
            org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("", "hi!", "", "", shape4, paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        int int0 = java.awt.Transparency.OPAQUE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_CATEGORY_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape5 = null;
        java.awt.Paint paint7 = null;
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Stroke stroke10 = null;
        java.awt.Shape shape12 = null;
        java.awt.Stroke stroke13 = null;
        java.awt.Color color14 = java.awt.Color.ORANGE;
        try {
            org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem(attributedString0, "", "hi!", "", true, shape5, false, paint7, false, (java.awt.Paint) color9, stroke10, true, shape12, stroke13, (java.awt.Paint) color14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color14);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) true);
        java.awt.Paint paint4 = renderAttributes0.getSeriesFillPaint(1);
        java.awt.Font font6 = null;
        try {
            renderAttributes0.setSeriesLabelFont((int) 'a', font6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Color color5 = java.awt.Color.ORANGE;
        try {
            org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem(attributedString0, "", "", "hi!", shape4, (java.awt.Paint) color5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = null;
        try {
            categoryPlot0.setOrientation(plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(true);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker4 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        java.awt.Stroke stroke4 = null;
        try {
            lineAndShapeRenderer0.setBaseStroke(stroke4, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape2 = null;
        try {
            legendItem1.setLine(shape2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'line' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.DEFAULT_ITEM_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.2d + "'", double0 == 0.2d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createInsetRectangle(rectangle2D1, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_RED;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = null;
        try {
            categoryPlot0.setDomainAxisLocation(axisLocation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("");
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        float[] floatArray3 = new float[] { (short) 10, (byte) 1 };
        try {
            float[] floatArray4 = color0.getColorComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        lineAndShapeRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis10, marker11, rectangle2D12);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot6.getDomainMarkers(layer14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        boolean boolean19 = barRenderer16.isSeriesVisible((int) (short) -1);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape23 = legendItem22.getLine();
        barRenderer16.setSeriesShape(0, shape23, false);
        java.awt.Stroke stroke26 = null;
        java.awt.Color color27 = java.awt.Color.darkGray;
        try {
            org.jfree.chart.LegendItem legendItem28 = new org.jfree.chart.LegendItem("hi!", "", "", "hi!", shape23, stroke26, (java.awt.Paint) color27);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(shape23);
        org.junit.Assert.assertNotNull(color27);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        java.awt.Color color5 = java.awt.Color.WHITE;
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke7 = defaultDrawingSupplier6.getNextOutlineStroke();
        java.awt.Color color8 = java.awt.Color.blue;
        try {
            org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem(attributedString0, "hi!", "", "hi!", shape4, (java.awt.Paint) color5, stroke7, (java.awt.Paint) color8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.SortOrder sortOrder3 = null;
        try {
            categoryPlot0.setRowRenderingOrder(sortOrder3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'order' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = null;
        try {
            double double9 = lineAndShapeRenderer0.getItemMiddle((java.lang.Comparable) (short) 0, (java.lang.Comparable) 100, categoryDataset5, categoryAxis6, rectangle2D7, rectangleEdge8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        int int0 = org.jfree.chart.util.AbstractObjectList.DEFAULT_INITIAL_CAPACITY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        lineAndShapeRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis10, marker11, rectangle2D12);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot6.getDomainMarkers(layer14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot20.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis24 = null;
        org.jfree.chart.plot.Marker marker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        lineAndShapeRenderer18.drawRangeMarker(graphics2D19, categoryPlot20, valueAxis24, marker25, rectangle2D26);
        org.jfree.chart.util.Layer layer28 = null;
        java.util.Collection collection29 = categoryPlot20.getDomainMarkers(layer28);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo32 = null;
        java.awt.geom.Point2D point2D33 = null;
        categoryPlot20.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo32, point2D33);
        org.jfree.chart.axis.AxisSpace axisSpace35 = null;
        categoryPlot20.setFixedDomainAxisSpace(axisSpace35);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean41 = lineAndShapeRenderer38.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer38.setPlot(categoryPlot42);
        categoryPlot20.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer38);
        barRenderer16.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot20);
        org.jfree.chart.axis.CategoryAxis categoryAxis46 = null;
        org.jfree.chart.plot.CategoryMarker categoryMarker47 = null;
        java.awt.geom.Rectangle2D rectangle2D48 = null;
        try {
            lineAndShapeRenderer0.drawDomainMarker(graphics2D3, categoryPlot20, categoryAxis46, categoryMarker47, rectangle2D48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertNull(collection29);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        org.jfree.chart.axis.AxisLocation axisLocation0 = null;
        org.jfree.chart.plot.PlotOrientation plotOrientation1 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color2 = java.awt.Color.WHITE;
        boolean boolean3 = plotOrientation1.equals((java.lang.Object) color2);
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge4 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(plotOrientation1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer12.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        barRenderer12.setBaseFillPaint((java.awt.Paint) color18);
        try {
            org.jfree.chart.LegendItem legendItem22 = barRenderer12.getLegendItem(0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(color18);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType2 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createAdjustedRectangle(rectangle2D1, lengthAdjustmentType2, lengthAdjustmentType3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.renderer.category.BarRenderer.setDefaultBarPainter(barPainter14);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        lineAndShapeRenderer14.drawRangeMarker(graphics2D15, categoryPlot16, valueAxis20, marker21, rectangle2D22);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot16.getDomainMarkers(layer24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot16.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo28, point2D29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot16.setFixedDomainAxisSpace(axisSpace31);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean37 = lineAndShapeRenderer34.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer34.setPlot(categoryPlot38);
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        barRenderer12.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        categoryPlot16.clearDomainAxes();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = rectangleInsets0.createOutsetRectangle(rectangle2D1, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        categoryPlot0.clearDomainAxes();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation5 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        java.lang.Boolean boolean43 = lineAndShapeRenderer20.getSeriesLinesVisible((int) (byte) 10);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(boolean43);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.plot.CategoryMarker categoryMarker27 = null;
        org.jfree.chart.util.Layer layer28 = null;
        try {
            categoryPlot2.addDomainMarker(categoryMarker27, layer28);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        try {
            org.jfree.chart.LegendItem legendItem29 = lineAndShapeRenderer20.getLegendItem((int) '#', 8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = null;
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.data.category.CategoryDataset categoryDataset17 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D23 = lineAndShapeRenderer0.createHotSpotBounds(graphics2D12, rectangle2D13, categoryPlot14, categoryAxis15, valueAxis16, categoryDataset17, 0, (int) (short) 100, true, categoryItemRendererState21, rectangle2D22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        java.awt.geom.Point2D point2D9 = null;
        org.jfree.chart.plot.PlotState plotState10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        try {
            categoryPlot0.draw(graphics2D7, rectangle2D8, point2D9, plotState10, plotRenderingInfo11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        java.lang.Comparable comparable7 = legendItem1.getSeriesKey();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(comparable7);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getBaseCreateEntities();
        java.awt.Graphics2D graphics2D5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color8 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot7.setNoDataMessagePaint((java.awt.Paint) color8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int11 = categoryPlot7.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer10);
        java.lang.Object obj12 = categoryPlot7.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D21 = lineAndShapeRenderer0.createHotSpotBounds(graphics2D5, rectangle2D6, categoryPlot7, categoryAxis13, valueAxis14, categoryDataset15, 0, 1, true, categoryItemRendererState19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
        org.junit.Assert.assertNotNull(obj12);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean1 = categoryPlot0.isNotify();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        try {
            categoryPlot0.setRangeAxisLocation((int) (short) 0, axisLocation3, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        double double5 = rectangleInsets3.extendHeight((double) (byte) 1);
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets3.createOutsetRectangle(rectangle2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 9.0d + "'", double5 == 9.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        lineAndShapeRenderer14.drawRangeMarker(graphics2D15, categoryPlot16, valueAxis20, marker21, rectangle2D22);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot16.getDomainMarkers(layer24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot16.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo28, point2D29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot16.setFixedDomainAxisSpace(axisSpace31);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean37 = lineAndShapeRenderer34.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer34.setPlot(categoryPlot38);
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        barRenderer12.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        java.awt.Graphics2D graphics2D42 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState43 = null;
        java.awt.geom.Rectangle2D rectangle2D44 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot45 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color46 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot45.setNoDataMessagePaint((java.awt.Paint) color46);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer48 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int49 = categoryPlot45.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer48);
        java.lang.Object obj50 = categoryPlot45.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        try {
            barRenderer12.drawItem(graphics2D42, categoryItemRendererState43, rectangle2D44, categoryPlot45, categoryAxis51, valueAxis52, categoryDataset53, (-1), (int) (byte) 0, true, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(color46);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1) + "'", int49 == (-1));
        org.junit.Assert.assertNotNull(obj50);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer12.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        java.awt.Color color18 = org.jfree.chart.ChartColor.VERY_DARK_RED;
        barRenderer12.setBaseFillPaint((java.awt.Paint) color18);
        boolean boolean20 = barRenderer12.getAutoPopulateSeriesOutlinePaint();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        lineAndShapeRenderer24.drawRangeMarker(graphics2D25, categoryPlot26, valueAxis30, marker31, rectangle2D32);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot26.getDomainMarkers(layer34);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo38 = null;
        java.awt.geom.Point2D point2D39 = null;
        categoryPlot26.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo38, point2D39);
        org.jfree.chart.axis.AxisSpace axisSpace41 = null;
        categoryPlot26.setFixedDomainAxisSpace(axisSpace41);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer44 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean47 = lineAndShapeRenderer44.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot48 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer44.setPlot(categoryPlot48);
        categoryPlot26.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer44);
        org.jfree.chart.axis.CategoryAxis categoryAxis51 = null;
        org.jfree.chart.axis.ValueAxis valueAxis52 = null;
        org.jfree.data.category.CategoryDataset categoryDataset53 = null;
        try {
            barRenderer12.drawItem(graphics2D21, categoryItemRendererState22, rectangle2D23, categoryPlot26, categoryAxis51, valueAxis52, categoryDataset53, (int) '#', (int) (short) 1, false, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean1 = renderAttributes0.getDefaultCreateEntity();
        java.awt.Paint paint2 = renderAttributes0.getDefaultLabelPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        lineAndShapeRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis10, marker11, rectangle2D12);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot6.getDomainMarkers(layer14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        boolean boolean19 = barRenderer16.isSeriesVisible((int) (short) -1);
        org.jfree.chart.LegendItem legendItem22 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape23 = legendItem22.getLine();
        barRenderer16.setSeriesShape(0, shape23, false);
        try {
            renderAttributes0.setSeriesShape((int) (short) -1, shape23);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean1);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(shape23);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        barRenderer12.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) false, true);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color21 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot20.setNoDataMessagePaint((java.awt.Paint) color21);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int24 = categoryPlot20.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer23);
        java.lang.Object obj25 = categoryPlot20.clone();
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = null;
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D34 = barRenderer12.createHotSpotBounds(graphics2D18, rectangle2D19, categoryPlot20, categoryAxis26, valueAxis27, categoryDataset28, (int) 'a', (int) (short) -1, true, categoryItemRendererState32, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1) + "'", int24 == (-1));
        org.junit.Assert.assertNotNull(obj25);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE6;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        lineAndShapeRenderer15.drawRangeMarker(graphics2D16, categoryPlot17, valueAxis21, marker22, rectangle2D23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot17.setRangeAxisLocation((int) (short) 100, axisLocation26, false);
        java.awt.Color color29 = java.awt.Color.ORANGE;
        java.awt.Color color30 = color29.brighter();
        categoryPlot17.setRangeMinorGridlinePaint((java.awt.Paint) color30);
        boolean boolean32 = barRenderer12.hasListener((java.util.EventListener) categoryPlot17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot36.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.plot.Marker marker41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        lineAndShapeRenderer34.drawRangeMarker(graphics2D35, categoryPlot36, valueAxis40, marker41, rectangle2D42);
        org.jfree.chart.util.Layer layer44 = null;
        java.util.Collection collection45 = categoryPlot36.getDomainMarkers(layer44);
        org.jfree.chart.renderer.category.BarRenderer barRenderer46 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot36.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer46);
        boolean boolean49 = barRenderer46.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition50 = barRenderer46.getBaseNegativeItemLabelPosition();
        try {
            barRenderer12.setSeriesNegativeItemLabelPosition((-1), itemLabelPosition50, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNull(collection45);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition50);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 100.0d);
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType2 = chartChangeEvent1.getType();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        lineAndShapeRenderer3.drawRangeMarker(graphics2D4, categoryPlot5, valueAxis9, marker10, rectangle2D11);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot5.getDomainMarkers(layer13);
        org.jfree.chart.renderer.category.BarRenderer barRenderer15 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot5.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer15);
        boolean boolean18 = barRenderer15.isSeriesVisible((int) (short) -1);
        double double19 = barRenderer15.getShadowYOffset();
        boolean boolean20 = chartChangeEventType2.equals((java.lang.Object) double19);
        org.junit.Assert.assertNotNull(chartChangeEventType2);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 4.0d + "'", double19 == 4.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection0.addAll(legendItemCollection1);
        int int3 = legendItemCollection0.getItemCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        java.net.URL uRL0 = null;
        java.net.URLClassLoader uRLClassLoader1 = null;
        try {
            org.jfree.chart.util.ResourceBundleWrapper.removeCodeBase(uRL0, uRLClassLoader1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean2 = lineAndShapeRenderer0.isSeriesVisible((int) (byte) 0);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo8 = null;
        try {
            lineAndShapeRenderer0.drawAnnotations(graphics2D3, rectangle2D4, categoryAxis5, valueAxis6, layer7, plotRenderingInfo8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 0, false);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo10 = null;
        java.awt.geom.Point2D point2D11 = null;
        categoryPlot0.zoomRangeAxes((double) (-1), (double) 10.0f, plotRenderingInfo10, point2D11);
        try {
            categoryPlot0.zoom((double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-32640) + "'", int1 == (-32640));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Stroke stroke1 = renderAttributes0.getDefaultOutlineStroke();
        org.junit.Assert.assertNull(stroke1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseOutlineStroke();
        java.awt.Paint paint5 = null;
        lineAndShapeRenderer2.setSeriesPaint(0, paint5, false);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        java.awt.Shape shape0 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        java.awt.Paint paint16 = null;
        try {
            barRenderer12.setSeriesFillPaint((int) (short) -1, paint16, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        categoryPlot2.setBackgroundAlpha((float) 8);
        boolean boolean21 = categoryPlot2.isNotify();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor22 = null;
        try {
            categoryPlot2.setDomainGridlinePosition(categoryAnchor22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.TOP_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        barRenderer12.setAutoPopulateSeriesStroke(true);
        boolean boolean18 = barRenderer12.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Shape shape20 = barRenderer12.getSeriesShape((int) (short) -1);
        int int21 = barRenderer12.getRowCount();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(shape20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getRendererCount();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedRangeAxisSpace();
        java.awt.Paint paint2 = categoryPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertNotNull(paint2);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint3 = renderAttributes0.getItemPaint(10, (int) (short) 0);
        java.awt.Paint paint4 = renderAttributes0.getDefaultFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        lineAndShapeRenderer5.drawRangeMarker(graphics2D6, categoryPlot7, valueAxis11, marker12, rectangle2D13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot7.setRangeAxisLocation((int) (short) 100, axisLocation16, false);
        java.awt.Color color19 = java.awt.Color.ORANGE;
        java.awt.Color color20 = color19.brighter();
        categoryPlot7.setRangeMinorGridlinePaint((java.awt.Paint) color20);
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color20);
        try {
            java.awt.Stroke stroke25 = renderAttributes0.getItemOutlineStroke(2, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 0, false);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Paint paint8 = categoryPlot0.getRangeMinorGridlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle(100.0d);
        java.awt.Font font3 = null;
        try {
            categoryAxis0.setLabelFont(font3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke7 = defaultDrawingSupplier6.getNextOutlineStroke();
        categoryPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier6, true);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot5.getDomainAxisLocation(1);
        java.lang.String str12 = axisLocation11.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation11, plotOrientation13);
        try {
            double double15 = categoryAxis0.getCategoryStart((-32640), 2, rectangle2D4, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str12.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.Marker marker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        lineAndShapeRenderer7.drawRangeMarker(graphics2D8, categoryPlot9, valueAxis13, marker14, rectangle2D15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot9.getDomainMarkers(layer17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot9.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo21, point2D22);
        org.jfree.chart.axis.AxisSpace axisSpace24 = null;
        categoryPlot9.setFixedDomainAxisSpace(axisSpace24);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean30 = lineAndShapeRenderer27.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer27.setPlot(categoryPlot31);
        categoryPlot9.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer27);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D35 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot36.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis40 = null;
        org.jfree.chart.plot.Marker marker41 = null;
        java.awt.geom.Rectangle2D rectangle2D42 = null;
        lineAndShapeRenderer34.drawRangeMarker(graphics2D35, categoryPlot36, valueAxis40, marker41, rectangle2D42);
        org.jfree.chart.axis.AxisLocation axisLocation45 = null;
        categoryPlot36.setRangeAxisLocation((int) (short) 100, axisLocation45, false);
        lineAndShapeRenderer27.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot36);
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot36.getRangeAxisEdge(100);
        try {
            double double51 = categoryAxis0.getCategorySeriesMiddle((int) '4', (int) 'a', (int) (short) 1, 0, (double) 1, rectangle2D6, rectangleEdge50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertNotNull(rectangleEdge50);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot2.setRangeAxisLocation((int) (short) 100, axisLocation11, false);
        java.awt.Color color14 = java.awt.Color.ORANGE;
        java.awt.Color color15 = color14.brighter();
        categoryPlot2.setRangeMinorGridlinePaint((java.awt.Paint) color15);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation17 = null;
        try {
            boolean boolean19 = categoryPlot2.removeAnnotation(categoryAnnotation17, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertNotNull(color15);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getRangeMarkers(layer5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder7 = org.jfree.chart.plot.DatasetRenderingOrder.REVERSE;
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder7);
        org.jfree.chart.axis.AxisLocation axisLocation10 = categoryPlot0.getRangeAxisLocation(0);
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNotNull(datasetRenderingOrder7);
        org.junit.Assert.assertNotNull(axisLocation10);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape5, "AxisLocation.TOP_OR_RIGHT", "hi!");
        java.awt.Shape shape10 = chartEntity9.getArea();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        try {
            org.jfree.chart.entity.CategoryItemEntity categoryItemEntity16 = new org.jfree.chart.entity.CategoryItemEntity(shape10, "AxisLocation.TOP_OR_RIGHT", "AxisLocation.TOP_OR_RIGHT", categoryDataset13, (java.lang.Comparable) (short) -1, (java.lang.Comparable) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape2 = legendItem1.getLine();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer5 = legendItem4.getFillPaintTransformer();
        legendItem1.setFillPaintTransformer(gradientPaintTransformer5);
        legendItem1.setDatasetIndex((int) (byte) 100);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(gradientPaintTransformer5);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARKS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 0, false);
        float float6 = categoryPlot0.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.Marker marker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        lineAndShapeRenderer7.drawRangeMarker(graphics2D8, categoryPlot9, valueAxis13, marker14, rectangle2D15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot9.getDomainMarkers(layer17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19);
        boolean boolean22 = barRenderer19.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = barRenderer19.getLegendItemLabelGenerator();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        lineAndShapeRenderer24.drawRangeMarker(graphics2D25, categoryPlot26, valueAxis30, marker31, rectangle2D32);
        boolean boolean34 = barRenderer19.hasListener((java.util.EventListener) categoryPlot26);
        int int35 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19);
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        boolean boolean38 = categoryPlot37.isNotify();
        boolean boolean39 = categoryPlot37.canSelectByRegion();
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        try {
            barRenderer19.drawBackground(graphics2D36, categoryPlot37, rectangle2D40);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.5f + "'", float6 == 0.5f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator23);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createInsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.lang.String str0 = org.jfree.chart.labels.StandardCategorySeriesLabelGenerator.DEFAULT_LABEL_FORMAT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "{0}" + "'", str0.equals("{0}"));
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint3 = renderAttributes0.getItemPaint(10, (int) (short) 0);
        java.awt.Paint paint5 = renderAttributes0.getSeriesOutlinePaint(10);
        java.awt.Color color6 = java.awt.Color.white;
        renderAttributes0.setDefaultPaint((java.awt.Paint) color6);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        lineAndShapeRenderer0.setSeriesLinesVisible(100, false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition0 = new org.jfree.chart.labels.ItemLabelPosition();
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Color color0 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.BOTTOM_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 0, false);
        float float6 = categoryPlot0.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.Marker marker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        lineAndShapeRenderer7.drawRangeMarker(graphics2D8, categoryPlot9, valueAxis13, marker14, rectangle2D15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot9.getDomainMarkers(layer17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19);
        boolean boolean22 = barRenderer19.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = barRenderer19.getLegendItemLabelGenerator();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        lineAndShapeRenderer24.drawRangeMarker(graphics2D25, categoryPlot26, valueAxis30, marker31, rectangle2D32);
        boolean boolean34 = barRenderer19.hasListener((java.util.EventListener) categoryPlot26);
        int int35 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor36 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.5f + "'", float6 == 0.5f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator23);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        lineAndShapeRenderer5.drawRangeMarker(graphics2D6, categoryPlot7, valueAxis11, marker12, rectangle2D13);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke16 = defaultDrawingSupplier15.getNextOutlineStroke();
        categoryPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        categoryPlot0.clearRangeMarkers();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        java.awt.Paint paint7 = categoryPlot0.getDomainGridlinePaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke10 = lineAndShapeRenderer8.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke12 = lineAndShapeRenderer8.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem15 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape16 = legendItem15.getLine();
        java.awt.Font font17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem15.setLabelFont(font17);
        lineAndShapeRenderer8.setSeriesItemLabelFont((int) ' ', font17);
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke22 = defaultDrawingSupplier21.getNextOutlineStroke();
        categoryPlot20.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21, true);
        org.jfree.chart.axis.AxisLocation axisLocation26 = categoryPlot20.getDomainAxisLocation(1);
        org.jfree.chart.axis.AxisLocation axisLocation27 = axisLocation26.getOpposite();
        boolean boolean28 = lineAndShapeRenderer8.equals((java.lang.Object) axisLocation27);
        categoryPlot0.setRangeAxisLocation(axisLocation27);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(shape16);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(axisLocation26);
        org.junit.Assert.assertNotNull(axisLocation27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle(100.0d);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.axis.AxisState axisState4 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets7 = categoryAxis6.getTickLabelInsets();
        java.awt.Graphics2D graphics2D8 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke13 = defaultDrawingSupplier12.getNextOutlineStroke();
        categoryPlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier12, true);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot11.getDomainAxisLocation(1);
        java.lang.String str18 = axisLocation17.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation17, plotOrientation19);
        org.jfree.chart.axis.AxisState axisState21 = null;
        categoryAxis6.drawTickMarks(graphics2D8, 0.05d, rectangle2D10, rectangleEdge20, axisState21);
        try {
            java.util.List list23 = categoryAxis0.refreshTicks(graphics2D3, axisState4, rectangle2D5, rectangleEdge20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets7);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str18.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        int int3 = java.awt.Color.HSBtoRGB(10.0f, 100.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-10289251) + "'", int3 == (-10289251));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        barRenderer0.setMaximumBarWidth((double) 0.0f);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator12 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator12, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        java.awt.Color color1 = java.awt.Color.getColor("AxisLocation.TOP_OR_RIGHT");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer8 = legendItem7.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem10 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape11 = legendItem10.getLine();
        legendItem7.setShape(shape11);
        try {
            lineAndShapeRenderer3.setLegendShape((int) (byte) -1, shape11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(gradientPaintTransformer8);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets3.createAdjustedRectangle(rectangle2D4, lengthAdjustmentType5, lengthAdjustmentType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        legendItem1.setDatasetIndex((int) (byte) 0);
        int int5 = legendItem1.getSeriesIndex();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        try {
            lineAndShapeRenderer0.setItemMargin((double) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        lineAndShapeRenderer5.drawRangeMarker(graphics2D6, categoryPlot7, valueAxis11, marker12, rectangle2D13);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke16 = defaultDrawingSupplier15.getNextOutlineStroke();
        categoryPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        java.awt.Paint paint19 = defaultDrawingSupplier15.getNextPaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint19);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color7 = java.awt.Color.WHITE;
        boolean boolean8 = plotOrientation6.equals((java.lang.Object) color7);
        int int9 = color7.getBlue();
        lineAndShapeRenderer3.setSeriesFillPaint(1, (java.awt.Paint) color7);
        boolean boolean11 = lineAndShapeRenderer3.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator13 = lineAndShapeRenderer3.getSeriesToolTipGenerator(0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator13);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = barRenderer12.getLegendItemLabelGenerator();
        java.awt.Graphics2D graphics2D17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        int int23 = categoryPlot19.getDatasetCount();
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        float float25 = categoryAxis24.getTickMarkOutsideLength();
        categoryAxis24.setCategoryMargin((double) 8);
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.data.category.CategoryDataset categoryDataset29 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState33 = null;
        java.awt.geom.Rectangle2D rectangle2D34 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D35 = barRenderer12.createHotSpotBounds(graphics2D17, rectangle2D18, categoryPlot19, categoryAxis24, valueAxis28, categoryDataset29, (int) 'a', (int) ' ', true, categoryItemRendererState33, rectangle2D34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.plot.PlotOrientation plotOrientation6 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color7 = java.awt.Color.WHITE;
        boolean boolean8 = plotOrientation6.equals((java.lang.Object) color7);
        int int9 = color7.getBlue();
        lineAndShapeRenderer3.setSeriesFillPaint(1, (java.awt.Paint) color7);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color13 = java.awt.Color.WHITE;
        boolean boolean14 = plotOrientation12.equals((java.lang.Object) color13);
        int int15 = color13.getBlue();
        lineAndShapeRenderer3.setSeriesOutlinePaint(0, (java.awt.Paint) color13, false);
        java.awt.Graphics2D graphics2D18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        lineAndShapeRenderer20.drawRangeMarker(graphics2D21, categoryPlot22, valueAxis26, marker27, rectangle2D28);
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = categoryPlot22.getDomainMarkers(layer30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot22.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo34, point2D35);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        categoryPlot22.setFixedDomainAxisSpace(axisSpace37);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean43 = lineAndShapeRenderer40.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer40.setPlot(categoryPlot44);
        categoryPlot22.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer40);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot49.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.plot.Marker marker54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        lineAndShapeRenderer47.drawRangeMarker(graphics2D48, categoryPlot49, valueAxis53, marker54, rectangle2D55);
        org.jfree.chart.axis.AxisLocation axisLocation58 = null;
        categoryPlot49.setRangeAxisLocation((int) (short) 100, axisLocation58, false);
        lineAndShapeRenderer40.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot49);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = categoryPlot49.getRangeAxisEdge(100);
        categoryPlot49.setDomainCrosshairVisible(false);
        org.jfree.chart.axis.CategoryAxis categoryAxis66 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets67 = categoryAxis66.getTickLabelInsets();
        java.awt.Graphics2D graphics2D68 = null;
        java.awt.geom.Rectangle2D rectangle2D70 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier72 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke73 = defaultDrawingSupplier72.getNextOutlineStroke();
        categoryPlot71.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier72, true);
        org.jfree.chart.axis.AxisLocation axisLocation77 = categoryPlot71.getDomainAxisLocation(1);
        java.lang.String str78 = axisLocation77.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation79 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation77, plotOrientation79);
        org.jfree.chart.axis.AxisState axisState81 = null;
        categoryAxis66.drawTickMarks(graphics2D68, 0.05d, rectangle2D70, rectangleEdge80, axisState81);
        org.jfree.chart.axis.ValueAxis valueAxis83 = null;
        org.jfree.data.category.CategoryDataset categoryDataset84 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState88 = null;
        java.awt.geom.Rectangle2D rectangle2D89 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D90 = lineAndShapeRenderer3.createHotSpotBounds(graphics2D18, rectangle2D19, categoryPlot49, categoryAxis66, valueAxis83, categoryDataset84, (-10289251), (int) (byte) 10, false, categoryItemRendererState88, rectangle2D89);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 255 + "'", int9 == 255);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 255 + "'", int15 == 255);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertNotNull(rectangleInsets67);
        org.junit.Assert.assertNotNull(stroke73);
        org.junit.Assert.assertNotNull(axisLocation77);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str78.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation79);
        org.junit.Assert.assertNotNull(rectangleEdge80);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE9;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE9" + "'", str1.equals("ItemLabelAnchor.INSIDE9"));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextOutlineStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1, true);
        java.awt.Paint paint5 = defaultDrawingSupplier1.getNextPaint();
        java.awt.Shape shape6 = defaultDrawingSupplier1.getNextShape();
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape6);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot4.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis8 = null;
        org.jfree.chart.plot.Marker marker9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        lineAndShapeRenderer2.drawRangeMarker(graphics2D3, categoryPlot4, valueAxis8, marker9, rectangle2D10);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot4.getDomainMarkers(layer12);
        org.jfree.chart.renderer.category.BarRenderer barRenderer14 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot4.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer14);
        boolean boolean17 = barRenderer14.isSeriesVisible((int) (short) -1);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape21 = legendItem20.getLine();
        barRenderer14.setSeriesShape(0, shape21, false);
        legendItem1.setShape(shape21);
        java.awt.Font font25 = legendItem1.getLabelFont();
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(shape21);
        org.junit.Assert.assertNull(font25);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) 0.5f);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets0.createInsetRectangle(rectangle2D4, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertNotNull(unitType3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemLabelPaint((int) (byte) 10, (int) (byte) -1, false);
        try {
            lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (byte) -1, (java.lang.Boolean) false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.CENTER;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot0.setRangeAxis(valueAxis5);
        categoryPlot0.setRangeCrosshairValue((double) '#');
        org.jfree.chart.axis.AxisSpace axisSpace9 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot11.setNoDataMessagePaint((java.awt.Paint) color12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot11.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis16 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis16.setLabelAngle(100.0d);
        categoryPlot11.setDomainAxis((int) (short) 100, categoryAxis16, true);
        try {
            categoryPlot0.setDomainAxis((int) (short) -1, categoryAxis16, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(axisSpace9);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        int int4 = categoryPlot0.getDatasetCount();
        org.jfree.chart.LegendItemCollection legendItemCollection5 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
        org.junit.Assert.assertNull(legendItemCollection5);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer0.setPlot(categoryPlot4);
        categoryPlot4.setBackgroundImageAlignment((int) (short) 0);
        java.util.List list8 = categoryPlot4.getAnnotations();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot4.getFixedLegendItems();
        org.jfree.data.category.CategoryDataset categoryDataset11 = null;
        categoryPlot4.setDataset((int) ' ', categoryDataset11);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation13 = null;
        try {
            boolean boolean14 = categoryPlot4.removeAnnotation(categoryAnnotation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(legendItemCollection9);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot2.setRangeAxisLocation((int) (short) 100, axisLocation11, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot2.getInsets();
        double double15 = rectangleInsets14.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.0d + "'", double15 == 8.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape2 = legendItem1.getLine();
        java.lang.String str3 = legendItem1.getDescription();
        java.lang.String str4 = legendItem1.getLabel();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        java.lang.String str7 = legendItem1.getToolTipText();
        java.awt.Shape shape8 = legendItem1.getShape();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNotNull(shape8);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setLabelAngle(100.0d);
        java.lang.String str3 = categoryAxis0.getLabel();
        org.junit.Assert.assertNull(str3);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.Marker marker1 = null;
        org.jfree.chart.util.Layer layer2 = null;
        try {
            boolean boolean3 = categoryPlot0.removeRangeMarker(marker1, layer2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.lang.Object obj5 = categoryPlot0.clone();
        org.jfree.chart.plot.CategoryMarker categoryMarker6 = null;
        org.jfree.chart.util.Layer layer7 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker6, layer7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        java.awt.Graphics2D graphics2D2 = null;
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke7 = defaultDrawingSupplier6.getNextOutlineStroke();
        categoryPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier6, true);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot5.getDomainAxisLocation(1);
        java.lang.String str12 = axisLocation11.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation11, plotOrientation13);
        org.jfree.chart.axis.AxisState axisState15 = null;
        categoryAxis0.drawTickMarks(graphics2D2, 0.05d, rectangle2D4, rectangleEdge14, axisState15);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot19.setNoDataMessagePaint((java.awt.Paint) color20);
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = categoryPlot19.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray24 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis23 };
        categoryPlot19.setDomainAxes(categoryAxisArray24);
        java.awt.Stroke stroke26 = categoryPlot19.getDomainCrosshairStroke();
        categoryPlot18.setDomainGridlineStroke(stroke26);
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = categoryAxis29.getTickLabelInsets();
        java.awt.Graphics2D graphics2D31 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier35 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke36 = defaultDrawingSupplier35.getNextOutlineStroke();
        categoryPlot34.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier35, true);
        org.jfree.chart.axis.AxisLocation axisLocation40 = categoryPlot34.getDomainAxisLocation(1);
        java.lang.String str41 = axisLocation40.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation42 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation40, plotOrientation42);
        org.jfree.chart.axis.AxisState axisState44 = null;
        categoryAxis29.drawTickMarks(graphics2D31, 0.05d, rectangle2D33, rectangleEdge43, axisState44);
        org.jfree.chart.axis.AxisSpace axisSpace46 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace47 = categoryAxis0.reserveSpace(graphics2D17, (org.jfree.chart.plot.Plot) categoryPlot18, rectangle2D28, rectangleEdge43, axisSpace46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str12.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNotNull(rectangleInsets22);
        org.junit.Assert.assertNotNull(categoryAxisArray24);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNotNull(axisLocation40);
        org.junit.Assert.assertTrue("'" + str41 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str41.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getTickMarkOutsideLength();
        categoryAxis0.setCategoryMargin((double) 8);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot4.setNoDataMessagePaint((java.awt.Paint) color5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int8 = categoryPlot4.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color11 = java.awt.Color.WHITE;
        boolean boolean12 = plotOrientation10.equals((java.lang.Object) color11);
        int int13 = color11.getBlue();
        lineAndShapeRenderer7.setSeriesFillPaint(1, (java.awt.Paint) color11);
        categoryAxis0.setTickMarkPaint((java.awt.Paint) color11);
        java.lang.String str16 = categoryAxis0.getLabel();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0f + "'", float1 == 2.0f);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNull(str16);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer12.getBaseNegativeItemLabelPosition();
        barRenderer12.setShadowYOffset((double) (-1L));
        java.awt.Color color20 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        barRenderer12.setSeriesOutlinePaint((int) (byte) 10, (java.awt.Paint) color20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        try {
            barRenderer12.drawOutline(graphics2D22, categoryPlot23, rectangle2D24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(color20);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot0.setRangeAxis(valueAxis5);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        categoryPlot0.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.LegendItemCollection legendItemCollection12 = categoryPlot0.getFixedLegendItems();
        org.junit.Assert.assertNull(legendItemCollection12);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.util.Layer layer19 = null;
        java.util.Collection collection20 = categoryPlot2.getDomainMarkers(layer19);
        java.awt.Stroke stroke21 = categoryPlot2.getRangeGridlineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset22 = categoryPlot2.getDataset();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(collection20);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(categoryDataset22);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE3;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        double double5 = rectangleInsets3.extendHeight((double) (byte) 1);
        double double7 = rectangleInsets3.calculateLeftOutset((double) (short) -1);
        double double9 = rectangleInsets3.trimHeight((double) 0);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets3.createOutsetRectangle(rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 9.0d + "'", double5 == 9.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.0d + "'", double7 == 8.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-8.0d) + "'", double9 == (-8.0d));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        java.awt.Color color10 = java.awt.Color.WHITE;
        categoryPlot2.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot2.panRangeAxes(0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = categoryPlot2.getOrientation();
        categoryPlot2.setOutlineVisible(false);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(plotOrientation16);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_CENTER;
        java.awt.Paint paint1 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        boolean boolean2 = textAnchor0.equals((java.lang.Object) paint1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertNotNull(paint1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 100.0d);
        java.lang.Object obj2 = chartChangeEvent1.getSource();
        java.lang.String str3 = chartChangeEvent1.toString();
        org.junit.Assert.assertTrue("'" + obj2 + "' != '" + 100.0d + "'", obj2.equals(100.0d));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.jfree.chart.event.ChartChangeEvent[source=100.0]" + "'", str3.equals("org.jfree.chart.event.ChartChangeEvent[source=100.0]"));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemLabelPaint((int) (byte) 10, (int) (byte) -1, false);
        int int9 = lineAndShapeRenderer0.getPassCount();
        java.lang.Object obj10 = lineAndShapeRenderer0.clone();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        lineAndShapeRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        boolean boolean6 = lineAndShapeRenderer0.getBaseCreateEntities();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setLabel("");
        categoryAxis0.setLabel("{0}");
        java.awt.Font font7 = categoryAxis0.getTickLabelFont();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.axis.AxisState axisState9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getTickLabelInsets();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke18 = defaultDrawingSupplier17.getNextOutlineStroke();
        categoryPlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17, true);
        org.jfree.chart.axis.AxisLocation axisLocation22 = categoryPlot16.getDomainAxisLocation(1);
        java.lang.String str23 = axisLocation22.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation24 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation22, plotOrientation24);
        org.jfree.chart.axis.AxisState axisState26 = null;
        categoryAxis11.drawTickMarks(graphics2D13, 0.05d, rectangle2D15, rectangleEdge25, axisState26);
        try {
            java.util.List list28 = categoryAxis0.refreshTicks(graphics2D8, axisState9, rectangle2D10, rectangleEdge25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(axisLocation22);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str23.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation24);
        org.junit.Assert.assertNotNull(rectangleEdge25);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color6);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int9 = categoryPlot5.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer8);
        org.jfree.chart.plot.PlotOrientation plotOrientation11 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color12 = java.awt.Color.WHITE;
        boolean boolean13 = plotOrientation11.equals((java.lang.Object) color12);
        int int14 = color12.getBlue();
        lineAndShapeRenderer8.setSeriesFillPaint(1, (java.awt.Paint) color12);
        java.awt.image.ColorModel colorModel16 = null;
        java.awt.Rectangle rectangle17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        java.awt.geom.AffineTransform affineTransform19 = null;
        java.awt.RenderingHints renderingHints20 = null;
        java.awt.PaintContext paintContext21 = color12.createContext(colorModel16, rectangle17, rectangle2D18, affineTransform19, renderingHints20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke24 = lineAndShapeRenderer22.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint26 = lineAndShapeRenderer22.lookupLegendTextPaint((int) '#');
        java.awt.Stroke stroke30 = lineAndShapeRenderer22.getItemStroke(1, (int) (short) 1, false);
        java.awt.Color color31 = java.awt.Color.black;
        try {
            org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem(attributedString0, "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "hi!", shape4, (java.awt.Paint) color12, stroke30, (java.awt.Paint) color31);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation11);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 255 + "'", int14 == 255);
        org.junit.Assert.assertNotNull(paintContext21);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(color31);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        org.jfree.chart.LegendItem legendItem5 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = legendItem5.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape9 = legendItem8.getLine();
        legendItem5.setShape(shape9);
        org.jfree.chart.entity.ChartEntity chartEntity13 = new org.jfree.chart.entity.ChartEntity(shape9, "AxisLocation.TOP_OR_RIGHT", "hi!");
        java.awt.Stroke stroke14 = null;
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = legendItem16.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape20 = legendItem19.getLine();
        legendItem16.setShape(shape20);
        java.awt.Stroke stroke22 = null;
        legendItem16.setOutlineStroke(stroke22);
        java.awt.Color color24 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color25 = color24.brighter();
        legendItem16.setOutlinePaint((java.awt.Paint) color25);
        try {
            org.jfree.chart.LegendItem legendItem27 = new org.jfree.chart.LegendItem("{0}", "PlotOrientation.HORIZONTAL", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "{0}", shape9, stroke14, (java.awt.Paint) color25);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer6);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(gradientPaintTransformer17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(color25);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer0.setPlot(categoryPlot4);
        org.jfree.data.category.CategoryDataset categoryDataset7 = categoryPlot4.getDataset((int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(categoryDataset7);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        lineAndShapeRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis10, marker11, rectangle2D12);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot6.getDomainMarkers(layer14);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo18 = null;
        java.awt.geom.Point2D point2D19 = null;
        categoryPlot6.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo18, point2D19);
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        try {
            lineAndShapeRenderer2.drawBackground(graphics2D3, categoryPlot6, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection15);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot2.setRangeAxisLocation((int) (short) 100, axisLocation11, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot2.getInsets();
        org.jfree.chart.LegendItemCollection legendItemCollection15 = categoryPlot2.getLegendItems();
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(legendItemCollection15);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int1 = color0.getAlpha();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 255 + "'", int1 == 255);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        barRenderer12.setAutoPopulateSeriesStroke(true);
        boolean boolean18 = barRenderer12.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer12.setShadowPaint((java.awt.Paint) color19);
        int int21 = color19.getTransparency();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 1 + "'", int21 == 1);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.renderer.category.BarPainter barPainter0 = org.jfree.chart.renderer.category.BarRenderer.getDefaultBarPainter();
        org.junit.Assert.assertNotNull(barPainter0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.text.TextAnchor textAnchor1 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition2 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor0, textAnchor1);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor3 = itemLabelPosition2.getItemLabelAnchor();
        java.awt.Color color4 = java.awt.Color.BLUE;
        java.awt.image.ColorModel colorModel5 = null;
        java.awt.Rectangle rectangle6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        java.awt.geom.AffineTransform affineTransform8 = null;
        java.awt.RenderingHints renderingHints9 = null;
        java.awt.PaintContext paintContext10 = color4.createContext(colorModel5, rectangle6, rectangle2D7, affineTransform8, renderingHints9);
        boolean boolean11 = itemLabelPosition2.equals((java.lang.Object) affineTransform8);
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertNotNull(textAnchor1);
        org.junit.Assert.assertNotNull(itemLabelAnchor3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(paintContext10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color6 = java.awt.Color.darkGray;
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color6, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, true);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer14 = legendItem13.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape17 = legendItem16.getLine();
        legendItem13.setShape(shape17);
        org.jfree.chart.entity.ChartEntity chartEntity21 = new org.jfree.chart.entity.ChartEntity(shape17, "AxisLocation.TOP_OR_RIGHT", "hi!");
        java.awt.Shape shape22 = chartEntity21.getArea();
        lineAndShapeRenderer0.setBaseLegendShape(shape22);
        java.awt.Graphics2D graphics2D24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis26 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = categoryAxis26.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis28 = null;
        org.jfree.chart.util.Layer layer29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            lineAndShapeRenderer0.drawAnnotations(graphics2D24, rectangle2D25, categoryAxis26, valueAxis28, layer29, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(gradientPaintTransformer14);
        org.junit.Assert.assertNotNull(shape17);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNotNull(rectangleInsets27);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        barRenderer12.setAutoPopulateSeriesStroke(true);
        boolean boolean18 = barRenderer12.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Color color19 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer12.setShadowPaint((java.awt.Paint) color19);
        barRenderer12.setMaximumBarWidth((double) 2.0f);
        barRenderer12.setShadowYOffset((double) '#');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator26 = null;
        barRenderer12.setSeriesItemLabelGenerator(2, categoryItemLabelGenerator26);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color19);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        java.awt.Paint paint4 = lineAndShapeRenderer2.lookupSeriesFillPaint(10);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        try {
            java.lang.Object obj2 = keyedObjects0.getObject((java.lang.Comparable) 0);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (0) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        barRenderer12.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) false, true);
        barRenderer12.setAutoPopulateSeriesOutlineStroke(true);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis23 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryAxis23.getTickLabelInsets();
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke30 = defaultDrawingSupplier29.getNextOutlineStroke();
        categoryPlot28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier29, true);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot28.getDomainAxisLocation(1);
        java.lang.String str35 = axisLocation34.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation36 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation34, plotOrientation36);
        org.jfree.chart.axis.AxisState axisState38 = null;
        categoryAxis23.drawTickMarks(graphics2D25, 0.05d, rectangle2D27, rectangleEdge37, axisState38);
        java.awt.geom.Rectangle2D rectangle2D40 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge41 = null;
        try {
            double double42 = barRenderer12.getItemMiddle((java.lang.Comparable) (short) 1, (java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", categoryDataset22, categoryAxis23, rectangle2D40, rectangleEdge41);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str35.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation36);
        org.junit.Assert.assertNotNull(rectangleEdge37);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        java.lang.Double double0 = org.jfree.chart.renderer.AbstractRenderer.ZERO;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0.equals(0.0d));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot0.setRangeAxis(valueAxis5);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        org.jfree.chart.plot.Marker marker9 = null;
        org.jfree.chart.util.Layer layer10 = null;
        try {
            categoryPlot0.addRangeMarker(marker9, layer10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray4 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot0.setRenderers(categoryItemRendererArray4);
        categoryPlot0.setForegroundAlpha(0.0f);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(categoryItemRendererArray4);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        keyedObjects0.insertValue(0, (java.lang.Comparable) (-1), (java.lang.Object) 0);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean10 = lineAndShapeRenderer7.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer7.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color13 = java.awt.Color.darkGray;
        lineAndShapeRenderer7.setBaseOutlinePaint((java.awt.Paint) color13, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = null;
        lineAndShapeRenderer7.setBaseToolTipGenerator(categoryToolTipGenerator16, true);
        org.jfree.chart.LegendItem legendItem20 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer21 = legendItem20.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape24 = legendItem23.getLine();
        legendItem20.setShape(shape24);
        org.jfree.chart.entity.ChartEntity chartEntity28 = new org.jfree.chart.entity.ChartEntity(shape24, "AxisLocation.TOP_OR_RIGHT", "hi!");
        java.awt.Shape shape29 = chartEntity28.getArea();
        lineAndShapeRenderer7.setBaseLegendShape(shape29);
        keyedObjects0.setObject((java.lang.Comparable) "PlotOrientation.HORIZONTAL", (java.lang.Object) lineAndShapeRenderer7);
        java.lang.Boolean boolean33 = lineAndShapeRenderer7.getSeriesShapesFilled((int) '4');
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(gradientPaintTransformer21);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNull(boolean33);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        barRenderer12.setAutoPopulateSeriesStroke(true);
        boolean boolean18 = barRenderer12.getDataBoundsIncludesVisibleSeriesOnly();
        try {
            java.awt.Shape shape20 = barRenderer12.lookupSeriesShape((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.junit.Assert.assertNotNull(axisLocation0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getBaseOutlineStroke();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace7 = categoryPlot6.getFixedRangeAxisSpace();
        boolean boolean8 = categoryPlot6.isRangePannable();
        java.awt.Paint paint9 = categoryPlot6.getRangeMinorGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot6.getRendererForDataset(categoryDataset10);
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            lineAndShapeRenderer0.drawBackground(graphics2D5, categoryPlot6, rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(axisSpace7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNull(categoryItemRenderer11);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        lineAndShapeRenderer0.setSeriesShapesFilled(0, (java.lang.Boolean) false);
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = null;
        java.awt.geom.Rectangle2D rectangle2D17 = null;
        try {
            lineAndShapeRenderer0.drawBackground(graphics2D15, categoryPlot16, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D2 = rectangleInsets0.createOutsetRectangle(rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer12.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        barRenderer12.setSeriesURLGenerator(10, categoryURLGenerator19, false);
        barRenderer12.setMaximumBarWidth(0.2d);
        boolean boolean24 = barRenderer12.getAutoPopulateSeriesOutlinePaint();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.DATASET_UPDATED;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        keyedObjects0.insertValue(0, (java.lang.Comparable) (-1), (java.lang.Object) 0);
        try {
            keyedObjects0.removeValue((java.lang.Comparable) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (0.0) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean1 = renderAttributes0.getDefaultCreateEntity();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) false);
        java.awt.Stroke stroke4 = null;
        try {
            renderAttributes0.setDefaultStroke(stroke4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        lineAndShapeRenderer20.setSeriesVisibleInLegend(1, (java.lang.Boolean) false, false);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean1 = renderAttributes0.getDefaultCreateEntity();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) false);
        org.jfree.chart.renderer.RenderAttributes renderAttributes4 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean5 = renderAttributes4.getDefaultCreateEntity();
        renderAttributes4.setDefaultLabelVisible((java.lang.Boolean) false);
        java.awt.Shape shape8 = renderAttributes4.getDefaultShape();
        org.jfree.chart.plot.PlotOrientation plotOrientation9 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color10 = java.awt.Color.WHITE;
        boolean boolean11 = plotOrientation9.equals((java.lang.Object) color10);
        renderAttributes4.setDefaultLabelPaint((java.awt.Paint) color10);
        renderAttributes0.setDefaultOutlinePaint((java.awt.Paint) color10);
        org.junit.Assert.assertNull(boolean1);
        org.junit.Assert.assertNull(boolean5);
        org.junit.Assert.assertNull(shape8);
        org.junit.Assert.assertNotNull(plotOrientation9);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str1 = rectangleInsets0.toString();
        double double3 = rectangleInsets0.calculateTopOutset((double) (short) 100);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        keyedObjects0.clear();
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape5, "AxisLocation.TOP_OR_RIGHT", "hi!");
        java.awt.Shape shape10 = chartEntity9.getArea();
        java.lang.String str11 = chartEntity9.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ChartEntity: tooltip = AxisLocation.TOP_OR_RIGHT" + "'", str11.equals("ChartEntity: tooltip = AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        org.jfree.chart.renderer.category.BarPainter barPainter16 = barRenderer12.getBarPainter();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(barPainter16);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint4 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '#');
        java.awt.Stroke stroke8 = lineAndShapeRenderer0.getItemStroke(1, (int) (short) 1, false);
        lineAndShapeRenderer0.setItemLabelAnchorOffset((double) 255);
        org.jfree.chart.JFreeChart jFreeChart11 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent12 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 255, jFreeChart11);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_FILL_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) ' ');
        java.lang.Object obj3 = objectList1.get((int) 'a');
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer12.getPositiveItemLabelPositionFallback();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_LIGHT_RED;
        barRenderer12.setSeriesPaint((int) (short) 1, (java.awt.Paint) color16, false);
        int int19 = color16.getAlpha();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        java.awt.Paint paint6 = categoryPlot0.getRangeCrosshairPaint();
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE8;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer12.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        java.awt.Color color19 = java.awt.Color.BLUE;
        barRenderer12.setSeriesItemLabelPaint((int) (short) 100, (java.awt.Paint) color19, true);
        java.awt.Color color22 = java.awt.Color.ORANGE;
        java.awt.Color color23 = color22.brighter();
        java.awt.Color color24 = color23.brighter();
        java.awt.color.ColorSpace colorSpace25 = color23.getColorSpace();
        float[] floatArray29 = new float[] { 100.0f, 'a', 10 };
        try {
            float[] floatArray30 = color19.getComponents(colorSpace25, floatArray29);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(color24);
        org.junit.Assert.assertNotNull(colorSpace25);
        org.junit.Assert.assertNotNull(floatArray29);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape5, "AxisLocation.TOP_OR_RIGHT", "hi!");
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator10 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator11 = null;
        try {
            java.lang.String str12 = chartEntity9.getImageMapAreaTag(toolTipTagFragmentGenerator10, uRLTagFragmentGenerator11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.GENERAL;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator7 = null;
        try {
            lineAndShapeRenderer0.setSeriesToolTipGenerator((-1), categoryToolTipGenerator7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        java.lang.String str1 = rectangleInsets0.toString();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createInsetRectangle(rectangle2D2, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]" + "'", str1.equals("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]"));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean1 = renderAttributes0.getDefaultCreateEntity();
        java.awt.Paint paint2 = renderAttributes0.getDefaultLabelPaint();
        java.awt.Paint paint5 = renderAttributes0.getItemOutlinePaint((-1), (-1));
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer8.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke13 = lineAndShapeRenderer8.lookupSeriesOutlineStroke(0);
        renderAttributes0.setDefaultOutlineStroke(stroke13);
        java.awt.Paint paint16 = renderAttributes0.getSeriesOutlinePaint((int) (byte) 100);
        org.junit.Assert.assertNull(boolean1);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer12.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator19 = null;
        barRenderer12.setSeriesURLGenerator(10, categoryURLGenerator19, false);
        barRenderer12.setMaximumBarWidth(0.2d);
        double double24 = barRenderer12.getMaximumBarWidth();
        java.awt.Paint paint26 = barRenderer12.lookupSeriesOutlinePaint(4);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.2d + "'", double24 == 0.2d);
        org.junit.Assert.assertNotNull(paint26);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape5, "AxisLocation.TOP_OR_RIGHT", "hi!");
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = null;
        categoryPlot10.setDomainAxis(10, categoryAxis12, true);
        org.jfree.chart.util.Layer layer15 = null;
        java.util.Collection collection16 = categoryPlot10.getRangeMarkers(layer15);
        boolean boolean17 = chartEntity9.equals((java.lang.Object) collection16);
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(collection16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape2 = legendItem1.getLine();
        java.awt.Paint paint3 = legendItem1.getFillPaint();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedRangeAxisSpace();
        boolean boolean2 = categoryPlot0.isRangePannable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 8, plotRenderingInfo4, point2D5, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot8.setNoDataMessagePaint((java.awt.Paint) color9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot8.getInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot8.setRenderers(categoryItemRendererArray12);
        categoryPlot0.setRenderers(categoryItemRendererArray12);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        java.lang.String str1 = gradientPaintTransformType0.toString();
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "GradientPaintTransformType.CENTER_VERTICAL" + "'", str1.equals("GradientPaintTransformType.CENTER_VERTICAL"));
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        java.awt.Color color2 = java.awt.Color.getColor("org.jfree.chart.event.ChartChangeEvent[source=100.0]", (int) (short) -1);
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape5, "AxisLocation.TOP_OR_RIGHT", "hi!");
        java.lang.String str10 = chartEntity9.getShapeType();
        java.awt.Shape shape11 = chartEntity9.getArea();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "poly" + "'", str10.equals("poly"));
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedRangeAxisSpace();
        boolean boolean2 = categoryPlot0.isRangePannable();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo4 = null;
        java.awt.geom.Point2D point2D5 = null;
        categoryPlot0.zoomRangeAxes((double) 8, plotRenderingInfo4, point2D5, false);
        org.jfree.chart.util.SortOrder sortOrder8 = org.jfree.chart.util.SortOrder.ASCENDING;
        categoryPlot0.setRowRenderingOrder(sortOrder8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke12 = lineAndShapeRenderer10.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke14 = lineAndShapeRenderer10.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem17 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape18 = legendItem17.getLine();
        java.awt.Font font19 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem17.setLabelFont(font19);
        lineAndShapeRenderer10.setSeriesItemLabelFont((int) ' ', font19);
        lineAndShapeRenderer10.setSeriesShapesFilled(0, (java.lang.Boolean) false);
        lineAndShapeRenderer10.setUseFillPaint(false);
        boolean boolean27 = sortOrder8.equals((java.lang.Object) false);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(sortOrder8);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint3 = renderAttributes0.getItemPaint(10, (int) (short) 0);
        java.awt.Paint paint5 = renderAttributes0.getSeriesOutlinePaint(10);
        java.awt.Stroke stroke6 = renderAttributes0.getDefaultStroke();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(stroke6);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setLabel("");
        categoryAxis0.setLabel("{0}");
        java.awt.Stroke stroke7 = categoryAxis0.getAxisLineStroke();
        boolean boolean8 = categoryAxis0.isVisible();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setLabelAngle(100.0d);
        categoryPlot0.setDomainAxis((int) (short) 100, categoryAxis5, true);
        categoryPlot0.setDomainCrosshairColumnKey((java.lang.Comparable) (-16.0d), true);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition14 = barRenderer12.getPositiveItemLabelPositionFallback();
        int int15 = barRenderer12.getPassCount();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(itemLabelPosition14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        categoryPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke10 = defaultDrawingSupplier9.getNextOutlineStroke();
        categoryPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9, true);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot8.getDomainAxisLocation(1);
        categoryPlot2.setDomainAxisLocation(axisLocation14);
        keyedObjects0.addObject((java.lang.Comparable) "hi!", (java.lang.Object) axisLocation14);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot21.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis25 = null;
        org.jfree.chart.plot.Marker marker26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        lineAndShapeRenderer19.drawRangeMarker(graphics2D20, categoryPlot21, valueAxis25, marker26, rectangle2D27);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke30 = defaultDrawingSupplier29.getNextOutlineStroke();
        categoryPlot21.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier29);
        try {
            keyedObjects0.insertValue((int) (short) -1, (java.lang.Comparable) (byte) 10, (java.lang.Object) categoryPlot21);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: 'position' out of bounds.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(axisLocation14);
        org.junit.Assert.assertNotNull(stroke30);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape19 = legendItem18.getLine();
        barRenderer12.setSeriesShape(0, shape19, false);
        java.awt.Paint paint23 = barRenderer12.getSeriesOutlinePaint((int) '#');
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(shape19);
        org.junit.Assert.assertNull(paint23);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextOutlineStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1, true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation(1);
        org.jfree.chart.axis.AxisLocation axisLocation7 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setLabelAngle(100.0d);
        categoryPlot0.setDomainAxis((int) (short) 100, categoryAxis5, true);
        java.awt.Image image10 = categoryPlot0.getBackgroundImage();
        categoryPlot0.setNotify(false);
        org.jfree.chart.axis.AxisSpace axisSpace13 = categoryPlot0.getFixedRangeAxisSpace();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor14 = null;
        try {
            categoryPlot0.setDomainGridlinePosition(categoryAnchor14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertNull(axisSpace13);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer0.setSeriesFillPaint((int) 'a', (java.awt.Paint) color11, true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer14.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean18 = lineAndShapeRenderer14.getDrawOutlines();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator21 = lineAndShapeRenderer19.getSeriesToolTipGenerator(1);
        java.lang.Boolean boolean23 = lineAndShapeRenderer19.getSeriesLinesVisible((int) (byte) 0);
        java.awt.Color color25 = java.awt.Color.GRAY;
        lineAndShapeRenderer19.setSeriesItemLabelPaint(10, (java.awt.Paint) color25);
        lineAndShapeRenderer14.setBaseLegendTextPaint((java.awt.Paint) color25);
        barRenderer0.setShadowPaint((java.awt.Paint) color25);
        float[] floatArray31 = new float[] { 0L, 100L };
        try {
            float[] floatArray32 = color25.getRGBComponents(floatArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(categoryToolTipGenerator21);
        org.junit.Assert.assertNull(boolean23);
        org.junit.Assert.assertNotNull(color25);
        org.junit.Assert.assertNotNull(floatArray31);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        categoryPlot29.setRangeCrosshairVisible(false);
        org.jfree.chart.util.Layer layer45 = null;
        java.util.Collection collection46 = categoryPlot29.getRangeMarkers((int) (short) 0, layer45);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(collection46);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint2 = lineAndShapeRenderer0.getSeriesPaint((int) (byte) 0);
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getSeriesStroke(1);
        try {
            lineAndShapeRenderer0.setSeriesLinesVisible((-10289251), false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(stroke4);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_OUTLINE_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke3 = defaultDrawingSupplier2.getNextOutlineStroke();
        categoryPlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier2, true);
        java.awt.Paint paint6 = defaultDrawingSupplier2.getNextPaint();
        boolean boolean7 = datasetRenderingOrder0.equals((java.lang.Object) paint6);
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType8 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        boolean boolean9 = datasetRenderingOrder0.equals((java.lang.Object) gradientPaintTransformType8);
        java.lang.Object obj10 = null;
        boolean boolean11 = gradientPaintTransformType8.equals(obj10);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(gradientPaintTransformType8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint3 = renderAttributes0.getItemPaint(10, (int) (short) 0);
        java.awt.Paint paint4 = renderAttributes0.getDefaultFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        lineAndShapeRenderer5.drawRangeMarker(graphics2D6, categoryPlot7, valueAxis11, marker12, rectangle2D13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot7.setRangeAxisLocation((int) (short) 100, axisLocation16, false);
        java.awt.Color color19 = java.awt.Color.ORANGE;
        java.awt.Color color20 = color19.brighter();
        categoryPlot7.setRangeMinorGridlinePaint((java.awt.Paint) color20);
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color20);
        java.awt.Paint paint25 = renderAttributes0.getItemPaint(10, (int) (short) 1);
        java.awt.Color color26 = org.jfree.chart.ChartColor.DARK_GREEN;
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color26);
        java.awt.Paint paint29 = null;
        try {
            renderAttributes0.setSeriesPaint((int) (byte) -1, paint29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(paint25);
        org.junit.Assert.assertNotNull(color26);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Color color1 = java.awt.Color.ORANGE;
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color1, true);
        lineAndShapeRenderer0.setAutoPopulateSeriesOutlineStroke(true);
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) 0.5f);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        java.awt.Color color4 = java.awt.Color.CYAN;
        boolean boolean5 = unitType3.equals((java.lang.Object) color4);
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot0.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier7, true);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getDomainAxisLocation(1);
        categoryPlot0.setDomainAxisLocation(axisLocation12);
        try {
            categoryPlot0.setBackgroundImageAlpha((float) (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'alpha' value must be in the range 0.0f to 1.0f.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation12);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.lang.Object obj5 = categoryPlot0.clone();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getRangeMarkers(layer6);
        org.jfree.chart.axis.AxisLocation axisLocation8 = categoryPlot0.getRangeAxisLocation();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(axisLocation8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        java.awt.Color color10 = java.awt.Color.WHITE;
        categoryPlot2.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot2.panRangeAxes(0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = categoryPlot2.getOrientation();
        java.awt.Stroke stroke17 = categoryPlot2.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryPlot2.setAxisOffset(rectangleInsets18);
        org.jfree.chart.renderer.RenderAttributes renderAttributes20 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint23 = renderAttributes20.getItemPaint(10, (int) (short) 0);
        java.awt.Paint paint24 = renderAttributes20.getDefaultFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer25 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D26 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot27.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis31 = null;
        org.jfree.chart.plot.Marker marker32 = null;
        java.awt.geom.Rectangle2D rectangle2D33 = null;
        lineAndShapeRenderer25.drawRangeMarker(graphics2D26, categoryPlot27, valueAxis31, marker32, rectangle2D33);
        org.jfree.chart.axis.AxisLocation axisLocation36 = null;
        categoryPlot27.setRangeAxisLocation((int) (short) 100, axisLocation36, false);
        java.awt.Color color39 = java.awt.Color.ORANGE;
        java.awt.Color color40 = color39.brighter();
        categoryPlot27.setRangeMinorGridlinePaint((java.awt.Paint) color40);
        renderAttributes20.setDefaultLabelPaint((java.awt.Paint) color40);
        java.awt.Paint paint45 = renderAttributes20.getItemPaint(10, (int) (short) 1);
        java.awt.Color color46 = org.jfree.chart.ChartColor.DARK_GREEN;
        renderAttributes20.setDefaultLabelPaint((java.awt.Paint) color46);
        categoryPlot2.setRangeZeroBaselinePaint((java.awt.Paint) color46);
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNull(paint24);
        org.junit.Assert.assertNotNull(color39);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNull(paint45);
        org.junit.Assert.assertNotNull(color46);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.Color color0 = java.awt.Color.yellow;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean2 = legendItem1.isLineVisible();
        legendItem1.setDescription("{0}");
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        java.awt.Paint paint3 = categoryAxis0.getLabelPaint();
        java.awt.Paint paint4 = categoryAxis0.getAxisLinePaint();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(paint4);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.lang.Object obj5 = categoryPlot0.clone();
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot0.getRangeMarkers(layer6);
        categoryPlot0.setRangePannable(true);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.axis.ValueAxis[] valueAxisArray11 = new org.jfree.chart.axis.ValueAxis[] { valueAxis10 };
        categoryPlot0.setRangeAxes(valueAxisArray11);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNotNull(valueAxisArray11);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Paint paint5 = null;
        try {
            org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem(attributedString0, "org.jfree.chart.event.ChartChangeEvent[source=100.0]", "ItemLabelAnchor.INSIDE9", "GradientPaintTransformType.CENTER_VERTICAL", shape4, paint5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke5 = defaultDrawingSupplier4.getNextOutlineStroke();
        categoryPlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4, true);
        java.awt.Paint paint8 = defaultDrawingSupplier4.getNextPaint();
        java.awt.Shape shape9 = defaultDrawingSupplier4.getNextShape();
        java.awt.Stroke stroke10 = defaultDrawingSupplier4.getNextOutlineStroke();
        legendItem1.setOutlineStroke(stroke10);
        org.jfree.data.general.Dataset dataset12 = null;
        legendItem1.setDataset(dataset12);
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = lineAndShapeRenderer0.getPlot();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(categoryPlot3);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        java.awt.Shape shape10 = lineAndShapeRenderer0.getBaseLegendShape();
        java.awt.Paint paint12 = null;
        lineAndShapeRenderer0.setSeriesItemLabelPaint((int) '4', paint12);
        org.junit.Assert.assertNull(shape10);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) true);
        java.awt.Stroke stroke3 = renderAttributes0.getDefaultOutlineStroke();
        java.awt.Stroke stroke5 = renderAttributes0.getSeriesStroke((int) (byte) 0);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(stroke5);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection0.addAll(legendItemCollection1);
        int int3 = legendItemCollection1.getItemCount();
        int int4 = legendItemCollection1.getItemCount();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        double double16 = barRenderer12.getShadowYOffset();
        double double17 = barRenderer12.getItemMargin();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke21 = lineAndShapeRenderer19.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint23 = lineAndShapeRenderer19.lookupLegendTextPaint((int) '#');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor24 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor24, textAnchor25);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor27 = itemLabelPosition26.getItemLabelAnchor();
        lineAndShapeRenderer19.setBasePositiveItemLabelPosition(itemLabelPosition26);
        barRenderer12.setSeriesNegativeItemLabelPosition(4, itemLabelPosition26, false);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(itemLabelAnchor24);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(itemLabelAnchor27);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape5, "AxisLocation.TOP_OR_RIGHT", "hi!");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean14 = lineAndShapeRenderer10.getDrawOutlines();
        java.awt.Paint paint18 = lineAndShapeRenderer10.getItemLabelPaint((int) (byte) 10, (int) (byte) -1, false);
        boolean boolean19 = chartEntity9.equals((java.lang.Object) lineAndShapeRenderer10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        lineAndShapeRenderer20.drawRangeMarker(graphics2D21, categoryPlot22, valueAxis26, marker27, rectangle2D28);
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = categoryPlot22.getDomainMarkers(layer30);
        org.jfree.chart.renderer.category.BarRenderer barRenderer32 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot22.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer32);
        boolean boolean35 = barRenderer32.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition36 = barRenderer32.getBaseNegativeItemLabelPosition();
        barRenderer32.setShadowYOffset((double) (-1L));
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke41 = lineAndShapeRenderer39.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint43 = lineAndShapeRenderer39.lookupLegendTextPaint((int) '#');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor44 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.text.TextAnchor textAnchor45 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition46 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor44, textAnchor45);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor47 = itemLabelPosition46.getItemLabelAnchor();
        lineAndShapeRenderer39.setBasePositiveItemLabelPosition(itemLabelPosition46);
        barRenderer32.setBaseNegativeItemLabelPosition(itemLabelPosition46, true);
        lineAndShapeRenderer10.setBaseNegativeItemLabelPosition(itemLabelPosition46, false);
        java.awt.Stroke stroke54 = lineAndShapeRenderer10.lookupSeriesStroke((int) (byte) 10);
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition36);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNotNull(itemLabelAnchor44);
        org.junit.Assert.assertNotNull(textAnchor45);
        org.junit.Assert.assertNotNull(itemLabelAnchor47);
        org.junit.Assert.assertNotNull(stroke54);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot0.setRangeAxis(valueAxis5);
        org.jfree.chart.axis.AxisSpace axisSpace7 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace7);
        categoryPlot0.setRangeCrosshairValue(0.0d, false);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        try {
            categoryPlot0.handleClick(2, 0, plotRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        categoryPlot0.setDataset(categoryDataset5);
        categoryPlot0.setNoDataMessage("");
        java.lang.Comparable comparable9 = categoryPlot0.getDomainCrosshairColumnKey();
        org.jfree.chart.plot.CategoryMarker categoryMarker10 = null;
        org.jfree.chart.util.Layer layer11 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker10, layer11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(comparable9);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint2 = lineAndShapeRenderer0.getSeriesPaint((int) (byte) 0);
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getSeriesStroke(1);
        double double5 = lineAndShapeRenderer0.getItemMargin();
        java.awt.Font font9 = lineAndShapeRenderer0.getItemLabelFont((int) '#', 0, false);
        java.lang.Boolean boolean11 = lineAndShapeRenderer0.getSeriesItemLabelsVisible((-35));
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNull(boolean11);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot29.getRangeAxisEdge(100);
        categoryPlot29.setCrosshairDatasetIndex(100, true);
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot29.getDomainAxisEdge();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(rectangleEdge47);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        java.lang.String str7 = legendItem1.getToolTipText();
        org.jfree.chart.renderer.RenderAttributes renderAttributes8 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint11 = renderAttributes8.getItemPaint(10, (int) (short) 0);
        java.awt.Paint paint12 = renderAttributes8.getDefaultFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot15.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis19 = null;
        org.jfree.chart.plot.Marker marker20 = null;
        java.awt.geom.Rectangle2D rectangle2D21 = null;
        lineAndShapeRenderer13.drawRangeMarker(graphics2D14, categoryPlot15, valueAxis19, marker20, rectangle2D21);
        org.jfree.chart.axis.AxisLocation axisLocation24 = null;
        categoryPlot15.setRangeAxisLocation((int) (short) 100, axisLocation24, false);
        java.awt.Color color27 = java.awt.Color.ORANGE;
        java.awt.Color color28 = color27.brighter();
        categoryPlot15.setRangeMinorGridlinePaint((java.awt.Paint) color28);
        renderAttributes8.setDefaultLabelPaint((java.awt.Paint) color28);
        java.awt.Paint paint33 = renderAttributes8.getItemPaint(10, (int) (short) 1);
        java.awt.Color color34 = org.jfree.chart.ChartColor.DARK_GREEN;
        renderAttributes8.setDefaultLabelPaint((java.awt.Paint) color34);
        legendItem1.setLabelPaint((java.awt.Paint) color34);
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNull(str7);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(color27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertNull(paint33);
        org.junit.Assert.assertNotNull(color34);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape5, "AxisLocation.TOP_OR_RIGHT", "hi!");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer10.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean14 = lineAndShapeRenderer10.getDrawOutlines();
        java.awt.Paint paint18 = lineAndShapeRenderer10.getItemLabelPaint((int) (byte) 10, (int) (byte) -1, false);
        boolean boolean19 = chartEntity9.equals((java.lang.Object) lineAndShapeRenderer10);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot22.setNoDataMessagePaint((java.awt.Paint) color23);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator28 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color23, (float) ' ', (int) (byte) 0, (double) (-1));
        lineAndShapeRenderer10.setSeriesOutlinePaint((int) (byte) 100, (java.awt.Paint) color23, false);
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(paint18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        lineAndShapeRenderer15.drawRangeMarker(graphics2D16, categoryPlot17, valueAxis21, marker22, rectangle2D23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot17.setRangeAxisLocation((int) (short) 100, axisLocation26, false);
        java.awt.Color color29 = java.awt.Color.ORANGE;
        java.awt.Color color30 = color29.brighter();
        categoryPlot17.setRangeMinorGridlinePaint((java.awt.Paint) color30);
        boolean boolean32 = barRenderer12.hasListener((java.util.EventListener) categoryPlot17);
        int int33 = categoryPlot17.getDomainAxisCount();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        java.awt.Color color10 = java.awt.Color.WHITE;
        categoryPlot2.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot2.panRangeAxes(0.0d, plotRenderingInfo13, point2D14);
        java.awt.Stroke stroke16 = categoryPlot2.getRangeZeroBaselineStroke();
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(stroke16);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4194304) + "'", int1 == (-4194304));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.data.category.CategoryDataset categoryDataset5 = null;
        categoryPlot0.setDataset(categoryDataset5);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot0.getDomainAxis((int) (short) 100);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation9 = null;
        try {
            categoryPlot0.addAnnotation(categoryAnnotation9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(categoryAxis8);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        lineAndShapeRenderer0.setAutoPopulateSeriesOutlinePaint(true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        boolean boolean4 = categoryPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) (short) 100, plotRenderingInfo6, point2D7, true);
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        categoryPlot0.setDataset(categoryDataset10);
        categoryPlot0.setDomainCrosshairVisible(false);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = null;
        org.jfree.chart.util.Layer layer16 = null;
        try {
            categoryPlot0.addDomainMarker((int) (short) 0, categoryMarker15, layer16, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean2 = legendItem1.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int7 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean8 = legendItem1.equals((java.lang.Object) categoryPlot3);
        boolean boolean9 = categoryPlot3.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot3.zoomRangeAxes(4.0d, plotRenderingInfo11, point2D12, false);
        categoryPlot3.configureDomainAxes();
        categoryPlot3.setOutlineVisible(true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.renderer.category.BarRenderer.setDefaultShadowsVisible(false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("hi!");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("hi!");
        org.jfree.data.UnknownKeyException unknownKeyException5 = new org.jfree.data.UnknownKeyException("hi!");
        unknownKeyException3.addSuppressed((java.lang.Throwable) unknownKeyException5);
        org.jfree.data.UnknownKeyException unknownKeyException8 = new org.jfree.data.UnknownKeyException("hi!");
        unknownKeyException5.addSuppressed((java.lang.Throwable) unknownKeyException8);
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException5);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke14 = defaultDrawingSupplier13.getNextOutlineStroke();
        categoryPlot12.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier13, true);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot12.getDomainAxisLocation(1);
        org.jfree.chart.axis.AxisLocation axisLocation19 = axisLocation18.getOpposite();
        boolean boolean20 = lineAndShapeRenderer0.equals((java.lang.Object) axisLocation19);
        org.jfree.chart.axis.AxisLocation axisLocation21 = axisLocation19.getOpposite();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(axisLocation21);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo43 = null;
        java.awt.geom.Point2D point2D44 = null;
        categoryPlot29.zoomDomainAxes((double) (-1L), plotRenderingInfo43, point2D44);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setLabelAngle(100.0d);
        categoryPlot0.setDomainAxis((int) (short) 100, categoryAxis5, true);
        org.jfree.chart.plot.Plot plot10 = categoryPlot0.getRootPlot();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(plot10);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        org.jfree.chart.plot.PlotOrientation plotOrientation13 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color14 = java.awt.Color.WHITE;
        boolean boolean15 = plotOrientation13.equals((java.lang.Object) color14);
        try {
            lineAndShapeRenderer0.setLegendTextPaint((int) (short) -1, (java.awt.Paint) color14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(plotOrientation13);
        org.junit.Assert.assertNotNull(color14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        lineAndShapeRenderer0.setSeriesShapesFilled(0, (java.lang.Boolean) false);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator17);
        lineAndShapeRenderer0.setUseSeriesOffset(true);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        org.jfree.chart.LegendItemCollection legendItemCollection1 = new org.jfree.chart.LegendItemCollection();
        legendItemCollection0.addAll(legendItemCollection1);
        int int3 = legendItemCollection1.getItemCount();
        try {
            org.jfree.chart.LegendItem legendItem5 = legendItemCollection1.get((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 1, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Paint paint5 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.chart.plot.Marker marker7 = null;
        org.jfree.chart.util.Layer layer8 = null;
        try {
            boolean boolean10 = categoryPlot0.removeRangeMarker((int) (short) 0, marker7, layer8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertNotNull(paint5);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        double double5 = rectangleInsets3.calculateTopOutset((double) 1.0f);
        double double7 = rectangleInsets3.calculateLeftInset(100.0d);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D9 = rectangleInsets3.createInsetRectangle(rectangle2D8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.0d + "'", double7 == 8.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        lineAndShapeRenderer14.drawRangeMarker(graphics2D15, categoryPlot16, valueAxis20, marker21, rectangle2D22);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot16.getDomainMarkers(layer24);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer26);
        boolean boolean29 = barRenderer26.isSeriesVisible((int) (short) -1);
        barRenderer26.setAutoPopulateSeriesStroke(true);
        boolean boolean32 = barRenderer26.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Shape shape34 = barRenderer26.getSeriesShape((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color36 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot35.setNoDataMessagePaint((java.awt.Paint) color36);
        barRenderer26.setShadowPaint((java.awt.Paint) color36);
        categoryPlot2.setRangeGridlinePaint((java.awt.Paint) color36);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(shape34);
        org.junit.Assert.assertNotNull(color36);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) true);
        java.awt.Stroke stroke3 = renderAttributes0.getDefaultOutlineStroke();
        java.awt.Stroke stroke5 = null;
        try {
            renderAttributes0.setSeriesOutlineStroke((int) (byte) 1, stroke5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(stroke3);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color6 = java.awt.Color.darkGray;
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color6, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, true);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean16 = lineAndShapeRenderer13.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer13.setPlot(categoryPlot17);
        categoryPlot17.setBackgroundImageAlignment((int) (short) 0);
        java.util.List list21 = categoryPlot17.getAnnotations();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = categoryPlot17.getFixedLegendItems();
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        try {
            lineAndShapeRenderer0.drawBackground(graphics2D12, categoryPlot17, rectangle2D23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(list21);
        org.junit.Assert.assertNull(legendItemCollection22);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemLabelPaint((int) (byte) 10, (int) (byte) -1, false);
        int int9 = lineAndShapeRenderer0.getPassCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot10.setNoDataMessagePaint((java.awt.Paint) color11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot10.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setLabelAngle(100.0d);
        categoryPlot10.setDomainAxis((int) (short) 100, categoryAxis15, true);
        java.awt.Image image20 = categoryPlot10.getBackgroundImage();
        categoryPlot10.setNotify(false);
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot10.getFixedRangeAxisSpace();
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean27 = legendItem26.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot28.setNoDataMessagePaint((java.awt.Paint) color29);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer31 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int32 = categoryPlot28.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer31);
        boolean boolean33 = legendItem26.equals((java.lang.Object) categoryPlot28);
        java.awt.Color color34 = java.awt.Color.magenta;
        categoryPlot28.setRangeCrosshairPaint((java.awt.Paint) color34);
        boolean boolean36 = lineAndShapeRenderer0.hasListener((java.util.EventListener) categoryPlot28);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1) + "'", int32 == (-1));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(color34);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.data.general.DatasetGroup datasetGroup1 = new org.jfree.data.general.DatasetGroup("hi!");
        java.lang.String str2 = datasetGroup1.getID();
        java.lang.Object obj3 = datasetGroup1.clone();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "hi!" + "'", str2.equals("hi!"));
        org.junit.Assert.assertNotNull(obj3);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        barRenderer0.setMaximumBarWidth((double) 0.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = barRenderer0.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator14 = barRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(itemLabelPosition13);
        org.junit.Assert.assertNull(categoryItemLabelGenerator14);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        java.lang.String str1 = rectangleInsets0.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str1.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.util.SortOrder sortOrder0 = org.jfree.chart.util.SortOrder.DESCENDING;
        org.junit.Assert.assertNotNull(sortOrder0);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getTickMarkOutsideLength();
        categoryAxis0.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis0.getTickLabelInsets();
        double double6 = rectangleInsets4.calculateTopOutset((double) 32.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0f + "'", float1 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        try {
            java.lang.String str4 = standardCategorySeriesLabelGenerator1.generateLabel(categoryDataset2, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier2 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke3 = defaultDrawingSupplier2.getNextOutlineStroke();
        categoryPlot1.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier2, true);
        java.awt.Paint paint6 = defaultDrawingSupplier2.getNextPaint();
        boolean boolean7 = datasetRenderingOrder0.equals((java.lang.Object) paint6);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke10 = defaultDrawingSupplier9.getNextOutlineStroke();
        categoryPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9, true);
        java.awt.Paint paint13 = defaultDrawingSupplier9.getNextPaint();
        java.awt.Shape shape14 = defaultDrawingSupplier9.getNextShape();
        org.jfree.chart.LegendItem legendItem16 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = legendItem16.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape20 = legendItem19.getLine();
        legendItem16.setShape(shape20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke24 = lineAndShapeRenderer22.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint26 = lineAndShapeRenderer22.lookupLegendTextPaint((int) '#');
        java.awt.Stroke stroke30 = lineAndShapeRenderer22.getItemStroke(1, (int) (short) 1, false);
        legendItem16.setOutlineStroke(stroke30);
        java.lang.String str32 = legendItem16.getToolTipText();
        boolean boolean33 = defaultDrawingSupplier9.equals((java.lang.Object) legendItem16);
        boolean boolean34 = datasetRenderingOrder0.equals((java.lang.Object) defaultDrawingSupplier9);
        java.awt.Paint paint35 = defaultDrawingSupplier9.getNextFillPaint();
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNotNull(paint6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer17);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNull(paint26);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNull(str32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(paint35);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE7;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        categoryPlot2.clearSelection();
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.PlotOrientation plotOrientation0 = org.jfree.chart.plot.PlotOrientation.VERTICAL;
        org.junit.Assert.assertNotNull(plotOrientation0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        java.awt.Color color0 = java.awt.Color.PINK;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("AxisLocation.TOP_OR_RIGHT", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean2 = legendItem1.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int7 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean8 = legendItem1.equals((java.lang.Object) categoryPlot3);
        boolean boolean9 = categoryPlot3.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot3.zoomRangeAxes(4.0d, plotRenderingInfo11, point2D12, false);
        org.jfree.chart.plot.Marker marker16 = null;
        org.jfree.chart.util.Layer layer17 = null;
        boolean boolean18 = categoryPlot3.removeDomainMarker(4, marker16, layer17);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape0, "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getTickMarkOutsideLength();
        categoryAxis0.setCategoryMargin((double) 8);
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        float float5 = categoryAxis0.getMinorTickMarkInsideLength();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0f + "'", float1 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) 'a');
        objectList1.clear();
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot4.setNoDataMessagePaint((java.awt.Paint) color5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int8 = categoryPlot4.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color11 = java.awt.Color.WHITE;
        boolean boolean12 = plotOrientation10.equals((java.lang.Object) color11);
        int int13 = color11.getBlue();
        lineAndShapeRenderer7.setSeriesFillPaint(1, (java.awt.Paint) color11);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color17 = java.awt.Color.WHITE;
        boolean boolean18 = plotOrientation16.equals((java.lang.Object) color17);
        int int19 = color17.getBlue();
        lineAndShapeRenderer7.setSeriesOutlinePaint(0, (java.awt.Paint) color17, false);
        objectList1.set((int) 'a', (java.lang.Object) lineAndShapeRenderer7);
        lineAndShapeRenderer7.setBaseItemLabelsVisible(false);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(color17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 255 + "'", int19 == 255);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier6 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke7 = defaultDrawingSupplier6.getNextOutlineStroke();
        categoryPlot5.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier6, true);
        java.awt.Paint paint10 = defaultDrawingSupplier6.getNextPaint();
        java.awt.Shape shape11 = defaultDrawingSupplier6.getNextShape();
        java.awt.Color color13 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Color color15 = java.awt.Color.darkGray;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer16 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke18 = lineAndShapeRenderer16.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke20 = lineAndShapeRenderer16.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem23 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape24 = legendItem23.getLine();
        java.awt.Font font25 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem23.setLabelFont(font25);
        lineAndShapeRenderer16.setSeriesItemLabelFont((int) ' ', font25);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier29 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke30 = defaultDrawingSupplier29.getNextOutlineStroke();
        categoryPlot28.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier29, true);
        org.jfree.chart.axis.AxisLocation axisLocation34 = categoryPlot28.getDomainAxisLocation(1);
        org.jfree.chart.axis.AxisLocation axisLocation35 = axisLocation34.getOpposite();
        boolean boolean36 = lineAndShapeRenderer16.equals((java.lang.Object) axisLocation35);
        boolean boolean37 = lineAndShapeRenderer16.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color40 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot39.setNoDataMessagePaint((java.awt.Paint) color40);
        org.jfree.chart.util.RectangleInsets rectangleInsets42 = categoryPlot39.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray44 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis43 };
        categoryPlot39.setDomainAxes(categoryAxisArray44);
        java.awt.Stroke stroke46 = categoryPlot39.getDomainCrosshairStroke();
        lineAndShapeRenderer16.setSeriesOutlineStroke((int) '#', stroke46, false);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor50 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.jfree.chart.LegendItem legendItem52 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer53 = legendItem52.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem55 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape56 = legendItem55.getLine();
        legendItem52.setShape(shape56);
        boolean boolean58 = itemLabelAnchor50.equals((java.lang.Object) shape56);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer59 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer59.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        java.awt.Stroke stroke64 = lineAndShapeRenderer59.lookupSeriesOutlineStroke(0);
        org.jfree.chart.plot.CategoryPlot categoryPlot65 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier66 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke67 = defaultDrawingSupplier66.getNextOutlineStroke();
        categoryPlot65.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier66, true);
        org.jfree.chart.axis.AxisLocation axisLocation71 = categoryPlot65.getDomainAxisLocation(1);
        categoryPlot65.setForegroundAlpha((float) (short) 100);
        java.awt.Paint paint74 = categoryPlot65.getNoDataMessagePaint();
        try {
            org.jfree.chart.LegendItem legendItem75 = new org.jfree.chart.LegendItem(attributedString0, "", "RectangleInsets[t=4.0,l=8.0,b=4.0,r=8.0]", "poly", false, shape11, false, (java.awt.Paint) color13, false, (java.awt.Paint) color15, stroke46, false, shape56, stroke64, paint74);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(font25);
        org.junit.Assert.assertNotNull(stroke30);
        org.junit.Assert.assertNotNull(axisLocation34);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(color40);
        org.junit.Assert.assertNotNull(rectangleInsets42);
        org.junit.Assert.assertNotNull(categoryAxisArray44);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNotNull(itemLabelAnchor50);
        org.junit.Assert.assertNotNull(gradientPaintTransformer53);
        org.junit.Assert.assertNotNull(shape56);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(stroke64);
        org.junit.Assert.assertNotNull(stroke67);
        org.junit.Assert.assertNotNull(axisLocation71);
        org.junit.Assert.assertNotNull(paint74);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        java.awt.Color color0 = java.awt.Color.cyan;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke7 = lineAndShapeRenderer5.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke9 = lineAndShapeRenderer5.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem12 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape13 = legendItem12.getLine();
        java.awt.Font font14 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem12.setLabelFont(font14);
        lineAndShapeRenderer5.setSeriesItemLabelFont((int) ' ', font14);
        lineAndShapeRenderer5.setSeriesShapesFilled(0, (java.lang.Boolean) false);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer27 = legendItem26.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem29 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape30 = legendItem29.getLine();
        legendItem26.setShape(shape30);
        org.jfree.chart.entity.ChartEntity chartEntity34 = new org.jfree.chart.entity.ChartEntity(shape30, "AxisLocation.TOP_OR_RIGHT", "hi!");
        java.awt.Shape shape35 = chartEntity34.getArea();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier36 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke37 = defaultDrawingSupplier36.getNextOutlineStroke();
        java.awt.Paint paint38 = null;
        org.jfree.chart.LegendItem legendItem39 = new org.jfree.chart.LegendItem("RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", "ItemLabelAnchor.INSIDE9", "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]", shape35, stroke37, paint38);
        lineAndShapeRenderer5.setSeriesOutlineStroke((int) (byte) 10, stroke37);
        try {
            lineAndShapeRenderer0.setSeriesStroke((int) (byte) -1, stroke37);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(shape13);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer27);
        org.junit.Assert.assertNotNull(shape30);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(stroke37);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint2 = lineAndShapeRenderer0.getSeriesPaint((int) (byte) 0);
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getSeriesStroke(1);
        double double5 = lineAndShapeRenderer0.getItemMargin();
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(true);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        java.lang.Object obj0 = null;
        try {
            org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent(obj0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke14 = defaultDrawingSupplier13.getNextOutlineStroke();
        categoryPlot12.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier13, true);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot12.getDomainAxisLocation(1);
        org.jfree.chart.axis.AxisLocation axisLocation19 = axisLocation18.getOpposite();
        boolean boolean20 = lineAndShapeRenderer0.equals((java.lang.Object) axisLocation19);
        boolean boolean21 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = lineAndShapeRenderer0.getLegendItems();
        lineAndShapeRenderer0.setDrawOutlines(false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(legendItemCollection22);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        java.lang.Object obj1 = keyedObjects0.clone();
        try {
            java.lang.Object obj3 = keyedObjects0.getObject((java.lang.Comparable) 32.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (32.0) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemLabelPaint((int) (byte) 10, (int) (byte) -1, false);
        int int9 = lineAndShapeRenderer0.getPassCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot10.setNoDataMessagePaint((java.awt.Paint) color11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot10.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setLabelAngle(100.0d);
        categoryPlot10.setDomainAxis((int) (short) 100, categoryAxis15, true);
        java.awt.Image image20 = categoryPlot10.getBackgroundImage();
        categoryPlot10.setNotify(false);
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot10.getFixedRangeAxisSpace();
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        int int25 = categoryPlot10.getCrosshairDatasetIndex();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot1.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot1.setDomainAxes(categoryAxisArray6);
        java.awt.Stroke stroke8 = categoryPlot1.getDomainCrosshairStroke();
        categoryPlot0.setDomainGridlineStroke(stroke8);
        org.jfree.data.event.DatasetChangeEvent datasetChangeEvent10 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent10);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        java.awt.Stroke stroke0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        org.junit.Assert.assertNotNull(stroke0);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        lineAndShapeRenderer0.setBaseShapesFilled(true);
        try {
            lineAndShapeRenderer0.setSeriesCreateEntities((-4194304), (java.lang.Boolean) false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        lineAndShapeRenderer5.drawRangeMarker(graphics2D6, categoryPlot7, valueAxis11, marker12, rectangle2D13);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke16 = defaultDrawingSupplier15.getNextOutlineStroke();
        categoryPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot19.getFixedRangeAxisSpace();
        boolean boolean21 = defaultDrawingSupplier15.equals((java.lang.Object) categoryPlot19);
        org.jfree.chart.axis.AxisSpace axisSpace22 = null;
        categoryPlot19.setFixedDomainAxisSpace(axisSpace22);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.awt.Image image5 = categoryPlot0.getBackgroundImage();
        java.awt.Paint paint6 = categoryPlot0.getNoDataMessagePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(image5);
        org.junit.Assert.assertNotNull(paint6);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.util.StrokeList strokeList0 = new org.jfree.chart.util.StrokeList();
        java.lang.Object obj1 = strokeList0.clone();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot5.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis9 = null;
        org.jfree.chart.plot.Marker marker10 = null;
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        lineAndShapeRenderer3.drawRangeMarker(graphics2D4, categoryPlot5, valueAxis9, marker10, rectangle2D11);
        org.jfree.chart.util.Layer layer13 = null;
        java.util.Collection collection14 = categoryPlot5.getDomainMarkers(layer13);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo17 = null;
        java.awt.geom.Point2D point2D18 = null;
        categoryPlot5.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo17, point2D18);
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        categoryPlot5.setFixedDomainAxisSpace(axisSpace20);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot5.getDomainMarkers(layer22);
        java.awt.Stroke stroke24 = categoryPlot5.getRangeGridlineStroke();
        strokeList0.setStroke(1, stroke24);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer26 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke28 = lineAndShapeRenderer26.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint30 = lineAndShapeRenderer26.lookupLegendTextPaint((int) '#');
        boolean boolean31 = lineAndShapeRenderer26.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color35 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot34.setNoDataMessagePaint((java.awt.Paint) color35);
        org.jfree.chart.util.RectangleInsets rectangleInsets37 = categoryPlot34.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray39 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis38 };
        categoryPlot34.setDomainAxes(categoryAxisArray39);
        java.awt.Stroke stroke41 = categoryPlot34.getDomainCrosshairStroke();
        categoryPlot33.setDomainGridlineStroke(stroke41);
        lineAndShapeRenderer26.setSeriesOutlineStroke((int) ' ', stroke41, true);
        boolean boolean45 = strokeList0.equals((java.lang.Object) lineAndShapeRenderer26);
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertNull(collection14);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertNotNull(stroke24);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertNull(paint30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(color35);
        org.junit.Assert.assertNotNull(rectangleInsets37);
        org.junit.Assert.assertNotNull(categoryAxisArray39);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer0.getPositiveItemLabelPosition((int) (short) 1, (int) (byte) 1, true);
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getTextAnchor();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemLabelPaint((int) (byte) 10, (int) (byte) -1, false);
        int int9 = lineAndShapeRenderer0.getPassCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot10.setNoDataMessagePaint((java.awt.Paint) color11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot10.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setLabelAngle(100.0d);
        categoryPlot10.setDomainAxis((int) (short) 100, categoryAxis15, true);
        java.awt.Image image20 = categoryPlot10.getBackgroundImage();
        categoryPlot10.setNotify(false);
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot10.getFixedRangeAxisSpace();
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        lineAndShapeRenderer0.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertNull(axisSpace23);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) 0.5f);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        java.lang.String str4 = unitType3.toString();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "UnitType.ABSOLUTE" + "'", str4.equals("UnitType.ABSOLUTE"));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        double double16 = barRenderer12.getShadowYOffset();
        java.awt.Color color18 = java.awt.Color.ORANGE;
        java.awt.Color color19 = color18.brighter();
        barRenderer12.setSeriesOutlinePaint((int) '4', (java.awt.Paint) color19, true);
        double double22 = barRenderer12.getMaximumBarWidth();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        lineAndShapeRenderer15.drawRangeMarker(graphics2D16, categoryPlot17, valueAxis21, marker22, rectangle2D23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot17.setRangeAxisLocation((int) (short) 100, axisLocation26, false);
        java.awt.Color color29 = java.awt.Color.ORANGE;
        java.awt.Color color30 = color29.brighter();
        categoryPlot17.setRangeMinorGridlinePaint((java.awt.Paint) color30);
        boolean boolean32 = barRenderer12.hasListener((java.util.EventListener) categoryPlot17);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation33 = null;
        try {
            barRenderer12.addAnnotation(categoryAnnotation33);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        java.awt.Stroke stroke5 = lineAndShapeRenderer0.getSeriesStroke(0);
        lineAndShapeRenderer0.setSeriesLinesVisible((int) (short) 0, (java.lang.Boolean) false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator10 = null;
        lineAndShapeRenderer0.setSeriesItemLabelGenerator(10, categoryItemLabelGenerator10, true);
        lineAndShapeRenderer0.setItemMargin((double) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = lineAndShapeRenderer0.getPositiveItemLabelPosition((int) (short) 1, (int) (byte) 1, true);
        org.jfree.chart.text.TextAnchor textAnchor8 = itemLabelPosition7.getRotationAnchor();
        java.lang.String str9 = textAnchor8.toString();
        java.lang.String str10 = textAnchor8.toString();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNotNull(textAnchor8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "TextAnchor.CENTER" + "'", str9.equals("TextAnchor.CENTER"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.CENTER" + "'", str10.equals("TextAnchor.CENTER"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextOutlineStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1, true);
        java.lang.Object obj5 = categoryPlot0.clone();
        java.awt.Image image6 = categoryPlot0.getBackgroundImage();
        categoryPlot0.setRangePannable(false);
        try {
            org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot0.getDomainAxisForDataset((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Negative 'index'.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(obj5);
        org.junit.Assert.assertNull(image6);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        int int1 = keyedObjects0.getItemCount();
        org.jfree.chart.util.SortOrder sortOrder2 = org.jfree.chart.util.SortOrder.ASCENDING;
        java.lang.String str3 = sortOrder2.toString();
        keyedObjects0.sortByKeys(sortOrder2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(sortOrder2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "SortOrder.ASCENDING" + "'", str3.equals("SortOrder.ASCENDING"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.jfree.chart.util.ObjectList objectList0 = new org.jfree.chart.util.ObjectList();
        java.lang.Object obj1 = objectList0.clone();
        objectList0.clear();
        int int3 = objectList0.size();
        org.junit.Assert.assertNotNull(obj1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("hi!");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("hi!");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
        org.jfree.data.UnknownKeyException unknownKeyException6 = new org.jfree.data.UnknownKeyException("hi!");
        unknownKeyException3.addSuppressed((java.lang.Throwable) unknownKeyException6);
        java.lang.String str8 = unknownKeyException3.toString();
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.jfree.data.UnknownKeyException: hi!" + "'", str8.equals("org.jfree.data.UnknownKeyException: hi!"));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        boolean boolean4 = categoryPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) (short) 100, plotRenderingInfo6, point2D7, true);
        categoryPlot0.clearRangeMarkers();
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        try {
            int int12 = categoryPlot0.getRangeAxisIndex(valueAxis11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'axis' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_LIGHT_CYAN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setLabel("");
        categoryAxis0.setLabel("{0}");
        java.awt.Font font7 = categoryAxis0.getTickLabelFont();
        categoryAxis0.setLabel("ChartEntity: tooltip = AxisLocation.TOP_OR_RIGHT");
        boolean boolean10 = categoryAxis0.isTickMarksVisible();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        legendItem1.setSeriesKey((java.lang.Comparable) 10L);
        java.awt.Paint paint5 = legendItem1.getLabelPaint();
        legendItem1.setShapeVisible(true);
        org.jfree.data.general.Dataset dataset8 = legendItem1.getDataset();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNull(dataset8);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        categoryPlot2.setBackgroundAlpha((float) 8);
        boolean boolean21 = categoryPlot2.isNotify();
        org.jfree.chart.plot.CategoryMarker categoryMarker23 = null;
        org.jfree.chart.util.Layer layer24 = null;
        try {
            categoryPlot2.addDomainMarker((int) 'a', categoryMarker23, layer24, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(0);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        boolean boolean5 = lineAndShapeRenderer0.isSeriesItemLabelsVisible((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        lineAndShapeRenderer5.drawRangeMarker(graphics2D6, categoryPlot7, valueAxis11, marker12, rectangle2D13);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke16 = defaultDrawingSupplier15.getNextOutlineStroke();
        categoryPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot19.getFixedRangeAxisSpace();
        boolean boolean21 = defaultDrawingSupplier15.equals((java.lang.Object) categoryPlot19);
        org.jfree.data.category.CategoryDataset categoryDataset22 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = categoryPlot19.getRendererForDataset(categoryDataset22);
        categoryPlot19.clearRangeAxes();
        categoryPlot19.clearRangeMarkers();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo27 = null;
        java.awt.geom.Point2D point2D28 = null;
        categoryPlot19.zoomDomainAxes((double) (-4194304), plotRenderingInfo27, point2D28);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNull(categoryItemRenderer23);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setLabelAngle(100.0d);
        categoryPlot0.setDomainAxis((int) (short) 100, categoryAxis5, true);
        java.lang.String str10 = categoryAxis5.getLabelToolTip();
        double double11 = categoryAxis5.getCategoryMargin();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(str10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2d + "'", double11 == 0.2d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getBaseCreateEntities();
        java.awt.Font font6 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) (byte) 10, font6);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font6);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean1 = renderAttributes0.getDefaultCreateEntity();
        java.awt.Paint paint2 = renderAttributes0.getDefaultLabelPaint();
        java.awt.Paint paint5 = renderAttributes0.getItemOutlinePaint((-1), (-1));
        java.awt.Paint paint7 = null;
        try {
            renderAttributes0.setSeriesOutlinePaint((-1), paint7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(boolean1);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(paint5);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = barRenderer12.getLegendItemLabelGenerator();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        lineAndShapeRenderer17.drawRangeMarker(graphics2D18, categoryPlot19, valueAxis23, marker24, rectangle2D25);
        boolean boolean27 = barRenderer12.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor28 = categoryPlot19.getDomainGridlinePosition();
        java.awt.Color color29 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color30 = color29.brighter();
        boolean boolean31 = categoryAnchor28.equals((java.lang.Object) color29);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(categoryAnchor28);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape5, "AxisLocation.TOP_OR_RIGHT", "hi!");
        java.lang.String str10 = chartEntity9.getShapeType();
        java.lang.String str11 = chartEntity9.getToolTipText();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "poly" + "'", str10.equals("poly"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str11.equals("AxisLocation.TOP_OR_RIGHT"));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        barRenderer12.setAutoPopulateSeriesStroke(true);
        boolean boolean18 = barRenderer12.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Shape shape20 = barRenderer12.getSeriesShape((int) (short) -1);
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot21.setNoDataMessagePaint((java.awt.Paint) color22);
        barRenderer12.setShadowPaint((java.awt.Paint) color22);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor25 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.text.TextAnchor textAnchor26 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor25, textAnchor26);
        barRenderer12.setPositiveItemLabelPositionFallback(itemLabelPosition27);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNull(shape20);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(itemLabelAnchor25);
        org.junit.Assert.assertNotNull(textAnchor26);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("");
        java.lang.String str2 = legendItem1.getDescription();
        org.junit.Assert.assertNull(str2);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean2 = legendItem1.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int7 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean8 = legendItem1.equals((java.lang.Object) categoryPlot3);
        boolean boolean9 = categoryPlot3.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot3.zoomRangeAxes(4.0d, plotRenderingInfo11, point2D12, false);
        org.jfree.chart.axis.ValueAxis valueAxis16 = categoryPlot3.getRangeAxis((int) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(valueAxis16);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets9 = categoryAxis8.getTickLabelInsets();
        float float10 = categoryAxis8.getTickMarkInsideLength();
        categoryAxis8.setLabel("");
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        try {
            lineAndShapeRenderer0.drawItem(graphics2D4, categoryItemRendererState5, rectangle2D6, categoryPlot7, categoryAxis8, valueAxis13, categoryDataset14, 4, 0, true, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(rectangleInsets9);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean6 = lineAndShapeRenderer3.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation7 = null;
        boolean boolean8 = lineAndShapeRenderer3.removeAnnotation(categoryAnnotation7);
        boolean boolean9 = categoryPlot0.equals((java.lang.Object) boolean8);
        double double10 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer12.getBaseNegativeItemLabelPosition();
        barRenderer12.setShadowYOffset((double) (-1L));
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke21 = lineAndShapeRenderer19.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint23 = lineAndShapeRenderer19.lookupLegendTextPaint((int) '#');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor24 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor24, textAnchor25);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor27 = itemLabelPosition26.getItemLabelAnchor();
        lineAndShapeRenderer19.setBasePositiveItemLabelPosition(itemLabelPosition26);
        barRenderer12.setBaseNegativeItemLabelPosition(itemLabelPosition26, true);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor31 = itemLabelPosition26.getItemLabelAnchor();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(itemLabelAnchor24);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(itemLabelAnchor27);
        org.junit.Assert.assertNotNull(itemLabelAnchor31);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets((double) 1.0f, 0.2d, 1.0d, (double) 'a');
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = null;
        barRenderer12.setBaseItemLabelGenerator(categoryItemLabelGenerator15, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator19 = null;
        barRenderer12.setSeriesToolTipGenerator(35, categoryToolTipGenerator19);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean2 = legendItem1.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int7 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean8 = legendItem1.equals((java.lang.Object) categoryPlot3);
        boolean boolean9 = categoryPlot3.isRangeZeroBaselineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot3.getRendererForDataset(categoryDataset10);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = null;
        categoryPlot3.setDomainAxis(0, categoryAxis13, false);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryItemRenderer11);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        java.awt.Color color10 = java.awt.Color.WHITE;
        categoryPlot2.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot2.panDomainAxes(0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.axis.AxisSpace axisSpace16 = null;
        categoryPlot2.setFixedRangeAxisSpace(axisSpace16, false);
        org.jfree.chart.plot.CategoryMarker categoryMarker19 = null;
        org.jfree.chart.util.Layer layer20 = null;
        try {
            categoryPlot2.addDomainMarker(categoryMarker19, layer20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot29.getRangeAxisEdge(100);
        categoryPlot29.setCrosshairDatasetIndex(100, true);
        org.jfree.chart.axis.AxisLocation axisLocation47 = categoryPlot29.getRangeAxisLocation();
        org.jfree.chart.util.RectangleInsets rectangleInsets48 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        double double50 = rectangleInsets48.calculateTopInset((double) 10);
        double double52 = rectangleInsets48.calculateLeftInset((double) (byte) 100);
        categoryPlot29.setInsets(rectangleInsets48);
        org.jfree.chart.util.Layer layer54 = null;
        java.util.Collection collection55 = categoryPlot29.getDomainMarkers(layer54);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(axisLocation47);
        org.junit.Assert.assertNotNull(rectangleInsets48);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 4.0d + "'", double50 == 4.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 8.0d + "'", double52 == 8.0d);
        org.junit.Assert.assertNull(collection55);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 0, false);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke11 = defaultDrawingSupplier10.getNextOutlineStroke();
        categoryPlot9.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10, true);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot9.getDomainAxisLocation(1);
        java.lang.String str16 = axisLocation15.toString();
        categoryPlot0.setDomainAxisLocation(8, axisLocation15);
        java.lang.String str18 = categoryPlot0.getPlotType();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str16.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "Category Plot" + "'", str18.equals("Category Plot"));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedRangeAxisSpace();
        boolean boolean2 = categoryPlot0.isRangePannable();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot6.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis10 = null;
        org.jfree.chart.plot.Marker marker11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        lineAndShapeRenderer4.drawRangeMarker(graphics2D5, categoryPlot6, valueAxis10, marker11, rectangle2D12);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot6.getDomainMarkers(layer14);
        org.jfree.chart.renderer.category.BarRenderer barRenderer16 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot6.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16);
        boolean boolean19 = barRenderer16.isSeriesVisible((int) (short) -1);
        barRenderer16.setAutoPopulateSeriesStroke(true);
        boolean boolean22 = barRenderer16.getDataBoundsIncludesVisibleSeriesOnly();
        java.awt.Color color23 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        barRenderer16.setShadowPaint((java.awt.Paint) color23);
        barRenderer16.setMaximumBarWidth((double) 2.0f);
        barRenderer16.setShadowYOffset((double) '#');
        categoryPlot0.setRenderer(2, (org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer16, false);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(collection15);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(color23);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.renderer.RenderAttributes renderAttributes1 = new org.jfree.chart.renderer.RenderAttributes(false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        java.awt.Color color4 = java.awt.Color.ORANGE;
        java.awt.Color color5 = color4.brighter();
        java.awt.Color color6 = color5.brighter();
        categoryPlot0.setRangeGridlinePaint((java.awt.Paint) color6);
        categoryPlot0.setBackgroundImageAlignment((int) (short) 10);
        categoryPlot0.setRangeCrosshairValue((double) 4);
        org.jfree.chart.axis.AxisLocation axisLocation13 = org.jfree.chart.axis.AxisLocation.TOP_OR_RIGHT;
        try {
            categoryPlot0.setRangeAxisLocation((-1), axisLocation13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(axisLocation13);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        barRenderer12.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) false, true);
        org.jfree.chart.renderer.category.BarRenderer barRenderer18 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean19 = barRenderer18.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint21 = barRenderer18.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator25 = barRenderer18.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator26 = null;
        barRenderer18.setBaseURLGenerator(categoryURLGenerator26);
        barRenderer18.setMaximumBarWidth((double) 0.0f);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition31 = barRenderer18.getSeriesPositiveItemLabelPosition((int) (byte) 10);
        barRenderer12.setBasePositiveItemLabelPosition(itemLabelPosition31, true);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(categoryItemLabelGenerator25);
        org.junit.Assert.assertNotNull(itemLabelPosition31);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.data.SelectableValue selectableValue1 = new org.jfree.data.SelectableValue((java.lang.Number) 100.0f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean2 = lineAndShapeRenderer0.isSeriesVisible((int) (byte) 0);
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int7 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        categoryPlot3.setDataset(categoryDataset8);
        org.jfree.chart.axis.AxisSpace axisSpace10 = null;
        categoryPlot3.setFixedRangeAxisSpace(axisSpace10);
        int int12 = categoryPlot3.getWeight();
        lineAndShapeRenderer0.setPlot(categoryPlot3);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.entity.ChartEntity chartEntity9 = new org.jfree.chart.entity.ChartEntity(shape5, "AxisLocation.TOP_OR_RIGHT", "hi!");
        java.awt.Shape shape10 = chartEntity9.getArea();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color13 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot12.setNoDataMessagePaint((java.awt.Paint) color13);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator18 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color13, (float) ' ', (int) (byte) 0, (double) (-1));
        double double19 = defaultShadowGenerator18.getAngle();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        lineAndShapeRenderer20.drawRangeMarker(graphics2D21, categoryPlot22, valueAxis26, marker27, rectangle2D28);
        org.jfree.chart.util.Layer layer30 = null;
        java.util.Collection collection31 = categoryPlot22.getDomainMarkers(layer30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot22.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo34, point2D35);
        org.jfree.chart.axis.AxisSpace axisSpace37 = null;
        categoryPlot22.setFixedDomainAxisSpace(axisSpace37);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer40 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean43 = lineAndShapeRenderer40.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer40.setPlot(categoryPlot44);
        categoryPlot22.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer40);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer47 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D48 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot49.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis53 = null;
        org.jfree.chart.plot.Marker marker54 = null;
        java.awt.geom.Rectangle2D rectangle2D55 = null;
        lineAndShapeRenderer47.drawRangeMarker(graphics2D48, categoryPlot49, valueAxis53, marker54, rectangle2D55);
        org.jfree.chart.axis.AxisLocation axisLocation58 = null;
        categoryPlot49.setRangeAxisLocation((int) (short) 100, axisLocation58, false);
        lineAndShapeRenderer40.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot49);
        org.jfree.chart.util.RectangleEdge rectangleEdge63 = categoryPlot49.getRangeAxisEdge(100);
        categoryPlot49.setDomainCrosshairVisible(false);
        boolean boolean66 = categoryPlot49.isRangeGridlinesVisible();
        boolean boolean67 = defaultShadowGenerator18.equals((java.lang.Object) categoryPlot49);
        org.jfree.chart.entity.PlotEntity plotEntity68 = new org.jfree.chart.entity.PlotEntity(shape10, (org.jfree.chart.plot.Plot) categoryPlot49);
        java.lang.Object obj69 = plotEntity68.clone();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(color13);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-1.0d) + "'", double19 == (-1.0d));
        org.junit.Assert.assertNull(collection31);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertNotNull(rectangleEdge63);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(obj69);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = legendItem1.getFillPaintTransformer();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer0.setPlot(categoryPlot4);
        categoryPlot4.setBackgroundImageAlignment((int) (short) 0);
        java.util.List list8 = categoryPlot4.getAnnotations();
        org.jfree.chart.LegendItemCollection legendItemCollection9 = categoryPlot4.getFixedLegendItems();
        int int10 = categoryPlot4.getWeight();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(list8);
        org.junit.Assert.assertNull(legendItemCollection9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color6 = java.awt.Color.darkGray;
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color6, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        lineAndShapeRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator9, true);
        java.awt.Paint paint13 = lineAndShapeRenderer0.getSeriesItemLabelPaint(0);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (short) 1, (java.lang.Boolean) true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(paint13);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextOutlineStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1, true);
        java.awt.Paint paint5 = defaultDrawingSupplier1.getNextPaint();
        java.awt.Shape shape6 = defaultDrawingSupplier1.getNextShape();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer7.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean11 = defaultDrawingSupplier1.equals((java.lang.Object) lineAndShapeRenderer7);
        java.awt.Stroke stroke13 = lineAndShapeRenderer7.getSeriesStroke(10);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator14 = lineAndShapeRenderer7.getBaseURLGenerator();
        double double15 = lineAndShapeRenderer7.getItemLabelAnchorOffset();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNull(stroke13);
        org.junit.Assert.assertNull(categoryURLGenerator14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.0d + "'", double15 == 2.0d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_CYAN;
        int int1 = color0.getBlue();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 192 + "'", int1 == 192);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.plot.Marker marker43 = null;
        org.jfree.chart.util.Layer layer44 = null;
        boolean boolean46 = categoryPlot29.removeDomainMarker((int) (short) 100, marker43, layer44, false);
        org.jfree.chart.axis.ValueAxis valueAxis48 = categoryPlot29.getRangeAxisForDataset(15);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNull(valueAxis48);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        java.util.Locale locale1 = null;
        java.lang.ClassLoader classLoader2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = org.jfree.chart.util.ResourceBundleWrapper.getBundle("DatasetRenderingOrder.FORWARD", locale1, classLoader2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator27 = null;
        lineAndShapeRenderer20.setBaseToolTipGenerator(categoryToolTipGenerator27);
        boolean boolean32 = lineAndShapeRenderer20.isItemLabelVisible(0, 0, false);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        java.awt.Paint paint3 = categoryAxis0.getLabelPaint();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis0.getTickLabelInsets();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleInsets4);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double1 = rectangleInsets0.getTop();
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = rectangleInsets0.createInsetRectangle(rectangle2D2, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean1 = renderAttributes0.getDefaultCreateEntity();
        java.awt.Paint paint3 = renderAttributes0.getSeriesOutlinePaint((int) (byte) 0);
        org.junit.Assert.assertNull(boolean1);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis5.setLabelAngle(100.0d);
        categoryPlot0.setDomainAxis((int) (short) 100, categoryAxis5, true);
        java.awt.Image image10 = categoryPlot0.getBackgroundImage();
        categoryPlot0.setNotify(false);
        org.jfree.chart.plot.Marker marker13 = null;
        org.jfree.chart.util.Layer layer14 = null;
        boolean boolean15 = categoryPlot0.removeDomainMarker(marker13, layer14);
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        try {
            categoryPlot0.setRangeAxisLocation(axisLocation16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'location' for index 0 not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(image10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint3 = renderAttributes0.getItemPaint(10, (int) (short) 0);
        java.awt.Paint paint4 = renderAttributes0.getDefaultFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        lineAndShapeRenderer5.drawRangeMarker(graphics2D6, categoryPlot7, valueAxis11, marker12, rectangle2D13);
        org.jfree.chart.axis.AxisLocation axisLocation16 = null;
        categoryPlot7.setRangeAxisLocation((int) (short) 100, axisLocation16, false);
        java.awt.Color color19 = java.awt.Color.ORANGE;
        java.awt.Color color20 = color19.brighter();
        categoryPlot7.setRangeMinorGridlinePaint((java.awt.Paint) color20);
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color20);
        java.awt.Stroke stroke23 = renderAttributes0.getDefaultStroke();
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertNull(stroke23);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        java.awt.image.ColorModel colorModel1 = null;
        java.awt.Rectangle rectangle2 = null;
        java.awt.geom.Rectangle2D rectangle2D3 = null;
        java.awt.geom.AffineTransform affineTransform4 = null;
        java.awt.RenderingHints renderingHints5 = null;
        java.awt.PaintContext paintContext6 = color0.createContext(colorModel1, rectangle2, rectangle2D3, affineTransform4, renderingHints5);
        int int7 = color0.getTransparency();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(paintContext6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        java.awt.Paint paint3 = categoryAxis0.getLabelPaint();
        org.jfree.chart.plot.Plot plot4 = categoryAxis0.getPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color6 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot5.setNoDataMessagePaint((java.awt.Paint) color6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = categoryPlot5.getInsets();
        double double10 = rectangleInsets8.calculateTopOutset((double) 1.0f);
        double double12 = rectangleInsets8.calculateLeftInset(100.0d);
        categoryAxis0.setTickLabelInsets(rectangleInsets8);
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier18 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke19 = defaultDrawingSupplier18.getNextOutlineStroke();
        categoryPlot17.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier18, true);
        org.jfree.chart.axis.AxisLocation axisLocation23 = categoryPlot17.getDomainAxisLocation(1);
        java.lang.String str24 = axisLocation23.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation23, plotOrientation25);
        try {
            double double27 = categoryAxis0.getCategoryEnd((int) (byte) 100, 0, rectangle2D16, rectangleEdge26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(plot4);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.0d + "'", double10 == 4.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 8.0d + "'", double12 == 8.0d);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(axisLocation23);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str24.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray5 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis4 };
        categoryPlot0.setDomainAxes(categoryAxisArray5);
        boolean boolean7 = categoryPlot0.isDomainCrosshairVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNotNull(categoryAxisArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) 0.5f);
        double double3 = rectangleInsets0.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.0d + "'", double3 == 3.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        categoryPlot2.clearRangeMarkers(0);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier21 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        categoryPlot2.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier21, false);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        lineAndShapeRenderer20.setSeriesShapesVisible(192, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot29.getRangeAxisEdge(100);
        categoryPlot29.setDomainCrosshairVisible(false);
        boolean boolean46 = categoryPlot29.isRangeGridlinesVisible();
        boolean boolean47 = categoryPlot29.isRangeCrosshairVisible();
        java.awt.Graphics2D graphics2D48 = null;
        java.awt.geom.Rectangle2D rectangle2D49 = null;
        try {
            categoryPlot29.drawOutline(graphics2D48, rectangle2D49);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.END;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_MAGENTA;
        lineAndShapeRenderer0.setSeriesPaint(100, (java.awt.Paint) color5);
        org.junit.Assert.assertNotNull(color5);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier13 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke14 = defaultDrawingSupplier13.getNextOutlineStroke();
        categoryPlot12.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier13, true);
        org.jfree.chart.axis.AxisLocation axisLocation18 = categoryPlot12.getDomainAxisLocation(1);
        org.jfree.chart.axis.AxisLocation axisLocation19 = axisLocation18.getOpposite();
        boolean boolean20 = lineAndShapeRenderer0.equals((java.lang.Object) axisLocation19);
        boolean boolean21 = lineAndShapeRenderer0.getAutoPopulateSeriesOutlinePaint();
        org.jfree.chart.LegendItemCollection legendItemCollection22 = lineAndShapeRenderer0.getLegendItems();
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator23 = lineAndShapeRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertNotNull(axisLocation18);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(legendItemCollection22);
        org.junit.Assert.assertNull(categoryItemLabelGenerator23);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        lineAndShapeRenderer0.setSeriesShapesFilled(0, (java.lang.Boolean) false);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator17 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator17);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator20 = null;
        lineAndShapeRenderer0.setSeriesToolTipGenerator(0, categoryToolTipGenerator20);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        double double16 = barRenderer12.getShadowYOffset();
        java.awt.Color color18 = java.awt.Color.ORANGE;
        java.awt.Color color19 = color18.brighter();
        barRenderer12.setSeriesOutlinePaint((int) '4', (java.awt.Paint) color19, true);
        java.awt.Color color22 = color19.brighter();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(color19);
        org.junit.Assert.assertNotNull(color22);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        categoryPlot2.setBackgroundAlpha((float) 8);
        org.jfree.chart.plot.Plot plot21 = categoryPlot2.getParent();
        org.jfree.chart.axis.ValueAxis valueAxis22 = categoryPlot2.getRangeAxis();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(plot21);
        org.junit.Assert.assertNull(valueAxis22);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("hi!");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("hi!");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
        org.jfree.data.UnknownKeyException unknownKeyException6 = new org.jfree.data.UnknownKeyException("hi!");
        unknownKeyException3.addSuppressed((java.lang.Throwable) unknownKeyException6);
        java.lang.Throwable[] throwableArray8 = unknownKeyException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextOutlineStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1, true);
        java.awt.Paint paint5 = defaultDrawingSupplier1.getNextPaint();
        java.awt.Shape shape6 = defaultDrawingSupplier1.getNextShape();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.Marker marker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        lineAndShapeRenderer7.drawRangeMarker(graphics2D8, categoryPlot9, valueAxis13, marker14, rectangle2D15);
        java.awt.Stroke stroke17 = categoryPlot9.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo19 = null;
        java.awt.geom.Point2D point2D20 = null;
        categoryPlot9.zoomRangeAxes(8.0d, plotRenderingInfo19, point2D20, false);
        org.jfree.chart.entity.PlotEntity plotEntity25 = new org.jfree.chart.entity.PlotEntity(shape6, (org.jfree.chart.plot.Plot) categoryPlot9, "", "PlotOrientation.HORIZONTAL");
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.geom.Rectangle2D rectangle2D27 = null;
        java.awt.geom.Point2D point2D28 = null;
        org.jfree.chart.plot.PlotState plotState29 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        try {
            categoryPlot9.draw(graphics2D26, rectangle2D27, point2D28, plotState29, plotRenderingInfo30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean2 = legendItem1.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int7 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean8 = legendItem1.equals((java.lang.Object) categoryPlot3);
        boolean boolean9 = categoryPlot3.isRangeZeroBaselineVisible();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer11 = categoryPlot3.getRendererForDataset(categoryDataset10);
        categoryPlot3.setDomainCrosshairColumnKey((java.lang.Comparable) false);
        java.awt.Stroke stroke14 = null;
        try {
            categoryPlot3.setRangeMinorGridlineStroke(stroke14);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNull(categoryItemRenderer11);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedRangeAxisSpace();
        boolean boolean2 = categoryPlot0.isRangePannable();
        java.awt.Paint paint3 = categoryPlot0.getRangeMinorGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset4 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer5 = categoryPlot0.getRendererForDataset(categoryDataset4);
        org.jfree.chart.axis.AxisSpace axisSpace6 = categoryPlot0.getFixedDomainAxisSpace();
        java.awt.Stroke stroke7 = categoryPlot0.getDomainCrosshairStroke();
        org.jfree.chart.event.PlotChangeListener plotChangeListener8 = null;
        categoryPlot0.addChangeListener(plotChangeListener8);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(categoryItemRenderer5);
        org.junit.Assert.assertNull(axisSpace6);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        boolean boolean2 = legendItem1.isLineVisible();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color4 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot3.setNoDataMessagePaint((java.awt.Paint) color4);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer6 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int7 = categoryPlot3.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer6);
        boolean boolean8 = legendItem1.equals((java.lang.Object) categoryPlot3);
        boolean boolean9 = categoryPlot3.isRangeZeroBaselineVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        java.awt.geom.Point2D point2D12 = null;
        categoryPlot3.zoomRangeAxes(4.0d, plotRenderingInfo11, point2D12, false);
        double double15 = categoryPlot3.getAnchorValue();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1) + "'", int7 == (-1));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        java.awt.Stroke stroke5 = lineAndShapeRenderer0.getSeriesStroke(0);
        lineAndShapeRenderer0.setSeriesLinesVisible((int) (short) 0, (java.lang.Boolean) false);
        lineAndShapeRenderer0.setSeriesItemLabelsVisible((int) (byte) 10, true);
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color15 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot14.setNoDataMessagePaint((java.awt.Paint) color15);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int18 = categoryPlot14.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer17);
        java.lang.Object obj19 = categoryPlot14.clone();
        org.jfree.chart.util.Layer layer20 = null;
        java.util.Collection collection21 = categoryPlot14.getRangeMarkers(layer20);
        categoryPlot14.setRangePannable(true);
        org.jfree.chart.axis.CategoryAxis categoryAxis24 = new org.jfree.chart.axis.CategoryAxis();
        float float25 = categoryAxis24.getTickMarkOutsideLength();
        java.lang.String str26 = categoryAxis24.getLabelURL();
        org.jfree.chart.axis.ValueAxis valueAxis27 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset28 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis29 = new org.jfree.chart.axis.CategoryAxis();
        float float30 = categoryAxis29.getTickMarkOutsideLength();
        categoryAxis29.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryAxis29.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis34 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer35 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke37 = lineAndShapeRenderer35.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint39 = lineAndShapeRenderer35.lookupLegendTextPaint((int) '#');
        boolean boolean40 = lineAndShapeRenderer35.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot42 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color44 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot43.setNoDataMessagePaint((java.awt.Paint) color44);
        org.jfree.chart.util.RectangleInsets rectangleInsets46 = categoryPlot43.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis47 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray48 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis47 };
        categoryPlot43.setDomainAxes(categoryAxisArray48);
        java.awt.Stroke stroke50 = categoryPlot43.getDomainCrosshairStroke();
        categoryPlot42.setDomainGridlineStroke(stroke50);
        lineAndShapeRenderer35.setSeriesOutlineStroke((int) ' ', stroke50, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot54 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset28, categoryAxis29, valueAxis34, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer35);
        int int56 = defaultCategoryDataset28.getRowIndex((java.lang.Comparable) (-4194304));
        java.lang.Object obj57 = defaultCategoryDataset28.clone();
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState61 = null;
        try {
            java.awt.Shape shape62 = lineAndShapeRenderer0.createHotSpotShape(graphics2D12, rectangle2D13, categoryPlot14, categoryAxis24, valueAxis27, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset28, (-32640), (int) 'a', false, categoryItemRendererState61);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNull(stroke5);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
        org.junit.Assert.assertNotNull(obj19);
        org.junit.Assert.assertNull(collection21);
        org.junit.Assert.assertTrue("'" + float25 + "' != '" + 2.0f + "'", float25 == 2.0f);
        org.junit.Assert.assertNull(str26);
        org.junit.Assert.assertTrue("'" + float30 + "' != '" + 2.0f + "'", float30 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(rectangleInsets46);
        org.junit.Assert.assertNotNull(categoryAxisArray48);
        org.junit.Assert.assertNotNull(stroke50);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1) + "'", int56 == (-1));
        org.junit.Assert.assertNotNull(obj57);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        java.lang.Boolean boolean6 = lineAndShapeRenderer3.getSeriesShapesFilled(100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer8 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot10.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        org.jfree.chart.plot.Marker marker15 = null;
        java.awt.geom.Rectangle2D rectangle2D16 = null;
        lineAndShapeRenderer8.drawRangeMarker(graphics2D9, categoryPlot10, valueAxis14, marker15, rectangle2D16);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot10.getDomainMarkers(layer18);
        org.jfree.chart.renderer.category.BarRenderer barRenderer20 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot10.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer20);
        boolean boolean23 = barRenderer20.isSeriesVisible((int) (short) -1);
        org.jfree.chart.LegendItem legendItem26 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape27 = legendItem26.getLine();
        barRenderer20.setSeriesShape(0, shape27, false);
        lineAndShapeRenderer3.setSeriesShape((int) (byte) 1, shape27);
        java.awt.Paint paint32 = lineAndShapeRenderer3.lookupSeriesOutlinePaint(0);
        java.awt.Font font33 = lineAndShapeRenderer3.getBaseLegendTextFont();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNull(boolean6);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(shape27);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertNull(font33);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer4 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean7 = lineAndShapeRenderer4.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = lineAndShapeRenderer4.getPositiveItemLabelPosition((int) (short) 1, (int) (byte) 1, true);
        barRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition11, false);
        double double14 = itemLabelPosition11.getAngle();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color6 = java.awt.Color.darkGray;
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color6, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = lineAndShapeRenderer0.getSeriesURLGenerator((int) (short) 100);
        org.jfree.chart.LegendItem legendItem13 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        lineAndShapeRenderer14.drawRangeMarker(graphics2D15, categoryPlot16, valueAxis20, marker21, rectangle2D22);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot16.getDomainMarkers(layer24);
        org.jfree.chart.renderer.category.BarRenderer barRenderer26 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot16.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer26);
        boolean boolean29 = barRenderer26.isSeriesVisible((int) (short) -1);
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape33 = legendItem32.getLine();
        barRenderer26.setSeriesShape(0, shape33, false);
        legendItem13.setShape(shape33);
        lineAndShapeRenderer0.setSeriesShape(15, shape33, false);
        java.awt.Paint paint40 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        lineAndShapeRenderer0.setSeriesOutlinePaint((int) (byte) 1, paint40, true);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(shape33);
        org.junit.Assert.assertNotNull(paint40);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition(255, itemLabelPosition5);
        lineAndShapeRenderer2.setBaseSeriesVisibleInLegend(false, true);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Paint paint8 = lineAndShapeRenderer0.getItemLabelPaint((int) (byte) 10, (int) (byte) -1, false);
        int int9 = lineAndShapeRenderer0.getPassCount();
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot10.setNoDataMessagePaint((java.awt.Paint) color11);
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = categoryPlot10.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.setLabelAngle(100.0d);
        categoryPlot10.setDomainAxis((int) (short) 100, categoryAxis15, true);
        java.awt.Image image20 = categoryPlot10.getBackgroundImage();
        categoryPlot10.setNotify(false);
        org.jfree.chart.axis.AxisSpace axisSpace23 = categoryPlot10.getFixedRangeAxisSpace();
        lineAndShapeRenderer0.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot10);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator25 = lineAndShapeRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(rectangleInsets13);
        org.junit.Assert.assertNull(image20);
        org.junit.Assert.assertNull(axisSpace23);
        org.junit.Assert.assertNull(categoryToolTipGenerator25);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        java.awt.Stroke[] strokeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_STROKE_SEQUENCE;
        org.junit.Assert.assertNotNull(strokeArray0);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        java.awt.Paint paint3 = lineAndShapeRenderer2.getBasePaint();
        org.junit.Assert.assertNotNull(paint3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier5 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke6 = defaultDrawingSupplier5.getNextOutlineStroke();
        categoryPlot4.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier5, true);
        java.awt.Paint paint9 = defaultDrawingSupplier5.getNextPaint();
        java.awt.Shape shape10 = defaultDrawingSupplier5.getNextShape();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        lineAndShapeRenderer11.drawRangeMarker(graphics2D12, categoryPlot13, valueAxis17, marker18, rectangle2D19);
        java.awt.Stroke stroke21 = categoryPlot13.getRangeZeroBaselineStroke();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        java.awt.geom.Point2D point2D24 = null;
        categoryPlot13.zoomRangeAxes(8.0d, plotRenderingInfo23, point2D24, false);
        org.jfree.chart.entity.PlotEntity plotEntity29 = new org.jfree.chart.entity.PlotEntity(shape10, (org.jfree.chart.plot.Plot) categoryPlot13, "", "PlotOrientation.HORIZONTAL");
        java.awt.Paint paint30 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        org.jfree.chart.LegendItem legendItem32 = new org.jfree.chart.LegendItem("");
        org.jfree.chart.plot.CategoryPlot categoryPlot33 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier34 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke35 = defaultDrawingSupplier34.getNextOutlineStroke();
        categoryPlot33.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier34, true);
        java.awt.Paint paint38 = defaultDrawingSupplier34.getNextPaint();
        java.awt.Shape shape39 = defaultDrawingSupplier34.getNextShape();
        java.awt.Stroke stroke40 = defaultDrawingSupplier34.getNextOutlineStroke();
        legendItem32.setOutlineStroke(stroke40);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer42 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot44.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.plot.Marker marker49 = null;
        java.awt.geom.Rectangle2D rectangle2D50 = null;
        lineAndShapeRenderer42.drawRangeMarker(graphics2D43, categoryPlot44, valueAxis48, marker49, rectangle2D50);
        org.jfree.chart.util.Layer layer52 = null;
        java.util.Collection collection53 = categoryPlot44.getDomainMarkers(layer52);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        java.awt.geom.Point2D point2D57 = null;
        categoryPlot44.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo56, point2D57);
        org.jfree.chart.axis.AxisSpace axisSpace59 = null;
        categoryPlot44.setFixedDomainAxisSpace(axisSpace59);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer62 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean65 = lineAndShapeRenderer62.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot66 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer62.setPlot(categoryPlot66);
        categoryPlot44.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer62);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer69 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D70 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot71 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot71.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis75 = null;
        org.jfree.chart.plot.Marker marker76 = null;
        java.awt.geom.Rectangle2D rectangle2D77 = null;
        lineAndShapeRenderer69.drawRangeMarker(graphics2D70, categoryPlot71, valueAxis75, marker76, rectangle2D77);
        org.jfree.chart.axis.AxisLocation axisLocation80 = null;
        categoryPlot71.setRangeAxisLocation((int) (short) 100, axisLocation80, false);
        lineAndShapeRenderer62.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot71);
        categoryPlot71.setRangeCrosshairVisible(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer86 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean89 = lineAndShapeRenderer86.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer86.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color92 = java.awt.Color.darkGray;
        lineAndShapeRenderer86.setBaseOutlinePaint((java.awt.Paint) color92, false);
        categoryPlot71.setOutlinePaint((java.awt.Paint) color92);
        try {
            org.jfree.chart.LegendItem legendItem96 = new org.jfree.chart.LegendItem(attributedString0, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "TextAnchor.CENTER", "hi!", shape10, paint30, stroke40, (java.awt.Paint) color92);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNotNull(paint30);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(shape39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertNull(collection53);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + true + "'", boolean89 == true);
        org.junit.Assert.assertNotNull(color92);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        java.awt.Stroke stroke15 = lineAndShapeRenderer7.getItemStroke(1, (int) (short) 1, false);
        legendItem1.setOutlineStroke(stroke15);
        int int17 = legendItem1.getSeriesIndex();
        legendItem1.setDatasetIndex(2);
        java.lang.Object obj20 = legendItem1.clone();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(obj20);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        boolean boolean12 = lineAndShapeRenderer7.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        java.awt.Stroke stroke22 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot14.setDomainGridlineStroke(stroke22);
        lineAndShapeRenderer7.setSeriesOutlineStroke((int) ' ', stroke22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        int int28 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4194304));
        java.lang.Object obj29 = defaultCategoryDataset0.clone();
        try {
            java.lang.Comparable comparable31 = defaultCategoryDataset0.getRowKey((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 100, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
        org.junit.Assert.assertNotNull(obj29);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot29.getRangeAxisEdge(100);
        categoryPlot29.setCrosshairDatasetIndex(100, true);
        java.awt.Stroke stroke47 = categoryPlot29.getDomainGridlineStroke();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertNotNull(stroke47);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer0.setPlot(categoryPlot4);
        categoryPlot4.setBackgroundImageAlignment((int) (short) 0);
        org.jfree.chart.JFreeChart jFreeChart8 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 100.0d);
        java.lang.Object obj11 = chartChangeEvent10.getSource();
        org.jfree.chart.JFreeChart jFreeChart12 = chartChangeEvent10.getChart();
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType13 = chartChangeEvent10.getType();
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent14 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (short) 0, jFreeChart8, chartChangeEventType13);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + obj11 + "' != '" + 100.0d + "'", obj11.equals(100.0d));
        org.junit.Assert.assertNull(jFreeChart12);
        org.junit.Assert.assertNotNull(chartChangeEventType13);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList(2);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        java.awt.Color color10 = java.awt.Color.WHITE;
        categoryPlot2.setOutlinePaint((java.awt.Paint) color10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo13 = null;
        java.awt.geom.Point2D point2D14 = null;
        categoryPlot2.panRangeAxes(0.0d, plotRenderingInfo13, point2D14);
        org.jfree.chart.plot.PlotOrientation plotOrientation16 = categoryPlot2.getOrientation();
        java.awt.Stroke stroke17 = categoryPlot2.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        categoryPlot2.setAxisOffset(rectangleInsets18);
        org.jfree.chart.plot.Marker marker21 = null;
        org.jfree.chart.util.Layer layer22 = null;
        try {
            categoryPlot2.addRangeMarker(0, marker21, layer22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color10);
        org.junit.Assert.assertNotNull(plotOrientation16);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(rectangleInsets18);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        double double5 = rectangleInsets3.calculateTopOutset((double) 1.0f);
        double double7 = rectangleInsets3.calculateLeftInset(100.0d);
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType9 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType10 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D11 = rectangleInsets3.createAdjustedRectangle(rectangle2D8, lengthAdjustmentType9, lengthAdjustmentType10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.0d + "'", double5 == 4.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 8.0d + "'", double7 == 8.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) ' ');
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis3.getTickLabelInsets();
        float float5 = categoryAxis3.getTickMarkInsideLength();
        categoryAxis3.setLabel("");
        categoryAxis3.setAxisLineVisible(true);
        float float10 = categoryAxis3.getMinorTickMarkInsideLength();
        java.lang.Object obj11 = categoryAxis3.clone();
        objectList1.set((int) (short) 10, obj11);
        java.lang.Object obj14 = objectList1.get(100);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNull(obj14);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        lineAndShapeRenderer15.drawRangeMarker(graphics2D16, categoryPlot17, valueAxis21, marker22, rectangle2D23);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot17.getDomainMarkers(layer25);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot17.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo29, point2D30);
        org.jfree.chart.axis.AxisSpace axisSpace32 = null;
        categoryPlot17.setFixedDomainAxisSpace(axisSpace32);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot17.getDomainMarkers(layer34);
        java.awt.Stroke stroke36 = categoryPlot17.getRangeGridlineStroke();
        barRenderer12.setBaseOutlineStroke(stroke36, true);
        org.jfree.chart.renderer.RenderAttributes renderAttributes39 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean40 = renderAttributes39.getDefaultCreateEntity();
        renderAttributes39.setDefaultLabelVisible((java.lang.Boolean) false);
        java.awt.Shape shape43 = renderAttributes39.getDefaultShape();
        org.jfree.chart.plot.PlotOrientation plotOrientation44 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color45 = java.awt.Color.WHITE;
        boolean boolean46 = plotOrientation44.equals((java.lang.Object) color45);
        renderAttributes39.setDefaultLabelPaint((java.awt.Paint) color45);
        boolean boolean48 = barRenderer12.equals((java.lang.Object) renderAttributes39);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator50 = barRenderer12.getSeriesToolTipGenerator((int) (short) -1);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNotNull(stroke36);
        org.junit.Assert.assertNull(boolean40);
        org.junit.Assert.assertNull(shape43);
        org.junit.Assert.assertNotNull(plotOrientation44);
        org.junit.Assert.assertNotNull(color45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNull(categoryToolTipGenerator50);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color6 = java.awt.Color.darkGray;
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color6, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = lineAndShapeRenderer0.getSeriesURLGenerator((int) (short) 100);
        int int11 = lineAndShapeRenderer0.getColumnCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        double double16 = barRenderer12.getShadowYOffset();
        double double17 = barRenderer12.getItemMargin();
        java.awt.Paint paint19 = barRenderer12.lookupSeriesOutlinePaint((int) (short) 100);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D21 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot22.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis26 = null;
        org.jfree.chart.plot.Marker marker27 = null;
        java.awt.geom.Rectangle2D rectangle2D28 = null;
        lineAndShapeRenderer20.drawRangeMarker(graphics2D21, categoryPlot22, valueAxis26, marker27, rectangle2D28);
        java.awt.Color color30 = java.awt.Color.WHITE;
        categoryPlot22.setOutlinePaint((java.awt.Paint) color30);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo33 = null;
        java.awt.geom.Point2D point2D34 = null;
        categoryPlot22.panRangeAxes(0.0d, plotRenderingInfo33, point2D34);
        barRenderer12.addChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot22);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 4.0d + "'", double16 == 4.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.2d + "'", double17 == 0.2d);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(color30);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer0.setPlot(categoryPlot4);
        categoryPlot4.setBackgroundImageAlignment((int) (short) 0);
        categoryPlot4.setBackgroundImageAlignment((int) (short) 10);
        int int10 = categoryPlot4.getRangeAxisCount();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        boolean boolean12 = lineAndShapeRenderer7.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        java.awt.Stroke stroke22 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot14.setDomainGridlineStroke(stroke22);
        lineAndShapeRenderer7.setSeriesOutlineStroke((int) ' ', stroke22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        int int28 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4194304));
        defaultCategoryDataset0.clear();
        try {
            java.lang.Comparable comparable31 = defaultCategoryDataset0.getColumnKey(192);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 192, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        double double5 = rectangleInsets3.extendHeight((double) (byte) 1);
        double double6 = rectangleInsets3.getTop();
        org.jfree.chart.util.UnitType unitType7 = rectangleInsets3.getUnitType();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 9.0d + "'", double5 == 9.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 4.0d + "'", double6 == 4.0d);
        org.junit.Assert.assertNotNull(unitType7);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        barRenderer12.setDrawBarOutline(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = barRenderer12.getGradientPaintTransformer();
        barRenderer12.setSeriesVisible(255, (java.lang.Boolean) true, true);
        boolean boolean22 = barRenderer12.getBaseCreateEntities();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer17);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getBaseCreateEntities();
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape7 = legendItem6.getLine();
        lineAndShapeRenderer0.setBaseLegendShape(shape7);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator9 = lineAndShapeRenderer0.getBaseURLGenerator();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke13 = defaultDrawingSupplier12.getNextOutlineStroke();
        categoryPlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier12, true);
        java.awt.Paint paint16 = defaultDrawingSupplier12.getNextPaint();
        lineAndShapeRenderer0.setLegendTextPaint((int) '4', paint16);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(categoryURLGenerator9);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(paint16);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean1 = renderAttributes0.getDefaultCreateEntity();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) false);
        java.awt.Shape shape4 = renderAttributes0.getDefaultShape();
        org.jfree.chart.plot.PlotOrientation plotOrientation5 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color6 = java.awt.Color.WHITE;
        boolean boolean7 = plotOrientation5.equals((java.lang.Object) color6);
        renderAttributes0.setDefaultLabelPaint((java.awt.Paint) color6);
        java.awt.Paint paint10 = renderAttributes0.getSeriesPaint((int) 'a');
        java.awt.Shape shape13 = renderAttributes0.getItemShape((int) (byte) -1, 0);
        org.junit.Assert.assertNull(boolean1);
        org.junit.Assert.assertNull(shape4);
        org.junit.Assert.assertNotNull(plotOrientation5);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertNull(shape13);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint4 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '#');
        boolean boolean5 = lineAndShapeRenderer0.getBaseSeriesVisible();
        java.awt.Stroke stroke6 = lineAndShapeRenderer0.getBaseOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition8 = lineAndShapeRenderer0.getSeriesNegativeItemLabelPosition((int) (short) 1);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNotNull(itemLabelPosition8);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) 0.5f);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) 255, 0.0d, (double) 10.0f, 0.0d);
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets8.createOutsetRectangle(rectangle2D9, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertNotNull(unitType3);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        java.awt.Font font28 = lineAndShapeRenderer20.getLegendTextFont(100);
        java.awt.Shape shape30 = lineAndShapeRenderer20.getSeriesShape((-10289251));
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = lineAndShapeRenderer20.getToolTipGenerator((int) '4', (-10289251), false);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNull(font28);
        org.junit.Assert.assertNull(shape30);
        org.junit.Assert.assertNull(categoryToolTipGenerator34);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer0.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color6 = java.awt.Color.darkGray;
        lineAndShapeRenderer0.setBaseOutlinePaint((java.awt.Paint) color6, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator10 = lineAndShapeRenderer0.getSeriesURLGenerator((int) (short) 100);
        java.awt.Color color11 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color12 = color11.brighter();
        lineAndShapeRenderer0.setBaseFillPaint((java.awt.Paint) color11);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNull(categoryURLGenerator10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertNotNull(color12);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint4 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '#');
        boolean boolean5 = lineAndShapeRenderer0.getBaseShapesFilled();
        java.awt.Shape shape7 = lineAndShapeRenderer0.lookupLegendShape((int) (short) 100);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator8 = lineAndShapeRenderer0.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNull(categoryItemLabelGenerator8);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer0.setPlot(categoryPlot4);
        categoryPlot4.setBackgroundImageAlignment((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot4.zoomDomainAxes((double) 0.0f, plotRenderingInfo9, point2D10, true);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        try {
            categoryPlot4.setRangeAxis((int) (byte) -1, valueAxis14, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        barRenderer12.setAutoPopulateSeriesStroke(true);
        boolean boolean18 = barRenderer12.getDataBoundsIncludesVisibleSeriesOnly();
        boolean boolean19 = barRenderer12.getShadowsVisible();
        java.awt.Stroke stroke20 = barRenderer12.getBaseStroke();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(stroke20);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        boolean boolean13 = barRenderer0.getItemCreateEntity((int) (short) 100, (int) (byte) 0, true);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        categoryPlot2.setBackgroundAlpha((float) 8);
        boolean boolean21 = categoryPlot2.isNotify();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean25 = lineAndShapeRenderer22.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer22.setPlot(categoryPlot26);
        categoryPlot26.setBackgroundImageAlignment((int) (short) 0);
        java.util.List list30 = categoryPlot26.getAnnotations();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot26.getFixedLegendItems();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot26);
        categoryPlot2.notifyListeners(plotChangeEvent32);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation34 = null;
        try {
            boolean boolean35 = categoryPlot2.removeAnnotation(categoryAnnotation34);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNull(legendItemCollection31);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        boolean boolean10 = categoryPlot2.isDomainGridlinesVisible();
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot2.getRangeAxisLocation();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(axisLocation11);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        java.awt.Paint paint2 = paintList0.getPaint((int) (short) 0);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint2 = lineAndShapeRenderer0.getSeriesPaint((int) (byte) 0);
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getSeriesStroke(1);
        double double5 = lineAndShapeRenderer0.getItemMargin();
        boolean boolean8 = lineAndShapeRenderer0.getItemShapeVisible((int) '#', (int) 'a');
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        boolean boolean12 = lineAndShapeRenderer7.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        java.awt.Stroke stroke22 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot14.setDomainGridlineStroke(stroke22);
        lineAndShapeRenderer7.setSeriesOutlineStroke((int) ' ', stroke22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        int int28 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4194304));
        defaultCategoryDataset0.clear();
        defaultCategoryDataset0.setValue(0.0d, (java.lang.Comparable) "UnitType.ABSOLUTE", (java.lang.Comparable) "TextAnchor.CENTER");
        try {
            defaultCategoryDataset0.removeRow((java.lang.Comparable) "RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]");
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Row key (RectangleInsets[t=1.0,l=1.0,b=1.0,r=1.0]) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setLabel("");
        categoryAxis0.setLabel("{0}");
        java.awt.Stroke stroke7 = categoryAxis0.getAxisLineStroke();
        org.jfree.data.category.CategoryDataset categoryDataset10 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier14 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke15 = defaultDrawingSupplier14.getNextOutlineStroke();
        categoryPlot13.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier14, true);
        org.jfree.chart.axis.AxisLocation axisLocation19 = categoryPlot13.getDomainAxisLocation(1);
        java.lang.String str20 = axisLocation19.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation19, plotOrientation21);
        try {
            double double23 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) 10L, (java.lang.Comparable) "poly", categoryDataset10, 0.0d, rectangle2D12, rectangleEdge22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str20.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNotNull(rectangleEdge22);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        boolean boolean1 = barRenderer0.getAutoPopulateSeriesOutlinePaint();
        java.awt.Paint paint3 = barRenderer0.getSeriesFillPaint(1);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator7 = barRenderer0.getItemLabelGenerator(10, 255, false);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator8 = null;
        barRenderer0.setBaseURLGenerator(categoryURLGenerator8);
        barRenderer0.setMaximumBarWidth((double) 0.0f);
        java.awt.Paint paint12 = barRenderer0.getBaseItemLabelPaint();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(categoryItemLabelGenerator7);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer12.getBaseNegativeItemLabelPosition();
        barRenderer12.setShadowYOffset((double) (-1L));
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer19 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke21 = lineAndShapeRenderer19.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint23 = lineAndShapeRenderer19.lookupLegendTextPaint((int) '#');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor24 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.text.TextAnchor textAnchor25 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition26 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor24, textAnchor25);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor27 = itemLabelPosition26.getItemLabelAnchor();
        lineAndShapeRenderer19.setBasePositiveItemLabelPosition(itemLabelPosition26);
        barRenderer12.setBaseNegativeItemLabelPosition(itemLabelPosition26, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot31 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color32 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot31.setNoDataMessagePaint((java.awt.Paint) color32);
        org.jfree.chart.util.RectangleInsets rectangleInsets34 = categoryPlot31.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis35 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray36 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis35 };
        categoryPlot31.setDomainAxes(categoryAxisArray36);
        categoryPlot31.clearRangeAxes();
        barRenderer12.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot31);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition40 = barRenderer12.getNegativeItemLabelPositionFallback();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(stroke21);
        org.junit.Assert.assertNull(paint23);
        org.junit.Assert.assertNotNull(itemLabelAnchor24);
        org.junit.Assert.assertNotNull(textAnchor25);
        org.junit.Assert.assertNotNull(itemLabelAnchor27);
        org.junit.Assert.assertNotNull(color32);
        org.junit.Assert.assertNotNull(rectangleInsets34);
        org.junit.Assert.assertNotNull(categoryAxisArray36);
        org.junit.Assert.assertNull(itemLabelPosition40);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint2 = lineAndShapeRenderer0.getSeriesPaint((int) (byte) 0);
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getSeriesStroke(1);
        double double5 = lineAndShapeRenderer0.getItemMargin();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition7, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer11 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot13.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis17 = null;
        org.jfree.chart.plot.Marker marker18 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        lineAndShapeRenderer11.drawRangeMarker(graphics2D12, categoryPlot13, valueAxis17, marker18, rectangle2D19);
        org.jfree.chart.util.Layer layer21 = null;
        java.util.Collection collection22 = categoryPlot13.getDomainMarkers(layer21);
        org.jfree.chart.renderer.category.BarRenderer barRenderer23 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot13.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer23);
        boolean boolean26 = barRenderer23.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition27 = barRenderer23.getBaseNegativeItemLabelPosition();
        lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) (byte) 10, itemLabelPosition27, false);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNull(collection22);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition27);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        legendItem1.setSeriesKey((java.lang.Comparable) 10L);
        java.awt.Paint paint5 = legendItem1.getLabelPaint();
        int int6 = legendItem1.getSeriesIndex();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        java.lang.Boolean boolean1 = renderAttributes0.getDefaultCreateEntity();
        java.awt.Paint paint2 = renderAttributes0.getDefaultLabelPaint();
        java.awt.Stroke stroke3 = renderAttributes0.getDefaultOutlineStroke();
        java.awt.Paint paint4 = renderAttributes0.getDefaultPaint();
        org.junit.Assert.assertNull(boolean1);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(stroke3);
        org.junit.Assert.assertNull(paint4);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape2 = legendItem1.getLine();
        java.awt.Paint paint3 = legendItem1.getLinePaint();
        java.lang.Comparable comparable4 = legendItem1.getSeriesKey();
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNull(comparable4);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = barRenderer12.getBaseNegativeItemLabelPosition();
        java.awt.Paint paint18 = barRenderer12.lookupLegendTextPaint(0);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNull(paint18);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((int) ' ');
        org.jfree.chart.axis.CategoryAxis categoryAxis3 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryAxis3.getTickLabelInsets();
        float float5 = categoryAxis3.getTickMarkInsideLength();
        categoryAxis3.setLabel("");
        categoryAxis3.setAxisLineVisible(true);
        float float10 = categoryAxis3.getMinorTickMarkInsideLength();
        java.lang.Object obj11 = categoryAxis3.clone();
        objectList1.set((int) (short) 10, obj11);
        org.jfree.chart.plot.PlotOrientation plotOrientation14 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        objectList1.set((int) (short) 100, (java.lang.Object) plotOrientation14);
        java.lang.Object obj16 = objectList1.clone();
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.0f + "'", float10 == 0.0f);
        org.junit.Assert.assertNotNull(obj11);
        org.junit.Assert.assertNotNull(plotOrientation14);
        org.junit.Assert.assertNotNull(obj16);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        java.awt.Color color0 = java.awt.Color.ORANGE;
        java.awt.Color color1 = color0.brighter();
        float[] floatArray6 = new float[] { (-10289251), (-1.0f), 2.0f, 0.0f };
        float[] floatArray7 = color1.getComponents(floatArray6);
        java.awt.image.ColorModel colorModel8 = null;
        java.awt.Rectangle rectangle9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        java.awt.geom.AffineTransform affineTransform11 = null;
        java.awt.RenderingHints renderingHints12 = null;
        java.awt.PaintContext paintContext13 = color1.createContext(colorModel8, rectangle9, rectangle2D10, affineTransform11, renderingHints12);
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(paintContext13);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getMinorTickMarkInsideLength();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color3);
        categoryAxis0.setTickMarkInsideLength((float) (-10289251));
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        float float8 = categoryAxis7.getTickMarkOutsideLength();
        categoryAxis7.setCategoryMargin((double) 8);
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets12 = categoryAxis11.getTickLabelInsets();
        float float13 = categoryAxis11.getTickMarkInsideLength();
        categoryAxis11.setLabel("");
        categoryAxis11.setLabel("{0}");
        java.awt.Font font18 = categoryAxis11.getTickLabelFont();
        categoryAxis7.setLabelFont(font18);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions20 = categoryAxis7.getCategoryLabelPositions();
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions20);
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 0.0f + "'", float13 == 0.0f);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(categoryLabelPositions20);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.util.PaintList paintList0 = new org.jfree.chart.util.PaintList();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer1 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot3.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis7 = null;
        org.jfree.chart.plot.Marker marker8 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        lineAndShapeRenderer1.drawRangeMarker(graphics2D2, categoryPlot3, valueAxis7, marker8, rectangle2D9);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot3.getDomainMarkers(layer11);
        float float13 = categoryPlot3.getForegroundAlpha();
        boolean boolean14 = paintList0.equals((java.lang.Object) categoryPlot3);
        java.awt.Paint paint16 = paintList0.getPaint(15);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertTrue("'" + float13 + "' != '" + 1.0f + "'", float13 == 1.0f);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNull(paint16);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getDrawOutlines();
        boolean boolean5 = lineAndShapeRenderer0.getDrawOutlines();
        java.awt.Graphics2D graphics2D6 = null;
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color9 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot8.setNoDataMessagePaint((java.awt.Paint) color9);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot8.getInsets();
        org.jfree.chart.renderer.category.CategoryItemRenderer[] categoryItemRendererArray12 = new org.jfree.chart.renderer.category.CategoryItemRenderer[] {};
        categoryPlot8.setRenderers(categoryItemRendererArray12);
        org.jfree.chart.axis.AxisLocation axisLocation15 = categoryPlot8.getDomainAxisLocation((int) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke18 = defaultDrawingSupplier17.getNextOutlineStroke();
        categoryPlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17, true);
        java.awt.Paint paint21 = defaultDrawingSupplier17.getNextPaint();
        java.awt.Shape shape22 = defaultDrawingSupplier17.getNextShape();
        categoryPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17, false);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        float float26 = categoryAxis25.getTickMarkOutsideLength();
        categoryAxis25.setCategoryMargin((double) 8);
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color30 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot29.setNoDataMessagePaint((java.awt.Paint) color30);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int33 = categoryPlot29.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer32);
        org.jfree.chart.plot.PlotOrientation plotOrientation35 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color36 = java.awt.Color.WHITE;
        boolean boolean37 = plotOrientation35.equals((java.lang.Object) color36);
        int int38 = color36.getBlue();
        lineAndShapeRenderer32.setSeriesFillPaint(1, (java.awt.Paint) color36);
        categoryAxis25.setTickMarkPaint((java.awt.Paint) color36);
        org.jfree.chart.axis.ValueAxis valueAxis41 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset42 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis43 = new org.jfree.chart.axis.CategoryAxis();
        float float44 = categoryAxis43.getTickMarkOutsideLength();
        categoryAxis43.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = categoryAxis43.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis48 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer49 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke51 = lineAndShapeRenderer49.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint53 = lineAndShapeRenderer49.lookupLegendTextPaint((int) '#');
        boolean boolean54 = lineAndShapeRenderer49.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot56 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot57 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color58 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot57.setNoDataMessagePaint((java.awt.Paint) color58);
        org.jfree.chart.util.RectangleInsets rectangleInsets60 = categoryPlot57.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis61 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray62 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis61 };
        categoryPlot57.setDomainAxes(categoryAxisArray62);
        java.awt.Stroke stroke64 = categoryPlot57.getDomainCrosshairStroke();
        categoryPlot56.setDomainGridlineStroke(stroke64);
        lineAndShapeRenderer49.setSeriesOutlineStroke((int) ' ', stroke64, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot68 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset42, categoryAxis43, valueAxis48, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer49);
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState72 = null;
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D74 = lineAndShapeRenderer0.createHotSpotBounds(graphics2D6, rectangle2D7, categoryPlot8, categoryAxis25, valueAxis41, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset42, 192, 4, true, categoryItemRendererState72, rectangle2D73);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(categoryItemRendererArray12);
        org.junit.Assert.assertNotNull(axisLocation15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertTrue("'" + float26 + "' != '" + 2.0f + "'", float26 == 2.0f);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + (-1) + "'", int33 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation35);
        org.junit.Assert.assertNotNull(color36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 255 + "'", int38 == 255);
        org.junit.Assert.assertTrue("'" + float44 + "' != '" + 2.0f + "'", float44 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertNotNull(stroke51);
        org.junit.Assert.assertNull(paint53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(color58);
        org.junit.Assert.assertNotNull(rectangleInsets60);
        org.junit.Assert.assertNotNull(categoryAxisArray62);
        org.junit.Assert.assertNotNull(stroke64);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer14 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot16.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis20 = null;
        org.jfree.chart.plot.Marker marker21 = null;
        java.awt.geom.Rectangle2D rectangle2D22 = null;
        lineAndShapeRenderer14.drawRangeMarker(graphics2D15, categoryPlot16, valueAxis20, marker21, rectangle2D22);
        org.jfree.chart.util.Layer layer24 = null;
        java.util.Collection collection25 = categoryPlot16.getDomainMarkers(layer24);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo28 = null;
        java.awt.geom.Point2D point2D29 = null;
        categoryPlot16.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo28, point2D29);
        org.jfree.chart.axis.AxisSpace axisSpace31 = null;
        categoryPlot16.setFixedDomainAxisSpace(axisSpace31);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer34 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean37 = lineAndShapeRenderer34.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer34.setPlot(categoryPlot38);
        categoryPlot16.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer34);
        barRenderer12.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot16);
        java.util.List list42 = categoryPlot16.getCategories();
        org.jfree.chart.axis.AxisSpace axisSpace43 = null;
        categoryPlot16.setFixedRangeAxisSpace(axisSpace43, true);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNull(collection25);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNull(list42);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint2 = lineAndShapeRenderer0.getSeriesPaint((int) (byte) 0);
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getSeriesStroke(1);
        double double5 = lineAndShapeRenderer0.getItemMargin();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition7, false);
        boolean boolean13 = lineAndShapeRenderer0.isItemLabelVisible(255, (int) (short) -1, false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        lineAndShapeRenderer15.drawRangeMarker(graphics2D16, categoryPlot17, valueAxis21, marker22, rectangle2D23);
        org.jfree.chart.util.Layer layer25 = null;
        java.util.Collection collection26 = categoryPlot17.getDomainMarkers(layer25);
        org.jfree.chart.renderer.category.BarRenderer barRenderer27 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot17.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer27);
        org.jfree.chart.renderer.category.BarPainter barPainter29 = barRenderer27.getBarPainter();
        barRenderer27.setDrawBarOutline(false);
        org.jfree.chart.LegendItem legendItem33 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer34 = legendItem33.getFillPaintTransformer();
        barRenderer27.setGradientPaintTransformer(gradientPaintTransformer34);
        double double36 = barRenderer27.getMinimumBarLength();
        java.awt.Paint paint37 = org.jfree.chart.plot.Plot.DEFAULT_OUTLINE_PAINT;
        barRenderer27.setShadowPaint(paint37);
        org.jfree.chart.axis.CategoryAxis categoryAxis39 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets40 = categoryAxis39.getTickLabelInsets();
        float float41 = categoryAxis39.getTickMarkInsideLength();
        categoryAxis39.setLabel("");
        categoryAxis39.setLabel("{0}");
        java.awt.Font font46 = categoryAxis39.getTickLabelFont();
        barRenderer27.setBaseItemLabelFont(font46);
        try {
            lineAndShapeRenderer0.setSeriesItemLabelFont((-35), font46, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNull(collection26);
        org.junit.Assert.assertNotNull(barPainter29);
        org.junit.Assert.assertNotNull(gradientPaintTransformer34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(rectangleInsets40);
        org.junit.Assert.assertTrue("'" + float41 + "' != '" + 0.0f + "'", float41 == 0.0f);
        org.junit.Assert.assertNotNull(font46);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        categoryPlot2.setBackgroundAlpha((float) 8);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer21 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean24 = lineAndShapeRenderer21.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer21.setPlot(categoryPlot25);
        categoryPlot25.setBackgroundImageAlignment((int) (short) 0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo30 = null;
        java.awt.geom.Point2D point2D31 = null;
        categoryPlot25.zoomDomainAxes((double) 0.0f, plotRenderingInfo30, point2D31, true);
        categoryPlot2.setParent((org.jfree.chart.plot.Plot) categoryPlot25);
        float float35 = categoryPlot25.getBackgroundAlpha();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + float35 + "' != '" + 1.0f + "'", float35 == 1.0f);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        float[] floatArray3 = new float[] { (byte) 10, 10.0f };
        try {
            float[] floatArray4 = color0.getRGBColorComponents(floatArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray3);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getMinorTickMarkInsideLength();
        java.awt.Color color3 = org.jfree.chart.ChartColor.VERY_DARK_CYAN;
        categoryAxis0.setAxisLinePaint((java.awt.Paint) color3);
        categoryAxis0.setTickMarkInsideLength((float) (-10289251));
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier12 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke13 = defaultDrawingSupplier12.getNextOutlineStroke();
        categoryPlot11.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier12, true);
        org.jfree.chart.axis.AxisLocation axisLocation17 = categoryPlot11.getDomainAxisLocation(1);
        java.lang.String str18 = axisLocation17.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation19 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation17, plotOrientation19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        try {
            org.jfree.chart.axis.AxisState axisState22 = categoryAxis0.draw(graphics2D7, (-16.0d), rectangle2D9, rectangle2D10, rectangleEdge20, plotRenderingInfo21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNotNull(axisLocation17);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str18.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Shape shape5 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier7 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke8 = defaultDrawingSupplier7.getNextOutlineStroke();
        categoryPlot6.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier7, true);
        org.jfree.chart.axis.AxisLocation axisLocation12 = categoryPlot6.getDomainAxisLocation(1);
        categoryPlot6.setForegroundAlpha((float) (short) 100);
        org.jfree.chart.entity.PlotEntity plotEntity16 = new org.jfree.chart.entity.PlotEntity(shape5, (org.jfree.chart.plot.Plot) categoryPlot6, "hi!");
        org.jfree.chart.renderer.RenderAttributes renderAttributes18 = new org.jfree.chart.renderer.RenderAttributes();
        java.awt.Paint paint21 = renderAttributes18.getItemPaint(10, (int) (short) 0);
        java.awt.Paint paint22 = renderAttributes18.getDefaultFillPaint();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer23 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot25.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis29 = null;
        org.jfree.chart.plot.Marker marker30 = null;
        java.awt.geom.Rectangle2D rectangle2D31 = null;
        lineAndShapeRenderer23.drawRangeMarker(graphics2D24, categoryPlot25, valueAxis29, marker30, rectangle2D31);
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot25.setRangeAxisLocation((int) (short) 100, axisLocation34, false);
        java.awt.Color color37 = java.awt.Color.ORANGE;
        java.awt.Color color38 = color37.brighter();
        categoryPlot25.setRangeMinorGridlinePaint((java.awt.Paint) color38);
        renderAttributes18.setDefaultLabelPaint((java.awt.Paint) color38);
        java.awt.Paint paint43 = renderAttributes18.getItemPaint(10, (int) (short) 1);
        java.awt.Color color44 = org.jfree.chart.ChartColor.DARK_GREEN;
        renderAttributes18.setDefaultLabelPaint((java.awt.Paint) color44);
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer49 = legendItem48.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem51 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape52 = legendItem51.getLine();
        legendItem48.setShape(shape52);
        java.awt.Stroke stroke54 = null;
        legendItem48.setOutlineStroke(stroke54);
        java.awt.Color color56 = org.jfree.chart.ChartColor.VERY_LIGHT_MAGENTA;
        java.awt.Color color57 = color56.brighter();
        legendItem48.setOutlinePaint((java.awt.Paint) color57);
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace60 = categoryPlot59.getFixedRangeAxisSpace();
        boolean boolean61 = categoryPlot59.isRangePannable();
        java.awt.Paint paint62 = categoryPlot59.getRangeMinorGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset63 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer64 = categoryPlot59.getRendererForDataset(categoryDataset63);
        org.jfree.chart.axis.AxisSpace axisSpace65 = categoryPlot59.getFixedDomainAxisSpace();
        java.awt.Stroke stroke66 = categoryPlot59.getDomainCrosshairStroke();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer68 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer68.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        lineAndShapeRenderer68.setAutoPopulateSeriesOutlineStroke(true);
        java.awt.Shape shape74 = lineAndShapeRenderer68.getBaseShape();
        java.awt.Stroke stroke75 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer76 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer76.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean80 = lineAndShapeRenderer76.getDrawOutlines();
        java.awt.Paint paint84 = lineAndShapeRenderer76.getItemLabelPaint((int) (byte) 10, (int) (byte) -1, false);
        try {
            org.jfree.chart.LegendItem legendItem85 = new org.jfree.chart.LegendItem("UnitType.ABSOLUTE", "SortOrder.ASCENDING", "PlotOrientation.HORIZONTAL", "", false, shape5, false, (java.awt.Paint) color44, false, (java.awt.Paint) color57, stroke66, false, shape74, stroke75, paint84);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'lineStroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertNull(paint21);
        org.junit.Assert.assertNull(paint22);
        org.junit.Assert.assertNotNull(color37);
        org.junit.Assert.assertNotNull(color38);
        org.junit.Assert.assertNull(paint43);
        org.junit.Assert.assertNotNull(color44);
        org.junit.Assert.assertNotNull(gradientPaintTransformer49);
        org.junit.Assert.assertNotNull(shape52);
        org.junit.Assert.assertNotNull(color56);
        org.junit.Assert.assertNotNull(color57);
        org.junit.Assert.assertNull(axisSpace60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(paint62);
        org.junit.Assert.assertNull(categoryItemRenderer64);
        org.junit.Assert.assertNull(axisSpace65);
        org.junit.Assert.assertNotNull(stroke66);
        org.junit.Assert.assertNotNull(shape74);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + true + "'", boolean80 == true);
        org.junit.Assert.assertNotNull(paint84);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean2 = lineAndShapeRenderer0.isSeriesVisible((int) (byte) 0);
        lineAndShapeRenderer0.setDefaultEntityRadius((-1));
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator5 = null;
        lineAndShapeRenderer0.setBaseURLGenerator(categoryURLGenerator5, false);
        java.awt.Color color9 = java.awt.Color.ORANGE;
        java.awt.Color color10 = color9.brighter();
        lineAndShapeRenderer0.setSeriesPaint((int) (short) 0, (java.awt.Paint) color10, true);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(color10);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        java.awt.Color color0 = java.awt.Color.MAGENTA;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color2);
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator7 = new org.jfree.chart.util.DefaultShadowGenerator((int) '#', color2, (float) ' ', (int) (byte) 0, (double) (-1));
        java.awt.Color color8 = defaultShadowGenerator7.getShadowColor();
        float float9 = defaultShadowGenerator7.getShadowOpacity();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer10 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot12.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis16 = null;
        org.jfree.chart.plot.Marker marker17 = null;
        java.awt.geom.Rectangle2D rectangle2D18 = null;
        lineAndShapeRenderer10.drawRangeMarker(graphics2D11, categoryPlot12, valueAxis16, marker17, rectangle2D18);
        org.jfree.chart.axis.AxisLocation axisLocation21 = null;
        categoryPlot12.setRangeAxisLocation((int) (short) 100, axisLocation21, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier26 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke27 = defaultDrawingSupplier26.getNextOutlineStroke();
        categoryPlot25.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier26, true);
        org.jfree.chart.axis.AxisLocation axisLocation31 = categoryPlot25.getDomainAxisLocation(1);
        categoryPlot12.setDomainAxisLocation(0, axisLocation31);
        org.jfree.chart.axis.AxisLocation axisLocation33 = axisLocation31.getOpposite();
        boolean boolean34 = defaultShadowGenerator7.equals((java.lang.Object) axisLocation33);
        java.awt.image.BufferedImage bufferedImage35 = null;
        try {
            java.awt.image.BufferedImage bufferedImage36 = defaultShadowGenerator7.createDropShadow(bufferedImage35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 32.0f + "'", float9 == 32.0f);
        org.junit.Assert.assertNotNull(stroke27);
        org.junit.Assert.assertNotNull(axisLocation31);
        org.junit.Assert.assertNotNull(axisLocation33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.jfree.chart.util.ShapeList shapeList0 = new org.jfree.chart.util.ShapeList();
        java.awt.Shape shape2 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_CIRCLE;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke5 = defaultDrawingSupplier4.getNextOutlineStroke();
        categoryPlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4, true);
        org.jfree.chart.axis.AxisLocation axisLocation9 = categoryPlot3.getDomainAxisLocation(1);
        categoryPlot3.setForegroundAlpha((float) (short) 100);
        org.jfree.chart.entity.PlotEntity plotEntity13 = new org.jfree.chart.entity.PlotEntity(shape2, (org.jfree.chart.plot.Plot) categoryPlot3, "hi!");
        try {
            shapeList0.setShape((-32640), shape2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(axisLocation9);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint4 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '#');
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor5 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_RIGHT;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor5, textAnchor6);
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor8 = itemLabelPosition7.getItemLabelAnchor();
        lineAndShapeRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition7);
        java.lang.Boolean boolean11 = lineAndShapeRenderer0.getSeriesShapesFilled((int) (short) 10);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertNotNull(itemLabelAnchor5);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertNotNull(itemLabelAnchor8);
        org.junit.Assert.assertNull(boolean11);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        boolean boolean4 = categoryPlot0.isDomainCrosshairVisible();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo6 = null;
        java.awt.geom.Point2D point2D7 = null;
        categoryPlot0.zoomDomainAxes((double) (short) 100, plotRenderingInfo6, point2D7, true);
        categoryPlot0.clearRangeMarkers();
        org.jfree.data.general.DatasetGroup datasetGroup11 = categoryPlot0.getDatasetGroup();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNull(datasetGroup11);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint2 = lineAndShapeRenderer0.getSeriesPaint((int) (byte) 0);
        lineAndShapeRenderer0.setDataBoundsIncludesVisibleSeriesOnly(true);
        org.junit.Assert.assertNull(paint2);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        categoryPlot2.setBackgroundAlpha((float) 8);
        boolean boolean21 = categoryPlot2.isNotify();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer22 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean25 = lineAndShapeRenderer22.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer22.setPlot(categoryPlot26);
        categoryPlot26.setBackgroundImageAlignment((int) (short) 0);
        java.util.List list30 = categoryPlot26.getAnnotations();
        org.jfree.chart.LegendItemCollection legendItemCollection31 = categoryPlot26.getFixedLegendItems();
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent32 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot26);
        categoryPlot2.notifyListeners(plotChangeEvent32);
        org.jfree.chart.util.Layer layer34 = null;
        java.util.Collection collection35 = categoryPlot2.getRangeMarkers(layer34);
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace37 = categoryPlot36.getFixedRangeAxisSpace();
        boolean boolean38 = categoryPlot36.isRangePannable();
        java.awt.Paint paint39 = categoryPlot36.getRangeMinorGridlinePaint();
        org.jfree.data.category.CategoryDataset categoryDataset40 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = categoryPlot36.getRendererForDataset(categoryDataset40);
        org.jfree.chart.axis.AxisSpace axisSpace42 = categoryPlot36.getFixedDomainAxisSpace();
        java.awt.Stroke stroke43 = categoryPlot36.getDomainCrosshairStroke();
        categoryPlot2.setOutlineStroke(stroke43);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(list30);
        org.junit.Assert.assertNull(legendItemCollection31);
        org.junit.Assert.assertNull(collection35);
        org.junit.Assert.assertNull(axisSpace37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNull(categoryItemRenderer41);
        org.junit.Assert.assertNull(axisSpace42);
        org.junit.Assert.assertNotNull(stroke43);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint4 = lineAndShapeRenderer0.lookupLegendTextPaint((int) '#');
        boolean boolean5 = lineAndShapeRenderer0.getBaseSeriesVisible();
        try {
            lineAndShapeRenderer0.setItemMargin((double) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires 0.0 <= margin < 1.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNull(paint4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer0.setPlot(categoryPlot4);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator6 = null;
        lineAndShapeRenderer0.setBaseItemLabelGenerator(categoryItemLabelGenerator6, false);
        try {
            java.awt.Stroke stroke12 = lineAndShapeRenderer0.getItemStroke((-1), 255, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setLabel("");
        categoryAxis0.setLabel("{0}");
        java.awt.Stroke stroke7 = categoryAxis0.getAxisLineStroke();
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color12 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot11.setNoDataMessagePaint((java.awt.Paint) color12);
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = categoryPlot11.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot11.setFixedDomainAxisSpace(axisSpace15);
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot11.getDomainAxisEdge();
        try {
            double double18 = categoryAxis0.getCategoryStart((int) (short) 100, 192, rectangle2D10, rectangleEdge17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(rectangleEdge17);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getTickMarkOutsideLength();
        categoryAxis0.setCategoryMargin((double) 8);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot4.setNoDataMessagePaint((java.awt.Paint) color5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int8 = categoryPlot4.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color11 = java.awt.Color.WHITE;
        boolean boolean12 = plotOrientation10.equals((java.lang.Object) color11);
        int int13 = color11.getBlue();
        lineAndShapeRenderer7.setSeriesFillPaint(1, (java.awt.Paint) color11);
        categoryAxis0.setTickMarkPaint((java.awt.Paint) color11);
        categoryAxis0.setCategoryMargin((double) 0.5f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0f + "'", float1 == 2.0f);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke2 = lineAndShapeRenderer0.lookupSeriesStroke((int) ' ');
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.lookupSeriesOutlineStroke(1);
        org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape8 = legendItem7.getLine();
        java.awt.Font font9 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        legendItem7.setLabelFont(font9);
        lineAndShapeRenderer0.setSeriesItemLabelFont((int) ' ', font9);
        lineAndShapeRenderer0.setSeriesShapesFilled(0, (java.lang.Boolean) false);
        lineAndShapeRenderer0.setBaseItemLabelsVisible(true);
        boolean boolean19 = lineAndShapeRenderer0.getItemShapeFilled((int) (byte) 100, (int) (short) 100);
        java.awt.Stroke stroke23 = lineAndShapeRenderer0.getItemOutlineStroke((-32640), 2, false);
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(font9);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(stroke23);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        legendItem1.setDatasetIndex((int) (byte) 0);
        boolean boolean5 = legendItem1.isShapeFilled();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        boolean boolean12 = lineAndShapeRenderer7.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        java.awt.Stroke stroke22 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot14.setDomainGridlineStroke(stroke22);
        lineAndShapeRenderer7.setSeriesOutlineStroke((int) ' ', stroke22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        int int28 = defaultCategoryDataset0.getRowIndex((java.lang.Comparable) (-4194304));
        try {
            defaultCategoryDataset0.removeRow(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1) + "'", int28 == (-1));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.jfree.data.UnknownKeyException unknownKeyException1 = new org.jfree.data.UnknownKeyException("hi!");
        org.jfree.data.UnknownKeyException unknownKeyException3 = new org.jfree.data.UnknownKeyException("hi!");
        unknownKeyException1.addSuppressed((java.lang.Throwable) unknownKeyException3);
        java.lang.String str5 = unknownKeyException3.toString();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.jfree.data.UnknownKeyException: hi!" + "'", str5.equals("org.jfree.data.UnknownKeyException: hi!"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.awt.Color color0 = java.awt.Color.green;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        barRenderer12.setSeriesCreateEntities((int) (short) 100, (java.lang.Boolean) false, true);
        barRenderer12.setAutoPopulateSeriesOutlineStroke(true);
        barRenderer12.setBaseItemLabelsVisible(false);
        org.junit.Assert.assertNull(collection11);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot2.setRangeAxisLocation((int) (short) 100, axisLocation11, false);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier16 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke17 = defaultDrawingSupplier16.getNextOutlineStroke();
        categoryPlot15.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier16, true);
        org.jfree.chart.axis.AxisLocation axisLocation21 = categoryPlot15.getDomainAxisLocation(1);
        categoryPlot2.setDomainAxisLocation(0, axisLocation21);
        org.jfree.chart.axis.ValueAxis valueAxis24 = categoryPlot2.getRangeAxisForDataset(10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot2.zoomDomainAxes((double) 4, plotRenderingInfo26, point2D27, false);
        org.junit.Assert.assertNotNull(stroke17);
        org.junit.Assert.assertNotNull(axisLocation21);
        org.junit.Assert.assertNull(valueAxis24);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        java.lang.String str3 = categoryAxis0.getLabelURL();
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset6 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        float float8 = categoryAxis7.getTickMarkOutsideLength();
        categoryAxis7.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryAxis7.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis12 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer13 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke15 = lineAndShapeRenderer13.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint17 = lineAndShapeRenderer13.lookupLegendTextPaint((int) '#');
        boolean boolean18 = lineAndShapeRenderer13.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color22 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot21.setNoDataMessagePaint((java.awt.Paint) color22);
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = categoryPlot21.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray26 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis25 };
        categoryPlot21.setDomainAxes(categoryAxisArray26);
        java.awt.Stroke stroke28 = categoryPlot21.getDomainCrosshairStroke();
        categoryPlot20.setDomainGridlineStroke(stroke28);
        lineAndShapeRenderer13.setSeriesOutlineStroke((int) ' ', stroke28, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset6, categoryAxis7, valueAxis12, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer13);
        int int34 = defaultCategoryDataset6.getRowIndex((java.lang.Comparable) (-4194304));
        java.lang.Object obj35 = defaultCategoryDataset6.clone();
        java.awt.geom.Rectangle2D rectangle2D37 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer38 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D39 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot40.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.chart.plot.Marker marker45 = null;
        java.awt.geom.Rectangle2D rectangle2D46 = null;
        lineAndShapeRenderer38.drawRangeMarker(graphics2D39, categoryPlot40, valueAxis44, marker45, rectangle2D46);
        org.jfree.chart.util.Layer layer48 = null;
        java.util.Collection collection49 = categoryPlot40.getDomainMarkers(layer48);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo52 = null;
        java.awt.geom.Point2D point2D53 = null;
        categoryPlot40.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo52, point2D53);
        org.jfree.chart.axis.AxisSpace axisSpace55 = null;
        categoryPlot40.setFixedDomainAxisSpace(axisSpace55);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer58 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean61 = lineAndShapeRenderer58.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot62 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer58.setPlot(categoryPlot62);
        categoryPlot40.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer58);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer65 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D66 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot67 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot67.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis71 = null;
        org.jfree.chart.plot.Marker marker72 = null;
        java.awt.geom.Rectangle2D rectangle2D73 = null;
        lineAndShapeRenderer65.drawRangeMarker(graphics2D66, categoryPlot67, valueAxis71, marker72, rectangle2D73);
        org.jfree.chart.axis.AxisLocation axisLocation76 = null;
        categoryPlot67.setRangeAxisLocation((int) (short) 100, axisLocation76, false);
        lineAndShapeRenderer58.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot67);
        org.jfree.chart.util.RectangleEdge rectangleEdge81 = categoryPlot67.getRangeAxisEdge(100);
        try {
            double double82 = categoryAxis0.getCategorySeriesMiddle((java.lang.Comparable) '#', (java.lang.Comparable) 0.2d, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset6, (double) (byte) 100, rectangle2D37, rectangleEdge81);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 2.0f + "'", float8 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertNotNull(categoryAxisArray26);
        org.junit.Assert.assertNotNull(stroke28);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertNotNull(obj35);
        org.junit.Assert.assertNull(collection49);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + true + "'", boolean61 == true);
        org.junit.Assert.assertNotNull(rectangleEdge81);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition(255, itemLabelPosition5);
        lineAndShapeRenderer2.setItemLabelAnchorOffset((double) 192);
        org.junit.Assert.assertNotNull(stroke3);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        float[] floatArray2 = new float[] { 255 };
        try {
            float[] floatArray3 = color0.getColorComponents(floatArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray2);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        lineAndShapeRenderer3.setDataBoundsIncludesVisibleSeriesOnly(true);
        java.awt.Paint paint8 = lineAndShapeRenderer3.lookupSeriesPaint((int) ' ');
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean15 = barRenderer12.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator16 = barRenderer12.getLegendItemLabelGenerator();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer17 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot19.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis23 = null;
        org.jfree.chart.plot.Marker marker24 = null;
        java.awt.geom.Rectangle2D rectangle2D25 = null;
        lineAndShapeRenderer17.drawRangeMarker(graphics2D18, categoryPlot19, valueAxis23, marker24, rectangle2D25);
        boolean boolean27 = barRenderer12.hasListener((java.util.EventListener) categoryPlot19);
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation28 = null;
        org.jfree.chart.util.Layer layer29 = null;
        try {
            barRenderer12.addAnnotation(categoryAnnotation28, layer29);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator16);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer2 = new org.jfree.chart.renderer.category.LineAndShapeRenderer(true, false);
        java.awt.Stroke stroke3 = lineAndShapeRenderer2.getBaseOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition5 = null;
        lineAndShapeRenderer2.setSeriesPositiveItemLabelPosition(255, itemLabelPosition5);
        boolean boolean7 = lineAndShapeRenderer2.getDataBoundsIncludesVisibleSeriesOnly();
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextOutlineStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1, true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation(1);
        java.lang.String str7 = axisLocation6.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation6, plotOrientation8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot10.getFixedRangeAxisSpace();
        boolean boolean12 = categoryPlot10.isRangePannable();
        java.awt.Paint paint13 = categoryPlot10.getRangeMinorGridlinePaint();
        boolean boolean14 = plotOrientation8.equals((java.lang.Object) categoryPlot10);
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer18 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int19 = categoryPlot15.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer18);
        org.jfree.chart.plot.PlotOrientation plotOrientation21 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color22 = java.awt.Color.WHITE;
        boolean boolean23 = plotOrientation21.equals((java.lang.Object) color22);
        int int24 = color22.getBlue();
        lineAndShapeRenderer18.setSeriesFillPaint(1, (java.awt.Paint) color22);
        int int26 = color22.getAlpha();
        boolean boolean27 = plotOrientation8.equals((java.lang.Object) int26);
        java.lang.String str28 = plotOrientation8.toString();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str7.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation21);
        org.junit.Assert.assertNotNull(color22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 255 + "'", int24 == 255);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 255 + "'", int26 == 255);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "PlotOrientation.HORIZONTAL" + "'", str28.equals("PlotOrientation.HORIZONTAL"));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Paint paint2 = lineAndShapeRenderer0.getSeriesPaint((int) (byte) 0);
        java.awt.Stroke stroke4 = lineAndShapeRenderer0.getSeriesStroke(1);
        double double5 = lineAndShapeRenderer0.getItemMargin();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = null;
        lineAndShapeRenderer0.setSeriesNegativeItemLabelPosition((int) '4', itemLabelPosition7, false);
        boolean boolean13 = lineAndShapeRenderer0.isItemLabelVisible(255, (int) (short) -1, false);
        lineAndShapeRenderer0.setBaseSeriesVisible(false, false);
        org.junit.Assert.assertNull(paint2);
        org.junit.Assert.assertNull(stroke4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double2 = rectangleInsets0.calculateBottomOutset((double) 0.5f);
        org.jfree.chart.util.UnitType unitType3 = rectangleInsets0.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = new org.jfree.chart.util.RectangleInsets(unitType3, (double) 255, 0.0d, (double) 10.0f, 0.0d);
        double double10 = rectangleInsets8.calculateTopOutset((double) 'a');
        double double11 = rectangleInsets8.getBottom();
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
        org.junit.Assert.assertNotNull(unitType3);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 255.0d + "'", double10 == 255.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 10.0d + "'", double11 == 10.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.renderer.RenderAttributes renderAttributes0 = new org.jfree.chart.renderer.RenderAttributes();
        renderAttributes0.setDefaultLabelVisible((java.lang.Boolean) true);
        java.lang.Boolean boolean3 = renderAttributes0.getDefaultCreateEntity();
        org.junit.Assert.assertNull(boolean3);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = categoryPlot0.getInsets();
        org.jfree.chart.axis.AxisSpace axisSpace4 = categoryPlot0.getFixedDomainAxisSpace();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer5 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot7.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis11 = null;
        org.jfree.chart.plot.Marker marker12 = null;
        java.awt.geom.Rectangle2D rectangle2D13 = null;
        lineAndShapeRenderer5.drawRangeMarker(graphics2D6, categoryPlot7, valueAxis11, marker12, rectangle2D13);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier15 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke16 = defaultDrawingSupplier15.getNextOutlineStroke();
        categoryPlot7.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier15);
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace20 = categoryPlot19.getFixedRangeAxisSpace();
        boolean boolean21 = defaultDrawingSupplier15.equals((java.lang.Object) categoryPlot19);
        categoryPlot19.clearRangeAxes();
        boolean boolean23 = categoryPlot19.isRangeGridlinesVisible();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertNotNull(rectangleInsets3);
        org.junit.Assert.assertNull(axisSpace4);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(axisSpace20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.jfree.data.KeyedObjects keyedObjects0 = new org.jfree.data.KeyedObjects();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        categoryPlot2.setRangeCrosshairLockedOnData(false);
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier9 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke10 = defaultDrawingSupplier9.getNextOutlineStroke();
        categoryPlot8.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier9, true);
        org.jfree.chart.axis.AxisLocation axisLocation14 = categoryPlot8.getDomainAxisLocation(1);
        categoryPlot2.setDomainAxisLocation(axisLocation14);
        keyedObjects0.addObject((java.lang.Comparable) "hi!", (java.lang.Object) axisLocation14);
        try {
            java.lang.Object obj18 = keyedObjects0.getObject((java.lang.Comparable) 100.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: The key (100.0) is not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(axisLocation14);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier4 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke5 = defaultDrawingSupplier4.getNextOutlineStroke();
        categoryPlot3.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier4, true);
        java.awt.Paint paint8 = defaultDrawingSupplier4.getNextPaint();
        java.awt.Shape shape9 = defaultDrawingSupplier4.getNextShape();
        java.awt.Stroke stroke10 = defaultDrawingSupplier4.getNextOutlineStroke();
        legendItem1.setOutlineStroke(stroke10);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer12 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot14.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis18 = null;
        org.jfree.chart.plot.Marker marker19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        lineAndShapeRenderer12.drawRangeMarker(graphics2D13, categoryPlot14, valueAxis18, marker19, rectangle2D20);
        org.jfree.chart.util.Layer layer22 = null;
        java.util.Collection collection23 = categoryPlot14.getDomainMarkers(layer22);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo26 = null;
        java.awt.geom.Point2D point2D27 = null;
        categoryPlot14.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo26, point2D27);
        org.jfree.chart.axis.AxisSpace axisSpace29 = null;
        categoryPlot14.setFixedDomainAxisSpace(axisSpace29);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer32 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean35 = lineAndShapeRenderer32.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer32.setPlot(categoryPlot36);
        categoryPlot14.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer32);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer39 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D40 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot41.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis45 = null;
        org.jfree.chart.plot.Marker marker46 = null;
        java.awt.geom.Rectangle2D rectangle2D47 = null;
        lineAndShapeRenderer39.drawRangeMarker(graphics2D40, categoryPlot41, valueAxis45, marker46, rectangle2D47);
        org.jfree.chart.axis.AxisLocation axisLocation50 = null;
        categoryPlot41.setRangeAxisLocation((int) (short) 100, axisLocation50, false);
        lineAndShapeRenderer32.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot41);
        categoryPlot41.setRangeCrosshairVisible(false);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer56 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean59 = lineAndShapeRenderer56.getItemShapeFilled((int) (short) 0, (-1));
        lineAndShapeRenderer56.setAutoPopulateSeriesFillPaint(false);
        java.awt.Color color62 = java.awt.Color.darkGray;
        lineAndShapeRenderer56.setBaseOutlinePaint((java.awt.Paint) color62, false);
        categoryPlot41.setOutlinePaint((java.awt.Paint) color62);
        legendItem1.setOutlinePaint((java.awt.Paint) color62);
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(shape9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(collection23);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(color62);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem4 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape5 = legendItem4.getLine();
        legendItem1.setShape(shape5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        java.awt.Stroke stroke15 = lineAndShapeRenderer7.getItemStroke(1, (int) (short) 1, false);
        legendItem1.setOutlineStroke(stroke15);
        int int17 = legendItem1.getSeriesIndex();
        java.awt.Stroke stroke18 = legendItem1.getOutlineStroke();
        int int19 = legendItem1.getDatasetIndex();
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(shape5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            keyedObjects2D0.removeColumn((java.lang.Comparable) 0.0f);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.UnknownKeyException; message: Column key (0.0) not recognised.");
        } catch (org.jfree.data.UnknownKeyException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer0.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean4 = lineAndShapeRenderer0.getBaseCreateEntities();
        boolean boolean5 = lineAndShapeRenderer0.getUseFillPaint();
        java.awt.Stroke stroke7 = lineAndShapeRenderer0.getSeriesStroke((int) '#');
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator11 = lineAndShapeRenderer0.getURLGenerator(0, (int) (byte) -1, true);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNull(stroke7);
        org.junit.Assert.assertNull(categoryURLGenerator11);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace1 = categoryPlot0.getFixedRangeAxisSpace();
        boolean boolean2 = categoryPlot0.isRangePannable();
        org.jfree.chart.axis.ValueAxis valueAxis4 = categoryPlot0.getRangeAxis((int) (short) 10);
        org.junit.Assert.assertNull(axisSpace1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNull(valueAxis4);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color2 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot1.setNoDataMessagePaint((java.awt.Paint) color2);
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = categoryPlot1.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis5 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray6 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis5 };
        categoryPlot1.setDomainAxes(categoryAxisArray6);
        java.awt.Stroke stroke8 = categoryPlot1.getDomainCrosshairStroke();
        categoryPlot0.setDomainGridlineStroke(stroke8);
        categoryPlot0.clearDomainMarkers();
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertNotNull(rectangleInsets4);
        org.junit.Assert.assertNotNull(categoryAxisArray6);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        barRenderer12.setDrawBarOutline(false);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer17 = barRenderer12.getGradientPaintTransformer();
        barRenderer12.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent20 = null;
        barRenderer12.notifyListeners(rendererChangeEvent20);
        barRenderer12.setSeriesItemLabelsVisible((int) '#', (java.lang.Boolean) true, false);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer17);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.CategoryAxis categoryAxis2 = null;
        categoryPlot0.setDomainAxis(10, categoryAxis2, true);
        org.jfree.chart.axis.ValueAxis valueAxis5 = null;
        categoryPlot0.setRangeAxis(valueAxis5);
        categoryPlot0.setRangeCrosshairValue((double) '#');
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke11 = defaultDrawingSupplier10.getNextOutlineStroke();
        categoryPlot9.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10, true);
        java.awt.Paint paint14 = defaultDrawingSupplier10.getNextPaint();
        java.awt.Shape shape15 = defaultDrawingSupplier10.getNextShape();
        java.awt.Stroke stroke16 = defaultDrawingSupplier10.getNextOutlineStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        java.awt.Paint paint18 = defaultDrawingSupplier10.getNextFillPaint();
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint18);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.data.KeyedObjects2D keyedObjects2D0 = new org.jfree.data.KeyedObjects2D();
        try {
            java.lang.Comparable comparable2 = keyedObjects2D0.getRowKey(0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE2;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getTickMarkOutsideLength();
        categoryAxis0.setCategoryMargin((double) 8);
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_INSETS;
        double double7 = rectangleInsets5.calculateBottomOutset((double) 0.5f);
        org.jfree.chart.util.UnitType unitType8 = rectangleInsets5.getUnitType();
        org.jfree.chart.util.RectangleInsets rectangleInsets13 = new org.jfree.chart.util.RectangleInsets(unitType8, (double) 255, 0.0d, (double) 10.0f, 0.0d);
        categoryAxis0.setTickLabelInsets(rectangleInsets13);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0f + "'", float1 == 2.0f);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 3.0d + "'", double7 == 3.0d);
        org.junit.Assert.assertNotNull(unitType8);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.util.DefaultShadowGenerator defaultShadowGenerator0 = new org.jfree.chart.util.DefaultShadowGenerator();
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier10 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke11 = defaultDrawingSupplier10.getNextOutlineStroke();
        categoryPlot2.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier10);
        org.jfree.chart.axis.ValueAxis valueAxis14 = null;
        categoryPlot2.setRangeAxis(0, valueAxis14);
        categoryPlot2.setAnchorValue((double) 0L);
        org.junit.Assert.assertNotNull(stroke11);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset0 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        float float2 = categoryAxis1.getTickMarkOutsideLength();
        categoryAxis1.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = categoryAxis1.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke9 = lineAndShapeRenderer7.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint11 = lineAndShapeRenderer7.lookupLegendTextPaint((int) '#');
        boolean boolean12 = lineAndShapeRenderer7.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color16 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot15.setNoDataMessagePaint((java.awt.Paint) color16);
        org.jfree.chart.util.RectangleInsets rectangleInsets18 = categoryPlot15.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray20 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis19 };
        categoryPlot15.setDomainAxes(categoryAxisArray20);
        java.awt.Stroke stroke22 = categoryPlot15.getDomainCrosshairStroke();
        categoryPlot14.setDomainGridlineStroke(stroke22);
        lineAndShapeRenderer7.setSeriesOutlineStroke((int) ' ', stroke22, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset0, categoryAxis1, valueAxis6, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        java.awt.Paint paint27 = categoryAxis1.getLabelPaint();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets5);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(color16);
        org.junit.Assert.assertNotNull(rectangleInsets18);
        org.junit.Assert.assertNotNull(categoryAxisArray20);
        org.junit.Assert.assertNotNull(stroke22);
        org.junit.Assert.assertNotNull(paint27);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        barRenderer12.setDrawBarOutline(false);
        org.jfree.chart.LegendItem legendItem18 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer19 = legendItem18.getFillPaintTransformer();
        barRenderer12.setGradientPaintTransformer(gradientPaintTransformer19);
        double double21 = barRenderer12.getMinimumBarLength();
        double double22 = barRenderer12.getMaximumBarWidth();
        java.awt.Graphics2D graphics2D23 = null;
        java.awt.geom.Rectangle2D rectangle2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = null;
        org.jfree.data.category.DefaultCategoryDataset defaultCategoryDataset26 = new org.jfree.data.category.DefaultCategoryDataset();
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        float float28 = categoryAxis27.getTickMarkOutsideLength();
        categoryAxis27.setCategoryMargin((double) 8);
        org.jfree.chart.util.RectangleInsets rectangleInsets31 = categoryAxis27.getTickLabelInsets();
        org.jfree.chart.axis.ValueAxis valueAxis32 = null;
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer33 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke35 = lineAndShapeRenderer33.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint37 = lineAndShapeRenderer33.lookupLegendTextPaint((int) '#');
        boolean boolean38 = lineAndShapeRenderer33.getBaseShapesFilled();
        org.jfree.chart.plot.CategoryPlot categoryPlot40 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.CategoryPlot categoryPlot41 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color42 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot41.setNoDataMessagePaint((java.awt.Paint) color42);
        org.jfree.chart.util.RectangleInsets rectangleInsets44 = categoryPlot41.getInsets();
        org.jfree.chart.axis.CategoryAxis categoryAxis45 = null;
        org.jfree.chart.axis.CategoryAxis[] categoryAxisArray46 = new org.jfree.chart.axis.CategoryAxis[] { categoryAxis45 };
        categoryPlot41.setDomainAxes(categoryAxisArray46);
        java.awt.Stroke stroke48 = categoryPlot41.getDomainCrosshairStroke();
        categoryPlot40.setDomainGridlineStroke(stroke48);
        lineAndShapeRenderer33.setSeriesOutlineStroke((int) ' ', stroke48, true);
        org.jfree.chart.plot.CategoryPlot categoryPlot52 = new org.jfree.chart.plot.CategoryPlot((org.jfree.data.category.CategoryDataset) defaultCategoryDataset26, categoryAxis27, valueAxis32, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer33);
        int int54 = defaultCategoryDataset26.getRowIndex((java.lang.Comparable) (-4194304));
        defaultCategoryDataset26.clear();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo56 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState57 = barRenderer12.initialise(graphics2D23, rectangle2D24, categoryPlot25, (org.jfree.data.category.CategoryDataset) defaultCategoryDataset26, plotRenderingInfo56);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(gradientPaintTransformer19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0d + "'", double22 == 1.0d);
        org.junit.Assert.assertTrue("'" + float28 + "' != '" + 2.0f + "'", float28 == 2.0f);
        org.junit.Assert.assertNotNull(rectangleInsets31);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNull(paint37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(color42);
        org.junit.Assert.assertNotNull(rectangleInsets44);
        org.junit.Assert.assertNotNull(categoryAxisArray46);
        org.junit.Assert.assertNotNull(stroke48);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1) + "'", int54 == (-1));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        java.awt.Color color2 = java.awt.Color.getColor("SortOrder.ASCENDING", (-10289251));
        org.junit.Assert.assertNotNull(color2);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean3 = lineAndShapeRenderer0.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer0.setPlot(categoryPlot4);
        categoryPlot4.setBackgroundImageAlignment((int) (short) 0);
        categoryPlot4.setBackgroundImageAlignment((int) (short) 10);
        categoryPlot4.configureRangeAxes();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        float float10 = categoryPlot2.getForegroundAlpha();
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 1.0f + "'", float10 == 1.0f);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = new org.jfree.chart.util.RectangleInsets();
        double double2 = rectangleInsets0.extendHeight((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 102.0d + "'", double2 == 102.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        boolean boolean14 = barRenderer12.isDrawBarOutline();
        barRenderer12.setSeriesItemLabelsVisible((int) (short) 0, (java.lang.Boolean) false);
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        categoryAxis0.setLabel("");
        categoryAxis0.setLabel("{0}");
        java.awt.Stroke stroke7 = categoryAxis0.getAxisLineStroke();
        java.awt.Stroke stroke8 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.setTickMarkInsideLength((float) (-35));
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNotNull(stroke8);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer3 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int4 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer3);
        org.jfree.chart.axis.AxisSpace axisSpace5 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace5);
        java.awt.Paint paint7 = categoryPlot0.getDomainGridlinePaint();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1) + "'", int4 == (-1));
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextOutlineStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1, true);
        java.awt.Paint paint5 = defaultDrawingSupplier1.getNextPaint();
        java.awt.Shape shape6 = defaultDrawingSupplier1.getNextShape();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        lineAndShapeRenderer7.setSeriesVisibleInLegend((int) (short) 100, (java.lang.Boolean) true);
        boolean boolean11 = defaultDrawingSupplier1.equals((java.lang.Object) lineAndShapeRenderer7);
        java.awt.Paint paint12 = defaultDrawingSupplier1.getNextFillPaint();
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier1 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke2 = defaultDrawingSupplier1.getNextOutlineStroke();
        categoryPlot0.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier1, true);
        org.jfree.chart.axis.AxisLocation axisLocation6 = categoryPlot0.getDomainAxisLocation(1);
        java.lang.String str7 = axisLocation6.toString();
        org.jfree.chart.plot.PlotOrientation plotOrientation8 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation6, plotOrientation8);
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisSpace axisSpace11 = categoryPlot10.getFixedRangeAxisSpace();
        boolean boolean12 = categoryPlot10.isRangePannable();
        java.awt.Paint paint13 = categoryPlot10.getRangeMinorGridlinePaint();
        boolean boolean14 = plotOrientation8.equals((java.lang.Object) categoryPlot10);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder15 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier17 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke18 = defaultDrawingSupplier17.getNextOutlineStroke();
        categoryPlot16.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier17, true);
        java.awt.Paint paint21 = defaultDrawingSupplier17.getNextPaint();
        boolean boolean22 = datasetRenderingOrder15.equals((java.lang.Object) paint21);
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.plot.DefaultDrawingSupplier defaultDrawingSupplier24 = new org.jfree.chart.plot.DefaultDrawingSupplier();
        java.awt.Stroke stroke25 = defaultDrawingSupplier24.getNextOutlineStroke();
        categoryPlot23.setDrawingSupplier((org.jfree.chart.plot.DrawingSupplier) defaultDrawingSupplier24, true);
        java.awt.Paint paint28 = defaultDrawingSupplier24.getNextPaint();
        java.awt.Shape shape29 = defaultDrawingSupplier24.getNextShape();
        org.jfree.chart.LegendItem legendItem31 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer32 = legendItem31.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem34 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape35 = legendItem34.getLine();
        legendItem31.setShape(shape35);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer37 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Stroke stroke39 = lineAndShapeRenderer37.lookupSeriesStroke((int) ' ');
        java.awt.Paint paint41 = lineAndShapeRenderer37.lookupLegendTextPaint((int) '#');
        java.awt.Stroke stroke45 = lineAndShapeRenderer37.getItemStroke(1, (int) (short) 1, false);
        legendItem31.setOutlineStroke(stroke45);
        java.lang.String str47 = legendItem31.getToolTipText();
        boolean boolean48 = defaultDrawingSupplier24.equals((java.lang.Object) legendItem31);
        boolean boolean49 = datasetRenderingOrder15.equals((java.lang.Object) defaultDrawingSupplier24);
        categoryPlot10.setDatasetRenderingOrder(datasetRenderingOrder15);
        java.awt.Graphics2D graphics2D51 = null;
        java.awt.geom.Rectangle2D rectangle2D52 = null;
        try {
            categoryPlot10.drawOutline(graphics2D51, rectangle2D52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke2);
        org.junit.Assert.assertNotNull(axisLocation6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "AxisLocation.TOP_OR_RIGHT" + "'", str7.equals("AxisLocation.TOP_OR_RIGHT"));
        org.junit.Assert.assertNotNull(plotOrientation8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNull(axisSpace11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(paint13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder15);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(paint21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(stroke25);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertNotNull(gradientPaintTransformer32);
        org.junit.Assert.assertNotNull(shape35);
        org.junit.Assert.assertNotNull(stroke39);
        org.junit.Assert.assertNull(paint41);
        org.junit.Assert.assertNotNull(stroke45);
        org.junit.Assert.assertNull(str47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color1 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot0.setNoDataMessagePaint((java.awt.Paint) color1);
        categoryPlot0.setCrosshairDatasetIndex((int) (byte) 0, false);
        float float6 = categoryPlot0.getBackgroundImageAlpha();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot9.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis13 = null;
        org.jfree.chart.plot.Marker marker14 = null;
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        lineAndShapeRenderer7.drawRangeMarker(graphics2D8, categoryPlot9, valueAxis13, marker14, rectangle2D15);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot9.getDomainMarkers(layer17);
        org.jfree.chart.renderer.category.BarRenderer barRenderer19 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot9.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19);
        boolean boolean22 = barRenderer19.isSeriesVisible((int) (short) -1);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = barRenderer19.getLegendItemLabelGenerator();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer24 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot26.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis30 = null;
        org.jfree.chart.plot.Marker marker31 = null;
        java.awt.geom.Rectangle2D rectangle2D32 = null;
        lineAndShapeRenderer24.drawRangeMarker(graphics2D25, categoryPlot26, valueAxis30, marker31, rectangle2D32);
        boolean boolean34 = barRenderer19.hasListener((java.util.EventListener) categoryPlot26);
        int int35 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer19);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo37 = null;
        java.awt.geom.Point2D point2D38 = null;
        categoryPlot0.zoomDomainAxes(0.0d, plotRenderingInfo37, point2D38, false);
        boolean boolean41 = categoryPlot0.isDomainPannable();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.5f + "'", float6 == 0.5f);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator23);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-1) + "'", int35 == (-1));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.renderer.category.BarRenderer barRenderer12 = new org.jfree.chart.renderer.category.BarRenderer();
        categoryPlot2.setRenderer((org.jfree.chart.renderer.category.CategoryItemRenderer) barRenderer12);
        org.jfree.chart.renderer.category.BarPainter barPainter14 = barRenderer12.getBarPainter();
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer15 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D16 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot17.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis21 = null;
        org.jfree.chart.plot.Marker marker22 = null;
        java.awt.geom.Rectangle2D rectangle2D23 = null;
        lineAndShapeRenderer15.drawRangeMarker(graphics2D16, categoryPlot17, valueAxis21, marker22, rectangle2D23);
        org.jfree.chart.axis.AxisLocation axisLocation26 = null;
        categoryPlot17.setRangeAxisLocation((int) (short) 100, axisLocation26, false);
        java.awt.Color color29 = java.awt.Color.ORANGE;
        java.awt.Color color30 = color29.brighter();
        categoryPlot17.setRangeMinorGridlinePaint((java.awt.Paint) color30);
        boolean boolean32 = barRenderer12.hasListener((java.util.EventListener) categoryPlot17);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        try {
            categoryPlot17.handleClick(15, 35, plotRenderingInfo35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertNotNull(barPainter14);
        org.junit.Assert.assertNotNull(color29);
        org.junit.Assert.assertNotNull(color30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.util.UnitType unitType0 = org.jfree.chart.util.UnitType.RELATIVE;
        org.junit.Assert.assertNotNull(unitType0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer0 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot2.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis6 = null;
        org.jfree.chart.plot.Marker marker7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        lineAndShapeRenderer0.drawRangeMarker(graphics2D1, categoryPlot2, valueAxis6, marker7, rectangle2D8);
        org.jfree.chart.util.Layer layer10 = null;
        java.util.Collection collection11 = categoryPlot2.getDomainMarkers(layer10);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo14 = null;
        java.awt.geom.Point2D point2D15 = null;
        categoryPlot2.zoomRangeAxes((double) (-1), (double) 100.0f, plotRenderingInfo14, point2D15);
        org.jfree.chart.axis.AxisSpace axisSpace17 = null;
        categoryPlot2.setFixedDomainAxisSpace(axisSpace17);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer20 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        boolean boolean23 = lineAndShapeRenderer20.getItemShapeFilled((int) (short) 0, (-1));
        org.jfree.chart.plot.CategoryPlot categoryPlot24 = new org.jfree.chart.plot.CategoryPlot();
        lineAndShapeRenderer20.setPlot(categoryPlot24);
        categoryPlot2.setRenderer(0, (org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer20);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer27 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        java.awt.Graphics2D graphics2D28 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        categoryPlot29.setDomainCrosshairRowKey((java.lang.Comparable) 100.0f, false);
        org.jfree.chart.axis.ValueAxis valueAxis33 = null;
        org.jfree.chart.plot.Marker marker34 = null;
        java.awt.geom.Rectangle2D rectangle2D35 = null;
        lineAndShapeRenderer27.drawRangeMarker(graphics2D28, categoryPlot29, valueAxis33, marker34, rectangle2D35);
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot29.setRangeAxisLocation((int) (short) 100, axisLocation38, false);
        lineAndShapeRenderer20.removeChangeListener((org.jfree.chart.event.RendererChangeListener) categoryPlot29);
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = categoryPlot29.getRangeAxisEdge(100);
        boolean boolean44 = categoryPlot29.isRangeCrosshairVisible();
        org.junit.Assert.assertNull(collection11);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getTickMarkOutsideLength();
        categoryAxis0.setCategoryMargin((double) 8);
        org.jfree.chart.plot.CategoryPlot categoryPlot4 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.Color color5 = org.jfree.chart.ChartColor.VERY_DARK_MAGENTA;
        categoryPlot4.setNoDataMessagePaint((java.awt.Paint) color5);
        org.jfree.chart.renderer.category.LineAndShapeRenderer lineAndShapeRenderer7 = new org.jfree.chart.renderer.category.LineAndShapeRenderer();
        int int8 = categoryPlot4.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) lineAndShapeRenderer7);
        org.jfree.chart.plot.PlotOrientation plotOrientation10 = org.jfree.chart.plot.PlotOrientation.HORIZONTAL;
        java.awt.Color color11 = java.awt.Color.WHITE;
        boolean boolean12 = plotOrientation10.equals((java.lang.Object) color11);
        int int13 = color11.getBlue();
        lineAndShapeRenderer7.setSeriesFillPaint(1, (java.awt.Paint) color11);
        categoryAxis0.setTickMarkPaint((java.awt.Paint) color11);
        java.awt.Stroke stroke16 = categoryAxis0.getTickMarkStroke();
        categoryAxis0.setCategoryLabelPositionOffset((int) (short) 1);
        java.awt.Paint paint20 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.0f + "'", float1 == 2.0f);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1) + "'", int8 == (-1));
        org.junit.Assert.assertNotNull(plotOrientation10);
        org.junit.Assert.assertNotNull(color11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 255 + "'", int13 == 255);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(paint20);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.LegendItem legendItem1 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer2 = legendItem1.getFillPaintTransformer();
        legendItem1.setDatasetIndex((int) (byte) 0);
        org.jfree.chart.LegendItem legendItem6 = new org.jfree.chart.LegendItem("hi!");
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer7 = legendItem6.getFillPaintTransformer();
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("hi!");
        java.awt.Shape shape10 = legendItem9.getLine();
        legendItem6.setShape(shape10);
        org.jfree.chart.entity.ChartEntity chartEntity14 = new org.jfree.chart.entity.ChartEntity(shape10, "AxisLocation.TOP_OR_RIGHT", "hi!");
        legendItem1.setShape(shape10);
        org.junit.Assert.assertNotNull(gradientPaintTransformer2);
        org.junit.Assert.assertNotNull(gradientPaintTransformer7);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        org.jfree.chart.util.RectangleInsets rectangleInsets1 = categoryAxis0.getTickLabelInsets();
        float float2 = categoryAxis0.getTickMarkInsideLength();
        java.lang.String str3 = categoryAxis0.getLabelURL();
        categoryAxis0.configure();
        org.junit.Assert.assertNotNull(rectangleInsets1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertNull(str3);
    }
}

