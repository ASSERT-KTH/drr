import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.String str2 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((int) (short) 1, (int) '#');
        java.lang.String str6 = timeSeries1.getDomainDescription();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class10);
        timeSeries11.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        int int14 = timeSeries11.getMaximumItemCount();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class18);
        timeSeries19.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.addChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class28);
        timeSeries29.setDomainDescription("hi!");
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month32, 0.0d);
        long long35 = month32.getFirstMillisecond();
        int int36 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) month32);
        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.String str39 = timeSeries38.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries40 = timeSeries19.addAndOrUpdate(timeSeries38);
        java.lang.Class class44 = null;
        org.jfree.data.time.TimeSeries timeSeries45 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class44);
        timeSeries45.setDomainDescription("hi!");
        org.jfree.data.time.Month month48 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem50 = timeSeries45.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month48, 0.0d);
        long long51 = month48.getFirstMillisecond();
        int int52 = month48.getYearValue();
        int int53 = timeSeries38.getIndex((org.jfree.data.time.RegularTimePeriod) month48);
        org.jfree.data.time.TimeSeries timeSeries54 = timeSeries1.addAndOrUpdate(timeSeries38);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Time" + "'", str6.equals("Time"));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1559372400000L + "'", long35 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "Value" + "'", str39.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries40);
        org.junit.Assert.assertNull(timeSeriesDataItem50);
        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 1559372400000L + "'", long51 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2019 + "'", int52 == 2019);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1) + "'", int53 == (-1));
        org.junit.Assert.assertNotNull(timeSeries54);
    }

//    @Test
//    public void test02() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test02");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(5);
//        java.lang.String str2 = spreadsheetDate1.getDescription();
//        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
//        serialDate4.setDescription("");
//        java.lang.String str7 = serialDate4.getDescription();
//        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getFollowingDayOfWeek(1);
//        serialDate9.setDescription("hi!");
//        boolean boolean12 = spreadsheetDate1.isOn(serialDate9);
//        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(9);
//        serialDate14.setDescription("");
//        java.lang.String str17 = serialDate14.getDescription();
//        org.jfree.data.time.SerialDate serialDate19 = serialDate14.getFollowingDayOfWeek(1);
//        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate14);
//        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(9);
//        serialDate23.setDescription("");
//        java.lang.String str26 = serialDate23.getDescription();
//        org.jfree.data.time.SerialDate serialDate28 = serialDate23.getFollowingDayOfWeek(1);
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays(0, serialDate23);
//        boolean boolean31 = spreadsheetDate1.isInRange(serialDate14, serialDate29, 0);
//        int int32 = spreadsheetDate1.toSerial();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate35 = new org.jfree.data.time.SpreadsheetDate(5);
//        java.lang.String str36 = spreadsheetDate35.getDescription();
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.addMonths(11, (org.jfree.data.time.SerialDate) spreadsheetDate35);
//        int int38 = spreadsheetDate35.getYYYY();
//        org.jfree.data.time.SerialDate serialDate41 = org.jfree.data.time.SerialDate.createInstance(9);
//        serialDate41.setDescription("");
//        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(serialDate41);
//        org.jfree.data.time.SerialDate serialDate45 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, serialDate41);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate47 = new org.jfree.data.time.SpreadsheetDate(5);
//        java.lang.String str48 = spreadsheetDate47.getDescription();
//        int int49 = spreadsheetDate47.getYYYY();
//        int int50 = spreadsheetDate47.getYYYY();
//        org.jfree.data.time.Day day51 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        boolean boolean52 = spreadsheetDate35.isInRange(serialDate41, (org.jfree.data.time.SerialDate) spreadsheetDate47);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate54 = new org.jfree.data.time.SpreadsheetDate(5);
//        org.jfree.data.time.SerialDate serialDate56 = org.jfree.data.time.SerialDate.createInstance(9);
//        serialDate56.setDescription("");
//        java.lang.String str59 = serialDate56.getDescription();
//        org.jfree.data.time.SerialDate serialDate61 = serialDate56.getFollowingDayOfWeek(1);
//        boolean boolean62 = spreadsheetDate54.isBefore(serialDate61);
//        org.jfree.data.time.SerialDate serialDate64 = org.jfree.data.time.SerialDate.createInstance(9);
//        serialDate64.setDescription("");
//        java.lang.String str67 = serialDate64.getDescription();
//        org.jfree.data.time.SerialDate serialDate69 = serialDate64.getFollowingDayOfWeek(1);
//        boolean boolean70 = spreadsheetDate54.isOnOrBefore(serialDate69);
//        boolean boolean71 = spreadsheetDate47.isOnOrAfter(serialDate69);
//        boolean boolean72 = spreadsheetDate1.isAfter((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        org.jfree.data.time.Day day73 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate47);
//        int int74 = spreadsheetDate47.toSerial();
//        org.jfree.data.time.Day day75 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod76 = day75.next();
//        int int77 = day75.getDayOfMonth();
//        java.util.Date date78 = day75.getEnd();
//        org.jfree.data.time.Month month79 = new org.jfree.data.time.Month(date78);
//        org.jfree.data.time.Year year80 = new org.jfree.data.time.Year(date78);
//        boolean boolean81 = spreadsheetDate47.equals((java.lang.Object) date78);
//        int int82 = spreadsheetDate47.getYYYY();
//        org.junit.Assert.assertNull(str2);
//        org.junit.Assert.assertNotNull(serialDate4);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
//        org.junit.Assert.assertNotNull(serialDate19);
//        org.junit.Assert.assertNotNull(serialDate23);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
//        org.junit.Assert.assertNotNull(serialDate28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
//        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 5 + "'", int32 == 5);
//        org.junit.Assert.assertNull(str36);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1900 + "'", int38 == 1900);
//        org.junit.Assert.assertNotNull(serialDate41);
//        org.junit.Assert.assertNotNull(serialDate45);
//        org.junit.Assert.assertNull(str48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 1900 + "'", int49 == 1900);
//        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1900 + "'", int50 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
//        org.junit.Assert.assertNotNull(serialDate56);
//        org.junit.Assert.assertTrue("'" + str59 + "' != '" + "" + "'", str59.equals(""));
//        org.junit.Assert.assertNotNull(serialDate61);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(serialDate64);
//        org.junit.Assert.assertTrue("'" + str67 + "' != '" + "" + "'", str67.equals(""));
//        org.junit.Assert.assertNotNull(serialDate69);
//        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
//        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
//        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
//        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 5 + "'", int74 == 5);
//        org.junit.Assert.assertNotNull(regularTimePeriod76);
//        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 10 + "'", int77 == 10);
//        org.junit.Assert.assertNotNull(date78);
//        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
//        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1900 + "'", int82 == 1900);
//    }

//    @Test
//    public void test03() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test03");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries1.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 12);
//        java.util.Calendar calendar7 = null;
//        fixedMillisecond4.peg(calendar7);
//        java.util.Date date9 = fixedMillisecond4.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.next();
//        long long12 = fixedMillisecond10.getMiddleMillisecond();
//        java.util.Date date13 = fixedMillisecond10.getTime();
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560190824267L + "'", long12 == 1560190824267L);
//        org.junit.Assert.assertNotNull(date13);
//    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        java.lang.Class class4 = null;
        org.jfree.data.time.TimeSeries timeSeries5 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class4);
        timeSeries5.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        int int8 = timeSeries5.getMaximumItemCount();
        java.lang.Class class12 = null;
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class12);
        timeSeries13.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener16 = null;
        timeSeries13.addChangeListener(seriesChangeListener16);
        java.util.Collection collection18 = timeSeries5.getTimePeriodsUniqueToOtherSeries(timeSeries13);
        java.lang.Class class22 = null;
        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class22);
        timeSeries23.setDomainDescription("hi!");
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month26, 0.0d);
        long long29 = month26.getFirstMillisecond();
        int int30 = timeSeries13.getIndex((org.jfree.data.time.RegularTimePeriod) month26);
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.String str33 = timeSeries32.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries13.addAndOrUpdate(timeSeries32);
        org.jfree.data.time.TimeSeries timeSeries36 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries36.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond39 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = timeSeries36.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (java.lang.Number) 12);
        java.util.Calendar calendar42 = null;
        fixedMillisecond39.peg(calendar42);
        java.lang.Class class47 = null;
        org.jfree.data.time.TimeSeries timeSeries48 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class47);
        timeSeries48.setDomainDescription("hi!");
        org.jfree.data.time.Month month51 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem53 = timeSeries48.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month51, 0.0d);
        long long54 = month51.getFirstMillisecond();
        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries13.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond39, (org.jfree.data.time.RegularTimePeriod) month51);
        java.util.Date date56 = fixedMillisecond39.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond57 = new org.jfree.data.time.FixedMillisecond(date56);
        org.jfree.data.time.TimeSeries timeSeries58 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) fixedMillisecond57);
        java.util.Date date59 = fixedMillisecond57.getTime();
        java.util.Date date60 = fixedMillisecond57.getStart();
        org.jfree.data.time.Year year61 = new org.jfree.data.time.Year(date60);
        org.jfree.data.time.Month month62 = new org.jfree.data.time.Month(8, year61);
        long long63 = year61.getLastMillisecond();
        java.lang.Class class67 = null;
        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class67);
        timeSeries68.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        int int71 = timeSeries68.getMaximumItemCount();
        java.lang.Class class75 = null;
        org.jfree.data.time.TimeSeries timeSeries76 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class75);
        timeSeries76.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener79 = null;
        timeSeries76.addChangeListener(seriesChangeListener79);
        java.util.Collection collection81 = timeSeries68.getTimePeriodsUniqueToOtherSeries(timeSeries76);
        java.lang.Object obj82 = timeSeries76.clone();
        java.lang.Comparable comparable83 = timeSeries76.getKey();
        org.jfree.data.time.Year year85 = new org.jfree.data.time.Year(2019);
        int int87 = year85.compareTo((java.lang.Object) "Mon Jun 10 11:18:58 PDT 2019");
        long long88 = year85.getSerialIndex();
        org.jfree.data.time.TimeSeries timeSeries90 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries90.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond93 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem95 = timeSeries90.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond93, (java.lang.Number) 12);
        java.util.Calendar calendar96 = null;
        fixedMillisecond93.peg(calendar96);
        org.jfree.data.time.TimeSeries timeSeries98 = timeSeries76.createCopy((org.jfree.data.time.RegularTimePeriod) year85, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond93);
        boolean boolean99 = year61.equals((java.lang.Object) fixedMillisecond93);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
        org.junit.Assert.assertNotNull(collection18);
        org.junit.Assert.assertNull(timeSeriesDataItem28);
        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 1559372400000L + "'", long29 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-1) + "'", int30 == (-1));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "Value" + "'", str33.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries34);
        org.junit.Assert.assertNull(timeSeriesDataItem41);
        org.junit.Assert.assertNull(timeSeriesDataItem53);
        org.junit.Assert.assertTrue("'" + long54 + "' != '" + 1559372400000L + "'", long54 == 1559372400000L);
        org.junit.Assert.assertNotNull(timeSeries55);
        org.junit.Assert.assertNotNull(date56);
        org.junit.Assert.assertNotNull(date59);
        org.junit.Assert.assertNotNull(date60);
        org.junit.Assert.assertTrue("'" + long63 + "' != '" + 1577865599999L + "'", long63 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 2147483647 + "'", int71 == 2147483647);
        org.junit.Assert.assertNotNull(collection81);
        org.junit.Assert.assertNotNull(obj82);
        org.junit.Assert.assertTrue("'" + comparable83 + "' != '" + '4' + "'", comparable83.equals('4'));
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 1 + "'", int87 == 1);
        org.junit.Assert.assertTrue("'" + long88 + "' != '" + 2019L + "'", long88 == 2019L);
        org.junit.Assert.assertNull(timeSeriesDataItem95);
        org.junit.Assert.assertNotNull(timeSeries98);
        org.junit.Assert.assertTrue("'" + boolean99 + "' != '" + false + "'", boolean99 == false);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries1.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 12);
        java.lang.Comparable comparable7 = timeSeries1.getKey();
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class11);
        timeSeries12.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        int int15 = timeSeries12.getMaximumItemCount();
        java.lang.Class class19 = null;
        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class19);
        timeSeries20.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener23 = null;
        timeSeries20.addChangeListener(seriesChangeListener23);
        java.util.Collection collection25 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries20);
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class29);
        timeSeries30.setDomainDescription("hi!");
        org.jfree.data.time.Month month33 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month33, 0.0d);
        long long36 = month33.getFirstMillisecond();
        int int37 = timeSeries20.getIndex((org.jfree.data.time.RegularTimePeriod) month33);
        boolean boolean39 = month33.equals((java.lang.Object) (short) 10);
        long long40 = month33.getFirstMillisecond();
        try {
            timeSeries1.add((org.jfree.data.time.RegularTimePeriod) month33, (java.lang.Number) 1560190777170L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) 0 + "'", comparable7.equals((short) 0));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
        org.junit.Assert.assertNotNull(collection25);
        org.junit.Assert.assertNull(timeSeriesDataItem35);
        org.junit.Assert.assertTrue("'" + long36 + "' != '" + 1559372400000L + "'", long36 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1) + "'", int37 == (-1));
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + long40 + "' != '" + 1559372400000L + "'", long40 == 1559372400000L);
    }

//    @Test
//    public void test06() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test06");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries1.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 12);
//        java.util.Calendar calendar7 = null;
//        long long8 = fixedMillisecond4.getFirstMillisecond(calendar7);
//        long long9 = fixedMillisecond4.getMiddleMillisecond();
//        java.lang.Number number10 = null;
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, number10);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1560190824733L + "'", long8 == 1560190824733L);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1560190824733L + "'", long9 == 1560190824733L);
//    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9);
        serialDate1.setDescription("");
        org.jfree.data.time.Day day4 = new org.jfree.data.time.Day(serialDate1);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod5 = day4.previous();
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries8.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 12);
        java.util.Calendar calendar14 = null;
        fixedMillisecond11.peg(calendar14);
        java.util.Date date16 = fixedMillisecond11.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date16, timeZone17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year21 = month19.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod22 = month19.next();
        java.util.Date date23 = regularTimePeriod22.getEnd();
        int int24 = day4.compareTo((java.lang.Object) regularTimePeriod22);
        java.util.Date date25 = day4.getStart();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertNotNull(regularTimePeriod5);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertNotNull(regularTimePeriod22);
        org.junit.Assert.assertNotNull(date23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(date25);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries1.setDescription("");
        timeSeries1.setDomainDescription("Mon Jun 10 11:18:52 PDT 2019");
        java.lang.Comparable comparable6 = timeSeries1.getKey();
        java.beans.PropertyChangeListener propertyChangeListener7 = null;
        timeSeries1.addPropertyChangeListener(propertyChangeListener7);
        org.junit.Assert.assertTrue("'" + comparable6 + "' != '" + (short) 0 + "'", comparable6.equals((short) 0));
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((-435), (-452), 12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        java.lang.Class class0 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries2.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 12);
        java.util.Calendar calendar8 = null;
        fixedMillisecond5.peg(calendar8);
        java.util.Date date10 = fixedMillisecond5.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date10, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date10);
        long long14 = month13.getSerialIndex();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = month13.previous();
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 24234L + "'", long14 == 24234L);
        org.junit.Assert.assertNotNull(regularTimePeriod15);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.jfree.data.time.Day day1 = org.jfree.data.time.Day.parseDay("May");
        org.junit.Assert.assertNull(day1);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        boolean boolean1 = org.jfree.data.time.SerialDate.isValidMonthCode(13);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9);
        serialDate1.setDescription("");
        java.lang.String str4 = serialDate1.getDescription();
        org.jfree.data.time.SerialDate serialDate6 = serialDate1.getFollowingDayOfWeek(1);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class11);
        timeSeries12.setDomainDescription("hi!");
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, 0.0d);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class21);
        timeSeries22.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        int int25 = timeSeries22.getMaximumItemCount();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class29);
        timeSeries30.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries30.addChangeListener(seriesChangeListener33);
        java.util.Collection collection35 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class39);
        timeSeries40.setDomainDescription("hi!");
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month43, 0.0d);
        long long46 = month43.getFirstMillisecond();
        int int47 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month43);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.String str50 = timeSeries49.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries30.addAndOrUpdate(timeSeries49);
        java.util.Collection collection52 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries49);
        boolean boolean53 = day7.equals((java.lang.Object) timeSeries49);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener54 = null;
        timeSeries49.removeChangeListener(seriesChangeListener54);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2147483647 + "'", int25 == 2147483647);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1559372400000L + "'", long46 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Value" + "'", str50.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(collection52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

//    @Test
//    public void test14() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test14");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(5);
//        java.lang.String str2 = spreadsheetDate1.getDescription();
//        int int3 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) (byte) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (byte) 10);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond7.getLastMillisecond(calendar10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) (byte) 100);
//        boolean boolean14 = timeSeriesDataItem6.equals((java.lang.Object) fixedMillisecond7);
//        long long15 = fixedMillisecond7.getMiddleMillisecond();
//        boolean boolean16 = spreadsheetDate1.equals((java.lang.Object) long15);
//        int int17 = spreadsheetDate1.getYYYY();
//        int int18 = spreadsheetDate1.getYYYY();
//        boolean boolean20 = spreadsheetDate1.equals((java.lang.Object) 1560190821817L);
//        org.junit.Assert.assertNull(str2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560190825158L + "'", long11 == 1560190825158L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190825158L + "'", long15 == 1560190825158L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1900 + "'", int17 == 1900);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 1900 + "'", int18 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//    }

//    @Test
//    public void test15() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test15");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries2.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 12);
//        java.util.Calendar calendar8 = null;
//        fixedMillisecond5.peg(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getEnd();
//        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date10, timeZone11);
//        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date10);
//        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month(date10);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(date10);
//        int int16 = day15.getDayOfMonth();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day15.previous();
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNotNull(timeZone11);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(5);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        serialDate4.setDescription("");
        java.lang.String str7 = serialDate4.getDescription();
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getFollowingDayOfWeek(1);
        serialDate9.setDescription("hi!");
        boolean boolean12 = spreadsheetDate1.isOn(serialDate9);
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(9);
        serialDate14.setDescription("");
        java.lang.String str17 = serialDate14.getDescription();
        org.jfree.data.time.SerialDate serialDate19 = serialDate14.getFollowingDayOfWeek(1);
        org.jfree.data.time.Day day20 = new org.jfree.data.time.Day(serialDate14);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.createInstance(9);
        serialDate23.setDescription("");
        java.lang.String str26 = serialDate23.getDescription();
        org.jfree.data.time.SerialDate serialDate28 = serialDate23.getFollowingDayOfWeek(1);
        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addDays(0, serialDate23);
        boolean boolean31 = spreadsheetDate1.isInRange(serialDate14, serialDate29, 0);
        int int32 = spreadsheetDate1.getMonth();
        int int33 = spreadsheetDate1.toSerial();
        org.jfree.data.time.SerialDate serialDate34 = null;
        org.jfree.data.time.SpreadsheetDate spreadsheetDate36 = new org.jfree.data.time.SpreadsheetDate(9999);
        java.util.Date date37 = spreadsheetDate36.toDate();
        try {
            boolean boolean39 = spreadsheetDate1.isInRange(serialDate34, (org.jfree.data.time.SerialDate) spreadsheetDate36, (-457));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "" + "'", str26.equals(""));
        org.junit.Assert.assertNotNull(serialDate28);
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 5 + "'", int33 == 5);
        org.junit.Assert.assertNotNull(date37);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(5);
        java.lang.String str3 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(11, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate6 = new org.jfree.data.time.SpreadsheetDate(5);
        org.jfree.data.time.SerialDate serialDate8 = org.jfree.data.time.SerialDate.createInstance(9);
        serialDate8.setDescription("");
        java.lang.String str11 = serialDate8.getDescription();
        org.jfree.data.time.SerialDate serialDate13 = serialDate8.getFollowingDayOfWeek(1);
        boolean boolean14 = spreadsheetDate6.isBefore(serialDate13);
        org.jfree.data.time.SerialDate serialDate16 = org.jfree.data.time.SerialDate.createInstance(9);
        serialDate16.setDescription("");
        java.lang.String str19 = serialDate16.getDescription();
        org.jfree.data.time.SerialDate serialDate21 = serialDate16.getFollowingDayOfWeek(1);
        boolean boolean22 = spreadsheetDate6.isOnOrBefore(serialDate21);
        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate6);
        boolean boolean24 = spreadsheetDate2.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate6);
        org.jfree.data.time.SerialDate serialDate26 = org.jfree.data.time.SerialDate.createInstance(9);
        serialDate26.setDescription("");
        java.lang.String str29 = serialDate26.getDescription();
        int int30 = spreadsheetDate2.compare(serialDate26);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertNotNull(serialDate8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "" + "'", str11.equals(""));
        org.junit.Assert.assertNotNull(serialDate13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(serialDate16);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "" + "'", str19.equals(""));
        org.junit.Assert.assertNotNull(serialDate21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(serialDate26);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "" + "'", str29.equals(""));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-4) + "'", int30 == (-4));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries1.setDescription("");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month4);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class10);
        timeSeries11.setDomainDescription("hi!");
        org.jfree.data.time.Month month14 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem16 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month14, 0.0d);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = month14.previous();
        try {
            timeSeries1.add(regularTimePeriod17, (java.lang.Number) 1560190774186L, true);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: You are trying to add data where the time period class is org.jfree.data.time.Month, but the TimeSeries is expecting an instance of org.jfree.data.time.Day.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNull(timeSeriesDataItem16);
        org.junit.Assert.assertNotNull(regularTimePeriod17);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(30);
        int int2 = spreadsheetDate1.getDayOfMonth();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 29 + "'", int2 == 29);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9);
        serialDate1.setDescription("");
        java.lang.String str4 = serialDate1.getDescription();
        org.jfree.data.time.SerialDate serialDate6 = serialDate1.getFollowingDayOfWeek(1);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class11);
        timeSeries12.setDomainDescription("hi!");
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, 0.0d);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class21);
        timeSeries22.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        int int25 = timeSeries22.getMaximumItemCount();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class29);
        timeSeries30.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries30.addChangeListener(seriesChangeListener33);
        java.util.Collection collection35 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class39);
        timeSeries40.setDomainDescription("hi!");
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month43, 0.0d);
        long long46 = month43.getFirstMillisecond();
        int int47 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month43);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.String str50 = timeSeries49.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries30.addAndOrUpdate(timeSeries49);
        java.util.Collection collection52 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries49);
        boolean boolean53 = day7.equals((java.lang.Object) timeSeries49);
        java.lang.String str54 = timeSeries49.getDescription();
        boolean boolean55 = timeSeries49.getNotify();
        timeSeries49.removeAgedItems(false);
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2147483647 + "'", int25 == 2147483647);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1559372400000L + "'", long46 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Value" + "'", str50.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(collection52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNull(str54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        java.lang.String str1 = org.jfree.data.time.SerialDate.relativeToString(9);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ERROR : Relative To String" + "'", str1.equals("ERROR : Relative To String"));
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries1.setDescription("");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month4);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class10);
        timeSeries11.setDomainDescription("hi!");
        timeSeries11.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries16.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 12);
        java.util.Calendar calendar22 = null;
        fixedMillisecond19.peg(calendar22);
        java.util.Date date24 = fixedMillisecond19.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) (-1.0f));
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (java.lang.Number) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        timeSeries30.setRangeDescription("Mon Jun 10 11:20:13 PDT 2019");
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(timeSeries30);
    }

//    @Test
//    public void test23() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test23");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class3);
//        timeSeries4.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        int int7 = timeSeries4.getMaximumItemCount();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class11);
//        timeSeries12.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries12.addChangeListener(seriesChangeListener15);
//        java.util.Collection collection17 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class21);
//        timeSeries22.setDomainDescription("hi!");
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month25, 0.0d);
//        long long28 = month25.getFirstMillisecond();
//        int int29 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) month25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) (byte) 10);
//        long long33 = fixedMillisecond30.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 1560190738578L);
//        java.util.Date date36 = fixedMillisecond30.getTime();
//        org.jfree.data.time.Day day37 = new org.jfree.data.time.Day(date36);
//        java.lang.Class class41 = null;
//        org.jfree.data.time.TimeSeries timeSeries42 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class41);
//        timeSeries42.setDomainDescription("hi!");
//        timeSeries42.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries47.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (java.lang.Number) 12);
//        java.util.Calendar calendar53 = null;
//        fixedMillisecond50.peg(calendar53);
//        java.util.Date date55 = fixedMillisecond50.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem57 = timeSeries42.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (java.lang.Number) (-1.0f));
//        long long58 = fixedMillisecond50.getMiddleMillisecond();
//        java.util.Date date59 = fixedMillisecond50.getTime();
//        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        boolean boolean62 = timeSeries61.isEmpty();
//        timeSeries61.setMaximumItemAge((long) 6);
//        java.lang.Class class65 = timeSeries61.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries67 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries67.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond70 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem72 = timeSeries67.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond70, (java.lang.Number) 12);
//        java.util.Calendar calendar73 = null;
//        fixedMillisecond70.peg(calendar73);
//        java.util.Date date75 = fixedMillisecond70.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond76 = new org.jfree.data.time.FixedMillisecond(date75);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond(date75);
//        java.lang.Class class78 = null;
//        org.jfree.data.time.TimeSeries timeSeries80 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries80.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond83 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = timeSeries80.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond83, (java.lang.Number) 12);
//        java.util.Calendar calendar86 = null;
//        fixedMillisecond83.peg(calendar86);
//        java.util.Date date88 = fixedMillisecond83.getEnd();
//        java.util.TimeZone timeZone89 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod90 = org.jfree.data.time.RegularTimePeriod.createInstance(class78, date88, timeZone89);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod91 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date75, timeZone89);
//        java.util.Date date92 = null;
//        java.util.TimeZone timeZone93 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod94 = org.jfree.data.time.RegularTimePeriod.createInstance(class65, date92, timeZone93);
//        org.jfree.data.time.Day day95 = new org.jfree.data.time.Day(date59, timeZone93);
//        java.util.TimeZone timeZone96 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.Day day97 = new org.jfree.data.time.Day(date59, timeZone96);
//        org.jfree.data.time.Day day98 = new org.jfree.data.time.Day(date36, timeZone96);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond99 = new org.jfree.data.time.FixedMillisecond(date36);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1559372400000L + "'", long28 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560190825417L + "'", long33 == 1560190825417L);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertNull(timeSeriesDataItem52);
//        org.junit.Assert.assertNotNull(date55);
//        org.junit.Assert.assertNull(timeSeriesDataItem57);
//        org.junit.Assert.assertTrue("'" + long58 + "' != '" + 1560190825423L + "'", long58 == 1560190825423L);
//        org.junit.Assert.assertNotNull(date59);
//        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
//        org.junit.Assert.assertNotNull(class65);
//        org.junit.Assert.assertNull(timeSeriesDataItem72);
//        org.junit.Assert.assertNotNull(date75);
//        org.junit.Assert.assertNull(timeSeriesDataItem85);
//        org.junit.Assert.assertNotNull(date88);
//        org.junit.Assert.assertNotNull(timeZone89);
//        org.junit.Assert.assertNull(regularTimePeriod90);
//        org.junit.Assert.assertNotNull(regularTimePeriod91);
//        org.junit.Assert.assertNotNull(timeZone93);
//        org.junit.Assert.assertNull(regularTimePeriod94);
//        org.junit.Assert.assertNotNull(timeZone96);
//    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(9999);
        int int2 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate4 = new org.jfree.data.time.SpreadsheetDate(5);
        org.jfree.data.time.SerialDate serialDate6 = org.jfree.data.time.SerialDate.createInstance(9);
        serialDate6.setDescription("");
        java.lang.String str9 = serialDate6.getDescription();
        org.jfree.data.time.SerialDate serialDate11 = serialDate6.getFollowingDayOfWeek(1);
        boolean boolean12 = spreadsheetDate4.isBefore(serialDate11);
        int int13 = spreadsheetDate4.getMonth();
        boolean boolean14 = spreadsheetDate1.isBefore((org.jfree.data.time.SerialDate) spreadsheetDate4);
        int int15 = spreadsheetDate1.getYYYY();
        java.util.Date date16 = spreadsheetDate1.toDate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1927 + "'", int2 == 1927);
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
        org.junit.Assert.assertNotNull(serialDate11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1 + "'", int13 == 1);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1927 + "'", int15 == 1927);
        org.junit.Assert.assertNotNull(date16);
    }

//    @Test
//    public void test25() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test25");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.lang.String str2 = timeSeries1.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((int) (short) 1, (int) '#');
//        timeSeries1.fireSeriesChanged();
//        java.lang.Class class7 = null;
//        org.jfree.data.time.TimeSeries timeSeries9 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries9.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond12 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem14 = timeSeries9.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond12, (java.lang.Number) 12);
//        java.util.Calendar calendar15 = null;
//        fixedMillisecond12.peg(calendar15);
//        java.util.Date date17 = fixedMillisecond12.getEnd();
//        java.util.TimeZone timeZone18 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = org.jfree.data.time.RegularTimePeriod.createInstance(class7, date17, timeZone18);
//        org.jfree.data.time.Year year20 = new org.jfree.data.time.Year(date17);
//        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(date17);
//        java.lang.Class class25 = null;
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class25);
//        timeSeries26.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        int int29 = timeSeries26.getMaximumItemCount();
//        java.lang.Class class33 = null;
//        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class33);
//        timeSeries34.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener37 = null;
//        timeSeries34.addChangeListener(seriesChangeListener37);
//        java.util.Collection collection39 = timeSeries26.getTimePeriodsUniqueToOtherSeries(timeSeries34);
//        java.lang.Class class43 = null;
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class43);
//        timeSeries44.setDomainDescription("hi!");
//        org.jfree.data.time.Month month47 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month47, 0.0d);
//        long long50 = month47.getFirstMillisecond();
//        int int51 = timeSeries34.getIndex((org.jfree.data.time.RegularTimePeriod) month47);
//        org.jfree.data.time.TimeSeries timeSeries53 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        java.lang.String str54 = timeSeries53.getRangeDescription();
//        org.jfree.data.time.TimeSeries timeSeries55 = timeSeries34.addAndOrUpdate(timeSeries53);
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries57.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries57.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, (java.lang.Number) 12);
//        java.util.Calendar calendar63 = null;
//        fixedMillisecond60.peg(calendar63);
//        java.lang.Class class68 = null;
//        org.jfree.data.time.TimeSeries timeSeries69 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class68);
//        timeSeries69.setDomainDescription("hi!");
//        org.jfree.data.time.Month month72 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem74 = timeSeries69.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month72, 0.0d);
//        long long75 = month72.getFirstMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries76 = timeSeries34.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, (org.jfree.data.time.RegularTimePeriod) month72);
//        java.util.Date date77 = fixedMillisecond60.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond78 = new org.jfree.data.time.FixedMillisecond(date77);
//        java.util.Date date79 = fixedMillisecond78.getStart();
//        long long80 = fixedMillisecond78.getLastMillisecond();
//        org.jfree.data.time.TimeSeries timeSeries81 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) day21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond78);
//        org.jfree.data.time.Year year82 = new org.jfree.data.time.Year();
//        long long83 = year82.getFirstMillisecond();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod84 = year82.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem85 = timeSeries81.getDataItem((org.jfree.data.time.RegularTimePeriod) year82);
//        java.util.Calendar calendar86 = null;
//        try {
//            long long87 = year82.getLastMillisecond(calendar86);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
//        org.junit.Assert.assertNotNull(timeSeries5);
//        org.junit.Assert.assertNull(timeSeriesDataItem14);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 2147483647 + "'", int29 == 2147483647);
//        org.junit.Assert.assertNotNull(collection39);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertTrue("'" + long50 + "' != '" + 1559372400000L + "'", long50 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1) + "'", int51 == (-1));
//        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "Value" + "'", str54.equals("Value"));
//        org.junit.Assert.assertNotNull(timeSeries55);
//        org.junit.Assert.assertNull(timeSeriesDataItem62);
//        org.junit.Assert.assertNull(timeSeriesDataItem74);
//        org.junit.Assert.assertTrue("'" + long75 + "' != '" + 1559372400000L + "'", long75 == 1559372400000L);
//        org.junit.Assert.assertNotNull(timeSeries76);
//        org.junit.Assert.assertNotNull(date77);
//        org.junit.Assert.assertNotNull(date79);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + 1560190825968L + "'", long80 == 1560190825968L);
//        org.junit.Assert.assertNotNull(timeSeries81);
//        org.junit.Assert.assertTrue("'" + long83 + "' != '" + 1546329600000L + "'", long83 == 1546329600000L);
//        org.junit.Assert.assertNotNull(regularTimePeriod84);
//        org.junit.Assert.assertNull(timeSeriesDataItem85);
//    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(5);
        java.lang.String str3 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SerialDate serialDate5 = org.jfree.data.time.SerialDate.createInstance(9);
        serialDate5.setDescription("");
        java.lang.String str8 = serialDate5.getDescription();
        org.jfree.data.time.SerialDate serialDate10 = serialDate5.getFollowingDayOfWeek(1);
        serialDate10.setDescription("hi!");
        boolean boolean13 = spreadsheetDate2.isOn(serialDate10);
        org.jfree.data.time.SerialDate serialDate15 = org.jfree.data.time.SerialDate.createInstance(9);
        serialDate15.setDescription("");
        java.lang.String str18 = serialDate15.getDescription();
        org.jfree.data.time.SerialDate serialDate20 = serialDate15.getFollowingDayOfWeek(1);
        org.jfree.data.time.Day day21 = new org.jfree.data.time.Day(serialDate15);
        org.jfree.data.time.SerialDate serialDate24 = org.jfree.data.time.SerialDate.createInstance(9);
        serialDate24.setDescription("");
        java.lang.String str27 = serialDate24.getDescription();
        org.jfree.data.time.SerialDate serialDate29 = serialDate24.getFollowingDayOfWeek(1);
        org.jfree.data.time.SerialDate serialDate30 = org.jfree.data.time.SerialDate.addDays(0, serialDate24);
        boolean boolean32 = spreadsheetDate2.isInRange(serialDate15, serialDate30, 0);
        serialDate15.setDescription("");
        try {
            org.jfree.data.time.SerialDate serialDate35 = org.jfree.data.time.SerialDate.getFollowingDayOfWeek((int) (short) 100, serialDate15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid day-of-the-week code.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(serialDate5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(serialDate10);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(serialDate15);
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNotNull(serialDate20);
        org.junit.Assert.assertNotNull(serialDate24);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "" + "'", str27.equals(""));
        org.junit.Assert.assertNotNull(serialDate29);
        org.junit.Assert.assertNotNull(serialDate30);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries1.setDescription("");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month4);
        org.jfree.data.time.Year year6 = month4.getYear();
        long long7 = month4.getLastMillisecond();
        long long8 = month4.getLastMillisecond();
        java.lang.String str9 = month4.toString();
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 1561964399999L + "'", long7 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 1561964399999L + "'", long8 == 1561964399999L);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "June 2019" + "'", str9.equals("June 2019"));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
        int int2 = day0.getYear();
        org.jfree.data.time.SerialDate serialDate3 = day0.getSerialDate();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
        org.junit.Assert.assertNotNull(serialDate3);
    }

//    @Test
//    public void test29() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test29");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries1.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 12);
//        int int7 = timeSeries1.getItemCount();
//        org.jfree.data.time.SerialDate serialDate9 = org.jfree.data.time.SerialDate.createInstance(9);
//        serialDate9.setDescription("");
//        java.lang.String str12 = serialDate9.getDescription();
//        org.jfree.data.time.SerialDate serialDate14 = serialDate9.getFollowingDayOfWeek(1);
//        org.jfree.data.time.Day day15 = new org.jfree.data.time.Day(serialDate9);
//        int int16 = day15.getYear();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day15);
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
//        timeSeries1.addChangeListener(seriesChangeListener18);
//        java.lang.String str20 = timeSeries1.getDomainDescription();
//        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(9);
//        serialDate22.setDescription("");
//        java.lang.String str25 = serialDate22.getDescription();
//        org.jfree.data.time.SerialDate serialDate27 = serialDate22.getFollowingDayOfWeek(1);
//        org.jfree.data.time.Day day28 = new org.jfree.data.time.Day(serialDate22);
//        long long29 = day28.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) (byte) 10);
//        long long33 = fixedMillisecond30.getMiddleMillisecond();
//        java.util.Calendar calendar34 = null;
//        fixedMillisecond30.peg(calendar34);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod36 = fixedMillisecond30.previous();
//        int int37 = day28.compareTo((java.lang.Object) regularTimePeriod36);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod38 = day28.previous();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod39 = day28.next();
//        long long40 = day28.getLastMillisecond();
//        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) day28);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertNotNull(serialDate9);
//        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
//        org.junit.Assert.assertNotNull(serialDate14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1900 + "'", int16 == 1900);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "Time" + "'", str20.equals("Time"));
//        org.junit.Assert.assertNotNull(serialDate22);
//        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "" + "'", str25.equals(""));
//        org.junit.Assert.assertNotNull(serialDate27);
//        org.junit.Assert.assertTrue("'" + long29 + "' != '" + 9L + "'", long29 == 9L);
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560190826027L + "'", long33 == 1560190826027L);
//        org.junit.Assert.assertNotNull(regularTimePeriod36);
//        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod38);
//        org.junit.Assert.assertNotNull(regularTimePeriod39);
//        org.junit.Assert.assertTrue("'" + long40 + "' != '" + (-2208268800001L) + "'", long40 == (-2208268800001L));
//    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(4, 10);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries1.setDescription("");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month4);
        org.jfree.data.time.Year year6 = month4.getYear();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class10);
        timeSeries11.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        int int14 = timeSeries11.getMaximumItemCount();
        java.lang.Class class18 = null;
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class18);
        timeSeries19.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener22 = null;
        timeSeries19.addChangeListener(seriesChangeListener22);
        java.util.Collection collection24 = timeSeries11.getTimePeriodsUniqueToOtherSeries(timeSeries19);
        java.lang.Class class28 = null;
        org.jfree.data.time.TimeSeries timeSeries29 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class28);
        timeSeries29.setDomainDescription("hi!");
        org.jfree.data.time.Month month32 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem34 = timeSeries29.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month32, 0.0d);
        long long35 = month32.getFirstMillisecond();
        int int36 = timeSeries19.getIndex((org.jfree.data.time.RegularTimePeriod) month32);
        boolean boolean38 = month32.equals((java.lang.Object) (short) 10);
        int int40 = month32.compareTo((java.lang.Object) 100);
        int int41 = year6.compareTo((java.lang.Object) 100);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries46 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class45);
        timeSeries46.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries50.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries50.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (java.lang.Number) 12);
        boolean boolean56 = timeSeries46.equals((java.lang.Object) timeSeries50);
        java.util.Collection collection57 = timeSeries50.getTimePeriods();
        int int58 = year6.compareTo((java.lang.Object) timeSeries50);
        timeSeries50.removeAgedItems(1560193199999L, false);
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem63 = timeSeries50.getDataItem(4);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 4, Size: 1");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(year6);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2147483647 + "'", int14 == 2147483647);
        org.junit.Assert.assertNotNull(collection24);
        org.junit.Assert.assertNull(timeSeriesDataItem34);
        org.junit.Assert.assertTrue("'" + long35 + "' != '" + 1559372400000L + "'", long35 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1) + "'", int36 == (-1));
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 1 + "'", int40 == 1);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1 + "'", int41 == 1);
        org.junit.Assert.assertNull(timeSeriesDataItem55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(collection57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 1 + "'", int58 == 1);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9);
        serialDate1.setDescription("");
        java.lang.String str4 = serialDate1.getDescription();
        org.jfree.data.time.SerialDate serialDate6 = serialDate1.getFollowingDayOfWeek(1);
        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate1);
        java.lang.Class class11 = null;
        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class11);
        timeSeries12.setDomainDescription("hi!");
        org.jfree.data.time.Month month15 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem17 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month15, 0.0d);
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class21);
        timeSeries22.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        int int25 = timeSeries22.getMaximumItemCount();
        java.lang.Class class29 = null;
        org.jfree.data.time.TimeSeries timeSeries30 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class29);
        timeSeries30.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener33 = null;
        timeSeries30.addChangeListener(seriesChangeListener33);
        java.util.Collection collection35 = timeSeries22.getTimePeriodsUniqueToOtherSeries(timeSeries30);
        java.lang.Class class39 = null;
        org.jfree.data.time.TimeSeries timeSeries40 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class39);
        timeSeries40.setDomainDescription("hi!");
        org.jfree.data.time.Month month43 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem45 = timeSeries40.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month43, 0.0d);
        long long46 = month43.getFirstMillisecond();
        int int47 = timeSeries30.getIndex((org.jfree.data.time.RegularTimePeriod) month43);
        org.jfree.data.time.TimeSeries timeSeries49 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.String str50 = timeSeries49.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries51 = timeSeries30.addAndOrUpdate(timeSeries49);
        java.util.Collection collection52 = timeSeries12.getTimePeriodsUniqueToOtherSeries(timeSeries49);
        boolean boolean53 = day7.equals((java.lang.Object) timeSeries49);
        java.lang.String str54 = day7.toString();
        org.junit.Assert.assertNotNull(serialDate1);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(serialDate6);
        org.junit.Assert.assertNull(timeSeriesDataItem17);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 2147483647 + "'", int25 == 2147483647);
        org.junit.Assert.assertNotNull(collection35);
        org.junit.Assert.assertNull(timeSeriesDataItem45);
        org.junit.Assert.assertTrue("'" + long46 + "' != '" + 1559372400000L + "'", long46 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1) + "'", int47 == (-1));
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "Value" + "'", str50.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries51);
        org.junit.Assert.assertNotNull(collection52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "8-January-1900" + "'", str54.equals("8-January-1900"));
    }

//    @Test
//    public void test33() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test33");
//        java.lang.Class class0 = null;
//        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries2.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 12);
//        java.util.Calendar calendar8 = null;
//        fixedMillisecond5.peg(calendar8);
//        java.util.Date date10 = fixedMillisecond5.getEnd();
//        java.util.TimeZone timeZone11 = null;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date10, timeZone11);
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date10);
//        java.lang.Class class17 = null;
//        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class17);
//        timeSeries18.setDomainDescription("hi!");
//        timeSeries18.fireSeriesChanged();
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries23.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond26 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem28 = timeSeries23.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) 12);
//        java.util.Calendar calendar29 = null;
//        fixedMillisecond26.peg(calendar29);
//        java.util.Date date31 = fixedMillisecond26.getEnd();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem33 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond26, (java.lang.Number) (-1.0f));
//        long long34 = fixedMillisecond26.getMiddleMillisecond();
//        java.util.Date date35 = fixedMillisecond26.getTime();
//        java.lang.Class class36 = null;
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries38.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond41 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem43 = timeSeries38.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond41, (java.lang.Number) 12);
//        java.util.Calendar calendar44 = null;
//        fixedMillisecond41.peg(calendar44);
//        java.util.Date date46 = fixedMillisecond41.getEnd();
//        java.util.TimeZone timeZone47 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod48 = org.jfree.data.time.RegularTimePeriod.createInstance(class36, date46, timeZone47);
//        org.jfree.data.time.Year year49 = new org.jfree.data.time.Year(date35, timeZone47);
//        org.jfree.data.time.Year year50 = new org.jfree.data.time.Year(date10, timeZone47);
//        long long51 = year50.getSerialIndex();
//        org.junit.Assert.assertNull(timeSeriesDataItem7);
//        org.junit.Assert.assertNotNull(date10);
//        org.junit.Assert.assertNull(regularTimePeriod12);
//        org.junit.Assert.assertNull(timeSeriesDataItem28);
//        org.junit.Assert.assertNotNull(date31);
//        org.junit.Assert.assertNull(timeSeriesDataItem33);
//        org.junit.Assert.assertTrue("'" + long34 + "' != '" + 1560190826214L + "'", long34 == 1560190826214L);
//        org.junit.Assert.assertNotNull(date35);
//        org.junit.Assert.assertNull(timeSeriesDataItem43);
//        org.junit.Assert.assertNotNull(date46);
//        org.junit.Assert.assertNotNull(timeZone47);
//        org.junit.Assert.assertNull(regularTimePeriod48);
//        org.junit.Assert.assertTrue("'" + long51 + "' != '" + 2019L + "'", long51 == 2019L);
//    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        java.lang.Class class0 = null;
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries2.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 12);
        java.util.Calendar calendar8 = null;
        fixedMillisecond5.peg(calendar8);
        java.util.Date date10 = fixedMillisecond5.getEnd();
        java.util.TimeZone timeZone11 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = org.jfree.data.time.RegularTimePeriod.createInstance(class0, date10, timeZone11);
        org.jfree.data.time.Month month13 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod14 = month13.next();
        org.jfree.data.time.Year year15 = month13.getYear();
        long long16 = month13.getSerialIndex();
        long long17 = month13.getFirstMillisecond();
        long long18 = month13.getLastMillisecond();
        java.util.Calendar calendar19 = null;
        try {
            long long20 = month13.getFirstMillisecond(calendar19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertNotNull(timeZone11);
        org.junit.Assert.assertNull(regularTimePeriod12);
        org.junit.Assert.assertNotNull(regularTimePeriod14);
        org.junit.Assert.assertNotNull(year15);
        org.junit.Assert.assertTrue("'" + long16 + "' != '" + 24234L + "'", long16 == 24234L);
        org.junit.Assert.assertTrue("'" + long17 + "' != '" + 1559372400000L + "'", long17 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + long18 + "' != '" + 1561964399999L + "'", long18 == 1561964399999L);
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class3);
        timeSeries4.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries8.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 12);
        boolean boolean14 = timeSeries4.equals((java.lang.Object) timeSeries8);
        timeSeries4.clear();
        timeSeries4.setNotify(false);
        org.jfree.data.general.SeriesChangeListener seriesChangeListener18 = null;
        timeSeries4.removeChangeListener(seriesChangeListener18);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        try {
            java.lang.String str1 = org.jfree.data.time.SerialDate.monthCodeToString(30);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        org.jfree.data.time.Month month2 = new org.jfree.data.time.Month(3, 43617);
        try {
            org.jfree.data.time.Year year3 = month2.getYear();
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Year constructor: year (43617) outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        try {
            org.jfree.data.time.SpreadsheetDate spreadsheetDate3 = new org.jfree.data.time.SpreadsheetDate((-1895), (-435), (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'year' argument must be in range 1900 to 9999.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class3);
        timeSeries4.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries8.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 12);
        boolean boolean14 = timeSeries4.equals((java.lang.Object) timeSeries8);
        boolean boolean15 = timeSeries4.getNotify();
        timeSeries4.removeAgedItems(true);
        timeSeries4.setDomainDescription("14-January-1900");
        java.beans.PropertyChangeListener propertyChangeListener20 = null;
        timeSeries4.removePropertyChangeListener(propertyChangeListener20);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        boolean boolean2 = timeSeries1.isEmpty();
        timeSeries1.setMaximumItemAge((long) 6);
        java.lang.String str5 = timeSeries1.getDomainDescription();
        java.beans.PropertyChangeListener propertyChangeListener6 = null;
        timeSeries1.removePropertyChangeListener(propertyChangeListener6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "Time" + "'", str5.equals("Time"));
    }

//    @Test
//    public void test41() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test41");
//        org.jfree.data.time.SerialDate serialDate1 = org.jfree.data.time.SerialDate.createInstance(9);
//        serialDate1.setDescription("");
//        java.lang.String str4 = serialDate1.getDescription();
//        org.jfree.data.time.SerialDate serialDate6 = serialDate1.getFollowingDayOfWeek(1);
//        org.jfree.data.time.Day day7 = new org.jfree.data.time.Day(serialDate1);
//        long long8 = day7.getSerialIndex();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond9 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond9, (java.lang.Number) (byte) 10);
//        long long12 = fixedMillisecond9.getMiddleMillisecond();
//        java.util.Calendar calendar13 = null;
//        fixedMillisecond9.peg(calendar13);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = fixedMillisecond9.previous();
//        int int16 = day7.compareTo((java.lang.Object) regularTimePeriod15);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod17 = day7.previous();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem19 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day7, (java.lang.Number) 1560190743567L);
//        org.jfree.data.time.SerialDate serialDate20 = day7.getSerialDate();
//        org.junit.Assert.assertNotNull(serialDate1);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
//        org.junit.Assert.assertNotNull(serialDate6);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 9L + "'", long8 == 9L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 1560190826408L + "'", long12 == 1560190826408L);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//        org.junit.Assert.assertNotNull(regularTimePeriod17);
//        org.junit.Assert.assertNotNull(serialDate20);
//    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries1.setDescription("");
        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month();
        timeSeries1.delete((org.jfree.data.time.RegularTimePeriod) month4);
        java.lang.String str6 = timeSeries1.getRangeDescription();
        java.lang.Class class10 = null;
        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class10);
        timeSeries11.setDomainDescription("hi!");
        timeSeries11.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries16 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries16.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond19 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries16.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) 12);
        java.util.Calendar calendar22 = null;
        fixedMillisecond19.peg(calendar22);
        java.util.Date date24 = fixedMillisecond19.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem26 = timeSeries11.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (java.lang.Number) (-1.0f));
        org.jfree.data.time.FixedMillisecond fixedMillisecond27 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond27, (java.lang.Number) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries30 = timeSeries1.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond19, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond27);
        java.lang.Comparable comparable31 = timeSeries30.getKey();
        java.lang.Class class32 = null;
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries34.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (java.lang.Number) 12);
        java.util.Calendar calendar40 = null;
        fixedMillisecond37.peg(calendar40);
        java.util.Date date42 = fixedMillisecond37.getEnd();
        java.util.TimeZone timeZone43 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date42, timeZone43);
        org.jfree.data.time.Month month45 = new org.jfree.data.time.Month(date42);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(date42);
        org.jfree.data.time.Day day47 = new org.jfree.data.time.Day(date42);
        java.lang.Class class48 = null;
        org.jfree.data.time.TimeSeries timeSeries50 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries50.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem55 = timeSeries50.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond53, (java.lang.Number) 12);
        java.util.Calendar calendar56 = null;
        fixedMillisecond53.peg(calendar56);
        java.util.Date date58 = fixedMillisecond53.getEnd();
        java.util.TimeZone timeZone59 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod60 = org.jfree.data.time.RegularTimePeriod.createInstance(class48, date58, timeZone59);
        org.jfree.data.time.Month month61 = new org.jfree.data.time.Month(date58);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod62 = month61.next();
        org.jfree.data.time.Year year63 = month61.getYear();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod64 = month61.next();
        java.util.Date date65 = month61.getStart();
        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.Month month67 = new org.jfree.data.time.Month(date65, timeZone66);
        org.jfree.data.time.Day day68 = new org.jfree.data.time.Day(date42, timeZone66);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem70 = timeSeries30.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day68, (java.lang.Number) 1560190742982L);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "Value" + "'", str6.equals("Value"));
        org.junit.Assert.assertNull(timeSeriesDataItem21);
        org.junit.Assert.assertNotNull(date24);
        org.junit.Assert.assertNull(timeSeriesDataItem26);
        org.junit.Assert.assertNotNull(timeSeries30);
        org.junit.Assert.assertTrue("'" + comparable31 + "' != '" + (short) 0 + "'", comparable31.equals((short) 0));
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNotNull(timeZone43);
        org.junit.Assert.assertNull(regularTimePeriod44);
        org.junit.Assert.assertNull(timeSeriesDataItem55);
        org.junit.Assert.assertNotNull(date58);
        org.junit.Assert.assertNotNull(timeZone59);
        org.junit.Assert.assertNull(regularTimePeriod60);
        org.junit.Assert.assertNotNull(regularTimePeriod62);
        org.junit.Assert.assertNotNull(year63);
        org.junit.Assert.assertNotNull(regularTimePeriod64);
        org.junit.Assert.assertNotNull(date65);
        org.junit.Assert.assertNotNull(timeZone66);
        org.junit.Assert.assertNull(timeSeriesDataItem70);
    }

//    @Test
//    public void test43() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test43");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
//        int int2 = day0.getYear();
//        long long3 = day0.getSerialIndex();
//        org.jfree.data.time.SerialDate serialDate4 = day0.getSerialDate();
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2019 + "'", int2 == 2019);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 43626L + "'", long3 == 43626L);
//        org.junit.Assert.assertNotNull(serialDate4);
//    }

//    @Test
//    public void test44() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test44");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries1.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 12);
//        java.lang.Comparable comparable7 = timeSeries1.getKey();
//        org.jfree.data.time.Month month10 = new org.jfree.data.time.Month(8, 9);
//        org.jfree.data.time.Day day11 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod12 = day11.next();
//        int int13 = day11.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem15 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day11, (java.lang.Number) 1);
//        java.lang.Object obj16 = null;
//        int int17 = day11.compareTo(obj16);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = day11.next();
//        int int19 = month10.compareTo((java.lang.Object) regularTimePeriod18);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem21 = timeSeries1.addOrUpdate(regularTimePeriod18, (double) 1560190735483L);
//        org.jfree.data.time.TimeSeries timeSeries23 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries23.setDescription("");
//        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month();
//        timeSeries23.delete((org.jfree.data.time.RegularTimePeriod) month26);
//        org.jfree.data.time.Year year28 = month26.getYear();
//        java.lang.Class class32 = null;
//        org.jfree.data.time.TimeSeries timeSeries33 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class32);
//        timeSeries33.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        int int36 = timeSeries33.getMaximumItemCount();
//        java.lang.Class class40 = null;
//        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class40);
//        timeSeries41.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener44 = null;
//        timeSeries41.addChangeListener(seriesChangeListener44);
//        java.util.Collection collection46 = timeSeries33.getTimePeriodsUniqueToOtherSeries(timeSeries41);
//        java.lang.Class class50 = null;
//        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class50);
//        timeSeries51.setDomainDescription("hi!");
//        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem56 = timeSeries51.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month54, 0.0d);
//        long long57 = month54.getFirstMillisecond();
//        int int58 = timeSeries41.getIndex((org.jfree.data.time.RegularTimePeriod) month54);
//        boolean boolean60 = month54.equals((java.lang.Object) (short) 10);
//        int int62 = month54.compareTo((java.lang.Object) 100);
//        int int63 = year28.compareTo((java.lang.Object) 100);
//        java.lang.Class class67 = null;
//        org.jfree.data.time.TimeSeries timeSeries68 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class67);
//        timeSeries68.setDomainDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries72 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries72.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond75 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem77 = timeSeries72.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond75, (java.lang.Number) 12);
//        boolean boolean78 = timeSeries68.equals((java.lang.Object) timeSeries72);
//        java.util.Collection collection79 = timeSeries72.getTimePeriods();
//        int int80 = year28.compareTo((java.lang.Object) timeSeries72);
//        java.util.Collection collection81 = timeSeries1.getTimePeriodsUniqueToOtherSeries(timeSeries72);
//        org.jfree.data.time.TimeSeries timeSeries83 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries83.setDescription("");
//        org.jfree.data.time.Month month86 = new org.jfree.data.time.Month();
//        timeSeries83.delete((org.jfree.data.time.RegularTimePeriod) month86);
//        org.jfree.data.time.Year year88 = month86.getYear();
//        long long89 = year88.getFirstMillisecond();
//        boolean boolean90 = timeSeries72.equals((java.lang.Object) long89);
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertTrue("'" + comparable7 + "' != '" + (short) 0 + "'", comparable7.equals((short) 0));
//        org.junit.Assert.assertNotNull(regularTimePeriod12);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod18);
//        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
//        org.junit.Assert.assertNotNull(timeSeriesDataItem21);
//        org.junit.Assert.assertNotNull(year28);
//        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 2147483647 + "'", int36 == 2147483647);
//        org.junit.Assert.assertNotNull(collection46);
//        org.junit.Assert.assertNull(timeSeriesDataItem56);
//        org.junit.Assert.assertTrue("'" + long57 + "' != '" + 1559372400000L + "'", long57 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-1) + "'", int58 == (-1));
//        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
//        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 1 + "'", int62 == 1);
//        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 1 + "'", int63 == 1);
//        org.junit.Assert.assertNull(timeSeriesDataItem77);
//        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
//        org.junit.Assert.assertNotNull(collection79);
//        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 1 + "'", int80 == 1);
//        org.junit.Assert.assertNotNull(collection81);
//        org.junit.Assert.assertNotNull(year88);
//        org.junit.Assert.assertTrue("'" + long89 + "' != '" + 1546329600000L + "'", long89 == 1546329600000L);
//        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
//    }

//    @Test
//    public void test45() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test45");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class3);
//        timeSeries4.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        timeSeries4.setRangeDescription("SerialDate.weekInMonthToString(): invalid code.");
//        java.lang.Class class9 = timeSeries4.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries11 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries11.setDescription("");
//        org.jfree.data.time.Day day14 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod15 = day14.next();
//        int int16 = day14.getDayOfMonth();
//        java.util.Date date17 = day14.getEnd();
//        timeSeries11.add((org.jfree.data.time.RegularTimePeriod) day14, (java.lang.Number) 13, true);
//        long long21 = day14.getSerialIndex();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries4.getDataItem((org.jfree.data.time.RegularTimePeriod) day14);
//        org.jfree.data.time.Day day23 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod24 = day23.next();
//        int int25 = day23.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) 1);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem29 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day23, (double) 43617);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) day23, (java.lang.Number) (-2208700800000L));
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod32 = day23.next();
//        org.junit.Assert.assertNull(class9);
//        org.junit.Assert.assertNotNull(regularTimePeriod15);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 10 + "'", int16 == 10);
//        org.junit.Assert.assertNotNull(date17);
//        org.junit.Assert.assertTrue("'" + long21 + "' != '" + 43626L + "'", long21 == 43626L);
//        org.junit.Assert.assertNull(timeSeriesDataItem22);
//        org.junit.Assert.assertNotNull(regularTimePeriod24);
//        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 10 + "'", int25 == 10);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNotNull(regularTimePeriod32);
//    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        try {
            java.lang.String str2 = org.jfree.data.time.SerialDate.monthCodeToString((-451), true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: SerialDate.monthCodeToString: month outside valid range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class3);
        timeSeries4.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        timeSeries4.setRangeDescription("Second");
        org.jfree.data.time.RegularTimePeriod regularTimePeriod9 = null;
        try {
            org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem11 = timeSeries4.addOrUpdate(regularTimePeriod9, (java.lang.Number) 1560190788338L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries1.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 12);
        int int7 = timeSeries1.getItemCount();
        int int8 = timeSeries1.getMaximumItemCount();
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 2147483647 + "'", int8 == 2147483647);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        org.jfree.data.time.TimeSeries timeSeries2 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries2.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond5 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem7 = timeSeries2.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond5, (java.lang.Number) 12);
        java.util.Calendar calendar8 = null;
        fixedMillisecond5.peg(calendar8);
        java.util.Date date10 = fixedMillisecond5.getTime();
        org.jfree.data.time.Month month11 = new org.jfree.data.time.Month(date10);
        org.jfree.data.time.TimeSeries timeSeries13 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        boolean boolean14 = timeSeries13.isEmpty();
        timeSeries13.setMaximumItemAge((long) 6);
        java.lang.Class class17 = timeSeries13.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries19 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries19.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond22 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem24 = timeSeries19.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond22, (java.lang.Number) 12);
        java.util.Calendar calendar25 = null;
        fixedMillisecond22.peg(calendar25);
        java.util.Date date27 = fixedMillisecond22.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond28 = new org.jfree.data.time.FixedMillisecond(date27);
        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond(date27);
        java.lang.Class class30 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries32.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (java.lang.Number) 12);
        java.util.Calendar calendar38 = null;
        fixedMillisecond35.peg(calendar38);
        java.util.Date date40 = fixedMillisecond35.getEnd();
        java.util.TimeZone timeZone41 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod42 = org.jfree.data.time.RegularTimePeriod.createInstance(class30, date40, timeZone41);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod43 = org.jfree.data.time.RegularTimePeriod.createInstance(class17, date27, timeZone41);
        org.jfree.data.time.Day day44 = new org.jfree.data.time.Day(date10, timeZone41);
        org.jfree.data.time.Year year45 = new org.jfree.data.time.Year(date10);
        org.jfree.data.time.Month month46 = new org.jfree.data.time.Month(12, year45);
        int int47 = year45.getYear();
        org.junit.Assert.assertNull(timeSeriesDataItem7);
        org.junit.Assert.assertNotNull(date10);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(class17);
        org.junit.Assert.assertNull(timeSeriesDataItem24);
        org.junit.Assert.assertNotNull(date27);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertNotNull(date40);
        org.junit.Assert.assertNotNull(timeZone41);
        org.junit.Assert.assertNull(regularTimePeriod42);
        org.junit.Assert.assertNotNull(regularTimePeriod43);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2019 + "'", int47 == 2019);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate2 = new org.jfree.data.time.SpreadsheetDate(5);
        java.lang.String str3 = spreadsheetDate2.getDescription();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.addMonths(11, (org.jfree.data.time.SerialDate) spreadsheetDate2);
        int int5 = spreadsheetDate2.getMonth();
        int int6 = spreadsheetDate2.toSerial();
        org.jfree.data.time.SpreadsheetDate spreadsheetDate8 = new org.jfree.data.time.SpreadsheetDate(5);
        org.jfree.data.time.SpreadsheetDate spreadsheetDate10 = new org.jfree.data.time.SpreadsheetDate(5);
        java.lang.String str11 = spreadsheetDate10.getDescription();
        int int12 = spreadsheetDate10.getYYYY();
        org.jfree.data.time.SerialDate serialDate14 = org.jfree.data.time.SerialDate.createInstance(9);
        serialDate14.setDescription("");
        java.lang.String str17 = serialDate14.getDescription();
        org.jfree.data.time.SerialDate serialDate19 = serialDate14.getFollowingDayOfWeek(1);
        serialDate14.setDescription("Second");
        boolean boolean23 = spreadsheetDate8.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate10, serialDate14, (int) (short) -1);
        boolean boolean24 = spreadsheetDate2.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate8);
        org.junit.Assert.assertNull(str3);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 5 + "'", int6 == 5);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1900 + "'", int12 == 1900);
        org.junit.Assert.assertNotNull(serialDate14);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertNotNull(serialDate19);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
    }

//    @Test
//    public void test51() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test51");
//        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries1.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 12);
//        java.util.Calendar calendar7 = null;
//        fixedMillisecond4.peg(calendar7);
//        java.util.Date date9 = fixedMillisecond4.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond10 = new org.jfree.data.time.FixedMillisecond(date9);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod11 = fixedMillisecond10.next();
//        java.util.Date date12 = fixedMillisecond10.getTime();
//        org.jfree.data.time.Year year13 = new org.jfree.data.time.Year(date12);
//        org.jfree.data.time.TimeSeries timeSeries15 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        boolean boolean16 = timeSeries15.isEmpty();
//        timeSeries15.setMaximumItemAge((long) 6);
//        java.lang.Class class19 = timeSeries15.getTimePeriodClass();
//        java.lang.Class class23 = null;
//        org.jfree.data.time.TimeSeries timeSeries24 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class23);
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries26.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) 12);
//        java.util.Calendar calendar32 = null;
//        fixedMillisecond29.peg(calendar32);
//        java.util.Date date34 = fixedMillisecond29.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond(date34);
//        boolean boolean36 = timeSeries24.equals((java.lang.Object) date34);
//        org.jfree.data.time.TimeSeries timeSeries38 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        boolean boolean39 = timeSeries38.isEmpty();
//        timeSeries38.setMaximumItemAge((long) 6);
//        java.lang.Class class42 = timeSeries38.getTimePeriodClass();
//        org.jfree.data.time.TimeSeries timeSeries44 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries44.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond47 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem49 = timeSeries44.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond47, (java.lang.Number) 12);
//        java.util.Calendar calendar50 = null;
//        fixedMillisecond47.peg(calendar50);
//        java.util.Date date52 = fixedMillisecond47.getEnd();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond53 = new org.jfree.data.time.FixedMillisecond(date52);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond54 = new org.jfree.data.time.FixedMillisecond(date52);
//        java.lang.Class class55 = null;
//        org.jfree.data.time.TimeSeries timeSeries57 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries57.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond60 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem62 = timeSeries57.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond60, (java.lang.Number) 12);
//        java.util.Calendar calendar63 = null;
//        fixedMillisecond60.peg(calendar63);
//        java.util.Date date65 = fixedMillisecond60.getEnd();
//        java.util.TimeZone timeZone66 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod67 = org.jfree.data.time.RegularTimePeriod.createInstance(class55, date65, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod68 = org.jfree.data.time.RegularTimePeriod.createInstance(class42, date52, timeZone66);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod69 = org.jfree.data.time.RegularTimePeriod.createInstance(class19, date34, timeZone66);
//        org.jfree.data.time.Day day70 = new org.jfree.data.time.Day(date12, timeZone66);
//        long long71 = day70.getLastMillisecond();
//        org.junit.Assert.assertNull(timeSeriesDataItem6);
//        org.junit.Assert.assertNotNull(date9);
//        org.junit.Assert.assertNotNull(regularTimePeriod11);
//        org.junit.Assert.assertNotNull(date12);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
//        org.junit.Assert.assertNotNull(class19);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNotNull(date34);
//        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
//        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
//        org.junit.Assert.assertNotNull(class42);
//        org.junit.Assert.assertNull(timeSeriesDataItem49);
//        org.junit.Assert.assertNotNull(date52);
//        org.junit.Assert.assertNull(timeSeriesDataItem62);
//        org.junit.Assert.assertNotNull(date65);
//        org.junit.Assert.assertNotNull(timeZone66);
//        org.junit.Assert.assertNull(regularTimePeriod67);
//        org.junit.Assert.assertNotNull(regularTimePeriod68);
//        org.junit.Assert.assertNotNull(regularTimePeriod69);
//        org.junit.Assert.assertTrue("'" + long71 + "' != '" + 1560236399999L + "'", long71 == 1560236399999L);
//    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test52");
        org.jfree.data.general.SeriesException seriesException1 = new org.jfree.data.general.SeriesException("hi!");
        java.lang.Throwable[] throwableArray2 = seriesException1.getSuppressed();
        java.lang.Throwable[] throwableArray3 = seriesException1.getSuppressed();
        java.lang.String str4 = seriesException1.toString();
        org.junit.Assert.assertNotNull(throwableArray2);
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.jfree.data.general.SeriesException: hi!" + "'", str4.equals("org.jfree.data.general.SeriesException: hi!"));
    }

//    @Test
//    public void test53() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test53");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class3);
//        timeSeries4.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        int int7 = timeSeries4.getMaximumItemCount();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class11);
//        timeSeries12.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries12.addChangeListener(seriesChangeListener15);
//        java.util.Collection collection17 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        java.lang.Object obj18 = timeSeries12.clone();
//        java.lang.Comparable comparable19 = timeSeries12.getKey();
//        org.jfree.data.time.Year year21 = new org.jfree.data.time.Year(2019);
//        int int23 = year21.compareTo((java.lang.Object) "Mon Jun 10 11:18:58 PDT 2019");
//        long long24 = year21.getSerialIndex();
//        org.jfree.data.time.TimeSeries timeSeries26 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries26.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond29 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem31 = timeSeries26.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond29, (java.lang.Number) 12);
//        java.util.Calendar calendar32 = null;
//        fixedMillisecond29.peg(calendar32);
//        org.jfree.data.time.TimeSeries timeSeries34 = timeSeries12.createCopy((org.jfree.data.time.RegularTimePeriod) year21, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond29);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond35 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (java.lang.Number) (byte) 10);
//        java.util.Calendar calendar38 = null;
//        long long39 = fixedMillisecond35.getLastMillisecond(calendar38);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem41 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond35, (double) (byte) 100);
//        java.lang.Object obj42 = null;
//        int int43 = timeSeriesDataItem41.compareTo(obj42);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod44 = timeSeriesDataItem41.getPeriod();
//        try {
//            timeSeries12.add(regularTimePeriod44, (java.lang.Number) 1560190743567L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertTrue("'" + comparable19 + "' != '" + '4' + "'", comparable19.equals('4'));
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
//        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 2019L + "'", long24 == 2019L);
//        org.junit.Assert.assertNull(timeSeriesDataItem31);
//        org.junit.Assert.assertNotNull(timeSeries34);
//        org.junit.Assert.assertTrue("'" + long39 + "' != '" + 1560190827611L + "'", long39 == 1560190827611L);
//        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1 + "'", int43 == 1);
//        org.junit.Assert.assertNotNull(regularTimePeriod44);
//    }

//    @Test
//    public void test54() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test54");
//        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod1 = day0.next();
//        int int2 = day0.getDayOfMonth();
//        java.util.Date date3 = day0.getEnd();
//        org.jfree.data.time.Month month4 = new org.jfree.data.time.Month(date3);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) month4, (java.lang.Number) 1560190823151L);
//        org.junit.Assert.assertNotNull(regularTimePeriod1);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
//        org.junit.Assert.assertNotNull(date3);
//    }

//    @Test
//    public void test55() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test55");
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(5);
//        java.lang.String str2 = spreadsheetDate1.getDescription();
//        int int3 = spreadsheetDate1.getYYYY();
//        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) (byte) 10);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond7 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (java.lang.Number) (byte) 10);
//        java.util.Calendar calendar10 = null;
//        long long11 = fixedMillisecond7.getLastMillisecond(calendar10);
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond7, (double) (byte) 100);
//        boolean boolean14 = timeSeriesDataItem6.equals((java.lang.Object) fixedMillisecond7);
//        long long15 = fixedMillisecond7.getMiddleMillisecond();
//        boolean boolean16 = spreadsheetDate1.equals((java.lang.Object) long15);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(5);
//        java.lang.String str19 = spreadsheetDate18.getDescription();
//        int int20 = spreadsheetDate18.getYYYY();
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate22 = new org.jfree.data.time.SpreadsheetDate(5);
//        boolean boolean23 = spreadsheetDate18.isOnOrAfter((org.jfree.data.time.SerialDate) spreadsheetDate22);
//        boolean boolean24 = spreadsheetDate1.isOnOrBefore((org.jfree.data.time.SerialDate) spreadsheetDate18);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate27 = new org.jfree.data.time.SpreadsheetDate(5);
//        java.lang.String str28 = spreadsheetDate27.getDescription();
//        org.jfree.data.time.SerialDate serialDate29 = org.jfree.data.time.SerialDate.addMonths(11, (org.jfree.data.time.SerialDate) spreadsheetDate27);
//        int int30 = spreadsheetDate27.getYYYY();
//        org.jfree.data.time.SerialDate serialDate33 = org.jfree.data.time.SerialDate.createInstance(9);
//        serialDate33.setDescription("");
//        org.jfree.data.time.Day day36 = new org.jfree.data.time.Day(serialDate33);
//        org.jfree.data.time.SerialDate serialDate37 = org.jfree.data.time.SerialDate.getNearestDayOfWeek(5, serialDate33);
//        org.jfree.data.time.SpreadsheetDate spreadsheetDate39 = new org.jfree.data.time.SpreadsheetDate(5);
//        java.lang.String str40 = spreadsheetDate39.getDescription();
//        int int41 = spreadsheetDate39.getYYYY();
//        int int42 = spreadsheetDate39.getYYYY();
//        org.jfree.data.time.Day day43 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate39);
//        boolean boolean44 = spreadsheetDate27.isInRange(serialDate33, (org.jfree.data.time.SerialDate) spreadsheetDate39);
//        org.jfree.data.time.SerialDate serialDate46 = org.jfree.data.time.SerialDate.createInstance(9);
//        serialDate46.setDescription("");
//        java.lang.String str49 = serialDate46.getDescription();
//        org.jfree.data.time.SerialDate serialDate52 = org.jfree.data.time.SerialDate.createInstance(9);
//        serialDate52.setDescription("");
//        java.lang.String str55 = serialDate52.getDescription();
//        org.jfree.data.time.SerialDate serialDate57 = serialDate52.getFollowingDayOfWeek(1);
//        org.jfree.data.time.SerialDate serialDate58 = org.jfree.data.time.SerialDate.addDays(0, serialDate52);
//        boolean boolean59 = spreadsheetDate27.isInRange(serialDate46, serialDate52);
//        org.jfree.data.time.SerialDate serialDate60 = spreadsheetDate1.getEndOfCurrentMonth(serialDate52);
//        org.junit.Assert.assertNull(str2);
//        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 1560190827640L + "'", long11 == 1560190827640L);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1560190827640L + "'", long15 == 1560190827640L);
//        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
//        org.junit.Assert.assertNull(str19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1900 + "'", int20 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
//        org.junit.Assert.assertNull(str28);
//        org.junit.Assert.assertNotNull(serialDate29);
//        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 1900 + "'", int30 == 1900);
//        org.junit.Assert.assertNotNull(serialDate33);
//        org.junit.Assert.assertNotNull(serialDate37);
//        org.junit.Assert.assertNull(str40);
//        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1900 + "'", int41 == 1900);
//        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 1900 + "'", int42 == 1900);
//        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
//        org.junit.Assert.assertNotNull(serialDate46);
//        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "" + "'", str49.equals(""));
//        org.junit.Assert.assertNotNull(serialDate52);
//        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "" + "'", str55.equals(""));
//        org.junit.Assert.assertNotNull(serialDate57);
//        org.junit.Assert.assertNotNull(serialDate58);
//        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
//        org.junit.Assert.assertNotNull(serialDate60);
//    }

//    @Test
//    public void test56() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test56");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class3);
//        timeSeries4.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        int int7 = timeSeries4.getMaximumItemCount();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class11);
//        timeSeries12.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries12.addChangeListener(seriesChangeListener15);
//        java.util.Collection collection17 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        java.lang.Class class21 = null;
//        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class21);
//        timeSeries22.setDomainDescription("hi!");
//        org.jfree.data.time.Month month25 = new org.jfree.data.time.Month();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem27 = timeSeries22.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month25, 0.0d);
//        long long28 = month25.getFirstMillisecond();
//        int int29 = timeSeries12.getIndex((org.jfree.data.time.RegularTimePeriod) month25);
//        org.jfree.data.time.FixedMillisecond fixedMillisecond30 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem32 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) (byte) 10);
//        long long33 = fixedMillisecond30.getMiddleMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem35 = timeSeries12.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond30, (java.lang.Number) 1560190738578L);
//        java.util.Date date36 = fixedMillisecond30.getTime();
//        long long37 = fixedMillisecond30.getMiddleMillisecond();
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNull(timeSeriesDataItem27);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1559372400000L + "'", long28 == 1559372400000L);
//        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1) + "'", int29 == (-1));
//        org.junit.Assert.assertTrue("'" + long33 + "' != '" + 1560190827889L + "'", long33 == 1560190827889L);
//        org.junit.Assert.assertNull(timeSeriesDataItem35);
//        org.junit.Assert.assertNotNull(date36);
//        org.junit.Assert.assertTrue("'" + long37 + "' != '" + 1560190827889L + "'", long37 == 1560190827889L);
//    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        boolean boolean2 = timeSeries1.isEmpty();
        timeSeries1.setMaximumItemAge((long) 6);
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent6 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day5);
        int int7 = day5.getMonth();
        java.lang.Object obj8 = null;
        int int9 = day5.compareTo(obj8);
        boolean boolean10 = timeSeries1.equals((java.lang.Object) day5);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 6 + "'", int7 == 6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.jfree.data.time.Day day0 = new org.jfree.data.time.Day();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent1 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day0);
        int int2 = day0.getMonth();
        java.lang.Object obj3 = null;
        int int4 = day0.compareTo(obj3);
        java.util.Calendar calendar5 = null;
        try {
            long long6 = day0.getFirstMillisecond(calendar5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1 + "'", int4 == 1);
    }

//    @Test
//    public void test59() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test59");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class3);
//        timeSeries4.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        int int7 = timeSeries4.getMaximumItemCount();
//        org.jfree.data.time.Day day8 = new org.jfree.data.time.Day();
//        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent9 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day8);
//        org.jfree.data.time.SerialDate serialDate10 = day8.getSerialDate();
//        long long11 = day8.getSerialIndex();
//        int int12 = timeSeries4.getIndex((org.jfree.data.time.RegularTimePeriod) day8);
//        java.util.Date date13 = day8.getEnd();
//        int int14 = day8.getYear();
//        java.util.Calendar calendar15 = null;
//        try {
//            long long16 = day8.getFirstMillisecond(calendar15);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertNotNull(serialDate10);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 43626L + "'", long11 == 43626L);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1) + "'", int12 == (-1));
//        org.junit.Assert.assertNotNull(date13);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2019 + "'", int14 == 2019);
//    }

//    @Test
//    public void test60() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test60");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class3);
//        timeSeries4.setDomainDescription("hi!");
//        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries8.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 12);
//        boolean boolean14 = timeSeries4.equals((java.lang.Object) timeSeries8);
//        boolean boolean15 = timeSeries4.getNotify();
//        timeSeries4.removeAgedItems(true);
//        org.jfree.data.time.Day day18 = new org.jfree.data.time.Day();
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod19 = day18.next();
//        int int20 = day18.getDayOfMonth();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) day18, (java.lang.Number) 1);
//        org.jfree.data.time.RegularTimePeriod regularTimePeriod23 = day18.next();
//        try {
//            timeSeries4.add(regularTimePeriod23, (double) 1560190734327L);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNull(timeSeriesDataItem13);
//        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
//        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
//        org.junit.Assert.assertNotNull(regularTimePeriod19);
//        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 10 + "'", int20 == 10);
//        org.junit.Assert.assertNotNull(regularTimePeriod23);
//    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        org.jfree.data.time.Year year0 = new org.jfree.data.time.Year();
        boolean boolean2 = year0.equals((java.lang.Object) 1559372400000L);
        long long3 = year0.getLastMillisecond();
        long long4 = year0.getFirstMillisecond();
        int int5 = year0.getYear();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1577865599999L + "'", long3 == 1577865599999L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1546329600000L + "'", long4 == 1546329600000L);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2019 + "'", int5 == 2019);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        org.jfree.data.time.TimePeriodFormatException timePeriodFormatException1 = new org.jfree.data.time.TimePeriodFormatException("hi!");
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries1.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond4 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem6 = timeSeries1.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond4, (java.lang.Number) 12);
        int int7 = timeSeries1.getItemCount();
        java.lang.Comparable comparable8 = timeSeries1.getKey();
        java.lang.Object obj9 = timeSeries1.clone();
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class13);
        timeSeries14.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries18 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries18.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond21 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem23 = timeSeries18.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond21, (java.lang.Number) 12);
        boolean boolean24 = timeSeries14.equals((java.lang.Object) timeSeries18);
        timeSeries14.clear();
        org.jfree.data.time.Day day26 = new org.jfree.data.time.Day();
        org.jfree.data.general.SeriesChangeEvent seriesChangeEvent27 = new org.jfree.data.general.SeriesChangeEvent((java.lang.Object) day26);
        org.jfree.data.time.Month month28 = new org.jfree.data.time.Month();
        int int29 = day26.compareTo((java.lang.Object) month28);
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem30 = timeSeries14.getDataItem((org.jfree.data.time.RegularTimePeriod) day26);
        java.beans.PropertyChangeListener propertyChangeListener31 = null;
        timeSeries14.addPropertyChangeListener(propertyChangeListener31);
        org.jfree.data.time.TimeSeries timeSeries33 = timeSeries1.addAndOrUpdate(timeSeries14);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod34 = null;
        try {
            timeSeries33.add(regularTimePeriod34, 0.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'period' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertTrue("'" + comparable8 + "' != '" + (short) 0 + "'", comparable8.equals((short) 0));
        org.junit.Assert.assertNotNull(obj9);
        org.junit.Assert.assertNull(timeSeriesDataItem23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNull(timeSeriesDataItem30);
        org.junit.Assert.assertNotNull(timeSeries33);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        org.jfree.data.time.TimeSeries timeSeries1 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.String str2 = timeSeries1.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries5 = timeSeries1.createCopy((int) (short) 1, (int) '#');
        java.lang.Class class6 = null;
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries8.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 12);
        java.util.Calendar calendar14 = null;
        fixedMillisecond11.peg(calendar14);
        java.util.Date date16 = fixedMillisecond11.getEnd();
        java.util.TimeZone timeZone17 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod18 = org.jfree.data.time.RegularTimePeriod.createInstance(class6, date16, timeZone17);
        org.jfree.data.time.Month month19 = new org.jfree.data.time.Month(date16);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod20 = month19.next();
        org.jfree.data.time.Year year21 = month19.getYear();
        long long22 = year21.getLastMillisecond();
        timeSeries5.delete((org.jfree.data.time.RegularTimePeriod) year21);
        java.util.Calendar calendar24 = null;
        try {
            long long25 = year21.getLastMillisecond(calendar24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "Value" + "'", str2.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries5);
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertNotNull(date16);
        org.junit.Assert.assertNotNull(timeZone17);
        org.junit.Assert.assertNull(regularTimePeriod18);
        org.junit.Assert.assertNotNull(regularTimePeriod20);
        org.junit.Assert.assertNotNull(year21);
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 1577865599999L + "'", long22 == 1577865599999L);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test65");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class3);
        timeSeries4.setDomainDescription("hi!");
        org.jfree.data.time.Month month7 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem9 = timeSeries4.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month7, 0.0d);
        java.lang.Class class13 = null;
        org.jfree.data.time.TimeSeries timeSeries14 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class13);
        timeSeries14.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        int int17 = timeSeries14.getMaximumItemCount();
        java.lang.Class class21 = null;
        org.jfree.data.time.TimeSeries timeSeries22 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class21);
        timeSeries22.setDescription("SerialDate.weekInMonthToString(): invalid code.");
        org.jfree.data.general.SeriesChangeListener seriesChangeListener25 = null;
        timeSeries22.addChangeListener(seriesChangeListener25);
        java.util.Collection collection27 = timeSeries14.getTimePeriodsUniqueToOtherSeries(timeSeries22);
        java.lang.Class class31 = null;
        org.jfree.data.time.TimeSeries timeSeries32 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class31);
        timeSeries32.setDomainDescription("hi!");
        org.jfree.data.time.Month month35 = new org.jfree.data.time.Month();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem37 = timeSeries32.addOrUpdate((org.jfree.data.time.RegularTimePeriod) month35, 0.0d);
        long long38 = month35.getFirstMillisecond();
        int int39 = timeSeries22.getIndex((org.jfree.data.time.RegularTimePeriod) month35);
        org.jfree.data.time.TimeSeries timeSeries41 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        java.lang.String str42 = timeSeries41.getRangeDescription();
        org.jfree.data.time.TimeSeries timeSeries43 = timeSeries22.addAndOrUpdate(timeSeries41);
        java.util.Collection collection44 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries41);
        org.jfree.data.time.Day day45 = new org.jfree.data.time.Day();
        org.jfree.data.time.RegularTimePeriod regularTimePeriod46 = day45.next();
        timeSeries41.setKey((java.lang.Comparable) regularTimePeriod46);
        java.lang.Comparable comparable48 = timeSeries41.getKey();
        long long49 = timeSeries41.getMaximumItemAge();
        org.jfree.data.time.TimeSeries timeSeries51 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries51.setDescription("");
        org.jfree.data.time.Month month54 = new org.jfree.data.time.Month();
        timeSeries51.delete((org.jfree.data.time.RegularTimePeriod) month54);
        java.lang.String str56 = timeSeries51.getRangeDescription();
        java.lang.Class class60 = null;
        org.jfree.data.time.TimeSeries timeSeries61 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class60);
        timeSeries61.setDomainDescription("hi!");
        timeSeries61.fireSeriesChanged();
        org.jfree.data.time.TimeSeries timeSeries66 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries66.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond69 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem71 = timeSeries66.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69, (java.lang.Number) 12);
        java.util.Calendar calendar72 = null;
        fixedMillisecond69.peg(calendar72);
        java.util.Date date74 = fixedMillisecond69.getEnd();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem76 = timeSeries61.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69, (java.lang.Number) (-1.0f));
        org.jfree.data.time.FixedMillisecond fixedMillisecond77 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem79 = new org.jfree.data.time.TimeSeriesDataItem((org.jfree.data.time.RegularTimePeriod) fixedMillisecond77, (java.lang.Number) (byte) 10);
        org.jfree.data.time.TimeSeries timeSeries80 = timeSeries51.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond69, (org.jfree.data.time.RegularTimePeriod) fixedMillisecond77);
        org.jfree.data.time.TimeSeries timeSeries82 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries82.setDescription("");
        org.jfree.data.time.Month month85 = new org.jfree.data.time.Month();
        timeSeries82.delete((org.jfree.data.time.RegularTimePeriod) month85);
        org.jfree.data.time.Year year87 = month85.getYear();
        org.jfree.data.time.TimeSeries timeSeries88 = timeSeries41.createCopy((org.jfree.data.time.RegularTimePeriod) fixedMillisecond77, (org.jfree.data.time.RegularTimePeriod) year87);
        java.util.Calendar calendar89 = null;
        fixedMillisecond77.peg(calendar89);
        java.util.Date date91 = fixedMillisecond77.getEnd();
        java.util.Date date92 = fixedMillisecond77.getStart();
        org.jfree.data.time.FixedMillisecond fixedMillisecond93 = new org.jfree.data.time.FixedMillisecond(date92);
        org.junit.Assert.assertNull(timeSeriesDataItem9);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 2147483647 + "'", int17 == 2147483647);
        org.junit.Assert.assertNotNull(collection27);
        org.junit.Assert.assertNull(timeSeriesDataItem37);
        org.junit.Assert.assertTrue("'" + long38 + "' != '" + 1559372400000L + "'", long38 == 1559372400000L);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1) + "'", int39 == (-1));
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "Value" + "'", str42.equals("Value"));
        org.junit.Assert.assertNotNull(timeSeries43);
        org.junit.Assert.assertNotNull(collection44);
        org.junit.Assert.assertNotNull(regularTimePeriod46);
        org.junit.Assert.assertNotNull(comparable48);
        org.junit.Assert.assertTrue("'" + long49 + "' != '" + 9223372036854775807L + "'", long49 == 9223372036854775807L);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "Value" + "'", str56.equals("Value"));
        org.junit.Assert.assertNull(timeSeriesDataItem71);
        org.junit.Assert.assertNotNull(date74);
        org.junit.Assert.assertNull(timeSeriesDataItem76);
        org.junit.Assert.assertNotNull(timeSeries80);
        org.junit.Assert.assertNotNull(year87);
        org.junit.Assert.assertNotNull(timeSeries88);
        org.junit.Assert.assertNotNull(date91);
        org.junit.Assert.assertNotNull(date92);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(5);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        org.jfree.data.time.SerialDate serialDate4 = org.jfree.data.time.SerialDate.createInstance(9);
        serialDate4.setDescription("");
        java.lang.String str7 = serialDate4.getDescription();
        org.jfree.data.time.SerialDate serialDate9 = serialDate4.getFollowingDayOfWeek(1);
        serialDate9.setDescription("hi!");
        boolean boolean12 = spreadsheetDate1.isOn(serialDate9);
        spreadsheetDate1.setDescription("Mon Jun 10 11:18:52 PDT 2019");
        spreadsheetDate1.setDescription("Mon Jun 10 11:19:23 PDT 2019");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate18 = new org.jfree.data.time.SpreadsheetDate(9999);
        java.util.Date date19 = spreadsheetDate18.toDate();
        org.jfree.data.time.SerialDate serialDate22 = org.jfree.data.time.SerialDate.createInstance(1900);
        org.jfree.data.time.SerialDate serialDate23 = org.jfree.data.time.SerialDate.addYears(2019, serialDate22);
        boolean boolean24 = spreadsheetDate1.isInRange((org.jfree.data.time.SerialDate) spreadsheetDate18, serialDate22);
        java.lang.String str25 = spreadsheetDate18.getDescription();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertNotNull(serialDate4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertNotNull(serialDate9);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(date19);
        org.junit.Assert.assertNotNull(serialDate22);
        org.junit.Assert.assertNotNull(serialDate23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(str25);
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test67");
        org.jfree.data.time.SpreadsheetDate spreadsheetDate1 = new org.jfree.data.time.SpreadsheetDate(5);
        java.lang.String str2 = spreadsheetDate1.getDescription();
        int int3 = spreadsheetDate1.getYYYY();
        int int4 = spreadsheetDate1.getYYYY();
        org.jfree.data.time.Day day5 = new org.jfree.data.time.Day((org.jfree.data.time.SerialDate) spreadsheetDate1);
        org.jfree.data.time.SerialDate serialDate7 = org.jfree.data.time.SerialDate.createInstance(9);
        serialDate7.setDescription("");
        java.lang.String str10 = serialDate7.getDescription();
        org.jfree.data.time.SerialDate serialDate12 = serialDate7.getFollowingDayOfWeek(1);
        boolean boolean13 = spreadsheetDate1.isOnOrAfter(serialDate7);
        java.util.Date date14 = spreadsheetDate1.toDate();
        org.junit.Assert.assertNull(str2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1900 + "'", int3 == 1900);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 1900 + "'", int4 == 1900);
        org.junit.Assert.assertNotNull(serialDate7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "" + "'", str10.equals(""));
        org.junit.Assert.assertNotNull(serialDate12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(date14);
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test68");
        java.lang.Class class3 = null;
        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class3);
        timeSeries4.setDomainDescription("hi!");
        org.jfree.data.time.TimeSeries timeSeries8 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries8.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond11 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem13 = timeSeries8.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond11, (java.lang.Number) 12);
        boolean boolean14 = timeSeries4.equals((java.lang.Object) timeSeries8);
        timeSeries4.clear();
        org.jfree.data.time.TimeSeries timeSeries17 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries17.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond20 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem22 = timeSeries17.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond20, (java.lang.Number) 12);
        java.util.Calendar calendar23 = null;
        fixedMillisecond20.peg(calendar23);
        java.util.Date date25 = fixedMillisecond20.getTime();
        org.jfree.data.time.Month month26 = new org.jfree.data.time.Month(date25);
        org.jfree.data.time.TimeSeries timeSeries28 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        boolean boolean29 = timeSeries28.isEmpty();
        timeSeries28.setMaximumItemAge((long) 6);
        java.lang.Class class32 = timeSeries28.getTimePeriodClass();
        org.jfree.data.time.TimeSeries timeSeries34 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries34.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond37 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem39 = timeSeries34.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond37, (java.lang.Number) 12);
        java.util.Calendar calendar40 = null;
        fixedMillisecond37.peg(calendar40);
        java.util.Date date42 = fixedMillisecond37.getEnd();
        org.jfree.data.time.FixedMillisecond fixedMillisecond43 = new org.jfree.data.time.FixedMillisecond(date42);
        org.jfree.data.time.FixedMillisecond fixedMillisecond44 = new org.jfree.data.time.FixedMillisecond(date42);
        java.lang.Class class45 = null;
        org.jfree.data.time.TimeSeries timeSeries47 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
        timeSeries47.setDescription("");
        org.jfree.data.time.FixedMillisecond fixedMillisecond50 = new org.jfree.data.time.FixedMillisecond();
        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem52 = timeSeries47.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond50, (java.lang.Number) 12);
        java.util.Calendar calendar53 = null;
        fixedMillisecond50.peg(calendar53);
        java.util.Date date55 = fixedMillisecond50.getEnd();
        java.util.TimeZone timeZone56 = org.jfree.data.time.RegularTimePeriod.DEFAULT_TIME_ZONE;
        org.jfree.data.time.RegularTimePeriod regularTimePeriod57 = org.jfree.data.time.RegularTimePeriod.createInstance(class45, date55, timeZone56);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod58 = org.jfree.data.time.RegularTimePeriod.createInstance(class32, date42, timeZone56);
        org.jfree.data.time.Day day59 = new org.jfree.data.time.Day(date25, timeZone56);
        org.jfree.data.time.Year year60 = new org.jfree.data.time.Year(date25);
        org.jfree.data.time.RegularTimePeriod regularTimePeriod61 = year60.previous();
        try {
            timeSeries4.update((org.jfree.data.time.RegularTimePeriod) year60, (java.lang.Number) 1560190808388L);
            org.junit.Assert.fail("Expected exception of type org.jfree.data.general.SeriesException; message: TimeSeries.update(TimePeriod, Number):  period does not exist.");
        } catch (org.jfree.data.general.SeriesException e) {
        }
        org.junit.Assert.assertNull(timeSeriesDataItem13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(timeSeriesDataItem22);
        org.junit.Assert.assertNotNull(date25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(class32);
        org.junit.Assert.assertNull(timeSeriesDataItem39);
        org.junit.Assert.assertNotNull(date42);
        org.junit.Assert.assertNull(timeSeriesDataItem52);
        org.junit.Assert.assertNotNull(date55);
        org.junit.Assert.assertNotNull(timeZone56);
        org.junit.Assert.assertNull(regularTimePeriod57);
        org.junit.Assert.assertNotNull(regularTimePeriod58);
        org.junit.Assert.assertNotNull(regularTimePeriod61);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test69");
        int int1 = org.jfree.data.time.SerialDate.leapYearCount(30);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-452) + "'", int1 == (-452));
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test70");
        org.jfree.data.time.FixedMillisecond fixedMillisecond1 = new org.jfree.data.time.FixedMillisecond(0L);
        java.util.Calendar calendar2 = null;
        long long3 = fixedMillisecond1.getMiddleMillisecond(calendar2);
        long long4 = fixedMillisecond1.getMiddleMillisecond();
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 0L + "'", long3 == 0L);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
    }

//    @Test
//    public void test71() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test71");
//        java.lang.Class class3 = null;
//        org.jfree.data.time.TimeSeries timeSeries4 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class3);
//        timeSeries4.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        int int7 = timeSeries4.getMaximumItemCount();
//        java.lang.Class class11 = null;
//        org.jfree.data.time.TimeSeries timeSeries12 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) '4', "", "SerialDate.weekInMonthToString(): invalid code.", class11);
//        timeSeries12.setDescription("SerialDate.weekInMonthToString(): invalid code.");
//        org.jfree.data.general.SeriesChangeListener seriesChangeListener15 = null;
//        timeSeries12.addChangeListener(seriesChangeListener15);
//        java.util.Collection collection17 = timeSeries4.getTimePeriodsUniqueToOtherSeries(timeSeries12);
//        java.lang.Object obj18 = timeSeries4.clone();
//        org.jfree.data.time.TimeSeries timeSeries20 = new org.jfree.data.time.TimeSeries((java.lang.Comparable) (short) 0);
//        timeSeries20.setDescription("");
//        org.jfree.data.time.FixedMillisecond fixedMillisecond23 = new org.jfree.data.time.FixedMillisecond();
//        org.jfree.data.time.TimeSeriesDataItem timeSeriesDataItem25 = timeSeries20.addOrUpdate((org.jfree.data.time.RegularTimePeriod) fixedMillisecond23, (java.lang.Number) 12);
//        java.util.Calendar calendar26 = null;
//        long long27 = fixedMillisecond23.getFirstMillisecond(calendar26);
//        long long28 = fixedMillisecond23.getMiddleMillisecond();
//        timeSeries4.setKey((java.lang.Comparable) long28);
//        java.lang.String str30 = timeSeries4.getRangeDescription();
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 2147483647 + "'", int7 == 2147483647);
//        org.junit.Assert.assertNotNull(collection17);
//        org.junit.Assert.assertNotNull(obj18);
//        org.junit.Assert.assertNull(timeSeriesDataItem25);
//        org.junit.Assert.assertTrue("'" + long27 + "' != '" + 1560190829403L + "'", long27 == 1560190829403L);
//        org.junit.Assert.assertTrue("'" + long28 + "' != '" + 1560190829403L + "'", long28 == 1560190829403L);
//        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "SerialDate.weekInMonthToString(): invalid code." + "'", str30.equals("SerialDate.weekInMonthToString(): invalid code."));
//    }
//}

