import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test002");
//        java.lang.Class class1 = null;
//        java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResource("", class1);
//        org.junit.Assert.assertNotNull(uRL2);
//    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        try {
            java.util.ResourceBundle resourceBundle1 = java.util.ResourceBundle.getBundle("hi!");
            org.junit.Assert.fail("Expected exception of type java.util.MissingResourceException; message: Can't find bundle for base name hi!, locale en_US");
        } catch (java.util.MissingResourceException e) {
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.event.PlotChangeEvent plotChangeEvent1 = new org.jfree.chart.event.PlotChangeEvent(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: null source");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        org.jfree.chart.util.Size2D size2D0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor3 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D4 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D0, (double) 0, (double) (-1L), rectangleAnchor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = null;
        org.jfree.chart.text.TextAnchor textAnchor6 = null;
        org.jfree.chart.text.TextUtilities.drawRotatedString("", graphics2D1, (float) (byte) 100, (float) (short) 10, textAnchor4, 0.0d, textAnchor6);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.CLASS_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ClassContext" + "'", str0.equals("ClassContext"));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_STARTED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = null;
        java.awt.Stroke stroke5 = null;
        java.awt.Color color6 = org.jfree.chart.ChartColor.DARK_RED;
        try {
            org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem(attributedString0, "", "ClassContext", "hi!", shape4, stroke5, (java.awt.Paint) color6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color6);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.jfree.data.function.Function2D function2D0 = null;
        try {
            org.jfree.data.xy.XYDataset xYDataset5 = org.jfree.data.general.DatasetUtilities.sampleFunction2D(function2D0, (double) (short) 0, (double) 0, 10, (java.lang.Comparable) 100.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'f' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE11;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions1 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition2 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions3 = org.jfree.chart.axis.CategoryLabelPositions.replaceRightPosition(categoryLabelPositions1, categoryLabelPosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'right' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(categoryLabelPositions1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        int int0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALIGNMENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 15 + "'", int0 == 15);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double0 = org.jfree.chart.axis.CategoryAxis.DEFAULT_AXIS_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = textTitle0.getMargin();
        java.awt.geom.Rectangle2D rectangle2D4 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType5 = null;
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType6 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D7 = rectangleInsets3.createAdjustedRectangle(rectangle2D4, lengthAdjustmentType5, lengthAdjustmentType6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets3);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setPadding(10.0d, 0.05d, 0.0d, 100.0d);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test018");
//        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.getClassLoaderSource();
//        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        org.jfree.chart.text.TextUtilities.setUseFontMetricsGetStringBounds(false);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        java.awt.Paint paint6 = null;
        try {
            categoryPlot0.setRangeCrosshairPaint(paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        float float0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_INSIDE_LENGTH;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.0f + "'", float0 == 0.0f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_RED;
        java.awt.Stroke stroke2 = null;
        try {
            org.jfree.chart.plot.ValueMarker valueMarker3 = new org.jfree.chart.plot.ValueMarker((double) 10, (java.awt.Paint) color1, stroke2);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(color1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumRangeValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE9;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis0.setTickLabelsVisible(true);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        java.awt.geom.Rectangle2D rectangle2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        int int9 = categoryPlot8.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot8.getRangeAxisEdge();
        java.awt.Paint paint11 = categoryPlot8.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot8.getRangeAxisEdge();
        org.jfree.chart.axis.AxisSpace axisSpace13 = null;
        try {
            org.jfree.chart.axis.AxisSpace axisSpace14 = categoryAxis0.reserveSpace(graphics2D5, (org.jfree.chart.plot.Plot) categoryPlot6, rectangle2D7, rectangleEdge12, axisSpace13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(paint11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            double double2 = org.jfree.data.general.DatasetUtilities.calculateStackTotal(tableXYDataset0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.AxisState axisState5 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        int int8 = categoryPlot7.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot7.getRangeAxisEdge();
        try {
            java.util.List list10 = numberAxis1.refreshTicks(graphics2D4, axisState5, rectangle2D6, rectangleEdge9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge9);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle1.setFont(font2);
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font2);
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.text.TextAnchor textAnchor8 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        try {
            textFragment4.draw(graphics2D5, (-1.0f), (float) '4', textAnchor8, (float) 100L, (float) (short) -1, (double) 100.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertNotNull(textAnchor8);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        boolean boolean0 = org.jfree.chart.axis.NumberAxis.DEFAULT_VERTICAL_TICK_LABELS;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("ThreadContext", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.POSITIVE;
        org.junit.Assert.assertNotNull(rangeType0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        java.awt.Color color0 = java.awt.Color.CYAN;
        boolean boolean2 = color0.equals((java.lang.Object) ' ');
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_VERTICAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_FOREGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        java.awt.geom.Rectangle2D rectangle2D0 = null;
        java.awt.geom.Rectangle2D rectangle2D1 = null;
        try {
            boolean boolean2 = org.jfree.chart.util.ShapeUtilities.intersects(rectangle2D0, rectangle2D1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle2.setFont(font3);
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font3);
        java.awt.Paint paint6 = null;
        try {
            org.jfree.chart.block.LabelBlock labelBlock7 = new org.jfree.chart.block.LabelBlock("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font3, paint6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.title.Title.DEFAULT_POSITION;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 100, numberFormat1, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition4 = null;
        try {
            statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        java.awt.geom.Rectangle2D rectangle2D11 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D12 = rectangleInsets8.createInsetRectangle(rectangle2D11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets8);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("ClassContext", font1);
        labelBlock2.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        labelBlock2.setToolTipText("");
        java.awt.Graphics2D graphics2D7 = null;
        java.awt.geom.Rectangle2D rectangle2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot9.setDomainAxisLocation(15, axisLocation11, true);
        org.jfree.chart.util.Layer layer14 = null;
        java.util.Collection collection15 = categoryPlot9.getDomainMarkers(layer14);
        try {
            java.lang.Object obj16 = labelBlock2.draw(graphics2D7, rectangle2D8, (java.lang.Object) layer14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(collection15);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot7.setDomainAxisLocation(15, axisLocation9, true);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot7.getDomainMarkers(layer12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = new org.jfree.chart.axis.CategoryAxis();
        float float15 = categoryAxis14.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor16 = null;
        java.awt.geom.Rectangle2D rectangle2D19 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = null;
        double double21 = categoryAxis14.getCategoryJava2DCoordinate(categoryAnchor16, (int) '#', (int) (short) 10, rectangle2D19, rectangleEdge20);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions23 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
        categoryAxis14.setCategoryLabelPositions(categoryLabelPositions23);
        org.jfree.chart.plot.CategoryMarker categoryMarker25 = null;
        java.awt.geom.Rectangle2D rectangle2D26 = null;
        try {
            statisticalBarRenderer0.drawDomainMarker(graphics2D6, categoryPlot7, categoryAxis14, categoryMarker25, rectangle2D26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertTrue("'" + float15 + "' != '" + 0.0f + "'", float15 == 0.0f);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions23);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER_LEFT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape11);
        numberAxis1.setDownArrow(shape11);
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        textTitle16.setURLText("hi!");
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = textTitle16.getPosition();
        try {
            double double20 = numberAxis1.lengthToJava2D(0.0d, rectangle2D15, rectangleEdge19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(rectangleEdge19);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, (float) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) 100.0f, (double) 0.0f);
        org.jfree.chart.block.BlockContainer blockContainer5 = null;
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.data.Range range8 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range8);
        try {
            org.jfree.chart.util.Size2D size2D10 = columnArrangement4.arrange(blockContainer5, graphics2D6, rectangleConstraint9);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not implemented.");
        } catch (java.lang.RuntimeException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        int int8 = categoryPlot7.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot7.getRangeAxisEdge();
        java.awt.Paint paint10 = categoryPlot7.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge11 = categoryPlot7.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot7.getDomainAxisEdge(0);
        try {
            double double14 = categoryAxis0.getCategoryStart(0, 0, rectangle2D6, rectangleEdge13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertNotNull(rectangleEdge11);
        org.junit.Assert.assertNotNull(rectangleEdge13);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity7 = new org.jfree.chart.entity.ChartEntity(shape6);
        java.awt.Color color8 = java.awt.Color.BLACK;
        try {
            org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem(attributedString0, "", "java.awt.Color[r=192,g=0,b=0]", "java.awt.Color[r=192,g=0,b=0]", shape6, (java.awt.Paint) color8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        org.jfree.data.category.CategoryDataset categoryDataset2 = null;
        try {
            java.lang.String str4 = standardCategorySeriesLabelGenerator1.generateLabel(categoryDataset2, 255);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape11);
        numberAxis1.setDownArrow(shape11);
        try {
            numberAxis1.setAutoRangeMinimumSize(0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: NumberAxis.setAutoRangeMinimumSize(double): must be > 0.0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findCumulativeRangeBounds(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setURLText("hi!");
        org.jfree.chart.util.RectangleInsets rectangleInsets3 = null;
        try {
            textTitle0.setMargin(rectangleInsets3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'margin' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        java.awt.Paint paint0 = org.jfree.chart.block.LabelBlock.DEFAULT_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setForegroundAlpha((float) 0);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        try {
            categoryPlot0.setRangeAxisLocation((-1), axisLocation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((double) 0L, (double) 255, 1.0E-8d, (double) 1.0f);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (-1L), (double) 10);
        boolean boolean4 = meanAndStandardDeviation2.equals((java.lang.Object) ' ');
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.jfree.chart.JFreeChart jFreeChart1 = null;
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent2 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) 'a', jFreeChart1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setAutoPopulateSeriesOutlinePaint(false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        try {
            statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        java.awt.Color color0 = org.jfree.chart.ChartColor.VERY_DARK_GREEN;
        int int1 = color0.getRed();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumRangeValue(categoryDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.general.PieDataset pieDataset2 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow(categoryDataset0, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.jfree.data.general.PieDataset pieDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(pieDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        org.jfree.chart.util.RectangleAnchor rectangleAnchor0 = org.jfree.chart.util.RectangleAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(rectangleAnchor0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        java.awt.Paint paint0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.jfree.chart.axis.AxisLocation axisLocation0 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Font font2 = statisticalBarRenderer1.getBaseItemLabelFont();
        boolean boolean3 = axisLocation0.equals((java.lang.Object) font2);
        org.jfree.chart.plot.PlotOrientation plotOrientation4 = null;
        try {
            org.jfree.chart.util.RectangleEdge rectangleEdge5 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation0, plotOrientation4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'orientation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(axisLocation0);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape6, (java.awt.Paint) color7);
        float[] floatArray11 = new float[] { '4', (short) 10 };
        try {
            float[] floatArray12 = color7.getRGBColorComponents(floatArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(floatArray11);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset0);
        org.junit.Assert.assertNull(number1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        java.awt.geom.GeneralPath generalPath0 = null;
        java.awt.geom.GeneralPath generalPath1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(generalPath0, generalPath1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        org.jfree.chart.axis.NumberAxis numberAxis0 = new org.jfree.chart.axis.NumberAxis();
        numberAxis0.setAutoTickUnitSelection(true, false);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.jfree.data.category.CategoryDataset categoryDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset0, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        try {
            org.jfree.chart.title.Title title11 = jFreeChart9.getSubtitle((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Index out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        float float0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 1.0f + "'", float0 == 1.0f);
    }

//    @Test
//    public void test076() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test076");
//        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
//        java.awt.Graphics2D graphics2D1 = null;
//        java.awt.geom.Rectangle2D rectangle2D2 = null;
//        java.lang.Class class3 = null;
//        java.lang.ClassLoader classLoader4 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class3);
//        try {
//            java.lang.Object obj5 = blockContainer0.draw(graphics2D1, rectangle2D2, (java.lang.Object) class3);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(classLoader4);
//    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str1 = color0.toString();
        boolean boolean3 = color0.equals((java.lang.Object) 'a');
        java.awt.Color color4 = java.awt.Color.CYAN;
        java.awt.color.ColorSpace colorSpace5 = color4.getColorSpace();
        float[] floatArray8 = new float[] { 1, (-16711681) };
        try {
            float[] floatArray9 = color0.getColorComponents(colorSpace5, floatArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str1.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertNotNull(colorSpace5);
        org.junit.Assert.assertNotNull(floatArray8);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE12;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        java.awt.geom.Line2D line2D0 = null;
        java.awt.geom.Line2D line2D1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(line2D0, line2D1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        double double2 = numberAxis1.getAutoRangeMinimumSize();
        numberAxis1.setVisible(true);
        org.jfree.data.Range range5 = null;
        try {
            numberAxis1.setRange(range5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-8d + "'", double2 == 1.0E-8d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_WIDTH_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        blockContainer0.clear();
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        int int0 = org.jfree.chart.plot.Plot.MINIMUM_HEIGHT_TO_DRAW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10 + "'", int0 == 10);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str2 = numberTickUnit1.toString();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str4 = numberTickUnit3.toString();
        boolean boolean6 = numberTickUnit3.equals((java.lang.Object) 0L);
        java.lang.Comparable[] comparableArray9 = new java.lang.Comparable[] { numberTickUnit0, str2, boolean6, 1, 0 };
        java.lang.Comparable[] comparableArray10 = new java.lang.Comparable[] {};
        double[] doubleArray16 = new double[] { (short) 100, 10, 100, (byte) 1, (-16711681) };
        double[] doubleArray22 = new double[] { (short) 100, 10, 100, (byte) 1, (-16711681) };
        double[] doubleArray28 = new double[] { (short) 100, 10, 100, (byte) 1, (-16711681) };
        double[] doubleArray34 = new double[] { (short) 100, 10, 100, (byte) 1, (-16711681) };
        double[] doubleArray40 = new double[] { (short) 100, 10, 100, (byte) 1, (-16711681) };
        double[][] doubleArray41 = new double[][] { doubleArray16, doubleArray22, doubleArray28, doubleArray34, doubleArray40 };
        try {
            org.jfree.data.category.CategoryDataset categoryDataset42 = org.jfree.data.general.DatasetUtilities.createCategoryDataset(comparableArray9, comparableArray10, doubleArray41);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The number of column keys does not match the number of columns in the data array.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertNotNull(numberTickUnit1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "[size=1]" + "'", str2.equals("[size=1]"));
        org.junit.Assert.assertNotNull(numberTickUnit3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "[size=1]" + "'", str4.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(comparableArray9);
        org.junit.Assert.assertNotNull(comparableArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.awt.Font font0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getInsets();
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D13 = rectangleInsets11.createInsetRectangle(rectangle2D12);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findDomainBounds(xYDataset0, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        org.jfree.data.Range range9 = null;
        try {
            numberAxis1.setRange(range9, false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.event.ChartChangeListener chartChangeListener10 = null;
        try {
            jFreeChart9.addChangeListener(chartChangeListener10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            java.lang.Number number1 = org.jfree.data.general.DatasetUtilities.findMinimumDomainValue(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.jfree.chart.axis.CategoryAnchor categoryAnchor0 = org.jfree.chart.axis.CategoryAnchor.START;
        org.junit.Assert.assertNotNull(categoryAnchor0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.jfree.chart.block.BlockBorder blockBorder0 = org.jfree.chart.block.BlockBorder.NONE;
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            blockBorder0.draw(graphics2D1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(blockBorder0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        java.awt.Graphics2D graphics2D11 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        java.awt.geom.Point2D point2D13 = null;
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo14 = null;
        try {
            jFreeChart9.draw(graphics2D11, rectangle2D12, point2D13, chartRenderingInfo14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.util.List list1 = textBlock0.getLines();
        try {
            java.util.Collection collection2 = org.jfree.chart.util.ObjectUtilities.deepClone((java.util.Collection) list1);
            org.junit.Assert.fail("Expected exception of type java.lang.CloneNotSupportedException; message: Failed to clone.");
        } catch (java.lang.CloneNotSupportedException e) {
        }
        org.junit.Assert.assertNotNull(list1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) '#', (int) (short) 10, rectangle2D5, rectangleEdge6);
        java.awt.Paint paint8 = categoryAxis0.getTickLabelPaint();
        categoryAxis0.clearCategoryLabelToolTips();
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        java.awt.geom.Rectangle2D rectangle2D2 = null;
        try {
            java.awt.geom.Point2D point2D3 = org.jfree.chart.util.ShapeUtilities.getPointInRectangle(1.0d, (double) 1, rectangle2D2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_45;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double0 = org.jfree.chart.renderer.category.BarRenderer.BAR_OUTLINE_WIDTH_THRESHOLD;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.0d + "'", double0 == 3.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) '#', (int) (short) 10, rectangle2D5, rectangleEdge6);
        java.awt.geom.Rectangle2D rectangle2D10 = null;
        org.jfree.chart.title.TextTitle textTitle11 = new org.jfree.chart.title.TextTitle();
        textTitle11.setURLText("hi!");
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = textTitle11.getPosition();
        try {
            double double15 = categoryAxis0.getCategoryEnd((int) (byte) 100, 1, rectangle2D10, rectangleEdge14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(rectangleEdge14);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.jfree.chart.block.LabelBlock labelBlock1 = new org.jfree.chart.block.LabelBlock("hi!");
        java.lang.Object obj2 = labelBlock1.clone();
        org.junit.Assert.assertNotNull(obj2);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_RED;
        int int1 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-4194304) + "'", int1 == (-4194304));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.jfree.data.RangeType rangeType0 = org.jfree.data.RangeType.FULL;
        org.junit.Assert.assertNotNull(rangeType0);
    }

//    @Test
//    public void test104() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test104");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getLibraries();
//        projectInfo0.setLicenceText("hi!");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
//        org.junit.Assert.assertNotNull(libraryArray2);
//    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke11 = statisticalBarRenderer10.getBaseStroke();
        java.awt.Paint paint13 = statisticalBarRenderer10.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke15 = statisticalBarRenderer14.getBaseStroke();
        statisticalBarRenderer10.setBaseStroke(stroke15, false);
        jFreeChart9.setBorderStroke(stroke15);
        java.awt.Graphics2D graphics2D19 = null;
        java.awt.geom.Rectangle2D rectangle2D20 = null;
        try {
            jFreeChart9.draw(graphics2D19, rectangle2D20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        try {
            org.jfree.data.Range range7 = statisticalBarRenderer0.findRangeBounds(categoryDataset6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot7.setDomainAxisLocation(15, axisLocation9, true);
        categoryPlot7.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset13 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer14 = categoryPlot7.getRendererForDataset(categoryDataset13);
        org.jfree.chart.util.Layer layer16 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection17 = categoryPlot7.getDomainMarkers((int) '#', layer16);
        org.jfree.chart.axis.NumberAxis numberAxis19 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis19.setPositiveArrowVisible(true);
        numberAxis19.setFixedAutoRange((double) (short) 0);
        numberAxis19.setRangeWithMargins((double) 0, (double) '#');
        java.awt.Shape shape29 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity(shape29);
        numberAxis19.setDownArrow(shape29);
        boolean boolean32 = numberAxis19.isTickMarksVisible();
        org.jfree.chart.plot.ValueMarker valueMarker34 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation37 = null;
        categoryPlot35.setDomainAxisLocation(15, axisLocation37, true);
        categoryPlot35.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset41 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer42 = categoryPlot35.getRendererForDataset(categoryDataset41);
        java.awt.Stroke stroke43 = categoryPlot35.getOutlineStroke();
        valueMarker34.setStroke(stroke43);
        valueMarker34.setLabel("ThreadContext");
        java.awt.Color color47 = java.awt.Color.BLUE;
        valueMarker34.setPaint((java.awt.Paint) color47);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor49 = org.jfree.chart.util.RectangleAnchor.TOP_RIGHT;
        valueMarker34.setLabelAnchor(rectangleAnchor49);
        java.awt.Font font52 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock53 = new org.jfree.chart.block.LabelBlock("ClassContext", font52);
        labelBlock53.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        java.awt.Font font57 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock58 = new org.jfree.chart.block.LabelBlock("ClassContext", font57);
        labelBlock58.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle();
        boolean boolean62 = labelBlock58.equals((java.lang.Object) textTitle61);
        java.awt.geom.Rectangle2D rectangle2D63 = textTitle61.getBounds();
        labelBlock53.setBounds(rectangle2D63);
        try {
            statisticalBarRenderer0.drawRangeMarker(graphics2D6, categoryPlot7, (org.jfree.chart.axis.ValueAxis) numberAxis19, (org.jfree.chart.plot.Marker) valueMarker34, rectangle2D63);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(categoryItemRenderer14);
        org.junit.Assert.assertNotNull(layer16);
        org.junit.Assert.assertNull(collection17);
        org.junit.Assert.assertNotNull(shape29);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNull(categoryItemRenderer42);
        org.junit.Assert.assertNotNull(stroke43);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(rectangleAnchor49);
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangle2D63);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.text.TextBlock textBlock5 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.Size2D size2D7 = textBlock5.calculateDimensions(graphics2D6);
        size2D7.setWidth((double) (short) 0);
        java.lang.String str10 = size2D7.toString();
        try {
            org.jfree.chart.util.Size2D size2D11 = rectangleConstraint2.calculateConstrainedSize(size2D7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNotNull(size2D7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str10.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        textTitle6.setID("ClassContext");
        java.lang.Object obj9 = null;
        columnArrangement5.add((org.jfree.chart.block.Block) textTitle6, obj9);
        boolean boolean11 = textAnchor0.equals((java.lang.Object) textTitle6);
        textTitle6.setHeight((double) 1);
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator2 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Color color3 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color3, true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator2);
        org.junit.Assert.assertNotNull(color3);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        java.awt.Color color0 = java.awt.Color.YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.CENTER_HORIZONTAL;
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block1 = null;
        java.lang.Number[] numberArray6 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray9 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray12 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray15 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray18 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray21 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[][] numberArray22 = new java.lang.Number[][] { numberArray6, numberArray9, numberArray12, numberArray15, numberArray18, numberArray21 };
        org.jfree.data.category.CategoryDataset categoryDataset23 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=192,g=0,b=0]", "hi!", numberArray22);
        try {
            blockContainer0.add(block1, (java.lang.Object) "java.awt.Color[r=192,g=0,b=0]");
            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: java.lang.String cannot be cast to org.jfree.chart.util.RectangleEdge");
        } catch (java.lang.ClassCastException e) {
        }
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray9);
        org.junit.Assert.assertNotNull(numberArray12);
        org.junit.Assert.assertNotNull(numberArray15);
        org.junit.Assert.assertNotNull(numberArray18);
        org.junit.Assert.assertNotNull(numberArray21);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(categoryDataset23);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        categoryPlot0.setAnchorValue((double) (byte) 100, true);
        categoryPlot0.setRangeCrosshairValue((double) (short) -1);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        int int7 = categoryPlot6.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge8 = categoryPlot6.getRangeAxisEdge();
        java.awt.Paint paint9 = categoryPlot6.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot6.getRangeAxisEdge();
        boolean boolean11 = categoryPlot6.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot6.getDomainAxisEdge((int) (short) -1);
        boolean boolean14 = categoryPlot6.getDrawSharedDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis15 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis15.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis15.setMaximumCategoryLabelWidthRatio((float) (-1L));
        org.jfree.chart.plot.CategoryMarker categoryMarker21 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer22 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator23 = statisticalBarRenderer22.getLegendItemToolTipGenerator();
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        int int26 = categoryPlot25.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot25.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = null;
        categoryPlot25.setRenderer((int) (byte) 100, categoryItemRenderer29);
        boolean boolean31 = categoryPlot25.isDomainGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis33 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean34 = numberAxis33.isVerticalTickLabels();
        org.jfree.data.Range range35 = numberAxis33.getRange();
        org.jfree.chart.plot.ValueMarker valueMarker37 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot38 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation40 = null;
        categoryPlot38.setDomainAxisLocation(15, axisLocation40, true);
        categoryPlot38.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset44 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer45 = categoryPlot38.getRendererForDataset(categoryDataset44);
        java.awt.Stroke stroke46 = categoryPlot38.getOutlineStroke();
        valueMarker37.setStroke(stroke46);
        valueMarker37.setLabel("ThreadContext");
        double double50 = valueMarker37.getValue();
        java.awt.Font font52 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock53 = new org.jfree.chart.block.LabelBlock("ClassContext", font52);
        labelBlock53.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle56 = new org.jfree.chart.title.TextTitle();
        boolean boolean57 = labelBlock53.equals((java.lang.Object) textTitle56);
        java.awt.geom.Rectangle2D rectangle2D58 = textTitle56.getBounds();
        statisticalBarRenderer22.drawRangeMarker(graphics2D24, categoryPlot25, (org.jfree.chart.axis.ValueAxis) numberAxis33, (org.jfree.chart.plot.Marker) valueMarker37, rectangle2D58);
        try {
            statisticalBarRenderer0.drawDomainMarker(graphics2D5, categoryPlot6, categoryAxis15, categoryMarker21, rectangle2D58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge8);
        org.junit.Assert.assertNotNull(paint9);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator23);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(range35);
        org.junit.Assert.assertNull(categoryItemRenderer45);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + (-1.0d) + "'", double50 == (-1.0d));
        org.junit.Assert.assertNotNull(font52);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(rectangle2D58);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        float float1 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor2 = null;
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = null;
        double double7 = categoryAxis0.getCategoryJava2DCoordinate(categoryAnchor2, (int) '#', (int) (short) 10, rectangle2D5, rectangleEdge6);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions9 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
        categoryAxis0.setCategoryLabelPositions(categoryLabelPositions9);
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition11 = null;
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions12 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions9, categoryLabelPosition11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'left' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions9);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        java.awt.Polygon polygon0 = null;
        java.awt.Polygon polygon1 = null;
        boolean boolean2 = org.jfree.chart.util.ShapeUtilities.equal(polygon0, polygon1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        java.awt.Font font5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("ClassContext", font5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str8 = color7.toString();
        boolean boolean10 = color7.equals((java.lang.Object) 'a');
        textBlock0.addLine("java.awt.Color[r=192,g=0,b=0]", font5, (java.awt.Paint) color7);
        org.jfree.chart.text.TextLine textLine12 = new org.jfree.chart.text.TextLine();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.text.TextAnchor textAnchor16 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment17 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment18 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement21 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment17, verticalAlignment18, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle22 = new org.jfree.chart.title.TextTitle();
        textTitle22.setID("ClassContext");
        java.lang.Object obj25 = null;
        columnArrangement21.add((org.jfree.chart.block.Block) textTitle22, obj25);
        boolean boolean27 = textAnchor16.equals((java.lang.Object) textTitle22);
        textLine12.draw(graphics2D13, (float) '4', (float) (short) 10, textAnchor16, (float) (short) -1, (float) 0L, 0.0d);
        textBlock0.addLine(textLine12);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str8.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(textAnchor16);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape11);
        numberAxis1.setDownArrow(shape11);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int15 = numberTickUnit14.getMinorTickCount();
        numberAxis1.setTickUnit(numberTickUnit14, false, true);
        boolean boolean19 = numberAxis1.isInverted();
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_INVERTED;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.jfree.chart.text.TextLine textLine0 = new org.jfree.chart.text.TextLine();
        boolean boolean2 = textLine0.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle4.setFont(font5);
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font5);
        textLine0.addFragment(textFragment7);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.text.TextAnchor textAnchor12 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_LEFT;
        try {
            textLine0.draw(graphics2D9, (float) 0, 0.0f, textAnchor12, 0.0f, (float) (short) 1, 10.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(textAnchor12);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_RIGHT;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str2 = color1.toString();
        statisticalBarRenderer0.setBasePaint((java.awt.Paint) color1, true);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier5 = statisticalBarRenderer0.getDrawingSupplier();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str2.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertNull(drawingSupplier5);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        java.awt.Color color0 = java.awt.Color.cyan;
        float[] floatArray4 = new float[] { 0L, 255, 15 };
        try {
            float[] floatArray5 = color0.getComponents(floatArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertNotNull(floatArray4);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke6 = statisticalBarRenderer5.getBaseStroke();
        java.awt.Paint paint8 = statisticalBarRenderer5.getSeriesOutlinePaint((-1));
        int int9 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer5);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator12 = statisticalBarRenderer11.getLegendItemToolTipGenerator();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = new org.jfree.chart.plot.CategoryPlot();
        int int15 = categoryPlot14.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot14.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer18 = null;
        categoryPlot14.setRenderer((int) (byte) 100, categoryItemRenderer18);
        boolean boolean20 = categoryPlot14.isDomainGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean23 = numberAxis22.isVerticalTickLabels();
        org.jfree.data.Range range24 = numberAxis22.getRange();
        org.jfree.chart.plot.ValueMarker valueMarker26 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot27 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation29 = null;
        categoryPlot27.setDomainAxisLocation(15, axisLocation29, true);
        categoryPlot27.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset33 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer34 = categoryPlot27.getRendererForDataset(categoryDataset33);
        java.awt.Stroke stroke35 = categoryPlot27.getOutlineStroke();
        valueMarker26.setStroke(stroke35);
        valueMarker26.setLabel("ThreadContext");
        double double39 = valueMarker26.getValue();
        java.awt.Font font41 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock42 = new org.jfree.chart.block.LabelBlock("ClassContext", font41);
        labelBlock42.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle45 = new org.jfree.chart.title.TextTitle();
        boolean boolean46 = labelBlock42.equals((java.lang.Object) textTitle45);
        java.awt.geom.Rectangle2D rectangle2D47 = textTitle45.getBounds();
        statisticalBarRenderer11.drawRangeMarker(graphics2D13, categoryPlot14, (org.jfree.chart.axis.ValueAxis) numberAxis22, (org.jfree.chart.plot.Marker) valueMarker26, rectangle2D47);
        org.jfree.chart.plot.CategoryPlot categoryPlot49 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo51 = null;
        try {
            org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState52 = statisticalBarRenderer5.initialise(graphics2D10, rectangle2D47, categoryPlot49, (int) (byte) 10, plotRenderingInfo51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNull(categorySeriesLabelGenerator12);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(range24);
        org.junit.Assert.assertNull(categoryItemRenderer34);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + (-1.0d) + "'", double39 == (-1.0d));
        org.junit.Assert.assertNotNull(font41);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(rectangle2D47);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = java.awt.Color.white;
        statisticalBarRenderer0.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color7);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        try {
            statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition9, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        java.awt.Paint paint1 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer2 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke3 = statisticalBarRenderer2.getBaseStroke();
        java.awt.Paint paint5 = statisticalBarRenderer2.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke7 = statisticalBarRenderer6.getBaseStroke();
        statisticalBarRenderer2.setBaseStroke(stroke7, false);
        try {
            org.jfree.chart.plot.ValueMarker valueMarker10 = new org.jfree.chart.plot.ValueMarker((double) (byte) 1, paint1, stroke7);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke3);
        org.junit.Assert.assertNull(paint5);
        org.junit.Assert.assertNotNull(stroke7);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        java.awt.Paint paint0 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder1 = new org.jfree.chart.block.BlockBorder(paint0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

//    @Test
//    public void test130() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test130");
//        java.lang.Class class1 = null;
//        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", class1);
//        org.junit.Assert.assertNull(inputStream2);
//    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.DOWN_90;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        try {
            textTitle0.setTextAlignment(horizontalAlignment1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        textTitle6.setID("ClassContext");
        java.lang.Object obj9 = null;
        columnArrangement5.add((org.jfree.chart.block.Block) textTitle6, obj9);
        boolean boolean11 = textAnchor0.equals((java.lang.Object) textTitle6);
        double double12 = textTitle6.getContentYOffset();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot2.getRendererForDataset(categoryDataset8);
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        valueMarker1.setStroke(stroke10);
        valueMarker1.setLabel("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = valueMarker1.getLabelOffset();
        java.awt.Color color15 = java.awt.Color.white;
        int int16 = color15.getGreen();
        valueMarker1.setPaint((java.awt.Paint) color15);
        java.awt.Color color18 = java.awt.Color.CYAN;
        java.awt.color.ColorSpace colorSpace19 = color18.getColorSpace();
        float[] floatArray21 = new float[] { (short) 0 };
        try {
            float[] floatArray22 = color15.getColorComponents(colorSpace19, floatArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets14);
        org.junit.Assert.assertNotNull(color15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 255 + "'", int16 == 255);
        org.junit.Assert.assertNotNull(color18);
        org.junit.Assert.assertNotNull(colorSpace19);
        org.junit.Assert.assertNotNull(floatArray21);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot2.getRendererForDataset(categoryDataset8);
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        valueMarker1.setStroke(stroke10);
        valueMarker1.setLabel("ThreadContext");
        valueMarker1.setLabel("[size=1]");
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE4;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setBaseSeriesVisible(false, false);
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) '4', (java.lang.Boolean) true, true);
        statisticalBarRenderer0.setBaseSeriesVisible(true);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        java.awt.Shape[] shapeArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_SHAPE_SEQUENCE;
        org.junit.Assert.assertNotNull(shapeArray0);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.plot.CategoryMarker categoryMarker11 = null;
        try {
            categoryPlot1.addDomainMarker(categoryMarker11);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        int int0 = org.jfree.chart.event.ChartProgressEvent.DRAWING_FINISHED;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.jfree.chart.event.ChartChangeEventType chartChangeEventType0 = org.jfree.chart.event.ChartChangeEventType.NEW_DATASET;
        org.junit.Assert.assertNotNull(chartChangeEventType0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.jfree.data.Range range3 = numberAxis1.getRange();
        try {
            numberAxis1.setRange(1.0d, (double) 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (1.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range3);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setVisible(true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand5 = numberAxis1.getMarkerBand();
        org.junit.Assert.assertNull(markerAxisBand5);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke13 = statisticalBarRenderer12.getBaseStroke();
        java.awt.Paint paint15 = statisticalBarRenderer12.getSeriesOutlinePaint((-1));
        boolean boolean16 = statisticalBarRenderer12.getAutoPopulateSeriesOutlineStroke();
        boolean boolean17 = statisticalBarRenderer12.getBaseSeriesVisible();
        statisticalBarRenderer12.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D20 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot21 = null;
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis23.setPositiveArrowVisible(true);
        numberAxis23.setFixedAutoRange((double) (short) 0);
        numberAxis23.setRangeWithMargins((double) 0, (double) '#');
        numberAxis23.setAutoRange(false);
        java.awt.Font font34 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock35 = new org.jfree.chart.block.LabelBlock("ClassContext", font34);
        labelBlock35.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle();
        boolean boolean39 = labelBlock35.equals((java.lang.Object) textTitle38);
        java.awt.geom.Rectangle2D rectangle2D40 = textTitle38.getBounds();
        statisticalBarRenderer12.drawRangeGridline(graphics2D20, categoryPlot21, (org.jfree.chart.axis.ValueAxis) numberAxis23, rectangle2D40, (double) (-16711681));
        java.awt.geom.Rectangle2D rectangle2D43 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor44 = null;
        java.awt.geom.Point2D point2D45 = org.jfree.chart.util.RectangleAnchor.coordinates(rectangle2D43, rectangleAnchor44);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo46 = null;
        try {
            jFreeChart9.draw(graphics2D11, rectangle2D40, point2D45, chartRenderingInfo46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(paint15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(font34);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(rectangle2D40);
        org.junit.Assert.assertNotNull(point2D45);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = textBlock4.calculateDimensions(graphics2D5);
        size2D6.setWidth((double) (short) 0);
        java.lang.String str9 = size2D6.toString();
        try {
            org.jfree.chart.util.Size2D size2D10 = rectangleConstraint2.calculateConstrainedSize(size2D6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str9.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.text.TextAnchor textAnchor6 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.lang.String str7 = textAnchor6.toString();
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("DatasetRenderingOrder.FORWARD", graphics2D1, (float) (-1L), (float) (byte) 0, textAnchor4, (-1.0d), textAnchor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertNotNull(textAnchor6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str7.equals("TextAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.jfree.data.Range range3 = numberAxis1.getRange();
        double double4 = range3.getUpperBound();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        java.util.ResourceBundle.clearCache();
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.lang.String str5 = textAnchor4.toString();
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.text.TextAnchor textAnchor11 = null;
        org.jfree.chart.text.TextAnchor textAnchor13 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment14 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment15 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement18 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment14, verticalAlignment15, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        textTitle19.setID("ClassContext");
        java.lang.Object obj22 = null;
        columnArrangement18.add((org.jfree.chart.block.Block) textTitle19, obj22);
        boolean boolean24 = textAnchor13.equals((java.lang.Object) textTitle19);
        java.awt.Shape shape25 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D8, 100.0f, (float) (-16711681), textAnchor11, (double) (byte) 100, textAnchor13);
        try {
            java.awt.Shape shape26 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", graphics2D1, 10.0f, (float) ' ', textAnchor4, (double) (byte) 100, textAnchor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str5.equals("TextAnchor.CENTER_RIGHT"));
        org.junit.Assert.assertNotNull(textAnchor13);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(shape25);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape11);
        numberAxis1.setDownArrow(shape11);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int15 = numberTickUnit14.getMinorTickCount();
        numberAxis1.setTickUnit(numberTickUnit14, false, true);
        org.jfree.data.KeyedValues keyedValues19 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset20 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) numberTickUnit14, keyedValues19);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.jfree.chart.util.RectangleInsets rectangleInsets4 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) 10L, (double) (byte) 1, 0.0d);
        java.awt.geom.Rectangle2D rectangle2D5 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D8 = rectangleInsets4.createInsetRectangle(rectangle2D5, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        int int0 = java.awt.Transparency.BITMASK;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block1 = null;
        blockContainer0.add(block1);
        java.awt.Graphics2D graphics2D3 = null;
        java.awt.Font font5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("ClassContext", font5);
        labelBlock6.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        java.awt.Font font10 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock11 = new org.jfree.chart.block.LabelBlock("ClassContext", font10);
        labelBlock11.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        boolean boolean15 = labelBlock11.equals((java.lang.Object) textTitle14);
        java.awt.geom.Rectangle2D rectangle2D16 = textTitle14.getBounds();
        labelBlock6.setBounds(rectangle2D16);
        try {
            blockContainer0.draw(graphics2D3, rectangle2D16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(rectangle2D16);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape6, (java.awt.Paint) color7);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer9 = null;
        try {
            legendItem8.setFillPaintTransformer(gradientPaintTransformer9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'transformer' attribute.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke6 = statisticalBarRenderer5.getBaseStroke();
        java.awt.Paint paint8 = statisticalBarRenderer5.getSeriesOutlinePaint((-1));
        int int9 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer5);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer11 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke12 = statisticalBarRenderer11.getBaseStroke();
        statisticalBarRenderer11.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer11.setBaseSeriesVisible(false, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator18 = null;
        statisticalBarRenderer11.setLegendItemURLGenerator(categorySeriesLabelGenerator18);
        categoryPlot0.setRenderer((int) (short) 1, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer11);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE7;
        java.lang.String str1 = itemLabelAnchor0.toString();
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ItemLabelAnchor.INSIDE7" + "'", str1.equals("ItemLabelAnchor.INSIDE7"));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        org.jfree.chart.axis.NumberAxis numberAxis5 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        org.jfree.chart.text.TextBlock textBlock6 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor10 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape14 = textBlock6.calculateBounds(graphics2D7, 0.0f, (float) (-1), textBlockAnchor10, 0.0f, (float) 10, (double) 10);
        numberAxis5.setLeftArrow(shape14);
        java.awt.Paint paint16 = null;
        java.awt.Stroke stroke17 = org.jfree.chart.axis.Axis.DEFAULT_TICK_MARK_STROKE;
        java.awt.Paint paint18 = null;
        try {
            org.jfree.chart.LegendItem legendItem19 = new org.jfree.chart.LegendItem("[size=1]", "", "3", "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", shape14, paint16, stroke17, paint18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'fillPaint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor10);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNotNull(stroke17);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setBaseSeriesVisible(false, false);
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        int int9 = categoryPlot8.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = categoryPlot8.getRangeAxisEdge();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent11 = null;
        categoryPlot8.rendererChanged(rendererChangeEvent11);
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("ClassContext", font14);
        labelBlock15.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        boolean boolean19 = labelBlock15.equals((java.lang.Object) textTitle18);
        java.awt.geom.Rectangle2D rectangle2D20 = textTitle18.getBounds();
        try {
            statisticalBarRenderer0.drawDomainGridline(graphics2D7, categoryPlot8, rectangle2D20, (double) 2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(rectangle2D20);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.title.TextTitle textTitle10 = new org.jfree.chart.title.TextTitle();
        textTitle10.setURLText("hi!");
        jFreeChart9.addSubtitle((org.jfree.chart.title.Title) textTitle10);
        org.jfree.chart.title.Title title15 = null;
        try {
            jFreeChart9.addSubtitle((-16711681), title15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        try {
            java.awt.Color color1 = java.awt.Color.decode("LegendItemEntity: seriesKey=, dataset=null");
            org.junit.Assert.fail("Expected exception of type java.lang.NumberFormatException; message: For input string: \"LegendItemEntity: seriesKey=, dataset=null\"");
        } catch (java.lang.NumberFormatException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        java.util.Locale locale0 = null;
        try {
            org.jfree.chart.axis.TickUnitSource tickUnitSource1 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color8, true);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition11 = null;
        try {
            statisticalBarRenderer0.setBasePositiveItemLabelPosition(itemLabelPosition11, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'position' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        org.jfree.chart.util.VerticalAlignment verticalAlignment0 = org.jfree.chart.title.Title.DEFAULT_VERTICAL_ALIGNMENT;
        org.junit.Assert.assertNotNull(verticalAlignment0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.jfree.chart.LegendItemCollection legendItemCollection0 = new org.jfree.chart.LegendItemCollection();
        java.awt.Shape shape7 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color8 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem9 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape7, (java.awt.Paint) color8);
        legendItemCollection0.add(legendItem9);
        org.junit.Assert.assertNotNull(shape7);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock0.setLineAlignment(horizontalAlignment3);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(horizontalAlignment3);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        java.lang.Class class1 = null;
        java.lang.Class class2 = null;
        java.lang.Object obj3 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("ClassContext", class1, class2);
        org.junit.Assert.assertNull(obj3);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo9, point2D10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot0.getOrientation();
        categoryPlot0.setForegroundAlpha((float) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(plotOrientation12);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        java.util.Locale locale1 = null;
//        java.lang.Class class2 = null;
//        java.lang.ClassLoader classLoader3 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class2);
//        java.util.ResourceBundle.Control control4 = null;
//        try {
//            java.util.ResourceBundle resourceBundle5 = java.util.ResourceBundle.getBundle("java.awt.Color[r=192,g=0,b=0]", locale1, classLoader3, control4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertNotNull(classLoader3);
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer4 = null;
        categoryPlot0.setRenderer((int) (byte) 100, categoryItemRenderer4);
        double double6 = categoryPlot0.getAnchorValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Font font3 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color4 = java.awt.Color.cyan;
        int int5 = color4.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder6 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color4);
        org.jfree.chart.text.TextFragment textFragment7 = new org.jfree.chart.text.TextFragment("ClassContext", font3, (java.awt.Paint) color4);
        java.awt.Paint paint8 = null;
        try {
            textBlock0.addLine("hi!", font3, paint8);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNotNull(color4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-16711681) + "'", int5 == (-16711681));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = org.jfree.chart.util.RectangleEdge.TOP;
        org.junit.Assert.assertNotNull(rectangleEdge0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        java.awt.Image image0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE;
        org.junit.Assert.assertNull(image0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_RANGE_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions0, categoryLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Shape shape5 = statisticalBarRenderer0.getSeriesShape((int) (byte) 100);
        java.awt.Font font7 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color8 = java.awt.Color.cyan;
        int int9 = color8.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder10 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color8);
        org.jfree.chart.text.TextFragment textFragment11 = new org.jfree.chart.text.TextFragment("ClassContext", font7, (java.awt.Paint) color8);
        statisticalBarRenderer0.setBaseItemLabelFont(font7, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(font7);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-16711681) + "'", int9 == (-16711681));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer10 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke11 = statisticalBarRenderer10.getBaseStroke();
        java.awt.Paint paint13 = statisticalBarRenderer10.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke15 = statisticalBarRenderer14.getBaseStroke();
        statisticalBarRenderer10.setBaseStroke(stroke15, false);
        jFreeChart9.setBorderStroke(stroke15);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer20 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator21 = statisticalBarRenderer20.getLegendItemToolTipGenerator();
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        int int24 = categoryPlot23.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot23.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer27 = null;
        categoryPlot23.setRenderer((int) (byte) 100, categoryItemRenderer27);
        boolean boolean29 = categoryPlot23.isDomainGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis31 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean32 = numberAxis31.isVerticalTickLabels();
        org.jfree.data.Range range33 = numberAxis31.getRange();
        org.jfree.chart.plot.ValueMarker valueMarker35 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation38 = null;
        categoryPlot36.setDomainAxisLocation(15, axisLocation38, true);
        categoryPlot36.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset42 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer43 = categoryPlot36.getRendererForDataset(categoryDataset42);
        java.awt.Stroke stroke44 = categoryPlot36.getOutlineStroke();
        valueMarker35.setStroke(stroke44);
        valueMarker35.setLabel("ThreadContext");
        double double48 = valueMarker35.getValue();
        java.awt.Font font50 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock51 = new org.jfree.chart.block.LabelBlock("ClassContext", font50);
        labelBlock51.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle54 = new org.jfree.chart.title.TextTitle();
        boolean boolean55 = labelBlock51.equals((java.lang.Object) textTitle54);
        java.awt.geom.Rectangle2D rectangle2D56 = textTitle54.getBounds();
        statisticalBarRenderer20.drawRangeMarker(graphics2D22, categoryPlot23, (org.jfree.chart.axis.ValueAxis) numberAxis31, (org.jfree.chart.plot.Marker) valueMarker35, rectangle2D56);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo58 = null;
        try {
            jFreeChart9.draw(graphics2D19, rectangle2D56, chartRenderingInfo58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNull(paint13);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator21);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNull(categoryItemRenderer43);
        org.junit.Assert.assertNotNull(stroke44);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + (-1.0d) + "'", double48 == (-1.0d));
        org.junit.Assert.assertNotNull(font50);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(rectangle2D56);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        int int0 = java.awt.Transparency.TRANSLUCENT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 3 + "'", int0 == 3);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        try {
            org.jfree.data.Range range1 = org.jfree.data.general.DatasetUtilities.iterateXYRangeBounds(xYDataset0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.lang.String str5 = textAnchor4.toString();
        try {
            java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.text.TextUtilities.drawAlignedString("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", graphics2D1, 1.0f, (float) (short) 1, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str5.equals("TextAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        float float0 = org.jfree.chart.JFreeChart.DEFAULT_BACKGROUND_IMAGE_ALPHA;
        org.junit.Assert.assertTrue("'" + float0 + "' != '" + 0.5f + "'", float0 == 0.5f);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRendererForDataset(categoryDataset6);
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = null;
        try {
            categoryPlot0.setInsets(rectangleInsets8, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'insets' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer7);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        categoryPlot0.setAnchorValue((double) (short) 0);
        categoryPlot0.setWeight((int) (byte) 10);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset13 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list14 = defaultStatisticalCategoryDataset13.getColumnKeys();
        categoryPlot0.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset13);
        categoryPlot0.setBackgroundImageAlignment(0);
        org.junit.Assert.assertNotNull(list14);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke5 = statisticalBarRenderer0.getBaseOutlineStroke();
        boolean boolean6 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation11 = null;
        categoryPlot9.setDomainAxisLocation(15, axisLocation11, true);
        categoryPlot9.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset15 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot9.getRendererForDataset(categoryDataset15);
        org.jfree.chart.util.Layer layer18 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection19 = categoryPlot9.getDomainMarkers((int) '#', layer18);
        try {
            statisticalBarRenderer0.addAnnotation(categoryAnnotation8, layer18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertNull(categoryItemRenderer16);
        org.junit.Assert.assertNotNull(layer18);
        org.junit.Assert.assertNull(collection19);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        java.awt.Paint[] paintArray0 = org.jfree.chart.ChartColor.createDefaultPaintArray();
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_BLUE;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.plot.Plot.DEFAULT_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        boolean boolean0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABELS_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        java.util.Locale locale1 = null;
        java.util.ResourceBundle.Control control2 = null;
        try {
            java.util.ResourceBundle resourceBundle3 = java.util.ResourceBundle.getBundle("java.awt.Color[r=192,g=0,b=0]", locale1, control2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        double double1 = numberTickUnit0.getSize();
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (-1L), numberFormat1, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        org.jfree.chart.text.TextLine textLine1 = new org.jfree.chart.text.TextLine("hi!");
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.awt.Paint paint2 = org.jfree.chart.plot.CategoryPlot.DEFAULT_GRIDLINE_PAINT;
        boolean boolean3 = datasetRenderingOrder0.equals((java.lang.Object) paint2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertNotNull(paint2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke5 = statisticalBarRenderer4.getBaseStroke();
        statisticalBarRenderer0.setBaseStroke(stroke5, false);
        org.jfree.chart.LegendItemCollection legendItemCollection8 = statisticalBarRenderer0.getLegendItems();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertNotNull(legendItemCollection8);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        double double1 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05d + "'", double1 == 0.05d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        statisticalBarRenderer0.setDrawBarOutline(true);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_BLUE;
        try {
            statisticalBarRenderer0.setSeriesFillPaint((-1), (java.awt.Paint) color8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(color8);
    }

//    @Test
//    public void test198() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test198");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getLibraries();
//        org.jfree.chart.ui.ProjectInfo projectInfo3 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo3.setLicenceName("");
//        org.jfree.chart.ui.Library[] libraryArray6 = projectInfo3.getLibraries();
//        projectInfo3.setVersion("ClassContext");
//        projectInfo0.addLibrary((org.jfree.chart.ui.Library) projectInfo3);
//        projectInfo0.setLicenceText("java.awt.Color[r=192,g=0,b=0]");
//        org.jfree.chart.ui.Library[] libraryArray12 = projectInfo0.getLibraries();
//        java.lang.String str13 = projectInfo0.getName();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
//        org.junit.Assert.assertNotNull(libraryArray2);
//        org.junit.Assert.assertNotNull(projectInfo3);
//        org.junit.Assert.assertNotNull(libraryArray6);
//        org.junit.Assert.assertNotNull(libraryArray12);
//        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "JFreeChart" + "'", str13.equals("JFreeChart"));
//    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.util.Locale locale1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("ClassContext", locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        java.awt.Font font1 = org.jfree.chart.JFreeChart.DEFAULT_TITLE_FONT;
        org.jfree.chart.plot.Plot plot2 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart4 = new org.jfree.chart.JFreeChart("hi!", font1, plot2, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        double double11 = rectangleInsets8.getRight();
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setBaseSeriesVisible(false, false);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = null;
        statisticalBarRenderer0.setLegendItemURLGenerator(categorySeriesLabelGenerator7);
        statisticalBarRenderer0.setBaseItemLabelsVisible(false, true);
        org.junit.Assert.assertNotNull(stroke1);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double3 = categoryAxis0.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int5 = numberTickUnit4.getMinorTickCount();
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) numberTickUnit4);
        java.awt.Paint paint8 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) (byte) 10);
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) '#');
        float float11 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + float11 + "' != '" + 32.0f + "'", float11 == 32.0f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "ItemLabelAnchor.INSIDE7");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = java.awt.Color.white;
        statisticalBarRenderer0.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        java.awt.Graphics2D graphics2D10 = null;
        java.awt.Font font12 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock13 = new org.jfree.chart.block.LabelBlock("ClassContext", font12);
        labelBlock13.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle16 = new org.jfree.chart.title.TextTitle();
        boolean boolean17 = labelBlock13.equals((java.lang.Object) textTitle16);
        java.awt.geom.Rectangle2D rectangle2D18 = textTitle16.getBounds();
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity21 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D18, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "Size2D[width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation24 = null;
        categoryPlot22.setDomainAxisLocation(15, axisLocation24, true);
        categoryPlot22.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset28 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer29 = categoryPlot22.getRendererForDataset(categoryDataset28);
        org.jfree.chart.util.Layer layer31 = org.jfree.chart.util.Layer.FOREGROUND;
        java.util.Collection collection32 = categoryPlot22.getDomainMarkers((int) '#', layer31);
        try {
            java.lang.Object obj33 = legendTitle9.draw(graphics2D10, rectangle2D18, (java.lang.Object) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(rectangle2D18);
        org.junit.Assert.assertNull(categoryItemRenderer29);
        org.junit.Assert.assertNotNull(layer31);
        org.junit.Assert.assertNull(collection32);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.jfree.data.KeyedValues keyedValues1 = null;
        try {
            org.jfree.data.category.CategoryDataset categoryDataset2 = org.jfree.data.general.DatasetUtilities.createCategoryDataset((java.lang.Comparable) 10, keyedValues1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'rowData' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.awt.Shape shape0 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_SHAPE;
        org.junit.Assert.assertNotNull(shape0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder0 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str1 = datasetRenderingOrder0.toString();
        java.lang.Object obj2 = null;
        boolean boolean3 = datasetRenderingOrder0.equals(obj2);
        org.junit.Assert.assertNotNull(datasetRenderingOrder0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str1.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        org.jfree.chart.plot.Plot plot11 = jFreeChart9.getPlot();
        java.awt.Stroke stroke12 = jFreeChart9.getBorderStroke();
        org.jfree.chart.title.LegendTitle legendTitle13 = null;
        try {
            jFreeChart9.addLegend(legendTitle13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'subtitle' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        java.awt.Paint paint0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("ClassContext", font1);
        labelBlock2.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        labelBlock2.setToolTipText("");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) labelBlock2);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.data.Range range10 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint11 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range10);
        double double12 = rectangleConstraint11.getWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType13 = rectangleConstraint11.getWidthConstraintType();
        try {
            org.jfree.chart.util.Size2D size2D14 = labelBlock2.arrange(graphics2D8, rectangleConstraint11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType13);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("ClassContext", font1);
        labelBlock2.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        labelBlock2.setToolTipText("");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) labelBlock2);
        labelBlock2.setWidth(10.0d);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator6 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer0.setLegendItemToolTipGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator6);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("CategoryAnchor.MIDDLE", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        int int1 = categoryPlot0.getWeight();
//        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
//        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
//        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
//        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
//        java.awt.geom.Point2D point2D10 = null;
//        categoryPlot0.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo9, point2D10);
//        boolean boolean12 = categoryPlot0.isDomainZoomable();
//        java.awt.Graphics2D graphics2D13 = null;
//        java.awt.Font font15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
//        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("ClassContext", font15);
//        labelBlock16.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
//        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
//        boolean boolean20 = labelBlock16.equals((java.lang.Object) textTitle19);
//        java.awt.geom.Rectangle2D rectangle2D21 = textTitle19.getBounds();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
//        boolean boolean24 = categoryPlot0.render(graphics2D13, rectangle2D21, (int) (byte) 100, plotRenderingInfo23);
//        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation27 = null;
//        categoryPlot25.setDomainAxisLocation(15, axisLocation27, true);
//        categoryPlot25.clearRangeAxes();
//        categoryPlot25.setAnchorValue((double) (short) 0);
//        org.jfree.chart.ui.ProjectInfo projectInfo33 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str34 = projectInfo33.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray35 = projectInfo33.getLibraries();
//        java.lang.String str36 = projectInfo33.getLicenceText();
//        java.awt.Image image37 = projectInfo33.getLogo();
//        categoryPlot25.setBackgroundImage(image37);
//        java.awt.Paint paint39 = categoryPlot25.getDomainGridlinePaint();
//        categoryPlot0.setNoDataMessagePaint(paint39);
//        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
//        org.junit.Assert.assertNotNull(rectangleEdge2);
//        org.junit.Assert.assertNotNull(paint3);
//        org.junit.Assert.assertNotNull(rectangleEdge4);
//        org.junit.Assert.assertNotNull(rectangleEdge6);
//        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
//        org.junit.Assert.assertNotNull(font15);
//        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
//        org.junit.Assert.assertNotNull(rectangle2D21);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(projectInfo33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str34.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
//        org.junit.Assert.assertNotNull(libraryArray35);
//        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "ThreadContext" + "'", str36.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(image37);
//        org.junit.Assert.assertNotNull(paint39);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        textTitle1.setID("RectangleEdge.RIGHT");
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
        projectInfo0.setLicenceName("");
        projectInfo0.setInfo("ThreadContext");
        java.lang.String str5 = projectInfo0.getInfo();
        org.junit.Assert.assertNotNull(projectInfo0);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "ThreadContext" + "'", str5.equals("ThreadContext"));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer0.setBase(0.05d);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator6 = statisticalBarRenderer0.getLegendItemURLGenerator();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator6);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = org.jfree.chart.axis.CategoryLabelPositions.STANDARD;
        org.junit.Assert.assertNotNull(categoryLabelPositions0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.data.Range range5 = rectangleConstraint2.getHeightRange();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = rectangleConstraint2.toFixedHeight(0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNull(range5);
        org.junit.Assert.assertNotNull(rectangleConstraint7);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double9 = categoryAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int11 = numberTickUnit10.getMinorTickCount();
        java.awt.Font font12 = categoryAxis6.getTickLabelFont((java.lang.Comparable) numberTickUnit10);
        categoryPlot0.setNoDataMessageFont(font12);
        int int14 = categoryPlot0.getDatasetCount();
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 1, (int) '4');
        categoryPlot0.clearAnnotations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo4 = new org.jfree.chart.ui.BasicProjectInfo("DatasetRenderingOrder.FORWARD", "DatasetRenderingOrder.FORWARD", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "hi!");
        java.lang.String str5 = basicProjectInfo4.getLicenceName();
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str5.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setURLText("hi!");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment3 = null;
        try {
            textTitle0.setHorizontalAlignment(horizontalAlignment3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'alignment' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        categoryPlot0.setAnchorValue((double) (short) 0);
        categoryPlot0.setWeight((int) (byte) 10);
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        org.jfree.chart.text.TextBlock textBlock12 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor16 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape20 = textBlock12.calculateBounds(graphics2D13, 0.0f, (float) (-1), textBlockAnchor16, 0.0f, (float) 10, (double) 10);
        numberAxis11.setLeftArrow(shape20);
        org.jfree.chart.axis.NumberAxis numberAxis22 = new org.jfree.chart.axis.NumberAxis();
        org.jfree.chart.axis.NumberAxis numberAxis24 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis24.setVisible(true);
        numberAxis24.setRange((double) (short) -1, 10.0d);
        double double30 = numberAxis24.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit31 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str32 = numberTickUnit31.toString();
        boolean boolean34 = numberTickUnit31.equals((java.lang.Object) 0L);
        numberAxis24.setTickUnit(numberTickUnit31, true, false);
        org.jfree.chart.axis.NumberAxis numberAxis39 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis39.setTickMarkOutsideLength((float) (short) 100);
        numberAxis39.setLabelAngle((double) '4');
        org.jfree.chart.axis.ValueAxis[] valueAxisArray44 = new org.jfree.chart.axis.ValueAxis[] { numberAxis11, numberAxis22, numberAxis24, numberAxis39 };
        categoryPlot0.setRangeAxes(valueAxisArray44);
        org.junit.Assert.assertNotNull(textBlockAnchor16);
        org.junit.Assert.assertNotNull(shape20);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "[size=1]" + "'", str32.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(valueAxisArray44);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.awt.Graphics2D graphics2D0 = null;
        org.jfree.chart.text.G2TextMeasurer g2TextMeasurer1 = new org.jfree.chart.text.G2TextMeasurer(graphics2D0);
        try {
            float float5 = g2TextMeasurer1.getStringWidth("JFreeChart", (int) '#', (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle1.setFont(font2);
        org.jfree.chart.text.TextFragment textFragment4 = new org.jfree.chart.text.TextFragment("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font2);
        float float5 = textFragment4.getBaselineOffset();
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.CENTER_RIGHT;
        java.lang.String str10 = textAnchor9.toString();
        try {
            textFragment4.draw(graphics2D6, (float) 0, 0.0f, textAnchor9, 100.0f, (float) 100, (double) 32.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "TextAnchor.CENTER_RIGHT" + "'", str10.equals("TextAnchor.CENTER_RIGHT"));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE10;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        jFreeChart9.clearSubtitles();
        jFreeChart9.setBackgroundImageAlpha(0.5f);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.title.TextTitle textTitle14 = new org.jfree.chart.title.TextTitle();
        textTitle14.setWidth((double) '4');
        java.lang.Object obj17 = textTitle14.clone();
        double double18 = textTitle14.getContentYOffset();
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis19.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis19.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.axis.AxisState axisState26 = null;
        java.awt.Font font28 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("ClassContext", font28);
        labelBlock29.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle();
        boolean boolean33 = labelBlock29.equals((java.lang.Object) textTitle32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle32.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot35 = new org.jfree.chart.plot.CategoryPlot();
        int int36 = categoryPlot35.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge37 = categoryPlot35.getRangeAxisEdge();
        java.awt.Paint paint38 = categoryPlot35.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot35.getRangeAxisEdge();
        java.util.List list40 = categoryAxis19.refreshTicks(graphics2D25, axisState26, rectangle2D34, rectangleEdge39);
        textTitle14.setBounds(rectangle2D34);
        try {
            jFreeChart9.draw(graphics2D13, rectangle2D34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge37);
        org.junit.Assert.assertNotNull(paint38);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertNotNull(list40);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        java.awt.Color color0 = java.awt.Color.GREEN;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", graphics2D1, (float) 1L, (float) 10L, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        textTitle6.setID("ClassContext");
        java.lang.Object obj9 = null;
        columnArrangement5.add((org.jfree.chart.block.Block) textTitle6, obj9);
        boolean boolean11 = textAnchor0.equals((java.lang.Object) textTitle6);
        double double12 = textTitle6.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = textTitle6.getHorizontalAlignment();
        java.lang.Object obj14 = textTitle6.clone();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertNotNull(obj14);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit((double) (byte) 0, numberFormat1, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.annotations.CategoryAnnotation categoryAnnotation1 = null;
        try {
            barRenderer0.addAnnotation(categoryAnnotation1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'annotation' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("ClassContext", font1);
        labelBlock2.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        boolean boolean6 = labelBlock2.equals((java.lang.Object) textTitle5);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle5.getBounds();
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity10 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D7, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "Size2D[width=0.0, height=0.0]");
        java.lang.String str11 = tickLabelEntity10.getToolTipText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str11.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle1.setFont(font2);
        org.jfree.chart.text.TextLine textLine4 = new org.jfree.chart.text.TextLine("java.awt.Color[r=192,g=0,b=0]", font2);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine();
        boolean boolean7 = textLine5.equals((java.lang.Object) (-1.0d));
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font10 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle9.setFont(font10);
        org.jfree.chart.text.TextFragment textFragment12 = new org.jfree.chart.text.TextFragment("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font10);
        textLine5.addFragment(textFragment12);
        textLine4.removeFragment(textFragment12);
        org.junit.Assert.assertNotNull(font2);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(font10);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        categoryPlot0.setAnchorValue((double) (byte) 100, true);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.junit.Assert.assertNull(collection6);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.LegendItem legendItem4 = statisticalBarRenderer0.getLegendItem((int) (short) 100, (int) (byte) 10);
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator5 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(legendItem4);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator5);
    }

//    @Test
//    public void test238() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test238");
//        java.lang.Class class0 = null;
//        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
//        org.jfree.chart.util.ObjectUtilities.setClassLoader(classLoader1);
//        org.junit.Assert.assertNotNull(classLoader1);
//    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.util.List list1 = textBlock0.getLines();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition7 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor5, textBlockAnchor6);
        textBlock0.draw(graphics2D2, (float) (byte) 10, (float) (byte) 1, textBlockAnchor6, (float) (byte) 10, (float) (byte) 10, 0.0d);
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.util.Size2D size2D13 = textBlock0.calculateDimensions(graphics2D12);
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(size2D13);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Color color8 = org.jfree.chart.ChartColor.LIGHT_YELLOW;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color8, true);
        java.awt.Font font12 = null;
        statisticalBarRenderer0.setSeriesItemLabelFont(0, font12, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color8);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double3 = categoryAxis0.getLabelAngle();
        double double4 = categoryAxis0.getLowerMargin();
        double double5 = categoryAxis0.getUpperMargin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.05d + "'", double4 == 0.05d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

//    @Test
//    public void test242() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test242");
//        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
//        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
//        categoryPlot0.clearRangeAxes();
//        categoryPlot0.setAnchorValue((double) (short) 0);
//        org.jfree.chart.ui.ProjectInfo projectInfo8 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str9 = projectInfo8.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray10 = projectInfo8.getLibraries();
//        java.lang.String str11 = projectInfo8.getLicenceText();
//        java.awt.Image image12 = projectInfo8.getLogo();
//        categoryPlot0.setBackgroundImage(image12);
//        java.awt.Paint paint14 = categoryPlot0.getDomainGridlinePaint();
//        categoryPlot0.clearAnnotations();
//        int int16 = categoryPlot0.getDatasetCount();
//        org.junit.Assert.assertNotNull(projectInfo8);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str9.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
//        org.junit.Assert.assertNotNull(libraryArray10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "ThreadContext" + "'", str11.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(image12);
//        org.junit.Assert.assertNotNull(paint14);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        java.awt.Shape shape1 = org.jfree.chart.util.ShapeUtilities.createDiamond(0.0f);
        org.junit.Assert.assertNotNull(shape1);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        boolean boolean8 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator11);
        java.awt.Shape shape14 = statisticalBarRenderer0.getSeriesShape((int) (short) 100);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNull(shape14);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setForegroundAlpha((float) 0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke6 = statisticalBarRenderer5.getBaseStroke();
        java.awt.Paint paint8 = statisticalBarRenderer5.getSeriesOutlinePaint((-1));
        int int9 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer5);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder10 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1) + "'", int9 == (-1));
        org.junit.Assert.assertNotNull(datasetRenderingOrder10);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        int int3 = categoryPlot2.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot2.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer6 = null;
        categoryPlot2.setRenderer((int) (byte) 100, categoryItemRenderer6);
        boolean boolean8 = categoryPlot2.isDomainGridlinesVisible();
        org.jfree.chart.util.SortOrder sortOrder9 = categoryPlot2.getRowRenderingOrder();
        categoryPlot0.setColumnRenderingOrder(sortOrder9);
        org.jfree.chart.axis.AxisLocation axisLocation11 = categoryPlot0.getRangeAxisLocation();
        double double12 = categoryPlot0.getRangeCrosshairValue();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(sortOrder9);
        org.junit.Assert.assertNotNull(axisLocation11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setForegroundAlpha((float) 0);
        java.awt.Color color5 = java.awt.Color.darkGray;
        float[] floatArray12 = new float[] { 255, (-1L), 2, (short) 10, '4', 1 };
        float[] floatArray13 = color5.getRGBColorComponents(floatArray12);
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color5);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer4 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke5 = statisticalBarRenderer4.getBaseStroke();
        statisticalBarRenderer0.setBaseStroke(stroke5, false);
        boolean boolean8 = statisticalBarRenderer0.getAutoPopulateSeriesFillPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        try {
            statisticalBarRenderer0.setPlot(categoryPlot9);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'plot' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        java.awt.Font font5 = statisticalBarRenderer0.getBaseItemLabelFont();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer0.setSeriesFillPaint(100, paint7, true);
        java.awt.Graphics2D graphics2D10 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState12 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo11);
        double double13 = categoryItemRendererState12.getSeriesRunningTotal();
        java.awt.Font font15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("ClassContext", font15);
        labelBlock16.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        boolean boolean20 = labelBlock16.equals((java.lang.Object) textTitle19);
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle19.getBounds();
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity24 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D21, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "Size2D[width=0.0, height=0.0]");
        org.jfree.chart.plot.CategoryPlot categoryPlot25 = new org.jfree.chart.plot.CategoryPlot();
        int int26 = categoryPlot25.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge27 = categoryPlot25.getRangeAxisEdge();
        java.awt.Paint paint28 = categoryPlot25.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot25.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot25.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo34 = null;
        java.awt.geom.Point2D point2D35 = null;
        categoryPlot25.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo34, point2D35);
        boolean boolean37 = categoryPlot25.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis38 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis38.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        int int42 = categoryAxis38.getCategoryLabelPositionOffset();
        boolean boolean43 = categoryAxis38.isTickMarksVisible();
        org.jfree.chart.axis.ValueAxis valueAxis44 = null;
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset45 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list46 = defaultStatisticalCategoryDataset45.getColumnKeys();
        try {
            statisticalBarRenderer0.drawItem(graphics2D10, categoryItemRendererState12, rectangle2D21, categoryPlot25, categoryAxis38, valueAxis44, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset45, (-16711681), (-1), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -16711681");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge27);
        org.junit.Assert.assertNotNull(paint28);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(list46);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        jFreeChart9.clearSubtitles();
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo13 = null;
        try {
            java.awt.image.BufferedImage bufferedImage14 = jFreeChart9.createBufferedImage((-16711681), (-16711681), chartRenderingInfo13);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (-16711681) and height (-16711681) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit0 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        java.lang.String str1 = numberTickUnit0.toString();
        boolean boolean3 = numberTickUnit0.equals((java.lang.Object) 0L);
        double double4 = numberTickUnit0.getSize();
        org.junit.Assert.assertNotNull(numberTickUnit0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "[size=1]" + "'", str1.equals("[size=1]"));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double9 = categoryAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int11 = numberTickUnit10.getMinorTickCount();
        java.awt.Font font12 = categoryAxis6.getTickLabelFont((java.lang.Comparable) numberTickUnit10);
        categoryPlot0.setNoDataMessageFont(font12);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke15 = statisticalBarRenderer14.getBaseStroke();
        java.awt.Paint paint17 = statisticalBarRenderer14.getSeriesOutlinePaint((-1));
        java.awt.Shape shape19 = statisticalBarRenderer14.getSeriesShape((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        statisticalBarRenderer14.setGradientPaintTransformer(gradientPaintTransformer20);
        int int22 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        org.jfree.chart.JFreeChart jFreeChart23 = new org.jfree.chart.JFreeChart((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo26 = null;
        try {
            jFreeChart23.handleClick((int) (short) 1, 10, chartRenderingInfo26);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("ClassContext", font1);
        labelBlock2.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        labelBlock2.setToolTipText("");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) labelBlock2);
        labelBlock2.setToolTipText("hi!");
        labelBlock2.setMargin((double) 15, (double) 15, (double) (byte) 1, 0.0d);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        java.awt.Color color6 = java.awt.Color.darkGray;
        float[] floatArray13 = new float[] { 255, (-1L), 2, (short) 10, '4', 1 };
        float[] floatArray14 = color6.getRGBColorComponents(floatArray13);
        float[] floatArray15 = java.awt.Color.RGBtoHSB((int) (short) 1, (int) (short) 0, 0, floatArray13);
        float[] floatArray16 = java.awt.Color.RGBtoHSB(1, 2, (-16711681), floatArray15);
        org.junit.Assert.assertNotNull(color6);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke7 = statisticalBarRenderer6.getBaseStroke();
        java.awt.Paint paint9 = statisticalBarRenderer6.getSeriesOutlinePaint((-1));
        boolean boolean10 = statisticalBarRenderer6.getAutoPopulateSeriesOutlineStroke();
        categoryPlot0.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer6, true);
        java.awt.Shape shape14 = statisticalBarRenderer6.lookupSeriesShape((int) 'a');
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator15 = statisticalBarRenderer6.getBaseItemLabelGenerator();
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(shape14);
        org.junit.Assert.assertNull(categoryItemLabelGenerator15);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape11);
        numberAxis1.setDownArrow(shape11);
        org.jfree.chart.axis.NumberTickUnit numberTickUnit14 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int15 = numberTickUnit14.getMinorTickCount();
        numberAxis1.setTickUnit(numberTickUnit14, false, true);
        double double19 = numberTickUnit14.getSize();
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertNotNull(numberTickUnit14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.0d + "'", double19 == 1.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setURLText("java.awt.Color[r=192,g=0,b=0]");
        textTitle0.setExpandToFitSpace(false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        java.lang.Number[] numberArray2 = new java.lang.Number[] {};
        java.lang.Number[] numberArray3 = new java.lang.Number[] {};
        java.lang.Number[] numberArray4 = new java.lang.Number[] {};
        java.lang.Number[] numberArray5 = new java.lang.Number[] {};
        java.lang.Number[] numberArray6 = new java.lang.Number[] {};
        java.lang.Number[] numberArray7 = new java.lang.Number[] {};
        java.lang.Number[][] numberArray8 = new java.lang.Number[][] { numberArray2, numberArray3, numberArray4, numberArray5, numberArray6, numberArray7 };
        org.jfree.data.category.CategoryDataset categoryDataset9 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("", "TextAnchor.CENTER_RIGHT", numberArray8);
        org.jfree.data.Range range10 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset9);
        org.junit.Assert.assertNotNull(numberArray2);
        org.junit.Assert.assertNotNull(numberArray3);
        org.junit.Assert.assertNotNull(numberArray4);
        org.junit.Assert.assertNotNull(numberArray5);
        org.junit.Assert.assertNotNull(numberArray6);
        org.junit.Assert.assertNotNull(numberArray7);
        org.junit.Assert.assertNotNull(numberArray8);
        org.junit.Assert.assertNotNull(categoryDataset9);
        org.junit.Assert.assertNull(range10);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator2 = null;
        barRenderer0.setSeriesToolTipGenerator((int) ' ', categoryToolTipGenerator2, false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        java.awt.Font font1 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_FONT;
        java.awt.Color color2 = java.awt.Color.cyan;
        int int3 = color2.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder4 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color2);
        org.jfree.chart.text.TextFragment textFragment5 = new org.jfree.chart.text.TextFragment("ClassContext", font1, (java.awt.Paint) color2);
        float float6 = textFragment5.getBaselineOffset();
        java.awt.Graphics2D graphics2D7 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor8 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition10 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor8, textAnchor9);
        try {
            float float11 = textFragment5.calculateBaselineOffset(graphics2D7, textAnchor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16711681) + "'", int3 == (-16711681));
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.0f + "'", float6 == 0.0f);
        org.junit.Assert.assertNotNull(itemLabelAnchor8);
        org.junit.Assert.assertNotNull(textAnchor9);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = java.awt.Color.white;
        statisticalBarRenderer0.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        org.jfree.chart.block.BlockContainer blockContainer10 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block11 = null;
        blockContainer10.add(block11);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        textTitle13.setWidth((double) '4');
        java.lang.Object obj16 = textTitle13.clone();
        double double17 = textTitle13.getContentYOffset();
        blockContainer10.add((org.jfree.chart.block.Block) textTitle13);
        legendTitle9.setWrapper(blockContainer10);
        java.awt.Graphics2D graphics2D20 = null;
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("ClassContext", font22);
        labelBlock23.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        boolean boolean27 = labelBlock23.equals((java.lang.Object) textTitle26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot29 = new org.jfree.chart.plot.CategoryPlot();
        int int30 = categoryPlot29.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge31 = categoryPlot29.getRangeAxisEdge();
        double double32 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D28, rectangleEdge31);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment33 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment34 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement37 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment33, verticalAlignment34, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle38 = new org.jfree.chart.title.TextTitle();
        textTitle38.setID("ClassContext");
        java.lang.Object obj41 = null;
        columnArrangement37.add((org.jfree.chart.block.Block) textTitle38, obj41);
        org.jfree.chart.util.VerticalAlignment verticalAlignment43 = textTitle38.getVerticalAlignment();
        org.jfree.chart.plot.CategoryPlot categoryPlot44 = new org.jfree.chart.plot.CategoryPlot();
        int int45 = categoryPlot44.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge46 = categoryPlot44.getRangeAxisEdge();
        categoryPlot44.setForegroundAlpha((float) 0);
        java.awt.Color color49 = java.awt.Color.darkGray;
        float[] floatArray56 = new float[] { 255, (-1L), 2, (short) 10, '4', 1 };
        float[] floatArray57 = color49.getRGBColorComponents(floatArray56);
        categoryPlot44.setBackgroundPaint((java.awt.Paint) color49);
        boolean boolean59 = verticalAlignment43.equals((java.lang.Object) categoryPlot44);
        try {
            java.lang.Object obj60 = blockContainer10.draw(graphics2D20, rectangle2D28, (java.lang.Object) categoryPlot44);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(obj16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0d + "'", double17 == 1.0d);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(verticalAlignment43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge46);
        org.junit.Assert.assertNotNull(color49);
        org.junit.Assert.assertNotNull(floatArray56);
        org.junit.Assert.assertNotNull(floatArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double9 = categoryAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int11 = numberTickUnit10.getMinorTickCount();
        java.awt.Font font12 = categoryAxis6.getTickLabelFont((java.lang.Comparable) numberTickUnit10);
        categoryPlot0.setNoDataMessageFont(font12);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke15 = statisticalBarRenderer14.getBaseStroke();
        java.awt.Paint paint17 = statisticalBarRenderer14.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer18 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke19 = statisticalBarRenderer18.getBaseStroke();
        statisticalBarRenderer14.setBaseStroke(stroke19, false);
        categoryPlot0.setRangeGridlineStroke(stroke19);
        java.lang.Object obj23 = categoryPlot0.clone();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNotNull(stroke19);
        org.junit.Assert.assertNotNull(obj23);
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        java.lang.Class class0 = null;
//        java.lang.ClassLoader classLoader1 = org.jfree.chart.util.ObjectUtilities.getClassLoader(class0);
//        java.util.ResourceBundle.clearCache(classLoader1);
//        org.junit.Assert.assertNotNull(classLoader1);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        numberAxis9.setVisible(true);
        categoryPlot0.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        org.jfree.chart.plot.CategoryMarker categoryMarker15 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        int int17 = categoryPlot16.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot16.getRangeAxisEdge();
        java.awt.Paint paint19 = categoryPlot16.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot16.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot16.getDomainAxisEdge(0);
        org.jfree.chart.plot.ValueMarker valueMarker25 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot26 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation28 = null;
        categoryPlot26.setDomainAxisLocation(15, axisLocation28, true);
        categoryPlot26.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset32 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer33 = categoryPlot26.getRendererForDataset(categoryDataset32);
        java.awt.Stroke stroke34 = categoryPlot26.getOutlineStroke();
        valueMarker25.setStroke(stroke34);
        org.jfree.chart.util.Layer layer36 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot16.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker25, layer36);
        try {
            categoryPlot0.addDomainMarker((int) (short) 0, categoryMarker15, layer36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertNotNull(paint19);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNull(categoryItemRenderer33);
        org.junit.Assert.assertNotNull(stroke34);
        org.junit.Assert.assertNotNull(layer36);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block1 = null;
        blockContainer0.add(block1);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        textTitle3.setWidth((double) '4');
        java.lang.Object obj6 = textTitle3.clone();
        double double7 = textTitle3.getContentYOffset();
        blockContainer0.add((org.jfree.chart.block.Block) textTitle3);
        java.awt.Graphics2D graphics2D9 = null;
        java.awt.Font font11 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock12 = new org.jfree.chart.block.LabelBlock("ClassContext", font11);
        labelBlock12.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        boolean boolean16 = labelBlock12.equals((java.lang.Object) textTitle15);
        java.awt.geom.Rectangle2D rectangle2D17 = textTitle15.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        int int19 = categoryPlot18.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot18.getRangeAxisEdge();
        double double21 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D17, rectangleEdge20);
        try {
            blockContainer0.draw(graphics2D9, rectangle2D17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(font11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(rectangle2D17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType0 = org.jfree.chart.util.LengthAdjustmentType.NO_CHANGE;
        org.junit.Assert.assertNotNull(lengthAdjustmentType0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.awt.Color color0 = java.awt.Color.gray;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        java.lang.Object obj3 = size2D2.clone();
        java.lang.String str4 = size2D2.toString();
        double double5 = size2D2.height;
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo10 = new org.jfree.chart.ui.BasicProjectInfo("3", "java.awt.Color[r=192,g=0,b=0]", "ThreadContext", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        boolean boolean11 = size2D2.equals((java.lang.Object) "java.awt.Color[r=192,g=0,b=0]");
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str4.equals("Size2D[width=0.0, height=0.0]"));
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list6 = defaultStatisticalCategoryDataset5.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity9 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        int int10 = defaultStatisticalCategoryDataset5.getColumnCount();
        try {
            java.lang.Comparable comparable12 = defaultStatisticalCategoryDataset5.getColumnKey((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 97, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        java.awt.Graphics2D graphics2D2 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        int int4 = categoryPlot3.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge5 = categoryPlot3.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D12 = null;
        org.jfree.chart.axis.AxisState axisState13 = null;
        java.awt.Font font15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("ClassContext", font15);
        labelBlock16.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        boolean boolean20 = labelBlock16.equals((java.lang.Object) textTitle19);
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle19.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        int int23 = categoryPlot22.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot22.getRangeAxisEdge();
        java.awt.Paint paint25 = categoryPlot22.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot22.getRangeAxisEdge();
        java.util.List list27 = categoryAxis6.refreshTicks(graphics2D12, axisState13, rectangle2D21, rectangleEdge26);
        org.jfree.chart.entity.ChartEntity chartEntity30 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D21, "TextAnchor.CENTER_RIGHT", "ItemLabelAnchor.INSIDE7");
        org.jfree.chart.axis.AxisState axisState32 = new org.jfree.chart.axis.AxisState((double) 15);
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean35 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge34);
        axisState32.moveCursor((double) '#', rectangleEdge34);
        double double37 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D21, rectangleEdge34);
        try {
            statisticalBarRenderer0.drawBackground(graphics2D2, categoryPlot3, rectangle2D21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge5);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(list27);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation1);
        boolean boolean3 = categoryPlot0.isRangeZoomable();
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        categoryPlot0.clearDomainMarkers((int) (byte) 10);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent10 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot0);
        org.jfree.chart.plot.Plot plot11 = plotChangeEvent10.getPlot();
        java.awt.Graphics2D graphics2D12 = null;
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock15 = new org.jfree.chart.block.LabelBlock("ClassContext", font14);
        labelBlock15.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        java.awt.Font font19 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock20 = new org.jfree.chart.block.LabelBlock("ClassContext", font19);
        labelBlock20.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle23 = new org.jfree.chart.title.TextTitle();
        boolean boolean24 = labelBlock20.equals((java.lang.Object) textTitle23);
        java.awt.geom.Rectangle2D rectangle2D25 = textTitle23.getBounds();
        labelBlock15.setBounds(rectangle2D25);
        try {
            plot11.drawOutline(graphics2D12, rectangle2D25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(font19);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(rectangle2D25);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block1 = null;
        blockContainer0.add(block1);
        org.jfree.chart.title.TextTitle textTitle3 = new org.jfree.chart.title.TextTitle();
        textTitle3.setWidth((double) '4');
        java.lang.Object obj6 = textTitle3.clone();
        double double7 = textTitle3.getContentYOffset();
        blockContainer0.add((org.jfree.chart.block.Block) textTitle3);
        org.jfree.chart.util.VerticalAlignment verticalAlignment9 = textTitle3.getVerticalAlignment();
        java.lang.String str10 = verticalAlignment9.toString();
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
        org.junit.Assert.assertNotNull(verticalAlignment9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "VerticalAlignment.CENTER" + "'", str10.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        java.awt.Font font1 = null;
        try {
            org.jfree.chart.text.TextFragment textFragment2 = new org.jfree.chart.text.TextFragment("ClassContext", font1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        int int11 = jFreeChart9.getSubtitleCount();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.util.RectangleInsets.ZERO_INSETS;
        double double2 = rectangleInsets0.calculateRightInset((double) ' ');
        org.junit.Assert.assertNotNull(rectangleInsets0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.jfree.chart.axis.NumberTickUnit numberTickUnit1 = new org.jfree.chart.axis.NumberTickUnit((double) 32.0f);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        categoryPlot0.setAnchorValue((double) (short) 0);
        categoryPlot0.setWeight((int) (byte) 10);
        categoryPlot0.setRangeCrosshairVisible(true);
        java.awt.Stroke stroke12 = categoryPlot0.getOutlineStroke();
        categoryPlot0.clearRangeMarkers(255);
        org.junit.Assert.assertNotNull(stroke12);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity3 = new org.jfree.chart.entity.ChartEntity(shape2);
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity6 = new org.jfree.chart.entity.TickLabelEntity(shape2, "JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0]", "JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.axis.NumberAxis numberAxis8 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        double double9 = numberAxis8.getAutoRangeMinimumSize();
        java.awt.Shape shape10 = numberAxis8.getUpArrow();
        tickLabelEntity6.setArea(shape10);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0E-8d + "'", double9 == 1.0E-8d);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, 0.0f, (float) (-1), textBlockAnchor4, 0.0f, (float) 10, (double) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator10 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator11 = null;
        java.lang.String str12 = legendItemEntity9.getImageMapAreaTag(toolTipTagFragmentGenerator10, uRLTagFragmentGenerator11);
        legendItemEntity9.setSeriesKey((java.lang.Comparable) "");
        java.lang.Comparable comparable15 = null;
        legendItemEntity9.setSeriesKey(comparable15);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        jFreeChart9.clearSubtitles();
        java.awt.Stroke stroke11 = jFreeChart9.getBorderStroke();
        java.util.List list12 = jFreeChart9.getSubtitles();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(stroke11);
        org.junit.Assert.assertNotNull(list12);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.data.Range range5 = rectangleConstraint2.getWidthRange();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNull(range5);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.jfree.chart.util.RectangleEdge rectangleEdge0 = null;
        boolean boolean1 = org.jfree.chart.util.RectangleEdge.isLeftOrRight(rectangleEdge0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Shape shape5 = statisticalBarRenderer0.getSeriesShape((int) (byte) 100);
        statisticalBarRenderer0.setAutoPopulateSeriesShape(true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(shape5);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (-1L));
        int int6 = categoryAxis0.getCategoryLabelPositionOffset();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot2.getRendererForDataset(categoryDataset8);
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        valueMarker1.setStroke(stroke10);
        valueMarker1.setLabel("ThreadContext");
        java.awt.Paint paint14 = null;
        valueMarker1.setOutlinePaint(paint14);
        float float16 = valueMarker1.getAlpha();
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + float16 + "' != '" + 0.8f + "'", float16 == 0.8f);
    }

//    @Test
//    public void test288() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test288");
//        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
//        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
//        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) ' ', (double) '4');
//        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
//        textTitle5.setID("ClassContext");
//        java.lang.Object obj8 = null;
//        columnArrangement4.add((org.jfree.chart.block.Block) textTitle5, obj8);
//        org.jfree.chart.ui.ProjectInfo projectInfo10 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str11 = projectInfo10.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray12 = projectInfo10.getLibraries();
//        org.jfree.chart.ui.ProjectInfo projectInfo13 = org.jfree.chart.JFreeChart.INFO;
//        projectInfo13.setLicenceName("");
//        org.jfree.chart.ui.Library[] libraryArray16 = projectInfo13.getLibraries();
//        projectInfo13.setVersion("ClassContext");
//        projectInfo10.addLibrary((org.jfree.chart.ui.Library) projectInfo13);
//        org.jfree.chart.ui.Library[] libraryArray20 = projectInfo13.getLibraries();
//        boolean boolean21 = columnArrangement4.equals((java.lang.Object) projectInfo13);
//        org.junit.Assert.assertNotNull(projectInfo10);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str11.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
//        org.junit.Assert.assertNotNull(libraryArray12);
//        org.junit.Assert.assertNotNull(projectInfo13);
//        org.junit.Assert.assertNotNull(libraryArray16);
//        org.junit.Assert.assertNotNull(libraryArray20);
//        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
//    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextAnchor textAnchor4 = org.jfree.chart.text.TextAnchor.BOTTOM_CENTER;
        try {
            java.awt.geom.Rectangle2D rectangle2D5 = org.jfree.chart.text.TextUtilities.drawAlignedString("", graphics2D1, (float) 0L, (float) (byte) 0, textAnchor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor4);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range1);
        double double3 = rectangleConstraint2.getWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType4 = rectangleConstraint2.getWidthConstraintType();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint5 = rectangleConstraint2.toUnconstrainedWidth();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 100.0d + "'", double3 == 100.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType4);
        org.junit.Assert.assertNotNull(rectangleConstraint5);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot2.getRendererForDataset(categoryDataset8);
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        valueMarker1.setStroke(stroke10);
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle13.setFont(font14);
        org.jfree.chart.text.TextFragment textFragment16 = new org.jfree.chart.text.TextFragment("(C)opyright 2000-2007, by Object Refinery Limited and Contributors", font14);
        valueMarker1.setLabelFont(font14);
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(font14);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation1 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_RIGHT;
        categoryPlot0.setRangeAxisLocation(axisLocation1);
        boolean boolean4 = categoryPlot0.equals((java.lang.Object) "hi!");
        org.junit.Assert.assertNotNull(axisLocation1);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        int int4 = categoryAxis0.getCategoryLabelPositionOffset();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        float float8 = categoryAxis7.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor9 = null;
        java.awt.geom.Rectangle2D rectangle2D12 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = null;
        double double14 = categoryAxis7.getCategoryJava2DCoordinate(categoryAnchor9, (int) '#', (int) (short) 10, rectangle2D12, rectangleEdge13);
        java.awt.Paint paint15 = categoryAxis7.getTickLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot16 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation18 = null;
        categoryPlot16.setDomainAxisLocation(15, axisLocation18, true);
        org.jfree.chart.title.TextTitle textTitle21 = new org.jfree.chart.title.TextTitle();
        textTitle21.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets24 = textTitle21.getMargin();
        categoryPlot16.setInsets(rectangleInsets24, false);
        double double27 = rectangleInsets24.getLeft();
        double double28 = rectangleInsets24.getTop();
        categoryAxis7.setTickLabelInsets(rectangleInsets24);
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis30.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis30.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.axis.AxisState axisState37 = null;
        java.awt.Font font39 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock40 = new org.jfree.chart.block.LabelBlock("ClassContext", font39);
        labelBlock40.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle();
        boolean boolean44 = labelBlock40.equals((java.lang.Object) textTitle43);
        java.awt.geom.Rectangle2D rectangle2D45 = textTitle43.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot46 = new org.jfree.chart.plot.CategoryPlot();
        int int47 = categoryPlot46.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge48 = categoryPlot46.getRangeAxisEdge();
        java.awt.Paint paint49 = categoryPlot46.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge50 = categoryPlot46.getRangeAxisEdge();
        java.util.List list51 = categoryAxis30.refreshTicks(graphics2D36, axisState37, rectangle2D45, rectangleEdge50);
        org.jfree.chart.entity.ChartEntity chartEntity54 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D45, "TextAnchor.CENTER_RIGHT", "ItemLabelAnchor.INSIDE7");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType55 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean57 = lengthAdjustmentType55.equals((java.lang.Object) 0L);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType58 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean60 = lengthAdjustmentType58.equals((java.lang.Object) 0L);
        java.awt.geom.Rectangle2D rectangle2D61 = rectangleInsets24.createAdjustedRectangle(rectangle2D45, lengthAdjustmentType55, lengthAdjustmentType58);
        org.jfree.chart.axis.CategoryAxis categoryAxis62 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis62.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis62.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D68 = null;
        org.jfree.chart.axis.AxisState axisState69 = null;
        java.awt.Font font71 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock72 = new org.jfree.chart.block.LabelBlock("ClassContext", font71);
        labelBlock72.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle75 = new org.jfree.chart.title.TextTitle();
        boolean boolean76 = labelBlock72.equals((java.lang.Object) textTitle75);
        java.awt.geom.Rectangle2D rectangle2D77 = textTitle75.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot78 = new org.jfree.chart.plot.CategoryPlot();
        int int79 = categoryPlot78.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge80 = categoryPlot78.getRangeAxisEdge();
        java.awt.Paint paint81 = categoryPlot78.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge82 = categoryPlot78.getRangeAxisEdge();
        java.util.List list83 = categoryAxis62.refreshTicks(graphics2D68, axisState69, rectangle2D77, rectangleEdge82);
        org.jfree.chart.entity.ChartEntity chartEntity86 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D77, "TextAnchor.CENTER_RIGHT", "ItemLabelAnchor.INSIDE7");
        org.jfree.chart.util.RectangleEdge rectangleEdge87 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo88 = null;
        try {
            org.jfree.chart.axis.AxisState axisState89 = categoryAxis0.draw(graphics2D5, (double) 100L, rectangle2D61, rectangle2D77, rectangleEdge87, plotRenderingInfo88);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.0f + "'", float8 == 0.0f);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleInsets24);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(font39);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(rectangle2D45);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge48);
        org.junit.Assert.assertNotNull(paint49);
        org.junit.Assert.assertNotNull(rectangleEdge50);
        org.junit.Assert.assertNotNull(list51);
        org.junit.Assert.assertNotNull(lengthAdjustmentType55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType58);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(rectangle2D61);
        org.junit.Assert.assertNotNull(font71);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(rectangle2D77);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge80);
        org.junit.Assert.assertNotNull(paint81);
        org.junit.Assert.assertNotNull(rectangleEdge82);
        org.junit.Assert.assertNotNull(list83);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle13.setFont(font14);
        textTitle13.setHeight((double) (short) -1);
        jFreeChart9.setTitle(textTitle13);
        java.util.List list19 = jFreeChart9.getSubtitles();
        org.jfree.chart.event.ChartChangeListener chartChangeListener20 = null;
        try {
            jFreeChart9.removeChangeListener(chartChangeListener20);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'listener' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(list19);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle13.setFont(font14);
        textTitle13.setHeight((double) (short) -1);
        jFreeChart9.setTitle(textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart9.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = legendTitle19.getLegendItemGraphicLocation();
        java.awt.Graphics2D graphics2D21 = null;
        java.awt.Font font23 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock24 = new org.jfree.chart.block.LabelBlock("ClassContext", font23);
        labelBlock24.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        java.awt.Font font28 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("ClassContext", font28);
        labelBlock29.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle32 = new org.jfree.chart.title.TextTitle();
        boolean boolean33 = labelBlock29.equals((java.lang.Object) textTitle32);
        java.awt.geom.Rectangle2D rectangle2D34 = textTitle32.getBounds();
        labelBlock24.setBounds(rectangle2D34);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset36 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list37 = defaultStatisticalCategoryDataset36.getColumnKeys();
        try {
            java.lang.Object obj38 = legendTitle19.draw(graphics2D21, rectangle2D34, (java.lang.Object) list37);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(font23);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(rectangle2D34);
        org.junit.Assert.assertNotNull(list37);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape6, (java.awt.Paint) color7);
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray13, numberArray16, numberArray19, numberArray22, numberArray25, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=192,g=0,b=0]", "hi!", numberArray29);
        java.lang.Number number31 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset30, 0.0d);
        legendItem8.setDataset((org.jfree.data.general.Dataset) categoryDataset30);
        org.jfree.data.KeyToGroupMap keyToGroupMap35 = null;
        try {
            org.jfree.data.Range range36 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset30, keyToGroupMap35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.3d + "'", number31.equals(0.3d));
        org.junit.Assert.assertNotNull(range33);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot10.setDomainAxisLocation(15, axisLocation12, true);
        categoryPlot10.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot10.getRendererForDataset(categoryDataset16);
        java.awt.Stroke stroke18 = categoryPlot10.getOutlineStroke();
        valueMarker9.setStroke(stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker9, layer20);
        org.jfree.chart.plot.CategoryPlot categoryPlot22 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation24 = null;
        categoryPlot22.setDomainAxisLocation(15, axisLocation24, true);
        org.jfree.chart.title.TextTitle textTitle27 = new org.jfree.chart.title.TextTitle();
        textTitle27.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets30 = textTitle27.getMargin();
        categoryPlot22.setInsets(rectangleInsets30, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets33 = categoryPlot22.getInsets();
        double double35 = rectangleInsets33.calculateLeftOutset((double) (byte) 10);
        valueMarker9.setLabelOffset(rectangleInsets33);
        valueMarker9.setLabel("java.awt.Color[r=192,g=0,b=0]");
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertNotNull(rectangleInsets30);
        org.junit.Assert.assertNotNull(rectangleInsets33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block1 = null;
        blockContainer0.add(block1);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ClassContext", font4);
        labelBlock5.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        labelBlock5.setToolTipText("");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) labelBlock5);
        java.lang.String str11 = labelBlock5.getURLText();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        org.jfree.chart.text.TextBlock textBlock14 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape22 = textBlock14.calculateBounds(graphics2D15, 0.0f, (float) (-1), textBlockAnchor18, 0.0f, (float) 10, (double) 10);
        numberAxis13.setLeftArrow(shape22);
        java.text.NumberFormat numberFormat24 = numberAxis13.getNumberFormatOverride();
        blockContainer0.add((org.jfree.chart.block.Block) labelBlock5, (java.lang.Object) numberFormat24);
        labelBlock5.setURLText("LegendItemEntity: seriesKey=, dataset=null");
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(numberFormat24);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        boolean boolean0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list6 = defaultStatisticalCategoryDataset5.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity9 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        java.lang.Object obj10 = defaultStatisticalCategoryDataset5.clone();
        try {
            java.lang.Comparable comparable12 = defaultStatisticalCategoryDataset5.getRowKey((-16711681));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -16711681");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(obj10);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot10.setDomainAxisLocation(15, axisLocation12, true);
        categoryPlot10.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot10.getRendererForDataset(categoryDataset16);
        java.awt.Stroke stroke18 = categoryPlot10.getOutlineStroke();
        valueMarker9.setStroke(stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker9, layer20);
        java.lang.Object obj22 = null;
        boolean boolean23 = layer20.equals(obj22);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke9 = statisticalBarRenderer8.getBaseStroke();
        java.awt.Paint paint11 = statisticalBarRenderer8.getSeriesOutlinePaint((-1));
        boolean boolean12 = statisticalBarRenderer8.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke13 = statisticalBarRenderer8.getBaseOutlineStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke13, false);
        statisticalBarRenderer0.setSeriesVisibleInLegend((int) (byte) 10, (java.lang.Boolean) false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
    }

//    @Test
//    public void test303() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test303");
//        java.lang.ClassLoader classLoader0 = org.jfree.chart.util.ObjectUtilities.getClassLoader();
//        org.junit.Assert.assertNotNull(classLoader0);
//    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_DOMAIN_GRIDLINES_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.block.ColumnArrangement columnArrangement1 = new org.jfree.chart.block.ColumnArrangement();
        boolean boolean2 = gradientPaintTransformType0.equals((java.lang.Object) columnArrangement1);
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        categoryPlot0.clearDomainMarkers((int) (byte) 10);
        org.jfree.chart.text.TextBlock textBlock10 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D11 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor14 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape18 = textBlock10.calculateBounds(graphics2D11, 0.0f, (float) (-1), textBlockAnchor14, 0.0f, (float) 10, (double) 10);
        java.awt.Graphics2D graphics2D19 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor22 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor23 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition24 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor22, textBlockAnchor23);
        textBlock10.draw(graphics2D19, (float) 0L, (float) 0, textBlockAnchor23, (float) 0L, (float) (byte) 10, (double) 0.0f);
        org.jfree.chart.axis.AxisLocation axisLocation29 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot30 = new org.jfree.chart.plot.CategoryPlot();
        int int31 = categoryPlot30.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge32 = categoryPlot30.getRangeAxisEdge();
        java.awt.Paint paint33 = categoryPlot30.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot30.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot30.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo39 = null;
        java.awt.geom.Point2D point2D40 = null;
        categoryPlot30.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo39, point2D40);
        org.jfree.chart.plot.PlotOrientation plotOrientation42 = categoryPlot30.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge43 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation29, plotOrientation42);
        boolean boolean44 = textBlockAnchor23.equals((java.lang.Object) plotOrientation42);
        categoryPlot0.setOrientation(plotOrientation42);
        org.jfree.chart.plot.CategoryMarker categoryMarker46 = null;
        org.jfree.chart.util.Layer layer47 = null;
        try {
            categoryPlot0.addDomainMarker(categoryMarker46, layer47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'marker' not permitted.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(textBlockAnchor14);
        org.junit.Assert.assertNotNull(shape18);
        org.junit.Assert.assertNotNull(rectangleAnchor22);
        org.junit.Assert.assertNotNull(textBlockAnchor23);
        org.junit.Assert.assertNotNull(axisLocation29);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge32);
        org.junit.Assert.assertNotNull(paint33);
        org.junit.Assert.assertNotNull(rectangleEdge34);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(plotOrientation42);
        org.junit.Assert.assertNotNull(rectangleEdge43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.text.NumberFormat numberFormat1 = null;
        try {
            org.jfree.chart.axis.NumberTickUnit numberTickUnit3 = new org.jfree.chart.axis.NumberTickUnit(0.0d, numberFormat1, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'formatter' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double3 = categoryAxis0.getLabelAngle();
        java.lang.String str5 = categoryAxis0.getCategoryLabelToolTip((java.lang.Comparable) 100);
        categoryAxis0.configure();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNull(str5);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color2 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str3 = color2.toString();
        statisticalBarRenderer0.setSeriesOutlinePaint(2, (java.awt.Paint) color2, false);
        java.awt.Graphics2D graphics2D6 = null;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment7 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment8 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement11 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment7, verticalAlignment8, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle12 = new org.jfree.chart.title.TextTitle();
        textTitle12.setID("ClassContext");
        java.lang.Object obj15 = null;
        columnArrangement11.add((org.jfree.chart.block.Block) textTitle12, obj15);
        org.jfree.chart.util.VerticalAlignment verticalAlignment17 = textTitle12.getVerticalAlignment();
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        int int19 = categoryPlot18.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge20 = categoryPlot18.getRangeAxisEdge();
        categoryPlot18.setForegroundAlpha((float) 0);
        java.awt.Color color23 = java.awt.Color.darkGray;
        float[] floatArray30 = new float[] { 255, (-1L), 2, (short) 10, '4', 1 };
        float[] floatArray31 = color23.getRGBColorComponents(floatArray30);
        categoryPlot18.setBackgroundPaint((java.awt.Paint) color23);
        boolean boolean33 = verticalAlignment17.equals((java.lang.Object) categoryPlot18);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer34 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator35 = statisticalBarRenderer34.getLegendItemToolTipGenerator();
        java.awt.Graphics2D graphics2D36 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot37 = new org.jfree.chart.plot.CategoryPlot();
        int int38 = categoryPlot37.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge39 = categoryPlot37.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer41 = null;
        categoryPlot37.setRenderer((int) (byte) 100, categoryItemRenderer41);
        boolean boolean43 = categoryPlot37.isDomainGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis45 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean46 = numberAxis45.isVerticalTickLabels();
        org.jfree.data.Range range47 = numberAxis45.getRange();
        org.jfree.chart.plot.ValueMarker valueMarker49 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot50 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation52 = null;
        categoryPlot50.setDomainAxisLocation(15, axisLocation52, true);
        categoryPlot50.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset56 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer57 = categoryPlot50.getRendererForDataset(categoryDataset56);
        java.awt.Stroke stroke58 = categoryPlot50.getOutlineStroke();
        valueMarker49.setStroke(stroke58);
        valueMarker49.setLabel("ThreadContext");
        double double62 = valueMarker49.getValue();
        java.awt.Font font64 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock65 = new org.jfree.chart.block.LabelBlock("ClassContext", font64);
        labelBlock65.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle68 = new org.jfree.chart.title.TextTitle();
        boolean boolean69 = labelBlock65.equals((java.lang.Object) textTitle68);
        java.awt.geom.Rectangle2D rectangle2D70 = textTitle68.getBounds();
        statisticalBarRenderer34.drawRangeMarker(graphics2D36, categoryPlot37, (org.jfree.chart.axis.ValueAxis) numberAxis45, (org.jfree.chart.plot.Marker) valueMarker49, rectangle2D70);
        try {
            statisticalBarRenderer0.drawDomainGridline(graphics2D6, categoryPlot18, rectangle2D70, 1.0E-8d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color2);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str3.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertNotNull(verticalAlignment17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge20);
        org.junit.Assert.assertNotNull(color23);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator35);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge39);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(range47);
        org.junit.Assert.assertNull(categoryItemRenderer57);
        org.junit.Assert.assertNotNull(stroke58);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + (-1.0d) + "'", double62 == (-1.0d));
        org.junit.Assert.assertNotNull(font64);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(rectangle2D70);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        java.text.AttributedString attributedString0 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis4 = new org.jfree.chart.axis.CategoryAxis();
        float float5 = categoryAxis4.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor6 = null;
        java.awt.geom.Rectangle2D rectangle2D9 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge10 = null;
        double double11 = categoryAxis4.getCategoryJava2DCoordinate(categoryAnchor6, (int) '#', (int) (short) 10, rectangle2D9, rectangleEdge10);
        java.awt.Paint paint12 = categoryAxis4.getTickLabelPaint();
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot13.setDomainAxisLocation(15, axisLocation15, true);
        org.jfree.chart.title.TextTitle textTitle18 = new org.jfree.chart.title.TextTitle();
        textTitle18.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets21 = textTitle18.getMargin();
        categoryPlot13.setInsets(rectangleInsets21, false);
        double double24 = rectangleInsets21.getLeft();
        double double25 = rectangleInsets21.getTop();
        categoryAxis4.setTickLabelInsets(rectangleInsets21);
        org.jfree.chart.axis.CategoryAxis categoryAxis27 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis27.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis27.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D33 = null;
        org.jfree.chart.axis.AxisState axisState34 = null;
        java.awt.Font font36 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock37 = new org.jfree.chart.block.LabelBlock("ClassContext", font36);
        labelBlock37.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle40 = new org.jfree.chart.title.TextTitle();
        boolean boolean41 = labelBlock37.equals((java.lang.Object) textTitle40);
        java.awt.geom.Rectangle2D rectangle2D42 = textTitle40.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot43 = new org.jfree.chart.plot.CategoryPlot();
        int int44 = categoryPlot43.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge45 = categoryPlot43.getRangeAxisEdge();
        java.awt.Paint paint46 = categoryPlot43.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge47 = categoryPlot43.getRangeAxisEdge();
        java.util.List list48 = categoryAxis27.refreshTicks(graphics2D33, axisState34, rectangle2D42, rectangleEdge47);
        org.jfree.chart.entity.ChartEntity chartEntity51 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D42, "TextAnchor.CENTER_RIGHT", "ItemLabelAnchor.INSIDE7");
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType52 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean54 = lengthAdjustmentType52.equals((java.lang.Object) 0L);
        org.jfree.chart.util.LengthAdjustmentType lengthAdjustmentType55 = org.jfree.chart.util.LengthAdjustmentType.CONTRACT;
        boolean boolean57 = lengthAdjustmentType55.equals((java.lang.Object) 0L);
        java.awt.geom.Rectangle2D rectangle2D58 = rectangleInsets21.createAdjustedRectangle(rectangle2D42, lengthAdjustmentType52, lengthAdjustmentType55);
        org.jfree.chart.plot.CategoryPlot categoryPlot59 = new org.jfree.chart.plot.CategoryPlot();
        int int60 = categoryPlot59.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge61 = categoryPlot59.getRangeAxisEdge();
        categoryPlot59.setForegroundAlpha((float) 0);
        java.awt.Color color64 = java.awt.Color.darkGray;
        float[] floatArray71 = new float[] { 255, (-1L), 2, (short) 10, '4', 1 };
        float[] floatArray72 = color64.getRGBColorComponents(floatArray71);
        categoryPlot59.setBackgroundPaint((java.awt.Paint) color64);
        int int74 = color64.getRed();
        try {
            org.jfree.chart.LegendItem legendItem75 = new org.jfree.chart.LegendItem(attributedString0, "java.awt.Color[r=192,g=0,b=0]", "ClassContext", "CategoryAnchor.MIDDLE", (java.awt.Shape) rectangle2D42, (java.awt.Paint) color64);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.0f + "'", float5 == 0.0f);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNotNull(rectangleInsets21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(font36);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(rectangle2D42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge45);
        org.junit.Assert.assertNotNull(paint46);
        org.junit.Assert.assertNotNull(rectangleEdge47);
        org.junit.Assert.assertNotNull(list48);
        org.junit.Assert.assertNotNull(lengthAdjustmentType52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(lengthAdjustmentType55);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(rectangle2D58);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge61);
        org.junit.Assert.assertNotNull(color64);
        org.junit.Assert.assertNotNull(floatArray71);
        org.junit.Assert.assertNotNull(floatArray72);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 64 + "'", int74 == 64);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.jfree.chart.ui.Licences licences0 = org.jfree.chart.ui.Licences.getInstance();
        java.lang.String str1 = licences0.getLGPL();
        org.junit.Assert.assertNotNull(licences0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent3);
        org.jfree.chart.axis.AxisLocation axisLocation6 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        try {
            categoryPlot0.setRangeAxisLocation((int) (short) -1, axisLocation6);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(axisLocation6);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent1 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) (byte) 10);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("");
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.jfree.data.xy.XYDataset xYDataset0 = null;
        boolean boolean1 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull(xYDataset0);
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 15);
        axisState1.setCursor((double) (-1));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor0 = org.jfree.chart.text.TextBlockAnchor.TOP_CENTER;
        org.junit.Assert.assertNotNull(textBlockAnchor0);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.lang.Class class1 = null;
        try {
            java.net.URL uRL2 = org.jfree.chart.util.ObjectUtilities.getResourceRelative("VerticalAlignment.CENTER", class1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.TOP_LEFT;
        org.junit.Assert.assertNotNull(textAnchor0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke5 = statisticalBarRenderer0.getBaseOutlineStroke();
        try {
            statisticalBarRenderer0.setSeriesVisibleInLegend((int) (byte) -1, (java.lang.Boolean) false, true);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent3);
        categoryPlot0.mapDatasetToDomainAxis((int) (short) 1, 1);
        categoryPlot0.clearDomainAxes();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double3 = categoryAxis0.getLabelAngle();
        double double4 = categoryAxis0.getCategoryMargin();
        double double5 = categoryAxis0.getLowerMargin();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.05d + "'", double5 == 0.05d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle0.setFont(font1);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.data.Range range5 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint6 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range5);
        double double7 = rectangleConstraint6.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = rectangleConstraint6.toUnconstrainedWidth();
        double double9 = rectangleConstraint6.getHeight();
        try {
            org.jfree.chart.util.Size2D size2D10 = textTitle0.arrange(graphics2D3, rectangleConstraint6);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        java.awt.Paint paint4 = null;
        try {
            org.jfree.chart.block.BlockBorder blockBorder5 = new org.jfree.chart.block.BlockBorder(0.0d, (double) 100L, 10.0d, (double) 'a', paint4);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_AUTO_RANGE_MINIMUM_SIZE;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-8d + "'", double0 == 1.0E-8d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        statisticalBarRenderer0.setDrawBarOutline(true);
        org.jfree.chart.title.TextTitle textTitle9 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font10 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle9.setFont(font10);
        java.awt.Paint paint12 = null;
        org.jfree.chart.text.TextBlock textBlock13 = org.jfree.chart.text.TextUtilities.createTextBlock("", font10, paint12);
        statisticalBarRenderer0.setSeriesItemLabelFont((int) (short) 100, font10);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(textBlock13);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (-1L), (double) 10);
        java.lang.Object obj3 = null;
        boolean boolean4 = meanAndStandardDeviation2.equals(obj3);
        java.lang.Number number5 = meanAndStandardDeviation2.getMean();
        java.lang.Number number6 = meanAndStandardDeviation2.getStandardDeviation();
        java.lang.Number number7 = meanAndStandardDeviation2.getMean();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.0d) + "'", number5.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10.0d + "'", number6.equals(10.0d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-1.0d) + "'", number7.equals((-1.0d)));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        java.awt.Color color0 = java.awt.Color.cyan;
        int int1 = color0.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextBlock textBlock4 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.chart.util.Size2D size2D6 = textBlock4.calculateDimensions(graphics2D5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor9 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D10 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D6, 0.3d, (double) (short) 100, rectangleAnchor9);
        try {
            blockBorder2.draw(graphics2D3, rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16711681) + "'", int1 == (-16711681));
        org.junit.Assert.assertNotNull(size2D6);
        org.junit.Assert.assertNotNull(rectangleAnchor9);
        org.junit.Assert.assertNotNull(rectangle2D10);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRendererForDataset(categoryDataset6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot0.getDrawingSupplier();
        org.jfree.chart.axis.NumberAxis numberAxis10 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis10.setTickMarkOutsideLength((float) (short) 100);
        numberAxis10.setLabelAngle((double) '4');
        org.jfree.data.Range range15 = categoryPlot0.getDataRange((org.jfree.chart.axis.ValueAxis) numberAxis10);
        java.text.NumberFormat numberFormat16 = null;
        numberAxis10.setNumberFormatOverride(numberFormat16);
        java.awt.Shape shape18 = numberAxis10.getRightArrow();
        try {
            numberAxis10.zoomRange((double) '#', 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Range(double, double): require lower (35.0) <= upper (0.0).");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNotNull(shape18);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE1;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo9, point2D10);
        org.jfree.chart.plot.PlotOrientation plotOrientation12 = categoryPlot0.getOrientation();
        java.util.List list13 = categoryPlot0.getCategories();
        boolean boolean14 = categoryPlot0.isRangeZoomable();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent15 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent15);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(plotOrientation12);
        org.junit.Assert.assertNull(list13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.jfree.chart.util.RectangleInsets rectangleInsets0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_INSETS;
        org.junit.Assert.assertNotNull(rectangleInsets0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        java.lang.Class class1 = null;
        java.lang.Object obj2 = org.jfree.chart.util.ObjectUtilities.loadAndInstantiate("", class1);
        org.junit.Assert.assertNull(obj2);
    }

//    @Test
//    public void test334() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test334");
//        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
//        statisticalBarRenderer0.setAutoPopulateSeriesStroke(false);
//        statisticalBarRenderer0.setBaseSeriesVisible(false, false);
//        java.awt.Font font9 = statisticalBarRenderer0.getItemLabelFont((int) (short) 1, (int) '4');
//        java.awt.Graphics2D graphics2D10 = null;
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo11 = null;
//        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState12 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo11);
//        double double13 = categoryItemRendererState12.getSeriesRunningTotal();
//        double double14 = categoryItemRendererState12.getBarWidth();
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo15 = categoryItemRendererState12.getInfo();
//        java.awt.geom.Rectangle2D rectangle2D16 = null;
//        org.jfree.chart.plot.CategoryPlot categoryPlot17 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation19 = null;
//        categoryPlot17.setDomainAxisLocation(15, axisLocation19, true);
//        categoryPlot17.clearRangeAxes();
//        categoryPlot17.setAnchorValue((double) (short) 0);
//        org.jfree.chart.ui.ProjectInfo projectInfo25 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str26 = projectInfo25.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray27 = projectInfo25.getLibraries();
//        java.lang.String str28 = projectInfo25.getLicenceText();
//        java.awt.Image image29 = projectInfo25.getLogo();
//        categoryPlot17.setBackgroundImage(image29);
//        java.awt.Paint paint31 = categoryPlot17.getDomainGridlinePaint();
//        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
//        int int33 = categoryPlot32.getWeight();
//        org.jfree.chart.util.RectangleEdge rectangleEdge34 = categoryPlot32.getRangeAxisEdge();
//        java.awt.Paint paint35 = categoryPlot32.getBackgroundPaint();
//        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot32.getRangeAxisEdge();
//        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot32.getDomainAxisEdge(0);
//        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo41 = null;
//        java.awt.geom.Point2D point2D42 = null;
//        categoryPlot32.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo41, point2D42);
//        org.jfree.chart.axis.CategoryAxis categoryAxis44 = new org.jfree.chart.axis.CategoryAxis();
//        categoryAxis44.setMaximumCategoryLabelWidthRatio((float) ' ');
//        categoryAxis44.setTickLabelsVisible(true);
//        java.util.List list49 = categoryPlot32.getCategoriesForAxis(categoryAxis44);
//        org.jfree.chart.axis.NumberAxis numberAxis51 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
//        numberAxis51.setVisible(true);
//        numberAxis51.setRange((double) (short) -1, 10.0d);
//        numberAxis51.setInverted(false);
//        org.jfree.chart.axis.TickUnitSource tickUnitSource59 = org.jfree.chart.axis.NumberAxis.createIntegerTickUnits();
//        numberAxis51.setStandardTickUnits(tickUnitSource59);
//        java.lang.Number[] numberArray65 = new java.lang.Number[] { 0.05d, (short) 0 };
//        java.lang.Number[] numberArray68 = new java.lang.Number[] { 0.05d, (short) 0 };
//        java.lang.Number[] numberArray71 = new java.lang.Number[] { 0.05d, (short) 0 };
//        java.lang.Number[] numberArray74 = new java.lang.Number[] { 0.05d, (short) 0 };
//        java.lang.Number[] numberArray77 = new java.lang.Number[] { 0.05d, (short) 0 };
//        java.lang.Number[] numberArray80 = new java.lang.Number[] { 0.05d, (short) 0 };
//        java.lang.Number[][] numberArray81 = new java.lang.Number[][] { numberArray65, numberArray68, numberArray71, numberArray74, numberArray77, numberArray80 };
//        org.jfree.data.category.CategoryDataset categoryDataset82 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=192,g=0,b=0]", "hi!", numberArray81);
//        java.lang.Number number83 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset82);
//        try {
//            statisticalBarRenderer0.drawItem(graphics2D10, categoryItemRendererState12, rectangle2D16, categoryPlot17, categoryAxis44, (org.jfree.chart.axis.ValueAxis) numberAxis51, categoryDataset82, (int) (byte) 0, (int) (byte) 0, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires StatisticalCategoryDataset.");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertNotNull(stroke1);
//        org.junit.Assert.assertNotNull(font9);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
//        org.junit.Assert.assertNull(plotRenderingInfo15);
//        org.junit.Assert.assertNotNull(projectInfo25);
//        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str26.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
//        org.junit.Assert.assertNotNull(libraryArray27);
//        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "ThreadContext" + "'", str28.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(image29);
//        org.junit.Assert.assertNotNull(paint31);
//        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
//        org.junit.Assert.assertNotNull(rectangleEdge34);
//        org.junit.Assert.assertNotNull(paint35);
//        org.junit.Assert.assertNotNull(rectangleEdge36);
//        org.junit.Assert.assertNotNull(rectangleEdge38);
//        org.junit.Assert.assertNotNull(list49);
//        org.junit.Assert.assertNotNull(tickUnitSource59);
//        org.junit.Assert.assertNotNull(numberArray65);
//        org.junit.Assert.assertNotNull(numberArray68);
//        org.junit.Assert.assertNotNull(numberArray71);
//        org.junit.Assert.assertNotNull(numberArray74);
//        org.junit.Assert.assertNotNull(numberArray77);
//        org.junit.Assert.assertNotNull(numberArray80);
//        org.junit.Assert.assertNotNull(numberArray81);
//        org.junit.Assert.assertNotNull(categoryDataset82);
//        org.junit.Assert.assertTrue("'" + number83 + "' != '" + 0.3d + "'", number83.equals(0.3d));
//    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        java.lang.Boolean boolean9 = statisticalBarRenderer0.getSeriesVisible((int) (short) 0);
        statisticalBarRenderer0.setBaseSeriesVisibleInLegend(false, false);
        java.awt.Stroke stroke14 = statisticalBarRenderer0.getSeriesOutlineStroke((int) '#');
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(boolean9);
        org.junit.Assert.assertNull(stroke14);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        boolean boolean0 = org.jfree.chart.plot.CategoryPlot.DEFAULT_CROSSHAIR_VISIBLE;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + false + "'", boolean0 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getInsets();
        double double13 = rectangleInsets11.calculateLeftOutset((double) (byte) 10);
        double double15 = rectangleInsets11.calculateTopInset((double) (byte) 0);
        double double17 = rectangleInsets11.trimHeight(0.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle13.setFont(font14);
        textTitle13.setHeight((double) (short) -1);
        jFreeChart9.setTitle(textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart9.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = legendTitle19.getLegendItemGraphicLocation();
        java.lang.String str21 = rectangleAnchor20.toString();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "RectangleAnchor.CENTER" + "'", str21.equals("RectangleAnchor.CENTER"));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        java.awt.Paint paint0 = org.jfree.chart.plot.Plot.DEFAULT_BACKGROUND_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

//    @Test
//    public void test340() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test340");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getLibraries();
//        java.lang.String str3 = projectInfo0.getLicenceText();
//        projectInfo0.setCopyright("RectangleAnchor.CENTER");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "(C)opyright 2000-2007, by Object Refinery Limited and Contributors" + "'", str1.equals("(C)opyright 2000-2007, by Object Refinery Limited and Contributors"));
//        org.junit.Assert.assertNotNull(libraryArray2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ThreadContext" + "'", str3.equals("ThreadContext"));
//    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("ClassContext", font1);
        labelBlock2.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        labelBlock2.setURLText("JFreeChart version ClassContext.\n(C)opyright 2000-2007, by Object Refinery Limited and Contributors.\n\nFor terms of use, see the licence below.\n\nFURTHER INFORMATION:ThreadContext\nCONTRIBUTORS:\nOTHER LIBRARIES USED BY JFreeChart:JFreeChart ClassContext (ThreadContext).JFreeChart ClassContext (ThreadContext).\nJFreeChart LICENCE TERMS:\njava.awt.Color[r=192,g=0,b=0]");
        labelBlock2.setURLText("3");
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block1 = null;
        blockContainer0.add(block1);
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ClassContext", font4);
        labelBlock5.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        labelBlock5.setToolTipText("");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent10 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) labelBlock5);
        java.lang.String str11 = labelBlock5.getURLText();
        org.jfree.chart.axis.NumberAxis numberAxis13 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        org.jfree.chart.text.TextBlock textBlock14 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D15 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor18 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape22 = textBlock14.calculateBounds(graphics2D15, 0.0f, (float) (-1), textBlockAnchor18, 0.0f, (float) 10, (double) 10);
        numberAxis13.setLeftArrow(shape22);
        java.text.NumberFormat numberFormat24 = numberAxis13.getNumberFormatOverride();
        blockContainer0.add((org.jfree.chart.block.Block) labelBlock5, (java.lang.Object) numberFormat24);
        java.awt.Graphics2D graphics2D26 = null;
        java.awt.Font font28 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock29 = new org.jfree.chart.block.LabelBlock("ClassContext", font28);
        labelBlock29.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        java.awt.Font font33 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock34 = new org.jfree.chart.block.LabelBlock("ClassContext", font33);
        labelBlock34.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle37 = new org.jfree.chart.title.TextTitle();
        boolean boolean38 = labelBlock34.equals((java.lang.Object) textTitle37);
        java.awt.geom.Rectangle2D rectangle2D39 = textTitle37.getBounds();
        labelBlock29.setBounds(rectangle2D39);
        java.awt.Font font42 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        java.awt.Color color43 = org.jfree.chart.ChartColor.DARK_RED;
        org.jfree.chart.block.LabelBlock labelBlock44 = new org.jfree.chart.block.LabelBlock("hi!", font42, (java.awt.Paint) color43);
        try {
            java.lang.Object obj45 = labelBlock5.draw(graphics2D26, rectangle2D39, (java.lang.Object) color43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertNull(str11);
        org.junit.Assert.assertNotNull(textBlockAnchor18);
        org.junit.Assert.assertNotNull(shape22);
        org.junit.Assert.assertNull(numberFormat24);
        org.junit.Assert.assertNotNull(font28);
        org.junit.Assert.assertNotNull(font33);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(rectangle2D39);
        org.junit.Assert.assertNotNull(font42);
        org.junit.Assert.assertNotNull(color43);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setSeriesItemLabelsVisible(0, (java.lang.Boolean) true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer5 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke6 = statisticalBarRenderer5.getBaseStroke();
        java.awt.Paint paint8 = statisticalBarRenderer5.getSeriesOutlinePaint((-1));
        boolean boolean9 = statisticalBarRenderer5.getAutoPopulateSeriesOutlineStroke();
        boolean boolean10 = statisticalBarRenderer5.getBaseSeriesVisible();
        statisticalBarRenderer5.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot14 = null;
        org.jfree.chart.axis.NumberAxis numberAxis16 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis16.setPositiveArrowVisible(true);
        numberAxis16.setFixedAutoRange((double) (short) 0);
        numberAxis16.setRangeWithMargins((double) 0, (double) '#');
        numberAxis16.setAutoRange(false);
        java.awt.Font font27 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("ClassContext", font27);
        labelBlock28.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        boolean boolean32 = labelBlock28.equals((java.lang.Object) textTitle31);
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle31.getBounds();
        statisticalBarRenderer5.drawRangeGridline(graphics2D13, categoryPlot14, (org.jfree.chart.axis.ValueAxis) numberAxis16, rectangle2D33, (double) (-16711681));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer36 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke37 = statisticalBarRenderer36.getBaseStroke();
        java.awt.Paint paint39 = statisticalBarRenderer36.getSeriesOutlinePaint((-1));
        java.awt.Shape shape41 = statisticalBarRenderer36.getSeriesShape((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer42 = null;
        statisticalBarRenderer36.setGradientPaintTransformer(gradientPaintTransformer42);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer45 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke46 = statisticalBarRenderer45.getBaseStroke();
        java.awt.Paint paint48 = statisticalBarRenderer45.getSeriesOutlinePaint((-1));
        boolean boolean49 = statisticalBarRenderer45.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition52 = statisticalBarRenderer45.getPositiveItemLabelPosition(0, 15);
        statisticalBarRenderer36.setSeriesPositiveItemLabelPosition(0, itemLabelPosition52, true);
        statisticalBarRenderer5.setNegativeItemLabelPositionFallback(itemLabelPosition52);
        statisticalBarRenderer0.setBaseNegativeItemLabelPosition(itemLabelPosition52, false);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNotNull(stroke6);
        org.junit.Assert.assertNull(paint8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertNotNull(stroke37);
        org.junit.Assert.assertNull(paint39);
        org.junit.Assert.assertNull(shape41);
        org.junit.Assert.assertNotNull(stroke46);
        org.junit.Assert.assertNull(paint48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition52);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        java.awt.Paint[] paintArray0 = org.jfree.chart.plot.DefaultDrawingSupplier.DEFAULT_PAINT_SEQUENCE;
        org.junit.Assert.assertNotNull(paintArray0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        int int6 = categoryPlot0.getDatasetCount();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent7 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent7);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.jfree.chart.block.BlockContainer blockContainer0 = new org.jfree.chart.block.BlockContainer();
        org.jfree.chart.block.Block block1 = null;
        blockContainer0.add(block1);
        blockContainer0.clear();
        blockContainer0.clear();
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo9, point2D10);
        boolean boolean12 = categoryPlot0.isDomainZoomable();
        java.awt.Graphics2D graphics2D13 = null;
        java.awt.Font font15 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock16 = new org.jfree.chart.block.LabelBlock("ClassContext", font15);
        labelBlock16.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle19 = new org.jfree.chart.title.TextTitle();
        boolean boolean20 = labelBlock16.equals((java.lang.Object) textTitle19);
        java.awt.geom.Rectangle2D rectangle2D21 = textTitle19.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo23 = null;
        boolean boolean24 = categoryPlot0.render(graphics2D13, rectangle2D21, (int) (byte) 100, plotRenderingInfo23);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer26 = categoryPlot0.getRenderer((int) ' ');
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent27 = null;
        categoryPlot0.datasetChanged(datasetChangeEvent27);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(font15);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(rectangle2D21);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNull(categoryItemRenderer26);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.jfree.chart.text.TextAnchor textAnchor2 = null;
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.text.TextAnchor textAnchor7 = null;
        org.jfree.chart.text.TextAnchor textAnchor9 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment10 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment11 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement14 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment10, verticalAlignment11, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle15 = new org.jfree.chart.title.TextTitle();
        textTitle15.setID("ClassContext");
        java.lang.Object obj18 = null;
        columnArrangement14.add((org.jfree.chart.block.Block) textTitle15, obj18);
        boolean boolean20 = textAnchor9.equals((java.lang.Object) textTitle15);
        java.awt.Shape shape21 = org.jfree.chart.text.TextUtilities.calculateRotatedStringBounds("", graphics2D4, 100.0f, (float) (-16711681), textAnchor7, (double) (byte) 100, textAnchor9);
        try {
            org.jfree.chart.axis.NumberTick numberTick23 = new org.jfree.chart.axis.NumberTick((java.lang.Number) (byte) 0, "RectangleEdge.RIGHT", textAnchor2, textAnchor7, (double) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'textAnchor' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNull(shape21);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape11);
        numberAxis1.setDownArrow(shape11);
        numberAxis1.setPositiveArrowVisible(false);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand16 = null;
        numberAxis1.setMarkerBand(markerAxisBand16);
        numberAxis1.setRangeWithMargins((double) '4', (double) 100.0f);
        org.junit.Assert.assertNotNull(shape11);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.jfree.chart.title.TextTitle textTitle2 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font3 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle2.setFont(font3);
        org.jfree.chart.text.TextLine textLine5 = new org.jfree.chart.text.TextLine("java.awt.Color[r=192,g=0,b=0]", font3);
        org.jfree.chart.plot.ValueMarker valueMarker7 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot8 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = null;
        categoryPlot8.setDomainAxisLocation(15, axisLocation10, true);
        categoryPlot8.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset14 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer15 = categoryPlot8.getRendererForDataset(categoryDataset14);
        java.awt.Stroke stroke16 = categoryPlot8.getOutlineStroke();
        valueMarker7.setStroke(stroke16);
        valueMarker7.setLabel("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets20 = valueMarker7.getLabelOffset();
        java.awt.Color color21 = java.awt.Color.white;
        int int22 = color21.getGreen();
        valueMarker7.setPaint((java.awt.Paint) color21);
        org.jfree.chart.text.TextFragment textFragment24 = new org.jfree.chart.text.TextFragment("java.awt.Color[r=192,g=0,b=0]", font3, (java.awt.Paint) color21);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer25 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke26 = statisticalBarRenderer25.getBaseStroke();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator28 = null;
        statisticalBarRenderer25.setSeriesURLGenerator((int) (byte) 1, categoryURLGenerator28);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer31 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator32 = statisticalBarRenderer31.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = null;
        statisticalBarRenderer33.setBaseToolTipGenerator(categoryToolTipGenerator34, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = null;
        statisticalBarRenderer33.setSeriesNegativeItemLabelPosition(10, itemLabelPosition38);
        java.awt.Stroke stroke41 = statisticalBarRenderer33.lookupSeriesOutlineStroke((int) (short) -1);
        statisticalBarRenderer31.setBaseStroke(stroke41);
        statisticalBarRenderer25.setSeriesOutlineStroke((int) (short) 100, stroke41, false);
        boolean boolean45 = textFragment24.equals((java.lang.Object) statisticalBarRenderer25);
        java.awt.Graphics2D graphics2D46 = null;
        org.jfree.chart.text.TextAnchor textAnchor47 = org.jfree.chart.text.TextAnchor.BASELINE_RIGHT;
        try {
            float float48 = textFragment24.calculateBaselineOffset(graphics2D46, textAnchor47);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(font3);
        org.junit.Assert.assertNull(categoryItemRenderer15);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(rectangleInsets20);
        org.junit.Assert.assertNotNull(color21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 255 + "'", int22 == 255);
        org.junit.Assert.assertNotNull(stroke26);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator32);
        org.junit.Assert.assertNotNull(stroke41);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(textAnchor47);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset0 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list1 = defaultStatisticalCategoryDataset0.getColumnKeys();
        org.jfree.data.Range range3 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0, true);
        boolean boolean4 = org.jfree.data.general.DatasetUtilities.isEmptyOrNull((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset0);
        org.jfree.data.Range range6 = defaultStatisticalCategoryDataset0.getRangeBounds(false);
        try {
            java.lang.Comparable comparable8 = defaultStatisticalCategoryDataset0.getColumnKey((-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(list1);
        org.junit.Assert.assertNull(range3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNull(range6);
    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test352");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getLicenceText();
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "ThreadContext" + "'", str1.equals("ThreadContext"));
//    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.jfree.chart.axis.TickUnitSource tickUnitSource0 = org.jfree.chart.axis.NumberAxis.createStandardTickUnits();
        org.junit.Assert.assertNotNull(tickUnitSource0);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis7.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double10 = categoryAxis7.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit11 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int12 = numberTickUnit11.getMinorTickCount();
        java.awt.Font font13 = categoryAxis7.getTickLabelFont((java.lang.Comparable) numberTickUnit11);
        categoryPlot0.setDomainAxis(categoryAxis7);
        org.jfree.chart.axis.AxisSpace axisSpace15 = null;
        categoryPlot0.setFixedRangeAxisSpace(axisSpace15);
        boolean boolean17 = categoryPlot0.isRangeCrosshairLockedOnData();
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(font13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double3 = categoryAxis0.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit4 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int5 = numberTickUnit4.getMinorTickCount();
        java.awt.Font font6 = categoryAxis0.getTickLabelFont((java.lang.Comparable) numberTickUnit4);
        java.awt.Paint paint8 = categoryAxis0.getTickLabelPaint((java.lang.Comparable) (byte) 10);
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) '#');
        double double11 = categoryAxis0.getLowerMargin();
        java.awt.Paint paint12 = org.jfree.chart.axis.Axis.DEFAULT_AXIS_LABEL_PAINT;
        categoryAxis0.setTickMarkPaint(paint12);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(font6);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.05d + "'", double11 == 0.05d);
        org.junit.Assert.assertNotNull(paint12);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        boolean boolean8 = categoryPlot0.getDrawSharedDomainAxis();
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder9 = org.jfree.chart.plot.DatasetRenderingOrder.FORWARD;
        java.lang.String str10 = datasetRenderingOrder9.toString();
        categoryPlot0.setDatasetRenderingOrder(datasetRenderingOrder9);
        java.lang.String str12 = datasetRenderingOrder9.toString();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder9);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str10.equals("DatasetRenderingOrder.FORWARD"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "DatasetRenderingOrder.FORWARD" + "'", str12.equals("DatasetRenderingOrder.FORWARD"));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis0.setTickLabelsVisible(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis0.getCategoryLabelPositions();
        categoryAxis0.setVisible(false);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.jfree.chart.util.Size2D size2D0 = new org.jfree.chart.util.Size2D();
        size2D0.width = 0.0d;
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle0.setFont(font1);
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.junit.Assert.assertNotNull(font1);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getPositiveItemLabelPosition(0, 15);
        double double8 = statisticalBarRenderer0.getMaximumBarWidth();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.0d + "'", double8 == 1.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setVisible(true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis1);
        org.jfree.chart.axis.Axis axis5 = axisChangeEvent4.getAxis();
        org.jfree.chart.JFreeChart jFreeChart6 = axisChangeEvent4.getChart();
        org.junit.Assert.assertNotNull(axis5);
        org.junit.Assert.assertNull(jFreeChart6);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.plot.Plot plot10 = jFreeChart9.getPlot();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(plot10);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        java.util.ResourceBundle.Control control1 = null;
        try {
            java.util.ResourceBundle resourceBundle2 = java.util.ResourceBundle.getBundle("java.awt.Color[r=192,g=0,b=0]", control1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot2.getRendererForDataset(categoryDataset8);
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        valueMarker1.setStroke(stroke10);
        valueMarker1.setLabel("ThreadContext");
        double double14 = valueMarker1.getValue();
        org.jfree.chart.event.MarkerChangeEvent markerChangeEvent15 = null;
        valueMarker1.notifyListeners(markerChangeEvent15);
        java.awt.Font font17 = null;
        try {
            valueMarker1.setLabelFont(font17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'font' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-1.0d) + "'", double14 == (-1.0d));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.util.RectangleInsets rectangleInsets5 = null;
        try {
            categoryPlot0.setAxisOffset(rectangleInsets5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'offset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor4);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("ClassContext", font1);
        labelBlock2.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        boolean boolean6 = labelBlock2.equals((java.lang.Object) textTitle5);
        java.awt.geom.Rectangle2D rectangle2D7 = textTitle5.getBounds();
        org.jfree.chart.entity.TickLabelEntity tickLabelEntity10 = new org.jfree.chart.entity.TickLabelEntity((java.awt.Shape) rectangle2D7, "(C)opyright 2000-2007, by Object Refinery Limited and Contributors", "Size2D[width=0.0, height=0.0]");
        java.lang.String str11 = tickLabelEntity10.getURLText();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(rectangle2D7);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "Size2D[width=0.0, height=0.0]" + "'", str11.equals("Size2D[width=0.0, height=0.0]"));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke7 = statisticalBarRenderer6.getBaseStroke();
        java.awt.Paint paint9 = statisticalBarRenderer6.getSeriesOutlinePaint((-1));
        boolean boolean10 = statisticalBarRenderer6.getAutoPopulateSeriesOutlineStroke();
        categoryPlot0.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer6, true);
        int int13 = categoryPlot0.getWeight();
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertNull(paint9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.jfree.chart.renderer.category.BarRenderer barRenderer0 = new org.jfree.chart.renderer.category.BarRenderer();
        barRenderer0.setBaseItemLabelsVisible(false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.jfree.data.Range range3 = numberAxis1.getRange();
        numberAxis1.resizeRange((-1.0d));
        java.lang.Object obj6 = numberAxis1.clone();
        double double7 = numberAxis1.getLowerMargin();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(obj6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.05d + "'", double7 == 0.05d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        categoryPlot0.setAnchorValue((double) (short) 0);
        categoryPlot0.setWeight((int) (byte) 10);
        categoryPlot0.setRangeCrosshairVisible(true);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset13 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list14 = defaultStatisticalCategoryDataset13.getColumnKeys();
        categoryPlot0.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset13);
        org.jfree.chart.axis.CategoryAxis categoryAxis17 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis17.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double20 = categoryAxis17.getLabelAngle();
        boolean boolean21 = categoryAxis17.isTickMarksVisible();
        categoryPlot0.setDomainAxis(255, categoryAxis17, true);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder24 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNotNull(list14);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(datasetRenderingOrder24);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor5 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        java.awt.geom.Rectangle2D rectangle2D6 = org.jfree.chart.util.RectangleAnchor.createRectangle(size2D2, 0.3d, (double) (short) 100, rectangleAnchor5);
        org.jfree.chart.util.RectangleAnchor rectangleAnchor7 = org.jfree.chart.util.RectangleAnchor.CENTER;
        java.awt.Shape shape10 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D6, rectangleAnchor7, 0.0d, (double) 32.0f);
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(rectangleAnchor5);
        org.junit.Assert.assertNotNull(rectangle2D6);
        org.junit.Assert.assertNotNull(rectangleAnchor7);
        org.junit.Assert.assertNotNull(shape10);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator3 = null;
        statisticalBarRenderer0.setSeriesURLGenerator((int) (byte) 1, categoryURLGenerator3);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer6 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator7 = statisticalBarRenderer6.getLegendItemToolTipGenerator();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator9 = null;
        statisticalBarRenderer8.setBaseToolTipGenerator(categoryToolTipGenerator9, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition13 = null;
        statisticalBarRenderer8.setSeriesNegativeItemLabelPosition(10, itemLabelPosition13);
        java.awt.Stroke stroke16 = statisticalBarRenderer8.lookupSeriesOutlineStroke((int) (short) -1);
        statisticalBarRenderer6.setBaseStroke(stroke16);
        statisticalBarRenderer0.setSeriesOutlineStroke((int) (short) 100, stroke16, false);
        org.jfree.chart.labels.CategoryItemLabelGenerator categoryItemLabelGenerator22 = statisticalBarRenderer0.getItemLabelGenerator(10, 0);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator7);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNull(categoryItemLabelGenerator22);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("ClassContext", font1);
        labelBlock2.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        labelBlock2.setToolTipText("");
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent7 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) labelBlock2);
        java.lang.String str8 = labelBlock2.getURLText();
        labelBlock2.setToolTipText("[size=1]");
        labelBlock2.setToolTipText("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]");
        org.jfree.chart.plot.ValueMarker valueMarker14 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot15 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation17 = null;
        categoryPlot15.setDomainAxisLocation(15, axisLocation17, true);
        categoryPlot15.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset21 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer22 = categoryPlot15.getRendererForDataset(categoryDataset21);
        java.awt.Stroke stroke23 = categoryPlot15.getOutlineStroke();
        valueMarker14.setStroke(stroke23);
        valueMarker14.setLabel("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets27 = valueMarker14.getLabelOffset();
        java.awt.Color color28 = java.awt.Color.white;
        int int29 = color28.getGreen();
        valueMarker14.setPaint((java.awt.Paint) color28);
        labelBlock2.setPaint((java.awt.Paint) color28);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNull(str8);
        org.junit.Assert.assertNull(categoryItemRenderer22);
        org.junit.Assert.assertNotNull(stroke23);
        org.junit.Assert.assertNotNull(rectangleInsets27);
        org.junit.Assert.assertNotNull(color28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 255 + "'", int29 == 255);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState((double) 15);
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean4 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge3);
        axisState1.moveCursor((double) '#', rectangleEdge3);
        double double6 = axisState1.getCursor();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 50.0d + "'", double6 == 50.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke9 = statisticalBarRenderer8.getBaseStroke();
        java.awt.Paint paint11 = statisticalBarRenderer8.getSeriesOutlinePaint((-1));
        boolean boolean12 = statisticalBarRenderer8.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke13 = statisticalBarRenderer8.getBaseOutlineStroke();
        statisticalBarRenderer0.setBaseOutlineStroke(stroke13, false);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator16 = statisticalBarRenderer0.getBaseToolTipGenerator();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertNull(categoryToolTipGenerator16);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset5 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list6 = defaultStatisticalCategoryDataset5.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity9 = new org.jfree.chart.entity.CategoryItemEntity(shape2, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset5, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        java.lang.Object obj10 = defaultStatisticalCategoryDataset5.clone();
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation14 = null;
        categoryPlot12.setDomainAxisLocation(15, axisLocation14, true);
        org.jfree.chart.util.Layer layer17 = null;
        java.util.Collection collection18 = categoryPlot12.getDomainMarkers(layer17);
        org.jfree.chart.axis.CategoryAxis categoryAxis19 = categoryPlot12.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart20 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent21 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot12);
        org.jfree.chart.plot.Plot plot22 = categoryPlot12.getParent();
        defaultStatisticalCategoryDataset5.addChangeListener((org.jfree.data.general.DatasetChangeListener) plot22);
        org.jfree.data.Range range25 = defaultStatisticalCategoryDataset5.getRangeBounds(true);
        org.junit.Assert.assertNotNull(shape2);
        org.junit.Assert.assertNotNull(list6);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNull(collection18);
        org.junit.Assert.assertNull(categoryAxis19);
        org.junit.Assert.assertNull(plot22);
        org.junit.Assert.assertNull(range25);
    }

//    @Test
//    public void test377() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test377");
//        org.jfree.chart.ui.ProjectInfo projectInfo0 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str1 = projectInfo0.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray2 = projectInfo0.getLibraries();
//        java.lang.String str3 = projectInfo0.getLicenceText();
//        java.awt.Image image4 = projectInfo0.getLogo();
//        org.jfree.chart.text.TextBlock textBlock5 = new org.jfree.chart.text.TextBlock();
//        java.util.List list6 = textBlock5.getLines();
//        projectInfo0.setContributors(list6);
//        projectInfo0.setCopyright("java.awt.Color[r=192,g=0,b=0]");
//        org.junit.Assert.assertNotNull(projectInfo0);
//        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "RectangleAnchor.CENTER" + "'", str1.equals("RectangleAnchor.CENTER"));
//        org.junit.Assert.assertNotNull(libraryArray2);
//        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "ThreadContext" + "'", str3.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(image4);
//        org.junit.Assert.assertNotNull(list6);
//    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getInsets();
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = categoryPlot0.getRangeAxisEdge();
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(rectangleEdge12);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.jfree.data.Range range3 = numberAxis1.getRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range3, (double) 10.0f, false);
        boolean boolean9 = range3.intersects((double) (short) -1, (double) 10L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace2 = null;
        categoryPlot0.setFixedDomainAxisSpace(axisSpace2);
        org.jfree.chart.axis.CategoryAnchor categoryAnchor4 = categoryPlot0.getDomainGridlinePosition();
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot6.setDomainAxisLocation(15, axisLocation8, true);
        org.jfree.chart.util.Layer layer11 = null;
        java.util.Collection collection12 = categoryPlot6.getDomainMarkers(layer11);
        org.jfree.chart.axis.CategoryAxis categoryAxis13 = categoryPlot6.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot6);
        boolean boolean15 = categoryPlot6.isRangeGridlinesVisible();
        boolean boolean16 = categoryAnchor4.equals((java.lang.Object) categoryPlot6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(categoryAnchor4);
        org.junit.Assert.assertNull(collection12);
        org.junit.Assert.assertNull(categoryAxis13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, 0.0f, (float) (-1), textBlockAnchor4, 0.0f, (float) 10, (double) 10);
        java.awt.Graphics2D graphics2D9 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor12 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor13 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition14 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor12, textBlockAnchor13);
        textBlock0.draw(graphics2D9, (float) 0L, (float) 0, textBlockAnchor13, (float) 0L, (float) (byte) 10, (double) 0.0f);
        org.jfree.chart.axis.AxisLocation axisLocation19 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot20 = new org.jfree.chart.plot.CategoryPlot();
        int int21 = categoryPlot20.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge22 = categoryPlot20.getRangeAxisEdge();
        java.awt.Paint paint23 = categoryPlot20.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = categoryPlot20.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = categoryPlot20.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo29 = null;
        java.awt.geom.Point2D point2D30 = null;
        categoryPlot20.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo29, point2D30);
        org.jfree.chart.plot.PlotOrientation plotOrientation32 = categoryPlot20.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge33 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation19, plotOrientation32);
        boolean boolean34 = textBlockAnchor13.equals((java.lang.Object) plotOrientation32);
        java.lang.String str35 = textBlockAnchor13.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(rectangleAnchor12);
        org.junit.Assert.assertNotNull(textBlockAnchor13);
        org.junit.Assert.assertNotNull(axisLocation19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge22);
        org.junit.Assert.assertNotNull(paint23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertNotNull(plotOrientation32);
        org.junit.Assert.assertNotNull(rectangleEdge33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "TextBlockAnchor.TOP_LEFT" + "'", str35.equals("TextBlockAnchor.TOP_LEFT"));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("RectangleEdge.RIGHT");
        java.awt.Font font3 = categoryAxis1.getTickLabelFont((java.lang.Comparable) "RectangleEdge.RIGHT");
        categoryAxis1.setTickMarkOutsideLength(0.8f);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent6 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis1);
        org.junit.Assert.assertNotNull(font3);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        double double12 = rectangleInsets8.extendHeight((double) 100.0f);
        double double14 = rectangleInsets8.calculateTopOutset((double) 'a');
        java.awt.Font font16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("ClassContext", font16);
        labelBlock17.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        boolean boolean21 = labelBlock17.equals((java.lang.Object) textTitle20);
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle20.getBounds();
        java.awt.geom.Rectangle2D rectangle2D23 = rectangleInsets8.createOutsetRectangle(rectangle2D22);
        double double25 = rectangleInsets8.calculateBottomInset((double) 0.0f);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.0d + "'", double12 == 100.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertNotNull(rectangle2D23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        java.awt.Stroke stroke5 = statisticalBarRenderer0.getBaseOutlineStroke();
        boolean boolean6 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition7 = statisticalBarRenderer0.getBasePositiveItemLabelPosition();
        boolean boolean8 = statisticalBarRenderer0.getIncludeBaseInRange();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke10 = statisticalBarRenderer9.getBaseStroke();
        java.awt.Paint paint12 = statisticalBarRenderer9.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke13 = statisticalBarRenderer9.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition15 = null;
        statisticalBarRenderer9.setSeriesNegativeItemLabelPosition(255, itemLabelPosition15);
        boolean boolean17 = statisticalBarRenderer9.getBaseItemLabelsVisible();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator19 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer9.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        statisticalBarRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator19);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition24 = statisticalBarRenderer0.getPositiveItemLabelPosition(0, (int) (byte) 10);
        java.awt.Paint paint25 = statisticalBarRenderer0.getBasePaint();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(itemLabelPosition7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition24);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        categoryPlot0.setForegroundAlpha((float) 0);
        java.awt.Color color5 = java.awt.Color.darkGray;
        float[] floatArray12 = new float[] { 255, (-1L), 2, (short) 10, '4', 1 };
        float[] floatArray13 = color5.getRGBColorComponents(floatArray12);
        categoryPlot0.setBackgroundPaint((java.awt.Paint) color5);
        int int15 = color5.getRed();
        int int16 = color5.getGreen();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertNotNull(floatArray13);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 64 + "'", int15 == 64);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 64 + "'", int16 == 64);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        org.jfree.chart.plot.CategoryPlot categoryPlot3 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation5 = null;
        categoryPlot3.setDomainAxisLocation(15, axisLocation5, true);
        org.jfree.chart.util.Layer layer8 = null;
        java.util.Collection collection9 = categoryPlot3.getDomainMarkers(layer8);
        org.jfree.chart.axis.CategoryAxis categoryAxis10 = categoryPlot3.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart11 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot3);
        org.jfree.chart.event.ChartProgressEvent chartProgressEvent14 = new org.jfree.chart.event.ChartProgressEvent((java.lang.Object) "ClassContext", jFreeChart11, (-4194304), (-4194304));
        int int15 = chartProgressEvent14.getType();
        int int16 = chartProgressEvent14.getPercent();
        org.junit.Assert.assertNull(collection9);
        org.junit.Assert.assertNull(categoryAxis10);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-4194304) + "'", int15 == (-4194304));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        java.awt.Font font5 = statisticalBarRenderer0.getBaseItemLabelFont();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer0.setSeriesFillPaint(100, paint7, true);
        statisticalBarRenderer0.setBaseCreateEntities(true);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_LOWER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        java.awt.Font font5 = statisticalBarRenderer0.getBaseItemLabelFont();
        try {
            statisticalBarRenderer0.setSeriesCreateEntities((-1), (java.lang.Boolean) false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        int int8 = categoryPlot0.getWeight();
        org.jfree.data.category.CategoryDataset categoryDataset10 = categoryPlot0.getDataset((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNull(categoryDataset10);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("ClassContext");
        textTitle0.setHeight((double) (byte) 100);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Object obj1 = booleanList0.clone();
        booleanList0.clear();
        booleanList0.setBoolean((int) ' ', (java.lang.Boolean) true);
        org.junit.Assert.assertNotNull(obj1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setPositiveArrowVisible(true);
        numberAxis11.setFixedAutoRange((double) (short) 0);
        numberAxis11.setRangeWithMargins((double) 0, (double) '#');
        numberAxis11.setAutoRange(false);
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("ClassContext", font22);
        labelBlock23.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        boolean boolean27 = labelBlock23.equals((java.lang.Object) textTitle26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        statisticalBarRenderer0.drawRangeGridline(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis11, rectangle2D28, (double) (-16711681));
        boolean boolean31 = numberAxis11.isTickMarksVisible();
        numberAxis11.setVerticalTickLabels(true);
        org.jfree.chart.axis.NumberAxis numberAxis35 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean36 = numberAxis35.isVerticalTickLabels();
        org.jfree.data.Range range37 = numberAxis35.getRange();
        org.jfree.data.Range range40 = org.jfree.data.Range.shift(range37, (double) 10.0f, false);
        org.jfree.data.Range range43 = org.jfree.data.Range.shift(range40, (double) (-4194304), false);
        numberAxis11.setRange(range43, false, true);
        double double47 = numberAxis11.getUpperBound();
        boolean boolean48 = numberAxis11.isNegativeArrowVisible();
        boolean boolean49 = numberAxis11.isVerticalTickLabels();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(range37);
        org.junit.Assert.assertNotNull(range40);
        org.junit.Assert.assertNotNull(range43);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator2 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator3 = statisticalBarRenderer0.getLegendItemLabelGenerator();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator2);
        org.junit.Assert.assertNotNull(categorySeriesLabelGenerator3);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor4 = org.jfree.chart.labels.ItemLabelAnchor.OUTSIDE3;
        org.jfree.chart.text.TextAnchor textAnchor5 = org.jfree.chart.text.TextAnchor.BASELINE_CENTER;
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = new org.jfree.chart.labels.ItemLabelPosition(itemLabelAnchor4, textAnchor5);
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("[size=1]", graphics2D1, (float) '4', 0.5f, textAnchor5, (double) 'a', (float) 4, 0.8f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(itemLabelAnchor4);
        org.junit.Assert.assertNotNull(textAnchor5);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.jfree.data.Range range3 = numberAxis1.getRange();
        org.jfree.data.Range range6 = org.jfree.data.Range.shift(range3, (double) 10.0f, false);
        double double7 = range3.getCentralValue();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(range6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.5d + "'", double7 == 0.5d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.jfree.chart.plot.ValueMarker valueMarker1 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation4 = null;
        categoryPlot2.setDomainAxisLocation(15, axisLocation4, true);
        categoryPlot2.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset8 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer9 = categoryPlot2.getRendererForDataset(categoryDataset8);
        java.awt.Stroke stroke10 = categoryPlot2.getOutlineStroke();
        valueMarker1.setStroke(stroke10);
        valueMarker1.setLabel("ThreadContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets14 = valueMarker1.getLabelOffset();
        java.awt.geom.Rectangle2D rectangle2D15 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D16 = rectangleInsets14.createOutsetRectangle(rectangle2D15);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer9);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNotNull(rectangleInsets14);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean2 = numberAxis1.isVerticalTickLabels();
        org.jfree.data.Range range3 = numberAxis1.getRange();
        numberAxis1.resizeRange((-1.0d));
        java.lang.Object obj6 = numberAxis1.clone();
        numberAxis1.setFixedAutoRange(0.05d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertNotNull(range3);
        org.junit.Assert.assertNotNull(obj6);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        jFreeChart9.clearSubtitles();
        jFreeChart9.setBackgroundImageAlpha(0.5f);
        org.jfree.chart.event.ChartProgressListener chartProgressListener13 = null;
        jFreeChart9.removeProgressListener(chartProgressListener13);
        jFreeChart9.setNotify(true);
        java.lang.Object obj17 = jFreeChart9.clone();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj17);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        boolean boolean8 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        java.awt.Color color9 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        statisticalBarRenderer0.setBaseOutlinePaint((java.awt.Paint) color9);
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator11 = null;
        statisticalBarRenderer0.setBaseToolTipGenerator(categoryToolTipGenerator11);
        java.awt.Shape shape15 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset18 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list19 = defaultStatisticalCategoryDataset18.getColumnKeys();
        org.jfree.chart.entity.CategoryItemEntity categoryItemEntity22 = new org.jfree.chart.entity.CategoryItemEntity(shape15, "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18, (java.lang.Comparable) "ItemLabelAnchor.INSIDE7", (java.lang.Comparable) 'a');
        int int23 = defaultStatisticalCategoryDataset18.getColumnCount();
        int int24 = defaultStatisticalCategoryDataset18.getColumnCount();
        org.jfree.data.Range range25 = statisticalBarRenderer0.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18);
        org.jfree.data.general.PieDataset pieDataset27 = org.jfree.data.general.DatasetUtilities.createPieDatasetForRow((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset18, 2);
        try {
            java.lang.Number number30 = defaultStatisticalCategoryDataset18.getValue((int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.IndexOutOfBoundsException; message: Index: 0, Size: 0");
        } catch (java.lang.IndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(shape15);
        org.junit.Assert.assertNotNull(list19);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNull(range25);
        org.junit.Assert.assertNotNull(pieDataset27);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.jfree.data.statistics.MeanAndStandardDeviation meanAndStandardDeviation2 = new org.jfree.data.statistics.MeanAndStandardDeviation((double) (-1L), (double) 10);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer3 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke4 = statisticalBarRenderer3.getBaseStroke();
        java.awt.Paint paint6 = statisticalBarRenderer3.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke7 = statisticalBarRenderer3.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition9 = null;
        statisticalBarRenderer3.setSeriesNegativeItemLabelPosition(255, itemLabelPosition9);
        boolean boolean11 = statisticalBarRenderer3.getBaseItemLabelsVisible();
        java.awt.Color color12 = org.jfree.chart.ChartColor.LIGHT_GREEN;
        statisticalBarRenderer3.setBaseOutlinePaint((java.awt.Paint) color12);
        org.jfree.chart.urls.CategoryURLGenerator categoryURLGenerator15 = null;
        statisticalBarRenderer3.setSeriesURLGenerator(0, categoryURLGenerator15, true);
        boolean boolean18 = statisticalBarRenderer3.getAutoPopulateSeriesShape();
        boolean boolean19 = meanAndStandardDeviation2.equals((java.lang.Object) statisticalBarRenderer3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertNull(paint6);
        org.junit.Assert.assertNotNull(stroke7);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(color12);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.jfree.chart.ui.BasicProjectInfo basicProjectInfo5 = new org.jfree.chart.ui.BasicProjectInfo("[size=1]", "", "DatasetRenderingOrder.FORWARD", "CategoryAnchor.MIDDLE", "ClassContext");
        java.lang.String str6 = basicProjectInfo5.getLicenceName();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "ClassContext" + "'", str6.equals("ClassContext"));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.awt.geom.Line2D line2D0 = null;
        try {
            java.awt.Shape shape2 = org.jfree.chart.util.ShapeUtilities.createLineRegion(line2D0, 1.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, 0.0f, (float) (-1), textBlockAnchor4, 0.0f, (float) 10, (double) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator10 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator11 = null;
        java.lang.String str12 = legendItemEntity9.getImageMapAreaTag(toolTipTagFragmentGenerator10, uRLTagFragmentGenerator11);
        legendItemEntity9.setSeriesKey((java.lang.Comparable) "");
        java.lang.String str15 = legendItemEntity9.toString();
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator16 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator17 = null;
        java.lang.String str18 = legendItemEntity9.getImageMapAreaTag(toolTipTagFragmentGenerator16, uRLTagFragmentGenerator17);
        java.lang.String str19 = legendItemEntity9.getURLText();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "LegendItemEntity: seriesKey=, dataset=null" + "'", str15.equals("LegendItemEntity: seriesKey=, dataset=null"));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "" + "'", str18.equals(""));
        org.junit.Assert.assertNull(str19);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle13.setFont(font14);
        textTitle13.setHeight((double) (short) -1);
        jFreeChart9.setTitle(textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart9.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = legendTitle19.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor21 = legendTitle19.getLegendItemGraphicAnchor();
        org.jfree.chart.util.RectangleInsets rectangleInsets22 = null;
        try {
            legendTitle19.setLegendItemGraphicPadding(rectangleInsets22);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'padding' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
        org.junit.Assert.assertNotNull(rectangleAnchor21);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis0.setTickLabelsVisible(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis0.getCategoryLabelPositions();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor6 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor7 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition8 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor6, textBlockAnchor7);
        org.jfree.chart.text.TextAnchor textAnchor9 = categoryLabelPosition8.getRotationAnchor();
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.replaceLeftPosition(categoryLabelPositions5, categoryLabelPosition8);
        org.jfree.chart.text.TextAnchor textAnchor11 = categoryLabelPosition8.getRotationAnchor();
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNotNull(rectangleAnchor6);
        org.junit.Assert.assertNotNull(textBlockAnchor7);
        org.junit.Assert.assertNotNull(textAnchor9);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertNotNull(textAnchor11);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment0 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment1 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement4 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment0, verticalAlignment1, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        java.lang.Object obj8 = null;
        columnArrangement4.add((org.jfree.chart.block.Block) textTitle5, obj8);
        org.jfree.chart.util.VerticalAlignment verticalAlignment10 = textTitle5.getVerticalAlignment();
        java.lang.String str11 = verticalAlignment10.toString();
        java.lang.String str12 = verticalAlignment10.toString();
        org.junit.Assert.assertNotNull(verticalAlignment10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "VerticalAlignment.CENTER" + "'", str11.equals("VerticalAlignment.CENTER"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "VerticalAlignment.CENTER" + "'", str12.equals("VerticalAlignment.CENTER"));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setTickMarkOutsideLength((float) (short) 100);
        numberAxis1.setLabelAngle((double) '4');
        numberAxis1.setLowerBound((double) (byte) 100);
        org.jfree.chart.axis.MarkerAxisBand markerAxisBand8 = null;
        numberAxis1.setMarkerBand(markerAxisBand8);
        boolean boolean10 = numberAxis1.getAutoRangeIncludesZero();
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.axis.AxisLocation axisLocation5 = categoryPlot0.getRangeAxisLocation();
        org.jfree.chart.axis.ValueAxis valueAxis7 = categoryPlot0.getRangeAxis((int) (byte) 0);
        org.junit.Assert.assertNotNull(axisLocation5);
        org.junit.Assert.assertNull(valueAxis7);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.jfree.chart.util.ObjectUtilities.setClassLoaderSource("Size2D[width=0.0, height=0.0]");
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo0 = null;
        org.jfree.chart.renderer.category.CategoryItemRendererState categoryItemRendererState1 = new org.jfree.chart.renderer.category.CategoryItemRendererState(plotRenderingInfo0);
        org.jfree.chart.entity.EntityCollection entityCollection2 = categoryItemRendererState1.getEntityCollection();
        org.junit.Assert.assertNull(entityCollection2);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        java.awt.Font font5 = statisticalBarRenderer0.getBaseItemLabelFont();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer0.setSeriesFillPaint(100, paint7, true);
        java.awt.Stroke stroke11 = statisticalBarRenderer0.getSeriesOutlineStroke((int) '4');
        boolean boolean12 = statisticalBarRenderer0.getBaseCreateEntities();
        java.awt.Stroke stroke13 = statisticalBarRenderer0.getErrorIndicatorStroke();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator0 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator();
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesShape();
        java.awt.Font font5 = statisticalBarRenderer0.getBaseItemLabelFont();
        java.awt.Paint paint7 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_PAINT;
        statisticalBarRenderer0.setSeriesFillPaint(100, paint7, true);
        java.awt.Stroke stroke11 = statisticalBarRenderer0.getSeriesOutlineStroke((int) '4');
        boolean boolean12 = statisticalBarRenderer0.getBaseCreateEntities();
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType13 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer14 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType13);
        java.lang.Object obj15 = standardGradientPaintTransformer14.clone();
        statisticalBarRenderer0.setGradientPaintTransformer((org.jfree.chart.util.GradientPaintTransformer) standardGradientPaintTransformer14);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(paint7);
        org.junit.Assert.assertNull(stroke11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertNotNull(gradientPaintTransformType13);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        java.awt.Color color0 = java.awt.Color.cyan;
        int int1 = color0.getRGB();
        org.jfree.chart.block.BlockBorder blockBorder2 = new org.jfree.chart.block.BlockBorder((java.awt.Paint) color0);
        int int3 = color0.getRGB();
        org.junit.Assert.assertNotNull(color0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-16711681) + "'", int1 == (-16711681));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-16711681) + "'", int3 == (-16711681));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.jfree.chart.labels.ItemLabelAnchor itemLabelAnchor0 = org.jfree.chart.labels.ItemLabelAnchor.INSIDE5;
        org.junit.Assert.assertNotNull(itemLabelAnchor0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        boolean boolean8 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot13.setDomainAxisLocation(15, axisLocation15, true);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot13.getDomainMarkers(layer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot13.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot13);
        java.lang.Object obj22 = jFreeChart21.clone();
        jFreeChart21.setBackgroundImageAlignment((-4194304));
        java.awt.Paint paint25 = jFreeChart21.getBorderPaint();
        statisticalBarRenderer0.setBaseFillPaint(paint25);
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement32 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment28, verticalAlignment29, (double) ' ', (double) '4');
        columnArrangement32.clear();
        columnArrangement32.clear();
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0, (org.jfree.chart.block.Arrangement) columnArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement32);
        org.jfree.chart.event.ChartChangeEvent chartChangeEvent36 = new org.jfree.chart.event.ChartChangeEvent((java.lang.Object) columnArrangement32);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(paint25);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis("GradientPaintTransformType.HORIZONTAL");
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        org.jfree.chart.axis.NumberAxis numberAxis9 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        double double10 = numberAxis9.getAutoRangeMinimumSize();
        numberAxis9.setVisible(true);
        categoryPlot0.setRangeAxis((int) (short) 10, (org.jfree.chart.axis.ValueAxis) numberAxis9);
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer16 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator17 = statisticalBarRenderer16.getLegendItemToolTipGenerator();
        java.awt.Graphics2D graphics2D18 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot19 = new org.jfree.chart.plot.CategoryPlot();
        int int20 = categoryPlot19.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge21 = categoryPlot19.getRangeAxisEdge();
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer23 = null;
        categoryPlot19.setRenderer((int) (byte) 100, categoryItemRenderer23);
        boolean boolean25 = categoryPlot19.isDomainGridlinesVisible();
        org.jfree.chart.axis.NumberAxis numberAxis27 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean28 = numberAxis27.isVerticalTickLabels();
        org.jfree.data.Range range29 = numberAxis27.getRange();
        org.jfree.chart.plot.ValueMarker valueMarker31 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot32 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation34 = null;
        categoryPlot32.setDomainAxisLocation(15, axisLocation34, true);
        categoryPlot32.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset38 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer39 = categoryPlot32.getRendererForDataset(categoryDataset38);
        java.awt.Stroke stroke40 = categoryPlot32.getOutlineStroke();
        valueMarker31.setStroke(stroke40);
        valueMarker31.setLabel("ThreadContext");
        double double44 = valueMarker31.getValue();
        java.awt.Font font46 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock47 = new org.jfree.chart.block.LabelBlock("ClassContext", font46);
        labelBlock47.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle();
        boolean boolean51 = labelBlock47.equals((java.lang.Object) textTitle50);
        java.awt.geom.Rectangle2D rectangle2D52 = textTitle50.getBounds();
        statisticalBarRenderer16.drawRangeMarker(graphics2D18, categoryPlot19, (org.jfree.chart.axis.ValueAxis) numberAxis27, (org.jfree.chart.plot.Marker) valueMarker31, rectangle2D52);
        org.jfree.chart.block.LineBorder lineBorder54 = new org.jfree.chart.block.LineBorder();
        java.awt.Graphics2D graphics2D55 = null;
        java.awt.Font font57 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock58 = new org.jfree.chart.block.LabelBlock("ClassContext", font57);
        labelBlock58.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle61 = new org.jfree.chart.title.TextTitle();
        boolean boolean62 = labelBlock58.equals((java.lang.Object) textTitle61);
        java.awt.geom.Rectangle2D rectangle2D63 = textTitle61.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot64 = new org.jfree.chart.plot.CategoryPlot();
        int int65 = categoryPlot64.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge66 = categoryPlot64.getRangeAxisEdge();
        double double67 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D63, rectangleEdge66);
        lineBorder54.draw(graphics2D55, rectangle2D63);
        org.jfree.chart.util.RectangleEdge rectangleEdge69 = null;
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo70 = null;
        try {
            org.jfree.chart.axis.AxisState axisState71 = numberAxis9.draw(graphics2D14, 0.05d, rectangle2D52, rectangle2D63, rectangleEdge69, plotRenderingInfo70);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-8d + "'", double10 == 1.0E-8d);
        org.junit.Assert.assertNull(categorySeriesLabelGenerator17);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge21);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(range29);
        org.junit.Assert.assertNull(categoryItemRenderer39);
        org.junit.Assert.assertNotNull(stroke40);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + (-1.0d) + "'", double44 == (-1.0d));
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertNotNull(font57);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(rectangle2D63);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        try {
            org.jfree.chart.util.ObjectList objectList1 = new org.jfree.chart.util.ObjectList((-16711681));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        org.jfree.chart.util.RectangleInsets rectangleInsets11 = categoryPlot0.getInsets();
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset12 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list13 = defaultStatisticalCategoryDataset12.getColumnKeys();
        org.jfree.data.Range range15 = org.jfree.data.general.DatasetUtilities.findRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12, true);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer16 = categoryPlot0.getRendererForDataset((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset12);
        defaultStatisticalCategoryDataset12.add((java.lang.Number) 10.0d, (java.lang.Number) 10.0d, (java.lang.Comparable) 192, (java.lang.Comparable) 100.0d);
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertNotNull(rectangleInsets11);
        org.junit.Assert.assertNotNull(list13);
        org.junit.Assert.assertNull(range15);
        org.junit.Assert.assertNull(categoryItemRenderer16);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
        int int3 = categoryAxis0.getCategoryLabelPositionOffset();
        double double4 = categoryAxis0.getCategoryMargin();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.2d + "'", double4 == 0.2d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        statisticalBarRenderer0.setBaseItemLabelsVisible(false, false);
        boolean boolean6 = statisticalBarRenderer0.isSeriesVisible((int) (short) 100);
        java.awt.Color color8 = java.awt.Color.darkGray;
        float[] floatArray15 = new float[] { 255, (-1L), 2, (short) 10, '4', 1 };
        float[] floatArray16 = color8.getRGBColorComponents(floatArray15);
        try {
            statisticalBarRenderer0.setSeriesOutlinePaint((int) (short) -1, (java.awt.Paint) color8, false);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Requires index >= 0.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.util.Size2D size2D2 = textBlock0.calculateDimensions(graphics2D1);
        java.awt.Font font5 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock6 = new org.jfree.chart.block.LabelBlock("ClassContext", font5);
        java.awt.Color color7 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str8 = color7.toString();
        boolean boolean10 = color7.equals((java.lang.Object) 'a');
        textBlock0.addLine("java.awt.Color[r=192,g=0,b=0]", font5, (java.awt.Paint) color7);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment12 = textBlock0.getLineAlignment();
        java.awt.Graphics2D graphics2D13 = null;
        org.jfree.chart.text.TextBlock textBlock16 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor20 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape24 = textBlock16.calculateBounds(graphics2D17, 0.0f, (float) (-1), textBlockAnchor20, 0.0f, (float) 10, (double) 10);
        java.awt.Graphics2D graphics2D25 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor28 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor29 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition30 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor28, textBlockAnchor29);
        textBlock16.draw(graphics2D25, (float) 0L, (float) 0, textBlockAnchor29, (float) 0L, (float) (byte) 10, (double) 0.0f);
        org.jfree.chart.axis.AxisLocation axisLocation35 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot36 = new org.jfree.chart.plot.CategoryPlot();
        int int37 = categoryPlot36.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot36.getRangeAxisEdge();
        java.awt.Paint paint39 = categoryPlot36.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge40 = categoryPlot36.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge42 = categoryPlot36.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo45 = null;
        java.awt.geom.Point2D point2D46 = null;
        categoryPlot36.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo45, point2D46);
        org.jfree.chart.plot.PlotOrientation plotOrientation48 = categoryPlot36.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge49 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation35, plotOrientation48);
        boolean boolean50 = textBlockAnchor29.equals((java.lang.Object) plotOrientation48);
        try {
            textBlock0.draw(graphics2D13, 32.0f, 0.5f, textBlockAnchor29);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(size2D2);
        org.junit.Assert.assertNotNull(font5);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str8.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(horizontalAlignment12);
        org.junit.Assert.assertNotNull(textBlockAnchor20);
        org.junit.Assert.assertNotNull(shape24);
        org.junit.Assert.assertNotNull(rectangleAnchor28);
        org.junit.Assert.assertNotNull(textBlockAnchor29);
        org.junit.Assert.assertNotNull(axisLocation35);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(paint39);
        org.junit.Assert.assertNotNull(rectangleEdge40);
        org.junit.Assert.assertNotNull(rectangleEdge42);
        org.junit.Assert.assertNotNull(plotOrientation48);
        org.junit.Assert.assertNotNull(rectangleEdge49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        java.text.AttributedString attributedString0 = null;
        java.awt.Shape shape4 = org.jfree.chart.plot.Plot.DEFAULT_LEGEND_ITEM_BOX;
        java.awt.Color color5 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str6 = color5.toString();
        try {
            org.jfree.chart.LegendItem legendItem7 = new org.jfree.chart.LegendItem(attributedString0, "LengthConstraintType.FIXED", "GradientPaintTransformType.HORIZONTAL", "Size2D[width=0.0, height=0.0]", shape4, (java.awt.Paint) color5);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'label' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(shape4);
        org.junit.Assert.assertNotNull(color5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str6.equals("java.awt.Color[r=192,g=0,b=0]"));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        org.jfree.chart.plot.Plot plot11 = jFreeChart9.getPlot();
        java.awt.Stroke stroke12 = jFreeChart9.getBorderStroke();
        jFreeChart9.setNotify(true);
        java.lang.Object obj15 = jFreeChart9.clone();
        try {
            java.awt.image.BufferedImage bufferedImage18 = jFreeChart9.createBufferedImage((int) (byte) 100, (-16711681));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Width (100) and height (-16711681) cannot be <= 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(obj15);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.jfree.chart.util.BooleanList booleanList0 = new org.jfree.chart.util.BooleanList();
        java.lang.Boolean boolean2 = booleanList0.getBoolean(3);
        org.junit.Assert.assertNull(boolean2);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke8 = statisticalBarRenderer7.getBaseStroke();
        java.awt.Paint paint10 = statisticalBarRenderer7.getSeriesOutlinePaint((-1));
        boolean boolean11 = statisticalBarRenderer7.getAutoPopulateSeriesOutlineStroke();
        categoryPlot1.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer7, true);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.INSIDE7", (org.jfree.chart.plot.Plot) categoryPlot1);
        categoryPlot1.setRangeCrosshairLockedOnData(true);
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis8.setTickLabelsVisible(true);
        categoryAxis8.setLowerMargin((double) 100.0f);
        int int15 = categoryPlot0.getDomainAxisIndex(categoryAxis8);
        boolean boolean16 = categoryAxis8.isVisible();
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke9 = statisticalBarRenderer8.getBaseStroke();
        java.awt.Paint paint11 = statisticalBarRenderer8.getSeriesOutlinePaint((-1));
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer12 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke13 = statisticalBarRenderer12.getBaseStroke();
        statisticalBarRenderer8.setBaseStroke(stroke13, false);
        boolean boolean16 = statisticalBarRenderer8.getAutoPopulateSeriesFillPaint();
        categoryPlot0.setRenderer(3, (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer8, false);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNull(paint11);
        org.junit.Assert.assertNotNull(stroke13);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("ClassContext", font1);
        labelBlock2.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        labelBlock2.setToolTipText("");
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis("RectangleEdge.RIGHT");
        java.awt.Font font10 = categoryAxis8.getTickLabelFont((java.lang.Comparable) "RectangleEdge.RIGHT");
        labelBlock2.setFont(font10);
        java.awt.Paint paint12 = org.jfree.chart.text.TextFragment.DEFAULT_PAINT;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot13.setDomainAxisLocation(15, axisLocation15, true);
        categoryPlot13.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset19 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer20 = categoryPlot13.getRendererForDataset(categoryDataset19);
        java.awt.Stroke stroke21 = categoryPlot13.getOutlineStroke();
        org.jfree.chart.util.RectangleInsets rectangleInsets26 = new org.jfree.chart.util.RectangleInsets(1.0d, (double) 10L, (double) (byte) 1, 0.0d);
        org.jfree.chart.block.LineBorder lineBorder27 = new org.jfree.chart.block.LineBorder(paint12, stroke21, rectangleInsets26);
        labelBlock2.setPaint(paint12);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(font10);
        org.junit.Assert.assertNotNull(paint12);
        org.junit.Assert.assertNull(categoryItemRenderer20);
        org.junit.Assert.assertNotNull(stroke21);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        jFreeChart9.setBackgroundImageAlignment((-4194304));
        org.jfree.chart.title.TextTitle textTitle13 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font14 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle13.setFont(font14);
        textTitle13.setHeight((double) (short) -1);
        jFreeChart9.setTitle(textTitle13);
        org.jfree.chart.title.LegendTitle legendTitle19 = jFreeChart9.getLegend();
        org.jfree.chart.util.RectangleAnchor rectangleAnchor20 = legendTitle19.getLegendItemGraphicLocation();
        org.jfree.chart.block.BlockContainer blockContainer21 = null;
        legendTitle19.setWrapper(blockContainer21);
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertNotNull(legendTitle19);
        org.junit.Assert.assertNotNull(rectangleAnchor20);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.jfree.data.Range range1 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint2 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range1);
        org.jfree.data.Range range3 = null;
        try {
            org.jfree.chart.block.RectangleConstraint rectangleConstraint4 = rectangleConstraint2.toRangeWidth(range3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'range' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer1 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color3 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str4 = color3.toString();
        statisticalBarRenderer1.setSeriesOutlinePaint(2, (java.awt.Paint) color3, false);
        java.awt.Color color7 = color3.brighter();
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer8 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke9 = statisticalBarRenderer8.getBaseStroke();
        statisticalBarRenderer8.setAutoPopulateSeriesStroke(false);
        statisticalBarRenderer8.setBaseSeriesVisible(false, false);
        java.awt.Stroke stroke16 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_OUTLINE_STROKE;
        statisticalBarRenderer8.setSeriesStroke(255, stroke16);
        java.awt.Stroke stroke18 = statisticalBarRenderer8.getBaseStroke();
        org.jfree.chart.plot.ValueMarker valueMarker19 = new org.jfree.chart.plot.ValueMarker((double) 'a', (java.awt.Paint) color7, stroke18);
        org.junit.Assert.assertNotNull(color3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str4.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(stroke9);
        org.junit.Assert.assertNotNull(stroke16);
        org.junit.Assert.assertNotNull(stroke18);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        java.awt.Font font0 = org.jfree.chart.title.TextTitle.DEFAULT_FONT;
        org.junit.Assert.assertNotNull(font0);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape6, (java.awt.Paint) color7);
        java.lang.String str9 = legendItem8.getLabel();
        int int10 = legendItem8.getDatasetIndex();
        boolean boolean11 = legendItem8.isLineVisible();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "ClassContext" + "'", str9.equals("ClassContext"));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis0.setTickLabelsVisible(true);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions5 = categoryAxis0.getCategoryLabelPositions();
        org.jfree.chart.plot.CategoryPlot categoryPlot7 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation9 = null;
        categoryPlot7.setDomainAxisLocation(15, axisLocation9, true);
        org.jfree.chart.util.Layer layer12 = null;
        java.util.Collection collection13 = categoryPlot7.getDomainMarkers(layer12);
        org.jfree.chart.axis.CategoryAxis categoryAxis14 = categoryPlot7.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart15 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot7);
        org.jfree.chart.event.PlotChangeEvent plotChangeEvent16 = new org.jfree.chart.event.PlotChangeEvent((org.jfree.chart.plot.Plot) categoryPlot7);
        org.jfree.chart.JFreeChart jFreeChart17 = plotChangeEvent16.getChart();
        boolean boolean18 = categoryLabelPositions5.equals((java.lang.Object) jFreeChart17);
        org.junit.Assert.assertNotNull(categoryLabelPositions5);
        org.junit.Assert.assertNull(collection13);
        org.junit.Assert.assertNull(categoryAxis14);
        org.junit.Assert.assertNull(jFreeChart17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Color color8 = java.awt.Color.darkGray;
        float[] floatArray15 = new float[] { 255, (-1L), 2, (short) 10, '4', 1 };
        float[] floatArray16 = color8.getRGBColorComponents(floatArray15);
        statisticalBarRenderer0.setBaseItemLabelPaint((java.awt.Paint) color8);
        java.lang.Boolean boolean19 = statisticalBarRenderer0.getSeriesItemLabelsVisible((int) (short) 10);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color8);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNull(boolean19);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
        int int3 = categoryAxis0.getCategoryLabelPositionOffset();
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent4 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) categoryAxis0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 4 + "'", int3 == 4);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        java.awt.Color color1 = java.awt.Color.getColor("");
        org.junit.Assert.assertNull(color1);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        org.jfree.chart.block.BorderArrangement borderArrangement0 = new org.jfree.chart.block.BorderArrangement();
        org.jfree.chart.axis.CategoryAxis categoryAxis1 = new org.jfree.chart.axis.CategoryAxis();
        float float2 = categoryAxis1.getMaximumCategoryLabelWidthRatio();
        org.jfree.chart.axis.CategoryAnchor categoryAnchor3 = null;
        java.awt.geom.Rectangle2D rectangle2D6 = null;
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = null;
        double double8 = categoryAxis1.getCategoryJava2DCoordinate(categoryAnchor3, (int) '#', (int) (short) 10, rectangle2D6, rectangleEdge7);
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions10 = org.jfree.chart.axis.CategoryLabelPositions.createDownRotationLabelPositions(10.0d);
        categoryAxis1.setCategoryLabelPositions(categoryLabelPositions10);
        org.jfree.chart.util.RectangleEdge rectangleEdge12 = org.jfree.chart.util.RectangleEdge.RIGHT;
        boolean boolean13 = org.jfree.chart.util.RectangleEdge.isTopOrBottom(rectangleEdge12);
        java.lang.String str14 = rectangleEdge12.toString();
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition15 = categoryLabelPositions10.getLabelPosition(rectangleEdge12);
        boolean boolean16 = borderArrangement0.equals((java.lang.Object) categoryLabelPositions10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(categoryLabelPositions10);
        org.junit.Assert.assertNotNull(rectangleEdge12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "RectangleEdge.RIGHT" + "'", str14.equals("RectangleEdge.RIGHT"));
        org.junit.Assert.assertNotNull(categoryLabelPosition15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategorySeriesLabelGenerator categorySeriesLabelGenerator1 = statisticalBarRenderer0.getLegendItemToolTipGenerator();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator3 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer0.setLegendItemURLGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator3);
        org.jfree.chart.plot.CategoryPlot categoryPlot5 = new org.jfree.chart.plot.CategoryPlot();
        int int6 = categoryPlot5.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot5.getRangeAxisEdge();
        java.awt.Paint paint8 = categoryPlot5.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge9 = categoryPlot5.getRangeAxisEdge();
        boolean boolean10 = categoryPlot5.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis11 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis11.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double14 = categoryAxis11.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit15 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int16 = numberTickUnit15.getMinorTickCount();
        java.awt.Font font17 = categoryAxis11.getTickLabelFont((java.lang.Comparable) numberTickUnit15);
        categoryPlot5.setNoDataMessageFont(font17);
        int int19 = categoryPlot5.getDatasetCount();
        java.awt.Stroke stroke20 = categoryPlot5.getRangeCrosshairStroke();
        statisticalBarRenderer0.setBaseStroke(stroke20);
        java.awt.Graphics2D graphics2D22 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
        int int24 = categoryPlot23.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge25 = categoryPlot23.getRangeAxisEdge();
        org.jfree.data.general.DatasetChangeEvent datasetChangeEvent26 = null;
        categoryPlot23.datasetChanged(datasetChangeEvent26);
        boolean boolean28 = categoryPlot23.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge29 = categoryPlot23.getRangeAxisEdge();
        org.jfree.chart.axis.CategoryAxis categoryAxis30 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis30.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis30.setMaximumCategoryLabelWidthRatio((float) (-1L));
        org.jfree.chart.plot.CategoryMarker categoryMarker36 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis37 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis37.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis37.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D43 = null;
        org.jfree.chart.axis.AxisState axisState44 = null;
        java.awt.Font font46 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock47 = new org.jfree.chart.block.LabelBlock("ClassContext", font46);
        labelBlock47.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle50 = new org.jfree.chart.title.TextTitle();
        boolean boolean51 = labelBlock47.equals((java.lang.Object) textTitle50);
        java.awt.geom.Rectangle2D rectangle2D52 = textTitle50.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot53 = new org.jfree.chart.plot.CategoryPlot();
        int int54 = categoryPlot53.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge55 = categoryPlot53.getRangeAxisEdge();
        java.awt.Paint paint56 = categoryPlot53.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge57 = categoryPlot53.getRangeAxisEdge();
        java.util.List list58 = categoryAxis37.refreshTicks(graphics2D43, axisState44, rectangle2D52, rectangleEdge57);
        org.jfree.chart.entity.ChartEntity chartEntity59 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D52);
        java.awt.Shape shape62 = org.jfree.chart.util.ShapeUtilities.createTranslatedShape((java.awt.Shape) rectangle2D52, (double) 15, (double) 32.0f);
        try {
            statisticalBarRenderer0.drawDomainMarker(graphics2D22, categoryPlot23, categoryAxis30, categoryMarker36, rectangle2D52);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(categorySeriesLabelGenerator1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertNotNull(paint8);
        org.junit.Assert.assertNotNull(rectangleEdge9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(font17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
        org.junit.Assert.assertNotNull(stroke20);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge25);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(rectangleEdge29);
        org.junit.Assert.assertNotNull(font46);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertNotNull(rectangle2D52);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge55);
        org.junit.Assert.assertNotNull(paint56);
        org.junit.Assert.assertNotNull(rectangleEdge57);
        org.junit.Assert.assertNotNull(list58);
        org.junit.Assert.assertNotNull(shape62);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.util.RectangleEdge rectangleEdge7 = categoryPlot0.getDomainAxisEdge((int) (short) -1);
        boolean boolean8 = categoryPlot0.isSubplot();
        org.jfree.chart.axis.AxisLocation axisLocation10 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        int int12 = categoryPlot11.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot11.getRangeAxisEdge();
        java.awt.Paint paint14 = categoryPlot11.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot11.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot11.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo20 = null;
        java.awt.geom.Point2D point2D21 = null;
        categoryPlot11.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo20, point2D21);
        org.jfree.chart.plot.PlotOrientation plotOrientation23 = categoryPlot11.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge24 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation10, plotOrientation23);
        categoryPlot0.setRangeAxisLocation(0, axisLocation10, false);
        org.jfree.chart.axis.AxisSpace axisSpace27 = categoryPlot0.getFixedDomainAxisSpace();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(rectangleEdge7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(axisLocation10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertNotNull(paint14);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(plotOrientation23);
        org.junit.Assert.assertNotNull(rectangleEdge24);
        org.junit.Assert.assertNull(axisSpace27);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.jfree.chart.util.GradientPaintTransformType gradientPaintTransformType0 = org.jfree.chart.util.GradientPaintTransformType.VERTICAL;
        org.jfree.chart.util.StandardGradientPaintTransformer standardGradientPaintTransformer1 = new org.jfree.chart.util.StandardGradientPaintTransformer(gradientPaintTransformType0);
        java.awt.GradientPaint gradientPaint2 = null;
        java.awt.Font font4 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock5 = new org.jfree.chart.block.LabelBlock("ClassContext", font4);
        labelBlock5.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle8 = new org.jfree.chart.title.TextTitle();
        boolean boolean9 = labelBlock5.equals((java.lang.Object) textTitle8);
        java.awt.geom.Rectangle2D rectangle2D10 = textTitle8.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot11 = new org.jfree.chart.plot.CategoryPlot();
        int int12 = categoryPlot11.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge13 = categoryPlot11.getRangeAxisEdge();
        double double14 = org.jfree.chart.util.RectangleEdge.coordinate(rectangle2D10, rectangleEdge13);
        try {
            java.awt.GradientPaint gradientPaint15 = standardGradientPaintTransformer1.transform(gradientPaint2, (java.awt.Shape) rectangle2D10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(gradientPaintTransformType0);
        org.junit.Assert.assertNotNull(font4);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(rectangle2D10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        java.awt.Paint paint0 = org.jfree.chart.axis.Axis.DEFAULT_TICK_LABEL_PAINT;
        org.junit.Assert.assertNotNull(paint0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.ValueMarker valueMarker9 = new org.jfree.chart.plot.ValueMarker((-1.0d));
        org.jfree.chart.plot.CategoryPlot categoryPlot10 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation12 = null;
        categoryPlot10.setDomainAxisLocation(15, axisLocation12, true);
        categoryPlot10.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset16 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer17 = categoryPlot10.getRendererForDataset(categoryDataset16);
        java.awt.Stroke stroke18 = categoryPlot10.getOutlineStroke();
        valueMarker9.setStroke(stroke18);
        org.jfree.chart.util.Layer layer20 = org.jfree.chart.util.Layer.FOREGROUND;
        categoryPlot0.addRangeMarker((int) (short) 1, (org.jfree.chart.plot.Marker) valueMarker9, layer20);
        int int22 = categoryPlot0.getWeight();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNull(categoryItemRenderer17);
        org.junit.Assert.assertNotNull(stroke18);
        org.junit.Assert.assertNotNull(layer20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        double double0 = org.jfree.chart.axis.ValueAxis.DEFAULT_UPPER_MARGIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.05d + "'", double0 == 0.05d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.jfree.chart.axis.AxisState axisState1 = new org.jfree.chart.axis.AxisState(100.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, 0.0f, (float) (-1), textBlockAnchor4, 0.0f, (float) 10, (double) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity9 = new org.jfree.chart.entity.LegendItemEntity(shape8);
        org.jfree.chart.imagemap.ToolTipTagFragmentGenerator toolTipTagFragmentGenerator10 = null;
        org.jfree.chart.imagemap.URLTagFragmentGenerator uRLTagFragmentGenerator11 = null;
        java.lang.String str12 = legendItemEntity9.getImageMapAreaTag(toolTipTagFragmentGenerator10, uRLTagFragmentGenerator11);
        java.lang.String str13 = legendItemEntity9.toString();
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "LegendItemEntity: seriesKey=null, dataset=null" + "'", str13.equals("LegendItemEntity: seriesKey=null, dataset=null"));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("ClassContext");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.title.Title title4 = titleChangeEvent3.getTitle();
        java.awt.Graphics2D graphics2D5 = null;
        org.jfree.data.Range range7 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint8 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range7);
        double double9 = rectangleConstraint8.getWidth();
        org.jfree.chart.block.LengthConstraintType lengthConstraintType10 = rectangleConstraint8.getWidthConstraintType();
        org.jfree.data.Range range11 = rectangleConstraint8.getHeightRange();
        try {
            org.jfree.chart.util.Size2D size2D12 = title4.arrange(graphics2D5, rectangleConstraint8);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(title4);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 100.0d + "'", double9 == 100.0d);
        org.junit.Assert.assertNotNull(lengthConstraintType10);
        org.junit.Assert.assertNull(range11);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        java.awt.Shape shape0 = null;
        try {
            org.jfree.chart.entity.ChartEntity chartEntity2 = new org.jfree.chart.entity.ChartEntity(shape0, "[size=1]");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'area' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = java.awt.Color.white;
        statisticalBarRenderer0.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color7);
        org.jfree.chart.title.LegendTitle legendTitle9 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0);
        java.awt.Paint paint10 = legendTitle9.getItemPaint();
        java.awt.Stroke stroke11 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot12 = new org.jfree.chart.plot.CategoryPlot();
        int int13 = categoryPlot12.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge14 = categoryPlot12.getRangeAxisEdge();
        java.awt.Paint paint15 = categoryPlot12.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge16 = categoryPlot12.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge18 = categoryPlot12.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo21 = null;
        java.awt.geom.Point2D point2D22 = null;
        categoryPlot12.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo21, point2D22);
        boolean boolean24 = categoryPlot12.isDomainZoomable();
        java.awt.Graphics2D graphics2D25 = null;
        java.awt.Font font27 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("ClassContext", font27);
        labelBlock28.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        boolean boolean32 = labelBlock28.equals((java.lang.Object) textTitle31);
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle31.getBounds();
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo35 = null;
        boolean boolean36 = categoryPlot12.render(graphics2D25, rectangle2D33, (int) (byte) 100, plotRenderingInfo35);
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer38 = categoryPlot12.getRenderer((int) ' ');
        org.jfree.chart.plot.CategoryPlot categoryPlot39 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation41 = null;
        categoryPlot39.setDomainAxisLocation(15, axisLocation41, true);
        org.jfree.chart.title.TextTitle textTitle44 = new org.jfree.chart.title.TextTitle();
        textTitle44.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets47 = textTitle44.getMargin();
        categoryPlot39.setInsets(rectangleInsets47, false);
        double double51 = rectangleInsets47.extendHeight((double) 100.0f);
        java.lang.String str52 = rectangleInsets47.toString();
        categoryPlot12.setAxisOffset(rectangleInsets47);
        try {
            org.jfree.chart.block.LineBorder lineBorder54 = new org.jfree.chart.block.LineBorder(paint10, stroke11, rectangleInsets47);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'stroke' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(paint10);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge14);
        org.junit.Assert.assertNotNull(paint15);
        org.junit.Assert.assertNotNull(rectangleEdge16);
        org.junit.Assert.assertNotNull(rectangleEdge18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNull(categoryItemRenderer38);
        org.junit.Assert.assertNotNull(rectangleInsets47);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 100.0d + "'", double51 == 100.0d);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]" + "'", str52.equals("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]"));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        java.awt.Font font2 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock3 = new org.jfree.chart.block.LabelBlock("ClassContext", font2);
        org.jfree.chart.title.TextTitle textTitle4 = new org.jfree.chart.title.TextTitle("CategoryAnchor.MIDDLE", font2);
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        org.jfree.chart.plot.Plot plot11 = jFreeChart9.getPlot();
        java.awt.Stroke stroke12 = jFreeChart9.getBorderStroke();
        org.jfree.chart.text.TextBlock textBlock13 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D14 = null;
        org.jfree.chart.util.Size2D size2D15 = textBlock13.calculateDimensions(graphics2D14);
        java.awt.Font font18 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock19 = new org.jfree.chart.block.LabelBlock("ClassContext", font18);
        java.awt.Color color20 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str21 = color20.toString();
        boolean boolean23 = color20.equals((java.lang.Object) 'a');
        textBlock13.addLine("java.awt.Color[r=192,g=0,b=0]", font18, (java.awt.Paint) color20);
        jFreeChart9.setBorderPaint((java.awt.Paint) color20);
        java.lang.Object obj26 = jFreeChart9.getTextAntiAlias();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(size2D15);
        org.junit.Assert.assertNotNull(font18);
        org.junit.Assert.assertNotNull(color20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str21.equals("java.awt.Color[r=192,g=0,b=0]"));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNull(obj26);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        java.awt.Color color7 = java.awt.Color.white;
        statisticalBarRenderer0.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color7);
        java.awt.Color color9 = java.awt.Color.darkGray;
        float[] floatArray16 = new float[] { 255, (-1L), 2, (short) 10, '4', 1 };
        float[] floatArray17 = color9.getRGBColorComponents(floatArray16);
        float[] floatArray18 = color7.getRGBColorComponents(floatArray17);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(color9);
        org.junit.Assert.assertNotNull(floatArray16);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        java.awt.Color color0 = org.jfree.chart.ChartColor.DARK_YELLOW;
        org.junit.Assert.assertNotNull(color0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setURLText("hi!");
        org.jfree.chart.util.RectangleEdge rectangleEdge3 = textTitle0.getPosition();
        java.lang.String str4 = rectangleEdge3.toString();
        org.junit.Assert.assertNotNull(rectangleEdge3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "RectangleEdge.TOP" + "'", str4.equals("RectangleEdge.TOP"));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot0.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo9 = null;
        java.awt.geom.Point2D point2D10 = null;
        categoryPlot0.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo9, point2D10);
        org.jfree.chart.axis.CategoryAxis categoryAxis12 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis12.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis12.setTickLabelsVisible(true);
        java.util.List list17 = categoryPlot0.getCategoriesForAxis(categoryAxis12);
        org.jfree.chart.plot.CategoryPlot categoryPlot18 = new org.jfree.chart.plot.CategoryPlot();
        int int19 = categoryPlot18.getWeight();
        org.jfree.chart.axis.AxisSpace axisSpace20 = null;
        categoryPlot18.setFixedDomainAxisSpace(axisSpace20);
        org.jfree.chart.axis.NumberAxis numberAxis23 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis23.setVisible(true);
        org.jfree.chart.event.AxisChangeEvent axisChangeEvent26 = new org.jfree.chart.event.AxisChangeEvent((org.jfree.chart.axis.Axis) numberAxis23);
        categoryPlot18.axisChanged(axisChangeEvent26);
        categoryPlot0.axisChanged(axisChangeEvent26);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertNotNull(list17);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        java.awt.Shape shape6 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color7 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem8 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape6, (java.awt.Paint) color7);
        java.lang.Number[] numberArray13 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray16 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray19 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray22 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray25 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[] numberArray28 = new java.lang.Number[] { 0.05d, (short) 0 };
        java.lang.Number[][] numberArray29 = new java.lang.Number[][] { numberArray13, numberArray16, numberArray19, numberArray22, numberArray25, numberArray28 };
        org.jfree.data.category.CategoryDataset categoryDataset30 = org.jfree.data.general.DatasetUtilities.createCategoryDataset("java.awt.Color[r=192,g=0,b=0]", "hi!", numberArray29);
        java.lang.Number number31 = org.jfree.data.general.DatasetUtilities.findMaximumStackedRangeValue(categoryDataset30);
        org.jfree.data.Range range33 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(categoryDataset30, 0.0d);
        legendItem8.setDataset((org.jfree.data.general.Dataset) categoryDataset30);
        java.awt.Stroke stroke35 = legendItem8.getOutlineStroke();
        java.awt.Paint paint36 = legendItem8.getOutlinePaint();
        int int37 = legendItem8.getDatasetIndex();
        org.junit.Assert.assertNotNull(shape6);
        org.junit.Assert.assertNotNull(color7);
        org.junit.Assert.assertNotNull(numberArray13);
        org.junit.Assert.assertNotNull(numberArray16);
        org.junit.Assert.assertNotNull(numberArray19);
        org.junit.Assert.assertNotNull(numberArray22);
        org.junit.Assert.assertNotNull(numberArray25);
        org.junit.Assert.assertNotNull(numberArray28);
        org.junit.Assert.assertNotNull(numberArray29);
        org.junit.Assert.assertNotNull(categoryDataset30);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.3d + "'", number31.equals(0.3d));
        org.junit.Assert.assertNotNull(range33);
        org.junit.Assert.assertNotNull(stroke35);
        org.junit.Assert.assertNotNull(paint36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        java.awt.Font font1 = org.jfree.chart.renderer.AbstractRenderer.DEFAULT_VALUE_LABEL_FONT;
        org.jfree.chart.plot.CategoryPlot categoryPlot2 = new org.jfree.chart.plot.CategoryPlot();
        int int3 = categoryPlot2.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot2.getRangeAxisEdge();
        java.awt.Paint paint5 = categoryPlot2.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge6 = categoryPlot2.getRangeAxisEdge();
        boolean boolean7 = categoryPlot2.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double11 = categoryAxis8.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit12 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int13 = numberTickUnit12.getMinorTickCount();
        java.awt.Font font14 = categoryAxis8.getTickLabelFont((java.lang.Comparable) numberTickUnit12);
        categoryPlot2.setNoDataMessageFont(font14);
        int int16 = categoryPlot2.getDatasetCount();
        org.jfree.chart.JFreeChart jFreeChart18 = new org.jfree.chart.JFreeChart("RectangleInsets[t=0.0,l=0.0,b=0.0,r=0.0]", font1, (org.jfree.chart.plot.Plot) categoryPlot2, false);
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertNotNull(paint5);
        org.junit.Assert.assertNotNull(rectangleEdge6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(font14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.jfree.data.xy.TableXYDataset tableXYDataset0 = null;
        try {
            org.jfree.data.Range range2 = org.jfree.data.general.DatasetUtilities.findStackedRangeBounds(tableXYDataset0, (double) 10L);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'dataset' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        java.awt.Graphics2D graphics2D1 = null;
        java.awt.FontMetrics fontMetrics2 = null;
        try {
            java.awt.geom.Rectangle2D rectangle2D3 = org.jfree.chart.text.TextUtilities.getTextBounds("VerticalAlignment.CENTER", graphics2D1, fontMetrics2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.jfree.chart.plot.Plot plot0 = null;
        try {
            org.jfree.chart.JFreeChart jFreeChart1 = new org.jfree.chart.JFreeChart(plot0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Null 'plot' argument.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        boolean boolean4 = statisticalBarRenderer0.getAutoPopulateSeriesOutlineStroke();
        boolean boolean5 = statisticalBarRenderer0.getBaseSeriesVisible();
        statisticalBarRenderer0.setMinimumBarLength((double) 10);
        java.awt.Graphics2D graphics2D8 = null;
        org.jfree.chart.plot.CategoryPlot categoryPlot9 = null;
        org.jfree.chart.axis.NumberAxis numberAxis11 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis11.setPositiveArrowVisible(true);
        numberAxis11.setFixedAutoRange((double) (short) 0);
        numberAxis11.setRangeWithMargins((double) 0, (double) '#');
        numberAxis11.setAutoRange(false);
        java.awt.Font font22 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock23 = new org.jfree.chart.block.LabelBlock("ClassContext", font22);
        labelBlock23.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle26 = new org.jfree.chart.title.TextTitle();
        boolean boolean27 = labelBlock23.equals((java.lang.Object) textTitle26);
        java.awt.geom.Rectangle2D rectangle2D28 = textTitle26.getBounds();
        statisticalBarRenderer0.drawRangeGridline(graphics2D8, categoryPlot9, (org.jfree.chart.axis.ValueAxis) numberAxis11, rectangle2D28, (double) (-16711681));
        boolean boolean31 = numberAxis11.isTickMarksVisible();
        java.awt.Paint paint32 = numberAxis11.getTickLabelPaint();
        boolean boolean33 = numberAxis11.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(font22);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(rectangle2D28);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(paint32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setWidth((double) '4');
        java.lang.Object obj3 = textTitle0.clone();
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.data.Range range6 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint7 = new org.jfree.chart.block.RectangleConstraint((double) (byte) 100, range6);
        double double8 = rectangleConstraint7.getWidth();
        org.jfree.chart.block.RectangleConstraint rectangleConstraint9 = rectangleConstraint7.toUnconstrainedWidth();
        double double10 = rectangleConstraint7.getHeight();
        try {
            org.jfree.chart.util.Size2D size2D11 = textTitle0.arrange(graphics2D4, rectangleConstraint7);
            org.junit.Assert.fail("Expected exception of type java.lang.RuntimeException; message: Not yet implemented.");
        } catch (java.lang.RuntimeException e) {
        }
        org.junit.Assert.assertNotNull(obj3);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.0d + "'", double8 == 100.0d);
        org.junit.Assert.assertNotNull(rectangleConstraint9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis0.setCategoryLabelPositionOffset((int) ' ');
        org.jfree.chart.plot.CategoryPlot categoryPlot6 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation8 = null;
        categoryPlot6.setDomainAxisLocation(15, axisLocation8, true);
        categoryPlot6.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset12 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer13 = categoryPlot6.getRendererForDataset(categoryDataset12);
        java.awt.Stroke stroke14 = categoryPlot6.getOutlineStroke();
        boolean boolean15 = categoryAxis0.equals((java.lang.Object) categoryPlot6);
        java.awt.Paint paint16 = null;
        try {
            categoryAxis0.setTickLabelPaint(paint16);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'paint' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(categoryItemRenderer13);
        org.junit.Assert.assertNotNull(stroke14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        textTitle6.setID("ClassContext");
        java.lang.Object obj9 = null;
        columnArrangement5.add((org.jfree.chart.block.Block) textTitle6, obj9);
        boolean boolean11 = textAnchor0.equals((java.lang.Object) textTitle6);
        double double12 = textTitle6.getWidth();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment13 = textTitle6.getHorizontalAlignment();
        java.lang.String str14 = textTitle6.getText();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(horizontalAlignment13);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "" + "'", str14.equals(""));
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        java.lang.Class class1 = null;
//        java.io.InputStream inputStream2 = org.jfree.chart.util.ObjectUtilities.getResourceAsStream("VerticalAlignment.CENTER", class1);
//        org.junit.Assert.assertNull(inputStream2);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        java.awt.Font font2 = textTitle1.getFont();
        org.junit.Assert.assertNotNull(font2);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.jfree.data.Range range0 = null;
        try {
            org.jfree.data.Range range3 = org.jfree.data.Range.shift(range0, 10.0d, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

//    @Test
//    public void test471() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test471");
//        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
//        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
//        org.jfree.chart.util.Layer layer6 = null;
//        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
//        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
//        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
//        java.lang.Object obj10 = jFreeChart9.clone();
//        jFreeChart9.setBackgroundImageAlignment((-4194304));
//        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer13 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
//        java.awt.Stroke stroke14 = statisticalBarRenderer13.getBaseStroke();
//        java.awt.Paint paint16 = statisticalBarRenderer13.getSeriesOutlinePaint((-1));
//        boolean boolean17 = statisticalBarRenderer13.getAutoPopulateSeriesOutlineStroke();
//        boolean boolean18 = statisticalBarRenderer13.getBaseSeriesVisible();
//        java.awt.Color color20 = java.awt.Color.white;
//        statisticalBarRenderer13.setSeriesPaint((int) (byte) 0, (java.awt.Paint) color20);
//        org.jfree.chart.title.LegendTitle legendTitle22 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer13);
//        org.jfree.chart.plot.CategoryPlot categoryPlot23 = new org.jfree.chart.plot.CategoryPlot();
//        org.jfree.chart.axis.AxisLocation axisLocation25 = null;
//        categoryPlot23.setDomainAxisLocation(15, axisLocation25, true);
//        categoryPlot23.clearRangeAxes();
//        categoryPlot23.setAnchorValue((double) (short) 0);
//        org.jfree.chart.ui.ProjectInfo projectInfo31 = org.jfree.chart.JFreeChart.INFO;
//        java.lang.String str32 = projectInfo31.getCopyright();
//        org.jfree.chart.ui.Library[] libraryArray33 = projectInfo31.getLibraries();
//        java.lang.String str34 = projectInfo31.getLicenceText();
//        java.awt.Image image35 = projectInfo31.getLogo();
//        categoryPlot23.setBackgroundImage(image35);
//        org.jfree.chart.plot.ValueMarker valueMarker38 = new org.jfree.chart.plot.ValueMarker((-1.0d));
//        categoryPlot23.addRangeMarker((org.jfree.chart.plot.Marker) valueMarker38);
//        org.jfree.chart.util.RectangleAnchor rectangleAnchor40 = valueMarker38.getLabelAnchor();
//        legendTitle22.setLegendItemGraphicLocation(rectangleAnchor40);
//        jFreeChart9.addLegend(legendTitle22);
//        org.jfree.chart.title.TextTitle textTitle43 = new org.jfree.chart.title.TextTitle();
//        textTitle43.setID("ClassContext");
//        jFreeChart9.setTitle(textTitle43);
//        try {
//            org.jfree.chart.plot.XYPlot xYPlot47 = jFreeChart9.getXYPlot();
//            org.junit.Assert.fail("Expected exception of type java.lang.ClassCastException; message: org.jfree.chart.plot.CategoryPlot cannot be cast to org.jfree.chart.plot.XYPlot");
//        } catch (java.lang.ClassCastException e) {
//        }
//        org.junit.Assert.assertNull(collection7);
//        org.junit.Assert.assertNull(categoryAxis8);
//        org.junit.Assert.assertNotNull(obj10);
//        org.junit.Assert.assertNotNull(stroke14);
//        org.junit.Assert.assertNull(paint16);
//        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
//        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + true + "'", boolean18 == true);
//        org.junit.Assert.assertNotNull(color20);
//        org.junit.Assert.assertNotNull(projectInfo31);
//        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str32.equals("java.awt.Color[r=192,g=0,b=0]"));
//        org.junit.Assert.assertNotNull(libraryArray33);
//        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "ThreadContext" + "'", str34.equals("ThreadContext"));
//        org.junit.Assert.assertNotNull(image35);
//        org.junit.Assert.assertNotNull(rectangleAnchor40);
//    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        java.lang.String str0 = org.jfree.chart.util.ObjectUtilities.THREAD_CONTEXT;
        org.junit.Assert.assertTrue("'" + str0 + "' != '" + "ThreadContext" + "'", str0.equals("ThreadContext"));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        org.jfree.chart.event.RendererChangeEvent rendererChangeEvent3 = null;
        categoryPlot0.rendererChanged(rendererChangeEvent3);
        categoryPlot0.setRangeCrosshairLockedOnData(false);
        int int7 = categoryPlot0.getDatasetCount();
        categoryPlot0.setAnchorValue((double) (byte) 10);
        java.awt.Stroke stroke10 = categoryPlot0.getRangeCrosshairStroke();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(stroke10);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        java.awt.Color color1 = java.awt.Color.white;
        int int2 = color1.getGreen();
        int int3 = color1.getRed();
        java.awt.Color color4 = java.awt.Color.getColor("ThreadContext", color1);
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 255 + "'", int2 == 255);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 255 + "'", int3 == 255);
        org.junit.Assert.assertNotNull(color4);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        java.awt.Graphics2D graphics2D1 = null;
        try {
            org.jfree.chart.text.TextUtilities.drawRotatedString("3", graphics2D1, (float) (byte) -1, (float) (short) 1, 0.05d, 0.0f, (float) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        numberAxis1.setAutoRange(false);
        java.text.NumberFormat numberFormat11 = null;
        numberAxis1.setNumberFormatOverride(numberFormat11);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double3 = categoryAxis0.getLabelAngle();
        boolean boolean4 = categoryAxis0.isTickMarksVisible();
        java.awt.Stroke stroke5 = categoryAxis0.getAxisLineStroke();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertNotNull(stroke5);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions0 = null;
        org.jfree.chart.util.RectangleAnchor rectangleAnchor1 = org.jfree.chart.util.RectangleAnchor.BOTTOM;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor2 = org.jfree.chart.text.TextBlockAnchor.TOP_LEFT;
        org.jfree.chart.axis.CategoryLabelPosition categoryLabelPosition3 = new org.jfree.chart.axis.CategoryLabelPosition(rectangleAnchor1, textBlockAnchor2);
        try {
            org.jfree.chart.axis.CategoryLabelPositions categoryLabelPositions4 = org.jfree.chart.axis.CategoryLabelPositions.replaceBottomPosition(categoryLabelPositions0, categoryLabelPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Null 'base' argument.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(rectangleAnchor1);
        org.junit.Assert.assertNotNull(textBlockAnchor2);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        org.jfree.chart.plot.Plot plot11 = jFreeChart9.getPlot();
        java.awt.Stroke stroke12 = jFreeChart9.getBorderStroke();
        jFreeChart9.setNotify(true);
        java.lang.Object obj15 = jFreeChart9.clone();
        org.jfree.chart.title.TextTitle textTitle17 = new org.jfree.chart.title.TextTitle();
        java.awt.Font font18 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        textTitle17.setFont(font18);
        textTitle17.setHeight((double) (short) -1);
        try {
            jFreeChart9.addSubtitle(15, (org.jfree.chart.title.Title) textTitle17);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: The 'index' argument is out of range.");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(obj15);
        org.junit.Assert.assertNotNull(font18);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer7 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke8 = statisticalBarRenderer7.getBaseStroke();
        java.awt.Paint paint10 = statisticalBarRenderer7.getSeriesOutlinePaint((-1));
        boolean boolean11 = statisticalBarRenderer7.getAutoPopulateSeriesOutlineStroke();
        categoryPlot1.setRenderer((int) ' ', (org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer7, true);
        org.jfree.chart.JFreeChart jFreeChart14 = new org.jfree.chart.JFreeChart("ItemLabelAnchor.INSIDE7", (org.jfree.chart.plot.Plot) categoryPlot1);
        org.jfree.chart.ChartRenderingInfo chartRenderingInfo18 = null;
        try {
            java.awt.image.BufferedImage bufferedImage19 = jFreeChart14.createBufferedImage(0, 10, 0, chartRenderingInfo18);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Unknown image type 0");
        } catch (java.lang.IllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(stroke8);
        org.junit.Assert.assertNull(paint10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double9 = categoryAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int11 = numberTickUnit10.getMinorTickCount();
        java.awt.Font font12 = categoryAxis6.getTickLabelFont((java.lang.Comparable) numberTickUnit10);
        categoryPlot0.setNoDataMessageFont(font12);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer14 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke15 = statisticalBarRenderer14.getBaseStroke();
        java.awt.Paint paint17 = statisticalBarRenderer14.getSeriesOutlinePaint((-1));
        java.awt.Shape shape19 = statisticalBarRenderer14.getSeriesShape((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer20 = null;
        statisticalBarRenderer14.setGradientPaintTransformer(gradientPaintTransformer20);
        int int22 = categoryPlot0.getIndexOf((org.jfree.chart.renderer.category.CategoryItemRenderer) statisticalBarRenderer14);
        double double23 = statisticalBarRenderer14.getMinimumBarLength();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertNotNull(stroke15);
        org.junit.Assert.assertNull(paint17);
        org.junit.Assert.assertNull(shape19);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator1 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        org.jfree.chart.text.TextBlock textBlock2 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D3 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor6 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape10 = textBlock2.calculateBounds(graphics2D3, 0.0f, (float) (-1), textBlockAnchor6, 0.0f, (float) 10, (double) 10);
        org.jfree.chart.entity.LegendItemEntity legendItemEntity11 = new org.jfree.chart.entity.LegendItemEntity(shape10);
        org.jfree.chart.axis.AxisLocation axisLocation12 = org.jfree.chart.axis.AxisLocation.BOTTOM_OR_LEFT;
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        int int14 = categoryPlot13.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge15 = categoryPlot13.getRangeAxisEdge();
        java.awt.Paint paint16 = categoryPlot13.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge17 = categoryPlot13.getRangeAxisEdge();
        org.jfree.chart.util.RectangleEdge rectangleEdge19 = categoryPlot13.getDomainAxisEdge(0);
        org.jfree.chart.plot.PlotRenderingInfo plotRenderingInfo22 = null;
        java.awt.geom.Point2D point2D23 = null;
        categoryPlot13.zoomDomainAxes((double) '4', (double) (-16711681), plotRenderingInfo22, point2D23);
        org.jfree.chart.plot.PlotOrientation plotOrientation25 = categoryPlot13.getOrientation();
        org.jfree.chart.util.RectangleEdge rectangleEdge26 = org.jfree.chart.plot.Plot.resolveDomainAxisLocation(axisLocation12, plotOrientation25);
        boolean boolean27 = legendItemEntity11.equals((java.lang.Object) rectangleEdge26);
        org.jfree.chart.plot.CategoryPlot categoryPlot28 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation30 = null;
        categoryPlot28.setDomainAxisLocation(15, axisLocation30, true);
        categoryPlot28.clearRangeAxes();
        categoryPlot28.setAnchorValue((double) (short) 0);
        categoryPlot28.setWeight((int) (byte) 10);
        categoryPlot28.setRangeCrosshairVisible(true);
        org.jfree.data.statistics.DefaultStatisticalCategoryDataset defaultStatisticalCategoryDataset41 = new org.jfree.data.statistics.DefaultStatisticalCategoryDataset();
        java.util.List list42 = defaultStatisticalCategoryDataset41.getColumnKeys();
        categoryPlot28.setDataset((int) (short) 10, (org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset41);
        legendItemEntity11.setDataset((org.jfree.data.general.Dataset) defaultStatisticalCategoryDataset41);
        org.jfree.data.Range range46 = org.jfree.data.general.DatasetUtilities.iterateCategoryRangeBounds((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset41, false);
        try {
            java.lang.String str48 = standardCategorySeriesLabelGenerator1.generateLabel((org.jfree.data.category.CategoryDataset) defaultStatisticalCategoryDataset41, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(textBlockAnchor6);
        org.junit.Assert.assertNotNull(shape10);
        org.junit.Assert.assertNotNull(axisLocation12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge15);
        org.junit.Assert.assertNotNull(paint16);
        org.junit.Assert.assertNotNull(rectangleEdge17);
        org.junit.Assert.assertNotNull(rectangleEdge19);
        org.junit.Assert.assertNotNull(plotOrientation25);
        org.junit.Assert.assertNotNull(rectangleEdge26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(list42);
        org.junit.Assert.assertNull(range46);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        jFreeChart9.clearSubtitles();
        jFreeChart9.setBackgroundImageAlpha(0.5f);
        java.awt.Stroke stroke13 = jFreeChart9.getBorderStroke();
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(stroke13);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Color color1 = org.jfree.chart.ChartColor.DARK_RED;
        java.lang.String str2 = color1.toString();
        statisticalBarRenderer0.setBasePaint((java.awt.Paint) color1, true);
        statisticalBarRenderer0.removeAnnotations();
        statisticalBarRenderer0.removeAnnotations();
        org.junit.Assert.assertNotNull(color1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "java.awt.Color[r=192,g=0,b=0]" + "'", str2.equals("java.awt.Color[r=192,g=0,b=0]"));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("ClassContext");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        org.jfree.chart.JFreeChart jFreeChart4 = titleChangeEvent3.getChart();
        org.junit.Assert.assertNull(jFreeChart4);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.jfree.chart.title.TextTitle textTitle1 = new org.jfree.chart.title.TextTitle("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        textTitle1.setURLText("DatasetRenderingOrder.FORWARD");
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.jfree.chart.text.TextAnchor textAnchor0 = org.jfree.chart.text.TextAnchor.HALF_ASCENT_CENTER;
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment1 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment2 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement5 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment1, verticalAlignment2, (double) ' ', (double) '4');
        org.jfree.chart.title.TextTitle textTitle6 = new org.jfree.chart.title.TextTitle();
        textTitle6.setID("ClassContext");
        java.lang.Object obj9 = null;
        columnArrangement5.add((org.jfree.chart.block.Block) textTitle6, obj9);
        boolean boolean11 = textAnchor0.equals((java.lang.Object) textTitle6);
        double double12 = textTitle6.getWidth();
        double double13 = textTitle6.getHeight();
        java.awt.Graphics2D graphics2D14 = null;
        java.awt.Font font16 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock17 = new org.jfree.chart.block.LabelBlock("ClassContext", font16);
        labelBlock17.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle20 = new org.jfree.chart.title.TextTitle();
        boolean boolean21 = labelBlock17.equals((java.lang.Object) textTitle20);
        java.awt.geom.Rectangle2D rectangle2D22 = textTitle20.getBounds();
        textTitle6.draw(graphics2D14, rectangle2D22);
        org.jfree.chart.axis.CategoryAxis categoryAxis25 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis25.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double28 = categoryAxis25.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit29 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int30 = numberTickUnit29.getMinorTickCount();
        java.awt.Font font31 = categoryAxis25.getTickLabelFont((java.lang.Comparable) numberTickUnit29);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer33 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        org.jfree.chart.labels.CategoryToolTipGenerator categoryToolTipGenerator34 = null;
        statisticalBarRenderer33.setBaseToolTipGenerator(categoryToolTipGenerator34, false);
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition38 = null;
        statisticalBarRenderer33.setSeriesNegativeItemLabelPosition(10, itemLabelPosition38);
        java.awt.Shape shape46 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        java.awt.Color color47 = java.awt.Color.BLUE;
        org.jfree.chart.LegendItem legendItem48 = new org.jfree.chart.LegendItem("ClassContext", "", "ClassContext", "ThreadContext", shape46, (java.awt.Paint) color47);
        statisticalBarRenderer33.setBaseItemLabelPaint((java.awt.Paint) color47);
        categoryAxis25.setTickLabelPaint((java.lang.Comparable) 100L, (java.awt.Paint) color47);
        java.awt.Color color51 = java.awt.Color.getColor("3", color47);
        textTitle6.setPaint((java.awt.Paint) color47);
        java.lang.String str53 = textTitle6.getToolTipText();
        org.junit.Assert.assertNotNull(textAnchor0);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(font16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(rectangle2D22);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(font31);
        org.junit.Assert.assertNotNull(shape46);
        org.junit.Assert.assertNotNull(color47);
        org.junit.Assert.assertNotNull(color51);
        org.junit.Assert.assertNull(str53);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.jfree.chart.text.TextBlock textBlock0 = new org.jfree.chart.text.TextBlock();
        java.awt.Graphics2D graphics2D1 = null;
        org.jfree.chart.text.TextBlockAnchor textBlockAnchor4 = org.jfree.chart.text.TextBlockAnchor.BOTTOM_CENTER;
        java.awt.Shape shape8 = textBlock0.calculateBounds(graphics2D1, 0.0f, (float) (-1), textBlockAnchor4, 0.0f, (float) 10, (double) 10);
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment9 = org.jfree.chart.util.HorizontalAlignment.CENTER;
        textBlock0.setLineAlignment(horizontalAlignment9);
        org.junit.Assert.assertNotNull(textBlockAnchor4);
        org.junit.Assert.assertNotNull(shape8);
        org.junit.Assert.assertNotNull(horizontalAlignment9);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setLowerMargin((double) (-4194304));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        int int1 = categoryPlot0.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge2 = categoryPlot0.getRangeAxisEdge();
        java.awt.Paint paint3 = categoryPlot0.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge4 = categoryPlot0.getRangeAxisEdge();
        boolean boolean5 = categoryPlot0.isDomainZoomable();
        org.jfree.chart.axis.CategoryAxis categoryAxis6 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis6.setMaximumCategoryLabelWidthRatio((float) ' ');
        double double9 = categoryAxis6.getLabelAngle();
        org.jfree.chart.axis.NumberTickUnit numberTickUnit10 = org.jfree.chart.axis.NumberAxis.DEFAULT_TICK_UNIT;
        int int11 = numberTickUnit10.getMinorTickCount();
        java.awt.Font font12 = categoryAxis6.getTickLabelFont((java.lang.Comparable) numberTickUnit10);
        categoryPlot0.setNoDataMessageFont(font12);
        int int14 = categoryPlot0.getDatasetCount();
        boolean boolean15 = categoryPlot0.isRangeGridlinesVisible();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge2);
        org.junit.Assert.assertNotNull(paint3);
        org.junit.Assert.assertNotNull(rectangleEdge4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(numberTickUnit10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(font12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Stroke stroke4 = statisticalBarRenderer0.getBaseStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition6 = null;
        statisticalBarRenderer0.setSeriesNegativeItemLabelPosition(255, itemLabelPosition6);
        boolean boolean8 = statisticalBarRenderer0.getBaseItemLabelsVisible();
        org.jfree.chart.labels.StandardCategorySeriesLabelGenerator standardCategorySeriesLabelGenerator10 = new org.jfree.chart.labels.StandardCategorySeriesLabelGenerator("ClassContext");
        statisticalBarRenderer0.setLegendItemLabelGenerator((org.jfree.chart.labels.CategorySeriesLabelGenerator) standardCategorySeriesLabelGenerator10);
        org.jfree.chart.plot.CategoryPlot categoryPlot13 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation15 = null;
        categoryPlot13.setDomainAxisLocation(15, axisLocation15, true);
        org.jfree.chart.util.Layer layer18 = null;
        java.util.Collection collection19 = categoryPlot13.getDomainMarkers(layer18);
        org.jfree.chart.axis.CategoryAxis categoryAxis20 = categoryPlot13.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart21 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot13);
        java.lang.Object obj22 = jFreeChart21.clone();
        jFreeChart21.setBackgroundImageAlignment((-4194304));
        java.awt.Paint paint25 = jFreeChart21.getBorderPaint();
        statisticalBarRenderer0.setBaseFillPaint(paint25);
        org.jfree.chart.block.ColumnArrangement columnArrangement27 = new org.jfree.chart.block.ColumnArrangement();
        org.jfree.chart.util.HorizontalAlignment horizontalAlignment28 = null;
        org.jfree.chart.util.VerticalAlignment verticalAlignment29 = null;
        org.jfree.chart.block.ColumnArrangement columnArrangement32 = new org.jfree.chart.block.ColumnArrangement(horizontalAlignment28, verticalAlignment29, (double) ' ', (double) '4');
        columnArrangement32.clear();
        columnArrangement32.clear();
        org.jfree.chart.title.LegendTitle legendTitle35 = new org.jfree.chart.title.LegendTitle((org.jfree.chart.LegendItemSource) statisticalBarRenderer0, (org.jfree.chart.block.Arrangement) columnArrangement27, (org.jfree.chart.block.Arrangement) columnArrangement32);
        java.awt.Paint paint37 = statisticalBarRenderer0.lookupSeriesFillPaint(15);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNotNull(stroke4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNull(collection19);
        org.junit.Assert.assertNull(categoryAxis20);
        org.junit.Assert.assertNotNull(obj22);
        org.junit.Assert.assertNotNull(paint25);
        org.junit.Assert.assertNotNull(paint37);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.util.Layer layer5 = null;
        java.util.Collection collection6 = categoryPlot0.getDomainMarkers(layer5);
        org.jfree.chart.axis.CategoryAxis categoryAxis7 = categoryPlot0.getDomainAxis();
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis8.setMaximumCategoryLabelWidthRatio((float) ' ');
        categoryAxis8.setTickLabelsVisible(true);
        categoryAxis8.setLowerMargin((double) 100.0f);
        int int15 = categoryPlot0.getDomainAxisIndex(categoryAxis8);
        categoryPlot0.setRangeGridlinesVisible(false);
        org.jfree.chart.plot.DatasetRenderingOrder datasetRenderingOrder18 = categoryPlot0.getDatasetRenderingOrder();
        org.junit.Assert.assertNull(collection6);
        org.junit.Assert.assertNull(categoryAxis7);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1) + "'", int15 == (-1));
        org.junit.Assert.assertNotNull(datasetRenderingOrder18);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.jfree.chart.title.TextTitle textTitle0 = new org.jfree.chart.title.TextTitle();
        textTitle0.setID("ClassContext");
        org.jfree.chart.event.TitleChangeEvent titleChangeEvent3 = new org.jfree.chart.event.TitleChangeEvent((org.jfree.chart.title.Title) textTitle0);
        java.awt.Graphics2D graphics2D4 = null;
        org.jfree.chart.axis.NumberAxis numberAxis6 = new org.jfree.chart.axis.NumberAxis("(C)opyright 2000-2007, by Object Refinery Limited and Contributors");
        boolean boolean7 = numberAxis6.isVerticalTickLabels();
        org.jfree.data.Range range8 = numberAxis6.getRange();
        org.jfree.data.Range range9 = null;
        org.jfree.chart.block.RectangleConstraint rectangleConstraint10 = new org.jfree.chart.block.RectangleConstraint(range8, range9);
        try {
            org.jfree.chart.util.Size2D size2D11 = textTitle0.arrange(graphics2D4, rectangleConstraint10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(range8);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        categoryPlot0.clearRangeAxes();
        org.jfree.data.category.CategoryDataset categoryDataset6 = null;
        org.jfree.chart.renderer.category.CategoryItemRenderer categoryItemRenderer7 = categoryPlot0.getRendererForDataset(categoryDataset6);
        org.jfree.chart.plot.DrawingSupplier drawingSupplier8 = categoryPlot0.getDrawingSupplier();
        categoryPlot0.setRangeCrosshairValue((double) ' ', false);
        float float12 = categoryPlot0.getBackgroundAlpha();
        org.junit.Assert.assertNull(categoryItemRenderer7);
        org.junit.Assert.assertNotNull(drawingSupplier8);
        org.junit.Assert.assertTrue("'" + float12 + "' != '" + 1.0f + "'", float12 == 1.0f);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.jfree.chart.axis.CategoryAxis categoryAxis0 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis0.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis0.setMaximumCategoryLabelWidthRatio((float) (-1L));
        float float6 = categoryAxis0.getMaximumCategoryLabelWidthRatio();
        categoryAxis0.removeCategoryLabelToolTip((java.lang.Comparable) "AxisLocation.BOTTOM_OR_LEFT");
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + (-1.0f) + "'", float6 == (-1.0f));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.jfree.chart.plot.CategoryPlot categoryPlot1 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation3 = null;
        categoryPlot1.setDomainAxisLocation(15, axisLocation3, true);
        org.jfree.chart.util.Layer layer6 = null;
        java.util.Collection collection7 = categoryPlot1.getDomainMarkers(layer6);
        org.jfree.chart.axis.CategoryAxis categoryAxis8 = categoryPlot1.getDomainAxis();
        org.jfree.chart.JFreeChart jFreeChart9 = new org.jfree.chart.JFreeChart("hi!", (org.jfree.chart.plot.Plot) categoryPlot1);
        java.lang.Object obj10 = jFreeChart9.clone();
        org.jfree.chart.plot.Plot plot11 = jFreeChart9.getPlot();
        java.awt.Stroke stroke12 = jFreeChart9.getBorderStroke();
        jFreeChart9.setNotify(true);
        jFreeChart9.setTextAntiAlias(true);
        java.awt.Graphics2D graphics2D17 = null;
        org.jfree.chart.axis.CategoryAxis categoryAxis18 = new org.jfree.chart.axis.CategoryAxis();
        categoryAxis18.addCategoryLabelToolTip((java.lang.Comparable) 0.0d, "hi!");
        categoryAxis18.setMaximumCategoryLabelWidthRatio((float) (-1L));
        java.awt.Graphics2D graphics2D24 = null;
        org.jfree.chart.axis.AxisState axisState25 = null;
        java.awt.Font font27 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock28 = new org.jfree.chart.block.LabelBlock("ClassContext", font27);
        labelBlock28.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        org.jfree.chart.title.TextTitle textTitle31 = new org.jfree.chart.title.TextTitle();
        boolean boolean32 = labelBlock28.equals((java.lang.Object) textTitle31);
        java.awt.geom.Rectangle2D rectangle2D33 = textTitle31.getBounds();
        org.jfree.chart.plot.CategoryPlot categoryPlot34 = new org.jfree.chart.plot.CategoryPlot();
        int int35 = categoryPlot34.getWeight();
        org.jfree.chart.util.RectangleEdge rectangleEdge36 = categoryPlot34.getRangeAxisEdge();
        java.awt.Paint paint37 = categoryPlot34.getBackgroundPaint();
        org.jfree.chart.util.RectangleEdge rectangleEdge38 = categoryPlot34.getRangeAxisEdge();
        java.util.List list39 = categoryAxis18.refreshTicks(graphics2D24, axisState25, rectangle2D33, rectangleEdge38);
        org.jfree.chart.entity.ChartEntity chartEntity42 = new org.jfree.chart.entity.ChartEntity((java.awt.Shape) rectangle2D33, "TextAnchor.CENTER_RIGHT", "ItemLabelAnchor.INSIDE7");
        try {
            jFreeChart9.draw(graphics2D17, rectangle2D33);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(collection7);
        org.junit.Assert.assertNull(categoryAxis8);
        org.junit.Assert.assertNotNull(obj10);
        org.junit.Assert.assertNotNull(plot11);
        org.junit.Assert.assertNotNull(stroke12);
        org.junit.Assert.assertNotNull(font27);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(rectangle2D33);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(rectangleEdge36);
        org.junit.Assert.assertNotNull(paint37);
        org.junit.Assert.assertNotNull(rectangleEdge38);
        org.junit.Assert.assertNotNull(list39);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer0 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke1 = statisticalBarRenderer0.getBaseStroke();
        java.awt.Paint paint3 = statisticalBarRenderer0.getSeriesOutlinePaint((-1));
        java.awt.Shape shape5 = statisticalBarRenderer0.getSeriesShape((int) (byte) 100);
        org.jfree.chart.util.GradientPaintTransformer gradientPaintTransformer6 = null;
        statisticalBarRenderer0.setGradientPaintTransformer(gradientPaintTransformer6);
        org.jfree.chart.renderer.category.StatisticalBarRenderer statisticalBarRenderer9 = new org.jfree.chart.renderer.category.StatisticalBarRenderer();
        java.awt.Stroke stroke10 = statisticalBarRenderer9.getBaseStroke();
        java.awt.Paint paint12 = statisticalBarRenderer9.getSeriesOutlinePaint((-1));
        boolean boolean13 = statisticalBarRenderer9.getAutoPopulateSeriesOutlineStroke();
        org.jfree.chart.labels.ItemLabelPosition itemLabelPosition16 = statisticalBarRenderer9.getPositiveItemLabelPosition(0, 15);
        statisticalBarRenderer0.setSeriesPositiveItemLabelPosition(0, itemLabelPosition16, true);
        org.jfree.chart.axis.NumberAxis numberAxis20 = new org.jfree.chart.axis.NumberAxis();
        java.awt.Shape shape21 = numberAxis20.getUpArrow();
        org.jfree.chart.entity.ChartEntity chartEntity24 = new org.jfree.chart.entity.ChartEntity(shape21, "hi!", "[size=1]");
        statisticalBarRenderer0.setSeriesShape((int) '4', shape21, false);
        org.jfree.chart.entity.ChartEntity chartEntity27 = new org.jfree.chart.entity.ChartEntity(shape21);
        org.junit.Assert.assertNotNull(stroke1);
        org.junit.Assert.assertNull(paint3);
        org.junit.Assert.assertNull(shape5);
        org.junit.Assert.assertNotNull(stroke10);
        org.junit.Assert.assertNull(paint12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(itemLabelPosition16);
        org.junit.Assert.assertNotNull(shape21);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.awt.Font font1 = org.jfree.chart.title.LegendTitle.DEFAULT_ITEM_FONT;
        org.jfree.chart.block.LabelBlock labelBlock2 = new org.jfree.chart.block.LabelBlock("ClassContext", font1);
        labelBlock2.setToolTipText("java.awt.Color[r=192,g=0,b=0]");
        labelBlock2.setToolTipText("");
        java.lang.Object obj7 = labelBlock2.clone();
        java.awt.Paint paint8 = labelBlock2.getPaint();
        org.junit.Assert.assertNotNull(font1);
        org.junit.Assert.assertNotNull(obj7);
        org.junit.Assert.assertNotNull(paint8);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.jfree.chart.axis.NumberAxis numberAxis1 = new org.jfree.chart.axis.NumberAxis("ThreadContext");
        numberAxis1.setPositiveArrowVisible(true);
        numberAxis1.setFixedAutoRange((double) (short) 0);
        numberAxis1.setRangeWithMargins((double) 0, (double) '#');
        java.awt.Shape shape11 = org.jfree.chart.util.ShapeUtilities.createRegularCross((float) 10L, (float) (short) 100);
        org.jfree.chart.entity.ChartEntity chartEntity12 = new org.jfree.chart.entity.ChartEntity(shape11);
        numberAxis1.setDownArrow(shape11);
        numberAxis1.setFixedDimension((double) (-1L));
        boolean boolean16 = numberAxis1.isNegativeArrowVisible();
        org.junit.Assert.assertNotNull(shape11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.jfree.chart.plot.CategoryPlot categoryPlot0 = new org.jfree.chart.plot.CategoryPlot();
        org.jfree.chart.axis.AxisLocation axisLocation2 = null;
        categoryPlot0.setDomainAxisLocation(15, axisLocation2, true);
        org.jfree.chart.title.TextTitle textTitle5 = new org.jfree.chart.title.TextTitle();
        textTitle5.setID("ClassContext");
        org.jfree.chart.util.RectangleInsets rectangleInsets8 = textTitle5.getMargin();
        categoryPlot0.setInsets(rectangleInsets8, false);
        double double11 = rectangleInsets8.getLeft();
        org.jfree.chart.util.UnitType unitType12 = rectangleInsets8.getUnitType();
        org.junit.Assert.assertNotNull(rectangleInsets8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(unitType12);
    }
}

